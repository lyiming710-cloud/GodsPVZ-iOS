set -euo pipefail
OUT="$RUNNER_TEMP/stage9-startup-r2"
UNITY="$(cat "$OUT/unity-path.txt")"
PROJECT="$(cat "$OUT/project-path.txt")"
cp "$GITHUB_WORKSPACE/scripts/actions/GodsPVZSerializedReferenceProbeR28.cs" "$PROJECT/Assets/Editor/"
set +e
timeout --signal=TERM 600s xvfb-run -a -s '-screen 0 1280x720x24' "$UNITY" -batchmode -quit -force-glcore -projectPath "$PROJECT" -executeMethod GodsPVZSerializedReferenceProbeR28.Run -logFile "$OUT/evidence/r28-serialization-reimport-probe.log"
RC=$?
set -e
echo "$RC" > "$OUT/evidence/r28-serialization-reimport-probe-exit.txt"
[ "$RC" -eq 0 ]
python3 - "$OUT/evidence/r28-serialization-reimport-probe.json" <<'PY'
import json,sys
r=json.load(open(sys.argv[1]))
assert r['candidate_sha256']=='9081408a2226a79e23991355108540a0260a3966a500cecf4524f3cba9dfb364'
assert r['collection_complete'] and r['import_count']>=100 and r['source_bytes_unchanged'] and r['game_dll_unchanged']
assert not r['source_references_rewritten'] and not r['game_fields_assigned'] and not r['device_execution'] and not r['exceptions']
print('IMPORT_PROBE_COLLECTED_NO_RESOURCE_OR_GAME_ACCEPTANCE',r['import_count'])
PY
