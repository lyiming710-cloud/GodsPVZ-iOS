set -euo pipefail
OUT="$RUNNER_TEMP/stage9-startup-r2"
UNITY="$(cat "$OUT/unity-path.txt")"
PROJECT="$(cat "$OUT/project-path.txt")"
set +e
"$UNITY" -batchmode -nographics -quit -projectPath "$PROJECT" -executeMethod GodsPVZStartupAudit.Run -logFile "$OUT/evidence/startup-asset-audit.log"
RC=$?
set -e
echo "$RC" > "$OUT/evidence/startup-asset-audit-exit.txt"
[ "$RC" -eq 0 ]
python3 - "$OUT/evidence/startup-asset-audit.json" <<'PY'
import json,sys
data=json.load(open(sys.argv[1]))
assert data['pass'] and data['missing_components']==0
assert data['game_start_component'] and data['game_start_prefab'] and data['board_start_component']
assert data['core_blit_keyword']
assert data['unresolved_custom_dummy_shaders']==[]
PY
