set -euo pipefail
OUT="$RUNNER_TEMP/stage9-startup-r2"
PROJECT="$(cat "$OUT/project-path.txt")"
python3 scripts/actions/prepare_startup_r28_unity.py --project "$PROJECT" --candidate "$OUT/candidate/Assembly-CSharp-bulk401.dll" --evidence "$OUT/evidence"
