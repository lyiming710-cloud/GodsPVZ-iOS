set -euo pipefail
test -d /Applications/Xcode_16.4.app/Contents/Developer
sudo xcode-select -s /Applications/Xcode_16.4.app/Contents/Developer
xcodebuild -version
[ "$(xcrun --sdk iphoneos --show-sdk-version)" = '18.5' ]
xcrun --sdk iphoneos --find clang
command -v ditto
command -v python3
python3 -c 'import plistlib,struct,zipfile,hashlib'
