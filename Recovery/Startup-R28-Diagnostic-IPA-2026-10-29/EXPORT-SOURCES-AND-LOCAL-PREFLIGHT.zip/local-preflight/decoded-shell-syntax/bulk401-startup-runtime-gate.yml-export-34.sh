python3 scripts/actions/sanitize_unity_evidence.py "$RUNNER_TEMP/stage9-startup-r2/evidence" "$RUNNER_TEMP/stage9-startup-r2/public-evidence"
