set -euo pipefail
OUT="$RUNNER_TEMP/stage9-startup-r2"
E="$OUT/evidence"
X="$OUT/xcode"
PROJECT="$(cat "$OUT/project-path.txt")"
mapfile -t SDKS < <(find "$PROJECT/Assets" -type f -name Unity.VisualScripting.Core.dll)
[ "${#SDKS[@]}" = 1 ]
python3 scripts/actions/startup_r28_export_binding.py --xcode-dir "$X" --plugin "$PROJECT/Assets/Plugins/GodsPVZRuntime1.dll" --sdk "${SDKS[0]}" --build-report "$E/actual-unity-build-report.json"
cp "$X/startup-r28-export-binding.json" "$E/"
PBX="$X/Unity-iPhone.xcodeproj/project.pbxproj"
test -f "$PBX"
test -d "$X/Classes"
test -d "$X/Libraries"
test -d "$X/Data"
test -d "$X/Il2CppOutputProject"
ASSEMBLY="$(cat "$E/candidate-assembly-name.txt")"
test -f "$X/Il2CppOutputProject/Source/il2cppOutput/$ASSEMBLY.cpp"
test -f "$X/Data/Managed/Metadata/global-metadata.dat"
grep -Eq 'PRODUCT_BUNDLE_IDENTIFIER[[:space:]]*=[[:space:]]*"?com\.tipsGodsStudio\.godsPVZ"?;' "$PBX"
grep -Eq 'IPHONEOS_DEPLOYMENT_TARGET[[:space:]]*=[[:space:]]*12(\.0)?;' "$PBX"
grep -q 'GodsPVZ iOS Xcode export succeeded' "$E/ios-export.log"
CPP_COUNT="$(find "$X/Il2CppOutputProject/Source/il2cppOutput" -maxdepth 1 -type f -name '*.cpp' | wc -l | tr -d ' ')"
FILE_COUNT="$(find "$X" -type f | wc -l | tr -d ' ')"
SIZE="$(du -sb "$X" | awk '{print $1}')"
{
  echo 'IOS_XCODE_EXPORT=PASS'
  echo "unity_version=$UNITY_VERSION"
  echo "test_dll_sha256=$TEST_DLL_SHA256"
  echo 'r28_whole_game_acceptance=NOT_PROVEN_DIAGNOSTIC_ONLY'
  echo 'r28_fresh_linux_compiler=PASS_COMPLEX_LEVEL_LOSS_RETAINED'
  echo 'bundle_id=com.tipsGodsStudio.godsPVZ'
  echo 'deployment_target=12.0'
  echo 'scenes=Assets/Scenes/MainMenu.unity,Assets/Scenes/Board.unity'
  echo "il2cpp_cpp_count=$CPP_COUNT"
  echo "xcode_file_count=$FILE_COUNT"
  echo "xcode_size_bytes=$SIZE"
  echo 'production_promotion=NO_ISOLATED_GATE_ONLY'
} | tee "$E/RESULT.txt"
sha256sum "$X/Data/Managed/Metadata/global-metadata.dat" > "$E/generated-global-metadata.sha256"
sha256sum "$X/Il2CppOutputProject/Source/il2cppOutput/$ASSEMBLY.cpp" > "$E/generated-assembly-csharp-cpp.sha256"
grep -E 'PRODUCT_BUNDLE_IDENTIFIER|IPHONEOS_DEPLOYMENT_TARGET' "$PBX" | sort -u > "$E/pbx-settings.txt"
tar --zstd -cf "$OUT/GodsPVZ-Startup-R28-unsigned-test-Xcode.tar.zst" -C "$OUT" xcode
sha256sum "$OUT/GodsPVZ-Startup-R28-unsigned-test-Xcode.tar.zst" > "$E/xcode-archive.sha256"
