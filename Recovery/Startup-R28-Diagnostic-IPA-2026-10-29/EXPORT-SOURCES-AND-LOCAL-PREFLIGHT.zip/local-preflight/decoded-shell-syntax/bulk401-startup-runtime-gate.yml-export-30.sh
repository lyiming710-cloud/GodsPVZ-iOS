set -euo pipefail
OUT="$RUNNER_TEMP/stage9-startup-r2"
E="$OUT/evidence"
UNITY="$(cat "$OUT/unity-path.txt")"
PROJECT="$(cat "$OUT/project-path.txt")"
PLUGIN="$PROJECT/Assets/Plugins/GodsPVZRuntime1.dll"
[ "$(sha256sum "$PLUGIN" | awk '{print $1}')" = "$TEST_DLL_SHA256" ] || exit 68
python3 scripts/actions/instrument_startup_r28_build_helper.py --source "$GITHUB_WORKSPACE/Recovery/Startup-R3-2026-10-24/ios-support/Assets/Editor/GodsPVZIOSBuild.cs" --project "$PROJECT" --evidence "$E"
set +e
xvfb-run -a -s '-screen 0 1280x720x24' "$UNITY" -batchmode -quit -force-glcore -buildTarget iOS -projectPath "$PROJECT" -executeMethod GodsPVZBuildReportCaptureR28.ExportIOS -logFile "$E/ios-export.log" > "$E/ios-export.stdout" 2> "$E/ios-export.stderr"
RC=$?
set -e
echo "$RC" > "$E/ios-export-exit.txt"
[ "$RC" -eq 0 ] || exit 69
test -d "$OUT/xcode"
