set -euo pipefail
OUT="$RUNNER_TEMP/stage9-startup-r2"
E="$OUT/evidence"
UNITY="$(cat "$OUT/unity-path.txt")"
PROJECT="$(cat "$OUT/project-path.txt")"
set +e
python3 scripts/actions/preflight_bulk401_startup_editor.py --editor "$UNITY" --project "$PROJECT" --output "$OUT/helper-preflight"
RC=$?
set -e
cp "$OUT/helper-preflight/"*.log "$OUT/helper-preflight/"*.json "$OUT/helper-preflight/"*.rsp "$E/"
[ "$RC" -eq 0 ] || exit 70
CLIENT="$(dirname "$UNITY")/Data/Resources/Licensing/Client/Unity.Licensing.Client"
"$CLIENT" --help > "$E/licensing-client-help.txt" 2>&1
grep -q -- '--activate-all' "$E/licensing-client-help.txt"
grep -q -- '--deactivate-all' "$E/licensing-client-help.txt"
