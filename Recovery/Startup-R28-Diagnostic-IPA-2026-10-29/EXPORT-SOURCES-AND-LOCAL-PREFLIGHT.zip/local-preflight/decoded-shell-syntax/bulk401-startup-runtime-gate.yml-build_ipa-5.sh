set -euo pipefail
X="${{ runner.temp }}/build/xcode"
LOG="${{ runner.temp }}/build/xcodebuild.log"
echo "=== Building Xcode Project with Apple Clang (fixed R28 diagnostic input) ==="
xcodebuild \
  -project "$X/Unity-iPhone.xcodeproj" \
  -scheme Unity-iPhone \
  -configuration Release \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -derivedDataPath "${{ runner.temp }}/build/DerivedData" \
  ARCHS=arm64 \
  ONLY_ACTIVE_ARCH=NO \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  DEVELOPMENT_TEAM="" \
  PROVISIONING_PROFILE_SPECIFIER="" \
  PROVISIONING_PROFILE="" \
  ENABLE_USER_SCRIPT_SANDBOXING=NO \
  COMPILER_INDEX_STORE_ENABLE=NO \
  CONFIGURATION_BUILD_DIR="${{ runner.temp }}/build/DerivedData/Build/Products/Release-iphoneos" \
  clean build 2>&1 | tee "$LOG"
