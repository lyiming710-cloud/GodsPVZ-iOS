set -euo pipefail
ARCHIVE="$(find "${{ runner.temp }}/xcode-input" -name '*.tar.zst' -type f | head -n 1)"
test -f "$ARCHIVE"
command -v zstd >/dev/null || brew install zstd
mkdir -p "${{ runner.temp }}/build"
zstd -dc "$ARCHIVE" | tar -xf - -C "${{ runner.temp }}/build"
python3 scripts/actions/startup_r28_export_binding.py --xcode-dir "$RUNNER_TEMP/build/xcode"
