set -euo pipefail
OUT="$RUNNER_TEMP/stage9-startup-r2"
python3 - "$OUT" "$PARENT_DLL_SHA256" "$GITHUB_SHA" <<'PY'
from pathlib import Path
import sys,json,hashlib,shutil
out=Path(sys.argv[1]);src=out/'bulk401-qualified'
p=json.loads((src/'PROVENANCE.json').read_text())
assert p['status']=='BULK401_LINUX_AND_APPLE_CPP_PRECHECK_PASS'
assert p['linux_compiler']['exit']==0 and p['linux_compiler']['failed_game_tus']==0 and p['linux_compiler']['diagnostics']==0
assert p['source_commit']==sys.argv[3]
assert p['apple_compiler']['all_generated']==1030 and p['apple_compiler']['failed']==0
dll=src/'Assembly-CSharp-bulk401.dll'
assert hashlib.sha256(dll.read_bytes()).hexdigest()==sys.argv[2]
assert p['outputs']['unlinked']['sha256']==sys.argv[2]
name=(src/'candidate-assembly-name.txt').read_text().strip()
assert name in ('Assembly-CSharp','GodsPVZRuntime1')
shutil.copy2(dll,out/'candidate'/dll.name)
for n in ('PROVENANCE.json','candidate-inspection.txt','candidate-assembly-name.txt'):
    shutil.copy2(src/n,out/'evidence'/n)
PY
echo 'BULK401_CONVERSION_QUALIFIED_INPUT_PASS'
