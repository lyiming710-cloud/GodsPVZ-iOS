set -euo pipefail
TOOLS="$RUNNER_TEMP/bulk389-helper-tools"
E="$RUNNER_TEMP/helper-preflight-evidence"
mkdir -p "$E"
python3 scripts/actions/check_bulk389_helper_tools.py verify "$TOOLS"
set +e
python3 scripts/actions/preflight_bulk401_startup_editor.py \
  --editor "$TOOLS/Editor/Unity" \
  --project "$GITHUB_WORKSPACE/Recovery/Startup-R3-2026-10-24/ios-support" \
  --output "$RUNNER_TEMP/helper-compilation"
RC=$?
set -e
find "$RUNNER_TEMP/helper-compilation" -maxdepth 1 -type f \( -name '*.json' -o -name '*.log' -o -name '*.rsp' \) -exec cp '{}' "$E/" \;
[ "$RC" -eq 0 ]
set +e
python3 scripts/actions/preflight_custom_shader_editor.py \
  --editor "$TOOLS/Editor/Unity" \
  --prior "$RUNNER_TEMP/helper-compilation" \
  --source "$GITHUB_WORKSPACE/Recovery/Custom-Shaders-2026-10-24/ios-support/Assets/Editor/GodsPVZCustomShaderAudit.cs"
RC=$?
set -e
find "$RUNNER_TEMP/helper-compilation" -maxdepth 1 -type f \( -name '*.json' -o -name '*.log' -o -name '*.rsp' \) -exec cp '{}' "$E/" \;
[ "$RC" -eq 0 ]
set +e
python3 scripts/actions/preflight_startup_r28_ipa_editor.py --editor "$TOOLS/Editor/Unity" --prior "$RUNNER_TEMP/helper-compilation"
RC=$?
set -e
find "$RUNNER_TEMP/helper-compilation" -maxdepth 1 -type f \( -name '*.json' -o -name '*.log' -o -name '*.rsp' \) -exec cp '{}' "$E/" \;
[ "$RC" -eq 0 ]
CLIENT="$TOOLS/Editor/Data/Resources/Licensing/Client/Unity.Licensing.Client"
"$CLIENT" --help > "$E/licensing-client-help.txt" 2>&1
grep -q -- '--activate-all' "$E/licensing-client-help.txt"
grep -q -- '--deactivate-all' "$E/licensing-client-help.txt"
cp "$TOOLS/HELPER-TOOLS-MANIFEST.json" "$E/"
