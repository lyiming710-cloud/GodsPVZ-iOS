python3 scripts/actions/bind_bulk401_compiler_package.py --output "$RUNNER_TEMP/bulk401-package"
cp "$RUNNER_TEMP/BULK401-PIPELINE-CONTROLS.json" "$RUNNER_TEMP/bulk401-package/"
