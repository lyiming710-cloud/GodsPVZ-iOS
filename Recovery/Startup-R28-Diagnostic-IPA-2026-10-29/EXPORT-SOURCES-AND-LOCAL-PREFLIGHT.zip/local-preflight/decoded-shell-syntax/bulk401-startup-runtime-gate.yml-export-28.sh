set -euo pipefail
OUT="$RUNNER_TEMP/stage9-startup-r2"
UNITY="$(cat "$OUT/unity-path.txt")"
PROJECT="$(cat "$OUT/project-path.txt")"
set +e
timeout --signal=TERM 600s xvfb-run -a -s '-screen 0 1280x720x24' "$UNITY" -batchmode -force-glcore -projectPath "$PROJECT" -executeMethod GodsPVZCustomShaderAudit.BeginAfterStartup -logFile "$OUT/evidence/custom-shader-audit.log"
RC=$?
set -e
echo "$RC" > "$OUT/evidence/custom-shader-audit-exit.txt"
[ "$RC" -eq 0 ]
python3 - "$OUT/evidence/custom-shader-audit.json" <<'PY'
import json,sys
data=json.load(open(sys.argv[1]))
assert data['pass'] and len(data['compilations'])==76 and all(r['success'] and r['bytes']>0 for r in data['compilations'])
assert len(data['pixels'])==20 and all(r['pass'] for r in data['pixels']) and data['negative_compile_control']
assert not data['metal_device_execution'] and not data['game_pixel_equivalence']
PY
