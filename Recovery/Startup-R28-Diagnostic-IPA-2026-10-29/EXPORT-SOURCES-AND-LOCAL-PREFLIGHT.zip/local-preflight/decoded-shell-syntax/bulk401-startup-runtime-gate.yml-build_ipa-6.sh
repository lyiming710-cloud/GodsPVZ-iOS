set -euo pipefail
APP_FOUND="$(find "$RUNNER_TEMP/build/DerivedData/Build/Products/Release-iphoneos" -maxdepth 1 -name '*.app' -type d | head -n1)"
test -d "$APP_FOUND"
python3 scripts/actions/package_startup_r28_ipa.py --app "$APP_FOUND" --xcode-dir "$RUNNER_TEMP/build/xcode" --output-dir "$RUNNER_TEMP/ipa-output"
