set -euo pipefail
OUT="$RUNNER_TEMP/stage9-startup-r2"
E="$OUT/evidence"
UNITY="$(cat "$OUT/unity-path.txt")"
PROJECT="$(cat "$OUT/project-path.txt")"
cp "$GITHUB_WORKSPACE/scripts/actions/GodsPVZAssetCaseAudit.cs" "$PROJECT/Assets/Editor/"
set +e
xvfb-run -a -s '-screen 0 1280x720x24' "$UNITY" -batchmode -quit -force-glcore -buildTarget iOS -projectPath "$PROJECT" -executeMethod GodsPVZAssetCaseAudit.Run -logFile "$E/asset-case-import-audit.log" > "$E/asset-case-import-audit.stdout" 2> "$E/asset-case-import-audit.stderr"
RC=$?
set -e
echo "$RC" > "$E/asset-case-import-audit-exit.txt"
[ "$RC" -eq 0 ] || exit 73
python3 - "$E/asset-case-import-audit.json" <<'PY'
import json,sys
r=json.load(open(sys.argv[1]));assert r['assets']==12 and r['failed']==0 and all(row['pass'] for row in r['rows'])
PY
