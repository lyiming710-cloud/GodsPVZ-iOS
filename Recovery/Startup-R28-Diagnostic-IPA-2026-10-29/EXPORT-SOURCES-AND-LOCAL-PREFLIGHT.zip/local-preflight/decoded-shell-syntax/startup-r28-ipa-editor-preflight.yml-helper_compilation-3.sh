set -euo pipefail
PARTS="$RUNNER_TEMP/helper-editor-parts"
TOOLS="$RUNNER_TEMP/bulk389-helper-tools"
ROOT="$RUNNER_TEMP/helper-editor-source"
mkdir -p "$ROOT"
mapfile -t FILES < <(find "$PARTS" -maxdepth 1 -type f -name 'Unity-China-2022.3.44f1c1.tar.xz.part-*' | sort)
[ "${#FILES[@]}" = '15' ]
SHA="$({ for part in "${FILES[@]}"; do cat "$part"; done; } | sha256sum | awk '{print $1}')"
[ "$SHA" = '0008115c785784baddb19e2b13b384ac845438239f293efb0c2e8b1379a1fe14' ]
{ for part in "${FILES[@]}"; do cat "$part"; rm -f "$part"; done; } | tar -xJf - -C "$ROOT"
python3 - "$ROOT" "$TOOLS" <<'PY'
from pathlib import Path
import shutil,sys
src=Path(sys.argv[1]);dst=Path(sys.argv[2]);dst.mkdir(parents=True,exist_ok=False)
for relative in ('NetCoreRuntime','DotNetSdkRoslyn','UnityReferenceAssemblies/unity-4.8-api','Managed/UnityEngine','Resources/Licensing/Client'):
    source=src/'Editor/Data'/relative;target=dst/'Editor/Data'/relative
    shutil.copytree(source,target,symlinks=False)
for relative in ('Managed/UnityEditor.Graphs.dll','Managed/UnityEngine.dll'):
    shutil.copy2(src/'Editor/Data'/relative,dst/'Editor/Data'/relative)
PY
python3 scripts/actions/check_bulk389_helper_tools.py create "$TOOLS"
