set -euo pipefail
OUT="$RUNNER_TEMP/stage9-startup-r2"
if [ -f "$OUT/project-path.txt" ]; then
  python3 scripts/actions/capture_startup_r28_export_forensics.py --out "$OUT" --project "$(cat "$OUT/project-path.txt")"
fi
