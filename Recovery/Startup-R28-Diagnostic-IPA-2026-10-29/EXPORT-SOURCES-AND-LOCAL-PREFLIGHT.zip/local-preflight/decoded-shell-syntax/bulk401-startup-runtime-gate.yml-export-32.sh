set -uo pipefail
OUT="$RUNNER_TEMP/stage9-startup-r2"
E="$OUT/evidence"
if [ -f "$OUT/seat-acquired.flag" ] && [ -f "$OUT/unity-path.txt" ]; then
  UNITY="$(cat "$OUT/unity-path.txt")"
  CLIENT="$(dirname "$UNITY")/Data/Resources/Licensing/Client/Unity.Licensing.Client"
  set +e
  "$CLIENT" --deactivate-all --username "$UNITY_EMAIL" --password "$UNITY_PASSWORD" > "$E/license-return.log" 2>&1
  RC=$?
  set -e
  echo "$RC" > "$E/license-return-exit.txt"
  [ "$RC" -eq 0 ] || exit 71
fi
