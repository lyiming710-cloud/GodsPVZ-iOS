set -euo pipefail
python3 scripts/actions/audit_startup_r28_real_export.py --xcode-dir "$RUNNER_TEMP/build/xcode" --output-dir "$RUNNER_TEMP/actual-export-compiler"
