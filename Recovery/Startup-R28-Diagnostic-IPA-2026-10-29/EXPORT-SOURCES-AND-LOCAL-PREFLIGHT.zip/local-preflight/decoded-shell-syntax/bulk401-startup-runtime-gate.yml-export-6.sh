set -euo pipefail
python3 scripts/actions/bind_startup_r28_test_ipa.py --output "$RUNNER_TEMP/stage9-startup-r2" --source "$GITHUB_SHA"
