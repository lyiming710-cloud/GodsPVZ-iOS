"""Compile the real instrumented build helper and observer against exact APIs."""
from pathlib import Path
import sys,hashlib,json,subprocess
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];R=Q.parents[1]/'repo-native113'
sys.path.insert(0,str(R/'scripts/actions'))
from instrument_startup_r28_build_helper import instrument
api=ROOT/'audit/local-preflight/exact-editor-tools/resolver';aot=api.parent/'aot-resolver'
refs=[aot/n for n in ['mscorlib.dll','System.dll','System.Core.dll','netstandard.dll']]+[api/n for n in ['UnityEditor.CoreModule.dll','UnityEngine.CoreModule.dll','UnityEngine.JSONSerializeModule.dll']]
known={Path(r['path']).name:r['sha256']for r in json.loads((W/'asset-audit-40081048209/HELPER-COMPILATION.json').read_bytes())['references']}
for p in refs[4:]:assert hashlib.sha256(p.read_bytes()).hexdigest()==known[p.name]
original=R/'Recovery/Startup-R3-2026-10-24/ios-support/Assets/Editor/GodsPVZIOSBuild.cs';derived=Q/'GodsPVZIOSBuild-R28.cs'
derived.write_bytes(instrument(original.read_bytes()));sources=[derived,R/'scripts/actions/GodsPVZBuildReportCaptureR28.cs']
cmd=[str(ROOT/'.local/dotnet10/dotnet.exe'),str(ROOT/'.local/dotnet10/sdk/10.0.402/Roslyn/bincore/csc.dll'),'/noconfig','/nostdlib','/target:library','/langversion:9.0','/utf8output','/preferreduilang:en-US','/define:UNITY_EDITOR','/out:'+str(Q/'EXPORT-HELPERS.dll')]+['/r:'+str(p)for p in refs]+[str(p)for p in sources]
proc=subprocess.run(cmd,capture_output=True);(Q/'EXPORT-HELPERS.log').write_bytes(proc.stdout+proc.stderr)
result=dict(scope='EXACT_EDITOR_EXPORT_HELPER_API_COMPILATION_ONLY_NOT_UNITY_OR_APPLE',exit_code=proc.returncode,sources=[dict(file=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in sources],references=[dict(file=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in refs],unity_started=False,game_changed=False)
(Q/'EXPORT-HELPERS.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print((proc.stdout+proc.stderr).decode('utf-8',errors='replace'));raise SystemExit(proc.returncode)
