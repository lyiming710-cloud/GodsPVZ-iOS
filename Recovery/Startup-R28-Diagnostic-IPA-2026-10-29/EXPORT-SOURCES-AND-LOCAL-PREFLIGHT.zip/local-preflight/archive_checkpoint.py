"""Archive the test-build purpose, exact inputs and local preflight limits."""
from pathlib import Path
import hashlib,json,sys
Q=Path(__file__).resolve().parent;W=Q.parent;R=Q.parents[1]/'repo-native113'
sys.path[:0]=[str(W),str(R/'scripts/actions')]
from archive_support import js,pack,manifest
from admit_startup_r28_test_ipa import validate
C=R/'Recovery/Startup-R28-Diagnostic-IPA-2026-10-29';assert not C.exists();C.mkdir()
(C/'.gitattributes').write_bytes(b'* -text\n');admission=validate();js(C/'BUILD-ADMISSION.json',admission)
for name in ['PIPELINE-CONTROLS.json','WORKFLOW-CHECKS.json','EXPORT-HELPERS.json']:(C/name).write_bytes((Q/name).read_bytes())
source_names=['GodsPVZBuildReportCaptureR28.cs','admit_startup_r28_test_ipa.py','bind_startup_r28_test_ipa.py','audit_startup_r28_real_export.py','capture_startup_r28_export_forensics.py','instrument_startup_r28_build_helper.py','package_startup_r28_ipa.py','preflight_startup_r28_ipa_editor.py','startup_r28_export_binding.py']
items=[('scripts/actions/'+n,(R/'scripts/actions'/n).read_bytes())for n in source_names]
for n in ['bulk401-startup-runtime-gate.yml','startup-r28-diagnostic-ipa.yml','startup-r28-ipa-editor-preflight.yml']:items.append(('.github/workflows/'+n,(R/'.github/workflows'/n).read_bytes()))
for p in sorted(Q.rglob('*')):
 if p.is_file()and p.suffix not in ['.dll']and'__pycache__'not in p.parts:
  items.append(('local-preflight/'+p.relative_to(Q).as_posix(),p.read_bytes()))
pack(C/'EXPORT-SOURCES-AND-LOCAL-PREFLIGHT.zip',items)
js(C/'REPOSITORY-SOURCE-BINDINGS.json',[dict(path=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())for n,b in items if not n.startswith('local-preflight/')])
js(C/'PROGRESS.json',dict(status='READY_FOR_FIXED_UNSIGNED_DIAGNOSTIC_BUILD_NOT_YET_DISPATCHED',candidate_sha256=admission['candidate_sha256'],sdk_sha256=admission['sdk_sha256'],new_game_changes=0,
 whole_game_accepted=False,whole_level_completed=False,ipad_accepted=False,qualified_methods_added=0,unity_export_run=None,actual_apple_compilation=None,ipa=None))
(C/'README.md').write_bytes('''# R28 unsigned diagnostic IPA

This checkpoint prepares a fresh platform build of the exact R28 game
`9081408a2226a79e23991355108540a0260a3966a500cecf4524f3cba9dfb364`
and actual-Editor SDK
`51f72bcd146c5571f642f3c4149f0545eb704fd325d83eb0f7c4ca2deec14c2b`.
No additional game method or field is changed here. This is a test IPA build,
not production promotion or game acceptance.

The preceding actual Unity run 40794439817 is preserved as FAILURE: one real
plant was selected and planted through OS input, the game logged no runtime
errors, and an independently reconstructed raw profiler tree observes
PlantAnimationEvent -> Plant.Shooting -> ST_Peasniper -> Zombie.TakeDamage.
The original complex level ended in loss after 48.15 game seconds. Only one
attack stack was retained and 162 profiler frames were lost; target argument
identity, numerical damage equivalence, full-level paths and iPad performance
are unaccepted. The failed result is not rewritten as PASS. Its complete raw
evidence remains under Startup-R28-Attack115-2026-10-29.

Actual Linux conversion/compiler run 40794444003 passed, with all 755 C++ and
274 C sources and raw logs independently reread. It does not qualify Apple
compilation or an IPA. Admission rechecks all 1029 raw compiler logs and the
original Unity delivery and raw attack tree before platform setup.

The diagnostic export reuses the authenticated R3 resources, exact Unity
2022.3.44f1c1 and source restoration used by the real Editor run. The original
Unity build result/error decisions remain intact. The build helper gains one
report observer and an API rename from symlinkLibraries to symlinkSources.
The actual report must be Succeeded with zero errors and no logged errors.
The complete exported tree is hash-bound to the game, SDK and workflow head;
all generated C/C++ is checked with Apple ARM64 flags before Xcode linking.
The unsigned IPA is checked for physical-iOS arm64 executable/framework roles,
absence of signing artifacts, exact metadata and every exported Data file.

Local preflight: exact Editor API compilation of both export helpers passed;
25 transport/admission/format controls passed; actionlint and 76 decoded Bash
blocks passed syntax checks. Format controls simulate ditto on Windows and
use explicitly synthetic Mach-O fixtures. They are not an Apple build, real
Unity export, runnable app or behavioral test. Bad metadata, missing/changed
resources, simulator/cpu mismatches, altered source/header/library inventories,
forged qualification and hidden original failures are rejected.

Workflow: `.github/workflows/startup-r28-diagnostic-ipa.yml`, also installed at
the already-registered `bulk401-startup-runtime-gate.yml` for dispatch on this
isolated branch. The original R28 gameplay workflow remains separately saved.
No new IPA exists until the actual workflow produces and validates it.
'''.encode('utf-8'))
manifest(C);print(json.dumps(dict(checkpoint=str(C),candidate_sha256=admission['candidate_sha256'],local_controls=25,game_changes=0,ipa=None)))
