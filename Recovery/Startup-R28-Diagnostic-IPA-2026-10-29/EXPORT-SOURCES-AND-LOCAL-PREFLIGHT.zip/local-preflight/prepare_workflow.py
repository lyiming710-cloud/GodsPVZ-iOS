"""Prepare a fixed diagnostic export; preserve the failed gameplay workflow."""
from pathlib import Path
import sys,json,copy
Q=Path(__file__).resolve().parent;W=Q.parent;R=Q.parents[1]/'repo-native113'
sys.path.insert(0,str(W/'tool-deps'));import yaml
text=(R/'.github/workflows/startup-r28-real-gameplay-diagnostic.yml').read_text(encoding='utf-8')
flow=yaml.safe_load(text)
assert True in flow and 'on'not in flow
flow.pop(True);flow['on']={'workflow_dispatch':None}
flow['name']='Startup R28 unsigned diagnostic IPA - exact reviewed game and SDK'
jobs=flow['jobs'];jobs.pop('asset_case_preflight')
for name in ['editor_helper_preflight','apple_preflight','export','build_ipa']:jobs[name].pop('if',None)
jobs['editor_helper_preflight']['uses']='./.github/workflows/startup-r28-ipa-editor-preflight.yml'
steps=jobs['conversion_binding']['steps']
steps=[s for s in steps if s.get('name')not in [
 'Reject interaction diagnostics combined with asset-only or IPA builds',
 'Keep R28 restricted to actual UI diagnosis until its new Editor result is reviewed',
 'Validate current R20 byte and evidence binding before large setup']]
steps.insert(1,dict(name='Admit exact R28 only for a diagnostic unsigned IPA and retain real level loss',run='python3 scripts/actions/admit_startup_r28_test_ipa.py'))
jobs['conversion_binding']['steps']=steps
steps=[]
for step in jobs['export']['steps']:
 condition=str(step.get('if',''))
 if 'inputs.gameplay_audit'in condition or 'inputs.interaction_audit'in condition:continue
 if '!inputs.audit_only'in condition:
  if 'always()'in condition:step['if']='always()'
  else:step.pop('if')
 steps.append(step)
jobs['export']['steps']=steps
replacements={
 'scripts/actions/bind_startup_r28_diagnostic.py':'scripts/actions/bind_startup_r28_test_ipa.py',
 'scripts/actions/instrument_startup_r20_build_helper.py':'scripts/actions/instrument_startup_r28_build_helper.py',
 'GodsPVZBuildReportCapture.ExportIOS':'GodsPVZBuildReportCaptureR28.ExportIOS',
 'scripts/actions/startup_r20_export_binding.py':'scripts/actions/startup_r28_export_binding.py',
 'startup-r20-export-binding.json':'startup-r28-export-binding.json',
 'scripts/actions/audit_startup_r20_real_export.py':'scripts/actions/audit_startup_r28_real_export.py',
 'scripts/actions/package_startup_r20_ipa.py':'scripts/actions/package_startup_r28_ipa.py',
 'scripts/actions/capture_startup_r20_export_forensics.py':'scripts/actions/capture_startup_r28_export_forensics.py',
 'GodsPVZ-Startup-R20-unsigned-Xcode':'GodsPVZ-Startup-R28-unsigned-test-Xcode',
 'STARTUP-R20-EDITOR-DIAGNOSTIC-EVIDENCE':'STARTUP-R28-EXPORT-EVIDENCE',
 'STARTUP-R20-SHADERS-COMPILED-AND-RENDERED':'STARTUP-R28-EXPORT-SHADERS-COMPILED-AND-RENDERED',
 'Startup-R20-UNQUALIFIED-EXPORT-FORENSICS':'Startup-R28-UNQUALIFIED-EXPORT-FORENSICS',
 'Startup-R20-APPLE-BUILD-EVIDENCE':'Startup-R28-APPLE-BUILD-EVIDENCE',
 'GodsPVZ_1.0.2_startup_r20_unsigned_ipa':'GodsPVZ_1.0.2_startup_r28_unsigned_test_ipa',
 'Export unsigned iOS Xcode project with exact R20 candidate':'Export exact R28 unsigned diagnostic Xcode project',
 'fixed R20 input':'fixed R28 diagnostic input',
 'r20_full_game_qualification=NOT_YET_PERFORMED':'r28_whole_game_acceptance=NOT_PROVEN_DIAGNOSTIC_ONLY',
 'r20_portable_il2cpp_conversion=PASS':'r28_fresh_linux_compiler=PASS_COMPLEX_LEVEL_LOSS_RETAINED',
 'inputs.assets_only':'false','inputs.audit_only':'false','inputs.interaction_audit':'false','inputs.gameplay_audit':'false'}
def replace(obj):
 if isinstance(obj,str):
  for old,new in replacements.items():obj=obj.replace(old,new)
  return obj
 if isinstance(obj,list):return[replace(x)for x in obj]
 if isinstance(obj,dict):return{k:replace(v)for k,v in obj.items()}
 return obj
flow=replace(flow)
for step in flow['jobs']['export']['steps']:
 if step.get('id')=='xcode_audit':
  old='python3 scripts/actions/startup_r28_export_binding.py --xcode-dir "$X" --plugin "$PROJECT/Assets/Plugins/GodsPVZRuntime1.dll"'
  new='''mapfile -t SDKS < <(find "$PROJECT/Assets" -type f -name Unity.VisualScripting.Core.dll)
[ "${#SDKS[@]}" = 1 ]
python3 scripts/actions/startup_r28_export_binding.py --xcode-dir "$X" --plugin "$PROJECT/Assets/Plugins/GodsPVZRuntime1.dll" --sdk "${SDKS[0]}" --build-report "$E/actual-unity-build-report.json"'''
  assert step['run'].count(old)==1;step['run']=step['run'].replace(old,new)
class Dumper(yaml.SafeDumper):pass
def represent(dumper,data):return dumper.represent_scalar('tag:yaml.org,2002:str',data,style='|'if'\n'in data else None)
Dumper.add_representer(str,represent)
text=yaml.dump(flow,Dumper=Dumper,sort_keys=False,allow_unicode=False,width=160)
assert 'inputs.'not in text and 'admit_startup_r28_test_ipa.py'in text
assert 'Try real complex Adventure 19'not in text and 'GodsPVZBuildReportCaptureR28.ExportIOS'in text
for name in ['startup-r28-diagnostic-ipa.yml','bulk401-startup-runtime-gate.yml']:(R/'.github/workflows'/name).write_bytes(text.encode('utf-8'))

helper=(R/'.github/workflows/startup-r28-editor-preflight.yml').read_text(encoding='utf-8')
old='python3 scripts/actions/preflight_startup_r28_capture_editor.py --editor "$TOOLS/Editor/Unity" --prior "$RUNNER_TEMP/helper-compilation"'
assert helper.count(old)==1
helper=helper.replace('name: Startup R28 exact Editor helper compilation only','name: Startup R28 exact Editor diagnostic export helper compilation only')
helper=helper.replace(old,'python3 scripts/actions/preflight_startup_r28_ipa_editor.py --editor "$TOOLS/Editor/Unity" --prior "$RUNNER_TEMP/helper-compilation"')
(R/'.github/workflows/startup-r28-ipa-editor-preflight.yml').write_bytes(helper.encode('utf-8'))
print(json.dumps(dict(workflow='bulk401-startup-runtime-gate.yml',jobs=list(flow['jobs']),no_game_image_change=True,only_diagnostic_ipa=True)))
