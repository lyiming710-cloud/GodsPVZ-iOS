"""Check decoded workflow inputs and Bash syntax without executing commands."""
from pathlib import Path
import ast,json,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;R=Q.parents[1]/'repo-native113'
sys.path.insert(0,str(W/'tool-deps'));import yaml
import re
flows=['bulk401-startup-runtime-gate.yml','startup-r28-diagnostic-ipa.yml','startup-r28-ipa-editor-preflight.yml']
actionlint=W/'zombie-serialization-2026-10-27/authoring-tools/actionlint.exe'
p=subprocess.run([str(actionlint),'-shellcheck=','-oneline']+[str(R/'.github/workflows'/n)for n in flows],capture_output=True)
(Q/'ACTIONLINT.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,p.stdout+p.stderr
bash=Path('C:/Users/86136/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/usr/bin/sh.exe');assert bash.is_file()
version=subprocess.check_output([str(bash),'--version']).decode(errors='replace').splitlines()[0];assert 'GNU bash'in version,version
negative=subprocess.run([str(bash),'-n'],input=b'if then\n',capture_output=True);assert negative.returncode!=0
out=Q/'decoded-shell-syntax';out.mkdir(exist_ok=True);rows=[];allrefs=set()
for name in flows:
 flow=yaml.safe_load((R/'.github/workflows'/name).read_text(encoding='utf-8'))
 if 'diagnostic-ipa'in name or name=='bulk401-startup-runtime-gate.yml':
  assert (flow.get(True)or flow.get('on'))=={'workflow_dispatch':None}
 for jobname,job in flow['jobs'].items():
  if 'uses'in job:
   assert(R/job['uses'].removeprefix('./')).is_file()
  for index,step in enumerate(job.get('steps',[])):
   run=step.get('run','');assert 'inputs.'not in run or 'ipa-editor'in name
   for ref in re.findall(r'(?:scripts/actions|Recovery)/[A-Za-z0-9_./-]+\.(?:py|cs|zip|json)',run):
    if(R/ref).is_file():allrefs.add(ref);continue
    assert '"$PROJECT/'+ref+'"'in run and '"$GITHUB_WORKSPACE/Recovery/'in run,ref
   if not run:continue
   file=out/(name+'-'+jobname+'-'+str(index)+'.sh');file.write_bytes(run.replace('\r\n','\n').encode('utf-8'))
   parsed=subprocess.run([str(bash),'-n',file.as_posix()],capture_output=True)
   assert parsed.returncode==0,(name,index,parsed.stderr.decode(errors='replace'))
   rows.append(dict(workflow=name,job=jobname,index=index,bash_syntax_exit=parsed.returncode))
for name in ['admit_startup_r28_test_ipa.py','bind_startup_r28_test_ipa.py','instrument_startup_r28_build_helper.py','startup_r28_export_binding.py','preflight_startup_r28_ipa_editor.py','package_startup_r28_ipa.py','audit_startup_r28_real_export.py','capture_startup_r28_export_forensics.py']:
 ast.parse((R/'scripts/actions'/name).read_text(encoding='utf-8'),filename=name)
result=dict(scope='DECODED_BASH_AND_PYTHON_SYNTAX_ACTIONLINT_AND_LITERAL_INPUTS_ONLY',workflows=len(flows),shell_blocks_checked=len(rows),repository_inputs_checked=len(allrefs),bash_parser=version,broken_syntax_control_rejected=True,rows=rows,unity_started=False)
(Q/'WORKFLOW-CHECKS.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in result.items()if k!='rows'}))
