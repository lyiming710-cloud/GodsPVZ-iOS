"""Reuse reviewed platform helpers with exact R28 bindings and explicit limits."""
from pathlib import Path
Q=Path(__file__).resolve().parent;W=Q.parent;R=Q.parents[1]/'repo-native113';S=R/'scripts/actions'
s=(S/'GodsPVZBuildReportCapture.cs').read_text(encoding='utf-8').replace('GodsPVZBuildReportCapture','GodsPVZBuildReportCaptureR28')
assert s.count('public bool original_build_helper_unchanged = true;')==1
s=s.replace('public bool original_build_helper_unchanged = true;',
 'public bool original_build_helper_unchanged = false;\n        public bool original_error_and_result_decisions_preserved = true;\n        public bool build_helper_api_alias_replaced = true;')
(S/'GodsPVZBuildReportCaptureR28.cs').write_bytes(s.encode('utf-8'))
s=(S/'capture_startup_r20_export_forensics.py').read_text(encoding='utf-8')
old='d887b370c95c2966dc40d80648d85c286bb42d85004c32d095f64f004e095b37';new='9081408a2226a79e23991355108540a0260a3966a500cecf4524f3cba9dfb364'
assert s.count(old)==1
(S/'capture_startup_r28_export_forensics.py').write_bytes(s.replace(old,new).encode('utf-8'))
s=(S/'audit_startup_r20_real_export.py').read_text(encoding='utf-8');assert s.count('from startup_r20_export_binding import validate')==1
(S/'audit_startup_r28_real_export.py').write_bytes(s.replace('from startup_r20_export_binding import validate','from startup_r28_export_binding import validate').encode('utf-8'))
s=(S/'package_startup_r20_ipa.py').read_text(encoding='utf-8').replace('from startup_r20_export_binding import','from startup_r28_export_binding import').replace('GodsPVZ_1.0.2_startup_r20_unsigned.ipa','GodsPVZ_1.0.2_startup_r28_unsigned_test.ipa')
marker=" if exported!=packaged:raise ValueError('Packaged metadata differs from exact Unity export')\n"
assert s.count(marker)==1
s=s.replace(marker,marker+''' data_prefix=metadata[0][:-len('Managed/Metadata/global-metadata.dat')]
 data_files=[]
 for source in sorted((xcode/'Data').rglob('*')):
  if not source.is_file():continue
  relative=source.relative_to(xcode/'Data').as_posix();target=data_prefix+relative;expected=source.read_bytes()
  if target not in names or z.read(target)!=expected:raise ValueError('Packaged export data differs: '+relative)
  data_files.append(dict(path=relative,bytes=len(expected),sha256=sha(expected)))
 if not data_files:raise ValueError('No exported game data was packaged')
''')
needle="(out/'IPA-VALIDATION.json').write_text"
assert s.count(needle)==1
s=s.replace(needle,"report.update(build_purpose='UNSIGNED_DIAGNOSTIC_TEST_ONLY',whole_game_accepted=False,whole_level_completed=False,prior_complex_level_status='ACTUAL_LOSS_RETAINED',sdk_sha256=binding['sdk_sha256'],export_data_files_verified=len(data_files),export_data_inventory=data_files)\n"+needle)
(S/'package_startup_r28_ipa.py').write_bytes(s.encode('utf-8'))
print('Prepared R28 observers, forensic capture, Apple all-source census and diagnostic IPA packager')
