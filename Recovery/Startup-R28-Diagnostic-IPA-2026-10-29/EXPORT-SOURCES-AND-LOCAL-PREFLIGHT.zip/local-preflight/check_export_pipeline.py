"""Physical binding/admission controls and synthetic format checks.

The ditto operation is simulated on Windows. Nothing here is an Apple build,
real Unity export, runnable binary or a game-behavior test.
"""
from pathlib import Path
import contextlib,copy,hashlib,io,json,plistlib,runpy,shutil,struct,sys,tempfile,zipfile
from unittest.mock import patch
Q=Path(__file__).resolve().parent;W=Q.parent;R=Q.parents[1]/'repo-native113'
sys.path[:0]=[str(R/'scripts/actions'),str(W)]
import startup_r28_export_binding as binding
import bind_startup_r28_test_ipa as build_binding
import admit_startup_r28_test_ipa as admission
from archive_support import js,manifest

checks=[]
def rejected(name,fn):
 try:fn()
 except (ValueError,AssertionError,KeyError):checks.append(dict(name=name,rejected=True));return
 raise AssertionError('Incorrect admission: '+name)

with zipfile.ZipFile(admission.game.ROOT/'STARTUP-R28-ATTACK115-CANDIDATE.zip')as z:game=z.read('STARTUP-R28-ATTACK115.dll')
with zipfile.ZipFile(R/'Recovery/Startup-R26-SDK-Helpers-2026-10-28/RECOVERED-VISUALSCRIPTING-CORE.zip')as z:sdk=z.read('Unity.VisualScripting.Core.dll')
assert hashlib.sha256(game).hexdigest()==binding.CANDIDATE and hashlib.sha256(sdk).hexdigest()==admission.SDK
with tempfile.TemporaryDirectory(prefix='binding-controls-',dir=Q)as temp:
 base=Path(temp).resolve();assert base.is_relative_to(Q.resolve())
 bound=base/'complete-transport';(bound/'candidate').mkdir(parents=True);(bound/'evidence').mkdir()
 for p in(W/'r22-real-gameplay-2026-10-27/parent-package-fixture').iterdir():
  shutil.copyfile(p,bound/('candidate'if p.name=='Assembly-CSharp-bulk401.dll'else'evidence')/p.name)
 p=bound/'evidence/PROVENANCE.json';j=json.loads(p.read_bytes());j['source_commit']='SYNTHETIC-TRANSPORT-NOT-A-WORKFLOW';js(p,j)
 transported=build_binding.bind(bound,j['source_commit'])
 assert transported['diagnostic_ipa_build_allowed']and not transported['ipa_promotion_allowed']and not transported['production_promotion_allowed']
 assert hashlib.sha256((bound/'candidate/Assembly-CSharp-bulk401.dll').read_bytes()).hexdigest()==binding.CANDIDATE
 assert hashlib.sha256((bound/'recovered-sdk/Unity.VisualScripting.Core.dll').read_bytes()).hexdigest()==admission.SDK
 assert(bound/'evidence/PARENT-R28-DIAGNOSTIC-TRANSPORT-PROVENANCE.json').is_file()
 checks.append(dict(name='complete-authenticated-game-sdk-transport-test-build-only',actual_candidate_and_sdk_hashes_checked=True,unity_executed=False))
 plugin=base/'game.dll';plugin.write_bytes(game);core=base/'sdk.dll';core.write_bytes(sdk)
 report=dict(build_report_found=True,result='Succeeded',total_errors=0,exception=None,errors_ignored=False,
             original_error_and_result_decisions_preserved=True,build_helper_api_alias_replaced=True,logs=[],steps=[])
 report_path=base/'SYNTHETIC-REPORT-NOT-A-UNITY-RUN.json';js(report_path,report)
 x=base/'xcode'
 for name,data in [
  ('Data/Managed/Metadata/global-metadata.dat',b'synthetic metadata, not real IL2CPP'),
  ('Data/boot.config',b'synthetic boot'),('Data/Resources/fixture.resS',b'synthetic game asset'),
  ('Unity-iPhone.xcodeproj/project.pbxproj',b'synthetic project, not a real Xcode project'),
  ('Il2CppOutputProject/Source/il2cppOutput/GodsPVZRuntime1.cpp',b'// synthetic source\n'),
  ('Il2CppOutputProject/Source/il2cppOutput/fixture.h',b'// synthetic header\n'),('Libraries/fixture.a',b'not a native library')]:
  p=x/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 binding.create(x,plugin,core,report_path,'SYNTHETIC-NOT-A-WORKFLOW')
 binding.validate(x,'SYNTHETIC-NOT-A-WORKFLOW');checks.append(dict(name='complete-fixture-file-binding',accepted_within_fixture_scope=True))
 for label,relative in [('changed-generated-header','Il2CppOutputProject/Source/il2cppOutput/fixture.h'),
                        ('changed-game-data','Data/Resources/fixture.resS'),('changed-native-library','Libraries/fixture.a')]:
  target=base/label;shutil.copytree(x,target);p=target/relative;p.write_bytes(p.read_bytes()+b' changed')
  rejected(label,lambda target=target:binding.validate(target,'SYNTHETIC-NOT-A-WORKFLOW'))
 target=base/'added-source';shutil.copytree(x,target);(target/'injected.cpp').write_text('// added')
 rejected('added-export-source',lambda:binding.validate(target,'SYNTHETIC-NOT-A-WORKFLOW'))
 rejected('wrong-export-workflow',lambda:binding.validate(x,'WRONG'))
 for label,mutate in [('duplicate-inventory-row',lambda j:j['files'].append(j['files'][0])),
                       ('invented-game-qualification',lambda j:j.update(whole_game_accepted=True))]:
  target=base/label;shutil.copytree(x,target);p=target/binding.RECEIPT;j=json.loads(p.read_bytes());mutate(j);js(p,j)
  rejected(label,lambda target=target:binding.validate(target,'SYNTHETIC-NOT-A-WORKFLOW'))
 rejected('replace-existing-receipt',lambda:binding.create(x,plugin,core,report_path,'SYNTHETIC-NOT-A-WORKFLOW'))
 for label,mutate in [('unity-reported-failure',lambda j:j.update(result='Failed',total_errors=1)),
                       ('unity-logged-error',lambda j:j.update(logs=[dict(type='Error',condition='error')])),
                       ('missing-report-observer-identity',lambda j:j.update(original_error_and_result_decisions_preserved=False))]:
  j=copy.deepcopy(report);mutate(j);rejected(label,lambda j=j:binding.report_valid(j))
 badcore=base/'wrong-sdk.dll';badcore.write_bytes(b'wrong')
 rejected('wrong-sdk-image',lambda:binding.create(base/'unused',plugin,badcore,report_path,'SYNTHETIC-NOT-A-WORKFLOW'))

 def mach(filetype,cpu=0x100000c,platform=2):
  return struct.pack('<8I',0xfeedfacf,cpu,0,filetype,1,24,0,0)+struct.pack('<6I',0x32,24,platform,12<<16,18<<16,0)
 app=base/'fixture.app';(app/'Frameworks/UnityFramework.framework').mkdir(parents=True)
 (app/'GodsPVZ').write_bytes(mach(2));(app/'Frameworks/UnityFramework.framework/UnityFramework').write_bytes(mach(6))
 (app/'Info.plist').write_bytes(plistlib.dumps(dict(CFBundleIdentifier='com.tipsGodsStudio.godsPVZ',CFBundleExecutable='GodsPVZ',MinimumOSVersion='12.0')))
 shutil.copytree(x/'Data',app/'Data')
 def package(label,mutation=None):
  out=base/('package-'+label)
  def fake_ditto(argv,**kwargs):
   assert argv[0]=='ditto'
   if len(argv)==3:shutil.copytree(argv[1],argv[2])
   else:
    assert argv[1:5]==['-c','-k','--keepParent',str(out/'Payload')]
    payload=out/'Payload'
    if mutation:mutation(payload/'GodsPVZ.app')
    with zipfile.ZipFile(argv[-1],'w',zipfile.ZIP_DEFLATED)as z:
     for p in payload.rglob('*'):
      if p.is_file():z.write(p,p.relative_to(out).as_posix())
  args=['package_startup_r28_ipa.py','--app',str(app),'--xcode-dir',str(x),'--output-dir',str(out),'--export-workflow-head','SYNTHETIC-NOT-A-WORKFLOW']
  with patch.object(sys,'argv',args),patch('subprocess.run',fake_ditto),contextlib.redirect_stdout(io.StringIO()):
   runpy.run_path(str(R/'scripts/actions/package_startup_r28_ipa.py'),run_name='__main__')
  return json.loads((out/'IPA-VALIDATION.json').read_bytes())
 p=package('valid-fixture');assert p['export_data_files_verified']==3 and p['whole_game_accepted']is False
 checks.append(dict(name='synthetic-format-and-all-export-data-binding',accepted_within_fixture_scope=True,apple_ditto_executed=False))
 rejected('ipa-resource-changed',lambda:package('bad-resource',lambda app:(app/'Data/Resources/fixture.resS').write_bytes(b'wrong')))
 rejected('ipa-resource-missing',lambda:package('missing-resource',lambda app:(app/'Data/Resources/fixture.resS').unlink()))
 rejected('ipa-metadata-changed',lambda:package('bad-metadata',lambda app:(app/'Data/Managed/Metadata/global-metadata.dat').write_bytes(b'wrong')))
 rejected('ipa-simulator-platform',lambda:package('simulator',lambda app:(app/'GodsPVZ').write_bytes(mach(2,platform=7))))
 rejected('ipa-wrong-cpu',lambda:package('cpu',lambda app:(app/'GodsPVZ').write_bytes(mach(2,cpu=0x1000007))))

 for label,file,mutate in [
  ('do-not-rewrite-actual-loss-as-pass','ACTUAL-UNITY-40794439817.json',lambda j:j.update(gameplay_pass=True)),
  ('runtime-error-is-not-admitted','ACTUAL-UNITY-40794439817.json',lambda j:j.update(raw_runtime_error_occurrences=1)),
  ('do-not-invent-qualified-methods','ACTUAL-UNITY-40794439817.json',lambda j:j.update(qualified_methods_added=4)),
  ('do-not-erase-raw-attack-stack','ACTUAL-UNITY-40794439817.json',lambda j:j['independent_raw_attack_readback'].update(rows=[])),
  ('do-not-inherit-wrong-sdk-compiler','ACTUAL-COMPILER-40794444003.json',lambda j:j.update(runtime_sdk_sha256='0'*64))]:
  target=base/label;shutil.copytree(admission.game.ROOT,target);p=target/file;j=json.loads(p.read_bytes());mutate(j);js(p,j);manifest(target)
  rejected(label,lambda target=target:admission.validate(target))

source_names=['admit_startup_r28_test_ipa.py','bind_startup_r28_test_ipa.py','startup_r28_export_binding.py','instrument_startup_r28_build_helper.py','preflight_startup_r28_ipa_editor.py','package_startup_r28_ipa.py']
result=dict(scope='LOCAL_BINDING_ADMISSION_AND_SYNTHETIC_FORMAT_CONTROLS_NOT_UNITY_OR_APPLE',checks=len(checks),all_expected_results_observed=True,
 rows=checks,sources=[dict(file=n,sha256=hashlib.sha256((R/'scripts/actions'/n).read_bytes()).hexdigest())for n in source_names],unity_started=False,apple_build_performed=False,apple_ditto_executed=False,game_image_changed=False)
js(Q/'PIPELINE-CONTROLS.json',result);print(json.dumps({k:v for k,v in result.items()if k!='rows'}))
