"""Preserve the actual platform run without calling setup Apple compilation."""
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;R=Q.parents[1]/'repo-native113'
sys.path.insert(0,str(W));from archive_support import js,pack,manifest
C=R/'Recovery/Startup-R28-Diagnostic-IPA-2026-10-29'
run=json.loads(subprocess.check_output(['C:/Program Files/GitHub CLI/gh.exe','run','view','40800918671','-R','lyiming710-cloud/GodsPVZ-iOS','--json','status,conclusion,headSha,url,jobs'],cwd=R))
assert run['headSha']=='7625352d818c5401324cccef76e7c596e0d8de13'
assert run['status']in ['queued','in_progress']and not run['conclusion']
jobs={x['name']:x for x in run['jobs']}
assert all(jobs[n]['conclusion']=='success'for n in ['conversion_binding','apple_preflight','editor_helper_preflight / helper_compilation'])
assert'build_ipa'not in jobs or jobs['build_ipa']['status']!='completed'
js(C/'DISPATCH-40800918671.json',dict(captured_at_utc=datetime.now(timezone.utc).isoformat(),scope='ACTUAL_PLATFORM_RUN_STATUS_SETUP_ONLY_NOT_APPLE_COMPILE_PASS',run=run))
progress=json.loads((C/'PROGRESS.json').read_bytes())
progress.update(status='ACTUAL_TEST_IPA_BUILD_IN_PROGRESS_PREFLIGHTS_PASS',unity_export_run=40800918671,build_source_commit=run['headSha'],actual_apple_compilation='NOT_YET_OBSERVED',ipa=None)
js(C/'PROGRESS.json',progress)
with(C/'README.md').open('a',encoding='utf-8')as f:f.write('\nActual test-IPA workflow 40800918671 has been dispatched at source 7625352d818c5401324cccef76e7c596e0d8de13. Exact input admission, remote Editor helper compilation and Xcode/iOS SDK setup preflights passed. The export job is running. These setup results are not Apple source compilation/linking or an IPA. Source and failed/partial gameplay evidence remain unchanged; see DISPATCH-40800918671.json for this observed status snapshot.\n')
pack(C/'DISPATCH-READER-SOURCE.zip',[('record_dispatch.py',Path(__file__).read_bytes())])
manifest(C);print(json.dumps(dict(run_id=40800918671,source=run['headSha'],status=run['status'],ipa=None)))
