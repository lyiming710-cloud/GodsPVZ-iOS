from pathlib import Path
import json,subprocess,hashlib,collections
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];O=Q/'exact-jit-results';O.mkdir(exist_ok=True)
plan=json.loads((Q/'CONSTRUCTION.json').read_bytes());tokens=[c['token'] for c in plan['changes']]
dot=ROOT/'.local/dotnet10/dotnet.exe';probe=W/'startup-r5/jit-probe/bin/Release/net10.0/Probe.dll';support=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'
rows=[]
for index,token in enumerate(tokens):
    pair=dict(token=token)
    for label,dll in [('parent',W/'startup-r6/candidate1.dll'),('candidate',Q/'candidate1.dll')]:
        name=token+'-'+label;report=O/(name+'.json');p=subprocess.run([str(dot),str(probe),str(dll),str(support),token,str(report)],capture_output=True,timeout=20)
        (O/(name+'.stdout.log')).write_bytes(p.stdout);(O/(name+'.stderr.log')).write_bytes(p.stderr)
        if p.returncode!=0 or not report.exists():r=dict(status='PROCESS_FAILURE',exit_code=p.returncode,error=p.stderr.decode('utf-8','replace')[:600])
        else:
            r=json.loads(report.read_bytes());assert r['input_sha256']==hashlib.sha256(dll.read_bytes()).hexdigest() and not r['method_executed']
        pair[label]=r
    rows.append(pair)
    if len(rows)%20==0:print(json.dumps(dict(completed=len(rows),total=len(tokens))),flush=True)
    (O/'PROGRESS.json').write_bytes((json.dumps(dict(completed=len(rows),total=len(tokens)))+'\n').encode())
counts=collections.Counter((r['parent']['status'],r['candidate']['status']) for r in rows)
report=dict(scope='EXACT_REAL_ASSEMBLY_METHOD_BODY_JIT_VALIDATION_NO_EXECUTION',parent_sha256=plan['parent_sha256'],candidate_sha256=plan['candidate_sha256'],methods=len(rows),
            status_pairs=[dict(parent=k[0],candidate=k[1],count=v) for k,v in counts.items()],all_jit_prepared=all(r['candidate']['status']=='JIT_PREPARED_NO_EXECUTION' for r in rows),
            method_execution=False,semantic_equivalence=False,unity_execution=False,rows=rows)
(O/'RESULT.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in report.items() if k!='rows'},indent=2))
