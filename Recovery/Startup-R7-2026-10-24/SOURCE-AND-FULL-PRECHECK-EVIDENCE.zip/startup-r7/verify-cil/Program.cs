using System.Security.Cryptography;using System.Text.Json;using Mono.Cecil;using Mono.Cecil.Cil;
// Independent actual-Cecil parser. Does not read the constructor or its plan.
public static class Program
{
    static HashSet<Instruction>? Reach(MethodDefinition method)
    {
        if(method.Body.ExceptionHandlers.Count!=0)return null;
        var seen=new HashSet<Instruction>();var pending=new Stack<Instruction>();pending.Push(method.Body.Instructions[0]);
        while(pending.TryPop(out var i))
        {
            if(!seen.Add(i))continue;
            if(i.OpCode.Code==Code.Jmp||i.OpCode.FlowControl is FlowControl.Return or FlowControl.Throw)continue;
            if(i.OpCode.FlowControl==FlowControl.Branch){if(i.Operand is not Instruction target)return null;pending.Push(target);continue;}
            if(i.OpCode.FlowControl==FlowControl.Cond_Branch)
            {
                if(i.Operand is Instruction target)pending.Push(target);
                else if(i.Operand is Instruction[] targets){foreach(var t in targets)pending.Push(t);}
                else return null;
            }
            if(i.Next!=null)pending.Push(i.Next);
        }
        return seen;
    }
    public static void Main(string[] args)
    {
        byte[] before=File.ReadAllBytes(args[0]),after=File.ReadAllBytes(args[1]);
        string sourceSha=Convert.ToHexString(SHA256.HashData(before)).ToLowerInvariant(),candidateSha=Convert.ToHexString(SHA256.HashData(after)).ToLowerInvariant();
        if(sourceSha!="c36092b5326687112adfa8c285bb3cf5e8ad46d3b3de8ebcd84daf598041465d"||candidateSha!="22d6aa537bfb71e40dcfa0fdd8776566278cf8fd9a4d4212a93fb7d49d3a8655")throw new InvalidOperationException("Pinned input mismatch");
        using var a=ModuleDefinition.ReadModule(new MemoryStream(before));using var b=ModuleDefinition.ReadModule(new MemoryStream(after));var rows=new List<object>();
        foreach(var m in a.GetTypes().SelectMany(t=>t.Methods).OrderBy(m=>m.MetadataToken.ToInt32()))
        {
            if(!m.HasBody||m.ReturnType.FullName!="System.Void")continue;var ins=m.Body.Instructions;
            if(ins.Count<2||ins[^1].OpCode.Code!=Code.Pop||ins[^2].OpCode.Code!=Code.Ldstr||ins[^2].Operand is not string message||!message.StartsWith("Warning:"))continue;
            var reach=Reach(m);if(reach==null||reach.Contains(ins[^2])||reach.Contains(ins[^1]))continue;
            var target=(MethodDefinition)b.LookupToken(m.MetadataToken);var newReach=Reach(target)??throw new InvalidOperationException("Added EH or unknown control flow");int tail=ins[^2].Offset;
            if(m.RVA!=target.RVA||m.Body.CodeSize!=target.Body.CodeSize||m.Body.MaxStackSize!=target.Body.MaxStackSize||m.Body.InitLocals!=target.Body.InitLocals||m.Body.LocalVarToken!=target.Body.LocalVarToken)throw new InvalidOperationException("Changed body header");
            if(!m.Body.Variables.Select(v=>v.VariableType.FullName).SequenceEqual(target.Body.Variables.Select(v=>v.VariableType.FullName)))throw new InvalidOperationException("Changed locals");
            int[] oldOffsets=reach.Select(i=>i.Offset).Order().ToArray(),newOffsets=newReach.Select(i=>i.Offset).Order().ToArray();
            if(!oldOffsets.SequenceEqual(newOffsets)||newReach.Any(i=>i.Offset>=tail))throw new InvalidOperationException("Changed reachable CFG");
            var replacement=target.Body.Instructions.Where(i=>i.Offset>=tail).ToArray();
            if(replacement.Length!=6||replacement.Take(5).Any(i=>i.OpCode.Code!=Code.Nop)||replacement[^1].OpCode.Code!=Code.Ret)throw new InvalidOperationException("Wrong unreachable replacement");
            foreach(var i in reach){var j=target.Body.Instructions.Single(x=>x.Offset==i.Offset);if(i.OpCode.Value!=j.OpCode.Value||i.Operand?.ToString()!=j.Operand?.ToString())throw new InvalidOperationException("Changed reachable instruction");}
            rows.Add(new {token="0x"+m.MetadataToken.ToInt32().ToString("X8"),name=m.FullName,rva=m.RVA,tail_il=tail,code_size=m.Body.CodeSize,reachable_instructions=reach.Count,warning=message,header_locals_eh_unchanged=true,reachable_cil_unchanged=true});
        }
        if(rows.Count!=132)throw new InvalidOperationException("Independent target count differs");
        File.WriteAllText(args[2],JsonSerializer.Serialize(new {scope="INDEPENDENT_ACTUAL_CIL_REACHABILITY_AND_FORM_DELTA_ONLY",parent_sha256=sourceSha,candidate_sha256=candidateSha,methods=rows.Count,pass=true,gameplay_or_original_native_equivalence=false,rows},new JsonSerializerOptions {WriteIndented=true}));Console.WriteLine("INDEPENDENT_CIL_FORM_PASS methods="+rows.Count);
    }
}
