from pathlib import Path
import hashlib,json,struct,subprocess,importlib.util,sys,collections
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'));import dnfile
sha=lambda b:hashlib.sha256(b).hexdigest();parent=(W/'startup-r6/candidate1.dll').read_bytes();candidate=Q/'candidate1.dll';data=candidate.read_bytes()
assert sha(parent)=='c36092b5326687112adfa8c285bb3cf5e8ad46d3b3de8ebcd84daf598041465d' and sha(data)=='22d6aa537bfb71e40dcfa0fdd8776566278cf8fd9a4d4212a93fb7d49d3a8655'
independent=json.loads((Q/'INDEPENDENT-CIL-FORM.json').read_bytes());assert independent['pass'] and independent['methods']==132 and independent['candidate_sha256']==sha(data)
pe=dnfile.dnPE(data=parent);expected=bytearray(parent);ranges=[]
for row in independent['rows']:
    rid=int(row['token'],16)&0xffffff;m=pe.net.mdtables.MethodDef.rows[rid-1];assert m.Rva==row['rva'];start=pe.get_offset_from_rva(m.Rva)
    tiny=parent[start]&3==2;header=1 if tiny else (struct.unpack_from('<H',parent,start)[0]>>12)*4;size=parent[start]>>2 if tiny else struct.unpack_from('<I',parent,start+4)[0]
    assert size==row['code_size']==row['tail_il']+6;at=start+header+row['tail_il'];assert parent[at]==0x72 and parent[at+5]==0x26
    expected[at:at+6]=b'\0'*5+b'\x2a';ranges.append((rid,start,header,at))
def boundary(b):
    if b!=expected:raise ValueError('Whole-file delta exceeds independently proven 132 tail spans')
boundary(data);assert data==(Q/'candidate2.dll').read_bytes();controls=[]
for name,at in [('reachable-opcode',ranges[0][1]+ranges[0][2]),('body-header',ranges[0][1]),('missing-tail-termination',ranges[0][3]+5),('metadata',pe.get_offset_from_rva(pe.net.struct.MetaDataRva))]:
    b=bytearray(data);b[at]^=1
    try:boundary(bytes(b))
    except ValueError:controls.append(dict(name=name,rejected=True));continue
    raise AssertionError('Boundary false accept '+name)
(Q/'ISOLATION.json').write_bytes((json.dumps(dict(scope='INDEPENDENT_WHOLE_FILE_132_TAIL_BYTE_BOUNDARY',candidate_sha256=sha(data),body_targets=132,untouched_methoddefs=2185,
    headers_metadata_rvas_and_other_bytes_unchanged=True,reachable_cil_unchanged=True,pass_=True,negative_controls=controls),indent=2)+'\n').encode())
DOT=ROOT/'.local/dotnet10/dotnet.exe';SUPPORT=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support';EXPORT=ROOT/'audit/bulk250-r1-evidence-39702928368/bulk250-r1-run/tools_bin/CilExporter/bin/CilExporter.dll'
CHECKER=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py';MEMBER=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/member-bin/MemberAccess.dll'
assert sha(CHECKER.read_bytes())=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14'
spec=importlib.util.spec_from_file_location('frozen_unchanged',CHECKER);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
def run(label,args,allowed=(0,)):
    p=subprocess.run([str(x) for x in args],capture_output=True);(Q/(label+'.stdout.log')).write_bytes(p.stdout);(Q/(label+'.stderr.log')).write_bytes(p.stderr);assert p.returncode in allowed,(label,p.returncode,p.stderr[:700]);return p.returncode
tokens=[r['token'] for r in json.loads((Q/'METHODS.json').read_bytes())['methods']];assert len(tokens)==174
run('union-cil-export',[DOT,EXPORT,candidate,Q/'UNION-CIL.json',SUPPORT,','.join(tokens)])
cil=json.loads((Q/'UNION-CIL.json').read_text('utf-8-sig'));results=[]
for m in cil['methods']:
    try:r=v.verify(m,cil['types'])
    except Exception as e:r=dict(token=m['token'],status='FAIL_OR_UNSUPPORTED',error=str(e))
    results.append(r)
prior={m['token'] for m in json.loads((W/'startup-r6/FORTY-FIVE-CIL.json').read_bytes())['methods']};assert all(r['status']=='PASS' for r in results if r['token'] in prior)
counts=dict(collections.Counter(r['status'] for r in results));(Q/'FROZEN-UNION-174.json').write_bytes((json.dumps(dict(scope='UNCHANGED_FROZEN_STACK_SCOPE_NOT_BEHAVIOR',candidate_sha256=sha(data),total=174,counts=counts,prior_45_passed=True,results=results),indent=2)+'\n').encode())
O=Q/'buff-runtime-results';O.mkdir(exist_ok=True);b=bytearray(data);start=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[0x5e7-1].Rva);header=(struct.unpack_from('<H',parent,start)[0]>>12)*4
for offset in [279,819]:assert b[start+header+offset]==0x20;b[start+header+offset:start+header+offset+9]=b'\x21'+struct.pack('<q',4294967295)
bad=O/'int64-sentinel-restored.dll';bad.write_bytes(b);run('int64-export',[DOT,EXPORT,bad,Q/'INT64-CONTROL-CIL.json',SUPPORT,'0x060005E7'])
bad_cil=json.loads((Q/'INT64-CONTROL-CIL.json').read_text('utf-8-sig'))
try:failure=v.verify(bad_cil['methods'][0],bad_cil['types'])
except Exception as e:failure=dict(token='0x060005E7',status='FAIL',error=str(e))
assert failure['status']!='PASS';(Q/'INT64-NEGATIVE-WIDTH.json').write_bytes((json.dumps(dict(scope='UNCHANGED_FROZEN_WIDTH_GATE_ON_PHYSICAL_INT64_MUTANT',baseline_passed=True,mutant_sha256=sha(b),checker_sha256=sha(CHECKER.read_bytes()),runtime_did_not_distinguish=True,rejected=True,result=failure),indent=2)+'\n').encode())
print(json.dumps(dict(isolation_methods=132,boundary_controls=4,union_frozen_counts=counts,prior45_passed=True,int64_control_rejected=True),indent=2))
