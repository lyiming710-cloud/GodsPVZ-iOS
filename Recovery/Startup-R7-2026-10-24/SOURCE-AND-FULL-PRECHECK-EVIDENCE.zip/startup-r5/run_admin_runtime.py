from pathlib import Path
import hashlib,json,subprocess,sys,struct
Q=Path(__file__).resolve().parent;ROOT=Q.parents[2]
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
OUT=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else Q/'admin-runtime-results';OUT.mkdir(exist_ok=True)
cases=[]
for board,manager in [(1,1),(0,1),(0,0),(2,1),(0,2)]:
    for mode in ['null','empty','value']:
        cases.append(dict(name=f'board{board}-manager{manager}-{mode}',board=board,manager=manager,json=mode,callback='none'))
for board,manager,mode,callback in [(1,1,'value','mutate-selected'),(0,1,'value','mutate-selected'),(1,1,'value','new-system2-at-path'),
        (0,0,'value','advance-save-at-path'),(0,0,'value','new-save-at-path'),(0,1,'value','replace-manager-on-truth'),(1,1,'empty','new-system2-at-constructor')]:
    cases.append(dict(name=callback+f'-board{board}',board=board,manager=manager,json=mode,callback=callback))
(OUT/'CASES.json').write_bytes((json.dumps(cases,indent=2)+'\n').encode())
def run(label,args):
    proc=subprocess.run(args,capture_output=True)
    (OUT/(label+'.stdout.log')).write_bytes(proc.stdout);(OUT/(label+'.stderr.log')).write_bytes(proc.stderr)
    if proc.returncode:raise RuntimeError(label+' exit='+str(proc.returncode)+' stderr='+proc.stderr.decode('utf-8','replace')[:500])
dot=ROOT/'.local/dotnet10/dotnet.exe';fixture=Q/'runtime-admin/bin/Release/net10.0/Fixture.dll'
candidate=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Q/'candidate1.dll';assert hashlib.sha256(candidate.read_bytes()).hexdigest() in ['7fa02b81d4d1af579a18eea103f776493f012565e64d5b38fd885cf40718a296','c36092b5326687112adfa8c285bb3cf5e8ad46d3b3de8ebcd84daf598041465d','22d6aa537bfb71e40dcfa0fdd8776566278cf8fd9a4d4212a93fb7d49d3a8655']
run('native',[sys.executable,str(Q/'native_admin_oracle.py'),str(OUT/'CASES.json'),str(OUT/'NATIVE.json')])
run('actual-cil',[str(dot),str(fixture),str(candidate),str(OUT/'CASES.json'),str(OUT/'ACTUAL-CIL.json')])
native=json.loads((OUT/'NATIVE.json').read_bytes());cil=json.loads((OUT/'ACTUAL-CIL.json').read_bytes())
assert len(native['results'])==len(cil['results'])==len(cases)==22
differences=[dict(name=a['name'],native=a,cil=b) for a,b in zip(native['results'],cil['results']) if a!=b]
raw=candidate.read_bytes();pe=dnfile.dnPE(data=raw);row=pe.net.mdtables.MethodDef.rows[8];start=pe.get_offset_from_rva(row.Rva)
header=(struct.unpack_from('<H',raw,start)[0]>>12)*4
mutants={}
b=bytearray(raw);struct.pack_into('<I',b,start+header+374,0x040001af);mutants['wrong-manager-challenge-field']=bytes(b)
b=bytearray(raw);b[start+header:start+header+5]=b'\x2a\0\0\0\0';mutants['early-return']=bytes(b)
b=bytearray(raw)
for offset in [531,588]:
    assert raw[start+header+offset]==0x7d
    b[start+header+offset:start+header+offset+5]=bytes.fromhex('2626000000')
mutants['config-assignment-omitted']=bytes(b)
controls=[]
for name,data in mutants.items():
    dll=OUT/(name+'.dll');dll.write_bytes(data)
    run(name,[str(dot),str(fixture),str(dll),str(OUT/'CASES.json'),str(OUT/(name+'.json'))])
    result=json.loads((OUT/(name+'.json')).read_bytes());detected=sum(a!=b for a,b in zip(native['results'],result['results']))
    controls.append(dict(name=name,mutant_sha256=hashlib.sha256(data).hexdigest(),detected_cases=detected,baseline_pass=not differences,pass_=not differences and detected>0))
parent=Q.parent/'startup-r4/candidate3.dll'
run('damaged-parent',[str(dot),str(fixture),str(parent),str(OUT/'CASES.json'),str(OUT/'damaged-parent.json')])
result=json.loads((OUT/'damaged-parent.json').read_bytes());detected=sum(a!=b for a,b in zip(native['results'],result['results']))
controls.append(dict(name='damaged-parent-native-pointer-placeholders',detected_cases=detected,baseline_pass=not differences,pass_=not differences and detected>0))
report=dict(scope='ADMIN_CONFIG_ACTUAL_CIL_VS_ORIGINAL_PC_NATIVE_CONTROLLED_NORMAL_PATHS_ONLY',candidate_sha256=hashlib.sha256(raw).hexdigest(),method_token='0x06000009',cases=len(cases),
            pass_=not differences and all(c['pass_'] for c in controls),differences=differences,negative_controls=controls,
            exceptions_native_unwind_modeled=False,log_text_equivalence=False,unity_execution=False,whole_six_method_acceptance=False)
(OUT/'RESULT.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
print(json.dumps(report,indent=2));assert report['pass_']
