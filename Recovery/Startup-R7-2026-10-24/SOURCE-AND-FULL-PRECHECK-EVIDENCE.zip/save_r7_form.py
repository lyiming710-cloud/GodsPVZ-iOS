from pathlib import Path
import hashlib,json,zipfile,collections
W=Path(__file__).resolve().parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113';Q=W/'startup-r7';D=R/'Recovery/Startup-R7-2026-10-24';D.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
def rec(n,b):return dict(file=n,bytes=len(b),sha256=sha(b))
def js(p,d):p.write_bytes((json.dumps(d,indent=2,ensure_ascii=False)+'\n').encode())
def pack(p,items):
    assert len(items)==len({n for n,b in items})
    with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
        for n,b in items:z.writestr(n,b)
        z.writestr('MANIFEST.json',json.dumps([rec(n,b) for n,b in items],indent=2))
    with zipfile.ZipFile(p) as z:
        assert z.testzip() is None
        rows=json.loads(z.read('MANIFEST.json'));assert set(z.namelist())=={'MANIFEST.json'}|{r['file'] for r in rows}
        for r in rows:assert rec(r['file'],z.read(r['file']))==r
raw=(Q/'candidate1.dll').read_bytes();digest=sha(raw);assert digest=='22d6aa537bfb71e40dcfa0fdd8776566278cf8fd9a4d4212a93fb7d49d3a8655'
form=json.loads((Q/'INDEPENDENT-CIL-FORM.json').read_bytes());assert form['pass'] and form['methods']==132
jit=json.loads((Q/'exact-jit-results/RESULT.json').read_bytes());assert jit['all_jit_prepared'] and jit['status_pairs']==[dict(parent='REJECTED',candidate='JIT_PREPARED_NO_EXECUTION',count=132)]
runtime=[]
for suite in ['admin','board','system','buff','events']:
    d=json.loads((Q/f'{suite}-runtime-results/RESULT.json').read_bytes());assert d['candidate_sha256']==digest and d['pass_'];runtime.append(dict(suite=suite,result=d))
assert sum(s['result']['cases'] for s in runtime)==2475
js(Q/'RUNTIME-SUMMARY.json',dict(scope='SAME_SIX_CALLER_SCOPES_REEXECUTED_ON_EXACT_R7_NOT_ALL_132_METHOD_BEHAVIOR',candidate_sha256=digest,cases=2475,methods=6,suites=runtime,whole_game_acceptance=False))
# Compact, lossless physical variants including the two diagnostic EH changes.
mutants=[]
for p in sorted(Q.rglob('*.dll')):
    rel=p.relative_to(Q)
    if p.name.startswith('candidate') or any(x in ['bin','obj'] for x in rel.parts):continue
    data=p.read_bytes();assert len(data)==len(raw);runs=[]
    for page in range(0,len(raw),4096):
        a=raw[page:page+4096];b=data[page:page+4096]
        if a==b:continue
        at=0
        while at<len(a):
            if a[at]==b[at]:at+=1;continue
            end=at+1
            while end<len(a) and a[end]!=b[end]:end+=1
            runs.append(dict(file_offset=page+at,before=a[at:end].hex(),after=b[at:end].hex()));at=end
    proof=bytearray(raw)
    for r in runs:
        at=r['file_offset'];before=bytes.fromhex(r['before']);after=bytes.fromhex(r['after']);assert proof[at:at+len(before)]==before;proof[at:at+len(after)]=after
    assert proof==data;mutants.append(dict(file=rel.as_posix(),parent_sha256=digest,sha256=sha(data),runs=runs))
js(Q/'PHYSICAL-VARIANTS.json',dict(scope='RECONSTRUCTABLE_ACTUALLY_EXECUTED_MUTANTS_AND_DIAGNOSTICS',variants=mutants))
alljit=json.loads((Q/'all-exact-jit-results/RESULT.json').read_bytes());supp=json.loads((Q/'closure-supplement/RESULT.json').read_bytes());bytoken={r['token']:r for r in alljit['rows']}
for r in supp['rows']:bytoken[r['token']]=r['supplemented']
names={m['token']:m['name'] for m in json.loads((Q/'ALL-CIL.json').read_bytes())['methods']}
queue=[dict(token=r['token'],name=names[r['token']],status=r['status'],error=r.get('error'),category='CLR_API_BINDING_REVIEW' if 'MissingMethodException' in r.get('error','') else 'ACTUAL_CLR_INVALID_PROGRAM_REQUIRES_CIL_NATIVE_REVIEW') for r in bytoken.values() if r['status']=='REJECTED']
assert len(queue)==13
js(Q/'NEXT-JIT-QUEUE.json',dict(candidate_sha256=digest,scope='JIT_REJECTIONS_AFTER_REFERENCE_CLOSURE_SUPPLEMENT_NOT_ALL_REMAINING_BUGS',rows=queue,open_generics_pending=50))
(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text whitespace=cr-at-eol\n*.md -text\n*.zip -text\n')
for n in ['CONSTRUCTION.json','INDEPENDENT-CIL-FORM.json','ISOLATION.json','FROZEN-UNION-174.json','INT64-NEGATIVE-WIDTH.json','LEXICAL-TAIL-CENSUS.json','RUNTIME-SUMMARY.json','NEXT-JIT-QUEUE.json']:(D/n).write_bytes((Q/n).read_bytes())
(D/'EXACT-JIT-132.json').write_bytes((Q/'exact-jit-results/RESULT.json').read_bytes())
(D/'EXACT-JIT-ALL-2297.json').write_bytes((Q/'all-exact-jit-results/RESULT.json').read_bytes())
(D/'REFERENCE-CLOSURE-SUPPLEMENT.json').write_bytes((Q/'closure-supplement/RESULT.json').read_bytes())
pack(D/'STARTUP-R7-CANDIDATE.zip',[('STARTUP-R7.dll',raw)])
items=[]
for p in sorted(Q.rglob('*')):
    if not p.is_file() or any(x in ['__pycache__','obj'] for x in p.relative_to(Q).parts):continue
    if p.suffix=='.dll' and 'bin' not in p.relative_to(Q).parts:continue
    if p.name in ['Mono.Cecil.dll'] or p.suffix=='.exe':continue
    items.append((p.relative_to(W).as_posix(),p.read_bytes()))
source=W/'startup-r5'
for p in sorted(source.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(source)
    if any(x in ['obj','__pycache__'] or x.endswith('-runtime-results') for x in rel.parts):continue
    if p.suffix=='.dll' and 'bin' not in rel.parts:continue
    if p.name in ['Mono.Cecil.dll'] or p.suffix=='.exe':continue
    if p.suffix not in ['.py','.cs','.csproj','.dll','.json','.pdb']:continue
    items.append((p.relative_to(W).as_posix(),p.read_bytes()))
items.append(('startup-r6/construct_r7_tails.py',(W/'startup-r6/construct_r7_tails.py').read_bytes()))
for p in [W/'remaining-native'/f'{rid}.normal-cfg.{ext}' for rid in ['0089','02AD','05E7','07B7','07B8'] for ext in ['json','txt']]:items.append((p.relative_to(W).as_posix(),p.read_bytes()))
for p in [W/'administrator-next-native'/f'0009.normal-cfg.{ext}' for ext in ['json','txt']]:items.append((p.relative_to(W).as_posix(),p.read_bytes()))
for p in [source/'runtime-admin/bin/Release/net10.0/Mono.Cecil.dll',ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support/Unity.VisualScripting.Core.exe']:items.append(('runtime-dependencies/'+p.name,p.read_bytes()))
items.append(('save_r7_form.py',Path(__file__).read_bytes()));pack(D/'SOURCE-AND-FULL-PRECHECK-EVIDENCE.zip',items)
js(D/'CURRENT-RESULT.json',dict(status='132_METHOD_FORM_REPAIRS_AND_SIX_SCOPED_RUNTIME_SUITES_FULL_PROMOTION_HELD',candidate_sha256=digest,parent_sha256='c36092b5326687112adfa8c285bb3cf5e8ad46d3b3de8ebcd84daf598041465d',bytes=len(raw),
    direct_body_targets=132,untouched_methoddefs=2185,reachable_cil_metadata_headers_rvas_unchanged=True,independent_cil_form_methods=132,exact_jit_parent_rejected=132,exact_jit_candidate_prepared=132,
    exact_six_method_controlled_cases=2475,union_frozen={'methods':174,'pass':163,'fail_or_unsupported':11,'prior_45_passed':True},
    whole_assembly={'methods':2297,'original_jit':alljit['counts'],'reference_supplement_jit':supp['supplemented_counts'],'raw_frozen':{'pass':2136,'fail_or_unsupported':161},'interface_fact_frozen':{'pass':2164,'fail_or_unsupported':133},
    'member_rejected_sites':217,'member_rejected_methods':112,'member_unresolved':0,'unterminated_tails':9,'all_pass':False},
    diagnostic_eh_variants={'Administrator.Start':'UNREACHABLE_TRY_GAP_SEALED_JIT_PREPARED_DIAGNOSTIC_ONLY','Zombie.SetUIs':'INNER_FIRST_CLAUSE_ORDER_JIT_PREPARED_DIAGNOSTIC_ONLY'},
    unity_r7='NOT_RUN',il2cpp_r7='NOT_RUN',apple_cpp_r7='NOT_RUN',ipa=None,ipad_acceptance=False))
(D/'README.md').write_bytes('''# Startup R7: 132 batch method-form repairs, full assembly prechecks

R7 candidate SHA-256: `22d6aa537bfb71e40dcfa0fdd8776566278cf8fd9a4d4212a93fb7d49d3a8655`, 18,863,104 bytes. Parent is R6 `c36092b5…41465d`. This checkpoint does not claim an updated IPA, full gameplay equivalence or complete compiler qualification.

## What changed

Exactly 132 additional void methods had a trailing Cpp2IL warning string/pop which was unreachable from both method entry and any exception entry (all selected methods have zero EH). The six-byte span is replaced with five NOPs and ret. Every reachable instruction, local, method header, RVA and metadata byte is unchanged, as are the other 2,185 MethodDefs. Tiny and fat body headers are handled separately. Nine reachable or nonvoid unterminated tails are explicitly excluded. No real method body is replaced by an early return, no exception is swallowed, and no whole-assembly return/throw rule is applied.

Independent verification reads actual parent/candidate CIL through Mono.Cecil without reading the constructor plan, recomputes reachability, and validates all 132 targets. A separate raw reader admits only the exact spans and rejects four physical boundary mutants. The exact real assemblies were then loaded in isolated CLR processes and each original method was passed to RuntimeHelpers.PrepareMethod: 132/132 parents rejected with InvalidProgramException, 132/132 corrected methods prepared. No game method was invoked by that JIT test. This is strong method-form evidence, not proof of original gameplay behavior.

The six R6 caller suites were reexecuted on the exact R7 input and again matched original PC caller execution in 2,475 controlled cases. Their narrow scopes and callee models remain unchanged. Of 24 fault controls, runtime detects 23; the Int64 sentinel remains undetected by CLR truncation and is independently rejected by the unchanged frozen width gate. RUNTIME-SUMMARY retains that false runtime control.

## Broad prechecks before another long Unity/Xcode run

All 2,297 actual bodies received a direct CLR JIT precheck. Original run: 2,230 prepared, 17 rejected, 50 unsupported open generic methods. Four rejection records were missing-reference artifacts: the resolver searched only .dll while the already present Unity.VisualScripting.Core dependency is a managed .exe. An identity-checked .exe resolution supplement makes those four prepare, without changing any DLL bytes or inventing a dependency. Both results are retained. Supplemented counts: 2,234 prepared, 13 rejected, 50 open generics pending. The source in the archive includes the corrected resolver; reproducing the original missing-reference records requires a DLL-only resolver. The original probe binary before the resolver correction was not retained; the original raw records and the source-level resolver difference are preserved. JIT preparation can miss permissive width conversions and runtime access checks, and is not a standalone acceptance gate.

The unchanged frozen checker still reports 2,136 PASS / 161 FAIL_OR_UNSUPPORTED; with exact InterfaceImpl facts it reports 2,164 / 133. The changed-plus-prior union contains 174 methods, of which 163 pass and 11 remain type failures; the prior 45 still pass. All 11 are retained, including I8-to-I4 and numeric comparison/argument defects. CLR preparation does not clear them. The whole-assembly member checker still rejects 217 sites across 112 methods with zero unresolved; its actual nonzero exit is archived. These queues overlap and are not a total remaining-game-bug count.

NEXT-JIT-QUEUE lists 12 InvalidProgramException methods plus one System.MathF.FMod binding review. Among the 12, nine have the excluded reachable/nonvoid tails. The other three are Administrator.Start, Plant.PC_Nutknight and Zombie.SetUIs. Two separate diagnostic files show that sealing an unreachable blank try-region edge in Administrator.Start and ordering nested clauses inner-first in Zombie.SetUIs make those exact methods prepare. These variants are evidence for the next repair checkpoint only; they are not part of the R7 candidate. No finally handler was removed or changed by the diagnostics.

## Artifacts and reproduction

STARTUP-R7-CANDIDATE.zip contains the exact candidate and internal SHA manifest. SOURCE-AND-FULL-PRECHECK-EVIDENCE.zip contains the batch constructor, independent CIL verifier, direct JIT probe, per-method 132 before/after records, all 2,297 JIT records, reference supplement, raw full CIL exports, frozen/access outputs, the six execution suites, native CFGs, compiled fixtures and reconstructable byte deltas for actually executed mutants/diagnostics. Every archive member is hashed. R6 and earlier checkpoints remain separate immutable parents.

Native caller execution requires Windows x64 with the original hash-locked PC PE/metadata inputs. The unchanged source-DLL frozen checker and authentic support folder remain required. Direct JIT checks require .NET but do not launch Unity or execute game methods. Open generics require explicit instantiation. Runtime fixture code emits every candidate instruction; the diagnostic appended-ret switch must remain unset. Actual Unity Editor, IL2CPP, Apple compilation, Board gameplay, physical audio, iPad rendering/input and unsigned IPA acceptance remain separate pending work. The earlier successful R3 shader/Editor run is not promoted onto this child.
'''.encode())
js(D/'MANIFEST.json',[rec(p.relative_to(D).as_posix(),p.read_bytes()) for p in sorted(D.rglob('*')) if p.is_file() and p!=D/'MANIFEST.json'])
print(json.dumps(dict(checkpoint=str(D),candidate_sha256=digest,archives={p.name:p.stat().st_size for p in D.glob('*.zip')},physical_variants=len(mutants))))
