"""Batch 132 proven-unreachable void tails; no reachable opcode is replaced."""
from pathlib import Path
import hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];O=W/'startup-r7';O.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'));import dnfile
sha=lambda b:hashlib.sha256(b).hexdigest();parent=(Q/'candidate1.dll').read_bytes();assert sha(parent)=='c36092b5326687112adfa8c285bb3cf5e8ad46d3b3de8ebcd84daf598041465d'
pe=dnfile.dnPE(data=parent);cil=json.loads((Q/'ALL-CIL.json').read_bytes());out=bytearray(parent);changes=[]
for m in cil['methods']:
    ins=m['instructions']
    if m['ret']!='System.Void' or m['handlers'] or len(ins)<2 or ins[-1]['opcode']!='pop' or ins[-2]['opcode']!='ldstr':continue
    if not str(ins[-2]['operand']).startswith('Warning:'):continue
    offsets=[i['offset'] for i in ins];by_offset={i['offset']:i for i in ins};edges={};unsupported=False
    for n,at in enumerate(offsets):
        i=by_offset[at];op=i['opcode'];following=offsets[n+1:n+2]
        if op in ['ret','throw','rethrow','endfinally','endfilter','jmp']:to=[]
        elif op in ['br','br.s','leave','leave.s']:to=[i['operand']['target']]
        elif op.startswith('br') or op.split('.')[0] in ['beq','bge','bgt','ble','blt','bne']:to=[i['operand']['target']]+following
        elif op=='switch':unsupported=True;break
        else:to=following
        assert all(t in by_offset for t in to);edges[at]=to
    if unsupported:continue
    reached=set();pending=[0]
    while pending:
        at=pending.pop()
        if at in reached:continue
        reached.add(at);pending+=edges[at]
    tail=ins[-2]['offset']
    if {tail,ins[-1]['offset']}&reached:continue
    assert ins[-1]['offset']==tail+5
    assert all(edges[at] or by_offset[at]['opcode'] in ['ret','throw','rethrow','endfinally','endfilter','jmp'] for at in reached)
    rid=int(m['token'],16)&0xffffff;at=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[rid-1].Rva)
    tiny=parent[at]&3==2;head=1 if tiny else (struct.unpack_from('<H',parent,at)[0]>>12)*4;size=parent[at]>>2 if tiny else struct.unpack_from('<I',parent,at+4)[0];assert size==tail+6,m['token']
    pos=at+head+tail;old=parent[pos:pos+6];assert old[0]==0x72 and old[-1]==0x26
    new=b'\0'*5+b'\x2a';out[pos:pos+6]=new
    changes.append(dict(token=m['token'],name=m['name'],il_offset=tail,file_offset=pos,before=old.hex(),after=new.hex(),reachable_offsets=sorted(reached),code_size=size,
                        return_type=m['ret'],handlers=0,header_kind='tiny' if tiny else 'fat',warning_text=ins[-2]['operand']))
assert len(changes)==132 and len({c['token'] for c in changes})==132
data=bytes(out);allowed={i for c in changes for i in range(c['file_offset'],c['file_offset']+6)}
assert len(parent)==len(data) and all(a==b or i in allowed for i,(a,b) in enumerate(zip(parent,data)))
for n in [1,2]:(O/f'candidate{n}.dll').write_bytes(data)
prior_tokens={m['token'] for m in json.loads((Q/'FORTY-FIVE-CIL.json').read_bytes())['methods']};tokens=prior_tokens|{c['token'] for c in changes}
(O/'METHODS.json').write_bytes((json.dumps(dict(methods=[dict(token=t) for t in sorted(tokens)]),indent=2)+'\n').encode())
report=dict(scope='132_UNREACHABLE_VOID_WARNING_TAILS_ONLY_NO_REACHABLE_CODE_REPLACED',parent_sha256=sha(parent),candidate_sha256=sha(data),bytes=len(data),body_targets=132,
            unchanged_methoddefs=2317-132,metadata_headers_rvas_unchanged=True,all_other_file_bytes_identical=True,prior_45_union=len(tokens),changes=changes,
            nine_reachable_or_nonvoid_tails_unchanged=True,runtime_or_gameplay_qualification=False,unity_export=False,ipa=None)
(O/'CONSTRUCTION.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in report.items() if k!='changes'},indent=2))
