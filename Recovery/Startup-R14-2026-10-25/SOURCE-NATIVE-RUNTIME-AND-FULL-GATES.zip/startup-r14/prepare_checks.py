from pathlib import Path
import hashlib,json,shutil
Q=Path(__file__).resolve().parent;W=Q.parent;old='e6452513ce3c5a3d9449d8c7287aae39a8458cdc8e4eec09d199769aa1794b4b';new='9b53867fb47378190f147f9b474ed24525b15dde44ce753143e56934aaf2c491';rows=[];sha=lambda b:hashlib.sha256(b).hexdigest()
for name in ['full_type_census_r13.py','interface_facts_r13.py','census_lexical_tails.py','full_member_access.py','run_changed_exact_jit.py']:
    src=W/'startup-r13'/name;b=src.read_bytes();s=b.decode().replace(old,new).replace('startup-r13','startup-r14').replace('len(tokens)==8','len(tokens)==5').replace('CHANGED_EIGHT_EXACT_CLR','CHANGED_FIVE_EXACT_CLR');out=Q/name.replace('_r13','_r14');out.write_bytes(s.encode());rows.append(dict(source=str(src.relative_to(W)),source_sha256=sha(b),derived=str(out.relative_to(W)),derived_sha256=sha(out.read_bytes()),changes='Exact child hash/output path and changed-five JIT count only'))
shutil.copy2(W/'startup-r13/ALL-METHODS.json',Q/'ALL-METHODS.json');(Q/'DRIVER-DERIVATION.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode());print('Prepared',len(rows),'readonly driver derivatives')
