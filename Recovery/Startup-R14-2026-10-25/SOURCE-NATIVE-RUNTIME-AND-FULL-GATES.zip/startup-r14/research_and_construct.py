"""Five complete short native-backed bodies: prop reset and TMP constructors.

Construct only after checking the original packed-three-field initialization.
All bodies fit existing slots; no metadata/visibility/RVA/local changes.
"""
from pathlib import Path
import hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];repeat='--repeat' in sys.argv;sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile,pefile
from capstone import *
from capstone.x86_const import X86_OP_IMM
sha=lambda b:hashlib.sha256(b).hexdigest();parent=(W/'startup-r13/candidate1.dll').read_bytes();assert sha(parent)=='e6452513ce3c5a3d9449d8c7287aae39a8458cdc8e4eec09d199769aa1794b4b';pe=dnfile.dnPE(data=parent)
raw=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/GameAssembly.dll').read_bytes();assert sha(raw)=='9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d';pc=pefile.PE(data=raw);base=pc.OPTIONAL_HEADER.ImageBase;dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True
fields=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_text('utf-8-sig'));targets={0x694,0x695,0x696,0x7c4,0x7cf};bodies={};changes=[];evidence=[]
def token(op,value):return bytes([op])+struct.pack('<I',value)
def get(rid):
    r=pe.net.mdtables.MethodDef.rows[rid-1];at=pe.get_offset_from_rva(r.Rva);h=1 if parent[at]&3==2 else (struct.unpack_from('<H',parent,at)[0]>>12)*4;size=parent[at]>>2 if h==1 else struct.unpack_from('<I',parent,at+4)[0];return r,at,h,parent[at+h:at+h+size]
def pointer(rid):return int.from_bytes(pc.get_data(0x181b82d60-base+(rid-1)*8,8),'little')
for rid in sorted(targets):
    entry=pointer(rid);pending=[entry];ins={};tails=[]
    while pending:
        at=pending.pop()
        while at not in ins:
            i=next(dis.disasm(pc.get_data(at-base,15),at));ins[at]=i;assert len(ins)<100
            if i.group(CS_GRP_RET) or i.mnemonic in ['int3','ud2']:break
            if i.group(CS_GRP_JUMP):
                assert i.operands[0].type==X86_OP_IMM;dest=i.operands[0].imm
                if dest in [0x18131bad0,0x1812e22a0]:tails.append(dict(source=hex(at),target=hex(dest)))
                elif dest not in ins:pending.append(dest)
                if i.mnemonic=='jmp':break
            at+=i.size
    rows=[dict(va=hex(i.address),op=i.mnemonic,operands=i.op_str,bytes=i.bytes.hex()) for i in sorted(ins.values(),key=lambda x:x.address)]
    assert len(tails)==1
    cfg=dict(token=f'0x{0x6000000|rid:08X}',entry=hex(entry),instructions=rows,tail_targets=tails,scope='COMPLETE_CALLER_NORMAL_CFG_WITH_EXPLICIT_CONTROLLED_EXTERNAL_TAIL',native_exception_unwind=False)
    (Q/f'{rid:04X}.native.json').write_bytes((json.dumps(cfg,indent=2)+'\n').encode());(Q/f'{rid:04X}.native.txt').write_text('\n'.join(f"{r['va']} {r['bytes']:22s} {r['op']} {r['operands']}" for r in rows)+'\n')
    row,at,h,old=get(rid)
    if rid in [0x694,0x695,0x696]:
        cd=0x0400089e;go=0x0400089b
        assert any(x['op']=='mov' and x['operands'].endswith(', 0xffffffff') and '+ 0x48]' in x['operands'] for x in rows)
        assert next(f for f in fields if f['type']=='PropChooseSystem' and f['name']=='currentPropBankID')['offset']==0x48
        assert next(f for f in fields if f['type']=='PropChooseSystem' and f['name']=='prop_ChooseList_GameObject')['offset']==0x30
        if rid==0x694:
            assert old[8]==0x28;select=int.from_bytes(old[9:13],'little');assert select>>24==6 and pointer(select&0xffffff)==0x1803a8b40
            active=int.from_bytes(old[45:49],'little');assert old[44]==0x28
            # Capture the list receiver before resetting the bank ID, exactly
            # like native MOV RCX,[RBX+30] then MOV [RBX+48],FFFFFFFF.
            code=b'\x02\x14\x02'+token(0x7b,cd)+token(0x28,select)+b'\x02'+token(0x7b,go)+b'\x02\x15'+token(0x7d,cd)+b'\x16'+token(0x6f,active)+b'\x2a'
        else:
            assert old[31]==0x28;active=int.from_bytes(old[32:36],'little');code=b'\x02\x15'+token(0x7d,cd)+b'\x02'+token(0x7b,go)+b'\x16'+token(0x6f,active)+b'\x2a'
        assert tails[0]['target']=='0x18131bad0';field_evidence=[f for f in fields if f['type']=='PropChooseSystem' and f['name'] in ['currentPropBankID','prop_ChooseList_GameObject']]
    else:
        type_name='TMP_TextSelector_A' if rid==0x7c4 else 'TMP_TextSelector_B';offset=0x34 if rid==0x7c4 else 0x54;tokens=[0x04000a08,0x04000a09,0x04000a0a] if rid==0x7c4 else [0x04000a14,0x04000a15,0x04000a16]
        assert any(x['op']=='mov' and x['operands']==f'qword ptr [rcx + {hex(offset)}], 0xffffffffffffffff' for x in rows)
        assert any(x['op']=='mov' and x['operands']==f'dword ptr [rcx + {hex(offset+8)}], 0xffffffff' for x in rows)
        field_evidence=[next(f for f in fields if f['type']==type_name and int(f['token'],16)==t) for t in tokens];assert [r['offset'] for r in field_evidence]==[offset,offset+4,offset+8]
        for t in tokens:assert pe.net.mdtables.Field.rows[(t&0xffffff)-1].Signature.value==bytes.fromhex('0608')
        assert old[27]==0x28;base_ctor=int.from_bytes(old[28:32],'little');assert tails[0]['target']=='0x1812e22a0'
        code=b''.join(b'\x02\x15'+token(0x7d,t) for t in tokens)+b'\x02'+token(0x28,base_ctor)+b'\x2a'
    assert len(code)<=len(old);bodies[rid]=code;evidence.append(dict(token=f'0x{0x6000000|rid:08X}',native_entry=hex(entry),native_instructions=len(rows),fields=field_evidence,external_tail=tails[0]))
out=bytearray(parent);allowed=set();writes={}
for rid,code in bodies.items():
    row,at,h,old=get(rid)
    aliases={n for n,r in enumerate(pe.net.mdtables.MethodDef.rows,1) if r.Rva==row.Rva};assert aliases<=targets
    if at in writes:assert writes[at]==code
    writes[at]=code;out[at+h:at+h+len(code)]=code;allowed.update(range(at+h,at+h+len(code)))
    if h==1:out[at]=(len(code)<<2)|2;allowed.add(at)
    else:struct.pack_into('<I',out,at+4,len(code));allowed.update(range(at+4,at+8))
    changes.append(dict(token=f'0x{0x6000000|rid:08X}',rva=hex(row.Rva),file_offset=at,header_bytes=h,old_code_size=len(old),new_code_size=len(code),code=code.hex(),unused_old_slot_preserved=True))
assert len(out)==len(parent) and all(x==y or i in allowed for i,(x,y) in enumerate(zip(parent,out)))
for name in (['candidate-reproduced.dll'] if repeat else ['candidate1.dll','candidate2.dll']):
    dest=Q/name;assert not dest.exists();dest.write_bytes(out)
report=dict(scope='FIVE_COMPLETE_SHORT_NATIVE_BACKED_BODIES_CONSTRUCTION_RUNTIME_PENDING',parent_sha256=sha(parent),candidate_sha256=sha(out),bytes=len(out),method_targets=5,physical_body_slots=len(writes),unchanged_methoddefs=2312,metadata_rvas_locals_maxstack_visibility_unchanged=True,changes=changes,native_evidence=evidence,runtime='PENDING',unity_or_ipa=False)
(Q/('CONSTRUCTION-REPEAT.json' if repeat else 'CONSTRUCTION.json')).write_bytes((json.dumps(report,indent=2)+'\n').encode());(Q/'METHODS.json').write_bytes((json.dumps(dict(methods=[dict(token=r['token']) for r in changes]),indent=2)+'\n').encode());print(json.dumps({k:v for k,v in report.items() if k not in ['changes','native_evidence']},indent=2))
