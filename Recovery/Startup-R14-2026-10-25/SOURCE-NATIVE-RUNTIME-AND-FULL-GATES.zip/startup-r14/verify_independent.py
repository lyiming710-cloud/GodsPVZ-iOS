"""Raw-byte boundary and decoded CIL check, without reading the writer plan."""
from pathlib import Path
import hashlib,importlib.util,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
sha=lambda b:hashlib.sha256(b).hexdigest()
a=(W/'startup-r13/candidate1.dll').read_bytes();b=(Q/'candidate1.dll').read_bytes();assert sha(a)=='e6452513ce3c5a3d9449d8c7287aae39a8458cdc8e4eec09d199769aa1794b4b' and sha(b)=='9b53867fb47378190f147f9b474ed24525b15dde44ce753143e56934aaf2c491' and b==(Q/'candidate2.dll').read_bytes()
pp=dnfile.dnPE(data=a);cp=dnfile.dnPE(data=b);targets={0x694,0x695,0x696,0x7c4,0x7cf}
spec=importlib.util.spec_from_file_location('raw_span',ROOT/'audit/native111-publication-2026-10-20/repository/scripts/actions/static_gates.py');reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
assert len(pp.net.mdtables.MethodDef.rows)==len(cp.net.mdtables.MethodDef.rows)==2317
allowed=set();changed=[];rows=[]
for rid,(old,new) in enumerate(zip(pp.net.mdtables.MethodDef.rows,cp.net.mdtables.MethodDef.rows),1):
    assert old.Rva==new.Rva
    if not old.Rva:continue
    at=pp.get_offset_from_rva(old.Rva);os=reader.parse_raw_method_body_span(a,at)[0];ns=reader.parse_raw_method_body_span(b,at)[0]
    if a[at:at+os]!=b[at:at+ns]:changed.append(rid)
    if rid not in targets:assert os==ns and a[at:at+os]==b[at:at+ns];continue
    assert a[at]&3==b[at]&3==3;h=(struct.unpack_from('<H',a,at)[0]>>12)*4;assert h==12
    n=struct.unpack_from('<I',a,at+4)[0];m=struct.unpack_from('<I',b,at+4)[0];assert 0<m<n
    assert a[at:at+4]==b[at:at+4] and a[at+8:at+h]==b[at+8:at+h] and a[at+h+m:at+h+n]==b[at+h+m:at+h+n]
    allowed.update(range(at+4,at+8));allowed.update(range(at+h,at+h+m));rows.append(dict(token=f'0x{0x6000000|rid:08X}',rva=hex(old.Rva),old_code_size=n,new_code_size=m))
assert set(changed)==targets
def boundary(data):
    if len(data)!=len(a) or any(x!=y and k not in allowed for k,(x,y) in enumerate(zip(a,data))):raise ValueError('Out-of-scope bytes changed')
boundary(b)
cil=json.loads((Q/'ALL-CIL.json').read_text('utf-8-sig'));methods={int(m['token'],16)&0xffffff:m for m in cil['methods']}
parent=json.loads((W/'startup-r13/ALL-CIL.json').read_text('utf-8-sig'));parent={int(m['token'],16)&0xffffff:m for m in parent['methods']};shape=[]
for rid in sorted(targets):
    m=methods[rid];p=parent[rid];i=m['instructions'];assert m['locals']==p['locals'] and m['handlers']==p['handlers']==[] and m['maxStack']==p['maxStack'] and m['args']==p['args'] and m['hasThis'] and m['ret']=='System.Void'
    if rid in [0x694,0x695,0x696]:
        ops=['ldarg.0','ldc.i4.m1','stfld','ldarg.0','ldfld','ldc.i4.0','callvirt','ret']
        if rid==0x694:ops=['ldarg.0','ldnull','ldarg.0','ldfld','call','ldarg.0','ldfld','ldarg.0','ldc.i4.m1','stfld','ldc.i4.0','callvirt','ret']
        assert [x['opcode'] for x in i]==ops
        assert [x['operand']['identity'] for x in i if x['opcode']=='stfld']==['System.Int32 PropChooseSystem::currentPropBankID']
        assert [x['operand']['identity'] for x in i if x['opcode']=='ldfld']==(['System.Int32 PropChooseSystem::currentPropBankID'] if rid==0x694 else [])+['UnityEngine.GameObject PropChooseSystem::prop_ChooseList_GameObject']
        assert [x['operand']['identity'] for x in i if x['opcode'] in ['call','callvirt']]==(['System.Void PropChooseSystem::Select(Prop_Choose,System.Int32)'] if rid==0x694 else [])+['System.Void UnityEngine.GameObject::SetActive(System.Boolean)']
    else:
        assert [x['opcode'] for x in i]==['ldarg.0','ldc.i4.m1','stfld']*3+['ldarg.0','call','ret']
        suffix='A' if rid==0x7c4 else 'B';names=['m_selectedLink','m_lastCharIndex','m_lastWordIndex'] if rid==0x7c4 else ['m_selectedWord','m_selectedLink','m_lastIndex']
        assert [x['operand']['identity'] for x in i if x['opcode']=='stfld']==[f'System.Int32 TMPro.Examples.TMP_TextSelector_{suffix}::{n}' for n in names]
        assert i[-2]['operand']['identity']=='System.Void UnityEngine.MonoBehaviour::.ctor()'
    shape.append(dict(token=m['token'],all_decoded_instructions_checked=True,locals_eh_maxstack_contracts_preserved=True))
controls=[]
for name,at in [('metadata',pp.get_offset_from_rva(pp.net.struct.MetaDataRva)),('non-target-body',pp.get_offset_from_rva(pp.net.mdtables.MethodDef.rows[0x526-1].Rva)+12),('target-unused-padding',rows[0]['new_code_size']+12+pp.get_offset_from_rva(pp.net.mdtables.MethodDef.rows[0x694-1].Rva)),('target-header-maxstack',pp.get_offset_from_rva(pp.net.mdtables.MethodDef.rows[0x694-1].Rva)+2)]:
    bad=bytearray(b);bad[at]^=1
    try:boundary(bad)
    except ValueError:controls.append(dict(name=name,rejected=True));continue
    raise AssertionError('Raw boundary false accept')
frozen=json.loads((Q/'FROZEN-STACK-ALL-2297.json').read_bytes());fr={int(r['token'],16)&0xffffff:r for r in frozen['results']};assert all(fr[rid]['status']=='PASS' for rid in targets)
result=dict(scope='INDEPENDENT_WHOLE_FILE_RAW_BOUNDARY_ALL_METHODS_AND_DECODED_CIL_CONTRACTS',candidate_sha256=sha(b),parent_sha256=sha(a),pass_=True,methoddefs=2317,method_bodies=2297,changed_methods=5,unchanged_methoddefs=2312,metadata_rvas_locals_maxstack_visibility_identical=True,unused_original_slots_preserved=True,methods=rows,cil_shapes=shape,negative_isolation_controls=controls,whole_game_acceptance=False)
(Q/'ISOLATION-AND-CIL-SPEC.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());(Q/'METHOD-CIL.json').write_bytes((json.dumps(dict(types=cil['types'],methods=[methods[rid] for rid in sorted(targets)]),indent=2)+'\n').encode());print(json.dumps({k:v for k,v in result.items() if k not in ['methods','cil_shapes']},indent=2))
