from pathlib import Path
import json,random
Q=Path(__file__).resolve().parent;O=Q/'runtime-results';O.mkdir(exist_ok=True);cases=[]
def add(**v):cases.append(dict(name=f"case-{len(cases):04d}",id=0,x=0,y=0,z=0,hovering=False,**v))
ids=[-2147483648,-123456,-2,-1,0,1,2,3,7,16,99,255,65536,2147483647]
for k in ['prop-drop','prop-cancel','prop-fold']:
    for mode in ['none','select-mutates-id','select-replaces-list','active-mutates-id','active-replaces-list']:
        for value in ids:
            row=dict(name=f'case-{len(cases):04d}',kind=k,mode=mode,id=value,x=0,y=0,z=0,hovering=False);cases.append(row)
rng=random.Random(20261025);seeds=[(0,0,0),(-1,-1,-1),(-2147483648,2147483647,-2),(2147483647,-2147483648,1)]+[tuple(rng.randint(-2147483648,2147483647) for _ in range(3)) for _ in range(16)]
for k in ['selector-a','selector-b']:
    for mode in ['none','base-mutates-middle','base-mutates-last']:
        for s in seeds:
            for hover in [False,True]:cases.append(dict(name=f'case-{len(cases):04d}',kind=k,mode=mode,id=0,x=s[0],y=s[1],z=s[2],hovering=hover))
(O/'CASES.json').write_bytes((json.dumps(cases,indent=2)+'\n').encode());print('CASES',len(cases))
