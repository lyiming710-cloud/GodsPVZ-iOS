"""Original PC five complete callers; only Select, SetActive and base ctor stubbed.
No native null throws or SEH are executed; managed null controls are separate.
"""
from pathlib import Path
import ctypes as C,json,sys
Q=Path(__file__).resolve().parent;sys.dont_write_bytecode=True;sys.path.insert(0,str(Q.parent/'startup-r5'))
from native_runtime_common import *
im=NativeImage();state={};rows=[]
def actor(id_):
    p=im.alloc(64);state['actors'][p]=dict(id=id_,active=True);return p
def select(owner,choice,id_,method):
    assert owner==state['owner'] and not choice and not method;state['trace'].append('Select:'+str(id_));mode=state['case']['mode']
    if mode=='select-mutates-id':put32(owner+0x48,99)
    if mode=='select-replaces-list':put64(owner+0x30,actor('list-new'))
def active(p,value,method):
    assert not method;state['trace'].append(f"Active:{state['actors'][p]['id']}:{int(value)}:{get32(state['owner']+0x48)}");state['actors'][p]['active']=bool(value);mode=state['case']['mode']
    if mode=='active-mutates-id':put32(state['owner']+0x48,17)
    if mode=='active-replaces-list':put64(state['owner']+0x30,actor('list-new'))
def base_ctor(p,method):
    assert p==state['owner'] and not method;c=state['case'];a=c['kind']=='selector-a';offset=0x34 if a else 0x54;label='A' if a else 'B';state['trace'].append(f'Base:{label}:{get32(p+offset)}:{get32(p+offset+4)}:{get32(p+offset+8)}')
    if c['mode']=='base-mutates-middle':put32(p+offset+4,71)
    if c['mode']=='base-mutates-last':put32(p+offset+8,-73)
def reject(*args):raise AssertionError('Native throw is outside normal-object oracle')
try:
    cfgs={rid:json.loads((Q/f'{rid:04X}.native.json').read_bytes()) for rid in [0x694,0x695,0x696,0x7c4,0x7cf]}
    for rid,cfg in cfgs.items():im.verify_caller(rid,int(cfg['entry'],16),cfg)
    im.hook(0x1803a8b40,None,[P,P,I,P],select);im.hook(0x18131bad0,None,[P,C.c_bool,P],active);im.hook(0x1812e22a0,None,[P,P],base_ctor);im.hook(0x180250150,None,[P],reject)
    for rid,cfg in cfgs.items():im.verify_caller(rid,int(cfg['entry'],16),cfg)
    functions={k:C.CFUNCTYPE(None,P,P)(int(cfgs[rid]['entry'],16)) for k,rid in [('prop-drop',0x694),('prop-cancel',0x695),('prop-fold',0x696),('selector-a',0x7c4),('selector-b',0x7cf)]}
    for c in json.loads(Path(sys.argv[1]).read_bytes()):
        state.clear();state.update(case=c,actors={},trace=[]);p=im.alloc(256);state['owner']=p;k=c['kind']
        if k.startswith('prop-'):
            original=actor('list');put32(p+0x48,c['id']);put64(p+0x30,original);functions[k](p,None);current=state['actors'][get64(p+0x30)];after=dict(id=get32(p+0x48),list_id=current['id'],list_active=current['active'],original_active=state['actors'][original]['active'])
        else:
            offset=0x34 if k=='selector-a' else 0x54
            for delta,value in zip([0,4,8],[c['x'],c['y'],c['z']]):put32(p+offset+delta,value)
            C.c_ubyte.from_address(p+offset-4).value=c['hovering'];functions[k](p,None);after=dict(x=get32(p+offset),y=get32(p+offset+4),z=get32(p+offset+8),hovering=bool(C.c_ubyte.from_address(p+offset-4).value))
        assert not im.errors,im.errors;rows.append(dict(name=c['name'],kind=k,trace=list(state['trace']),state=after,error=None))
    result=dict(scope='ORIGINAL_PC_CALLERS_CONTROLLED_SELECT_SETACTIVE_AND_MONOBEHAVIOUR_BASE_CTOR',original_sha256=PC_SHA,original_caller_bytes_rechecked_after_hooks=True,callback_errors=im.errors,native_exception_execution=False,real_unity_callees=False,results=rows);Path(sys.argv[2]).write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(dict(cases=len(rows))))
finally:im.close()
