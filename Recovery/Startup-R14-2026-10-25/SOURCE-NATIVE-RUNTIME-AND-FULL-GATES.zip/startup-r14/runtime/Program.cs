using System.Reflection;using System.Runtime.CompilerServices;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public class ChoiceState{}
public class GameObjectState(string id){public string Id=id;public bool Active=true;public void SetActive(bool value){Program.Trace.Add($"Active:{Id}:{(value?1:0)}:{Program.Prop.currentPropBankID}");Active=value;if(Program.Current.mode=="active-mutates-id")Program.Prop.currentPropBankID=17;if(Program.Current.mode=="active-replaces-list")Program.Prop.prop_ChooseList_GameObject=new("list-new");}}
public class PropState
{
    public int currentPropBankID;public GameObjectState? prop_ChooseList_GameObject;
    public void Select(ChoiceState? choice,int id){if(choice!=null)throw new Exception("Unexpected non-null choice");Program.Trace.Add("Select:"+id);if(Program.Current.mode=="select-mutates-id")currentPropBankID=99;if(Program.Current.mode=="select-replaces-list")prop_ChooseList_GameObject=new("list-new");if(Program.Current.mode=="select-clears-list")prop_ChooseList_GameObject=null;}
}
public class BaseState{public BaseState(){Program.BaseConstruct(this);}}
public class SelectorA:BaseState{public int m_selectedLink,m_lastCharIndex,m_lastWordIndex;public bool isHoveringObject;}
public class SelectorB:BaseState{public int m_selectedWord,m_selectedLink,m_lastIndex;public bool isHoveringObject;}
public class Case{public string name{get;set;}="";public string kind{get;set;}="";public string mode{get;set;}="none";public int id{get;set;}public int x{get;set;}public int y{get;set;}public int z{get;set;}public bool hovering{get;set;}}
public static class Program
{
    public static Case Current=new();public static List<string> Trace=[];public static PropState Prop=new();
    public static void BaseConstruct(BaseState s)
    {
        if(s is SelectorA a){Trace.Add($"Base:A:{a.m_selectedLink}:{a.m_lastCharIndex}:{a.m_lastWordIndex}");if(Current.mode=="base-mutates-middle")a.m_lastCharIndex=71;if(Current.mode=="base-mutates-last")a.m_lastWordIndex=-73;}
        else if(s is SelectorB b){Trace.Add($"Base:B:{b.m_selectedWord}:{b.m_selectedLink}:{b.m_lastIndex}");if(Current.mode=="base-mutates-middle")b.m_selectedLink=71;if(Current.mode=="base-mutates-last")b.m_lastIndex=-73;}
        else throw new NotSupportedException(s.GetType().Name);
    }
    static Type Map(MC.TypeReference t)=>t.FullName switch{"System.Void"=>typeof(void),"System.Boolean"=>typeof(bool),"System.Int32"=>typeof(int),"System.Int64"=>typeof(long),"System.Object"=>typeof(object),"PropChooseSystem"=>typeof(PropState),"Prop_Choose"=>typeof(ChoiceState),"UnityEngine.GameObject"=>typeof(GameObjectState),"UnityEngine.MonoBehaviour"=>typeof(BaseState),"TMPro.Examples.TMP_TextSelector_A"=>typeof(SelectorA),"TMPro.Examples.TMP_TextSelector_B"=>typeof(SelectorB),_=>throw new NotSupportedException(t.FullName)};
    static FieldInfo Field(MC.FieldReference f)=>Map(f.DeclaringType).GetField(f.Name,BindingFlags.Public|BindingFlags.Instance|BindingFlags.Static)??throw new NotSupportedException(f.FullName);
    static MethodBase Method(MC.MethodReference m)
    {
        if(m.DeclaringType.FullName=="PropChooseSystem"&&m.Name=="Select")return typeof(PropState).GetMethod("Select")!;
        if(m.DeclaringType.FullName=="UnityEngine.GameObject"&&m.Name=="SetActive")return typeof(GameObjectState).GetMethod("SetActive")!;
        if(m.DeclaringType.FullName=="UnityEngine.MonoBehaviour"&&m.Name==".ctor")return typeof(BaseState).GetConstructor(Type.EmptyTypes)!;
        throw new NotSupportedException(m.FullName);
    }
    public static void Main(string[] args)
    {
        using var m=MC.ModuleDefinition.ReadModule(args[0]);Action<T> Emit<T>(int t)=>ActualCil.Emit((MC.MethodDefinition)m.LookupToken(t),Map,Field,Method).CreateDelegate<Action<T>>();
        var drop=Emit<PropState>(0x06000694);var cancel=Emit<PropState>(0x06000695);var fold=Emit<PropState>(0x06000696);var a=Emit<SelectorA>(0x060007C4);var b=Emit<SelectorB>(0x060007CF);var rows=new List<object>();
        foreach(var c in JsonSerializer.Deserialize<List<Case>>(File.ReadAllText(args[1]))!)
        {
            Current=c;Trace=[];object? state=null;string? error=null;
            try
            {
                if(c.kind.StartsWith("prop-")){var original=new GameObjectState("list");Prop=new(){currentPropBankID=c.id,prop_ChooseList_GameObject=original};switch(c.kind){case "prop-drop":drop(Prop);break;case "prop-cancel":cancel(Prop);break;case "prop-fold":fold(Prop);break;default:throw new Exception(c.kind);}state=new{id=Prop.currentPropBankID,list_id=Prop.prop_ChooseList_GameObject?.Id,list_active=Prop.prop_ChooseList_GameObject?.Active,original_active=original.Active};}
                else if(c.kind=="selector-a"){var x=(SelectorA)RuntimeHelpers.GetUninitializedObject(typeof(SelectorA));x.m_selectedLink=c.x;x.m_lastCharIndex=c.y;x.m_lastWordIndex=c.z;x.isHoveringObject=c.hovering;a(x);state=new{x=x.m_selectedLink,y=x.m_lastCharIndex,z=x.m_lastWordIndex,hovering=x.isHoveringObject};}
                else if(c.kind=="selector-b"){var x=(SelectorB)RuntimeHelpers.GetUninitializedObject(typeof(SelectorB));x.m_selectedWord=c.x;x.m_selectedLink=c.y;x.m_lastIndex=c.z;x.isHoveringObject=c.hovering;b(x);state=new{x=x.m_selectedWord,y=x.m_selectedLink,z=x.m_lastIndex,hovering=x.isHoveringObject};}
                else throw new Exception(c.kind);
            }catch(Exception e){error=e.GetType().FullName;}
            rows.Add(new{name=c.name,kind=c.kind,trace=Trace.ToArray(),state,error});
        }
        var nulls=new List<object>();foreach(var kind in new[]{"prop-drop","prop-cancel","prop-fold"}){Current=new();Trace=[];Prop=new(){currentPropBankID=123,prop_ChooseList_GameObject=null};string? error=null;try{if(kind=="prop-drop")drop(Prop);else if(kind=="prop-cancel")cancel(Prop);else fold(Prop);}catch(Exception e){error=e.GetType().FullName;}nulls.Add(new{kind,error,id=Prop.currentPropBankID,trace=Trace.ToArray()});}
        var report=new{scope="FIVE_COMPLETE_ACTUAL_CIL_CALLERS_CONTROLLED_SELECT_SETACTIVE_AND_BASE_CTOR",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),all_source_instructions_emitted=true,results=rows,managed_null_controls=nulls,unity_execution=false};File.WriteAllText(args[2],JsonSerializer.Serialize(report,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{cases=rows.Count}));
    }
}
