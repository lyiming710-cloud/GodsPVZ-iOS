from pathlib import Path
import collections,hashlib,importlib.util,json,struct,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];O=Q/'runtime-results';sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
raw=(Q/'candidate1.dll').read_bytes();digest=hashlib.sha256(raw).hexdigest();assert digest=='9b53867fb47378190f147f9b474ed24525b15dde44ce753143e56934aaf2c491';dot=ROOT/'.local/dotnet10/dotnet.exe';fixture=Q/'runtime/bin/Release/net10.0/Fixture.dll'
a=json.loads((O/'NATIVE.json').read_bytes())['results'];cil=json.loads((O/'ACTUAL-CIL.json').read_bytes());b=cil['results'];assert cil['candidate_sha256']==digest and len(a)==len(b)==450
diff=[dict(native=x,cil=y) for x,y in zip(a,b) if x!=y];(O/'BASELINE.json').write_bytes((json.dumps(dict(cases=len(a),differences=diff),indent=2)+'\n').encode());assert not diff,diff[:3]
expected=[dict(kind=k,error='System.NullReferenceException',id=-1,trace=['Select:123'] if k=='prop-drop' else []) for k in ['prop-drop','prop-cancel','prop-fold']];assert cil['managed_null_controls']==expected,cil['managed_null_controls']
pe=dnfile.dnPE(data=raw)
def body(data,rid):
    at=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[rid-1].Rva);assert data[at]&3==3;h=(struct.unpack_from('<H',data,at)[0]>>12)*4;n=struct.unpack_from('<I',data,at+4)[0];return at,h,data[at+h:at+h+n]
mutants={}
def replace(name,rid,code):
    out=bytearray(raw);at,h,old=body(raw,rid);assert len(code)<=struct.unpack_from('<I',(W/'startup-r13/candidate1.dll').read_bytes(),at+4)[0];out[at+h:at+h+len(code)]=code;struct.pack_into('<I',out,at+4,len(code));mutants[name]=bytes(out)
for rid,label in [(0x7c4,'a'),(0x7cf,'b')]:
    at,h,code=body(raw,rid);assert len(code)==28 and code[7:9]==bytes.fromhex('0215')
    replace('selector-'+label+'-missing-middle',rid,code[:7]+b'\0'*7+code[14:])
    replace('selector-'+label+'-first-zero',rid,code[:1]+b'\x16'+code[2:])
    replace('selector-'+label+'-omitted-base-call',rid,code[:21]+b'\0'*6+b'\x2a')
    replace('selector-'+label+'-base-before-fields',rid,code[21:27]+code[:21]+b'\x2a')
for rid,label in [(0x694,'drop'),(0x695,'cancel'),(0x696,'fold')]:
    at,h,code=body(raw,rid);offset=20 if rid==0x694 else 1;assert code[offset]==0x15;replace('prop-'+label+'-reset-zero',rid,code[:offset]+b'\x16'+code[offset+1:])
    active_offset=26 if rid==0x694 else 13;assert code[active_offset]==0x16;replace('prop-'+label+'-activate-instead-of-hide',rid,code[:active_offset]+b'\x17'+code[active_offset+1:])
    prefix=code[:13] if rid==0x694 else b'';reset=bytes.fromhex('02157d9e080004');go=bytes.fromhex('027b9b080004166f0700000a');replace('prop-'+label+'-reset-after-active',rid,prefix+go+reset+b'\x2a')
at,h,code=body(raw,0x694);replace('prop-drop-wrong-select-id',0x694,code[:2]+b'\x16'+b'\0'*5+code[8:]);replace('prop-drop-omitted-select',0x694,b'\0'*13+code[13:])
# Restore the exact historical width-damaged body as a physical width control.
parent=(W/'startup-r13/candidate1.dll').read_bytes();replace('prop-cancel-parent-int64-reset',0x695,body(parent,0x695)[2])
controls=[]
for name,data in mutants.items():
    dll=O/(name+'.dll');dll.write_bytes(data);p=subprocess.run([str(dot),str(fixture),str(dll),str(O/'CASES.json'),str(O/(name+'.json'))],capture_output=True,timeout=30);(O/(name+'.stdout.log')).write_bytes(p.stdout);(O/(name+'.stderr.log')).write_bytes(p.stderr)
    count=None
    if p.returncode==0:
        out=json.loads((O/(name+'.json')).read_bytes());assert out['candidate_sha256']==hashlib.sha256(data).hexdigest();count=sum(x!=y for x,y in zip(a,out['results']));assert len(out['results'])==450
    row=dict(name=name,mutant_sha256=hashlib.sha256(data).hexdigest(),runtime_exit=p.returncode,runtime_differences=count)
    if name=='prop-cancel-parent-int64-reset':
        exp=ROOT/'audit/bulk250-r1-evidence-39702928368/bulk250-r1-run/tools_bin/CilExporter/bin/CilExporter.dll';sup=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support';out=O/'WIDTH-MUTANT-CIL.json';e=subprocess.run([str(dot),str(exp),str(dll),str(out),str(sup),'0x06000695'],capture_output=True);assert e.returncode==0
        f=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py';assert hashlib.sha256(f.read_bytes()).hexdigest()=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14';s=importlib.util.spec_from_file_location('unchanged_frozen',f);v=importlib.util.module_from_spec(s);s.loader.exec_module(v);c=json.loads(out.read_text('utf-8-sig'))
        try:r=v.verify(c['methods'][0],c['types'])
        except Exception as err:r=dict(status='FAIL_OR_UNSUPPORTED',error=str(err))
        assert r['status']!='PASS' and 'I8' in r['error'];row.update(runtime_alone_adequate=False,frozen_width_rejected=True,frozen_result=r)
    else:assert count and count>0,row
    controls.append(row)
result=dict(scope='FIVE_COMPLETE_ORIGINAL_PC_CALLERS_VS_ACTUAL_CANDIDATE_CIL_CONTROLLED_CALLEES',candidate_sha256=digest,pass_=True,cases=450,counts=dict(collections.Counter(r['kind'] for r in a)),differences=[],negative_controls=controls,managed_null_controls=expected,original_caller_bytes_preserved=True,real_unity_callees=False,real_select_side_effects=False,native_null_throw_and_seh=False,full_game_acceptance=False,ipa=None);(O/'RESULT.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in result.items() if k not in ['negative_controls','managed_null_controls']},indent=2));print('Physical controls:',len(controls))
