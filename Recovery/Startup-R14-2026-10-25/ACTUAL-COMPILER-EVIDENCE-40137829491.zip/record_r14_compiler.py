"""Independently stream every generated source and read raw GHA evidence.
The staged-input identity is a raw runner-manifest readback, not a returned DLL.
"""
from pathlib import Path,PurePosixPath
import json,tarfile
from archive_support import sha,js,pack,manifest
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';D=R/'Recovery/Startup-R14-2026-10-25';A=W/'r14-compiler-run-40137829491';Q=A/'startup-r14';expected='9b53867fb47378190f147f9b474ed24525b15dde44ce753143e56934aaf2c491';run=40137829491
report=json.loads((Q/'STARTUP-R14-COMPILER-REPORT.json').read_bytes());assert report['candidate_sha256']==expected and report['pass'] and report['conversion']['exit_code']==0
rows=json.loads((Q/'ALL-CPP-RESULTS.json').read_bytes())+json.loads((Q/'ALL-C-RESULTS.json').read_bytes());files={r['file']:r for r in rows};assert len(files)==1030 and report['cpp']['attempted']==report['cpp']['passed']==756 and report['c']['attempted']==274 and report['cpp']['failed']==report['c']['failed']==0
found={}
with tarfile.open(A/'startup-r14-generated.tar.gz','r|gz') as t:
    for m in t:
        p=PurePosixPath(m.name);assert '..' not in p.parts and not p.is_absolute()
        if not m.isfile() or not m.name.startswith('il2cppOutput/cpp/'):continue
        assert p.name in files and p.name not in found and p.suffix in ['.cpp','.c'];data=t.extractfile(m).read();row=files[p.name];assert len(data)==row['bytes'] and sha(data)==row['sha256'] and row['exit_code']==row['error_count']==0
        found[p.name]=dict(file=m.name,bytes=len(data),sha256=sha(data))
assert set(found)==set(files)
staged=[];items=[];returned_dlls=[]
with tarfile.open(A/'startup-r14-evidence.tar.gz','r|gz') as t:
    for m in t:
        p=PurePosixPath(m.name);assert '..' not in p.parts and not p.is_absolute()
        if not m.isfile():continue
        data=t.extractfile(m).read()
        if p.suffix=='.dll':returned_dlls.append(dict(file=m.name,bytes=len(data),sha256=sha(data)))
        if m.name.endswith('COHERENT-PLAYER-INPUT-ASSEMBLIES.json'):
            value=json.loads(data);row=next(r for r in value['files'] if r['name']=='GodsPVZRuntime1.dll');staged.append(dict(path=m.name,sha256=row['sha256'],bytes=row['bytes'],assemblies=value['count']))
        items.append((m.name.lstrip('./'),data))
assert any(r['sha256']==expected and r['bytes']==20166656 and '/candidate/' in r['path'] for r in staged)
assert any(r['sha256']=='ef1992326d1ee494a389bc2c78bdfab131721434c0b08ab5f41dbc3e506c4e48' for r in staged)
damaged=report['damaged_r4_control'];assert sum(r['error_count'] for r in damaged['units'])==37 and all(r['exit_code']!=0 for r in damaged['units'])
assert len(report['compiler_controls'])==6 and all((r['exit_code']!=0)==r['expected_nonzero'] for r in report['compiler_controls'])
for p in sorted(Q.glob('*.json')):items.append(('top-level/'+p.name,p.read_bytes()))
items.append(('startup-r14-restore-receipt.json',(A/'startup-r14-restore-receipt.json').read_bytes()));items.append(('record_r14_compiler.py',Path(__file__).read_bytes()));pack(D/'ACTUAL-COMPILER-EVIDENCE-40137829491.zip',items)
result=dict(scope='ACTUAL_R14_FRESH_IL2CPP_AND_ALL_GENERATED_SOURCES_LINUX_SYNTAX_ONLY',run_id=run,url=f'https://github.com/lyiming710-cloud/GodsPVZ-iOS/actions/runs/{run}',source_commit='5d2481743b1b96658faae6ceaf1d2ef549d4181a',candidate_sha256=expected,pass_=True,conversion=report['conversion'],cpp=report['cpp'],c=report['c'],compiler_controls=report['compiler_controls'],damaged_r4_errors=37,raw_generated_sources_rehashed=1030,source_rows=[found[k] for k in sorted(found)],raw_staged_manifest_readbacks=staged,staged_physical_dlls_returned=returned_dlls,staged_dll_identity_evidence='RUNNER_MANIFEST_READBACK_NOT_PHYSICAL_STAGED_DLL_DOWNLOAD',downloaded_archives=[dict(file=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in A.glob('*.tar.gz')],unity_editor=False,apple_compiler=False,linking=False,ipa=None)
js(D/'ACTUAL-COMPILER-40137829491.json',result)
status=json.loads((D/'CURRENT-RESULT.json').read_bytes());assert status['r14_il2cpp']=='NOT_RUN';status['r14_il2cpp']='PASS_FRESH_LINUX_COMPILER_ONLY_RUN_40137829491';status['r14_linux_all_sources']=dict(cpp=756,c=274,failed=0,independently_rehashed=1030);js(D/'CURRENT-RESULT.json',status)
marker='## Actual compiler readback: run 40137829491';p=D/'README.md';text=p.read_text('utf-8');assert marker not in text;text+='\n'+marker+'\n\nExact source commit `5d2481743b1b96658faae6ceaf1d2ef549d4181a` completed fresh R14 IL2CPP conversion and Linux syntax checks for all 756 C++ and 274 C files. Downloaded generated archive was streamed independently: every one of the 1,030 source sizes and hashes matches its zero-error compiler record. The raw runner input manifests identify candidate GodsPVZRuntime1 as the exact R14 hash and 20,166,656 bytes; those manifests are returned, not the physical staged DLL. Fresh historical R4 control still produces 37 errors, and all six C/C++ controls meet expectations. Full raw reports/logs and archive identities are retained. This is license-free Linux compiler evidence; no R14 Unity Editor, Apple compiler, player link, IPA or device acceptance is claimed. Wider gates remain held.\n';p.write_bytes(text.encode());manifest(D)
print(json.dumps(dict(run_id=run,pass_=True,cpp=756,c=274,source_hashes_rechecked=1030,staged_input_manifest_readbacks=len(staged),physical_staged_dlls_returned=len(returned_dlls),damaged_control_errors=37,ipa=None)))
