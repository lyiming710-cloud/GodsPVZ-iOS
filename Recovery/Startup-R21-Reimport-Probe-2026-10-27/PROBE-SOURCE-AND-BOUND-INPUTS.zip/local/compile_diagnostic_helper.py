"""Compile the diagnostic helper against hash-bound actual Editor modules."""
from pathlib import Path
import hashlib,json,subprocess
Q=Path(__file__).resolve().parent;W=Q.parent;R=W.parents[1]
src=R/'audit/repo-native113/scripts/actions/GodsPVZInteractionAudit.cs'
sources=[src,R/'audit/repo-native113/scripts/actions/GodsPVZSerializedReferenceProbe.cs']
r=R/'audit/local-preflight/exact-editor-tools/resolver';a=r.parent/'aot-resolver'
refs=[a/n for n in ['mscorlib.dll','System.dll','System.Core.dll','netstandard.dll']]
refs += [r/n for n in ['UnityEditor.CoreModule.dll','UnityEngine.CoreModule.dll','UnityEngine.UIModule.dll','UnityEngine.JSONSerializeModule.dll']]
known={Path(row['path']).name:row['sha256'] for row in json.loads((W/'asset-audit-40081048209/HELPER-COMPILATION.json').read_bytes())['references']}
for p in refs[4:]:assert hashlib.sha256(p.read_bytes()).hexdigest()==known[p.name],p.name
stem='INTERACTION-HELPER-API';i=1
while (Q/(stem+'.json')).exists():stem='INTERACTION-HELPER-API-'+str(i);i+=1
cmd=[str(R/'.local/dotnet10/dotnet.exe'),str(R/'.local/dotnet10/sdk/10.0.402/Roslyn/bincore/csc.dll'),'/noconfig','/nostdlib','/target:library','/langversion:9.0','/utf8output','/preferreduilang:en-US','/define:UNITY_EDITOR','/out:'+str(Q/(stem+'.dll'))]+['/r:'+str(p) for p in refs]+[str(p) for p in sources]
p=subprocess.run(cmd,capture_output=True);(Q/(stem+'.log')).write_bytes(p.stdout+p.stderr)
j=dict(scope='DIAGNOSTIC_HELPER_API_COMPILATION_ONLY_NO_GAME_EXECUTION',exit=p.returncode,source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),sources=[dict(file=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sources],references=[dict(file=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in refs],unity_started=False,game_changed=False)
(Q/(stem+'.json')).write_bytes((json.dumps(j,indent=2)+'\n').encode());print((p.stdout+p.stderr).decode('utf-8',errors='replace'));print(json.dumps(j));raise SystemExit(p.returncode)
