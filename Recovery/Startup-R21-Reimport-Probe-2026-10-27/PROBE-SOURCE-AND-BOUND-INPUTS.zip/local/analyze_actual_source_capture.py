"""Verify captured raw sources and compare the ordered audio source list, read-only."""
from pathlib import Path,PurePosixPath
import collections,hashlib,json,re,sys,zipfile
Q=Path(__file__).resolve().parent;W=Q.parent;A=W/'r21-source-run-40368892424';capture=json.loads((A/'r21-source-data-capture.json').read_bytes());archive=A/capture['archive'];assert len(archive.read_bytes())==capture['bytes'] and hashlib.sha256(archive.read_bytes()).hexdigest()==capture['sha256'];original=json.loads((Q/'ORIGINAL-ZOMBIE-MANAGER-AUDIO-PLAN.json').read_bytes());graph=[];callbacks=[]
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None;rows=json.loads(z.read('MANIFEST.json'));assert len(rows)==576 and len({r['file'] for r in rows})==576
 for row in rows:
  name=PurePosixPath(row['file']);assert not name.is_absolute() and '..' not in name.parts;b=z.read(row['file']);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
 audio=json.loads(z.read('AUDIO-SOURCE-INVENTORY.json'));byguid={r['guid']:r for r in audio};assert len(byguid)==len(audio)==199
 for r in audio:
  meta=z.read(r['file']+'.meta');assert hashlib.sha256(meta).hexdigest()==r['meta_sha256'] and re.findall(rb'(?m)^guid: ([0-9a-f]{32})\s*$',meta)==[r['guid'].encode()]
 source=next(n for n in z.namelist() if n.endswith('/ZombieManager.prefab'));text=z.read(source).decode();match=re.search(r'(?m)^  audioClip_zombie:\r?\n((?:  -[^\r\n]*\r?\n)+)',text);assert match;values=re.findall(r'(?m)^  - \{fileID: (-?\d+)(?:, guid: ([0-9a-f]{32}), type: 3)?\}',match[1]);assert len(values)==76;ordered=[]
 for item,(fid,guid) in zip(original['items'],values):
  if item['null']:assert int(fid)==0 and not guid;ordered.append(None)
  else:assert int(fid)==8300000 and guid in byguid and byguid[guid]['basename']==item['name'];ordered.append(item['name'])
 for n in z.namelist():
  if not n.endswith(('.prefab','.unity')):continue
  t=z.read(n).decode('utf-8');ids={int(x) for x in re.findall(r'(?m)^--- !u!\d+ &(-?\d+)',t)};bad=[]
  for m in re.finditer(r'\{fileID: (-?\d+)\}',t):
   fid=int(m[1])
   if fid and fid not in ids:bad.append(dict(line=t.count('\n',0,m.start())+1,file_id=fid))
  if bad:graph.append(dict(file=n,dangling_local_references=bad))
  for i,line in enumerate(t.splitlines(),1):
   if 'ButtonDown_Menu' in line:callbacks.append(dict(file=n,line=i,text=line.strip()))
report=dict(scope='ACTUAL_R3_SOURCE_CAPTURE_READBACK_NOT_UNITY_SERIALIZATION_ACCEPTANCE',run=40368892424,source_files_rehashed=576,audio_meta_sources_rehashed=199,archive_sha256=capture['sha256'],zombie_audio_source_count=76,zombie_audio_source_order_matches_original=True,original_null_slots=13,existing_source_list_already_correct=True,source_audio_list_does_not_need_reauthoring=True,ordered_names=ordered,raw_local_reference_graph_findings=graph,menu_callback_source_sites=callbacks,limitations=['A source fileID graph does not prove Unity importer or loaded object resolution.','Audio binary hashes are runner input inventory observations; binaries were not returned in this small source archive.','Other raw slot/layout differences remain discovery leads.'],game_data_changed=False)
(Q/'ACTUAL-SOURCE-CAPTURE-READBACK.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in report.items() if k not in ['ordered_names','raw_local_reference_graph_findings','limitations']},ensure_ascii=True));print('files with dangling local refs',len(graph))
