"""Same candidate, bounded cache-import experiment with actual before/after records."""
from pathlib import Path
import ast,json,sys
Q=Path(__file__).resolve().parent;W=Q.parent;R=W.parents[1]/'audit/repo-native113';sys.path.insert(0,str(W));from archive_support import js,pack,manifest,sha
D=R/'Recovery/Startup-R21-Reimport-Probe-2026-10-27';assert not D.exists();D.mkdir();(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text\n*.md -text\n*.zip -text\n*.yml -text\n*.log -text -diff\n')
wf=R/'.github/workflows/bulk401-startup-runtime-gate.yml';old=wf.read_bytes();text=old.decode();start=text.index('      - name: Restore six original serialized zombie-window component references after candidate reimport\n');end=text.index('      - name: Verify every relocated resource GUID, path and original imported name\n',start)
text=text[:start]+'''      - name: Observe real serialized objects and force import original prefabs without editing source bytes
        shell: bash
        env:
          GODSPVZ_STARTUP_EVIDENCE: ${{ runner.temp }}/stage9-startup-r2/evidence
          LIBGL_ALWAYS_SOFTWARE: '1'
        run: |
          set -euo pipefail
          OUT="$RUNNER_TEMP/stage9-startup-r2"
          UNITY="$(cat "$OUT/unity-path.txt")"
          PROJECT="$(cat "$OUT/project-path.txt")"
          cp "$GITHUB_WORKSPACE/scripts/actions/GodsPVZSerializedReferenceProbe.cs" "$PROJECT/Assets/Editor/"
          set +e
          timeout --signal=TERM 600s xvfb-run -a -s '-screen 0 1280x720x24' "$UNITY" -batchmode -quit -force-glcore -projectPath "$PROJECT" -executeMethod GodsPVZSerializedReferenceProbe.Run -logFile "$OUT/evidence/r21-serialization-reimport-probe.log"
          RC=$?
          set -e
          echo "$RC" > "$OUT/evidence/r21-serialization-reimport-probe-exit.txt"
          [ "$RC" -eq 0 ]
          python3 - "$OUT/evidence/r21-serialization-reimport-probe.json" <<'PY'
          import json,sys
          r=json.load(open(sys.argv[1]))
          assert r['candidate_sha256']=='75160a3233f1e1ab13a44f712efb4b47fdeb9b57bd38fa25f180276bb7b50e15'
          assert r['collection_complete'] and r['import_count']>=100 and r['source_bytes_unchanged'] and r['game_dll_unchanged']
          assert not r['source_references_rewritten'] and not r['game_fields_assigned'] and not r['device_execution'] and not r['exceptions']
          print('IMPORT_PROBE_COLLECTED_NO_RESOURCE_OR_GAME_ACCEPTANCE',r['import_count'])
          PY

'''+text[end:]
needle="      TEST_DLL_SHA256: '75160a3233f1e1ab13a44f712efb4b47fdeb9b57bd38fa25f180276bb7b50e15'\n";assert text.count(needle)==1;text=text.replace(needle,needle+'      GODSPVZ_ORIGINAL_AUDIO_PLAN: ${{ github.workspace }}/Recovery/Startup-R21-Actual-UI-2026-10-27/ORIGINAL-ZOMBIE-MANAGER-AUDIO-PLAN.json\n');wf.write_bytes(text.encode())
files=[('previous-workflow.yml',old),('current-workflow.yml',wf.read_bytes())]
for name in ['GodsPVZSerializedReferenceProbe.cs','GodsPVZInteractionAudit.cs','preflight_build_capture_editor.py']:
 p=R/'scripts/actions'/name;files.append(('tools/'+name,p.read_bytes()))
for p in [Q/'compile_diagnostic_helper.py',Q/'ORIGINAL-MENU-SOURCE-PATH.json',Q/'analyze_actual_source_capture.py',Q/'archive_actual_r21_ui.py',Path(__file__)]:files.append(('local/'+p.name,p.read_bytes()))
latest=max(Q.glob('INTERACTION-HELPER-API*.json'),key=lambda p:p.stat().st_mtime);j=json.loads(latest.read_bytes());assert j['exit']==0 and len(j['sources'])==2
for r in j['sources']:assert sha((R/'scripts/actions'/r['file']).read_bytes())==r['sha256']
(D/'EXACT-API-COMPILATION.json').write_bytes(latest.read_bytes());(D/'EXACT-API-COMPILATION.log').write_bytes(latest.with_suffix('.log').read_bytes());pack(D/'PROBE-SOURCE-AND-BOUND-INPUTS.zip',files)
js(D/'PROGRESS.json',dict(status='PREPARED_ACTUAL_SERIALIZATION_OBSERVATION_AND_FORCE_IMPORT_EXPERIMENT',candidate_sha256='75160a3233f1e1ab13a44f712efb4b47fdeb9b57bd38fa25f180276bb7b50e15',game_dll_changed=False,new_method_changes=0,source_value_rewrites=0,cache_hypothesis_confirmed=False,actual_probe='NOT_RUN',actual_ui='NOT_RUN_AFTER_FORCE_IMPORT',ipa=None,ipad_acceptance=False))
(D/'README.md').write_bytes('''# R21 序列化/重新导入观察实验（同一游戏DLL）

实际run40365525028已证明选卡/确认恢复，但图鉴仍失败。source-only run40368892424进一步逐项确认：ZombieWindow六个引用和ZombieManager的76个音频槽位（63音频+13空槽）在源YAML本来正确，全部预制体/场景本地fileID图未发现悬空引用；2,802个游戏字段声明类型与原版一致。因此停止重写正确源引用，转查导入/对象加载。

新Editor-only probe在强制重新导入之前/之后，分别通过AssetDatabase和Resources加载同一ZombieWindow、ZombieManager和Sunflower。记录实际程序集位置、类型/属性、MonoScript.GetClass、Reflection字段值、SerializedObject属性路径和对象/数组值、每个对象实际GUID/local fileID和EditorJsonUtility原始输出。再ForceUpdate+ForceSynchronousImport全部原有prefab/scene，记录每个路径和完整Assets前后SHA；任何源字节或游戏DLL变化、异常/收集不全都会拒绝该实验。不会SetValue/改SerializedProperty/SaveAssets/保存预制体/赋值游戏字段或替换方法。

“收集完成”仅说明执行和字节边界，不代表资源值恢复或缓存假设成立。后续实际交互另行断言六个引用、76音频顺序、选卡/确认、图鉴、菜单。菜单目标改用已读源中的Adventure/Windows/Button/MenuButton，源回调确为Board.ButtonDown_Menu；等待真实gameStart或开场对话启动，再推进实际对话，移除不存在的senarioState观察项。不靠显示文字猜控件，不写游戏状态。

本次仍固定75160a32…7b50e15，原139处/7方法的静态/有限对照与Linux/Apple证明继续按同一DLL身份保留。没有新游戏代码、没有声称额外76槽位已修复；强制导入能否改善要看实际前后结果。helper先通过精确Editor API编译，CI再在许可激活前独立编译；仍仅audit_only=true和interaction_audit=true，失败保存与归还席位原样保留，不导出新IPA。
'''.encode());manifest(D)
for p in [R/'README.md',R/'Recovery/STATUS.md']:
 t=p.read_text('utf-8');note='R21 actual Editor UI run 40365525028: selection and confirmation pass, Board public menu callback works, but almanac references/Plant.animationGroup still fail. Original source bindings and 76 audio slots are already correct; [serialization/import investigation]('+('Recovery/' if p.name=='README.md' else '')+D.name+'/README.md) is prepared with the same DLL. No new IPA or iPad acceptance.\n\n'
 at=t.index('\n')+1;t=t[:at]+'\n'+note+t[at:];p.write_bytes(t.encode())
print(json.dumps(dict(checkpoint=D.name,game_dll_changed=False,probe_prepared=True)))
