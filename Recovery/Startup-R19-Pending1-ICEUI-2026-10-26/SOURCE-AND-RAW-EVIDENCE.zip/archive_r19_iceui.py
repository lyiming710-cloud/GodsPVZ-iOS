"""Record the existing ICEUI.Update caller's finite profile and two physical faults."""
from pathlib import Path
import json
from archive_support import sha,js,pack,manifest,variants
W=Path(__file__).resolve().parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113';Q=W/'r19-pending-iceui-update-2026-10-26';D=R/'Recovery/Startup-R19-Pending1-ICEUI-2026-10-26';H=R/'Recovery/Startup-R19-Batch100-2026-10-25';T=R/'Recovery/Startup-R20-Sites104-2026-10-26'
assert not D.exists();D.mkdir();(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text\n*.md -text\n*.zip -text\n')
n=json.loads((Q/'NATIVE-ATTEMPT1.json').read_bytes());c=json.loads((Q/'controls/RESULT.json').read_bytes());binding=json.loads((Q/'R19-AND-R20-BINDING.json').read_bytes())
assert n['normal_records']==5040 and n['caller_bytes_verified']==1 and not n['differences'] and not n['callback_errors']
assert c['controls']==c['detected']==2 and c['process_failures']==0 and binding['all_rows_identical']
current=(W/'startup-r20-sites100/authored3.dll').read_bytes();parent=(W/'startup-r19-batch100/candidate9.dll').read_bytes();assert sha(current)==binding['current_sha256'] and sha(parent)==binding['parent_sha256']
assert sha((W/'startup-r5/runtime-common/Rehost.cs').read_bytes())=='59b1e80892d0038ee188f0ef36d1af25ce37ae6df71016ba6617cc221ca51d40'
delta=variants(Q/'controls',current);assert len(delta)==2;js(Q/'PHYSICAL-CONTROL-DELTAS.json',delta)
for p,name in [(Q/'NATIVE-ATTEMPT1.json','NATIVE.json'),(Q/'R19-AND-R20-BINDING.json','R19-AND-R20-BINDING.json'),(Q/'controls/RESULT.json','CONTROLS.json'),(Q/'PHYSICAL-CONTROL-DELTAS.json','PHYSICAL-CONTROL-DELTAS.json')]:(D/name).write_bytes(p.read_bytes())
files=[]
for p in sorted(Q.rglob('*')):
    if not p.is_file() or any(x in p.parts for x in ['obj','__pycache__']):continue
    if p.suffix=='.dll' and 'bin' not in p.parts:continue
    files.append(('iceui-profile/'+p.relative_to(Q).as_posix(),p.read_bytes()))
token='0x06000342'
for suffix in ['.txt','.json']:
    p=W/'startup-r19-batch100/native-source-complete'/(token+suffix);files.append(('original-native/'+p.name,p.read_bytes()))
cil=json.loads((W/'startup-r20-sites100/shared-authored3/ALL-CIL.json').read_bytes());m=next(m for m in cil['methods'] if m['token']==token);files.append(('current-cil/'+token+'.json',(json.dumps(m,indent=2)+'\n').encode()))
files += [('frozen-runtime/Rehost.cs',(W/'startup-r5/runtime-common/Rehost.cs').read_bytes()),('frozen-runtime/native_runtime_common.py',(W/'startup-r5/native_runtime_common.py').read_bytes()),(Path(__file__).name,Path(__file__).read_bytes())];pack(D/'SOURCE-AND-RAW-EVIDENCE.zip',files)
pending=json.loads((H/'CURRENT-PENDING-RUNTIME-PROFILES.json').read_bytes());assert pending['methods']==20;remaining=[r for r in pending['rows'] if r['token']!=token];assert len(remaining)==19;pending.update(methods=19,added_supplement='../'+D.name,rows=remaining);js(H/'CURRENT-PENDING-RUNTIME-PROFILES.json',pending)
s=json.loads((H/'PROGRESS.json').read_bytes());assert s['finite_comparison_method_union']==80 and s['total_native_finite_comparison_records']==26772
s.update(status='HUNDRED_CONSTRUCTED_EIGHTY_ONE_FINITE_PROFILES_NINETEEN_PENDING_INCLUDING_TWO_FLOAT_FAILURES',finite_comparison_method_union=81,other_runtime_profile_count=19,total_native_finite_comparison_records=31812,finite_original_native_vs_complete_cil_additional_methods=46,iceui_native_normal_records=5040,iceui_physical_controls=2,iceui_detected_controls=2,total_physical_controls_including_foreach_and_new_profiles=s['total_physical_controls_including_foreach_and_new_profiles']+2,total_runtime_differences_including_supplements=s['total_runtime_differences_including_supplements']+2);js(H/'PROGRESS.json',s)
js(D/'PROGRESS.json',dict(status='ONE_FINITE_ICEUI_FULL_CALLER_PASS_PRODUCT_PENDING',parent_candidate_sha256=sha(parent),current_candidate_sha256=sha(current),new_game_code_changes=0,methods=1,native_normal_records=5040,controls_detected=2,r19_finite_union=81,r19_native_comparison_records=31812,r19_pending_profiles=19,unity=False,ipa=None,ipad_acceptance=False))
(D/'README.md').write_bytes('''# R19 ICEUI.Update 完整调用方补充

0x06000342 Device/ICEUIController.Update(float,float,Device,bool) 的完整未改原版调用方与实际发射的完整候选 CIL，5,040条正常记录0差异，两个固定R19/R20候选全部结果一致。保留原版除法、COMISS、所有分支和while循环，原生Vector3隐藏返回缓冲区与按值/栈参数按真实ABI传递。

覆盖各破损阈值、零分母、NaN/Infinity、初始brokenLevel=-1/0/1/2/Int32.Max、sound开关、返回粒子实际空/伪空/有效，以及Sprite/Particle/Transform getter/AudioVolume/Unity比较回调后替换字段、资源列表和Camera。两个物理故障（sprite5误为6、while终止级别2误为3）分别产生432条正常行为差异，其他方法未变，无进程/异常算检测。完整输入、原生/CLR输出、两个候选重放、源码和故障增量SHA均保存。

Unity/粒子/音频/Camera/伤害终结子方法是受控叶函数，本结果不证明其内部、实际音频/画面、普遍等价或真机。R19有限联合81，正常原版记录31,812，另19个方法profile待验收（包含两处浮点差异方法）。没有新增游戏DLL改动，当前R20新8方法768条的原有范围不变；真实Unity导出的四条BuildReport错误在单独复现中定位，不与此有限profile混为通过。
'''.encode())
p=H/'README.md';v=p.read_text('utf-8');v+='\n## ICEUI.Update补充\n\n[ICEUI完整调用方](../Startup-R19-Pending1-ICEUI-2026-10-26/README.md) 保存5,040条正常原版对照及两个检出的物理故障。R19有限联合81 /31,812条记录，19个profile待完成，包含两处浮点差异方法。\n';p.write_bytes(v.encode())
s=json.loads((T/'PROGRESS.json').read_bytes());s.update(r19_runtime_profiles_still_pending=19,r19_additional_finite_profiles_verified_on_current_r20=16);js(T/'PROGRESS.json',s)
q=json.loads((T/'CURRENT-WORK-QUEUE.json').read_bytes());r=next(r for r in q['rows'] if r['token']==token);r.update(current_state='R19_BODY_FINITE_ICEUI_PROFILE_PASS_BOTH_EXACT_CANDIDATES_PRODUCT_PENDING',r19_runtime_pending=False,normal_native_records=5040,current_required_action='Actual engine/product integration and callee internals remain pending');q.update(other_parent_followup_work_items=132,additional_parent_r19_profiles_completed=16);js(T/'CURRENT-WORK-QUEUE.json',q)
p=R/'README.md';v=p.read_text('utf-8');assert 'Eighty methods now have 26,772' in v;v=v.replace('Eighty methods now have 26,772','Eighty-one methods now have 31,812').replace('Twenty other runtime profiles','Nineteen other runtime profiles').replace('87 physical controls: 83 runtime differences','89 physical controls: 85 runtime differences').replace('R19 now has80 finite profiles/20 pending','R19 now has81 finite profiles/19 pending');p.write_bytes(v.encode())
p=R/'Recovery/STATUS.md';v=p.read_text('utf-8');marker='## Latest checkpoint - 2026-10-26\n';v=v.replace(marker,marker+'\n[ICEUI.Update profile](Startup-R19-Pending1-ICEUI-2026-10-26/README.md) matches5,040 normal original records and detects two physical faults. R19 finite union81 /31,812 normal records,19 profiles pending including two known float differences. No new gameplay DLL changes.\n',1);p.write_bytes(v.encode())
for folder in [D,H,T]:manifest(folder)
print(json.dumps(dict(archived=D.name,native_records=5040,r19_union=81,r19_pending=19,new_game_changes=0)))
