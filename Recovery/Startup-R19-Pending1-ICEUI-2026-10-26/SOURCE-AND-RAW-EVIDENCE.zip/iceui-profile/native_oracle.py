"""Actual original ICEUI.Update, including SSE division and every while/branch."""
from pathlib import Path
import ctypes as C,functools,hashlib,json,struct,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
im=NativeImage();state={};rid=0x342;cfg=json.loads((W/'startup-r19-batch100/native-source-complete/0x06000342.json').read_bytes());fields=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_bytes())
@functools.lru_cache(None)
def off(owner,name):
    rows=[r for r in fields if r['type']==owner and r['namespace']=='' and r['name']==name];assert len(rows)==1,(owner,name);return rows[0]['offset']
def log(s):state['trace'].append(s)
def tag(p):return None if not p else state['tags'][p]
def bits(v):return struct.pack('<f',v)[::-1].hex().upper()
def f(key):return struct.unpack('<f',bytes.fromhex(state['q'][key])[::-1])[0]
def write_vec(p,values):C.memmove(p,b''.join(bytes.fromhex(v)[::-1] for v in values),12)
def vec(p):return ','.join(f'{C.c_uint32.from_address(p+4*k).value:08X}' for k in range(3))
def set_resource(name,p):put64(resource_static+off('ResourceManager',name),p)
def field(name):return state['ice']+off('ICEUIController',name)
def mutate(stage):
    n=state['q']['mode']
    if n==1 and stage=='Sprite':
        put64(field('gameObject'),state['otherRoot']);put64(field('spriteRenderer1'),state['otherR']);set_resource('vfxSprites',state['other-sprites']);set_resource('particleClips',state['other-clips'])
    if n==2 and stage=='Particle':put64(field('gameObject'),state['otherRoot'])
    if n==3 and stage=='GetPosition':state['mainCamera']=state['otherCamera'];set_resource('particleClips',state['other-clips'])
    if n==4 and stage=='Volume':state['mainCamera']=state['otherCamera'];set_resource('particleClips',state['other-clips'])
    if n==5 and stage=='Exists':put64(field('gameObject'),state['otherRoot'])
def array(values):
    p=im.alloc(32+8*len(values));put64(p+0x18,len(values))
    for i,v in enumerate(values):put64(p+0x20+8*i,v)
    return p
def listing(values):
    p=im.alloc(32);put64(p+0x10,array(values));put32(p+0x18,len(values));put32(p+0x1c,0);return p
def list_item(p,index,m):assert m in handles and 0<=index<get32(p+0x18);return get64(get64(p+0x10)+0x20+8*index)
def sprite(p,value,m):assert not m;state['sprites'][p]=tag(value);log('Sprite:'+tag(p)+':'+tag(value));mutate('Sprite')
def broken(p,d,sound,m):assert p==state['ice'] and d==state['device'] and not m;state['broken']+=1;log('Broken:'+tag(d)+':'+str(int(sound)))
def particles(m):assert not m;log('Particles');return state['particles']
def particle(p,kind,m):assert p==state['particles'] and not m;log('Particle:'+tag(p)+':'+str(kind));mutate('Particle');return state['made']
def exists(p,m):assert not m;v=bool(p and state['q']['particle']==1);log('Exists:'+('null' if not p else tag(p))+':'+str(int(v)));mutate('Exists');return v
def transform(p,m):assert not m;log('Transform:'+tag(p));return state['transforms'][p]
def position(out,p,m):
    assert not m;values=state['positions'][p];log('GetPosition:'+tag(p)+':'+','.join(values));mutate('GetPosition');write_vec(out,values);return out
def set_position(p,v,m):assert not m;state['assigned'][p]=vec(v);log('SetPosition:'+tag(p)+':'+vec(v))
def camera(m):assert not m;log('Camera:'+tag(state['mainCamera']));return state['mainCamera']
def volume(m):assert not m;log('Volume:'+state['q']['volume']);mutate('Volume');return f('volume')
def audio(clip,v,value,m):assert not m;log('Audio:'+tag(clip)+':'+vec(v)+':'+bits(value));return state['audio']
try:
    dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True;slots=set();handles=set();rip_slots={}
    for row in cfg['instructions']:
        i=next(dis.disasm(bytes.fromhex(row['bytes']),int(row['va'],16)))
        if i.mnemonic not in ['mov','lea']:continue
        for o in i.operands:
            if o.type!=X86_OP_MEM or o.mem.base!=X86_REG_RIP:continue
            at=i.address+i.size+o.mem.disp;raw=im.pe.get_data(at-im.base,8)
            if len(raw)!=8:continue
            code=int.from_bytes(raw,'little')
            if code>0xffffffff or code>>29 not in range(1,8):continue
            rip_slots[i.address]=at
            if at in slots:continue
            slots.add(at);assert code>>29!=5;handles.add(im.class_slot(at))
    assert rip_slots[0x18034d733]==rip_slots[0x18034d983];resource_slot=rip_slots[0x18034d733];resource_static=im.alloc(1024);put64(get64(resource_slot)+0xb8,resource_static);assert off('ResourceManager','vfxSprites')==0x90 and off('ResourceManager','particleClips')==0x130
    def init(p):assert p in slots
    im.hook(0x18024fef0,None,[P],init);im.hook(0x1802501e0,None,[P],lambda p:None)
    im.hook(0x180825710,P,[P,I,P],list_item);im.hook(0x1813290f0,None,[P,P,P],sprite);im.hook(0x18034d1b0,None,[P,P,C.c_bool,P],broken)
    im.hook(0x1802fb100,P,[P],particles);im.hook(0x180321f30,P,[P,I,P],particle);im.hook(0x18131f870,C.c_bool,[P,P],exists)
    im.hook(0x18131c070,P,[P,P],transform);im.hook(0x181304510,P,[P,P],transform);im.hook(0x18132f3a0,P,[P,P,P],position);im.hook(0x18132fbb0,None,[P,P,P],set_position)
    im.hook(0x1812e27c0,P,[P],camera);im.hook(0x18031aea0,F,[P],volume);im.hook(0x18031b230,P,[P,P,F,P],audio)
    im.verify_caller(rid,int(cfg['entry'],16),cfg);rows=[];cases=json.loads((Q/'CASES.json').read_bytes())
    for q in cases:
        if '--trace-cases' in sys.argv:print(json.dumps(dict(starting_case=q['name'])),flush=True)
        state.clear();state.update(q=q,tags={},trace=[],sprites={},transforms={},positions={},assigned={},broken=0)
        def make(label,size=128):
            p=im.alloc(size);state['tags'][p]=label;return p
        for label in ['ice','device','root','otherRoot','r0','r1','otherR','particle','particles','camera','otherCamera','audio']:state[label]=make(label)
        state['mainCamera']=state['camera'];state['made']=state['particle'] if q['particle'] else 0
        put32(field('brokenLevel'),q['level']);put64(field('gameObject'),state['root']);put64(field('spriteRenderer0'),state['r0']);put64(field('spriteRenderer1'),state['r1'])
        for label in ['r0','r1','otherR']:state['sprites'][state[label]]=None
        for label in ['root','otherRoot','particle','camera','otherCamera']:
            p=make(label+'Transform');state['transforms'][state[label]]=p;values=list(q['position'])
            if label.startswith('other'):
                for i,amount in [(0,100),(1,-100)]:values[i]=bits(struct.unpack('<f',bytes.fromhex(values[i])[::-1])[0]+amount)
            state['positions'][p]=values;state['assigned'][p]=None
        for label,count,prefix in [('initial-sprites',8,'sprite'),('other-sprites',8,'otherSprite'),('initial-clips',16,'clip'),('other-clips',16,'otherClip')]:state[label]=listing([make(prefix+str(i)) for i in range(count)])
        set_resource('vfxSprites',state['initial-sprites']);set_resource('particleClips',state['initial-clips'])
        C.CFUNCTYPE(None,P,F,F,P,C.c_bool,P)(int(cfg['entry'],16))(state['ice'],f('current'),f('maximum'),state['device'],bool(q['sound']),None)
        assert not im.errors,(q,im.errors)
        snap=dict(level=get32(field('brokenLevel')),broken_calls=state['broken'],root=tag(get64(field('gameObject'))),renderer1=tag(get64(field('spriteRenderer1'))),initial_sprite=state['sprites'][state['r0']],second_sprite=state['sprites'][state['r1']],other_sprite=state['sprites'][state['otherR']],camera=tag(state['mainCamera']),resources='initial' if get64(resource_static+off('ResourceManager','vfxSprites'))==state['initial-sprites'] else 'other',clips='initial' if get64(resource_static+off('ResourceManager','particleClips'))==state['initial-clips'] else 'other',particle_position=state['assigned'][state['transforms'][state['particle']]])
        rows.append(dict(name=q['name'],token='0x06000342',error=None,trace=list(state['trace']),state=snap))
    actual=json.loads(Path(sys.argv[1]).read_bytes());digest=hashlib.sha256((W/'startup-r20-sites100/authored3.dll').read_bytes()).hexdigest();assert actual['candidate_sha256']==digest;found={r['name']:r for r in actual['results']};assert set(found)=={q['name'] for q in cases}
    diff=[dict(original=r,actual=found[r['name']]) for r in rows if r!=found[r['name']]]
    report=dict(scope='COMPLETE_ORIGINAL_ICEUI_UPDATE_CALLER_CONTROLLED_LEAVES',candidate_sha256=digest,original_pc_sha256=hashlib.sha256(im.raw).hexdigest(),caller_bytes_verified=1,normal_records=len(rows),managed_only_records=0,results=rows,differences=diff,callback_errors=im.errors,native_division_comiss_jumps_and_loops_unchanged=True,vector3_hidden_sret_and_value_arguments_preserved=True,new_game_changes=0,not_callee_or_engine_or_device_acceptance=True,formal_or_product_acceptance=False)
    Path(sys.argv[2]).write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in report.items() if k not in ['results','differences']}));print('differences',len(diff));raise SystemExit(2 if diff else 0)
finally:im.close()
