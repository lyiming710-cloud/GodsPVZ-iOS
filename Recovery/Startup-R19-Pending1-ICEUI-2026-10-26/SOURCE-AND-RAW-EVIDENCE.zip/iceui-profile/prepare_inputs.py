from pathlib import Path
import itertools,json,struct
Q=Path(__file__).resolve().parent;bits=lambda x:struct.pack('>f',x).hex().upper();pairs=[[0,100],[100,100],[75,100],[66.666664,100],[50,100],[33.3333,100],[25,100],[-10,100],[0,0],[1,0],[-1,0],[float('nan'),1],[1,float('nan')],[float('inf'),float('inf')]];vectors=[[bits(x) for x in a] for a in [[1.25,-2.5,3.75],[-0.,2**-149,1e10]]];rows=[]
for pair,level,sound,particle,mode,pos in itertools.product(pairs,[-1,0,1,2,2147483647],range(2),range(3),range(6),vectors):rows.append(dict(name=f'i{len(rows):05}',token='0x06000342',current=bits(pair[0]),maximum=bits(pair[1]),level=level,sound=sound,particle=particle,mode=mode,position=pos,volume=bits(.375)))
(Q/'CASES.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode());print(json.dumps(dict(records=len(rows))))
