"""Publish five finite profiles, keeping original candidates and failures intact."""
from pathlib import Path
import json
from archive_support import sha,js,pack,manifest,variants
W=Path(__file__).resolve().parent;ROOT=W.parents[1];Q=W/'r19-pending-supplement1-2026-10-26';R=ROOT/'audit/repo-native113';D=R/'Recovery/Startup-R19-Pending5-2026-10-26';H=R/'Recovery/Startup-R19-Batch100-2026-10-25';T=R/'Recovery/Startup-R20-Sites104-2026-10-26'
assert not D.exists();D.mkdir();(D/'.gitattributes').write_bytes(b'*.json -text\n*.md -text\n*.zip -text\n')
native=json.loads((Q/'NATIVE-ATTEMPT2.json').read_bytes());controls=json.loads((Q/'controls/RESULT.json').read_bytes());binding=json.loads((Q/'R19-AND-R20-BINDING.json').read_bytes())
assert not native['differences'] and native['normal_records']==861 and len(native['per_method'])==5
assert controls['controls']==controls['detected']==5 and controls['process_failures']==0 and binding['all_rows_identical']
current=(W/'startup-r20-sites100/authored3.dll').read_bytes();parent=(W/'startup-r19-batch100/candidate9.dll').read_bytes()
assert sha(current)==binding['current_sha256'] and sha(parent)==binding['parent_sha256']
for p,h in [(W/'startup-r5/runtime-common/Rehost.cs','59b1e80892d0038ee188f0ef36d1af25ce37ae6df71016ba6617cc221ca51d40'),
 (ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py','2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14'),
 (ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/member-bin/MemberAccess.dll','d21ae9d0b39cbadc7c0412c87f41942e86d7eff25b22212c2c64cdd1fc4833db')]:assert sha(p.read_bytes())==h
delta=variants(Q/'controls',current);assert len(delta)==5;js(Q/'PHYSICAL-CONTROL-DELTAS.json',delta)
for source,name in [(Q/'INPUTS.json','INPUTS.json'),(Q/'NATIVE-ATTEMPT2.json','NATIVE.json'),(Q/'R19-AND-R20-BINDING.json','R19-AND-R20-BINDING.json'),(Q/'controls/RESULT.json','CONTROLS.json'),(Q/'PHYSICAL-CONTROL-DELTAS.json','PHYSICAL-CONTROL-DELTAS.json'),(Q/'failed-input-model-v1/DIAGNOSIS.json','INITIAL-INPUT-MODEL-DIAGNOSIS.json')]:(D/name).write_bytes(source.read_bytes())
items=[]
for p in sorted(Q.rglob('*')):
    if not p.is_file() or any(x in p.parts for x in ['obj','__pycache__']):continue
    if p.suffix=='.dll' and 'bin' not in p.parts:continue
    items.append(('r19-pending-supplement1/'+p.relative_to(Q).as_posix(),p.read_bytes()))
for token in native['per_method']:
    for suffix in ['.json','.txt']:
        p=W/'startup-r19-batch100/native-source-complete'/(token+suffix);items.append(('original-native/'+p.name,p.read_bytes()))
items += [('frozen-runtime/Rehost.cs',(W/'startup-r5/runtime-common/Rehost.cs').read_bytes()),('frozen-runtime/native_runtime_common.py',(W/'startup-r5/native_runtime_common.py').read_bytes()),(Path(__file__).name,Path(__file__).read_bytes())]
pack(D/'SOURCE-AND-RAW-EVIDENCE.zip',items)
pending=json.loads((W/'startup-r19-batch100/shared-candidate9/PENDING-RUNTIME-PROFILES.json').read_bytes());assert pending['methods']==35
assert set(native['per_method'])<={r['token'] for r in pending['rows']};remaining=[r for r in pending['rows'] if r['token'] not in native['per_method']]
assert len(remaining)==30
js(H/'CURRENT-PENDING-RUNTIME-PROFILES.json',dict(candidate_sha256=sha(parent),methods=30,not_a_count_of_confirmed_remaining_game_bugs=True,added_supplement='../'+D.name,rows=remaining))
status=json.loads((H/'PROGRESS.json').read_bytes());assert status['finite_comparison_method_union']==65 and status['other_runtime_profile_count']==35 and status['total_native_finite_comparison_records']==18077
status.update(status='HUNDRED_CONSTRUCTED_SEVENTY_FINITE_PROFILES_BATCH_QUALIFICATION_PENDING',finite_comparison_method_union=70,
    other_runtime_profile_count=30,total_native_finite_comparison_records=18938,
    finite_original_native_vs_complete_cil_additional_methods=35,pending5_normal_records=861,pending5_managed_only_records=7,
    pending5_candidate_complete_cil_executed_on_both_parent_and_r20=True,pending5_physical_controls=5,pending5_detected_controls=5,
    total_physical_controls_including_foreach_and_new_profiles=status['total_physical_controls_including_foreach_and_new_profiles']+5,
    total_runtime_differences_including_supplements=status['total_runtime_differences_including_supplements']+5)
js(H/'PROGRESS.json',status)
js(D/'PROGRESS.json',dict(status='FIVE_FINITE_FULL_CALLER_PROFILES_PASS_PRODUCT_NOT_PROMOTED',
    parent_candidate_sha256=sha(parent),current_candidate_sha256=sha(current),new_game_code_changes=0,
    methods=5,native_normal_records=861,managed_only_records=7,controls_detected=5,
    r19_finite_union=70,r19_native_comparison_records=18938,r19_pending_profiles=30,
    initial_input_mismatches_preserved=252,initial_input_mismatches_were_list_version_only=True,
    frozen_tools_unchanged=True,unity=False,compiler_not_rerun_because_no_game_bytes_changed=True,ipa=None,ipad_acceptance=False))
(D/'README.md').write_bytes('''# R19 待对照方法补充：5 个完整调用方

本次没有修改游戏 DLL。对固定 R19 candidate9 和当前 R20 authored3 都实际发射并执行完整候选 CIL，868 条 CLR 记录逐项相同；其中 861 条正常记录与完整原版 PC 调用方一致，7 条 CLR 异常另列。

| Token | 方法 | 原版正常记录 |
|---|---|---:|
| 0x060004CA | PlantSave.Clone | 21 |
| 0x06000341 | Device.ICEUIController.Start | 252 |
| 0x06000599 | Almanac_TalentSystem.Preview | 336 |
| 0x06000578 | Almanac_PlantDetail.CloseOrderUpPage | 126 |
| 0x06000579 | Almanac_PlantDetail.CloseSkillUpPage | 126 |

克隆检查完整字段位模式、数组独立性、字符串浅复制和受控 Skill.Copy 返回对象；冰冻初始化覆盖正负零/有限值/Infinity/NaN、Unity 伪空及回调后的接收者重读。天赋/关闭页面覆盖预览分支、按钮状态、销毁次序、列表替换、真实 CLR List.Clear 的版本/容量/元素效果。升级资格判断保留原版纯整数叶函数实际执行。

五个物理单点故障全部被真实执行差异捕获：少复制一个数组元素、错误动画速度、反向按钮状态、分别漏掉两个 Clear。所有故障进程退出 0，未将异常/崩溃当成功；其他目标无差异。完整故障 DLL 可由当前候选与 PHYSICAL-CONTROL-DELTAS 重建并校验 SHA。

初次对照保留 252 条失败：CLR 输入通过 LINQ ToList 生成非空列表版本 1，而原生输入设为 0。所有轨迹及非版本字段一致。保存旧源码/完整结果后，改用公开 List<T>(T[]) 构造，并在调用前断言初始版本 0、容量等于数量；游戏和冻结验证器/发射器未改。重新执行全部记录后 0 差异。

分配、克隆子对象、Unity 对象生命周期/动画/UI/销毁、天赋数量和页面内部叶函数有明确受控契约。本测试没有证明这些叶函数内部、Windows SEH、实际 Unity 渲染或普遍等价。R19 有限 profile 从 65 增至70，累计原版正常记录 18,938，30 个完整 profile 仍待完成。这些是验证工作项数量，不是剩余 bug 总数。没有新持证 Editor 导出、链接、IPA 或 iPad 验收。新代码仍按超过100处后集中测试的政策累计；本次新增游戏改动为0。
'''.encode())
p=H/'README.md';text=p.read_text('utf-8');text+='\n## 五个待对照调用方补充\n\n[独立补充目录](../Startup-R19-Pending5-2026-10-26/README.md) 保存五个完整调用方的 861 条正常原版对照、两个精确候选的868条实际CIL记录、七条CLR-only异常和五个检测到的物理故障。初版252条列表输入版本差异及工具输入修正均保留。有限方法联合数70、原版记录18,938，30个profile仍待完成；候选/冻结工具不变，无新Unity/IPA/真机提升。\n';p.write_bytes(text.encode())
progress=json.loads((T/'PROGRESS.json').read_bytes());progress['r19_runtime_profiles_still_pending']=30;progress['r19_additional_finite_profiles_verified_on_current_r20']=5;js(T/'PROGRESS.json',progress)
queue=json.loads((T/'CURRENT-WORK-QUEUE.json').read_bytes())
for r in queue['rows']:
    if r['token'] in native['per_method']:
        assert r['parent_census_priority']=='P1_R19_RUNTIME_PROFILE';r.update(current_state='R19_BODY_FINITE_PROFILE_PASS_BOTH_EXACT_CANDIDATES_PRODUCT_PENDING',r19_runtime_pending=False,normal_native_records=native['per_method'][r['token']],current_required_action='Actual engine/product integration remains pending; finite full-caller supplement is archived')
queue.update(other_parent_followup_work_items=143,additional_parent_r19_profiles_completed=5);js(T/'CURRENT-WORK-QUEUE.json',queue)
p=R/'README.md';text=p.read_text('utf-8');assert 'Sixty-five methods now have 18,077' in text;text=text.replace('Sixty-five methods now have 18,077','Seventy methods now have 18,938').replace('Thirty-five other runtime profiles','Thirty other runtime profiles').replace('71 physical controls: 67 runtime differences','76 physical controls: 72 runtime differences');p.write_bytes(text.encode())
p=R/'Recovery/STATUS.md';text=p.read_text('utf-8');marker='## Latest checkpoint - 2026-10-26\n';assert marker in text;text=text.replace(marker,marker+'\n[R19 pending-five supplement](Startup-R19-Pending5-2026-10-26/README.md): five more complete original callers match861 normal records on both unchanged R19/R20 candidates. Five one-site physical faults are detected; seven CLR-only exceptions and initial252 input-version mismatches are preserved. R19 finite union70 /18,938 records,30 pending. No game code change, new compiler run, Unity export, IPA or device result.\n',1);p.write_bytes(text.encode())
for d in [D,H,T]:manifest(d)
print(json.dumps(dict(finite_r19_methods=70,r19_native_records=18938,pending_profiles=30,new_game_code_changes=0)))
