"""Five complete original PC callers against complete, previously authored CIL.

Controlled allocations/engine/game leaves are declared; native SEH and Unity
rendering are outside scope. The original pure OrderUpAble_Lv leaf executes.
"""
from pathlib import Path
import collections,ctypes as C,functools,hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
ids=[0x4ca,0x341,0x599,0x578,0x579];im=NativeImage();state={}
cfgs={rid:json.loads((W/'startup-r19-batch100/native-source-complete'/f'0x{0x6000000|rid:08X}.json').read_bytes()) for rid in ids}
fields=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_bytes())
ints='plantType stars ID clique order level skillLevel sunPrice defaultSkillID fashionSerialNumber'.split()
floats='replantCD healthPoint maxHealthPoint attackPoint armorPoint defensePoint attackInterva characteristicTicking characteristicMaxTicking'.split()
strings='name synopsis description characteristicText'.split();skills=['skill1','skill2','skill3']
@functools.lru_cache(None)
def off(owner,name):
    rows=[r for r in fields if r['type']==owner and r['namespace']=='' and r['name']==name];assert len(rows)==1,(owner,name);return rows[0]['offset']
def js(p,v):p.write_bytes((json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode())
def string(s):
    if s is None:return 0
    b=s.encode('utf-16-le');p=im.alloc(24+len(b));put32(p+0x10,len(b)//2);C.memmove(p+0x14,b,len(b));return p
def text(p):return None if not p else C.string_at(p+0x14,get32(p+0x10)*2).decode('utf-16-le')
def bits(v):return struct.pack('<f',v)[::-1].hex().upper()
def f(k):return struct.unpack('<f',bytes.fromhex(state['q'][k])[::-1])[0]
def mode():return state['q']['mode']
def n(k,d=0):return state['q'].get(k,d)
def tag(p):return 'null' if not p else state['tags'][p]
def make(label,size=512):
    p=im.alloc(size);state['tags'][p]=label;return p
def field(label,owner,name):return state[label]+off(owner,name)
def array(values,boolean=False):
    p=im.alloc(32+len(values)*(1 if boolean else 8));put64(p+0x18,len(values))
    for k,v in enumerate(values):
        if boolean:C.c_ubyte.from_address(p+0x20+k).value=bool(v)
        else:put64(p+0x20+8*k,v)
    return p
def listing(values,boolean=False):
    p=im.alloc(32);put64(p+0x10,array(values,boolean));put32(p+0x18,len(values));put32(p+0x1c,0);state['capacities'][p]=len(values);return p
def items(p):return [get64(get64(p+0x10)+0x20+8*k) for k in range(get32(p+0x18))]
def save(label,seed):
    p=make(label);vals=state['q']['values']
    for name in ints:put32(p+off('PlantSave',name),vals[name])
    for name in floats:C.c_uint32.from_address(p+off('PlantSave',name)).value=int(vals[name],16)
    for name in strings:put64(p+off('PlantSave',name),string(None if seed%3==0 else label+':'+name))
    for name in skills:put64(p+off('PlantSave',name),make(label+':'+name))
    for name,singular in [('talentNames','name'),('talents','talent')]:put64(p+off('PlantSave',name),array([string(label+':'+singular+str(i)) for i in range(n('length',3))]))
    C.c_ubyte.from_address(p+off('PlantSave','isUnlocked')).value=seed&1
    put32(p+off('PlantSave','order'),n('order'));put32(p+off('PlantSave','level'),n('level'));put32(p+off('PlantSave','skillLevel'),seed*3);put64(p+off('PlantSave','hormon'),make(label+':hormon'));return p
def data(p):
    if not p:return None
    d={name:get32(p+off('PlantSave',name)) for name in ints}
    d.update({name:f'{C.c_uint32.from_address(p+off("PlantSave",name)).value:08X}' for name in floats})
    d.update({name:text(get64(p+off('PlantSave',name))) for name in strings})
    d.update({name:tag(get64(p+off('PlantSave',name))) if get64(p+off('PlantSave',name)) else None for name in skills+['hormon']})
    d['isUnlocked']=bool(C.c_ubyte.from_address(p+off('PlantSave','isUnlocked')).value)
    for name in ['talentNames','talents']:
        a=get64(p+off('PlantSave',name));d[name]=[text(get64(a+0x20+8*i)) for i in range(get32(a+0x18))] if a else None
    return d
def alloc_save(cls):
    assert cls in handles;state['trace'].append('AllocateSave');p=make('clone');state['clone']=p;return p
def alloc_array(cls,count):
    assert cls in handles and count==3;state['trace'].append('Array:3');return array([0]*count)
def object_ctor(p,method):assert p==state['clone'] and not method;state['trace'].append('ObjectCtor')
def skill_copy(p,method):assert not method;state['trace'].append('Copy:'+tag(p));return make('copy('+tag(p)+')')
def exists(p,method):
    assert not method;value=bool(p and state['live'].get(p,True));state['trace'].append('Exists:'+tag(p)+':'+str(int(value)))
    if p in [state['object'],state['other-object']] and mode()=='exists-fields':put64(field('ice','ICEUIController','gameObject'),state['other-object'])
    if p in [state['animator'],state['other-animator']] and mode()=='animator-fields':put64(field('device','Device','animator'),state['other-animator'])
    return value
def equal(p,b,method):assert not b;return not exists(p,method)
def active(p,value,method):
    assert not method;state['active'][p]=bool(value);state['trace'].append('Active:'+tag(p)+':'+str(int(value)))
    if mode()=='active-fields':put64(field('ice','ICEUIController','gameObject'),state['other-object']);put64(field('device','Device','animator'),state['other-animator'])
def speed(p,value,method):assert not method;state['speed'][p]=bits(value);state['trace'].append('Speed:'+tag(p)+':'+bits(value))
def ice_update(p,a,b,device,final,method):assert p==state['ice'] and device==state['device'] and not method;state['trace'].append('IceUpdate:'+bits(a)+':'+bits(b)+':device:'+str(int(final)))
def count(p,method):assert not method;state['trace'].append('Count:'+tag(p)+':'+str(n('unlocked')));return n('unlocked')
def list_item(p,index,method):assert method in handles and 0<=index<get32(p+0x18);return get64(get64(p+0x10)+0x20+index*8)
def bool_item(p,index,method):assert method in handles and 0<=index<get32(p+0x18);return bool(C.c_ubyte.from_address(get64(p+0x10)+0x20+index).value)
def enable(p,value,method):
    assert not method;state['enabled'][p]=bool(value);state['trace'].append('Enable:'+tag(p)+':'+str(int(value)))
    if mode()=='enable-fields':
        for name,label in [('buttons','other-buttons'),('select','other-select'),('plantSave','other-save'),('talentDescription','other-text')]:put64(field('talent','Almanac_TalentSystem',name),state[label])
def settext(p,s,force,method):
    assert not method;state['text'][p]=(text(s),bool(force));state['trace'].append('Text:'+tag(p)+':'+(text(s) if s else 'null')+':'+str(int(force)))
    if mode()=='text-fields':put64(field('talent','Almanac_TalentSystem','buttons'),state['other-buttons']);put64(field('talent','Almanac_TalentSystem','select'),state['other-select'])
def update_talent(p,index,method):
    assert p==state['talent'] and not method;state['trace'].append('UpdateTalent:'+str(index))
    if mode()=='update-fields':put64(field('talent','Almanac_TalentSystem','buttons'),state['other-buttons']);put64(field('talent','Almanac_TalentSystem','select'),state['other-select'])
def trigger(p,key,method):
    assert not method;state['trace'].append('Trigger:'+tag(p)+':'+str(key))
    if mode()=='trigger-fields':put64(field('detail','Almanac_PlantDetail','animator'),state['other-animator']);put64(field('detail','Almanac_PlantDetail','plantSave'),state['other-save'])
def bool_int(p,key,value,method):
    assert not method;state['trace'].append('BoolI:'+tag(p)+':'+str(key)+':'+str(int(value)))
    if mode()=='bool-fields':put64(field('detail','Almanac_PlantDetail','plantSave'),state['other-save']);put64(field('detail','Almanac_PlantDetail','suppliesItemList'),state['other-items'])
def bool_string(p,key,value,method):
    assert not method;state['trace'].append('BoolS:'+tag(p)+':'+text(key)+':'+str(int(value)))
    if mode()=='bool-fields':put64(field('detail','Almanac_PlantDetail','suppliesItemList'),state['other-items'])
def close_preview(p,method):
    assert p==state['skill-page'] and not method;state['trace'].append('ClosePreview')
    if mode()=='close-fields':put64(field('detail','Almanac_PlantDetail','animator'),state['other-animator']);put64(field('detail','Almanac_PlantDetail','plantSave'),state['other-save'])
def order_preview(p,index,value,method):
    assert p==state['detail'] and not method;state['trace'].append('OrderPreview:'+str(index)+':'+str(int(value)))
    if mode()=='preview-fields':put64(field('detail','Almanac_PlantDetail','animator'),state['other-animator']);put64(field('detail','Almanac_PlantDetail','suppliesItemList'),state['other-items'])
def skill_preview(p,index,method):
    assert p==state['detail'] and not method;state['trace'].append('SkillPreview:'+str(index))
    if mode()=='preview-fields':put64(field('detail','Almanac_PlantDetail','plantSave'),state['other-save']);put64(field('detail','Almanac_PlantDetail','button_previewOrderUp'),state['other-order-button'])
def interact(p,value,method):
    assert not method;state['interactable'][p]=bool(value);state['trace'].append('Interact:'+tag(p)+':'+str(int(value)))
    if mode()=='interact-list':put64(field('detail','Almanac_PlantDetail','suppliesItemList'),state['other-items'])
def gameobject(p,method):assert not method;state['trace'].append('Object:'+tag(p));return state['item_objects'][p]
def destroy(p,method):
    assert not method;state['trace'].append('Destroy:'+tag(p));state['destroyed'].add(tag(p))
    if not state['destroy_changed']:
        state['destroy_changed']=True
        if mode()=='destroy-list':put64(field('detail','Almanac_PlantDetail','suppliesItemList'),state['other-items'])
def clear_array(p,start,length,method):
    assert not method and start==0 and 0<=length<=get32(p+0x18)
    for k in range(length):put64(p+0x20+k*8,0)
def list_state(p):return dict(items=[tag(x) for x in items(p)],size=get32(p+0x18),capacity=state['capacities'][p],version=get32(p+0x1c))
def snapshot(rid):
    if rid==0x4ca:
        source,result=state['save'],state['clone'];return dict(source=data(source),result=data(result),root_distinct=source!=result,names_distinct=get64(source+0x30)!=get64(result+0x30),talents_distinct=get64(source+0x38)!=get64(result+0x38),strings_shared=[get64(source+off('PlantSave',name))==get64(result+off('PlantSave',name)) for name in strings])
    if rid==0x341:return dict(root=tag(get64(field('ice','ICEUIController','gameObject'))),animator=tag(get64(field('device','Device','animator'))),active=state['active'][state['object']],other_active=state['active'][state['other-object']],speed=state['speed'][state['animator']],other_speed=state['speed'][state['other-animator']])
    if rid==0x599:
        a=state['text'][state['text-object']];b=state['text'][state['other-text']]
        return dict(preview=get32(field('talent','Almanac_TalentSystem','previewID')),buttons='other' if get64(field('talent','Almanac_TalentSystem','buttons'))==state['other-buttons'] else 'initial',save=tag(get64(field('talent','Almanac_TalentSystem','plantSave'))),text_owner=tag(get64(field('talent','Almanac_TalentSystem','talentDescription'))),enabled=[state['enabled'][p] for p in state['button-values']],other_enabled=[state['enabled'][p] for p in state['other-button-values']],text=a[0],force=a[1],other_text=b[0],other_force=b[1])
    return dict(animator=tag(get64(field('detail','Almanac_PlantDetail','animator'))),save=tag(get64(field('detail','Almanac_PlantDetail','plantSave'))),button=tag(get64(field('detail','Almanac_PlantDetail','button_previewOrderUp'))),interactable=state['interactable'][state['order-button']],other_interactable=state['interactable'][state['other-order-button']],root='other' if get64(field('detail','Almanac_PlantDetail','suppliesItemList'))==state['other-items'] else 'initial',initial=list_state(state['items']),other=list_state(state['other-items']),destroyed=sorted(state['destroyed']))
try:
    meta=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/global-metadata.dat').read_bytes();assert hashlib.sha256(meta).hexdigest()=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9'
    so,sn,do,dn=struct.unpack_from('<4I',meta,8);dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True;slots=set();handles=set()
    for cfg in cfgs.values():
        for row in cfg['instructions']:
            i=next(dis.disasm(bytes.fromhex(row['bytes']),int(row['va'],16)))
            if i.mnemonic not in ['mov','lea']:continue
            for o in i.operands:
                if o.type!=X86_OP_MEM or o.mem.base!=X86_REG_RIP:continue
                at=i.address+i.size+o.mem.disp;raw=im.pe.get_data(at-im.base,8)
                if len(raw)!=8:continue
                code=int.from_bytes(raw,'little')
                if code>0xffffffff or code>>29 not in range(1,8) or at in slots:continue
                slots.add(at);kind,index=code>>29,(code&0x1fffffff)>>1
                if kind==5:ln,pos=struct.unpack_from('<II',meta,so+8*index);put64(at,string(meta[do+pos:do+pos+ln].decode('utf-8')))
                else:handles.add(im.class_slot(at))
    page_slot=0x181bce780;assert page_slot in slots;page_static=get64(get64(page_slot)+0xb8);put32(page_static+0xc,101);put32(page_static+4,102)
    def init(at):assert at in slots,hex(at)
    def barrier(at,p):assert get64(at)==(p or 0)
    im.hook(0x18024fef0,None,[P],init);im.hook(0x1802501e0,None,[P],lambda p:None);im.hook(0x18024f360,None,[P,P],barrier)
    im.hook(0x180250100,P,[P],alloc_save);im.hook(0x18024f3e0,P,[P,C.c_size_t],alloc_array);im.hook(0x180302170,None,[P,P],object_ctor);im.hook(0x180385e70,P,[P,P],skill_copy)
    im.hook(0x18131f760,C.c_bool,[P,P,P],equal);im.hook(0x18131f870,C.c_bool,[P,P],exists);im.hook(0x18131bad0,None,[P,C.c_bool,P],active);im.hook(0x1812dbcd0,None,[P,F,P],speed);im.hook(0x18034d610,None,[P,F,F,P,C.c_bool,P],ice_update)
    im.hook(0x180376130,I,[P,P],count);im.hook(0x180825710,P,[P,I,P],list_item);im.hook(0x180825760,C.c_bool,[P,I,P],bool_item);im.hook(0x181302cb0,None,[P,C.c_bool,P],enable);im.hook(0x1811af070,None,[P,P,C.c_bool,P],settext);im.hook(0x180391a10,None,[P,I,P],update_talent)
    im.hook(0x1812dbbc0,None,[P,I,P],trigger);im.hook(0x1812db9a0,None,[P,I,C.c_bool,P],bool_int);im.hook(0x1812dba00,None,[P,P,C.c_bool,P],bool_string);im.hook(0x18038f9b0,None,[P,P],close_preview);im.hook(0x18038e550,None,[P,I,C.c_bool,P],order_preview);im.hook(0x18038ef10,None,[P,I,P],skill_preview);im.hook(0x18156cc70,None,[P,C.c_bool,P],interact);im.hook(0x1813044d0,P,[P,P],gameobject);im.hook(0x18131e940,None,[P,P],destroy);im.hook(0x180cb86f0,None,[P,I,I,P],clear_array)
    for rid,cfg in cfgs.items():im.verify_caller(rid,int(cfg['entry'],16),cfg)
    pure=im.pe.get_data(0x1803761e0-im.base,18);assert C.string_at(0x1803761e0,18)==pure
    rows=[];cases=json.loads((Q/'CASES.json').read_bytes())
    for q in cases:
        if not q['native_supported']:continue
        if '--trace-cases' in sys.argv:print(json.dumps(dict(starting_case=q['name'],token=q['token'])),flush=True)
        state.clear();state.update(q=q,tags={},capacities={},live={},trace=[],clone=0,active={},speed={},enabled={},interactable={},text={},item_objects={},destroyed=set(),destroy_changed=False)
        state['save']=save('save',n('seed',1));state['other-save']=save('other-save',7)
        put32(state['other-save']+off('PlantSave','order'),7);put32(state['other-save']+off('PlantSave','level'),99);put32(state['other-save']+off('PlantSave','skillLevel'),21)
        for label in ['ice','device','object','other-object','animator','other-animator','talent','text-object','other-text','detail','order-button','other-order-button','skill-page']:state[label]=make('text' if label=='text-object' else label)
        state['live'][state['object']]=n('object',1)==1;state['live'][state['animator']]=n('animator',1)==1
        for label in ['object','other-object']:state['active'][state[label]]=None
        for label in ['animator','other-animator']:state['speed'][state[label]]=None
        put64(field('ice','ICEUIController','gameObject'),state['object'] if n('object',1) else 0);put64(field('device','Device','animator'),state['animator'] if n('animator',1) else 0)
        state['button-values']=[make('button'+str(i)) for i in range(3)];state['other-button-values']=[make('other-button'+str(i)) for i in range(3)]
        state['buttons']=listing(state['button-values']);state['other-buttons']=listing(state['other-button-values']);state['select']=listing([bool(n('select')&(1<<i)) for i in range(3)],True);state['other-select']=listing([True,False,True],True)
        for p in state['button-values']+state['other-button-values']:state['enabled'][p]=True
        for label in ['order-button','other-order-button']:state['interactable'][state[label]]=True
        for label in ['text-object','other-text']:state['text'][state[label]]=(None,False)
        for name,label in [('plantSave','save'),('buttons','buttons'),('select','select'),('talentDescription','text-object')]:put64(field('talent','Almanac_TalentSystem',name),state[label])
        put32(field('talent','Almanac_TalentSystem','previewID'),-7)
        for label,num,prefix in [('items',n('items'),'item'),('other-items',2,'other-item')]:
            values=[make(prefix+str(i)) for i in range(num)]
            for p in values:state['item_objects'][p]=make(tag(p)+'-object')
            state[label]=listing(values)
        for name,label in [('animator','animator'),('plantSave','save'),('skillSystem','skill-page'),('button_previewOrderUp','order-button'),('suppliesItemList','items')]:put64(field('detail','Almanac_PlantDetail',name),state[label])
        rid=int(q['token'],16)&0xffffff;entry=int(cfgs[rid]['entry'],16)
        if rid==0x4ca:result=C.CFUNCTYPE(P,P,P)(entry)(state['save'],None);assert result==state['clone']
        elif rid==0x341:C.CFUNCTYPE(None,P,F,F,P,P)(entry)(state['ice'],f('duration'),f('total'),state['device'],None)
        elif rid==0x599:C.CFUNCTYPE(None,P,I,P)(entry)(state['talent'],n('id'),None)
        else:C.CFUNCTYPE(None,P,P)(entry)(state['detail'],None)
        assert not im.errors,(q,im.errors);rows.append(dict(name=q['name'],token=q['token'],error=None,trace=list(state['trace']),state=snapshot(rid)))
    actual=json.loads(Path(sys.argv[1]).read_bytes());expected_hash=hashlib.sha256((W/'startup-r20-sites100/authored3.dll').read_bytes()).hexdigest();assert actual['candidate_sha256']==expected_hash
    byname={r['name']:r for r in actual['results']};assert len(byname)==len(cases) and set(byname)=={c['name'] for c in cases}
    differences=[dict(original=r,actual=byname[r['name']]) for r in rows if r!=byname[r['name']]]
    report=dict(scope='FIVE_COMPLETE_ORIGINAL_PC_CALLERS_VS_COMPLETE_R19_BODIES_IN_CURRENT_R20',candidate_sha256=expected_hash,original_pc_sha256=hashlib.sha256(im.raw).hexdigest(),caller_bytes_verified=5,
        normal_records=len(rows),per_method=dict(collections.Counter(r['token'] for r in rows)),results=rows,differences=differences,callback_errors=im.errors,
        managed_only_exception_records=[byname[c['name']] for c in cases if not c['native_supported']],
        original_pure_order_able_leaf_executed=True,pure_order_able_leaf_bytes_sha256=hashlib.sha256(pure).hexdigest(),
        controlled_leaves=['Object/array allocation and clone constructor initialization','Skill.Copy identity contract','Unity lifetime/Animator/GameObject/Behaviour/TMP/Destroy','GetTalentNum_Unlocked bounded count','Preview game leaves','Reference/boolean list indexing and Array.Clear'],
        limitations=['No original native SEH or exceptional-path equivalence','No complete Skill.Copy, talent-count or child preview behavior proof','No actual Unity lifecycle/rendering or universal equivalence'],formal_or_product_acceptance=False)
    js(Path(sys.argv[2]),report);print(json.dumps({k:v for k,v in report.items() if k not in ['results','differences','managed_only_exception_records']}));print('differences',len(differences));assert not differences
finally:im.close()
