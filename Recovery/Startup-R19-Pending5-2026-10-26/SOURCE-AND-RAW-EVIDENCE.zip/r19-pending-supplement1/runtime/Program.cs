using System.Reflection;using System.Runtime.CompilerServices;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public class Obj{public string Tag="";public bool Live=true;}
public class Hormon:Obj{}
public class Skill:Obj{public Skill Copy(){Program.Trace.Add("Copy:"+Tag);return new(){Tag="copy("+Tag+")"};}}
public class PlantSave:Obj
{
 public string? name,synopsis,description,characteristicText;public string?[]? talentNames,talents;
 public int plantType,stars,ID,clique,order,level,skillLevel,sunPrice,defaultSkillID,fashionSerialNumber;public bool isUnlocked;
 public float replantCD,healthPoint,maxHealthPoint,attackPoint,armorPoint,defensePoint,attackInterva,characteristicTicking,characteristicMaxTicking;
 public Skill? skill1,skill2,skill3;public Hormon? hormon;
 public PlantSave(){Program.Trace.Add("AllocateSave");Program.Trace.Add("Array:3");talentNames=new string[3];Program.Trace.Add("Array:3");talents=new string[3];Program.Trace.Add("ObjectCtor");}
 public bool OrderUpAble_Lv()=>level>=unchecked((order+2)*10);
 public int GetTalentNum_Unlocked(){int n=Program.N("unlocked");Program.Trace.Add("Count:"+Tag+":"+n);return n;}
}
public class GO:Obj
{
 public bool? Active;
 public void SetActive(bool value){Active=value;Program.Trace.Add("Active:"+Tag+":"+(value?1:0));if(Program.Mode=="active-fields"){Program.Ice.gameObject=Program.OtherGO;Program.Dev.animator=Program.OtherAnimator;}}
}
public class Animator:Obj
{
 public string? Speed;
 public float speed{set{Speed=Program.Bits(value);Program.Trace.Add("Speed:"+Tag+":"+Speed);}}
 public void SetTrigger(int value){Program.Trace.Add("Trigger:"+Tag+":"+value);if(Program.Mode=="trigger-fields"){Program.Detail.animator=Program.OtherAnimator;Program.Detail.plantSave=Program.OtherSave;}}
 public void SetBool(int key,bool value){Program.Trace.Add("BoolI:"+Tag+":"+key+":"+(value?1:0));if(Program.Mode=="bool-fields"){Program.Detail.plantSave=Program.OtherSave;Program.Detail.suppliesItemList=Program.OtherItems;}}
 public void SetBool(string key,bool value){Program.Trace.Add("BoolS:"+Tag+":"+key+":"+(value?1:0));if(Program.Mode=="bool-fields")Program.Detail.suppliesItemList=Program.OtherItems;}
}
public class Device{public Animator? animator;}
public class IcePage{public GO? gameObject;public void Update(float a,float b,Device d,bool final){Program.Trace.Add("IceUpdate:"+Program.Bits(a)+":"+Program.Bits(b)+":"+(ReferenceEquals(d,Program.Dev)?"device":"other")+":"+(final?1:0));}}
public class Btn:Obj
{
 public bool Enabled=true,Interactable=true;
 public bool enabled{set{Enabled=value;Program.Trace.Add("Enable:"+Tag+":"+(value?1:0));if(Program.Mode=="enable-fields"){Program.Talent.buttons=Program.OtherButtons;Program.Talent.select=Program.OtherSelect;Program.Talent.plantSave=Program.OtherSave;Program.Talent.talentDescription=Program.OtherText;}}}
 public bool interactable{set{Interactable=value;Program.Trace.Add("Interact:"+Tag+":"+(value?1:0));if(Program.Mode=="interact-list")Program.Detail.suppliesItemList=Program.OtherItems;}}
}
public class Txt:Obj
{
 public string? Last;public bool Force;
 public void SetText(string? s,bool force){Last=s;Force=force;Program.Trace.Add("Text:"+Tag+":"+(s??"null")+":"+(force?1:0));if(Program.Mode=="text-fields"){Program.Talent.buttons=Program.OtherButtons;Program.Talent.select=Program.OtherSelect;}}
}
public class TalentPage
{
 public PlantSave? plantSave;public int previewID=-7;public List<Btn> buttons=[];public List<bool> select=[];public Txt talentDescription=null!;
 public void UpdateTalentTexts(int index){Program.Trace.Add("UpdateTalent:"+index);if(Program.Mode=="update-fields"){buttons=Program.OtherButtons;select=Program.OtherSelect;}}
}
public class Item:Obj{public GO Value=null!;public GO gameObject{get{Program.Trace.Add("Object:"+Tag);return Value;}}}
public class SkillPage{public void ClosePreview(){Program.Trace.Add("ClosePreview");if(Program.Mode=="close-fields"){Program.Detail.animator=Program.OtherAnimator;Program.Detail.plantSave=Program.OtherSave;}}}
public class DetailPage
{
 public Animator? animator;public PlantSave? plantSave;public SkillPage? skillSystem;public Btn? button_previewOrderUp;public List<Item>? suppliesItemList;
 public static int Ani_OrderCloseHash=101,Ani_SkillHash=102;
 public void SetOrderUpPreview(int n,bool on){Program.Trace.Add("OrderPreview:"+n+":"+(on?1:0));if(Program.Mode=="preview-fields"){animator=Program.OtherAnimator;suppliesItemList=Program.OtherItems;}}
 public void SetSkillUpPreview(int n){Program.Trace.Add("SkillPreview:"+n);if(Program.Mode=="preview-fields"){plantSave=Program.OtherSave;button_previewOrderUp=Program.OtherButton;}}
}
public static class Program
{
 public static JsonElement Case;public static List<string> Trace=[];public static IcePage Ice=null!;public static Device Dev=null!;public static GO FirstGO=null!,OtherGO=null!;public static Animator FirstAnimator=null!,OtherAnimator=null!;public static PlantSave Input=null!,OtherSave=null!;public static TalentPage Talent=null!;public static DetailPage Detail=null!;public static Txt Text=null!,OtherText=null!;public static List<Btn> Buttons=null!,OtherButtons=null!;public static List<bool> Select=null!,OtherSelect=null!;public static Btn Button=null!,OtherButton=null!;public static List<Item> Items=null!,OtherItems=null!;public static HashSet<string> Destroyed=[];public static bool DestroyChanged;
 public static string Mode=>Case.GetProperty("mode").GetString()!;public static int N(string k,int d=0)=>Case.TryGetProperty(k,out var v)?v.GetInt32():d;
 public static string Tag(Obj? o)=>o?.Tag??"null";public static string Bits(float f)=>((uint)BitConverter.SingleToInt32Bits(f)).ToString("X8");
 public static float F(string key)=>BitConverter.Int32BitsToSingle(unchecked((int)Convert.ToUInt32(Case.GetProperty(key).GetString(),16)));
 public static bool Exists(Obj? p){bool a=p!=null&&p.Live;Trace.Add("Exists:"+Tag(p)+":"+(a?1:0));if(p is GO&&Mode=="exists-fields")Ice.gameObject=OtherGO;if(p is Animator&&Mode=="animator-fields")Dev.animator=OtherAnimator;return a;}
 public static bool Unequal(Obj? p,Obj? b){if(b!=null)throw new Exception();return Exists(p);}
 public static void Destroy(Obj? p){Trace.Add("Destroy:"+Tag(p));if(p!=null)Destroyed.Add(p.Tag);if(!DestroyChanged){DestroyChanged=true;if(Mode=="destroy-list")Detail.suppliesItemList=OtherItems;}}
 static Type Map(MC.TypeReference t)
 {
  if(t is MC.ArrayType a)return Map(a.ElementType).MakeArrayType();
  if(t is MC.GenericInstanceType g&&g.ElementType.FullName=="System.Collections.Generic.List`1")return typeof(List<>).MakeGenericType(g.GenericArguments.Select(Map).ToArray());
  return t.FullName switch{"System.Void"=>typeof(void),"System.Boolean"=>typeof(bool),"System.Int32" or "PlantType" or "Clique"=>typeof(int),"System.Single"=>typeof(float),"System.IntPtr"=>typeof(IntPtr),"System.Object"=>typeof(object),"System.String"=>typeof(string),"System.IndexOutOfRangeException"=>typeof(IndexOutOfRangeException),"UnityEngine.Object"=>typeof(Obj),"UnityEngine.Component" or "SuppliesItem"=>typeof(Item),"UnityEngine.GameObject"=>typeof(GO),"UnityEngine.Animator"=>typeof(Animator),"UnityEngine.Behaviour" or "UnityEngine.UI.Selectable" or "UnityEngine.UI.Button"=>typeof(Btn),"TMPro.TMP_Text" or "TMPro.TextMeshProUGUI"=>typeof(Txt),"Device"=>typeof(Device),"Device/ICEUIController"=>typeof(IcePage),"PlantSave"=>typeof(PlantSave),"Hormon"=>typeof(Hormon),"Skill"=>typeof(Skill),"Almanac_TalentSystem"=>typeof(TalentPage),"Almanac_PlantDetail"=>typeof(DetailPage),"Almanac_SkillSystem"=>typeof(SkillPage),_=>throw new NotSupportedException(t.FullName)};
 }
 static FieldInfo Field(MC.FieldReference f)=>Map(f.DeclaringType).GetField(f.Name)!;
 static MethodBase Method(MC.MethodReference m)
 {
  if(m.DeclaringType.FullName=="UnityEngine.Object")return typeof(Program).GetMethod(m.Name=="op_Implicit"?"Exists":m.Name=="op_Inequality"?"Unequal":m.Name)!;
  Type Closed(MC.TypeReference p)=>p is MC.GenericParameter gp&&m.DeclaringType is MC.GenericInstanceType gt?Map(gt.GenericArguments[gp.Position]):Map(p);
  var args=m.Parameters.Select(p=>Closed(p.ParameterType)).ToArray();return m.Name==".ctor"?Map(m.DeclaringType).GetConstructor(args)!:Map(m.DeclaringType).GetMethod(m.Name,BindingFlags.Public|BindingFlags.Static|BindingFlags.Instance,null,args,null)!;
 }
 static PlantSave MakeSave(string tag,int seed)
 {
  var p=(PlantSave)RuntimeHelpers.GetUninitializedObject(typeof(PlantSave));p.Tag=tag;
  foreach(var f in typeof(PlantSave).GetFields(BindingFlags.Public|BindingFlags.Instance|BindingFlags.DeclaredOnly))
  {
   var values=Case.GetProperty("values");if(f.FieldType==typeof(int))f.SetValue(p,values.GetProperty(f.Name).GetInt32());else if(f.FieldType==typeof(float))f.SetValue(p,BitConverter.Int32BitsToSingle(unchecked((int)Convert.ToUInt32(values.GetProperty(f.Name).GetString(),16))));else if(f.FieldType==typeof(bool))f.SetValue(p,(seed&1)!=0);else if(f.FieldType==typeof(string))f.SetValue(p,seed%3==0?null:tag+":"+f.Name);else if(f.FieldType==typeof(Skill))f.SetValue(p,new Skill{Tag=tag+":"+f.Name});
  }
  int len=N("length",3);p.talentNames=Enumerable.Range(0,len).Select(i=>(string?)($"{tag}:name{i}")).ToArray();p.talents=Enumerable.Range(0,len).Select(i=>(string?)($"{tag}:talent{i}")).ToArray();p.hormon=new(){Tag=tag+":hormon"};p.order=N("order");p.level=N("level");p.skillLevel=seed*3;return p;
 }
 static object Data(PlantSave p)
 {
  var d=new SortedDictionary<string,object?>();foreach(var f in typeof(PlantSave).GetFields(BindingFlags.Public|BindingFlags.Instance|BindingFlags.DeclaredOnly)){object? v=f.GetValue(p);d[f.Name]=v is float n?Bits(n):v is Obj o?o.Tag:v;}return d;
 }
 static object ListState(List<Item> l)=>new{items=l.Select(p=>Tag(p)).ToArray(),size=l.Count,capacity=l.Capacity,version=(int)typeof(List<Item>).GetField("_version",BindingFlags.Instance|BindingFlags.NonPublic)!.GetValue(l)!};
 static Item MakeItem(string tag)=>new(){Tag=tag,Value=new(){Tag=tag+"-object"}};
 public static void Main(string[] args)
 {
  var resolver=new MC.DefaultAssemblyResolver();resolver.AddSearchDirectory(args[1]);using var asm=MC.AssemblyDefinition.ReadAssembly(args[0],new MC.ReaderParameters{AssemblyResolver=resolver});int[] ids={0x4ca,0x341,0x599,0x578,0x579};var code=ids.ToDictionary(r=>r,r=>ActualCil.Emit((MC.MethodDefinition)asm.MainModule.LookupToken(0x6000000|r),Map,Field,Method));using var cases=JsonDocument.Parse(File.ReadAllText(args[2]));var rows=new List<object>();
  foreach(var q in cases.RootElement.EnumerateArray())
  {
   Case=q;Trace.Clear();Destroyed=[];DestroyChanged=false;Input=MakeSave("save",N("seed",1));OtherSave=MakeSave("other-save",7);OtherSave.order=7;OtherSave.level=99;OtherSave.skillLevel=21;
   string missing=q.TryGetProperty("missing",out var me)?me.GetString()!:"";if(missing.StartsWith("skill"))typeof(PlantSave).GetField(missing)!.SetValue(Input,null);if(missing=="talents")Input.talents=null;
   FirstGO=new(){Tag="object",Live=N("object",1)==1};OtherGO=new(){Tag="other-object"};FirstAnimator=new(){Tag="animator",Live=N("animator",1)==1};OtherAnimator=new(){Tag="other-animator"};Ice=new(){gameObject=N("object",1)==0?null:FirstGO};Dev=new(){animator=N("animator",1)==0?null:FirstAnimator};
   Text=new(){Tag="text"};OtherText=new(){Tag="other-text"};Buttons=Enumerable.Range(0,3).Select(i=>new Btn{Tag="button"+i}).ToList();OtherButtons=Enumerable.Range(0,3).Select(i=>new Btn{Tag="other-button"+i}).ToList();Select=Enumerable.Range(0,3).Select(i=>(N("select")&(1<<i))!=0).ToList();OtherSelect=[true,false,true];Talent=new(){plantSave=N("save",1)==0?null:Input,buttons=Buttons,select=Select,talentDescription=Text};Button=new(){Tag="order-button"};OtherButton=new(){Tag="other-order-button"};Items=new(Enumerable.Range(0,N("items")).Select(i=>MakeItem("item"+i)).ToArray());OtherItems=new(Enumerable.Range(0,2).Select(i=>MakeItem("other-item"+i)).ToArray());Detail=new(){animator=FirstAnimator,plantSave=Input,skillSystem=new(),button_previewOrderUp=Button,suppliesItemList=Items};
   foreach(var list in new[]{Items,OtherItems})if((int)typeof(List<Item>).GetField("_version",BindingFlags.Instance|BindingFlags.NonPublic)!.GetValue(list)!=0||list.Capacity!=list.Count)throw new Exception("Mismatched initial reference-list contract");
   Trace.Clear();int rid=Convert.ToInt32(q.GetProperty("token").GetString(),16)&0xffffff;object? result=null;string? error=null;
   try{result=code[rid].Invoke(null,rid==0x4ca?[Input]:rid==0x341?[Ice,F("duration"),F("total"),Dev]:rid==0x599?[Talent,N("id")]:[Detail]);}catch(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;error=e.GetType().FullName;}
   object state=rid==0x4ca?new{source=Data(Input),result=result is PlantSave copy?Data(copy):null,root_distinct=result!=null&&!ReferenceEquals(Input,result),names_distinct=result is PlantSave cp&&!ReferenceEquals(Input.talentNames,cp.talentNames),talents_distinct=result is PlantSave ct&&!ReferenceEquals(Input.talents,ct.talents),strings_shared=result is PlantSave cs?new[]{ReferenceEquals(Input.name,cs.name),ReferenceEquals(Input.synopsis,cs.synopsis),ReferenceEquals(Input.description,cs.description),ReferenceEquals(Input.characteristicText,cs.characteristicText)}:null}:
    rid==0x341?new{root=Tag(Ice.gameObject),animator=Tag(Dev.animator),active=FirstGO.Active,other_active=OtherGO.Active,speed=FirstAnimator.Speed,other_speed=OtherAnimator.Speed}:
    rid==0x599?new{preview=Talent.previewID,buttons=ReferenceEquals(Talent.buttons,OtherButtons)?"other":"initial",save=Tag(Talent.plantSave),text_owner=Tag(Talent.talentDescription),enabled=Buttons.Select(x=>x.Enabled).ToArray(),other_enabled=OtherButtons.Select(x=>x.Enabled).ToArray(),text=Text.Last,force=Text.Force,other_text=OtherText.Last,other_force=OtherText.Force}:
    new{animator=Tag(Detail.animator),save=Tag(Detail.plantSave),button=Tag(Detail.button_previewOrderUp),interactable=Button.Interactable,other_interactable=OtherButton.Interactable,root=ReferenceEquals(Detail.suppliesItemList,OtherItems)?"other":"initial",initial=ListState(Items),other=ListState(OtherItems),destroyed=Destroyed.Order().ToArray()};
   rows.Add(new{name=q.GetProperty("name").GetString(),token=q.GetProperty("token").GetString(),error,trace=Trace.ToArray(),state});
  }
  File.WriteAllText(args[3],JsonSerializer.Serialize(new{scope="FIVE_COMPLETE_PREVIOUSLY_AUTHORED_R19_CIL_BODIES_CONTROLLED_ALLOCATIONS_AND_ENGINE_LEAVES",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),methods=5,results=rows,eh_removed=false,private_access_bypass=false,unity_or_product_acceptance=false},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{records=rows.Count,methods=5}));
 }
}
