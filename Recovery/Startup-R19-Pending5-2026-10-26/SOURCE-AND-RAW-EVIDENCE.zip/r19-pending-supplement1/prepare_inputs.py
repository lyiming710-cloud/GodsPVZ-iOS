"""Explicit inputs for five already-authored bodies, without candidate edits."""
from pathlib import Path
import collections,hashlib,itertools,json,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1]
def sha(b):return hashlib.sha256(b).hexdigest()
def js(p,v):p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
assert sha((W/'startup-r20-sites100/authored3.dll').read_bytes())=='d887b370c95c2966dc40d80648d85c286bb42d85004c32d095f64f004e095b37'
assert sha((W/'startup-r19-batch100/candidate9.dll').read_bytes())=='0ba5bc7ec9603d14a1c0bde6d784d232aa78efaa1700304e75e4f2b56ef7dec2'
assert sha((W/'startup-r5/runtime-common/Rehost.cs').read_bytes())=='59b1e80892d0038ee188f0ef36d1af25ce37ae6df71016ba6617cc221ca51d40'
ints='plantType stars ID clique order level skillLevel sunPrice defaultSkillID fashionSerialNumber'.split()
floats='replantCD healthPoint maxHealthPoint attackPoint armorPoint defensePoint attackInterva characteristicTicking characteristicMaxTicking'.split()
patterns=['00000000','80000000','3F800000','BF800000','7F800000','FF800000','7FC01234']
cases=[]
def add(rid,mode='none',native=True,**kw):
    seed=kw.get('seed',1);vals={name:seed*100+i+1 for i,name in enumerate(ints)};vals.update({name:patterns[(i+seed)%len(patterns)] for i,name in enumerate(floats)})
    cases.append(dict(name=f'p{len(cases):05d}',token=f'0x{0x6000000|rid:08X}',mode=mode,native_supported=native,values=vals,**kw))
for seed,length in itertools.product(range(1,8),[3,4,7]):add(0x4ca,seed=seed,length=length)
for missing in ['skill1','skill2','skill3','talents']:add(0x4ca,native=False,seed=1,length=3,missing=missing)
for length in [0,2]:add(0x4ca,native=False,seed=1,length=length)
for duration,obj,animator,mode in itertools.product(patterns,range(3),range(3),['none','exists-fields','active-fields','animator-fields']):
    add(0x341,mode=mode,duration=duration,total='7FC04321' if duration=='7FC01234' else '41200000',object=obj,animator=animator)
for ident,unlocked,select,mode in itertools.product([-2147483648,-1,0,1,2,3,2147483647],[-1,0,1,3],[0,5,7],['none','enable-fields','text-fields','update-fields']):
    add(0x599,mode=mode,id=ident,unlocked=unlocked,select=select,length=3)
add(0x599,native=False,id=0,unlocked=1,select=0,save=0,length=3)
for rid,items,order,level,mode in itertools.product([0x578,0x579],[0,1,3],[0,1],[9,20,30],['none','trigger-fields','bool-fields','close-fields','preview-fields','destroy-list','interact-list']):
    add(rid,mode=mode,items=items,order=order,level=level)
js(Q/'CASES.json',cases)
js(Q/'INPUTS.json',dict(scope='FIVE_ALREADY_AUTHORED_R19_METHOD_RUNTIME_SUPPLEMENT',r19_candidate_sha256=sha((W/'startup-r19-batch100/candidate9.dll').read_bytes()),
    current_r20_candidate_sha256=sha((W/'startup-r20-sites100/authored3.dll').read_bytes()),new_game_methods_or_positions=0,
    per_method=dict(collections.Counter(c['token'] for c in cases if c['native_supported'])),
    native_normal_cases=sum(c['native_supported'] for c in cases),managed_only_cases=sum(not c['native_supported'] for c in cases),
    allocations_and_engine_leaves_are_controlled=True,original_order_able_pure_leaf_left_executable=True,
    count_leaf_is_bounded_input_contract_not_full_GetTalentNum_Unlocked_acceptance=True,
    complete_candidate_cil_and_frozen_rehost=True,formal_or_product_acceptance=False))
print(json.dumps(json.loads((Q/'INPUTS.json').read_bytes())))
