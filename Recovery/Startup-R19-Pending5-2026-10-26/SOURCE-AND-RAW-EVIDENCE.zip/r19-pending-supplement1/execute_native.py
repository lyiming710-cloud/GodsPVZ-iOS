"""Keep process failures and diagnostics before evaluating any comparison."""
from pathlib import Path
import json,subprocess,sys
Q=Path(__file__).resolve().parent
attempt=int(sys.argv[1]);out=Q/f'native-attempt{attempt}';assert not (out.with_suffix('.process.json')).exists()
cmd=[sys.executable,str(Q/'native_oracle.py'),str(Q/'FULL-CIL-R20.json'),str(Q/f'NATIVE-ATTEMPT{attempt}.json'),'--trace-cases']
cp=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
out.with_suffix('.stdout.log').write_bytes(cp.stdout);out.with_suffix('.stderr.log').write_bytes(cp.stderr)
out.with_suffix('.process.json').write_bytes((json.dumps(dict(command=cmd,actual_exit=cp.returncode,
    result_file_exists=(Q/f'NATIVE-ATTEMPT{attempt}.json').is_file(),process_failure_never_counts_as_detection=True),indent=2)+'\n').encode())
print(json.dumps(dict(actual_exit=cp.returncode,result_file_exists=(Q/f'NATIVE-ATTEMPT{attempt}.json').is_file())))
print(cp.stdout.decode('utf-8',errors='replace')[-2200:]);print(cp.stderr.decode('utf-8',errors='replace')[-2200:])
raise SystemExit(0 if cp.returncode==0 else 1)
