"""Resolve native addresses using every original metadata image, not a two-image map."""
import importlib.util, json, struct
import source_common as s

path=s.ROOT/'audit/actions-cleanup-2026-10-02/repository/Tools/MethodIndexDump/native_map.py'
spec=importlib.util.spec_from_file_location('original_metadata_codegen_reader',path)
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
meta=(s.I/'original-pc/global-metadata.dat').read_bytes()
assert s.sha(meta)=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9'
pe=mod.PE(s.raw); so,_=mod.pair(meta,mod.STRINGS);io,ic=mod.pair(meta,mod.IMAGES)
targets={int(r['operands'],16) for rid in [0xe4,0xe7,0x2a8,0x2ab,0x2c2,0x309,0x30a,0x335]
         for r in s.native(s.tok(rid))['instructions']
         if r['op'] in ['call','jmp'] and r['operands'].startswith('0x')}
maps={};modules=[];unsupported=[]
for off in range(io,io+ic,mod.IMAGE_SIZE):
    image=mod.cstr(meta,so+mod.i32(meta,off))
    methods=mod.metadata_methods(meta,image)
    if not methods:continue
    try:nameva,count,tableva,tableoff=mod.find_codegen(s.raw,pe,image,len(methods))
    except ValueError as ex:unsupported.append(dict(image=image,error=str(ex)));continue
    modules.append(dict(image=image,count=count,table_va=hex(tableva)))
    for rid,token,owner,name,argc in methods:
        va=mod.u64(s.raw,tableoff+(rid-1)*8)
        if va in targets:
            maps.setdefault(hex(va),[]).append(dict(image=image,token=f'0x{token:08X}',owner=owner,name=name,args=argc,table_va=hex(tableva)))
result=dict(scope='ORIGINAL_METADATA_AND_NATIVE_CODEGEN_DIRECT_API_IDENTITY_READ_ONLY',
    original_pc_sha256=s.sha(s.raw),original_metadata_sha256=s.sha(meta),
    reader_sha256=s.sha(path.read_bytes()),resolved=maps,modules=modules,unsupported=unsupported,
    unregistered_native_targets=[hex(x)for x in sorted(targets)if hex(x)not in maps])
(s.Q/'ORIGINAL-DIRECT-API-IDENTITIES.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
assert any(r['name']=='SetBool' and r['args']==2 and r['owner']=='UnityEngine.Animator' for r in maps['0x1812dba00'])
print(json.dumps(dict(images=len(modules),resolved_targets=len(maps),unregistered=len(result['unregistered_native_targets']),set_bool=maps['0x1812dba00'])))
