"""Correct the R22 runtime failures with source-bound edits; keep all old bodies."""
import json, sys
import source_common as s
from construction import Context

c=Context()

def field(b, name):
    return b.arg(0).token(0x7b,c.fld('Device',name))

def clone(rid, patches, skipped=()):
    token=s.tok(rid); b=c.begin(rid); m=s.methods[token]; raw=s.body(token)['code']
    assert not m['handlers'], 'No implicit exception-region rewriting'
    for k,ins in enumerate(m['instructions']):
        at=ins['offset']; end=m['instructions'][k+1]['offset'] if k+1<len(m['instructions']) else len(raw)
        b.mark(at)
        if at in patches:
            patches[at](b)
        elif any(a<=at<z for a,z in skipped):
            # Every removed label remains addressable, but no branch is allowed
            # to enter the middle of the replaced arithmetic region.
            assert not any(isinstance(i['operand'],dict) and i['operand'].get('target')==at for i in m['instructions'])
        elif isinstance(ins['operand'],dict) and 'target' in ins['operand']:
            op=raw[at]
            if 0x2b<=op<=0x37: op+=0xd
            elif op==0xde: op=0xdd
            b.branch(op,ins['operand']['target'])
        elif ins['opcode']=='switch':
            raise AssertionError('Switch reconstruction requires an explicit switch plan')
        else:b.emit(raw[at:end])
    b.mark(len(raw))
    return b

# Exact original AnimationModule CodeGenModule lookup, independent of the
# incomplete two-image map formerly used in R22.
apis=json.loads((s.Q/'ORIGINAL-DIRECT-API-IDENTITIES.json').read_bytes())
assert any(r['owner']=='UnityEngine.Animator' and r['name']=='SetBool' and r['args']==2
           for r in apis['resolved']['0x1812dba00'])
rid=0x2ab; original=s.methods[s.tok(rid)]
trigger=next(i for i in original['instructions'] if i['opcode']=='callvirt' and i['operand'].get('owner')=='UnityEngine.Animator')
assert trigger['operand']['name']=='SetTrigger' and trigger['operand']['args']==['System.String']
at=trigger['offset']; tok=c.meth('UnityEngine.Animator','SetBool',('System.String','System.Boolean'))
b=clone(rid,{at:lambda b:b.site(0x18032925b,'CALL',
    'Original Animator.SetBool(string,false), not SetTrigger; the hide parameter is a bool defaulting to true',
    lambda x:x.op('16').token(0x6f,tok))})
c.add(rid,b,'Correct exact original two-argument AnimationModule API and original false value',group='runtime-correction-original-animator-bool')

def device_update():
    rid=0x309; m=s.methods[s.tok(rid)]; ins={i['offset']:i for i in m['instructions']}
    patches={}
    for at,va in [(0x177,0x18034c989),(0x1c0,0x18034c9a7),(0x283,0x18034c96f)]:
        assert ins[at]['opcode']=='ldc.i4' and ins[at]['operand']==0
        patches[at]=lambda b,va=va:b.site(va,'CONTROL_FLOW','Compare float operands with a real single-precision zero, preserving the original SSE comparison type',lambda x:x.r4(0))
    assert ins[0x1c9]['opcode']=='clt'
    patches[0x1c9]=lambda b:b.site(0x18034c9b3,'CONTROL_FLOW',
        'Native ordered 0>=remaining resets only finite/non-NaN expiration; unordered continues the original arithmetic',lambda x:x.op('fe05'))
    def snapshot(b):
        b.site(0x18034c996,'FIELD_READ','Capture brightTime before the deltaTime API, including callback-induced field mutation',lambda x:field(x,'brightTime').store(22))
        b.token(0x28,c.meth('UnityEngine.Time','get_deltaTime'))
    patches[0x19c]=snapshot
    patches[0x1a5]=lambda b:b.loc(22).loc(19).op('59')
    # The native qword store clears BOTH contiguous f32 fields f8/fc.
    oldtoken=s.operand_token(s.tok(rid),ins[0x235])
    patches[0x235]=lambda b:b.token(0x7d,oldtoken).site(0x18034c9d6,'FIELD_WRITE',
        'Restore both brightEffectTime and brightTime zeroed by the native qword store',lambda x:x.arg(0).r4(0).token(0x7d,c.fld('Device','brightTime')))
    b=clone(rid,patches,[(0x1a6,0x1b2)])
    c.add(rid,b,'Correct three mixed I4/F comparisons, preserve NaN expiration behavior and pre-API brightTime snapshot, restore missing brightTime reset',group='runtime-correction-device-update')

def device_brightness():
    rid=0x30a;m=s.methods[s.tok(rid)];ins={i['offset']:i for i in m['instructions']}
    assert ins[0x5d]['opcode']=='clt'
    def snapshot(b):
        b.site(0x18034bf0f,'FIELD_READ','Capture standalone brightTime before the deltaTime API',lambda x:field(x,'brightTime').store(8))
        b.token(0x28,c.meth('UnityEngine.Time','get_deltaTime'))
    oldtoken=s.operand_token(s.tok(rid),ins[0xd4])
    patches={0x30:snapshot,0x39:lambda b:b.loc(8).loc(5).op('59'),
        0x5d:lambda b:b.site(0x18034bf2c,'CONTROL_FLOW','Preserve ordered native expiration and unordered NaN arithmetic in the standalone method',lambda x:x.op('fe05')),
        0xd4:lambda b:b.token(0x7d,oldtoken).site(0x18034bf5b,'FIELD_WRITE','Restore both f32 fields cleared by original qword store',lambda x:x.arg(0).r4(0).token(0x7d,c.fld('Device','brightTime')))}
    b=clone(rid,patches,[(0x3a,0x46)])
    c.add(rid,b,'Match the standalone brightness native snapshot, NaN branch, and two-field expiry reset',group='runtime-correction-device-brightness')

device_update();device_brightness();stem=sys.argv[1];c.save_authored(stem)
p=s.Q/(stem+'.json');report=json.loads(p.read_bytes())
report.update(scope='R22_POST_RUNTIME_CORRECTION_NOT_A_NEW_HUNDRED_POSITION_BATCH',
    correction_of_actual_run=40456165422,
    prior_completed_authoring_cohort=dict(batch='R22',positions=112,methods=5),
    additional_distinct_source_corrections=len(c.sites),
    shared_test_reason='Retest a failed completed cohort after exact source corrections; no claim of 100 new repairs',
    known_not_fixed=['Actual Device.InjuryStatusUpdate NRE cause still under investigation',
        'Loaded VisualScripting ComponentHolderProtocol default-return methods',
        'Normal modal OS input handling and inactive observation volume in gameplay helper'])
p.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(candidate_sha256=report['candidate_sha256'],positions=len(c.sites),methods=len(report['changes']))))
