"""New scoped correction checks; old frozen checkers and evidence remain unchanged."""
from pathlib import Path
import json, shutil
import source_common as s

old=s.W/'startup-r22-board-loop'
for name in ['run_static.py','run_exact_jit.py','verify_isolation.py']:
    text=(old/name).read_text(encoding='utf-8')
    text=text.replace("report['new_unique_methods']==5 and report['new_unique_repair_positions']>100", "report['new_unique_methods']==3 and report['additional_distinct_source_corrections']==10 and report['prior_completed_authoring_cohort']['positions']==112")
    text=text.replace("len(report['changes'])==5 and report['new_unique_repair_positions']>100", "len(report['changes'])==3 and report['additional_distinct_source_corrections']==10")
    text=text.replace('startup-r21-ui-batch100/authored1.dll','startup-r22-board-loop/authored2.dll')
    text=text.replace('75160a3233f1e1ab13a44f712efb4b47fdeb9b57bd38fa25f180276bb7b50e15','15e0150337a14f1613321385af2d9b1997abd1bc255d56abe4a4ce2c5f7ac2cf')
    text=text.replace('len(targets)==5','len(targets)==3')
    text=text.replace('changed_methods=5,unchanged_methoddefs=2312','changed_methods=3,unchanged_methoddefs=2314')
    text=text.replace('EXACT_CANDIDATE_FIVE_METHOD_112_POSITION','EXACT_THREE_METHOD_POST_RUNTIME_CORRECTION')
    (s.Q/name).write_text(text,encoding='utf-8')
for name in ['ALL-METHODS.json','CASES.json','ORIGINAL-OPERAND-RESOLUTION.json']:
    shutil.copyfile(old/name,s.Q/name)
for rid in [0xe4,0xe7,0x2a8,0x2ab,0x2c2]:s.save_native(rid)
runtime=s.Q/'board-runtime';runtime.mkdir(exist_ok=True)
for name in ['RehostExact.cs','Fixture.csproj']:shutil.copyfile(old/'runtime'/name,runtime/name)
text=(old/'runtime/Program.cs').read_text(encoding='utf-8')
assert text.count('public class Animator:Component {public void SetTrigger(string s)=>Program.Log("trigger",this,s);}')==1
text=text.replace('public class Animator:Component {public void SetTrigger(string s)=>Program.Log("trigger",this,s);}',
    'public class Animator:Component {public bool Hidden=true;public void SetTrigger(string s)=>Program.Log("trigger",this,s);public void SetBool(string s,bool v){Program.Log("bool",this,s,v);Hidden=v;}}')
text=text.replace('cardHidden=B.cardBankHidden,','cardHidden=B.cardBankHidden,bankAnimatorHidden=K.animator.Hidden,')
(runtime/'Program.cs').write_text(text,encoding='utf-8')
text=(old/'native_compare.py').read_text(encoding='utf-8')
text=text.replace("mode=q['mode'],q=q)","mode=q['mode'],q=q,anim_hidden=True)")
assert text.count("im.hook(0x1812dba00,None,[P,P,P],lambda p,s,m:log('trigger',tag(p),state['strings'][s]))")==1
text=text.replace("im.hook(0x1812dba00,None,[P,P,P],lambda p,s,m:log('trigger',tag(p),state['strings'][s]))",
    "im.hook(0x1812dba00,None,[P,P,C.c_bool,P],lambda p,s,v,m:(log('bool',tag(p),state['strings'][s],bool(v)),state.update(anim_hidden=bool(v))) and None)")
text=text.replace("cardHidden=bool(C.c_ubyte.from_address(b+0x138).value),", "cardHidden=bool(C.c_ubyte.from_address(b+0x138).value),bankAnimatorHidden=state['anim_hidden'],")
assert "bankAnimatorHidden=state['anim_hidden']"in text
text=text.replace("FIVE_UNMODIFIED_PC_CALLERS_VS_EXACT_RAW_CIL_AND_EH_NORMAL_CONTROLLED_LEAF_PROFILES_ONLY", "R22_CORRECTION_ORIGINAL_FIVE_CALLERS_WITH_EXACT_SETBOOL_ABI_AND_STATE")
(s.Q/'board_native_compare.py').write_text(text,encoding='utf-8')
(s.Q/'SHARED-TEST-START.json').write_text(json.dumps(dict(scope='CORRECTION_OF_PREVIOUS_COMPLETED_112_POSITION_COHORT_NOT_NEW_100_POSITION_CLAIM',actual_failed_run=40456165422,correction_methods=3,source_corrections=10,old_frozen_checkers_unchanged=True),indent=2)+'\n',encoding='utf-8')
print('SCOPED_CORRECTION_CHECK_PREPARATION_COMPLETE')
