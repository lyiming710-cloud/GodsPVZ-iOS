"""Execute five untouched PC callers with explicit controlled callees.
Normal paths only. The three injected managed-throw/finally cases are excluded
from native comparison rather than pretending to emulate Windows C++ unwind.
"""
from pathlib import Path
import sys,json,struct,collections,ctypes as C
S=Path(__file__).resolve().parent;W=S.parent;sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
cases=json.loads((S/'CASES.json').read_bytes());actual=json.loads(Path(sys.argv[1]).read_bytes());byname={r['name']:r for r in actual['results']};spec=json.loads((S/'ORIGINAL-OPERAND-RESOLUTION.json').read_bytes());class_slots={r['resolved']['slot_va']:r['resolved']['class']for d in spec for r in d['rows']if isinstance(r['resolved'],dict)and'class'in r['resolved']}
scenario=['Daytime','Night','Secretforest','Foggymoon','Season','Moonbeams','Sky','Abyss','Snowfield','Twilight','DarkSnowfield'];state={};rows=[];limitations=[]
def n(q,k,default=0):
 v=q.get(k,default);return float(str(v).replace('Inf','inf'))
def f32(v):return struct.unpack('<f',struct.pack('<f',v))[0]
def fmt(v):return 'NaN'if v!=v else struct.pack('<f',v)[::-1].hex().upper()
def vec(v):return ','.join(fmt(x)for x in v)
def tag(p):return 'null'if not p else state['objects'][p]['tag']
def log(*args):state['trace'].append(':'.join('1'if a is True else'0'if a is False else'null'if a is None else str(a).replace('\\','/')for a in args))
def obj(label,kind='UObj',size=512):
 p=im.alloc(size);state['objects'][p]=dict(tag=label,kind=kind,alive=True);state['tags'][label]=p
 if kind=='GameObject':state['objects'][p].update(transform=obj(label+'-tr','Transform'),active=True,reads=0)
 elif kind=='Transform':state['objects'][p].update(parent=0,pos=(0.,0.,0.),scale=(2.,3.,4.))
 elif kind in['Board','Banks','Camera','SpriteRenderer','AudioSource','Animator','MouseManager','DeviceManager','SunManager','EnemyManager','FlagMeter','Card','Prop']:state['objects'][p]['go']=obj(label+'-go','GameObject')
 return p
def seq(items,kind):
 p=im.alloc(64);a=im.alloc(32+8*len(items));put64(p+0x10,a);put32(p+0x18,len(items));put32(a+0x18,len(items))
 for k,item in enumerate(items):put64(a+0x20+8*k,item)
 state['seq'][p]=dict(items=items,kind=kind);return p
def arr(items):
 p=im.alloc(32+8*len(items));put32(p+0x18,len(items))
 for k,item in enumerate(items):put64(p+0x20+8*k,item)
 return p
def string(text):p=im.alloc(32+len(text.encode('utf-16-le')));state['strings'][p]=text;return p
def getgo(p,method):
 log('gameObject',tag(p))
 if state['mode']=='ordinal-callback'and state['objects'][p]['kind']=='Card':put32(p+0x58,99)
 return state['objects'][p]['go']
def transform(p,method):log('transform',tag(p));return state['objects'][state['objects'][p]['go']]['transform']
def gotransform(p,method):
 log('goTransform',tag(p));o=state['objects'][p];o['reads']+=1
 return state['tags']['other-transform']if state['mode']=='effect-transform'and tag(p)=='ready-clone'and o['reads']==2 else o['transform']
def parent(p,other,stay,method):log('parent',tag(p),tag(other),bool(stay));state['objects'][p]['parent']=other
def getvector(kind,label):
 def get(out,p,method):log(label,tag(p));C.memmove(out,struct.pack('<3f',*state['objects'][p][kind]),12);return out
 return get
def setvector(kind,label):
 def setter(p,value,method):v=struct.unpack('<3f',C.string_at(value,12));log(label,tag(p),vec(v));state['objects'][p][kind]=v
 return setter
def item(p,i,method):q=state['seq'][p];log('item',q['kind'],i);return q['items'][i]
def getenum(out,p,method):log('getEnum');put64(out,p);put32(out+8,0);put32(out+12,0);put64(out+16,0);return out
def move(p,method):
 seqp=get64(p);i=get32(p+8);items=state['seq'][seqp]['items'];v=i<len(items);log('move',v)
 if v:put64(p+16,items[i]);put32(p+8,i+1)
 return v
def presence(kind):
 def call(a,b=None,method=None):
  if kind=='implicit':v=bool(a and state['objects'][a]['alive']);log(kind,tag(a),v)
  else:
   v=(not(a and state['objects'][a]['alive'])and not(b and state['objects'][b]['alive']))or a==b
   if kind=='ne':v=not v
   log(kind,tag(a),tag(b),v)
  return v
 return call
def setup(q):
 state.clear();state.update(objects={},tags={},seq={},strings={},trace=[],mode=q['mode'],q=q,anim_hidden=True)
 for label,kind in [('board','Board'),('banks','Banks'),('bank-anim','Animator'),('mouse','MouseManager'),('devices','DeviceManager'),('sun','SunManager'),('bottom-buttons','GameObject'),('meter-parent','GameObject'),('card-parent','GameObject'),('last-page','GameObject'),('next-page','GameObject'),('prop-bank','GameObject'),('background','SpriteRenderer'),('other-background','SpriteRenderer'),('bgm','AudioSource'),('camera','Camera'),('other-transform','Transform'),('background-sprite','Sprite'),('positional-audio','AudioSource'),('enemy-prefab','GameObject'),('enemy-clone','GameObject'),('enemy','EnemyManager'),('ready-prefab','GameObject'),('ready-clone','GameObject'),('meter-prefab','FlagMeter'),('meter-clone','FlagMeter')]:obj(label,kind)
 t=state['tags'];b=t['board'];k=t['banks'];state['b']=b;state['k']=k
 camera_tr=state['objects'][state['objects'][t['camera']]['go']]['transform'];state['objects'][camera_tr]['pos']=(7.,8.,9.);state['objects'][t['other-transform']]['scale']=(5.,6.,7.)
 config=im.alloc(128);mp=im.alloc(64);state['config']=config;state['map']=mp;put32(mp+0x18,q.get('scenario',0));putf(mp+0x1c,n(q,'camera',540));put64(config+0x20,im.alloc(64));state['int_list']=get64(config+0x20);put32(config+0x28,12);put32(config+0x38,3);put32(config+0x3c,30);put32(config+0x40,1500)
 put64(b+0x28,0 if q.get('no_config')else config);put64(b+0x30,mp);put64(b+0xa0,0 if q.get('no_buttons')else t['bottom-buttons']);put64(b+0x60,t['meter-parent']);put64(b+0x50,t['background']);put64(b+0x110,t['mouse']);put64(b+0x108,t['devices']);put64(b+0x120,t['sun']);put64(b+0x118,t['enemy']);put64(b+0x128,0 if q.get('no_bank')else k);put64(b+0x140,arr([t['bgm']]));C.c_ubyte.from_address(b+0x41).value=q.get('started',False);C.c_ubyte.from_address(b+0x39).value=q.get('won',False);C.c_ubyte.from_address(b+0x138).value=q.get('hidden',True);putf(b+0x4c,n(q,'countdown',5))
 put64(k+0x20,b);put64(k+0x28,t['bank-anim']);put64(k+0xa8,t['card-parent']);put64(k+0x90,t['last-page']);put64(k+0x98,t['next-page']);put64(k+0x50,0 if q.get('no_prop_bank')else t['prop-bank']);put32(k+0xa0,q.get('page',0));put32(k+0xa4,88)
 cards=[]
 for i in range(q.get('cards',1)):
  p=obj('card-'+str(i),'Card');put32(p+0x58,77);C.c_ubyte.from_address(p+0x54).value=1;cards.append(p)
 state['cards']=cards;put64(k+0x30,seq(cards,'Card'));put32(k+0x44,q.get('cardNum',len(cards)));props=[]
 for i in range(q.get('props',0)):
  p=obj('prop-'+str(i),'Prop');state['objects'][p]['key']=-1;props.append(p)
 state['props']=props;put64(k+0x68,seq(props,'Prop'))
 clips={}
 for group in['bgm','board-clip']:
  clips[group]=seq([obj(group+'-'+str(i),'AudioClip')for i in range(20)],'AudioClip')
 sf=statics['ResourceManager'];put64(sf+0xf8,clips['bgm']);put64(sf+0x100,clips['board-clip']);put64(sf+0x208,t['ready-prefab']);put64(sf+0x210,t['meter-prefab']);app=im.alloc(64);putf(app+0x14,.25);put64(statics['GlobalStaticVars'],app)
def snapshot():
 b=state['b'];k=state['k'];t=state['tags'];e=get64(b+0x118)
 objects=[dict(tag=o['tag'],parent=tag(o['parent']),position=vec(o['pos']),scale=vec(o['scale']))for o in state['objects'].values()if o['kind']=='Transform'and(o['parent']or o['tag']in['ready-clone-tr','other-transform','meter-clone-go-tr'])]
 objects.sort(key=lambda r:r['tag'])
 return dict(gameStart=bool(C.c_ubyte.from_address(b+0x41).value),countdown=fmt(getf(b+0x4c)),cardHidden=bool(C.c_ubyte.from_address(b+0x138).value),bankAnimatorHidden=state['anim_hidden'],sun=get32(t['sun']+0x20),enemy=tag(e),enemyBoard=tag(get64(e+0x80)),enemyFlags=get32(e+0x48),enemyWaves=get32(e+0x4c),enemyPoint=get32(e+0x38),enemyTypes=[1,2,3]if get64(e+0x30)else None,cardNum=get32(k+0x44),page=get32(k+0xa0),maxPage=get32(k+0xa4),background=tag(get64(b+0x50)),originalSprite=tag(state['objects'][t['background']].get('sprite')),otherSprite=tag(state['objects'][t['other-background']].get('sprite')),meter=tag(get64(b+0x130)),objects=objects,cards=[dict(tag=tag(p),ordinal=get32(p+0x58),onBank=bool(C.c_ubyte.from_address(p+0x54).value))for p in state['cards']],props=[dict(tag=tag(p),key=state['objects'][p]['key'])for p in state['props']])
for rid in[0xe4,0xe7,0x2a8,0x2ab,0x2c2]:
 im=NativeImage();statics={};cfg=json.loads((S/'native-source-complete'/f'0x{0x6000000|rid:08X}.json').read_bytes());dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True;slots=set();literal_slots={};class_names={}
 # Source metadata slot decoding is independent of the candidate's tables.
 for d in spec:
  for r in d['rows']:
   v=r['resolved']
   if isinstance(v,dict)and'class'in v:class_names[int(v['slot_va'],16)]=v['class']
   if isinstance(v,dict)and'string'in v:literal_slots[int(v['slot_va'],16)]=v['string']
 for r in cfg['instructions']:
  i=next(dis.disasm(bytes.fromhex(r['bytes']),int(r['va'],16)))
  for op in i.operands:
   if op.type==X86_OP_MEM and op.mem.base==X86_REG_RIP:
    at=i.address+i.size+op.mem.disp;encoded=int.from_bytes(im.pe.get_data(at-im.base,8),'little')
    if at in class_names and encoded<=0xffffffff and encoded>>29==1 and encoded&1:slots.add(at)
 for at in slots:
  name=class_names.get(at,'unused-'+hex(at));cls=im.alloc(512);sf=im.alloc(4096);put64(cls+0xb8,sf);put32(cls+0xe0,1);put64(at,cls);statics[name]=sf
 # Canonicalize repeated references to the same metadata class slot.
 assert 'ResourceManager'in statics or rid in[0xe4,0xe7]
 if 'ResourceManager'not in statics:statics['ResourceManager']=im.alloc(4096)
 if 'GlobalStaticVars'not in statics:statics['GlobalStaticVars']=im.alloc(4096)
 im.hook(0x18024fef0,None,[P],lambda p:None);im.hook(0x1802501e0,None,[P],lambda p:None)
 im.hook(0x18131f760,C.c_bool,[P,P,P],presence('eq'));im.hook(0x18131f900,C.c_bool,[P,P,P],presence('ne'));im.hook(0x18131f870,C.c_bool,[P,P],lambda p,m:presence('implicit')(p))
 im.hook(0x181304510,P,[P,P],transform);im.hook(0x1813044d0,P,[P,P],getgo);im.hook(0x18131c070,P,[P,P],gotransform);im.hook(0x18132e900,None,[P,P,C.c_bool,P],parent)
 im.hook(0x18132f3a0,P,[P,P,P],getvector('pos','position'));im.hook(0x18132f1b0,P,[P,P,P],getvector('scale','getScale'));im.hook(0x18132f910,None,[P,P,P],setvector('pos','localPosition'));im.hook(0x18132fa50,None,[P,P,P],setvector('scale','setScale'))
 def active(p,v,m):log('active',tag(p),bool(v));state['objects'][p]['active']=bool(v)
 im.hook(0x18131bad0,None,[P,C.c_bool,P],active)
 im.hook(0x180825710,P,[P,I,P],item);im.hook(0x1808197f0,P,[P,P,P],getenum);im.hook(0x180669280,C.c_bool,[P,P],move);im.hook(0x180302170,None,[P,P],lambda p,m:log('dispose'))
 im.hook(0x180300d80,None,[P,I,I,P],lambda p,a,b,m:log('compare',a,b));im.hook(0x180344e90,None,[P,C.c_bool,P],lambda p,v,m:log('cardStart',tag(p),bool(v)))
 def propkey(p,i,m):log('propKey',tag(p),i);state['objects'][p]['key']=i
 im.hook(0x18037ea40,None,[P,I,P],propkey)
 im.hook(0x180321170,None,[P,P],lambda p,m:log('resetMouse',tag(p)))
 def combine3(a,b,c,m):return string(state['strings'][a]+'\\'+state['strings'][b]+'\\'+state['strings'][c])
 im.hook(0x180c84b90,P,[P,P,P,P],combine3);im.hook(0x180c84600,P,[P,P,P],lambda a,b,m:string(state['strings'][a]+'\\'+state['strings'][b]))
 def load(p,method):
  path=state['strings'][p];kind='GameObject'if 'EnemyManager'in path else'Sprite';log('load',kind,path)
  if kind=='Sprite'and state['mode']=='load-bg':put64(state['b']+0x50,state['tags']['other-background'])
  return state['tags']['enemy-prefab'if kind=='GameObject'else'background-sprite']
 im.hook(0x18047ba00,P,[P,P],load)
 def instantiate(p,m):log('instantiate',tag(p));return state['tags'][{'enemy-prefab':'enemy-clone','ready-prefab':'ready-clone','meter-prefab':'meter-clone'}[tag(p)]]
 im.hook(0x1804a0690,P,[P,P],instantiate);im.hook(0x18046dc80,P,[P,P],lambda p,m:(log('component',tag(p),'EnemyManager'),state['tags']['enemy'])[1])
 im.hook(0x18030ebb0,P,[P,P],lambda p,m:(log('createMap'),state['map'])[1]);im.hook(0x1812e27c0,P,[P],lambda m:(log('main'),state['tags']['camera'])[1]);im.hook(0x1812e2e80,None,[P,F,P],lambda p,v,m:log('cameraSize',tag(p),fmt(v)))
 im.hook(0x1812dc410,None,[P,P,P],lambda p,v,m:log('clip',tag(p),tag(v)))
 im.hook(0x180340990,None,[P,P,P,P],lambda p,c,m,x:log('sunFall',tag(p)));im.hook(0x1803136f0,None,[P,P,P,P],lambda p,c,m,x:log('preDevices',tag(p)));im.hook(0x180301a80,None,[P,P,P],lambda p,c,m:log('preCards'));im.hook(0x180300700,None,[P,P],lambda p,m:log('entryEffects'));im.hook(0x1812e68f0,None,[P,P],lambda p,m:log('debug',state['strings'][p]))
 im.hook(0x180ccee30,P,[P,P],lambda p,m:p)
 def box(cls,value):p=im.alloc(32);put32(p+0x10,get32(value));return p
 im.hook(0x18024f340,P,[P,P],box);im.hook(0x180cdcd20,P,[P,P,P],lambda t,v,m:string(scenario[get32(v+0x10)]))
 def sprite(p,v,m):log('sprite',tag(p),tag(v));state['objects'][p]['sprite']=v
 im.hook(0x1813290f0,None,[P,P,P],sprite)
 if rid!=0x2ab:
  im.hook(0x180328db0,None,[P,P],lambda p,m:log('popups'));im.hook(0x1803282b0,None,[P,P],lambda p,m:log('keys'));im.hook(0x180328f30,None,[P,P],lambda p,m:log('won'))
 else:
  im.hook(0x180328db0,None,[P,P],lambda p,m:log('popups'));im.hook(0x1803282b0,None,[P,P],lambda p,m:log('keys'));im.hook(0x180328f30,None,[P,P],lambda p,m:log('won'))
 im.hook(0x18132c2f0,F,[P],lambda m:(log('deltaTime'),f32(n(state['q'],'delta',.1)))[1]);im.hook(0x1812dba00,None,[P,P,C.c_bool,P],lambda p,s,v,m:(log('bool',tag(p),state['strings'][s],bool(v)),state.update(anim_hidden=bool(v))) and None);im.hook(0x18031aea0,F,[P],lambda m:(log('audioVolume'),.75)[1])
 im.hook(0x18031b230,P,[P,P,F,P],lambda p,v,f,m:(log('audioAt',tag(p),vec(struct.unpack('<3f',C.string_at(v,12))),fmt(f)),state['tags']['positional-audio'])[1])
 if rid!=0x2c2:im.hook(0x180326bd0,None,[P,P],lambda p,m:log('gameStartLeaf'))
 if rid!=0xe4:im.hook(0x180300530,None,[P,P],lambda p,m:log('bankStart'))
 im.hook(0x18039ce70,None,[P,P,P],lambda p,e,m:log('meterInit',tag(p),tag(e)));im.hook(0x1812dc4b0,None,[P,F,P],lambda p,f,m:log('volume',tag(p),fmt(f)));im.hook(0x1812dc300,None,[P,P],lambda p,m:log('play',tag(p)))
 try:
  im.verify_caller(rid,int(cfg['entry'],16),cfg)
  for q in cases:
   if(int(q['token'],16)&0xffffff)!=rid:continue
   if q['mode']=='throw-parent':limitations.append(dict(name=q['name'],status='NATIVE_WINDOWS_EXCEPTION_UNWIND_NOT_EXECUTED',managed_finally_observed='dispose'in byname[q['name']]['trace']));continue
   setup(q)
   for at,text in literal_slots.items():put64(at,string(text))
   C.CFUNCTYPE(None,P,P)(int(cfg['entry'],16))(state['k']if rid in[0xe4,0xe7]else state['b'],None)
   assert not im.errors,(q['name'],im.errors)
   rows.append(dict(name=q['name'],token=q['token'],error=None,trace=list(state['trace']),state=snapshot()))
 finally:im.close()
diff=[dict(original=r,actual=byname[r['name']])for r in rows if r!=byname[r['name']]]
report=dict(scope='R22_CORRECTION_ORIGINAL_FIVE_CALLERS_WITH_EXACT_SETBOOL_ABI_AND_STATE',candidate_sha256=actual['candidate_sha256'],records=len(rows),per_method=dict(collections.Counter(r['token']for r in rows)),results=rows,differences=diff,caller_byte_checks=5,callback_errors=[],exception_limits=limitations,controlled_leaves=['Unity engine accessors/rendering/audio/objects','nested game callees, loaders and path/enum helpers','List operations including explicit normal-path Dispose observation','initialized metadata/class scaffolding'],not_unity_or_ios_execution=True,universal_semantic_equivalence=False)
Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(records=len(rows),differences=len(diff),exception_limits=len(limitations))))
if diff:print(json.dumps(diff[0],ensure_ascii=True)[:6000]);raise SystemExit(1)
