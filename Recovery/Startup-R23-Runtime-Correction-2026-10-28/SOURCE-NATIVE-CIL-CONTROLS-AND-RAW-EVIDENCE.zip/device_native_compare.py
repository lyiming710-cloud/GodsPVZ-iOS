"""Untouched original Device native callers against actual emitted candidate CIL."""
from pathlib import Path
import ctypes as C, json, struct, sys, collections
Q=Path(__file__).resolve().parent;W=Q.parent
sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import NativeImage,P,F,put64,get64,putf,getf,number,bits
actual=json.loads(Path(sys.argv[1]).read_bytes());by={r['name']:r for r in actual['results']}
cases=json.loads((Q/'DEVICE-CASES.json').read_bytes());rows=[]
for rid in [0x309,0x30a]:
 im=NativeImage();im.install_metadata();state={}
 cfg=json.loads((Q/'native-source-complete'/f'0x{0x6000000|rid:08X}.json').read_bytes())
 def log(*args):state['trace'].append(':'.join(str(x)for x in args))
 def obj(tag):
  p=im.alloc(512);state['tags'][p]=tag;return p
 def transform(p,m):log('transform',state['tags'][p]);return state['transforms'][p]
 def position(out,p,m):
  log('position',state['tags'][p]);C.memmove(out,struct.pack('<3f',*state['positions'][p]),12);return out
 def delta(m):
  log('deltaTime');state['calls']+=1
  if state['q']['mode']=='mutate-time'and state['calls']==(2 if rid==0x309 else 1):putf(state['d']+0xfc,123)
  return state['delta']
 def bright(p,v,m):log('brightness',bits(v));state['brightness']=v
 im.hook(0x18131f760,C.c_bool,[P,P,P],lambda a,b,m:not bool(a and state['alive'].get(a,True)))
 im.hook(0x181304510,P,[P,P],transform);im.hook(0x18131c070,P,[P,P],transform)
 im.hook(0x18132f3a0,P,[P,P,P],position);im.hook(0x18132c2f0,F,[P],delta)
 im.hook(0x18034bfd0,None,[P,P],lambda p,m:log('characteristic'))
 im.hook(0x18034c3e0,None,[P,P],lambda p,m:log('events'))
 im.hook(0x18034cde0,None,[P,P,P],lambda p,d,m:log('hp',state['tags'][d]))
 im.hook(0x18034d610,None,[P,F,F,P,C.c_bool,P],lambda p,ice,max_,d,b,m:log('ice',bits(ice),bits(max_),state['tags'][d],'1'if b else'0'))
 # Original mscorlib Math.Max(single,single) receives method info in r8.
 def maximum(a,b,m):
  return a if a>b else a if a!=a else b
 im.hook(0x180ca5fc0,F,[F,F,P],maximum);im.hook(0x18034a0b0,None,[P,F,P],bright)
 try:
  im.verify_caller(rid,int(cfg['entry'],16),cfg)
  for q in cases:
   if int(q['token'],16)&0xffffff!=rid:continue
   state.clear();state.update(q=q,trace=[],tags={},transforms={},positions={},alive={},calls=0,delta=number(str(q['delta'])),brightness=-99)
   d=obj('device');state['d']=d;board=obj('board');put64(d+0x28,0 if q['mode']=='no-board'else board);state['alive'][board]=q['mode']!='destroyed-board'
   for tag,off,xyz in [('device',None,(11,12,13)),('group',0xc0,(21,24,25)),('shadow',0xd0,(31,34,35))]:
    p=d if off is None else obj(tag);t=obj(tag+'-tr');state['transforms'][p]=t;state['positions'][t]=xyz
    if off is not None:put64(d+off,p)
   put64(d+0x118,obj('ice-ui'));put64(d+0x120,obj('hp-ui'))
   for off,val in [(0x38,-1),(0x3c,-2),(0x40,-3),(0x44,-4),(0x98,.5),(0x88,17),(0x8c,6000),(0xf8,q['duration']),(0xfc,q['remaining']),(0x100,q['intensity'])]:putf(d+off,number(str(val)))
   C.c_ubyte.from_address(d+0x104).value=int(q['selected'])
   C.CFUNCTYPE(None,P,P)(int(cfg['entry'],16))(d,None)
   assert not im.errors,(q['name'],im.errors)
   out=dict(fX=bits(getf(d+0x38)),fY=bits(getf(d+0x3c)),fZ=bits(getf(d+0x40)),shadow=bits(getf(d+0x44)),living=bits(getf(d+0x98)),remaining=bits(getf(d+0xfc)),duration=bits(getf(d+0xf8)),intensity=bits(getf(d+0x100)),selected=bool(C.c_ubyte.from_address(d+0x104).value),brightness=bits(state['brightness']),delta_calls=state['calls'])
   rows.append(dict(name=q['name'],token=q['token'],error=None,trace=state['trace'][:],state=out))
 finally:im.close()
diff=[dict(original=r,actual=by[r['name']])for r in rows if r!=by[r['name']]]
report=dict(scope='TWO_UNTOUCHED_ORIGINAL_PC_DEVICE_CALLERS_VS_EXACT_RAW_CIL_CONTROLLED_NORMAL_PROFILES',candidate_sha256=actual['candidate_sha256'],cases=len(rows),results=rows,differences=diff,untouched_callers_byte_checked=2,callback_errors=[],engine_and_nested_game_leaves_controlled=True,unity_execution=False,native_exception_unwind_executed=False,universal_equivalence=False)
Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(cases=len(rows),differences=len(diff))))
if diff:print(json.dumps(diff[0]));raise SystemExit(1)
