using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using MC=Mono.Cecil;

public class UObj { public string Tag=""; public bool Alive=true;public static bool Eq(UObj? a,UObj? b)=>(a==null||!a.Alive)&&(b==null||!b.Alive)||ReferenceEquals(a,b);public static bool Ne(UObj? a,UObj? b)=>!Eq(a,b); }
public struct V3 {public float x,y,z;public V3(float a,float b,float c){x=a;y=b;z=c;}}
public class Transform:UObj {public V3 Pos;public V3 position{get{Program.Log("position",Tag);return Pos;}}}
public class Component:UObj {public Transform T=new();public Transform transform{get{Program.Log("transform",Tag);return T;}}}
public class GameObject:UObj {public Transform T=new();public Transform transform{get{Program.Log("transform",Tag);return T;}}}
public class Board:UObj {}
public class Device:Component {
 public Board? board;public GameObject animationGroup=new(),shadow=new();public float fX,fY,fZ,fZ_shadow,livingTime,icePoint,maxIcePoint,brightEffectTime,brightTime,brightIntensity;public bool selected_Bright;
 public HPUIController hpUIController=new();public ICEUIController iceUIController=new();public float OutputBrightness;
 public void Update_Characteristic()=>Program.Log("characteristic");public void Update_Events()=>Program.Log("events");
 public void SetBrightness(float value){Program.Log("brightness",Program.Bits(value));OutputBrightness=value;}
 public class HPUIController {public void Update_HPUI(Device d)=>Program.Log("hp",d.Tag);}
 public class ICEUIController {public void Update(float ice,float max,Device d,bool broken)=>Program.Log("ice",Program.Bits(ice),Program.Bits(max),d.Tag,broken?"1":"0");}
}
public static class Time {public static float deltaTime{get{Program.Log("deltaTime");Program.Calls++;if(Program.Mode=="mutate-time"&&Program.Calls==Program.MutateAt)Program.D.brightTime=123;return Program.Delta;}}}
public static class Program {
 public static Device D=new();public static string Mode="";public static float Delta;public static int Calls,MutateAt;public static List<string> Trace=[];
 public static string Bits(float f)=>float.IsNaN(f)?"NaN":((uint)BitConverter.SingleToInt32Bits(f)).ToString("X8");
 public static void Log(params string[] values)=>Trace.Add(string.Join(":",values));
 static Type Map(MC.TypeReference t)=>t.FullName switch {"System.Void"=>typeof(void),"System.Single"=>typeof(float),"System.Int32"=>typeof(int),"System.Boolean"=>typeof(bool),"System.Object"=>typeof(object),"UnityEngine.Object"=>typeof(UObj),"UnityEngine.Component"=>typeof(Component),"UnityEngine.GameObject"=>typeof(GameObject),"UnityEngine.Transform"=>typeof(Transform),"UnityEngine.Vector3"=>typeof(V3),"UnityEngine.Time"=>typeof(Time),"System.Math"=>typeof(Math),_=>typeof(Program).Assembly.GetType(t.FullName.Replace('/','+'),true)!};
 static MethodBase Method(MC.MethodReference m){var owner=Map(m.DeclaringType);var name=m.Name;if(owner==typeof(UObj))name=name switch{"op_Equality"=>"Eq","op_Inequality"=>"Ne",_=>throw new Exception(name)};return owner.GetMethods(BindingFlags.Public|BindingFlags.Static|BindingFlags.Instance).Single(x=>x.Name==name&&x.GetParameters().Select(p=>p.ParameterType).SequenceEqual(m.Parameters.Select(p=>Map(p.ParameterType))));}
 static float N(JsonElement q,string k,float def=0){if(!q.TryGetProperty(k,out var e))return def;return e.ValueKind==JsonValueKind.String?e.GetString()switch{"NaN"=>float.NaN,"Inf"=>float.PositiveInfinity,"-Inf"=>float.NegativeInfinity,_=>throw new Exception("number")}:e.GetSingle();}
 static void Setup(JsonElement q,int rid){Mode=q.GetProperty("mode").GetString()!;Delta=N(q,"delta",.1f);Calls=0;MutateAt=rid==0x309?2:1;D=new(){Tag="device",board=new(){Tag="board"},T=new(){Tag="device-tr",Pos=new(11,12,13)},animationGroup=new(){Tag="group",T=new(){Tag="group-tr",Pos=new(21,24,25)}},shadow=new(){Tag="shadow",T=new(){Tag="shadow-tr",Pos=new(31,34,35)}},fX=-1,fY=-2,fZ=-3,fZ_shadow=-4,livingTime=.5f,icePoint=17,maxIcePoint=6000,brightTime=N(q,"remaining",1),brightEffectTime=N(q,"duration",1),brightIntensity=N(q,"intensity",5),selected_Bright=q.GetProperty("selected").GetBoolean(),OutputBrightness=-99};if(Mode=="no-board")D.board=null;if(Mode=="destroyed-board")D.board!.Alive=false;Trace.Clear();}
 static object State()=>new{fX=Bits(D.fX),fY=Bits(D.fY),fZ=Bits(D.fZ),shadow=Bits(D.fZ_shadow),living=Bits(D.livingTime),remaining=Bits(D.brightTime),duration=Bits(D.brightEffectTime),intensity=Bits(D.brightIntensity),selected=D.selected_Bright,brightness=Bits(D.OutputBrightness),delta_calls=Calls};
 public static void Main(string[] args){var bytes=File.ReadAllBytes(args[0]);using var asm=MC.AssemblyDefinition.ReadAssembly(new MemoryStream(bytes));var methods=new[]{0x309,0x30a}.ToDictionary(r=>r,r=>RehostExact.Emit(bytes,(MC.MethodDefinition)asm.MainModule.LookupToken(0x06000000|r),Map,f=>Map(f.DeclaringType).GetField(f.Name)!,Method));using var cases=JsonDocument.Parse(File.ReadAllText(args[1]));var rows=new List<object>();foreach(var q in cases.RootElement.EnumerateArray()){int rid=Convert.ToInt32(q.GetProperty("token").GetString(),16)&0xffffff;Setup(q,rid);string? error=null;try{methods[rid].Invoke(null,[D]);}catch(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;error=e.GetType().FullName;}rows.Add(new{name=q.GetProperty("name").GetString(),token=q.GetProperty("token").GetString(),error,trace=Trace.ToArray(),state=State()});}File.WriteAllText(args[2],JsonSerializer.Serialize(new{scope="EXACT_RAW_CIL_DEVICE_CALLERS_WITH_CONTROLLED_ENGINE_AND_NESTED_GAME_CALLEES",candidate_sha256=Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant(),results=rows},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine("DEVICE_RAW_CIL_EXECUTED "+rows.Count);}
}
