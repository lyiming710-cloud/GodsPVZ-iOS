"""Read returned evidence, including every trajectory record; do not promote gameplay."""
from pathlib import Path, PurePosixPath
import collections, hashlib, json, re, sys, tarfile

W = Path(__file__).resolve().parent.parent
D = W / 'r22-gameplay-run-40456165422'
A = W / 'r22-apple-run-40456172986'
EXPECTED = '15e0150337a14f1613321385af2d9b1997abd1bc255d56abe4a4ce2c5f7ac2cf'
sys.path.insert(0, str(W))
from archive_support import js

def sha_file(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

g = D / 'gameplay'
manifest = json.loads((g / 'DELIVERY-MANIFEST.json').read_bytes())
for row in manifest['files']:
    name = PurePosixPath(row['path'])
    assert not name.is_absolute() and '..' not in name.parts
    p = g / name
    assert p.stat().st_size == row['size'] and sha_file(p) == row['sha256'], str(p)
result = json.loads((g / 'GAMEPLAY-RESULT.json').read_bytes())
assert result['candidate_sha256'] == EXPECTED
assert result['workflow_head'] == 'd707440be4ad379f8aa83c82e461aa0392fe54c1'
assert result['game_dll_changed'] is False
host = json.loads((g / 'HOST-RESULT.json').read_bytes())
assert host['candidate_unchanged']
resources = json.loads((D / 'editor/r22-actual-original-resource-values.json').read_bytes())
assert resources['candidate_sha256'] == EXPECTED
assert resources['all_actual_fields_match_original'] and resources['passed_leaf_checks'] == 9902
assert resources['failed_leaf_checks'] == resources['unresolved_reference_checks'] == 0
assert (D / 'editor/license-return-exit.txt').read_text().strip() == '0'

units = {}
count = 0
by_kind = collections.Counter()
for line in (g / 'UNIT-TRAJECTORIES.jsonl').open(encoding='utf-8'):
    r = json.loads(line)
    count += 1
    by_kind[r['kind']] += 1
    key = (r['kind'], r['instance'])
    if key not in units:
        units[key] = dict(kind=r['kind'], instance=r['instance'], ID=r['ID'], first=r, last=r,
                          samples=0, active_samples=0, moved_active=False, path_counts=set())
    u = units[key]
    u['samples'] += 1
    u['last'] = r
    u['path_counts'].add(r['path_count'])
    if r['active']:
        u['active_samples'] += 1
        if 'first_active' not in u:
            u['first_active'] = r
        u['last_active'] = r
        u['moved_active'] |= any(r[k] != u['first_active'][k] for k in ['x', 'y', 'z'])
assert count == result['unit_samples']
for u in units.values():
    u['path_counts'] = sorted(u['path_counts'])
battle = [json.loads(x) for x in (g / 'BATTLE-STATE.jsonl').read_text().splitlines()]
bank = [json.loads(x) for x in (g / 'BANK-OBSERVATIONS.jsonl').read_text().splitlines()]
paused = [x for x in battle if x['game_pause'] == 'True']
ui = json.loads((D / 'editor/r22-interaction-audit.json').read_bytes())
summary = dict(
    scope='ACTUAL_R22_UNITY_COMPLEX_LEVEL_OBSERVATIONS_RETAINED_NOT_GAMEPLAY_ACCEPTANCE',
    candidate_sha256=EXPECTED, run=40456165422, source_commit=result['workflow_head'],
    delivery_manifest_files_verified=len(manifest['files']), runtime_identity_unchanged=True,
    actual_resource_routes=70, actual_resource_leaf_checks=9902,
    resource_failures=0, seat_return_exit=0, host=host,
    result_status=result['status'], collection_complete=result['collection_complete'],
    board_started=result['board_started'], real_os_input_checks=result['checks'],
    observed_game_seconds=result['observed_game_seconds'], observed_frames=result['observed_frames'],
    unit_records_read=count, records_by_kind=dict(by_kind),
    unique_by_kind=dict(collections.Counter(u['kind'] for u in units.values())),
    active_moving_zombies=sum(u['kind']=='Zombie' and u['moved_active'] for u in units.values()),
    zombies_with_nonempty_path=sum(u['kind']=='Zombie' and max(u['path_counts'])>0 for u in units.values()),
    first_pause=paused[0] if paused else None, final_battle_state=battle[-1],
    bank_visibility_counts=dict(collections.Counter(r['visibility'].split()[0] for r in bank)),
    bank_first=bank[:4], bank_last=bank[-4:],
    actual_runtime_errors=result['runtime_errors'],
    interaction_failed_checks=[r for r in ui['checks'] if not r['pass']],
    plant_on_field_observed=result['plant_on_field_observed'],
    plant_sourced_projectiles=result['projectiles_with_live_plant_source'],
    complex_gameplay_pass=False, whole_level_completed=False, ipad_acceptance=False, ipa=None,
    interpretation_limits=result['limits'] + [
        'An actual original warning modal and pause/resume screen remained visible in the final screenshot. The input probe did not handle this normal game state.',
        'Moving zombie samples alone do not prove intended path geometry or plant attacks.',
        'The observation helper retained inactive objects; their counts do not imply active gameplay progress.'
    ])
js(D / 'ACTUAL-READBACK.json', summary)
js(D / 'UNIT-ENDPOINTS.json', list(units.values()))

report = json.loads((A / 'APPLE-REPORT.json').read_bytes())
assert report['candidate_sha256'] == EXPECTED and report['apple_audit_source_commit'] == result['workflow_head']
entries = json.loads((A / 'ALL-APPLE-RESULTS.json').read_bytes())
assert len(entries) == 1029 and all(r['exit_code'] == r['error_count'] == 0 for r in entries)
lookup = {r['file']: r for r in entries}
seen = set()
with tarfile.open(W / 'r22-compiler-run-40452784098/startup-r22-generated.tar.gz') as t:
    for m in t:
        p = PurePosixPath(m.name)
        assert not p.is_absolute() and '..' not in p.parts and not m.issym() and not m.islnk()
        if m.isfile() and p.suffix in ['.cpp', '.c']:
            b = t.extractfile(m).read(); row = lookup[p.name]
            assert len(b) == row['bytes'] and hashlib.sha256(b).hexdigest() == row['sha256']
            seen.add(p.name)
assert seen == set(lookup)
warnings = 0
for name, row in lookup.items():
    raw = (A / 'logs' / (name + '.log')).read_text(errors='replace')
    assert not re.search(r': (?:fatal )?error:', raw)
    wc = raw.count(': warning:')
    assert wc == row['warning_count']
    warnings += wc
controls = []
for name in ['COMPILER-CONTROLS.json', 'C-COMPILER-CONTROLS.json']:
    for row in json.loads((A / name).read_bytes()):
        raw = (A / 'logs' / (row['file'] + '.log')).read_text(errors='replace')
        errors = len(re.findall(r': (?:fatal )?error:', raw))
        assert errors == row['error_count'] and row['expectation_met']
        controls.append(dict(file=row['file'], exit=row['exit_code'], raw_errors=errors))
assert len(controls) == 6
damaged = json.loads((A / 'DAMAGED-R4-CONTROL.json').read_bytes())
logs = list((A / 'damaged-r4-control').rglob('*.log'))
assert len(logs) == 1
raw_errors = len(re.findall(r': (?:fatal )?error:', logs[0].read_text(errors='replace')))
assert damaged['exit_code'] and raw_errors == damaged['error_count'] == 34
apple = dict(scope='ACTUAL_FRESH_R22_APPLE_ARM64_SYNTAX_PRECHECK_RAW_READBACK_NOT_LINK_OR_IPA',
             run=40456172986, candidate_sha256=EXPECTED, source_commit=result['workflow_head'],
             generated_source_records_rehashed=len(seen), raw_logs_rechecked=len(lookup),
             cpp=755, c=274, raw_errors=0, raw_warnings=warnings,
             compiler_controls=controls, damaged_r4_raw_errors=34,
             actual_new_unity_export=False, linked=False, ipa=None, gameplay_pass=False)
js(A / 'ACTUAL-READBACK.json', apple)
print(json.dumps(dict(unity={k:summary[k] for k in ['unit_records_read','records_by_kind','unique_by_kind','active_moving_zombies','zombies_with_nonempty_path','plant_sourced_projectiles','observed_game_seconds']},apple=apple)))
