"""Archive final diagnostic source bytes after path, binder and Editor-API checks."""
from pathlib import Path
import hashlib,json,sys,tarfile
W=Path(__file__).resolve().parent.parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113';Q=W/'startup-r23-battle-loop';C=R/'Recovery/Startup-R23-Runtime-Correction-2026-10-28'
sys.path.insert(0,str(W));from archive_support import js,pack,manifest
with tarfile.open(Q/'visualscripting-official-1.9.4.tgz')as t:
 for n in t.getnames():
  if n.lower().endswith(('license.md','license.txt')):
   b=t.extractfile(n).read();(Q/'OFFICIAL-VISUALSCRIPTING-LICENSE.txt').write_bytes(b);break
sources=sorted((R/'scripts/actions').glob('*r23*.py'))+sorted((R/'scripts/actions').glob('*R23.cs'))
flows=[R/'.github/workflows'/n for n in ['bulk401-startup-runtime-gate.yml','startup-r23-real-gameplay-diagnostic.yml','startup-r23-editor-preflight.yml','bulk401-generic-compiler-check.yml','startup-r23-compiler-check.yml']]
paths=sources+flows
identities=[]
for p in paths:
 b=p.read_bytes();assert b'\r\n'not in b,'Normalize before binding source identity';identities.append(dict(file=p.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
js(Q/'FINAL-TOOL-SOURCE-IDENTITIES.json',identities)
helper=json.loads((Q/'FINAL-EXACT-EDITOR-HELPERS.json').read_bytes());assert helper['exit_code']==0
assert all(next(r['sha256']for r in identities if Path(r['file']).name==x['file'])==x['sha256']for x in helper['sources'])
files=[('repository/'+p.relative_to(R).as_posix(),p.read_bytes())for p in paths]
for n in ['FINAL-TOOL-SOURCE-IDENTITIES.json','FINAL-EXACT-EDITOR-HELPERS.json','FINAL-EXACT-EDITOR-HELPERS.log','FINAL-EXACT-EDITOR-HELPERS.dll','BINDING-PIPELINE-FIXTURE.json','BINDING-NEGATIVE-CONTROLS.json','WORKFLOW-LITERAL-PATHS.json','COMPILER-TOOL-DERIVATION.json','RUNTIME-TOOL-DERIVATION.json','physical_controls.py','physical_controls.initial-clr-assumption.py','finish_physical_controls.py','OFFICIAL-ComponentHolderProtocol-1.9.4.cs','OFFICIAL-visualscripting-package.json','OFFICIAL-VISUALSCRIPTING-LICENSE.txt','ORIGINAL-COMPONENT-HOLDER-METHODS.json','read_actual_compiler.py','check_workflow_paths.py','check_binding_pipeline.py','binding_negative_controls.py','compile_helpers.py']:
 p=Q/n;files.append(('local-tools/'+n,p.read_bytes()))
for name in ['prepare_correction_compiler.py','prepare_correction_runtime.py','prepare_correction_workflow.py','archive_actual_and_correction.py','archive_correction_preparation.py','read_actual_runs.py']:
 p=W/'r22-real-gameplay-2026-10-27'/name;files.append(('drivers/'+name,p.read_bytes()))
pack(C/'PREPARED-DIAGNOSTIC-TOOLS-AND-GUARD-CONTROLS.zip',files)
js(C/'RUNTIME-DIAGNOSTIC-PREPARATION.json',dict(scope='LOCAL_EXACT_EDITOR_API_COMPILE_AND_SOURCE_BINDING_NOT_ACTUAL_UNITY',candidate_sha256='1d244776ee85083c2ed298c4f749f96b6c5ae820a78d50b0ce47480691775122',source_files=len(identities),editor_helpers_compiled=3,bootstrap_binding_fixture=True,negative_admission_controls_rejected=4,original_resource_plans_unchanged=True,normal_modal_actions='OS clicks on exact Window_T.ClickExitButton and Board.ResumeGame persistent targets; bounded to twelve each',read_only_new_observations=['All current path nodes per sampled unit, with explicit >1024 truncation flag','Device animation lists and actual SpriteRenderers on source prefabs and scene instances','Bank hierarchy and actual Animator hide bool'],inactive_sampling='First sight and complete observed-state changes retained; duplicate inactive rows counted and suppressed; active interval remains 0.2s',runtime_sdk_changed=False,known_open=['Actual Device.InjuryStatusUpdate null reference cause','Default-return methods in actual loaded VisualScripting Core'],actual_corrected_unity_run=None,whole_game_accepted=False,ipa=None))
with(C/'README.md').open('a',encoding='utf-8')as f:f.write('''

The corrected diagnostic helper compiles against the exact captured Editor APIs.
The complete bootstrap-to-child fixture preserves all four provenance records;
four false-admission controls reject wrong API arity, invented semantic detection,
invented strict-CLR rejection and premature product promotion. Workflow syntax and
42 literal repository inputs were checked before dispatch. The new helper sends
OS clicks to the original warning-close and ResumeGame buttons, records complete
current paths, Device sprite-list/hierarchy details and actual bank hide state,
and batches writes. Unchanged inactive rows are suppressed with an explicit count;
their first sight/state changes remain, while active sampling stays at 0.2 seconds.
All of these are prepared diagnostics. No new actual Unity result is implied.

Official Visual Scripting 1.9.4 package source and license are retained in the
prepared-tools archive only as investigation evidence. Its GameObject extension
and generic AddComponent have distinct handling of unsupported holders; no guessed
shared-null fallback was applied. The actual loaded runtime SDK remains unchanged.
''')
manifest(C)
print(json.dumps(dict(archived_source_files=len(identities),prepared_archive_bytes=(C/'PREPARED-DIAGNOSTIC-TOOLS-AND-GUARD-CONTROLS.zip').stat().st_size)))
