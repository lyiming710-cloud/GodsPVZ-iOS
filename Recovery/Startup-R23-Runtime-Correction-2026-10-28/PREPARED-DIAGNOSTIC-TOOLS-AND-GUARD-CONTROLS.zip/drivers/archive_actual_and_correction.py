"""Preserve raw failure evidence and the separate unpromoted correction checkpoint."""
from pathlib import Path
import hashlib,json,sys,shutil
W=Path(__file__).resolve().parent.parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113'
sys.path.insert(0,str(W));from archive_support import js,pack,manifest
D=W/'r22-gameplay-run-40456165422';A=W/'r22-apple-run-40456172986';Q=W/'startup-r23-battle-loop'
C=R/'Recovery/Startup-R22-Actual-Gameplay-2026-10-28';C.mkdir(exist_ok=False)
(C/'.gitattributes').write_text('* -text\n')
for source,target in [(D/'ACTUAL-READBACK.json','ACTUAL-UNITY-40456165422.json'),(A/'ACTUAL-READBACK.json','ACTUAL-APPLE-40456172986.json'),(D/'UNIT-ENDPOINTS.json','UNIT-ENDPOINTS.json')]:shutil.copyfile(source,C/target)
text=[(p.relative_to(D).as_posix(),p.read_bytes())for p in sorted(D.rglob('*'))if p.is_file()and p.suffix.lower()not in['.png','.jpg']and p.name not in['ACTUAL-READBACK.json','UNIT-ENDPOINTS.json']]
text.append(('read_actual_runs.py',(W/'r22-real-gameplay-2026-10-27/read_actual_runs.py').read_bytes()))
pack(C/'ACTUAL-UNITY-FULL-TEXT-AND-RUNTIME.zip',text)
images=[p for p in sorted((D/'gameplay/screens').glob('*.png'))]
groups=[];group=[];size=0
for p in images:
 if group and size+p.stat().st_size>32000000:groups.append(group);group=[];size=0
 group.append(p);size+=p.stat().st_size
if group:groups.append(group)
for i,g in enumerate(groups):pack(C/f'ACTUAL-UNITY-SCREENS-{i+1:02}.zip',[(p.relative_to(D).as_posix(),p.read_bytes())for p in g])
shutil.copyfile(D/'gameplay/screens/desktop-0422.png',C/'ACTUAL-FINAL-ORIGINAL-PATH-WARNING.png')
pack(C/'ACTUAL-APPLE-ALL-1029-LOGS-AND-REPORTS.zip',[(p.relative_to(A).as_posix(),p.read_bytes())for p in sorted(A.rglob('*'))if p.is_file()])
js(C/'PROGRESS.json',dict(candidate_sha256='15e0150337a14f1613321385af2d9b1997abd1bc255d56abe4a4ce2c5f7ac2cf',unity_run=40456165422,apple_run=40456172986,status='ACTUAL_UNITY_GAMEPLAY_FAILED_COMPILER_SYNTAX_PASSED',gameplay_accepted=False,formal_qualified_methods_added=0,ipad_acceptance=False,ipa=None))
(C/'README.md').write_text('''# R22 actual complex gameplay and Apple evidence

Unity run 40456165422 at d707440 used exact candidate 15e01503. Every delivered
gameplay byte was checked against its delivery manifest. All 1,598,357 trajectory
records were read. The raw text, original PNGs, runtime support DLLs and their
manifests are preserved here, including the failure.

The original Adventure 19 began through OS selection/confirm/start clicks.
35 zombies were observed; three active zombies changed position and four had a
nonempty path in at least one sample. These observations do not establish correct
path geometry. No plant was placed and no plant-origin projectile was observed.
The game advanced 12.67876 seconds after board start before a normal original
path-warning modal paused it. The input helper did not handle that modal and
ended with WALL_TIMEOUT_RETAINED. Device.Update produced 165,880 InvalidProgram
events; Device.InjuryStatusUpdate also threw twice. Original Plant/Zombie resource
readback still passed all 9,902 checks over 70 routes. The Personal seat was returned.

Independent investigation found that R22 incorrectly used Animator.SetTrigger
where original AnimationModule MethodDef 0x06000016 / native 0x1812dba00 is
Animator.SetBool(string,bool), with false in r8. The original CardBank controller
declares hide as a bool defaulting to true. The old finite oracle incorrectly
labeled that address as a three-argument trigger leaf and failed to observe the
bool argument. The old report remains historical evidence; its Board.Update
comparison is not sufficient semantic proof. A corrected ABI/state oracle finds
24 genuine normal-path differences in the old R22 DLL. The corrected child lives
in the separate Startup-R23-Runtime-Correction checkpoint.

Apple run 40456172986 independently rehashed all 755 C++ and 274 C files and read
all 1,029 raw logs: zero errors, 10,572 warnings. Six compiler controls and all
34 errors in the known damaged R4 source were read back. This used previously
captured physical-iOS runtime headers and portable newly generated sources; it
did not export/link this candidate, generate an IPA, or pass real gameplay.
''',encoding='utf-8')
manifest(C)

C2=R/'Recovery/Startup-R23-Runtime-Correction-2026-10-28';C2.mkdir(exist_ok=False)
(C2/'.gitattributes').write_text('* -text\n')
for src,dst in [('correction1.json','CONSTRUCTION.json'),('REPEATED-CONSTRUCTION.json','REPEATED-CONSTRUCTION.json'),('shared-correction1/ISOLATION.json','ISOLATION.json'),('shared-correction1/FROZEN-RAW.json','FROZEN-RAW.json'),('shared-correction1/MEMBER-EXIT.json','MEMBER-EXIT.json'),('shared-correction1/jit/RESULT.json','EXACT-JIT.json'),('PHYSICAL-CONTROLS.json','PHYSICAL-CONTROLS.json'),('CLR-PERMISSIVENESS-OBSERVED.json','CLR-PERMISSIVENESS-OBSERVED.json'),('BOARD-NATIVE-COMPARE.json','BOARD-NATIVE-COMPARE.json'),('DEVICE-NATIVE-COMPARE.json','DEVICE-NATIVE-COMPARE.json'),('ORIGINAL-DIRECT-API-IDENTITIES.json','ORIGINAL-DIRECT-API-IDENTITIES.json')]:shutil.copyfile(Q/src,C2/dst)
pack(C2/'STARTUP-R23-CORRECTION-CANDIDATE.zip',[('STARTUP-R23-CORRECTION.dll',(Q/'correction1.dll').read_bytes())])
exclude={'correction1.dll','correction2.dll','visualscripting-official-1.9.4.tgz'}
files=[]
for p in sorted(Q.rglob('*')):
 if not p.is_file()or p.name in exclude:continue
 rel=p.relative_to(Q)
 if any(x in ['bin','obj','__pycache__']for x in rel.parts):continue
 if p.suffix=='.dll':continue
 files.append((rel.as_posix(),p.read_bytes()))
pack(C2/'SOURCE-NATIVE-CIL-CONTROLS-AND-RAW-EVIDENCE.zip',files)
js(C2/'PROGRESS.json',dict(status='POST_RUNTIME_SOURCE_CORRECTION_SCOPED_CHECKS_PASSED_FRESH_COMPILER_AND_REAL_UNITY_PENDING',candidate_sha256=hashlib.sha256((Q/'correction1.dll').read_bytes()).hexdigest(),parent_sha256='15e0150337a14f1613321385af2d9b1997abd1bc255d56abe4a4ce2c5f7ac2cf',changed_methods=3,source_corrections=10,prior_authoring_cohort_positions=112,new_hundred_position_batch_claimed=False,qualified_methods=0,whole_game_accepted=False,ipad_acceptance=False,ipa=None))
(C2/'README.md').write_text('''# R23: correction after the actual R22 gameplay failure

Candidate 1d244776ee85083c2ed298c4f749f96b6c5ae820a78d50b0ce47480691775122,
24,095,232 bytes, is based on exact R22 15e01503. This is a correction to the
completed 112-position cohort, not a claim of 100 new repairs. Three bodies change:
Board.Update 0x060002AB, Device.Update 0x06000309 and Device.Update_Brightness 0x0600030A.

Ten distinct native-backed corrections restore Animator.SetBool("hide",false),
three float-zero comparisons, ordered NaN expiration behavior in both brightness
forms, capture brightTime before the deltaTime API in both forms, and clear both
float fields in both native qword resets. All branches are re-emitted with label
targets; old body slots remain unchanged. All 2,314 other MethodDef bodies, old
metadata rows/heaps, method flags and section permissions are preserved. No new
MemberRef, MethodSpec or local signature is added. Two fresh constructions match.

Actual raw candidate CIL was executed against the five old caller profiles plus
two Device profiles. The corrected, fully parameterized native oracle observes
128 Board/bank normal cases and 124 Device cases with zero differences. Three
managed finally cases still do not execute original Windows SEH unwind. Seven
physical type-valid semantic mutants execute normally and disagree with the
original callers. A malformed F/I4 comparison mutant is rejected by the unchanged
strict checker. Stock CLR tolerated that mutant; this negative finding is retained
and is not mislabeled as InvalidProgramException. Unity Mono rejected that shape
in the actual failed run. Exact DLL JIT preparation passed for three changed
methods, without claiming method execution in Unity. Raw full type census is
2,200 PASS / 97 FAIL_OR_UNSUPPORTED; it is not whole-assembly acceptance.

The old R22 trigger oracle's false acceptance and the new parent mismatch report
are preserved. Incomplete SDK ComponentHolderProtocol behavior and the actual
Device.InjuryStatusUpdate NRE remain open. Official Visual Scripting 1.9.4 source
was retrieved for investigation only; no SDK or resource binary was patched here.
Fresh IL2CPP/all-source compiler checks and actual Unity input/play remain pending.
No IPA or device acceptance is claimed.
''',encoding='utf-8')
manifest(C2)
assert all(p.stat().st_size<100000000 for c in [C,C2]for p in c.rglob('*')if p.is_file())
print(json.dumps(dict(actual_checkpoint=str(C),correction_checkpoint=str(C2),actual_bytes=sum(p.stat().st_size for p in C.iterdir()if p.is_file()),correction_bytes=sum(p.stat().st_size for p in C2.iterdir()if p.is_file()))))
