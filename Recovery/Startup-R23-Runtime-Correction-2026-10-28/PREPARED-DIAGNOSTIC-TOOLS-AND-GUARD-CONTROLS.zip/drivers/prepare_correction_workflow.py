"""Reuse restricted diagnostic pipeline; preserve all historical source plans."""
from pathlib import Path
import json
W=Path(__file__).resolve().parent.parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113';Q=W/'startup-r23-battle-loop'
p=R/'.github/workflows/bulk401-startup-runtime-gate.yml';saved=Q/'PREVIOUS-REGISTERED-UNITY-WORKFLOW.yml';before=saved.read_bytes()if saved.exists()else p.read_bytes();saved.write_bytes(before)
text=before.decode().replace('Recovery/Startup-R22-Board112-2026-10-27/STARTUP-R22-BOARD112-CANDIDATE.zip','Recovery/Startup-R23-Runtime-Correction-2026-10-28/STARTUP-R23-CORRECTION-CANDIDATE.zip').replace('15e0150337a14f1613321385af2d9b1997abd1bc255d56abe4a4ce2c5f7ac2cf','1d244776ee85083c2ed298c4f749f96b6c5ae820a78d50b0ce47480691775122').replace('R22','R23').replace('r22','r23').replace('Startup R23 Board112','Startup R23 runtime correction')
p.write_text(text,encoding='utf-8',newline='\n');(R/'.github/workflows/startup-r23-real-gameplay-diagnostic.yml').write_text(text,encoding='utf-8',newline='\n')
p=R/'.github/workflows/startup-r22-editor-preflight.yml';text=p.read_text(encoding='utf-8').replace('R22','R23').replace('r22','r23');(p.with_name('startup-r23-editor-preflight.yml')).write_text(text,encoding='utf-8',newline='\n')
print('R23_RESTRICTED_DIAGNOSTIC_WORKFLOWS_PREPARED_NO_DISPATCH')
