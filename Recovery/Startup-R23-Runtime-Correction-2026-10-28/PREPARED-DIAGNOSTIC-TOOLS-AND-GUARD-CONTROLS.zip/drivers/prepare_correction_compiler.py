"""Keep the established compiler algorithm and controls; pin the correction input."""
from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent.parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113';Q=W/'startup-r23-battle-loop'
oldsha='15e0150337a14f1613321385af2d9b1997abd1bc255d56abe4a4ce2c5f7ac2cf'
newsha='1d244776ee85083c2ed298c4f749f96b6c5ae820a78d50b0ce47480691775122'
src=R/'scripts/actions/check_startup_r22_compiler.py';text=src.read_text(encoding='utf-8')
new=text.replace(oldsha,newsha).replace('R22','R23').replace('r22','r23').replace('Board112','Correction').replace('BOARD112','CORRECTION')
dest=R/'scripts/actions/check_startup_r23_compiler.py';assert not dest.exists();dest.write_text(new,encoding='utf-8',newline='\n')
p=R/'.github/workflows/bulk401-generic-compiler-check.yml';before=p.read_bytes()
(Q/'PREVIOUS-REGISTERED-COMPILER-WORKFLOW.yml').write_bytes(before)
text=before.decode().replace(oldsha,newsha).replace('Startup-R22-Board112-2026-10-27','Startup-R23-Runtime-Correction-2026-10-28')
text=text.replace('R22','R23').replace('r22','r23').replace('Board112','Correction').replace('BOARD112','CORRECTION')
p.write_text(text,encoding='utf-8',newline='\n');(R/'.github/workflows/startup-r23-compiler-check.yml').write_text(text,encoding='utf-8',newline='\n')
report=dict(scope='EXACT_INPUT_COMPILER_DERIVATION_ALGORITHM_UNCHANGED',parent_script_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),child_script_sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),candidate_sha256=newsha,negative_controls_unchanged=True,unity_activation=False,gameplay_acceptance=False)
(Q/'COMPILER-TOOL-DERIVATION.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
