"""New diagnostic helpers retain original resource plans and pin the corrected game DLL."""
from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent.parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113';Q=W/'startup-r23-battle-loop';rows=[]
for name in ['prepare_startup_r22_unity.py','prepare_startup_r22_plugin.py','restore_startup_r22_plant_fields.py','restore_startup_r22_zombie_fields.py','verify_startup_r22_resource_values.py','preflight_startup_r22_capture_editor.py','run_startup_r22_gameplay.py','GodsPVZSerializedReferenceProbeR22.cs','GodsPVZInteractionAuditR22.cs','GodsPVZGameplayAuditR22.cs']:
 p=R/'scripts/actions'/name;dest=p.with_name(name.replace('R22','R23').replace('r22','r23'));assert not dest.exists()
 before=p.read_bytes();text=before.decode().replace('15e0150337a14f1613321385af2d9b1997abd1bc255d56abe4a4ce2c5f7ac2cf','1d244776ee85083c2ed298c4f749f96b6c5ae820a78d50b0ce47480691775122').replace('R22','R23').replace('r22','r23')
 dest.write_text(text,encoding='utf-8',newline='\n');rows.append(dict(source=name,source_sha256=hashlib.sha256(before).hexdigest(),new_file=dest.name,new_sha256=hashlib.sha256(dest.read_bytes()).hexdigest()))
text=(W/'r22-real-gameplay-2026-10-27/compile_helpers.py').read_text(encoding='utf-8').replace("D=Path(__file__).resolve().parent;W=D.parent;", "D=Path(__file__).resolve().parent;W=D.parent;").replace('R22','R23').replace('r22','r23')
(Q/'compile_helpers.py').write_text(text,encoding='utf-8')
(Q/'RUNTIME-TOOL-DERIVATION.json').write_text(json.dumps(dict(scope='DERIVED_R23_DIAGNOSTIC_TOOLS_BEFORE_READ_ONLY_OBSERVER_AND_MODAL_UPDATES',rows=rows,original_plant_and_zombie_plan_identities_unchanged=True,sdk_binary_changed=False),indent=2)+'\n')
print('DERIVED_R23_RUNTIME_TOOLS',len(rows))
