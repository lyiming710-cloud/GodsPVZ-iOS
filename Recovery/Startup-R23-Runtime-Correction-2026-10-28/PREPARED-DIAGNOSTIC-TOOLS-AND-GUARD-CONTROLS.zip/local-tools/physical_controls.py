"""Physically mutate real candidate bytes; distinguish semantic and invalid-IL controls."""
from pathlib import Path
import concurrent.futures, hashlib, importlib.util, json, struct, subprocess, sys
import source_common as s
import dnfile

Q=s.Q;dot=s.ROOT/'.local/dotnet10/dotnet.exe'
good=(Q/'correction1.dll').read_bytes();pe=dnfile.dnPE(data=good)
plan=json.loads((Q/'correction1.json').read_bytes());out=Q/'physical-controls';out.mkdir(exist_ok=False)
assert hashlib.sha256(good).hexdigest()==plan['candidate_sha256']
def location(token,va):
    site=next(r for r in plan['repair_sites']if r['method']==token and int(r['native_va'],16)==va)
    row=pe.net.mdtables.MethodDef.rows[(int(token,16)&0xffffff)-1]
    at=pe.get_offset_from_rva(row.Rva);h=(struct.unpack_from('<H',good,at)[0]>>12)*4
    return at+h+site['new_cil_start'],site
def save(name,data,kind,fixture,compare):
    p=out/(name+'.dll');p.write_bytes(data)
    return dict(name=name,path=p,kind=kind,fixture=fixture,compare=compare,sha256=hashlib.sha256(data).hexdigest())
controls=[]
# Point only this target MethodDef back at its preserved R22 body. This is a
# type-valid wrong-API control; all unrelated MethodDef rows remain identical.
bad=bytearray(good);rid=0x2ab
row=pe.net.mdtables.MethodDef.rows[rid-1]
struct.pack_into('<I',bad,row.struct.get_file_offset(),s.pe.net.mdtables.MethodDef.rows[rid-1].Rva)
controls.append(save('wrong-animator-api',bad,'SEMANTIC','board','board'))
for token,va,name in [('0x06000309',0x18034c9d6,'missing-inline-time-reset'),('0x0600030A',0x18034bf5b,'missing-standalone-time-reset')]:
    at,site=location(token,va);size=site['new_cil_end']-site['new_cil_start'];bad=bytearray(good)
    assert size==11 and good[at+6]==0x7d
    field=int.from_bytes(good[at+7:at+11],'little');assert str(pe.net.mdtables.Field.rows[(field&0xffffff)-1].Name)=='brightTime'
    replacement=next(0x04000000|k for k,r in enumerate(pe.net.mdtables.Field.rows,1)if str(r.Name)=='brightEffectTime' and k==0x48c)
    struct.pack_into('<I',bad,at+7,replacement)
    controls.append(save(name,bad,'SEMANTIC','device','device'))
for token,va,name in [('0x06000309',0x18034c9b3,'wrong-inline-nan-expiration'),('0x0600030A',0x18034bf2c,'wrong-standalone-nan-expiration')]:
    at,site=location(token,va);bad=bytearray(good);assert good[at:at+2]==b'\xfe\x05';bad[at+1]=4
    controls.append(save(name,bad,'SEMANTIC','device','device'))
for token,va,name in [('0x06000309',0x18034c996,'late-inline-time-snapshot'),('0x0600030A',0x18034bf0f,'late-standalone-time-snapshot')]:
    at,site=location(token,va);n=site['new_cil_end']-site['new_cil_start'];assert n==8 and good[at+n]==0x28
    # get_deltaTime (5 bytes), followed by the old long stloc (4 bytes).
    assert good[at+n+5:at+n+7]==b'\xfe\x0e'
    bad=bytearray(good);bad[at:at+n+9]=good[at+n:at+n+9]+good[at:at+n]
    controls.append(save(name,bad,'SEMANTIC','device','device'))
at,site=location('0x06000309',0x18034c989);bad=bytearray(good);assert bad[at]==0x22;bad[at]=0x20
controls.append(save('mixed-float-integer-zero',bad,'INVALID_IL','device','device'))

def run(c):
    name=c['name'];actual=out/(name+'-cil.json')
    cmd=[str(dot),str(Q/(c['fixture']+'-runtime/bin/Fixture.dll')),str(c['path']),str(Q/('CASES.json'if c['fixture']=='board'else'DEVICE-CASES.json')),str(actual)]
    p=subprocess.run(cmd,capture_output=True,timeout=40);(out/(name+'-cil.stdout.log')).write_bytes(p.stdout);(out/(name+'-cil.stderr.log')).write_bytes(p.stderr)
    assert p.returncode==0,(name,p.returncode,p.stderr[-1000:])
    rows=json.loads(actual.read_bytes());assert rows['candidate_sha256']==c['sha256']
    if c['kind']=='INVALID_IL':
        # Stock CLR is permissive for this exact malformed comparison. Preserve
        # that result and require the unchanged strict checker to reject it.
        exporter=s.ROOT/'audit/bulk250-r1-evidence-39702928368/bulk250-r1-run/tools_bin/CilExporter/bin/CilExporter.dll'
        assert hashlib.sha256(exporter.read_bytes()).hexdigest()=='0a9964ecd2cfa0f5f7e57ecb41b5809c6f305070285734a36cdebc2747798dc0'
        exported=out/(name+'-export.json')
        xp=subprocess.run([str(dot),str(exporter),str(c['path']),str(exported),str(s.ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'),'0x06000309'],capture_output=True,timeout=30)
        assert xp.returncode==0
        checker=s.ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py'
        assert hashlib.sha256(checker.read_bytes()).hexdigest()=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14'
        spec=importlib.util.spec_from_file_location('unchanged_strict_negative',checker);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
        data=json.loads(exported.read_bytes())
        try:r=v.verify(data['methods'][0],data['types'])
        except Exception as ex:r=dict(status='REJECTED',error=str(ex))
        assert r['status']!='PASS' and 'compar' in r['error']
        return dict(name=name,kind='STRICT_TYPE',sha256=c['sha256'],detected=True,stock_clr_rejected=any(x['error']for x in rows['results']),strict_type_result=r,semantic_execution=False)
    assert not any(r['error']for r in rows['results']if not r['name'].startswith('e7-throw'))
    target=out/(name+'-native.json');p=subprocess.run([sys.executable,str(Q/(c['compare']+'_native_compare.py')),str(actual),str(target)],capture_output=True,timeout=90)
    (out/(name+'-native.stdout.log')).write_bytes(p.stdout);(out/(name+'-native.stderr.log')).write_bytes(p.stderr)
    assert p.returncode==1 and target.exists(),(name,p.returncode,p.stderr[-1000:])
    report=json.loads(target.read_bytes());diff=report['differences'];assert diff
    assert all(x['actual']['error'] is None for x in diff)
    return dict(name=name,kind=c['kind'],sha256=c['sha256'],detected=True,normal_execution_differences=len(diff),semantic_execution=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
    rows=[]
    for r in pool.map(run,controls):rows.append(r);print(json.dumps(r),flush=True)
report=dict(scope='PHYSICAL_CANDIDATE_BYTE_MUTANTS_REJECTED_BY_REPAIRED_NATIVE_ABI_ORACLE_AND_ACTUAL_CIL',candidate_sha256=plan['candidate_sha256'],controls=len(rows),semantic_controls=sum(r['semantic_execution']for r in rows),strict_type_controls=sum(not r['semantic_execution']for r in rows),all_detected=True,results=rows,unity_execution=False)
(Q/'PHYSICAL-CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
