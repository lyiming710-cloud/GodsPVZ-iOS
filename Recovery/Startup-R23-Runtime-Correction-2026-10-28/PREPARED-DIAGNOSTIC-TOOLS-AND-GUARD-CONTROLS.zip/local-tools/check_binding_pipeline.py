"""Exercise the new binding from the immutable bootstrap input, never Unity."""
from pathlib import Path
import hashlib,json,shutil,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113'
sys.path.insert(0,str(R/'scripts/actions'));import bind_startup_r23_diagnostic as b
out=Q/'binding-pipeline-fixture-v2';out.mkdir(exist_ok=False);(out/'candidate').mkdir();(out/'evidence').mkdir()
old=W/'r22-real-gameplay-2026-10-27/parent-package-fixture'
for p in old.iterdir():
 if p.name=='Assembly-CSharp-bulk401.dll':shutil.copyfile(p,out/'candidate'/p.name)
 else:shutil.copyfile(p,out/'evidence'/p.name)
provenance=out/'evidence/PROVENANCE.json';fixture=json.loads(provenance.read_bytes());fixture['source_commit']='R23_LOCAL_BINDING_FIXTURE_NOT_AN_ACTUAL_WORKFLOW';provenance.write_text(json.dumps(fixture,indent=2)+'\n')
result=b.bind(out,'R23_LOCAL_BINDING_FIXTURE_NOT_AN_ACTUAL_WORKFLOW')
assert hashlib.sha256((out/'candidate/Assembly-CSharp-bulk401.dll').read_bytes()).hexdigest()==b.CANDIDATE
parents=sorted(p.name for p in (out/'evidence').glob('PARENT-*-PROVENANCE.json'))
assert set(parents)>={'PARENT-BULK401-PROVENANCE.json','PARENT-R20-PROVENANCE.json','PARENT-R21-PROVENANCE.json','PARENT-R22-CORRECTION-PROVENANCE.json'}
report=dict(scope='LOCAL_COMPLETE_BOOTSTRAP_THROUGH_CORRECTION_BINDING_NOT_UNITY',candidate_sha256=b.CANDIDATE,pipeline_completed=True,parent_provenance_preserved=parents,old_wrong_abi_report_used_for_admission=False,local_fixture_parent_source_identity_explicitly_rebound=True,unity_started=False,ipa_allowed=False)
(Q/'BINDING-PIPELINE-FIXTURE.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
