"""The admission gate must reject invented ABI, semantic and product passes."""
from pathlib import Path
import json,shutil,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113'
sys.path.insert(0,str(R/'scripts/actions'));sys.path.insert(0,str(W))
import bind_startup_r23_diagnostic as b
from archive_support import js,manifest
out=Q/'binding-negative-controls';out.mkdir(exist_ok=False);rows=[]
def bad_api(d):
 p=d/'ORIGINAL-DIRECT-API-IDENTITIES.json';j=json.loads(p.read_bytes())
 for r in j['resolved']['0x1812dba00']:r['args']=1
 js(p,j)
def no_semantic_difference(d):
 p=d/'PHYSICAL-CONTROLS.json';j=json.loads(p.read_bytes());next(r for r in j['results']if r['kind']=='SEMANTIC')['normal_execution_differences']=0;js(p,j)
def fabricated_clr_rejection(d):
 p=d/'PHYSICAL-CONTROLS.json';j=json.loads(p.read_bytes());next(r for r in j['results']if r['kind']=='STRICT_TYPE')['stock_clr_rejected']=True;js(p,j)
def invented_gameplay_pass(d):
 p=d/'PROGRESS.json';j=json.loads(p.read_bytes());j['whole_game_accepted']=True;js(p,j)
for name,mutate in [('wrong-original-api-arity',bad_api),('invented-semantic-control',no_semantic_difference),('fabricated-stock-clr-rejection',fabricated_clr_rejection),('invented-product-promotion',invented_gameplay_pass)]:
 d=out/name;shutil.copytree(b.CHECKPOINT,d);mutate(d);manifest(d)
 try:b.validate_checkpoint(d)
 except ValueError as ex:rows.append(dict(name=name,rejected=True,reason=str(ex)));continue
 raise AssertionError('False admission accepted: '+name)
report=dict(scope='LOCAL_DIAGNOSTIC_ADMISSION_FALSIFICATION_CONTROLS_NOT_GAMEPLAY',candidate_sha256=b.CANDIDATE,controls=4,all_rejected=True,rows=rows)
js(Q/'BINDING-NEGATIVE-CONTROLS.json',report);print(json.dumps(report))
