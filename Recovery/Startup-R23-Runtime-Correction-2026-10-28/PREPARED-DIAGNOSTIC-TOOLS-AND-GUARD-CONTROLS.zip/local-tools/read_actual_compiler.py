"""Independently rehash every returned source and reread every raw compiler log."""
from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,re,subprocess,sys
S=Path(__file__).resolve().parent;W=S.parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113';D=W/'r23-compiler-run-40612953895';C=R/'Recovery/Startup-R23-Runtime-Correction-2026-10-28'
sys.path.insert(0,str(W));from archive_support import js,pack,manifest
sha=lambda b:hashlib.sha256(b).hexdigest()
report=json.loads((D/'startup-r23/STARTUP-R23-CORRECTION-COMPILER-REPORT.json').read_bytes());entries=sum([json.loads((D/'startup-r23'/f).read_bytes())for f in['ALL-CPP-RESULTS.json','ALL-C-RESULTS.json']],[])
assert report['candidate_sha256']=='1d244776ee85083c2ed298c4f749f96b6c5ae820a78d50b0ce47480691775122'and report['pass']and report['conversion']['exit_code']==0
assert len(entries)==1029 and len({r['file']for r in entries})==1029 and all(r['exit_code']==r['error_count']==0 for r in entries)
lookup={r['file']:r for r in entries};read=[];game=[]
with tarfile.open(D/'startup-r23-generated.tar.gz')as t:
 for member in t:
  p=PurePosixPath(member.name);assert not p.is_absolute()and'..'not in p.parts and not member.issym()and not member.islnk()
  if not member.isfile():continue
  if p.suffix in['.cpp','.c']:
   b=t.extractfile(member).read();row=lookup[p.name];assert len(b)==row['bytes']and sha(b)==row['sha256'];read.append(p.name)
   if p.name.startswith('GodsPVZRuntime1'):game.append((p.name,b))
assert len(read)==len(set(read))==1029 and set(read)==set(lookup)
logs=[];negative=[];warnings=0
with tarfile.open(D/'startup-r23-evidence.tar.gz')as t:
 for member in t:
  if not member.isfile():continue
  p=PurePosixPath(member.name)
  if p.parent.as_posix()=='.validation/startup-r23/candidate/results/clang_logs'and p.name.endswith('.log'):
   b=t.extractfile(member).read();text=b.decode(errors='replace');assert not re.search(r': (?:fatal )?error:',text),p.name;source=p.name[:-4];assert source in lookup;assert text.count(': warning:')==lookup[source]['warning_count'];warnings+=text.count(': warning:');logs.append(source)
  elif p.name.endswith('.log')and'/controls/'in p.as_posix():
   text=t.extractfile(member).read().decode(errors='replace');errors=len(re.findall(r': (?:fatal )?error:',text));negative.append(dict(file=p.as_posix(),raw_errors=errors))
assert set(logs)==set(lookup)and len(logs)==1029
bad=[x for x in negative if PurePosixPath(x['file']).name.startswith('bad_')];assert len(bad)==4 and all(x['raw_errors']for x in bad)
run=json.loads(subprocess.check_output(['C:/Program Files/GitHub CLI/gh.exe','run','view','40612953895','-R','lyiming710-cloud/GodsPVZ-iOS','--json','status,conclusion,headSha,url'],cwd=R));assert run['conclusion']=='success'and run['headSha']=='8df1d5acb420070a973701d0f055bae5a09697a4'
result=dict(scope='ACTUAL_FRESH_LINUX_COMPILER_AND_RAW_ALL_SOURCE_READBACK_NOT_UNITY_OR_IPA',candidate_sha256=report['candidate_sha256'],run_id=40612953895,source_commit=run['headSha'],pass_=True,conversion_exit=0,raw_generated_sources_rehashed=len(read),raw_source_logs_rechecked=len(logs),cpp=755,c=274,raw_errors=0,raw_warnings=warnings,all_game_translation_units_preserved=len(game),generated_archive_bytes=(D/'startup-r23-generated.tar.gz').stat().st_size,generated_archive_sha256=sha((D/'startup-r23-generated.tar.gz').read_bytes()),evidence_archive_sha256=sha((D/'startup-r23-evidence.tar.gz').read_bytes()),raw_compiler_controls=negative,damaged_R4_control=report['damaged_r4_control'],unity_executed=False,apple_compiler_executed=False,ipa=None)
js(D/'ACTUAL-READBACK.json',result);js(C/'ACTUAL-COMPILER-40612953895.json',result)
pack(C/'ACTUAL-LINUX-40612953895-REPORTS-AND-GAME-SOURCES.zip',[(p.relative_to(D).as_posix(),p.read_bytes())for p in sorted(D.rglob('*'))if p.is_file()and p.name!='startup-r23-generated.tar.gz']+ [('generated-game/'+n,b)for n,b in game])
progress=json.loads((C/'PROGRESS.json').read_bytes());progress.update(status='SCOPED_CALLER_CHECKS_AND_FRESH_LINUX_ALL_SOURCE_COMPILER_PASS_REAL_UNITY_PENDING',fresh_linux_compiler='PASS_RAW_1029_SOURCES_AND_LOGS_READ_BACK',fresh_apple_compiler='PENDING');js(C/'PROGRESS.json',progress)
with(C/'README.md').open('a',encoding='utf-8')as f:f.write('\n实际Linux运行40612953895已成功结束，固定ba78423源码及15e01503候选。逐一重算755个CPP+274个C的源码大小/SHA，并回读全部1029份原始日志，0错误；编译器负控制仍检出真实损坏。全量生成源码tar的SHA及所有游戏分片保留，不能代指真实Unity导入、Apple链接或IPA。\n')
manifest(C);print(json.dumps({k:v for k,v in result.items()if k not in['damaged_R4_control','raw_compiler_controls']}))
