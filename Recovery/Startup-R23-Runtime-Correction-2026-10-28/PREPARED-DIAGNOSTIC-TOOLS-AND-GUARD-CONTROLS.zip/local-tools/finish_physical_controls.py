"""Retain seven completed semantic controls; use strict type checking for mixed IL.

Stock .NET executed the deliberately mixed comparison rather than throwing.
That observation is preserved, not relabeled as a CLR rejection.
"""
from pathlib import Path
import hashlib, importlib.util, json, subprocess, sys

Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1]
out=Q/'physical-controls';rows=[]
for p in sorted(out.glob('*-native.json')):
    name=p.name.removesuffix('-native.json');r=json.loads(p.read_bytes())
    cil=json.loads((out/(name+'-cil.json')).read_bytes())
    digest=hashlib.sha256((out/(name+'.dll')).read_bytes()).hexdigest()
    assert r['candidate_sha256']==cil['candidate_sha256']==digest and r['differences']
    assert not r.get('callback_errors',[])
    assert all(x['actual']['error'] is None for x in r['differences'])
    rows.append(dict(name=name,sha256=digest,detected=True,kind='SEMANTIC',normal_execution_differences=len(r['differences']),semantic_execution=True))
assert len(rows)==7
name='mixed-float-integer-zero';dll=out/(name+'.dll')
cil=json.loads((out/(name+'-cil.json')).read_bytes())
assert not any(r['error'] for r in cil['results'])
note=dict(scope='REJECTED_TEST_HARNESS_ASSUMPTION_RAW_RUNTIME_OBSERVATION',
    original_assumption='Stock CLR would throw InvalidProgramException for this mixed F/I4 comparison',
    observed='All 124 controlled CLR cases executed without InvalidProgramException',
    actual_affected_Unity_Mono_run=40456165422,
    unity_mono_observation='Device.Update IL_017c cgt rejected with InvalidProgramException',
    acceptance='The physical malformed IL must be rejected by the unchanged strict type checker, not by pretending stock CLR threw',
    candidate_unchanged=True)
(Q/'CLR-PERMISSIVENESS-OBSERVED.json').write_text(json.dumps(note,indent=2)+'\n')
exporter=ROOT/'audit/bulk250-r1-evidence-39702928368/bulk250-r1-run/tools_bin/CilExporter/bin/CilExporter.dll'
assert hashlib.sha256(exporter.read_bytes()).hexdigest()=='0a9964ecd2cfa0f5f7e57ecb41b5809c6f305070285734a36cdebc2747798dc0'
path=out/(name+'-export.json')
p=subprocess.run([str(ROOT/'.local/dotnet10/dotnet.exe'),str(exporter),str(dll),str(path),str(ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'),'0x06000309'],capture_output=True)
(out/(name+'-export.stdout.log')).write_bytes(p.stdout);(out/(name+'-export.stderr.log')).write_bytes(p.stderr);assert p.returncode==0
checker=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py'
assert hashlib.sha256(checker.read_bytes()).hexdigest()=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14'
spec=importlib.util.spec_from_file_location('immutable_type_checker_mixed_negative',checker);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
data=json.loads(path.read_bytes());assert len(data['methods'])==1
try:r=v.verify(data['methods'][0],data['types'])
except Exception as ex:r=dict(status='REJECTED',error=str(ex))
assert r['status']!='PASS' and ('comparison'in r['error']or 'compare'in r['error'])
rows.append(dict(name=name,sha256=hashlib.sha256(dll.read_bytes()).hexdigest(),detected=True,kind='STRICT_TYPE',semantic_execution=False,stock_clr_rejected=False,strict_type_result=r))
report=dict(scope='PHYSICAL_CORRECTION_CONTROLS_SEPARATING_SEMANTIC_DIFFERENCES_AND_STRICT_TYPE_REJECTION',candidate_sha256=hashlib.sha256((Q/'correction1.dll').read_bytes()).hexdigest(),controls=8,semantic_controls=7,strict_type_controls=1,all_detected=True,results=rows,clr_permissiveness_observed=True,unity_execution=False,malformed_runtime_execution_not_claimed_as_semantic_success=True)
(Q/'PHYSICAL-CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items()if k!='results'}))
