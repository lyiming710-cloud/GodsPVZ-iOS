"""Complete original talent-preview caller, including real scalar comparison."""
from pathlib import Path
import ctypes as C,hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
im=NativeImage();s={};cfg=json.loads((W/'startup-r19-batch100/native-source-complete/0x06000598.json').read_bytes())
fields=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_bytes())
def off(name):
    r=[r for r in fields if r['namespace']=='' and r['type']=='Almanac_TalentSystem' and r['name']==name];assert len(r)==1;return r[0]['offset']
def n(k,d=0):return s['q'].get(k,d)
def mode():return s['q']['mode']
def make(label):p=im.alloc(256);s['tags'][p]=label;return p
def tag(p):return s['tags'][p]
def bits(f):return struct.pack('<f',f)[::-1].hex().upper()
def count(p,method):assert p==s['save'] and not method;s['trace'].append('Count:'+str(n('old')));return n('old')
def next_count(p,value,method):assert p==s['save'] and not method;s['trace'].append('NextCount:'+str(value)+':'+str(n('next')));return n('next')
def object0(p,method):assert not method;s['trace'].append('Object:'+tag(p));return s['objects'][p]
def active(p,on,method):
    assert not method;s['active'][p]=bool(on);s['trace'].append('Active:'+tag(p)+':'+str(int(on)))
    if mode()=='active-fields' and tag(p)=='gift-open-object' and on:
        C.c_ubyte.from_address(s['page']+off('preview')).value=0;put64(s['page']+off('tip_new'),s['other-tip']);put64(s['page']+off('content'),s['other-content'])
def transform(p,method):
    assert not method;s['trace'].append('Transform:'+tag(p))
    if mode()=='transform-fields':put64(s['page']+off('tip_new'),s['other-tip']);put64(s['page']+off('content'),s['other-content'])
    return s['transforms'][p]
def position(retbuf,p,method):
    assert not method;s['trace'].append('Position:'+tag(p)+':'+s['positions'][p][1])
    if mode()=='position-fields':put64(s['page']+off('tip_new'),s['other-tip'])
    for i,v in enumerate(s['positions'][p]):C.c_uint32.from_address(retbuf+4*i).value=int(v,16)
    return retbuf
def preview(p,value,method):assert p==s['page'] and not method;s['trace'].append('Preview:'+str(value))
try:
    im.hook(0x180376130,I,[P,P],count);im.hook(0x180375fb0,I,[P,I,P],next_count);im.hook(0x1813044d0,P,[P,P],object0);im.hook(0x18131bad0,None,[P,C.c_bool,P],active);im.hook(0x18131c070,P,[P,P],transform);im.hook(0x18132f070,P,[P,P,P],position);im.hook(0x1803916a0,None,[P,I,P],preview)
    im.verify_caller(0x598,0x180391480,cfg)
    raw_constant=im.pe.get_data(0x180391644+8+0x1216624-im.base,4);assert struct.unpack('<f',raw_constant)[0]==100
    cases=json.loads((Q/'CASES.json').read_bytes());rows=[]
    for q in cases:
        if not q['native_supported']:continue
        if '--trace-cases' in sys.argv:print(json.dumps(dict(starting_case=q['name'])),flush=True)
        s.clear();s.update(q=q,tags={},trace=[],objects={},active={},transforms={},positions={})
        for label in ['page','save','gift','gift-open','text','gift-object','gift-open-object','text-object','tip','other-tip','content','other-content','content-transform','other-content-transform']:s[label]=make(label)
        put32(s['save']+0x54,n('order'));put64(s['page']+off('plantSave'),s['save']);C.c_ubyte.from_address(s['page']+off('preview')).value=n('initial')
        for name,label in [('gift','gift'),('gift_open','gift-open'),('text_new','text'),('tip_new','tip'),('content','content')]:put64(s['page']+off(name),s[label])
        for label in ['gift','gift-open','text']:s['objects'][s[label]]=s[label+'-object']
        for label in ['gift-object','gift-open-object','text-object','tip','other-tip']:s['active'][s[label]]=None
        s['transforms'][s['content']]=s['content-transform'];s['transforms'][s['other-content']]=s['other-content-transform'];s['positions'][s['content-transform']]=['40400000',q['y'],'40E00000'];s['positions'][s['other-content-transform']]=['41100000','4479C000','41300000']
        C.CFUNCTYPE(None,P,C.c_bool,P)(0x180391480)(s['page'],bool(n('on')),None);assert not im.errors,(q,im.errors)
        snap=dict(preview=bool(C.c_ubyte.from_address(s['page']+off('preview')).value),tip_root=tag(get64(s['page']+off('tip_new'))),content_root=tag(get64(s['page']+off('content'))),gift=s['active'][s['gift-object']],open=s['active'][s['gift-open-object']],text=s['active'][s['text-object']],tip=s['active'][s['tip']],other_tip=s['active'][s['other-tip']])
        rows.append(dict(name=q['name'],token='0x06000598',error=None,trace=list(s['trace']),state=snap))
    actual=json.loads(Path(sys.argv[1]).read_bytes());digest=hashlib.sha256((W/'startup-r20-sites100/authored3.dll').read_bytes()).hexdigest();assert actual['candidate_sha256']==digest
    found={r['name']:r for r in actual['results']};assert set(found)=={q['name'] for q in cases};diff=[dict(original=r,actual=found[r['name']]) for r in rows if r!=found[r['name']]]
    result=dict(scope='COMPLETE_ORIGINAL_TALENT_ORDER_PREVIEW_VS_COMPLETE_CANDIDATE_CIL',candidate_sha256=digest,original_pc_sha256=hashlib.sha256(im.raw).hexdigest(),caller_bytes_verified=1,normal_records=len(rows),results=rows,differences=diff,callback_errors=im.errors,
        original_comiss_and_unsigned_jump_executed=True,original_threshold_bits=raw_constant.hex(),real_clr_vector3_value_flow=True,native_vector3_sret_preserved=True,
        managed_only_exception_records=[found[q['name']] for q in cases if not q['native_supported']],controlled_leaves=['Talent count and child Preview','Unity component/activation/transform/localPosition ABI'],limitations=['Finite caller contract; leaf internals/native SEH/actual Unity rendering not proven'],formal_or_product_acceptance=False)
    Path(sys.argv[2]).write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in result.items() if k not in ['results','differences','managed_only_exception_records']}));print('differences',len(diff));assert not diff
finally:im.close()
