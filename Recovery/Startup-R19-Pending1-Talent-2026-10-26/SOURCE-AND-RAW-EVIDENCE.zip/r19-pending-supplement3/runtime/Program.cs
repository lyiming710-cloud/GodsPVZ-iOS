using System.Reflection;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public struct Vec{public float x,y,z;}
public class Transform{public string Tag="";public Vec Position;public Vec localPosition{get{Program.Trace.Add("Position:"+Tag+":"+Program.Bits(Position.y));if(Program.Mode=="position-fields")Program.Page.tip_new=Program.OtherTip;return Position;}}}
public class GO{public string Tag="";public bool? Active;public Transform Value=null!;
 public Transform transform{get{Program.Trace.Add("Transform:"+Tag);if(Program.Mode=="transform-fields"){Program.Page.tip_new=Program.OtherTip;Program.Page.content=Program.OtherContent;}return Value;}}
 public void SetActive(bool value){Active=value;Program.Trace.Add("Active:"+Tag+":"+(value?1:0));if(Program.Mode=="active-fields"&&Tag=="gift-open-object"&&value){Program.Page.preview=false;Program.Page.tip_new=Program.OtherTip;Program.Page.content=Program.OtherContent;}}
}
public class Comp{public string Tag="";public GO Value=null!;public GO gameObject{get{Program.Trace.Add("Object:"+Tag);return Value;}}}
public class Save{public int order;public int GetTalentNum_Unlocked(){Program.Trace.Add("Count:"+Program.N("old"));return Program.N("old");}public int GetTalentNum_Unlocked(int value){Program.Trace.Add("NextCount:"+value+":"+Program.N("next"));return Program.N("next");}}
public class Page{public Save? plantSave;public Comp gift=null!,gift_open=null!,text_new=null!;public GO tip_new=null!,content=null!;public bool preview;public void Preview(int value)=>Program.Trace.Add("Preview:"+value);}
public static class Program
{
 public static JsonElement Case;public static List<string> Trace=[];public static Page Page=null!;public static GO Gift=null!,GiftOpen=null!,Text=null!,Tip=null!,OtherTip=null!,Content=null!,OtherContent=null!;
 public static int N(string key,int d=0)=>Case.TryGetProperty(key,out var v)?v.GetInt32():d;public static string Mode=>Case.GetProperty("mode").GetString()!;public static string Bits(float v)=>((uint)BitConverter.SingleToInt32Bits(v)).ToString("X8");
 static Type Map(MC.TypeReference t)=>t.FullName switch{"System.Void"=>typeof(void),"System.Boolean"=>typeof(bool),"System.Int32"=>typeof(int),"System.Single"=>typeof(float),"Almanac_TalentSystem"=>typeof(Page),"PlantSave"=>typeof(Save),"UnityEngine.Component" or "UnityEngine.UI.Image" or "TMPro.TextMeshProUGUI"=>typeof(Comp),"UnityEngine.GameObject"=>typeof(GO),"UnityEngine.Transform"=>typeof(Transform),"UnityEngine.Vector3"=>typeof(Vec),_=>throw new NotSupportedException(t.FullName)};
 static FieldInfo Field(MC.FieldReference f)=>Map(f.DeclaringType).GetField(f.Name)!;
 static MethodBase Method(MC.MethodReference m)=>Map(m.DeclaringType).GetMethod(m.Name,BindingFlags.Public|BindingFlags.Instance|BindingFlags.Static,null,m.Parameters.Select(p=>Map(p.ParameterType)).ToArray(),null)!;
 static GO Object(string tag)=>new(){Tag=tag,Value=new(){Tag=tag+"-transform"}};
 public static void Main(string[] args)
 {
  var resolver=new MC.DefaultAssemblyResolver();resolver.AddSearchDirectory(args[1]);using var asm=MC.AssemblyDefinition.ReadAssembly(args[0],new MC.ReaderParameters{AssemblyResolver=resolver});var caller=ActualCil.Emit((MC.MethodDefinition)asm.MainModule.LookupToken(0x6000598),Map,Field,Method);using var cases=JsonDocument.Parse(File.ReadAllText(args[2]));var rows=new List<object>();
  foreach(var q in cases.RootElement.EnumerateArray())
  {
   Case=q;Trace.Clear();Gift=Object("gift-object");GiftOpen=Object("gift-open-object");Text=Object("text-object");Tip=Object("tip");OtherTip=Object("other-tip");Content=Object("content");OtherContent=Object("other-content");Content.Value.Position=new(){x=3,y=BitConverter.Int32BitsToSingle(unchecked((int)Convert.ToUInt32(q.GetProperty("y").GetString(),16))),z=7};OtherContent.Value.Position=new(){x=9,y=999,z=11};Page=new(){plantSave=N("save",1)==0?null:new(){order=N("order")},gift=new(){Tag="gift",Value=Gift},gift_open=new(){Tag="gift-open",Value=GiftOpen},text_new=new(){Tag="text",Value=Text},tip_new=Tip,content=Content,preview=N("initial")==1};string? error=null;
   try{caller.Invoke(null,[Page,N("on")==1]);}catch(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;error=e.GetType().FullName;}
   rows.Add(new{name=q.GetProperty("name").GetString(),token="0x06000598",error,trace=Trace.ToArray(),state=new{preview=Page.preview,tip_root=Page.tip_new.Tag,content_root=Page.content.Tag,gift=Gift.Active,open=GiftOpen.Active,text=Text.Active,tip=Tip.Active,other_tip=OtherTip.Active}});
  }
  File.WriteAllText(args[3],JsonSerializer.Serialize(new{scope="COMPLETE_TALENT_ORDER_PREVIEW_CIL_REAL_VECTOR3_VALUE_FLOW",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),methods=1,results=rows,eh_removed=false,private_access_bypass=false,unity_or_product_acceptance=false},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{records=rows.Count,methods=1}));
 }
}
