from pathlib import Path
import itertools,json
Q=Path(__file__).resolve().parent;cases=[]
for old,new,on,order,y,mode in itertools.product([0,1,3],[0,1,3],[0,1],[-1,0,2147483647],['FF800000','80000000','00000000','42C60000','42C80000','42CA0000','7F800000','7FC01234'],['none','active-fields','transform-fields','position-fields']):
    cases.append(dict(name=f't{len(cases):05d}',token='0x06000598',old=old,next=new,on=on,order=order,y=y,mode=mode,initial=1,native_supported=True))
for on in [0,1]:cases.append(dict(name=f't{len(cases):05d}',token='0x06000598',old=0,next=1,on=on,order=0,y='00000000',mode='none',initial=1,save=0,native_supported=False))
(Q/'CASES.json').write_bytes((json.dumps(cases,indent=2)+'\n').encode());print(json.dumps(dict(normal=sum(c['native_supported'] for c in cases),managed_only=2)))
