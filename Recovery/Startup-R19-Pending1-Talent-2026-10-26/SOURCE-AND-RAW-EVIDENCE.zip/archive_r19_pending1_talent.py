"""Publish one original vector/float caller profile, retaining product gates."""
from pathlib import Path
import json
from archive_support import sha,js,pack,manifest,variants
W=Path(__file__).resolve().parent;ROOT=W.parents[1];Q=W/'r19-pending-supplement3-2026-10-26';R=ROOT/'audit/repo-native113';D=R/'Recovery/Startup-R19-Pending1-Talent-2026-10-26';H=R/'Recovery/Startup-R19-Batch100-2026-10-25';T=R/'Recovery/Startup-R20-Sites104-2026-10-26';E=R/'Recovery/Startup-R20-Editor-Diagnostic-2026-10-26'
assert not D.exists();D.mkdir();(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text\n*.md -text\n*.zip -text\n')
native=json.loads((Q/'NATIVE-ATTEMPT1.json').read_bytes());controls=json.loads((Q/'controls/RESULT.json').read_bytes());binding=json.loads((Q/'R19-AND-R20-BINDING.json').read_bytes())
assert not native['differences'] and native['normal_records']==1728 and native['caller_bytes_verified']==1
assert native['original_comiss_and_unsigned_jump_executed'] and native['real_clr_vector3_value_flow'] and native['native_vector3_sret_preserved']
assert controls['controls']==controls['detected']==2 and controls['process_failures']==0 and binding['all_rows_identical']
current=(W/'startup-r20-sites100/authored3.dll').read_bytes();parent=(W/'startup-r19-batch100/candidate9.dll').read_bytes();assert sha(current)==binding['current_sha256'] and sha(parent)==binding['parent_sha256']
assert sha((W/'startup-r5/runtime-common/Rehost.cs').read_bytes())=='59b1e80892d0038ee188f0ef36d1af25ce37ae6df71016ba6617cc221ca51d40'
delta=variants(Q/'controls',current);assert len(delta)==2;js(Q/'PHYSICAL-CONTROL-DELTAS.json',delta)
for p,name in [(Q/'NATIVE-ATTEMPT1.json','NATIVE.json'),(Q/'R19-AND-R20-BINDING.json','R19-AND-R20-BINDING.json'),(Q/'controls/RESULT.json','CONTROLS.json'),(Q/'PHYSICAL-CONTROL-DELTAS.json','PHYSICAL-CONTROL-DELTAS.json')]:(D/name).write_bytes(p.read_bytes())
files=[]
for p in sorted(Q.rglob('*')):
    if not p.is_file() or any(x in p.parts for x in ['obj','__pycache__']):continue
    if p.suffix=='.dll' and 'bin' not in p.parts:continue
    files.append(('r19-pending-supplement3/'+p.relative_to(Q).as_posix(),p.read_bytes()))
for suffix in ['.json','.txt']:
    p=W/'startup-r19-batch100/native-source-complete'/('0x06000598'+suffix);files.append(('original-native/'+p.name,p.read_bytes()))
files += [('frozen-runtime/Rehost.cs',(W/'startup-r5/runtime-common/Rehost.cs').read_bytes()),('frozen-runtime/native_runtime_common.py',(W/'startup-r5/native_runtime_common.py').read_bytes()),(Path(__file__).name,Path(__file__).read_bytes())];pack(D/'SOURCE-AND-RAW-EVIDENCE.zip',files)
pending=json.loads((H/'CURRENT-PENDING-RUNTIME-PROFILES.json').read_bytes());assert pending['methods']==26;remaining=[r for r in pending['rows'] if r['token']!='0x06000598'];assert len(remaining)==25
js(H/'CURRENT-PENDING-RUNTIME-PROFILES.json',dict(candidate_sha256=sha(parent),methods=25,not_a_count_of_confirmed_remaining_game_bugs=True,added_supplement='../'+D.name,rows=remaining))
s=json.loads((H/'PROGRESS.json').read_bytes());assert s['finite_comparison_method_union']==74 and s['total_native_finite_comparison_records']==19728
s.update(status='HUNDRED_CONSTRUCTED_SEVENTY_FIVE_FINITE_PROFILES_BATCH_QUALIFICATION_PENDING',finite_comparison_method_union=75,other_runtime_profile_count=25,total_native_finite_comparison_records=21456,
    finite_original_native_vs_complete_cil_additional_methods=40,talent_order_normal_records=1728,talent_order_managed_only_records=2,talent_order_physical_controls=2,talent_order_detected_controls=2,
    total_physical_controls_including_foreach_and_new_profiles=s['total_physical_controls_including_foreach_and_new_profiles']+2,total_runtime_differences_including_supplements=s['total_runtime_differences_including_supplements']+2)
js(H/'PROGRESS.json',s)
js(D/'PROGRESS.json',dict(status='ONE_FINITE_FULL_TALENT_ORDER_CALLER_PASS_PRODUCT_PENDING',parent_candidate_sha256=sha(parent),current_candidate_sha256=sha(current),new_game_code_changes=0,methods=1,native_normal_records=1728,managed_only_records=2,controls_detected=2,r19_finite_union=75,r19_native_comparison_records=21456,r19_pending_profiles=25,unity=False,ipa=None,ipad_acceptance=False))
(D/'README.md').write_bytes('''# R19 天赋升级预览：完整浮点/结构体调用方对照

0x06000598 Almanac_TalentSystem.PreviewOrderUp(bool) 在两个固定候选 R19 candidate9 / R20 authored3 上实际发射并执行完整 CIL。1,730条CLR记录相同，其中1,728条正常路径与未改的完整原版调用方一致；两个空存档 CLR 异常另列。游戏DLL和冻结Rehost不变。

原版执行 comiss 与无符号跳转，100f阈值直接从PC常量字节0000c842核验。覆盖NaN、正负零、正负Infinity、99/100/101、旧/新天赋数量、开关、order=-1/0/Int32.MaxValue以及激活/Transform/位置回调的字段替换；同时保留原生Vector3隐藏返回缓冲区协议，在CLR内实际按值传递结构体。正常路径0差异。

两个物理故障进程正常完成并产生可定位差异：阈值100f改0f（162条）、保持栈平衡但漏掉最终Preview调用（1,152条）。完整变体通过增量重建和SHA验证保留，没有靠异常/崩溃报通过。

天赋数量、子Preview及Unity组件/激活/Transform/localPosition为明确受控叶函数，不代表其内部已恢复，也不证明实际Unity画面、Windows SEH或普遍等价。R19有限profile联合数75，累计原版正常记录21,456，25个完整profile待完成。没有新增游戏改动，没有新的编译/Unity导出、链接、IPA或设备验收；R20真实Editor诊断作为独立工作流另行记录。
'''.encode())
p=H/'README.md';v=p.read_text('utf-8');v+='\n## 天赋升级预览完整调用方补充\n\n[独立浮点/Vector3补充](../Startup-R19-Pending1-Talent-2026-10-26/README.md) 保存1,728条正常原版对照、两个固定候选重放、两个CLR-only异常与两个检出的物理故障。R19有限联合75 /21,456条记录，25个profile待完成。\n';p.write_bytes(v.encode())
s=json.loads((T/'PROGRESS.json').read_bytes());s.update(r19_runtime_profiles_still_pending=25,r19_additional_finite_profiles_verified_on_current_r20=10,unity='REAL_EDITOR_DIAGNOSTIC_RUNNING_40224994102');js(T/'PROGRESS.json',s)
q=json.loads((T/'CURRENT-WORK-QUEUE.json').read_bytes());row=next(r for r in q['rows'] if r['token']=='0x06000598');assert row['parent_census_priority']=='P1_R19_RUNTIME_PROFILE';row.update(current_state='R19_BODY_FINITE_PROFILE_PASS_BOTH_EXACT_CANDIDATES_PRODUCT_PENDING',r19_runtime_pending=False,normal_native_records=1728,current_required_action='Actual engine/product integration remains pending; finite full-caller supplement is archived');q.update(other_parent_followup_work_items=138,additional_parent_r19_profiles_completed=10);js(T/'CURRENT-WORK-QUEUE.json',q)
s=json.loads((E/'PROGRESS.json').read_bytes());s.update(status='REAL_EDITOR_WORKFLOW_RUNNING',run_id=40224994102,url='https://github.com/lyiming710-cloud/GodsPVZ-iOS/actions/runs/40224994102',source_commit='e3b7e3d998bf1100cf7995bcce59cc474f316d47',conversion_binding='PASS',editor_helper_preflight='PASS',unity_result='PENDING');js(E/'PROGRESS.json',s)
p=E/'README.md';v=p.read_text('utf-8');v+='\n## 已启动\n\n[真实Editor诊断40224994102](https://github.com/lyiming710-cloud/GodsPVZ-iOS/actions/runs/40224994102) 使用固定提交e3b7e3d和d887b370候选；候选绑定、管线控制和辅助工具编译已通过。此检查点记录时正在还原精确Unity Editor，实际场景/着色器/PlayMode结果尚待回读。没有IPA产物。\n';p.write_bytes(v.encode())
p=R/'README.md';v=p.read_text('utf-8');assert 'Seventy-four methods now have 19,728' in v;v=v.replace('Seventy-four methods now have 19,728','Seventy-five methods now have 21,456').replace('Twenty-six other runtime profiles','Twenty-five other runtime profiles').replace('80 physical controls: 76 runtime differences','82 physical controls: 78 runtime differences');p.write_bytes(v.encode())
p=R/'Recovery/STATUS.md';v=p.read_text('utf-8');marker='## Latest checkpoint - 2026-10-26\n';v=v.replace(marker,marker+'\n[R19 talent-order supplement](Startup-R19-Pending1-Talent-2026-10-26/README.md): one additional complete caller matches1,728 normal original records on both exact candidates, including actual comiss/unsigned branches and Vector3 sret/CLR value flow. Both physical faults are detected; two CLR-only exceptions stay separate. R19 finite union75 /21,456 records,25 pending. R20 real Editor diagnostic40224994102 is running after binding/helper preflight pass; no current Editor/IPA/device success inferred.\n',1);p.write_bytes(v.encode())
for d in [D,H,T,E]:manifest(d)
print(json.dumps(dict(r19_finite_methods=75,r19_native_records=21456,pending_profiles=25,new_game_code_changes=0,editor_run=40224994102)))
