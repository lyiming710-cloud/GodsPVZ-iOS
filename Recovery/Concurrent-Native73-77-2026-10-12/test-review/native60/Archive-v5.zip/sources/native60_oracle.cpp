#include <sys/mman.h>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <vector>
#include <random>
#include <stdexcept>
#include <csetjmp>

template<class T>T at(const std::vector<char>&b,size_t p){T x;std::memcpy(&x,b.data()+p,sizeof x);return x;}
template<class T>void put(void*p,size_t off,T x){std::memcpy(static_cast<char*>(p)+off,&x,sizeof x);}
template<class T>T get(void*p,size_t off){T x;std::memcpy(&x,(char*)p+off,sizeof x);return x;}

struct V3{uint32_t x,y,z;};

alignas(16) char self[1024], board[1024], zm[1024], elemMgr[256], elem[256];
alignas(16) char audioList[256], clip[64], camera[64], transform[64], audioSource[64];
alignas(16) char saveObj[256], boolArray[256], zombieInfo[256], eliteMark[256], bossMark[256], goElite[64], goBoss[64];
alignas(16) char readyClass[512], statics[1024];

int token, mode, hook, scenario, err;
uint64_t trace;
bool argsOK;
uint32_t volumeBits, audioVolumeVal;
V3 pos, alternatePos, audioPos;
int activeCalls, audioCalls, setStateCalls;
int eliteActive, bossActive, stateVal, clipIndexChosen;

std::jmp_buf jump;

int id(void* p) {
    void* all[] = {
        nullptr, self, board, zm, elemMgr, elem, audioList, clip, camera, transform, audioSource,
        saveObj, boolArray, zombieInfo, eliteMark, bossMark, goElite, goBoss
    };
    for (int i = 0; i < 18; i++) if (p == all[i]) return i;
    return 99;
}

void event(int e, void* r = nullptr) {
    trace = trace * 131 + (uint64_t)(e * 32 + id(r));
}

extern "C" void __attribute__((ms_abi)) hook_init(void*) { return; }

extern "C" void __attribute__((ms_abi)) nre() {
    event(30);
    err = 1;
    std::longjmp(jump, 1);
}

extern "C" void __attribute__((ms_abi)) out_of_range() {
    event(31);
    err = 2;
    std::longjmp(jump, 1);
}

void failure() {
    event(32);
    err = 3;
    std::longjmp(jump, 1);
}

float F(uint32_t x){float f;std::memcpy(&f,&x,4);return f;}
uint32_t B(float f){uint32_t x;std::memcpy(&x,&f,4);return x;}

// 0x0600046D Hooks
extern "C" bool __attribute__((ms_abi)) hook_isDisabled(void* r) {
    event(1, r);
    if (hook == 1) put<void*>(self, 0x108, nullptr); // elementManager = null
    if (hook == 2) put<void*>(self, 0x20, nullptr);  // board = null
    if (mode == 4) failure();
    return (scenario == 1);
}

extern "C" void* __attribute__((ms_abi)) hook_getElement(void* r, int type) {
    event(2, r);
    argsOK &= (type == 0);
    if (mode == 5) failure();
    return (mode == 2) ? nullptr : elem;
}

extern "C" int __attribute__((ms_abi)) hook_randomRange(int min, int max) {
    event(3);
    argsOK &= (min == 8 && max == 10);
    if (hook == 3) put<void*>(zm, 0x28, nullptr); // audioClip_zombie = null
    if (mode == 6) failure();
    return (scenario == 2) ? 8 : 9;
}

extern "C" void* __attribute__((ms_abi)) hook_listItem(void* r, int index) {
    event(4, r);
    clipIndexChosen = index;
    if (mode == 7 || index < 0 || index >= 16) out_of_range();
    return clip;
}

extern "C" void* __attribute__((ms_abi)) hook_mainCamera() {
    event(5);
    if (mode == 8) return nullptr;
    return camera;
}

extern "C" void* __attribute__((ms_abi)) hook_componentTransform(void* r) {
    event(6, r);
    if (mode == 9) return nullptr;
    return transform;
}

extern "C" V3* __attribute__((ms_abi)) hook_getPosition(V3* out, void* r) {
    event(7, r);
    if (hook == 4) pos = alternatePos;
    *out = pos;
    return out;
}

extern "C" float __attribute__((ms_abi)) hook_audioVolume() {
    event(8);
    return F(volumeBits);
}

extern "C" void* __attribute__((ms_abi)) hook_createAudioAtPoint(void* c, V3* p, float vol) {
    event(9, c);
    audioCalls++;
    audioPos = *p;
    audioVolumeVal = B(vol);
    return audioSource;
}

// 0x060005B9 Hooks
extern "C" void __attribute__((ms_abi)) hook_setState(void* r, bool s) {
    event(10, r);
    setStateCalls++;
    stateVal = s ? 1 : 0;
    if (hook == 1) put<void*>(self, 0x50, nullptr); // eliteMark = null
    if (hook == 2) put<void*>(self, 0x58, nullptr); // bossMark = null
    if (mode == 10) failure();
}

extern "C" void* __attribute__((ms_abi)) hook_loadZombieInfo(int id) {
    event(11);
    if (mode == 11) failure();
    return (mode == 3) ? nullptr : zombieInfo;
}

extern "C" void* __attribute__((ms_abi)) hook_gameObject(void* r) {
    event(12, r);
    if (r == eliteMark) return goElite;
    if (r == bossMark) return goBoss;
    return goElite;
}

extern "C" void __attribute__((ms_abi)) hook_setActive(void* r, bool a) {
    event(13, r);
    activeCalls++;
    if (r == goElite) eliteActive = a ? 1 : 0;
    if (r == goBoss) bossActive = a ? 1 : 0;
}

void dependency(uint64_t va, void* f) {
    unsigned char bytes[12] = {0x48, 0xb8, 0, 0, 0, 0, 0, 0, 0, 0, 0xff, 0xe0};
    std::memcpy(bytes + 2, &f, 8);
    std::memcpy((void*)va, bytes, 12);
    if (std::memcmp((void*)va, bytes, 12)) throw std::runtime_error("trampoline");
}

int main(int argc, char** argv) {
    if (argc != 2) return 2;
    std::ifstream f(argv[1], std::ios::binary);
    std::vector<char> b((std::istreambuf_iterator<char>(f)), {});
    auto nt = at<uint32_t>(b, 60);
    if (at<uint32_t>(b, nt) != 0x4550 || at<uint16_t>(b, nt + 24) != 0x20b) throw std::runtime_error("PE64 required");
    auto base = at<uint64_t>(b, nt + 48);
    auto size = at<uint32_t>(b, nt + 80);
    auto ns = at<uint16_t>(b, nt + 6), opt = at<uint16_t>(b, nt + 20);
    auto p = mmap((void*)base, size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED_NOREPLACE, -1, 0);
    if (p == MAP_FAILED || reinterpret_cast<uint64_t>(p) != base) throw std::runtime_error("base mmap failed");
    std::memcpy(p, b.data(), at<uint32_t>(b, nt + 84));
    for (int i = 0; i < ns; i++) {
        auto s = nt + 24 + opt + 40 * i;
        auto rva = at<uint32_t>(b, s + 12), len = at<uint32_t>(b, s + 16), raw = at<uint32_t>(b, s + 20);
        if (uint64_t(raw) + len > b.size() || uint64_t(rva) + len > size) throw std::runtime_error("bounds");
        std::memcpy((char*)p + rva, b.data() + raw, len);
    }

    // Set metadata ready flags so native code doesn't call il2cpp initialization
    for (auto va : {0x181ce4d7aULL, 0x181ce4e6bULL, 0x181ce4cf5ULL, 0x181ce4ddcULL, 0x181ce4d7bULL, 0x181ce4d7cULL, 0x181ce4f4cULL, 0x181ce4fd6ULL}) {
        put<uint8_t>((void*)va, 0, 1);
    }

    put<int>(readyClass, 0xe0, 1);
    put<void*>(readyClass, 0xb8, statics);
    for (auto va : {0x181ba2018ULL, 0x181ba4278ULL, 0x181bb0500ULL, 0x181bb6478ULL, 0x181bcb4a0ULL}) {
        put<void*>((void*)va, 0, readyClass);
    }

    dependency(0x18024fef0, (void*)&hook_init);
    dependency(0x1802501e0, (void*)&hook_init);
    dependency(0x180250150, (void*)&nre);
    dependency(0x180250140, (void*)&out_of_range);
    dependency(0x18024f360, (void*)&hook_init); // gc write barrier

    dependency(0x1803659e0, (void*)&hook_isDisabled);
    dependency(0x180315250, (void*)&hook_getElement);
    dependency(0x18130d310, (void*)&hook_randomRange);
    dependency(0x180825710, (void*)&hook_listItem);
    dependency(0x1812e27c0, (void*)&hook_mainCamera);
    dependency(0x181304510, (void*)&hook_componentTransform);
    dependency(0x18132f3a0, (void*)&hook_getPosition);
    dependency(0x18031aea0, (void*)&hook_audioVolume);
    dependency(0x18031b230, (void*)&hook_createAudioAtPoint);

    dependency(0x180394160, (void*)&hook_setState);
    dependency(0x18033ae30, (void*)&hook_loadZombieInfo);
    dependency(0x1813044d0, (void*)&hook_gameObject);
    dependency(0x18131bad0, (void*)&hook_setActive);

    if (mprotect(p, size, PROT_READ | PROT_EXEC)) throw std::runtime_error("mprotect failed");

    using VoidFn = void(__attribute__((ms_abi))*)(void*);
    using SetDataFn = void(__attribute__((ms_abi))*)(void*, void*, int);

    std::mt19937 rng(0x602026);
    uint32_t edges[] = {0, 0x3f800000, 0xbf800000, 0x7f800000, 0x3f000000};

    int targets[] = {0x0600046D, 0x060005B9};

    for (int t : targets) {
        for (int k = 0; k < 4096; k++) {
            token = t;
            mode = k % 16;
            hook = (k / 16) % 8;
            scenario = (k / 128) % 16;
            volumeBits = edges[(k / 32) % 5];
            pos = {(uint32_t)rng(), (uint32_t)rng(), (uint32_t)rng()};
            alternatePos = {(uint32_t)rng(), (uint32_t)rng(), (uint32_t)rng()};
            V3 initialPos = pos;
            alternatePos = {(uint32_t)rng(), (uint32_t)rng(), (uint32_t)rng()};
            trace = 0; err = 0; argsOK = true;
            activeCalls = audioCalls = setStateCalls = 0;
            eliteActive = bossActive = stateVal = -1;
            clipIndexChosen = -1;
            audioVolumeVal = 0xdeadbeef;
            audioPos = {0xdeadbeef, 0xdeadbeef, 0xdeadbeef};

            std::memset(self, 0, sizeof(self));
            std::memset(board, 0, sizeof(board));
            std::memset(zm, 0, sizeof(zm));
            std::memset(elemMgr, 0, sizeof(elemMgr));
            std::memset(elem, 0, sizeof(elem));
            std::memset(saveObj, 0, sizeof(saveObj));
            std::memset(boolArray, 0, sizeof(boolArray));
            std::memset(zombieInfo, 0, sizeof(zombieInfo));

            if (t == 0x0600046D) {
                put<void*>(self, 0x108, (mode == 1) ? nullptr : elemMgr);
                put<float>(elem, 0x24, (scenario == 3) ? 0.0f : 1.0f);
                put<void*>(self, 0x20, (mode == 3) ? nullptr : board);
                put<void*>(board, 0xf0, zm);
                put<void*>(zm, 0x28, audioList);
            } else if (t == 0x060005B9) {
                put<void*>(self, 0x50, (mode == 1) ? nullptr : eliteMark);
                put<void*>(self, 0x58, (mode == 2) ? nullptr : bossMark);
                put<void*>(saveObj, 0x80, (mode == 4) ? nullptr : boolArray);
                put<int>(boolArray, 0x18, 16);
                put<uint8_t>(boolArray, 0x20 + (scenario % 16), (scenario % 2));
                put<uint8_t>(zombieInfo, 0x20, (scenario & 1));
                put<uint8_t>(zombieInfo, 0x21, ((scenario >> 1) & 1));
            }

            if (setjmp(jump) == 0) {
                if (t == 0x0600046D) ((VoidFn)0x180366640)(self);
                else if (t == 0x060005B9) ((SetDataFn)0x180394240)(self, (mode == 5) ? nullptr : saveObj, scenario);
            }

            std::cout << "0x" << std::hex << t << std::dec << " "
                      << mode << " " << hook << " " << scenario << " "
                      << volumeBits << " " << initialPos.x << " " << initialPos.y << " " << initialPos.z << " " << alternatePos.x << " " << alternatePos.y << " " << alternatePos.z << " "
                      << trace << " " << err << " " << (argsOK ? 1 : 0) << " "
                      << activeCalls << " " << audioCalls << " " << setStateCalls << " "
                      << eliteActive << " " << bossActive << " " << stateVal << " " << ((t == 0x060005B9) ? get<int>(self, 0x28) : 0) << " "
                      << clipIndexChosen << " "
                      << audioVolumeVal << " " << audioPos.x << " " << audioPos.y << " " << audioPos.z << "\n";
        }
    }
    munmap(p, size);
    return 0;
}
