using System; using System.IO; using System.Linq; using System.Collections.Generic; using System.Security.Cryptography; using System.Text.Json;
using Mono.Cecil; using System.Reflection.PortableExecutable; using System.Reflection.Metadata;
using AssemblyDefinition = Mono.Cecil.AssemblyDefinition; using MethodDefinition = Mono.Cecil.MethodDefinition;
class P {
    static void Require(bool b, string m) { if (!b) throw new Exception(m); }
    static string Hash(byte[] b) => Convert.ToHexString(SHA256.HashData(b)).ToLowerInvariant();
    static int Off(PEReader pe, int rva) {
        var s = pe.PEHeaders.SectionHeaders.Single(s => rva >= s.VirtualAddress && rva < s.VirtualAddress + s.SizeOfRawData);
        return s.PointerToRawData + rva - s.VirtualAddress;
    }
    static void Main(string[] args) {
        byte[] pBytes = File.ReadAllBytes(args[0]);
        byte[] cBytes = File.ReadAllBytes(args[1]);
        using var pPe = new PEReader(new MemoryStream(pBytes));
        using var cPe = new PEReader(new MemoryStream(cBytes));
        Require(pPe.GetMetadata().GetContent().SequenceEqual(cPe.GetMetadata().GetContent()), "Metadata must be bit-identical");

        using var pAsm = AssemblyDefinition.ReadAssembly(args[0]);
        using var cAsm = AssemblyDefinition.ReadAssembly(args[1]);
        var targets = new HashSet<int> { 0x0600046D, 0x060005B9 };
        int nonTargetCount = 0;
        int nonTargetIdentical = 0;

        foreach (var type in pAsm.MainModule.GetTypes()) {
            foreach (var m in type.Methods) {
                if (!m.HasBody) continue;
                int token = m.MetadataToken.ToInt32();
                if (!targets.Contains(token)) {
                    nonTargetCount++;
                    var cm = (MethodDefinition)cAsm.MainModule.LookupToken(token);
                    Require(cm.HasBody, "Non-target body must exist: " + m.FullName);
                    Require(m.Body.CodeSize == cm.Body.CodeSize, "Code size match: " + m.FullName);
                    int h1 = Off(pPe, m.RVA);
                    int h2 = Off(cPe, cm.RVA);
                    int len = pPe.GetMethodBody(m.RVA).Size;
                    var b1 = pBytes.AsSpan(h1, len);
                    var b2 = cBytes.AsSpan(h2, len);
                    Require(b1.SequenceEqual(b2), "Raw body match: " + m.FullName);
                    nonTargetIdentical++;
                }
            }
        }

        var rep = new {
            parent_sha256 = Hash(pBytes),
            candidate_sha256 = Hash(cBytes),
            metadata_identical = true,
            non_target_bodies_total = nonTargetCount,
            non_target_bodies_identical = nonTargetIdentical,
            isolation_passed = (nonTargetCount == nonTargetIdentical && nonTargetIdentical == 2295)
        };
        File.WriteAllText(args[2], JsonSerializer.Serialize(rep, new JsonSerializerOptions { WriteIndented = true }));
    }
}
