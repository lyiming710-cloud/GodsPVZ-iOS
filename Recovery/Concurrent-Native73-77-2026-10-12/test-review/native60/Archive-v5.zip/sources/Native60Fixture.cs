using Mono.Cecil;
using RO = System.Reflection.Emit.OpCodes;
using System.Reflection;
using System.Reflection.Emit;
using System.Security.Cryptography;
using System.Text.Json;
using UnityEngine;

public class DependencyException : Exception {}
public class Obj {}
public class Zombie : Obj {
    public Manager? elementManager;
    public Board? board;
}
public class Board : Obj {
    public ZombieManager? zombieManager;
}
public class ZombieManager : Obj {
    public Clips? audioClip_zombie;
}
public class Manager : Obj {}
public class Element : Obj {
    public float point;
}
public class Clips : Obj {}
public class Clip : Obj {}
public class Source : Obj {}
public class Camera : Obj {}
public class Transform : Obj {}
public class Save : Obj {
    public bool[]? almanac_ZombieLock;
}
public class ZombieInfo : Obj {
    public bool isElite;
    public bool isBoss;
}
public class Image : Obj {}
public class Game : Obj {}
public class Almanac_ZombieWindow : Obj {
    public int zombieID;
    public ZombieInfo? zombieInfo;
    public Image? eliteMark;
    public Image? bossMark;
}

public static class State {
    public static Obj self = new();
    public static Board board = new();
    public static ZombieManager zm = new();
    public static Manager elemMgr = new();
    public static Element elem = new();
    public static Clips audioList = new();
    public static Clip clip = new();
    public static Camera camera = new();
    public static Transform transform = new();
    public static Source audioSource = new();
    public static Save saveObj = new();
    public static bool[] boolArray = new bool[16];
    public static ZombieInfo zombieInfo = new();
    public static Image eliteMark = new(), bossMark = new();
    public static Game goElite = new(), goBoss = new();

    public static int token, mode, hook, scenario, err;
    public static ulong trace;
    public static bool argsOK;
    public static uint volumeBits, audioVolumeVal;
    public static Vector3 pos, alternatePos, audioPos;
    public static int activeCalls, audioCalls, setStateCalls;
    public static int eliteActive, bossActive, stateVal, clipIndexChosen;

    public static int ID(object? p) {
        object?[] all = {
            null, self, board, zm, elemMgr, elem, audioList, clip, camera, transform, audioSource,
            saveObj, boolArray, zombieInfo, eliteMark, bossMark, goElite, goBoss
        };
        for (int i = 0; i < all.Length; i++) if (ReferenceEquals(p, all[i])) return i;
        return 99;
    }

    public static void Ev(int e, object? r = null) => trace = unchecked(trace * 131 + (uint)(e * 32 + ID(r)));
    public static void Check(object? r) { if (r == null) throw new NullReferenceException(); }
    public static void Fail() { Ev(32); throw new DependencyException(); }
    public static float F(uint x) => BitConverter.Int32BitsToSingle(unchecked((int)x));
    public static uint B(float x) => unchecked((uint)BitConverter.SingleToInt32Bits(x));

    public static bool IsDisabled(Zombie? r) {
        Check(r); Ev(1, r);
        if (hook == 1) ((Zombie)self).elementManager = null;
        if (hook == 2) ((Zombie)self).board = null;
        if (mode == 4) Fail();
        return (scenario == 1);
    }

    public static Element? GetElement(Manager? r, int type) {
        Check(r); Ev(2, r);
        argsOK &= (type == 0);
        if (mode == 5) Fail();
        return (mode == 2) ? null : elem;
    }

    public static int RandomRange(int min, int max) {
        Ev(3);
        argsOK &= (min == 8 && max == 10);
        if (hook == 3) zm.audioClip_zombie = null;
        if (mode == 6) Fail();
        return (scenario == 2) ? 8 : 9;
    }

    public static Clip? GetItem(Clips? r, int index) {
        Check(r); Ev(4, r);
        clipIndexChosen = index;
        Console.WriteLine($"[GET_ITEM_CALLED] index={index}");
        if (mode == 7 || index < 0 || index >= 16) throw new IndexOutOfRangeException();
        return clip;
    }

    public static Camera? MainCamera() {
        Ev(5);
        if (mode == 8) return null;
        return camera;
    }

    public static Transform? GetTransform(Obj? r) {
        Check(r); Ev(6, r);
        if (mode == 9) return null;
        return transform;
    }

    public static Vector3 GetPosition(Transform? r) {
        Check(r); Ev(7, r);
        if (hook == 4) pos = alternatePos;
        return pos;
    }

    public static float AudioVolume() {
        Ev(8);
        return F(volumeBits);
    }

    public static Source? CreateAudioAtPoint(Clip? c, Vector3 p, float vol) {
        Ev(9, c);
        audioCalls++;
        audioPos = p;
        audioVolumeVal = B(vol);
        return audioSource;
    }

    public static void SetState(Almanac_ZombieWindow? r, bool s) {
        Check(r); Ev(10, r);
        setStateCalls++;
        stateVal = s ? 1 : 0;
        if (hook == 1) ((Almanac_ZombieWindow)self).eliteMark = null;
        if (hook == 2) ((Almanac_ZombieWindow)self).bossMark = null;
        if (mode == 10) Fail();
    }

    public static ZombieInfo? LoadZombieInfo(int id) {
        Ev(11);
        if (mode == 11) Fail();
        return (mode == 3) ? null : zombieInfo;
    }

    public static Game? GameObject(Obj? r) {
        Check(r); Ev(12, r);
        if (ReferenceEquals(r, eliteMark)) return goElite;
        if (ReferenceEquals(r, bossMark)) return goBoss;
        return goElite;
    }

    public static void SetActive(Game? r, bool a) {
        Check(r); Ev(13, r);
        activeCalls++;
        if (ReferenceEquals(r, goElite)) eliteActive = a ? 1 : 0;
        if (ReferenceEquals(r, goBoss)) bossActive = a ? 1 : 0;
    }
}

public static class Fixture {
    static Type T(TypeReference r) {
        if (r is ByReferenceType br) return T(br.ElementType).MakeByRefType();
        return r.FullName switch {
            "System.Void" => typeof(void),
            "System.Object" => typeof(object),
            "System.Boolean" => typeof(bool),
            "System.Single" => typeof(float),
            "System.String" => typeof(string),
            "System.Int32" => typeof(int),
            "UnityEngine.Vector3" => typeof(Vector3),
            "UnityEngine.AudioClip" => typeof(Clip),
            "UnityEngine.AudioSource" => typeof(Source),
            "UnityEngine.Camera" => typeof(Camera),
            "UnityEngine.Transform" => typeof(Transform),
            "UnityEngine.GameObject" => typeof(Game),
            "UnityEngine.UI.Image" => typeof(Image),
            "UnityEngine.Component" or "UnityEngine.Object" => typeof(Obj),
            "Zombie" => typeof(Zombie),
            "Board" => typeof(Board),
            "ZombieManager" => typeof(ZombieManager),
            "ElementManager" => typeof(Manager),
            "Element" => typeof(Element),
            "Save" => typeof(Save),
            "ZombieInfo" => typeof(ZombieInfo),
            "Almanac_ZombieWindow" => typeof(Almanac_ZombieWindow),
            "System.Boolean[]" => typeof(bool[]),
            "System.Collections.Generic.List`1<UnityEngine.AudioClip>" => typeof(Clips),
            _ => throw new Exception("Unmapped type " + r)
        };
    }

    static Delegate Emit(MethodDefinition m, string mutation) {
        int rid = (int)m.MetadataToken.RID;
        var ret = T(m.ReturnType);
        var param = new[] { T(m.DeclaringType) }.Concat(m.Parameters.Select(p => T(p.ParameterType))).ToArray();
        var dm = new DynamicMethod(m.FullName + mutation, ret, param, typeof(Fixture).Module, false) { InitLocals = m.Body.InitLocals };
        var il = dm.GetILGenerator();
        var labels = m.Body.Instructions.ToDictionary(i => i, i => il.DefineLabel());
        var ops = typeof(RO).GetFields().Where(f => f.FieldType == typeof(System.Reflection.Emit.OpCode)).Select(f => (System.Reflection.Emit.OpCode)f.GetValue(null)!).ToDictionary(o => o.Value);
        var locals = m.Body.Variables.Select(v => il.DeclareLocal(T(v.VariableType))).ToArray();

        foreach (var i in m.Body.Instructions) {
            il.MarkLabel(labels[i]);
            var op = ops[i.OpCode.Value];

            if (i.Operand is FieldReference f) {
                var fi = T(f.DeclaringType).GetField(f.Name) ?? throw new Exception("Field " + f);
                if (mutation == "almanac_no_id_write" && f.Name == "zombieID") {
                    il.Emit(RO.Pop); il.Emit(RO.Pop);
                    continue;
                }
                il.Emit(op, fi);
                continue;
            }

            if (i.Operand is MethodReference r) {
                string name = r.Name switch {
                    "IsDisabled" => nameof(State.IsDisabled),
                    "GetElement" => nameof(State.GetElement),
                    "Range" => nameof(State.RandomRange),
                    "get_Item" => nameof(State.GetItem),
                    "get_main" => nameof(State.MainCamera),
                    "get_transform" => nameof(State.GetTransform),
                    "get_position" => nameof(State.GetPosition),
                    "AudioVolume" => nameof(State.AudioVolume),
                    "CreateAudioAtPoint" => nameof(State.CreateAudioAtPoint),
                    "SetState" => nameof(State.SetState),
                    "Load_zombieInfo" => nameof(State.LoadZombieInfo),
                    "get_gameObject" => nameof(State.GameObject),
                    "SetActive" => nameof(State.SetActive),
                    _ => throw new Exception("Call " + r)
                };

                if (mutation == "eat_skip_isdisabled" && r.Name == "IsDisabled") {
                    il.Emit(RO.Pop);
                    il.Emit(RO.Ldc_I4_0);
                    continue;
                }
                if (mutation == "almanac_wrong_state" && r.Name == "SetState") {
                    il.Emit(RO.Ldc_I4_0);
                    il.Emit(RO.Ceq);
                }
                il.Emit(RO.Call, typeof(State).GetMethod(name)!);
                continue;
            }

            if (i.Operand is Mono.Cecil.Cil.Instruction j) {
                if (mutation == "almanac_no_null_check" && rid == 0x5b9 && (op.Value == RO.Brfalse_S.Value || op.Value == RO.Brfalse.Value)) {
                    il.Emit(RO.Pop);
                    continue;
                }
                il.Emit(op, labels[j]);
                continue;
            }

            if (i.Operand is Mono.Cecil.Cil.VariableDefinition v) {
                il.Emit(op, locals[v.Index]);
                continue;
            }
            if (i.Operand is ParameterDefinition a) {
                il.Emit(op, (short)(a.Index + 1));
                continue;
            }
            if (i.Operand is float fl) {
                il.Emit(op, fl);
                continue;
            }
            if (i.Operand is sbyte b) {
                if (mutation == "eat_wrong_range" && b == 10) b = 11;
                il.Emit(op, b);
                continue;
            }
            if (i.Operand is int k) {
                il.Emit(op, k);
                continue;
            }

            il.Emit(op);
        }
        return dm.CreateDelegate(System.Linq.Expressions.Expression.GetDelegateType(param.Concat(new[] { ret }).ToArray()));
    }

    static Vector3 Vector(ulong[] r, int at) => new(State.F((uint)r[at]), State.F((uint)r[at + 1]), State.F((uint)r[at + 2]));
    static ulong ParseVal(string s) => uint.TryParse(s, out var u) ? u : (s.StartsWith('-') ? (uint)int.Parse(s) : ulong.Parse(s));

    public static (int count, int fail, List<string> samples) Cases(Dictionary<int, Delegate> fs, List<ulong[]> rows, bool stop = false) {
        int count = 0, fail = 0;
        var samples = new List<string>();

        foreach (var r in rows) {
            int t = (int)r[0];
            State.token = t;
            State.mode = (int)r[1];
            State.hook = (int)r[2];
            State.scenario = (int)r[3];
            State.volumeBits = (uint)r[4];
            State.pos = Vector(r, 5);
            State.alternatePos = Vector(r, 8);

            if (t == 0x0600046D) {
                State.self = new Zombie {
                    elementManager = (State.mode == 1) ? null : State.elemMgr,
                    board = (State.mode == 3) ? null : State.board
                };
                State.elem.point = (State.scenario == 3) ? 0.0f : 1.0f;
                State.board.zombieManager = State.zm;
                State.zm.audioClip_zombie = State.audioList;
            } else if (t == 0x060005B9) {
                State.self = new Almanac_ZombieWindow {
                    eliteMark = (State.mode == 1) ? null : State.eliteMark,
                    bossMark = (State.mode == 2) ? null : State.bossMark
                };
                State.saveObj.almanac_ZombieLock = (State.mode == 4) ? null : State.boolArray;
                State.boolArray[State.scenario % 16] = (State.scenario % 2 == 1);
                State.zombieInfo.isElite = (State.scenario & 1) == 1;
                State.zombieInfo.isBoss = ((State.scenario >> 1) & 1) == 1;
            }

            State.trace = 0; State.err = 0; State.argsOK = true;
            State.activeCalls = State.audioCalls = State.setStateCalls = 0;
            State.eliteActive = State.bossActive = State.stateVal = -1;
            State.clipIndexChosen = -1;
            State.audioVolumeVal = 0xdeadbeef;
            State.audioPos = new Vector3(State.F(0xdeadbeef), State.F(0xdeadbeef), State.F(0xdeadbeef));

            try {
                if (t == 0x0600046D) fs[t].DynamicInvoke(State.self);
                else if (t == 0x060005B9) fs[t].DynamicInvoke(State.self, (State.mode == 5) ? null : State.saveObj, State.scenario);
            } catch (Exception e) {
                var ex = e is TargetInvocationException ? e.InnerException! : e;
                if (ex is NullReferenceException) { State.Ev(30); State.err = 1; }
                else if (ex is IndexOutOfRangeException) { State.Ev(31); State.err = 2; }
                else if (ex is DependencyException) { State.err = 3; }
                else throw ex;
            }

            ulong[] observed = {
                State.trace, (uint)State.err, State.argsOK ? 1UL : 0,
                (uint)State.activeCalls, (uint)State.audioCalls, (uint)State.setStateCalls,
                unchecked((uint)State.eliteActive), unchecked((uint)State.bossActive), unchecked((uint)State.stateVal),
                unchecked((uint)((State.self is Almanac_ZombieWindow azw) ? azw.zombieID : 0)),
                unchecked((uint)State.clipIndexChosen),
                State.audioVolumeVal, State.B(State.audioPos.x), State.B(State.audioPos.y), State.B(State.audioPos.z)
            };

            var bad = observed.Select((v, i) => (v, i)).Where(x => x.v != r[x.i + 11]).ToArray();
            count++;
            if (bad.Length > 0) {
                fail++;
                if (samples.Count < 5) samples.Add($"0x{t:X8} case={count} mode={State.mode} hook={State.hook} diffs={string.Join(',', bad.Select(x => $"obs[{x.i}]={x.v} vs r[{x.i+11}]={r[x.i+11]}"))}");
                if (stop) return (count, fail, samples);
            }
        }
        return (count, fail, samples);
    }

    public static int Main(string[] args) {
        try {
            using var a = AssemblyDefinition.ReadAssembly(args[0]);
            int[] ts = { 0x0600046D, 0x060005B9 };
            var ms = ts.ToDictionary(t => t, t => (MethodDefinition)a.MainModule.LookupToken(t));
var rows = File.ReadLines(args[1]).Select(l => l.Split(' ')).Select(v => new[] { (ulong)Convert.ToInt32(v[0], 16) }.Concat(v.Skip(1).Select(ParseVal)).ToArray()).ToList();

            var positive = Cases(ms.ToDictionary(x => x.Key, x => Emit(x.Value, "none")), rows);
            Console.WriteLine($"Positive: count={positive.count}, fail={positive.fail}");
            foreach (var s in positive.samples) Console.WriteLine($"DIFF SAMPLE: {s}");

            var controls = new List<object>();
            bool cp = true;
            foreach (string mut in new[] { "eat_skip_isdisabled", "eat_wrong_range", "almanac_wrong_state", "almanac_no_id_write", "almanac_no_null_check" }) {
                bool detected = false;
                string stage = "none";
                string? diff = null;
                int casesRun = 0;
                try {
                    var delMap = ms.ToDictionary(x => x.Key, x => Emit(x.Value, mut));
                    stage = "executed";
                    var res = Cases(delMap, rows, true);
                    casesRun = res.count;
                    if (res.fail > 0) { detected = true; stage = "behavior_diff"; diff = res.samples.FirstOrDefault(); }
                } catch (Exception ex) {
                    detected = true;
                    stage = "runtime_exception";
                    diff = $"{ex.GetType().Name}: {ex.Message}";
                }
                cp &= detected;
                controls.Add(new { mutation = mut, detected, detection_stage = stage, cases_evaluated = casesRun, evidence = diff });
                Console.WriteLine($"Mutant {mut}: detected={detected}, stage={stage}, evidence={diff}");
            }

            bool pass = positive.fail == 0 && cp;
            var report = new {
                candidate_sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),
                positive_cases = positive.count,
                positive_failures = positive.fail,
                negative_controls = controls,
                pass
            };
            File.WriteAllText(args[2], JsonSerializer.Serialize(report, new JsonSerializerOptions { WriteIndented = true }));
            return pass ? 0 : 1;
        } catch (Exception ex) {
            Console.Error.WriteLine(ex);
            return 2;
        }
    }
}
