# Native60 External Dependencies & Stable Release Locations

| Component | Type | Path / Location | Bytes | SHA-256 |
| :--- | :--- | :--- | :--- | :--- |
| Mono.Cecil | Managed Assembly | /workspaces/GodsPVZ-native24-codespace/.validation/native58-2026-10-03/built/Audit/Mono.Cecil.dll | 361,472 | 3b8398e04b407481ecbb29a8a6df2f42cf076df3087093375cb4bbf255ffef8c |
| Full UnityEngine.CoreModule | Reference Resolver | /workspaces/GodsPVZ-iOS/Tools/Stage9Native4Recovery/resolver/UnityEngine.CoreModule.dll | 1,532,928 | 83192116b34abac2bb1797ec0e3943362be33b028b1eefd2e561d5fdc1c3312f |
| Native GameAssembly | PE64 Binary | /workspaces/GodsPVZ-native19/.validation/native22/pcnative/GameAssembly.dll | 23,347,200 | 485ca0c1eb485294a2b9777556708f515d911b32d2011116c49749ba7c653bc0 |
| Method Exporter (PatcherNative19) | Tool Binary | /workspaces/GodsPVZ-native19/.validation/native22/bin/PatcherNative19.dll | 68,096 | b6f888f4ad699e15918739958ee853d9943ba87796440263f3cebb3874c76b91 |
| MemberAccess Validator | Tool Binary | /workspaces/GodsPVZ-native24-codespace/.validation/native55-2026-10-02/member-access-bin/MemberAccess.dll | 34,304 | 454378f14980a3733074092b3f11467a216447c20c027e80d467ea78345155f8 |
| Frozen verify_types.py | Static Verifier | /workspaces/GodsPVZ-native24-codespace/scripts/takeover/native40/verify_types.py | 38,728 | 5175b68ae0cb9366a493499b566a7430dc1d8986d81cf17be91e0640974dd47a |
| Native59 Replay DLL | Regression Fixture | /workspaces/GodsPVZ-native24-codespace/scripts/takeover/native59/RuntimeFixture/RuntimeFixture.csproj | N/A | Compiled in scratch |
