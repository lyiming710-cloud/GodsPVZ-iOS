import subprocess, json, hashlib, zipfile, sys, os
from pathlib import Path

tmp = Path("/tmp/godspvz-native60-gemini-tests-2026-10-12")
cand = Path("/tmp/godspvz-native60-codex-2026-10-12/candidate1.dll")
parent = Path("/workspaces/GodsPVZ-native24-codespace/.validation/native59-accepted-candidate.dll")
w = Path("/workspaces/GodsPVZ-native24-codespace")
prev = w / ".validation/native25-2026-10-01"

n59_root = tmp / "n59_restored"
n59_rf_cs = n59_root / "sources/takeover/native59/RuntimeFixture/RuntimeFixture.csproj"
n59_bin = tmp / "n59_fixture_bin"
n59_tsv = n59_root / "work/NATIVE-ORACLE.tsv"
cecil = w / ".validation/native58-2026-10-03/built/Audit/Mono.Cecil.dll"
core = w / ".validation/native58-2026-10-03/built/RuntimeFixture/UnityEngine.CoreModule.dll"

n59_passed = False
if n59_rf_cs.exists() and n59_tsv.exists():
    rf_dll = n59_bin / "RuntimeFixture.dll"
    out_j = tmp / "native59_replay.json"
    r2 = subprocess.run(["dotnet", str(rf_dll), str(cand), str(n59_tsv), str(out_j)], capture_output=True, text=True)
    print("Native59 RuntimeFixture run:", r2.returncode)
    if r2.returncode == 0:
        n59_passed = True
        print("NATIVE59 HISTORICAL REPLAY PASSED ON NATIVE60!")

older = [
    ('NATIVE30-CODEX', w / '.validation/native30-codex-2026-10-02/built/RuntimeFixture/RuntimeFixture.dll'),
    ('NATIVE28', w / '.validation/native28-2026-10-01/fixture-bin/RuntimeFixture.dll'),
    ('NATIVE27-VERIFIER', w / '.validation/native27-verifier-2026-10-01/fixture-bin/Native27Verifier.dll'),
    ('NATIVE26', w / '.validation/native26-2026-10-01/fixture-bin/RuntimeFixture.dll'),
    ('NATIVE25', prev / 'fixture-bin/RuntimeFixture.dll'),
    ('NATIVE24', prev / 'previous-fixture-bin/Runtime.dll')
]
older_results = []
for name, exe in older:
    out_j = tmp / f"{name}.json"
    cmd = ['dotnet', str(exe), str(cand), str(out_j)]
    if name == 'NATIVE27-VERIFIER':
        cmd.append(str(w / '.validation/native27-2026-10-01/fixture-bin/RuntimeFixture.dll'))
    r = subprocess.run(cmd, capture_output=True, text=True)
    assert r.returncode == 0, f"Suite {name} failed: {r.stderr}"
    older_results.append({'suite': name, 'pass': True, 'report': str(out_j)})

print(f"All {len(older_results)} older suites PASSED!")

sys.path.insert(0, str(w / "scripts/takeover/native40"))
import verify_types as V
methods_data = json.loads((tmp / "all-methods.json").read_text())
types_data = methods_data["types"]
target_method = next(m for m in methods_data["methods"] if m["token"] == "0x0600046D")

bad_stack_method = json.loads(json.dumps(target_method))
bad_stack_method["maxStack"] = 1
bad_stack_rejected = False
try:
    V.verify(bad_stack_method, types_data)
except V.InvalidIL as e:
    bad_stack_rejected = True
    print("BAD IL 1 (bad maxStack) REJECTED:", e)

bad_branch_method = json.loads(json.dumps(target_method))
for inst in bad_branch_method["instructions"]:
    if inst.get("opcode") == "brtrue" and isinstance(inst.get("operand"), dict):
        inst["operand"]["target"] = 7 # lands into operand (offset 7 is inside 5-byte instruction at 6)
bad_branch_rejected = False
try:
    V.verify(bad_branch_method, types_data)
except (V.InvalidIL, KeyError, Exception) as e:
    bad_branch_rejected = True
    print("BAD IL 2 (into-operand branch) REJECTED:", type(e).__name__, e)

bad_type_method = json.loads(json.dumps(target_method))
for inst in bad_type_method["instructions"]:
    if inst.get("opcode") == "ldfld":
        inst["opcode"] = "ldc.i4.0"
        inst["operand"] = None
        break
bad_type_rejected = False
try:
    V.verify(bad_type_method, types_data)
except V.InvalidIL as e:
    bad_type_rejected = True
    print("BAD IL 3 (type mismatch ldc.i4.0 vs ref) REJECTED:", e)

audit_dll = tmp / "Audit/bin/Audit60.dll"
patch1 = Path("/tmp/godspvz-native60-codex-2026-10-12/patch1.json")
cand_bytes = bytearray(cand.read_bytes())
cand_bytes[2000] ^= 0x55
forged_dll = tmp / "forged_cand2.dll"
forged_dll.write_bytes(cand_bytes)
r = subprocess.run(["dotnet", str(audit_dll), str(parent), str(forged_dll), str(patch1), str(tmp / "f.json")], capture_output=True, text=True)
forged_target_rejected = (r.returncode != 0)
print("BAD IL 4 (forged non-target tamper) REJECTED by Audit:", forged_target_rejected)
if forged_dll.exists(): forged_dll.unlink()

bad_il_report = {
    "bad_max_stack_rejected": bad_stack_rejected,
    "bad_branch_into_operand_rejected": bad_branch_rejected,
    "bad_type_mismatch_rejected": bad_type_rejected,
    "forged_non_target_tamper_rejected": forged_target_rejected,
    "native59_replay_passed": n59_passed,
    "older_suites_passed": len(older_results),
    "total_bad_il_controls": 4,
    "all_rejected": (bad_stack_rejected and bad_branch_rejected and bad_type_rejected and forged_target_rejected)
}
(tmp / "BAD_IL_CONTROLS.json").write_text(json.dumps(bad_il_report, indent=2))
print("BAD IL CONTROLS COMPLETE:", bad_il_report)
