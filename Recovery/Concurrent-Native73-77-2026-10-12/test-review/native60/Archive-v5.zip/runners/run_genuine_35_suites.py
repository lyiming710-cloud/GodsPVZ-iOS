import subprocess, json, hashlib, os, sys
from pathlib import Path

tmp = Path("/tmp/godspvz-native60-gemini-tests-2026-10-12")
cand = Path("/tmp/godspvz-native60-codex-2026-10-12/candidate1.dll")
w = Path("/workspaces/GodsPVZ-native24-codespace")
prev = w / ".validation/native25-2026-10-01"

cand_bytes = cand.read_bytes()
cand_h = hashlib.sha256(cand_bytes).hexdigest()

suites_dir = tmp / "historical_35_suites"
suites_dir.mkdir(parents=True, exist_ok=True)

suite_records = []

for i in range(31, 59):
    label = f"native{i}"
    date = "-2026-10-03" if i in [55, 56, 57, 58] else "-2026-10-02"
    if i == 55: label = "native55a"
    folder = w / f".validation/{label}{date}"
    dll = folder / "built/RuntimeFixture/RuntimeFixture.dll"
    tsv = folder / "NATIVE-ORACLE.tsv"
    out_j = suites_dir / f"{label}.json"

    rec = {"name": label, "suite_type": "standard_batch"}
    if dll.exists() and tsv.exists():
        r = subprocess.run(["dotnet", str(dll), str(cand), str(tsv), str(out_j)], capture_output=True, text=True)
        rec["exit_code"] = r.returncode
        if out_j.exists():
            try:
                j = json.loads(out_j.read_text())
                rec["input_candidate_hash"] = j.get("candidate_sha256")
                rec["positive_failures"] = j.get("positive_failures", 0)
                rec["positive_cases"] = j.get("positive_cases", 0)
                rec["pass"] = (r.returncode == 0 and rec["positive_failures"] == 0 and rec["input_candidate_hash"] == cand_h)
            except Exception as e:
                rec["pass"] = False
                rec["error"] = str(e)
        else:
            rec["pass"] = False
            rec["error"] = "no output json"
    else:
        rec["pass"] = False
        rec["missing"] = True
    suite_records.append(rec)
    print(f"Suite {label}: pass={rec.get('pass')}, failures={rec.get('positive_failures')}, exit={rec.get('exit_code')}")

n59_label = "native59"
n59_dll = tmp / "n59_fixture_bin/RuntimeFixture.dll"
n59_tsv = tmp / "n59_restored/work/NATIVE-ORACLE.tsv"
n59_out = suites_dir / "native59.json"
n59_rec = {"name": n59_label, "suite_type": "native59_restored"}
if n59_dll.exists() and n59_tsv.exists():
    r = subprocess.run(["dotnet", str(n59_dll), str(cand), str(n59_tsv), str(n59_out)], capture_output=True, text=True)
    n59_rec["exit_code"] = r.returncode
    if n59_out.exists():
        j = json.loads(n59_out.read_text())
        n59_rec["input_candidate_hash"] = j.get("candidate_sha256")
        n59_rec["positive_failures"] = j.get("positive_failures", 0)
        n59_rec["positive_cases"] = j.get("positive_cases", 0)
        n59_rec["pass"] = (r.returncode == 0 and n59_rec["positive_failures"] == 0 and n59_rec["input_candidate_hash"] == cand_h)
    else:
        n59_rec["pass"] = False
else:
    n59_rec["pass"] = False
    n59_rec["missing"] = True
suite_records.append(n59_rec)
print(f"Suite {n59_label}: pass={n59_rec.get('pass')}, failures={n59_rec.get('positive_failures')}, exit={n59_rec.get('exit_code')}")

older = [
    ('NATIVE30-CODEX', w / '.validation/native30-codex-2026-10-02/built/RuntimeFixture/RuntimeFixture.dll'),
    ('NATIVE28', w / '.validation/native28-2026-10-01/fixture-bin/RuntimeFixture.dll'),
    ('NATIVE27-VERIFIER', w / '.validation/native27-verifier-2026-10-01/fixture-bin/Native27Verifier.dll'),
    ('NATIVE26', w / '.validation/native26-2026-10-01/fixture-bin/RuntimeFixture.dll'),
    ('NATIVE25', prev / 'fixture-bin/RuntimeFixture.dll'),
    ('NATIVE24', prev / 'previous-fixture-bin/Runtime.dll')
]
for name, exe in older:
    out_j = suites_dir / f"{name}.json"
    cmd = ['dotnet', str(exe), str(cand), str(out_j)]
    if name == 'NATIVE27-VERIFIER':
        cmd.append(str(w / '.validation/native27-2026-10-01/fixture-bin/RuntimeFixture.dll'))
    rec = {"name": name, "suite_type": "legacy_checkpoint"}
    if exe.exists():
        r = subprocess.run(cmd, capture_output=True, text=True)
        rec["exit_code"] = r.returncode
        if out_j.exists():
            j = json.loads(out_j.read_text())
            rec["input_candidate_hash"] = j.get("candidate_sha256")
            rec["pass"] = (r.returncode == 0 and (rec["input_candidate_hash"] == cand_h or "candidate_sha256" not in j))
        else:
            rec["pass"] = False
    else:
        rec["pass"] = False
        rec["missing"] = True
    suite_records.append(rec)
    print(f"Suite {name}: pass={rec.get('pass')}, exit={rec.get('exit_code')}")

rep = {
    "target_candidate_sha256": cand_h,
    "total_suites_evaluated": len(suite_records),
    "total_suites_passed": sum(1 for s in suite_records if s.get("pass")),
    "all_passed": all(s.get("pass") for s in suite_records),
    "suites": suite_records
}
(tmp / "HISTORICAL_35_REGRESSIONS_REPORT.json").write_text(json.dumps(rep, indent=2))
print("SAVED FULL 35 SUITES REPORT: passed", rep["total_suites_passed"], "/", rep["total_suites_evaluated"])
