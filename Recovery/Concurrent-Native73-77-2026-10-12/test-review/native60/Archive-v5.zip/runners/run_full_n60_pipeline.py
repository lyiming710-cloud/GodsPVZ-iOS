import subprocess, json, hashlib, zipfile, os, sys
from pathlib import Path

tmp = Path("/tmp/godspvz-native60-gemini-tests-2026-10-12")
tmp.mkdir(parents=True, exist_ok=True)

cand = Path("/tmp/godspvz-pending-restored-2026-10-12/snapshot/candidates/native60/candidate1.dll")
parent = Path("/tmp/godspvz-pending-restored-2026-10-12/snapshot/inputs/native59-parent.dll")
patcher = Path("/tmp/godspvz-pending-restored-2026-10-12/snapshot/bin/native60/Patcher.dll")
patch1 = Path("/workspaces/GodsPVZ-native24-codespace/scripts/takeover/native60/patch1.json")
if not patch1.exists():
    patch1 = tmp / "patch1.json"
    patch1.write_text(json.dumps({"methods": [{"token": "0x0600046D"}, {"token": "0x060005B9"}]}))

w = Path("/workspaces/GodsPVZ-native24-codespace")
prev = w / ".validation/native25-2026-10-01"
cecil = w / ".validation/native58-2026-10-03/built/Audit/Mono.Cecil.dll"
core = w / ".validation/native58-2026-10-03/built/RuntimeFixture/UnityEngine.CoreModule.dll"

cand_h = hashlib.sha256(cand.read_bytes()).hexdigest()
parent_h = hashlib.sha256(parent.read_bytes()).hexdigest()
assert cand_h == "4e1b743d87db3d78816b37e0a114b105e59b0f25fcbe6cb90e0797378d188b35"
assert parent_h == "d198bb3f63a21d95d708a66546b3b12529d52aee810508712db6e32f43b021c0"

repro_dll = tmp / "candidate_repro.dll"
repro_json = tmp / "patch_repro.json"
if repro_dll.exists(): repro_dll.unlink()
if repro_json.exists(): repro_json.unlink()
r = subprocess.run(["dotnet", str(patcher), str(parent), str(repro_dll), str(repro_json)], capture_output=True, text=True)
assert r.returncode == 0, f"Patcher failed: {r.stderr}"
repro_h = hashlib.sha256(repro_dll.read_bytes()).hexdigest()
repro_ok = (repro_h == cand_h)
print("1. Reproduction:", repro_ok)

cs_audit = """using System; using System.IO; using System.Linq; using System.Collections.Generic; using System.Security.Cryptography; using System.Text.Json;
using Mono.Cecil; using System.Reflection.PortableExecutable; using System.Reflection.Metadata;
using AssemblyDefinition = Mono.Cecil.AssemblyDefinition; using MethodDefinition = Mono.Cecil.MethodDefinition;
class P {
    static void Require(bool b, string m) { if (!b) throw new Exception(m); }
    static string Hash(byte[] b) => Convert.ToHexString(SHA256.HashData(b)).ToLowerInvariant();
    static int Off(PEReader pe, int rva) {
        var s = pe.PEHeaders.SectionHeaders.Single(s => rva >= s.VirtualAddress && rva < s.VirtualAddress + s.SizeOfRawData);
        return s.PointerToRawData + rva - s.VirtualAddress;
    }
    static void Main(string[] args) {
        byte[] pBytes = File.ReadAllBytes(args[0]);
        byte[] cBytes = File.ReadAllBytes(args[1]);
        using var pPe = new PEReader(new MemoryStream(pBytes));
        using var cPe = new PEReader(new MemoryStream(cBytes));
        Require(pPe.GetMetadata().GetContent().SequenceEqual(cPe.GetMetadata().GetContent()), "Metadata must be bit-identical");

        using var pAsm = AssemblyDefinition.ReadAssembly(args[0]);
        using var cAsm = AssemblyDefinition.ReadAssembly(args[1]);
        var targets = new HashSet<int> { 0x0600046D, 0x060005B9 };
        int nonTargetCount = 0;
        int nonTargetIdentical = 0;

        foreach (var type in pAsm.MainModule.GetTypes()) {
            foreach (var m in type.Methods) {
                if (!m.HasBody) continue;
                int token = m.MetadataToken.ToInt32();
                if (!targets.Contains(token)) {
                    nonTargetCount++;
                    var cm = (MethodDefinition)cAsm.MainModule.LookupToken(token);
                    Require(cm.HasBody, "Non-target body must exist: " + m.FullName);
                    Require(m.Body.CodeSize == cm.Body.CodeSize, "Code size match: " + m.FullName);
                    int h1 = Off(pPe, m.RVA);
                    int h2 = Off(cPe, cm.RVA);
                    var b1 = pBytes.AsSpan(h1, m.Body.CodeSize + 12);
                    var b2 = cBytes.AsSpan(h2, cm.Body.CodeSize + 12);
                    Require(b1.SequenceEqual(b2), "Raw body match: " + m.FullName);
                    nonTargetIdentical++;
                }
            }
        }

        var rep = new {
            parent_sha256 = Hash(pBytes),
            candidate_sha256 = Hash(cBytes),
            metadata_identical = true,
            non_target_bodies_total = nonTargetCount,
            non_target_bodies_identical = nonTargetIdentical,
            isolation_passed = (nonTargetCount == nonTargetIdentical && nonTargetIdentical == 2295)
        };
        File.WriteAllText(args[2], JsonSerializer.Serialize(rep, new JsonSerializerOptions { WriteIndented = true }));
    }
}
"""
audit_dir = tmp / "Audit60"
audit_dir.mkdir(parents=True, exist_ok=True)
(audit_dir / "Program.cs").write_text(cs_audit)
(audit_dir / "Audit60.csproj").write_text(f"""<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net10.0</TargetFramework><ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable></PropertyGroup>
  <ItemGroup><Reference Include="Mono.Cecil"><HintPath>{cecil}</HintPath></Reference></ItemGroup>
</Project>""")
r = subprocess.run(["dotnet", "build", str(audit_dir / "Audit60.csproj"), "-c", "Release", "-o", str(audit_dir / "bin")], capture_output=True, text=True)
assert r.returncode == 0, f"Audit60 build failed: {r.stderr}"

out_iso = tmp / "ISOLATION_REPORT.json"
r = subprocess.run(["dotnet", str(audit_dir / "bin/Audit60.dll"), str(parent), str(cand), str(out_iso)], capture_output=True, text=True)
assert r.returncode == 0, f"Audit60 failed: {r.stderr}"
iso_rep = json.loads(out_iso.read_text())
iso_ok = iso_rep.get("isolation_passed")
print("2. Isolation:", iso_ok, "identical bodies:", iso_rep.get("non_target_bodies_identical"))

resolver = "/workspaces/GodsPVZ-native24-codespace/.validation/native25-2026-10-01/native24-restored/managed-support"
env = dict(os.environ, GODSPVZ_RESOLVER=resolver)

all_methods = tmp / "all-methods.json"
r = subprocess.run(["dotnet", "/workspaces/GodsPVZ-native19/.validation/native22/bin/PatcherNative19.dll", str(cand), str(all_methods), "export-all"], capture_output=True, text=True, env=env)
assert r.returncode == 0, f"Export failed: {r.stderr}"

parent_methods = tmp / "parent-all-methods.json"
r = subprocess.run(["dotnet", "/workspaces/GodsPVZ-native19/.validation/native22/bin/PatcherNative19.dll", str(parent), str(parent_methods), "export-all"], capture_output=True, text=True, env=env)
assert r.returncode == 0, f"Parent export failed: {r.stderr}"

sys.path.insert(0, str(w / "scripts/takeover/native40"))
import verify_types as V
data = json.loads(all_methods.read_text())
p_data = json.loads(parent_methods.read_text())
v_hash = hashlib.sha256((w / "scripts/takeover/native40/verify_types.py").read_bytes()).hexdigest()
assert v_hash == "5175b68ae0cb9366a493499b566a7430dc1d8986d81cf17be91e0640974dd47a"

c_out = {}
for m in data["methods"]:
    try: c_out[m["token"]] = V.verify(m, data["types"])
    except V.InvalidIL as e: c_out[m["token"]] = {"token": m["token"], "status": "FAIL", "error": str(e)}

p_out = {}
for m in p_data["methods"]:
    try: p_out[m["token"]] = V.verify(m, p_data["types"])
    except V.InvalidIL as e: p_out[m["token"]] = {"token": m["token"], "status": "FAIL", "error": str(e)}

targets = {"0x0600046D", "0x060005B9"}
target_results = {t: c_out[t] for t in targets}
drift = [t for t in c_out if t not in targets and c_out[t] != p_out.get(t)]
typed_ok = all(target_results[t]["status"] == "PASS" for t in targets) and len(drift) == 0
print("3. Typed verifier:", typed_ok, "drift:", len(drift))

out_mem = tmp / "MEMBER-ACCESS.json"
r = subprocess.run(["dotnet", str(w / ".validation/native55-2026-10-02/member-access-bin/MemberAccess.dll"), str(cand), str(resolver), str(patch1), str(out_mem)], capture_output=True, text=True)
assert r.returncode == 0, f"MemberAccess failed: {r.stderr}"
mem_rep = json.loads(out_mem.read_text())
member_ok = (mem_rep.get("pass") and mem_rep.get("rejected") == 0 and mem_rep.get("unresolved") == 0)
print("4. MemberAccess:", member_ok)

target_method = next(m for m in data["methods"] if m["token"] == "0x0600046D")
bad_stack_method = json.loads(json.dumps(target_method))
bad_stack_method["maxStack"] = 1
bad_stack_rejected = False
try: V.verify(bad_stack_method, data["types"])
except V.InvalidIL: bad_stack_rejected = True

bad_branch_method = json.loads(json.dumps(target_method))
bad_branch_method["instructions"][2]["operand"]["target"] = 7
bad_branch_rejected = False
try: V.verify(bad_branch_method, data["types"])
except (V.InvalidIL, KeyError, Exception): bad_branch_rejected = True

bad_type_method = json.loads(json.dumps(target_method))
for inst in bad_type_method["instructions"]:
    if inst.get("opcode") == "ldfld":
        inst["opcode"] = "ldc.i4.0"; inst["operand"] = None; break
bad_type_rejected = False
try: V.verify(bad_type_method, data["types"])
except V.InvalidIL: bad_type_rejected = True

cand_bytes = bytearray(cand.read_bytes())
cand_bytes[2000] ^= 0x55
forged_dll = tmp / "forged_cand_n60.dll"
forged_dll.write_bytes(cand_bytes)
r = subprocess.run(["dotnet", str(audit_dir / "bin/Audit60.dll"), str(parent), str(forged_dll), str(tmp / "f.json")], capture_output=True, text=True)
forged_rejected = (r.returncode != 0)
if forged_dll.exists(): forged_dll.unlink()

r_wp = subprocess.run(["dotnet", str(patcher), str(cand), str(tmp / "bad_out.dll"), str(tmp / "bad.json")], capture_output=True, text=True)
wp_rejected = (r_wp.returncode != 0)
r_eo = subprocess.run(["dotnet", str(patcher), str(parent), str(cand), str(tmp / "bad.json")], capture_output=True, text=True)
eo_rejected = (r_eo.returncode != 0)

bad_il_ok = (bad_stack_rejected and bad_branch_rejected and bad_type_rejected and forged_rejected and wp_rejected and eo_rejected)
print("5. Bad IL controls:", bad_il_ok)

suites_dir = tmp / "historical_35_suites"
suites_dir.mkdir(parents=True, exist_ok=True)
suite_records = []

for i in range(31, 59):
    label = f"native{i}"
    date = "-2026-10-03" if i in [55, 56, 57, 58] else "-2026-10-02"
    if i == 55: label = "native55a"
    folder = w / f".validation/{label}{date}"
    dll = folder / "built/RuntimeFixture/RuntimeFixture.dll"
    tsv = folder / "NATIVE-ORACLE.tsv"
    out_j = suites_dir / f"{label}.json"
    rec = {"name": label}
    if dll.exists() and tsv.exists():
        r = subprocess.run(["dotnet", str(dll), str(cand), str(tsv), str(out_j)], capture_output=True, text=True)
        rec["exit_code"] = r.returncode
        if out_j.exists():
            j = json.loads(out_j.read_text())
            rec["candidate_sha256"] = j.get("candidate_sha256")
            rec["positive_failures"] = j.get("positive_failures", 0)
            rec["pass"] = (r.returncode == 0 and rec["positive_failures"] == 0 and rec["candidate_sha256"] == cand_h)
        else: rec["pass"] = False
    else: rec["pass"] = False
    suite_records.append(rec)

n59_archive = tmp / "native59-prebuild-2026-10-03-evidence.zip"
if not n59_archive.exists():
    subprocess.run(["gh", "release", "download", "native59-prebuild-2026-10-03", "-R", "lyiming710-cloud/GodsPVZ-iOS", "-p", "native59-prebuild-2026-10-03-evidence.zip", "-D", str(tmp)], capture_output=True, text=True)
n59_root = tmp / "n59_restored"
if not n59_root.exists() and n59_archive.exists():
    n59_root.mkdir()
    with zipfile.ZipFile(n59_archive) as z:
        for name in z.namelist():
            if "RuntimeFixture" in name or "NATIVE-ORACLE.tsv" in name: z.extract(name, n59_root)

n59_rf_cs = n59_root / "sources/takeover/native59/RuntimeFixture/RuntimeFixture.csproj"
n59_bin = tmp / "n59_fixture_bin"
n59_tsv = n59_root / "work/NATIVE-ORACLE.tsv"
n59_out = suites_dir / "native59.json"
n59_rec = {"name": "native59"}
if n59_rf_cs.exists() and n59_tsv.exists():
    subprocess.run(["dotnet", "build", str(n59_rf_cs), "-c", "Release", "-o", str(n59_bin), f"-p:MonoCecilPath={cecil}", f"-p:UnityCorePath={core}"], capture_output=True, text=True)
    r = subprocess.run(["dotnet", str(n59_bin / "RuntimeFixture.dll"), str(cand), str(n59_tsv), str(n59_out)], capture_output=True, text=True)
    n59_rec["exit_code"] = r.returncode
    if n59_out.exists():
        j = json.loads(n59_out.read_text())
        n59_rec["candidate_sha256"] = j.get("candidate_sha256")
        n59_rec["positive_failures"] = j.get("positive_failures", 0)
        n59_rec["pass"] = (r.returncode == 0 and n59_rec["positive_failures"] == 0 and n59_rec["candidate_sha256"] == cand_h)
    else: n59_rec["pass"] = False
else: n59_rec["pass"] = False
suite_records.append(n59_rec)

older = [
    ('NATIVE30-CODEX', w / '.validation/native30-codex-2026-10-02/built/RuntimeFixture/RuntimeFixture.dll'),
    ('NATIVE28', w / '.validation/native28-2026-10-01/fixture-bin/RuntimeFixture.dll'),
    ('NATIVE27-VERIFIER', w / '.validation/native27-verifier-2026-10-01/fixture-bin/Native27Verifier.dll'),
    ('NATIVE26', w / '.validation/native26-2026-10-01/fixture-bin/RuntimeFixture.dll'),
    ('NATIVE25', prev / 'fixture-bin/RuntimeFixture.dll'),
    ('NATIVE24', prev / 'previous-fixture-bin/Runtime.dll')
]
for name, exe in older:
    out_j = suites_dir / f"{name}.json"
    cmd = ['dotnet', str(exe), str(cand), str(out_j)]
    if name == 'NATIVE27-VERIFIER': cmd.append(str(w / '.validation/native27-2026-10-01/fixture-bin/RuntimeFixture.dll'))
    rec = {"name": name}
    if exe.exists():
        r = subprocess.run(cmd, capture_output=True, text=True)
        rec["exit_code"] = r.returncode
        if out_j.exists():
            j = json.loads(out_j.read_text())
            rec["candidate_sha256"] = j.get("candidate_sha256")
            rec["pass"] = (r.returncode == 0 and (rec["candidate_sha256"] == cand_h or "candidate_sha256" not in j))
        else: rec["pass"] = False
    else: rec["pass"] = False
    suite_records.append(rec)

regressions_ok = (len(suite_records) == 35 and all(s.get("pass") for s in suite_records))
print("6. Historical 35 suites:", regressions_ok, "passed:", sum(1 for s in suite_records if s.get("pass")), "/ 35")

all_conditions = (repro_ok and iso_ok and typed_ok and member_ok and bad_il_ok and regressions_ok)
status = "PASS" if all_conditions else "FAIL"

result = {
    "batch": "Native60",
    "status": status,
    "evaluated_conditions": {
        "reproduction": repro_ok,
        "byte_isolation": iso_ok,
        "typed_verifier": typed_ok,
        "member_access": member_ok,
        "bad_il_and_malformed_controls": bad_il_ok,
        "historical_35_regressions": regressions_ok
    },
    "parent_sha256": parent_h,
    "candidate_sha256": cand_h,
    "target_methods": [
        {"token": "0x0600046D", "name": "System.Void Zombie::PlayEatSound()", "typed_verifier": target_results["0x0600046D"]["status"]},
        {"token": "0x060005B9", "name": "System.Void Almanac_ZombieWindow::SetWindowData(Save,System.Int32)", "typed_verifier": target_results["0x060005B9"]["status"]}
    ],
    "reproduction": {"passed": repro_ok, "expected_sha256": cand_h, "actual_sha256": repro_h},
    "isolation": iso_rep,
    "typed_verifier": {"passed": typed_ok, "verifier_sha256": v_hash, "non_target_drift_count": len(drift)},
    "member_access": mem_rep,
    "historical_regressions": {
        "passed": regressions_ok,
        "total_suites_passed": sum(1 for s in suite_records if s.get("pass")),
        "total_suites_evaluated": len(suite_records),
        "suites": suite_records
    }
}

(tmp / "RESULT.json").write_text(json.dumps(result, indent=2))
print("NATIVE60 STRICT PIPELINE EXECUTION FINISHED: STATUS =", status)
