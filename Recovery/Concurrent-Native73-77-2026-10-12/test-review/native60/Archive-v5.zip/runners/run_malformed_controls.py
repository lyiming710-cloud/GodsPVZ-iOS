import subprocess, json, hashlib, sys
from pathlib import Path

tmp = Path("/tmp/godspvz-native60-gemini-tests-2026-10-12")
cand = Path("/tmp/godspvz-native60-codex-2026-10-12/candidate1.dll")
parent = Path("/workspaces/GodsPVZ-native24-codespace/.validation/native59-accepted-candidate.dll")
patcher = Path("/tmp/godspvz-native60-codex-2026-10-12/patcher-bin/Patcher.dll")
audit_dll = tmp / "Audit/bin/Audit60.dll"
patch1 = Path("/tmp/godspvz-native60-codex-2026-10-12/patch1.json")

r1 = subprocess.run(["dotnet", str(patcher), str(cand), str(tmp / "bad_out.dll"), str(tmp / "bad_patch.json")], capture_output=True, text=True)
assert r1.returncode != 0, "Patcher accepted wrong parent!"
print("MALFORMED TEST 1: Patcher rejected wrong parent (exit code", r1.returncode, ")")

r2 = subprocess.run(["dotnet", str(patcher), str(parent), str(cand), str(tmp / "bad_patch.json")], capture_output=True, text=True)
assert r2.returncode != 0, "Patcher accepted overwriting existing output!"
print("MALFORMED TEST 2: Patcher rejected existing output (exit code", r2.returncode, ")")

cand_bytes = bytearray(cand.read_bytes())
cand_bytes[1000] ^= 0xFF
forged_cand = tmp / "forged_candidate.dll"
forged_cand.write_bytes(cand_bytes)

r3 = subprocess.run(["dotnet", str(audit_dll), str(parent), str(forged_cand), str(patch1), str(tmp / "forged_rep.json")], capture_output=True, text=True)
assert r3.returncode != 0, "Audit accepted forged candidate!"
print("FORGED SCOPE TEST 1: Audit rejected tampered non-target byte (exit code", r3.returncode, ")")

trunc_cand = tmp / "truncated_candidate.dll"
trunc_cand.write_bytes(cand_bytes[:len(cand_bytes)//2])
r4 = subprocess.run(["dotnet", str(audit_dll), str(parent), str(trunc_cand), str(patch1), str(tmp / "trunc_rep.json")], capture_output=True, text=True)
assert r4.returncode != 0, "Audit accepted truncated candidate!"
print("MALFORMED TEST 3: Audit rejected truncated DLL (exit code", r4.returncode, ")")

if forged_cand.exists(): forged_cand.unlink()
if trunc_cand.exists(): trunc_cand.unlink()

controls_rep = {
    "wrong_parent_rejected": True,
    "existing_output_rejected": True,
    "forged_non_target_tamper_rejected": True,
    "truncated_dll_rejected": True,
    "all_negative_controls_passed": True
}
(tmp / "MALFORMED_AND_FORGED_CONTROLS.json").write_text(json.dumps(controls_rep, indent=2))
print("MALFORMED AND FORGED CONTROLS PASSED!")
