from pathlib import Path
import collections,hashlib,json,re
Q=Path(__file__).resolve().parent.parent/'startup-r5'
stack=json.loads((Q/'FROZEN-STACK-ALL-2297.json').read_bytes())
access=json.loads((Q/'REMAINING-MEMBER-CLASSIFICATION.json').read_bytes())
rows=[]
for result in stack['results']:
    if result['status']=='PASS':continue
    error=result.get('error','');reason=re.sub(r'^.*IL_[0-9A-F]+: ','',error)
    if 'unsupported' in reason.lower():category='CHECKER_EXPLICITLY_UNSUPPORTED'
    elif 'receiver FTRuntime.Internal.Swf' in reason and '<T>' in reason:category='GENERIC_SELF_RECEIVER_REQUIRES_INDEPENDENT_CHECK'
    elif 'System.Collections.IEnumerator' in reason:category='INTERFACE_ASSIGNABILITY_REQUIRES_INDEPENDENT_CHECK'
    elif 'invalid comparison F, I4' in reason or 'invalid comparison I4, F' in reason:category='FLOAT_INTEGER_COMPARISON_REQUIRES_NATIVE_EVIDENCE'
    elif 'invalid comparison I, I4' in reason:category='NATIVE_INT_INTEGER_COMPARISON_REQUIRES_NATIVE_EVIDENCE'
    elif 'I8 is not assignable to System.Int32' in reason:category='INT64_INT32_ARGUMENT_OR_LOCAL_REQUIRES_NATIVE_EVIDENCE'
    else:category='OTHER_TYPE_OR_CHECKER_LIMIT_REQUIRES_REVIEW'
    rows.append(dict(token=result['token'],method=result.get('method'),category=category,error=error))
counter=collections.Counter(r['category'] for r in rows)
access_tokens={r['token'] for r in access['methods']};stack_tokens={r['token'] for r in rows}
report=dict(scope='FIRST_FAILURE_CLASSIFICATION_PER_METHOD_NOT_COMPLETE_ERROR_OR_GAME_BUG_COUNT',candidate_sha256=stack['candidate_sha256'],
            frozen_pass=2136,frozen_fail_or_unsupported=len(rows),categories=dict(counter),member_access_affected_methods=len(access_tokens),
            methods_with_either_unclosed_gate=len(access_tokens|stack_tokens),overlap=len(access_tokens&stack_tokens),
            qualification=False,notes=['Frozen verifier is unchanged; no PASS/FAIL/UNSUPPORTED result has been waived.',
                                       'Generic self and interface cases may be checker limitations or real metadata damage; inspect independently.',
                                       'Only the first type-flow failure per method is reported; successful checks do not prove behavior.'],methods=rows)
(Q/'REMAINING-TYPE-CLASSIFICATION.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
print(json.dumps({k:v for k,v in report.items() if k!='methods'},indent=2))
