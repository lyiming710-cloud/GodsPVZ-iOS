"""Recover the four lost BoardManager reads in Administrator's config loader.

Append one private local signature for this method alone. The native code caches
the singleton once, applies Unity truthiness to that same pointer, and reads its
public challengeType/level fields. Never cast zero to Int32 to hide lost data.
Construction only; runtime/native equivalence remains a separate pending gate.
"""
from pathlib import Path
import hashlib,importlib.util,json,struct,sys
W=Path(__file__).resolve().parent.parent;ROOT=W.parents[1]
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
spec=importlib.util.spec_from_file_location('metadata_writer',W/'startup-r2/construct.py')
writer=importlib.util.module_from_spec(spec);spec.loader.exec_module(writer)
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(ok,message):
    if not ok:raise ValueError(message)
def compressed(n):
    if n<128:return bytes([n])
    if n<16384:return (0x8000|n).to_bytes(2,'big')
    need(n<0x20000000,'Compressed integer limit');return (0xc0000000|n).to_bytes(4,'big')
def read_compressed(data,at):
    first=data[at]
    if first<128:return first,at+1
    if first<192:return ((first&63)<<8)|data[at+1],at+2
    return ((first&31)<<24)|int.from_bytes(data[at+1:at+4],'big'),at+4

def construct(source,output,report):
    source=Path(source).resolve();output=Path(output).resolve();report=Path(report).resolve()
    need(len({source,output,report})==3 and not output.exists() and not report.exists(),'Fresh distinct outputs')
    before=source.read_bytes();need(sha(before)=='530550053cfae3d8be6ea886f87ee77b74e5c1cc8c2b96517b5ac18d3cbb4ec9','Exact R4 pending parent')
    pe=dnfile.dnPE(data=before);method=pe.net.mdtables.MethodDef.rows[8]
    at=pe.get_offset_from_rva(method.Rva);header_size=(struct.unpack_from('<H',before,at)[0]>>12)*4
    need(header_size==12,'Exact fat header')
    local_token=struct.unpack_from('<I',before,at+8)[0]
    need(local_token==0x11000008,'Original method-local signature identity')
    signature=pe.net.mdtables.StandAloneSig.rows[7].Signature.value
    count,pos=read_compressed(signature,1);need(signature[0]==7 and count==31,'31 original locals')
    locals_=[]
    for _ in range(count):
        start=pos;code=signature[pos];pos+=1
        if code in (0x11,0x12):_,pos=read_compressed(signature,pos)
        else:need(code in (2,8,14,24),'No unparsed local type forms')
        locals_.append(signature[start:pos])
    need(pos==len(signature) and locals_[17]==bytes.fromhex('1221'),'Exact original V17 UnityEngine.Object TypeRef')
    old_class=pe.net.mdtables.TypeRef.rows[7]
    need(str(old_class.TypeName)=='Object' and str(old_class.TypeNamespace)=='UnityEngine','Original V17 owner')
    manager=pe.net.mdtables.TypeDef.rows[58]
    need(str(manager.TypeName)=='BoardManager','Existing BoardManager TypeDef RID59')
    locals_[17]=b'\x12'+compressed(59<<2)
    new_signature=signature[:2]+b''.join(locals_)
    fields=pe.net.mdtables.Field.rows
    need(str(fields[0x1ae-1].Name)=='challengeType' and fields[0x1ae-1].Flags.fdPublic,'Public native-backed manager challengeType')
    need(str(fields[0x1af-1].Name)=='level' and fields[0x1af-1].Flags.fdPublic,'Public native-backed manager level')
    native_fields=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_text('utf-8-sig'))
    field_evidence=[]
    for name,token,offset in [('challengeType',0x040001ae,0x20),('level',0x040001af,0x24)]:
        matches=[r for r in native_fields if r['type']=='BoardManager' and r['name']==name and int(r['token'],16)==token]
        need(len(matches)==1 and matches[0]['offset']==offset,'Original native field offset and token')
        field_evidence.append(matches[0])
    after=bytearray(before);changes=[]
    def patch(offset,expected,replacement,why):
        need(len(expected)==len(replacement) and before[at+header_size+offset:at+header_size+offset+len(expected)]==expected,'Fixed-width exact original site')
        after[at+header_size+offset:at+header_size+offset+len(expected)]=replacement
        changes.append(dict(offset=offset,file_offset=at+header_size+offset,before=expected.hex(),after=replacement.hex(),reason=why))
    for offset,field in [(371,0x040001ae),(379,0x040001af),(415,0x040001ae),(443,0x040001af)]:
        old=before[at+header_size+offset:at+header_size+offset+8]
        need(old[0]==0x72 and old[5:]==bytes.fromhex('2616d3'),'Exact unsupported native load placeholder')
        patch(offset,old,b'\x11\x11\x7b'+struct.pack('<I',field)+b'\0','Load captured typed BoardManager field; retain byte slot with one NOP')
    patch(654,b'\x7e'+struct.pack('<I',0x040001ad),b'\x28'+struct.pack('<I',0x06000169),'Original public singleton getter; cache once in V17')
    patch(149,b'\x7e'+struct.pack('<I',0x040001ad),b'\x11\x11\0\0\0','Use the same captured pointer for Unity truthiness as original RBX, without a second singleton read')
    cli=pe.get_offset_from_rva(pe.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress)
    meta_rva,meta_size=struct.unpack_from('<II',before,cli+8);meta_at=pe.get_offset_from_rva(meta_rva)
    root,streams=writer.metadata_root(before[meta_at:meta_at+meta_size]);values={n:b for n,_,b in streams}
    th,rows,tail,counts=writer.tables_decode(values['#~'])
    blob=values['#Blob'];index=len(blob)
    values['#Blob']=blob+compressed(len(new_signature))+new_signature
    rows[17].append([index]);new_token=0x11000000|len(rows[17])
    struct.pack_into('<I',after,at+8,new_token)
    values['#~']=writer.tables_encode(th,rows,tail,counts)
    metadata=bytearray(root)
    for name,h,_ in streams:
        start=writer.align(len(metadata),4);metadata.extend(b'\0'*(start-len(metadata)))
        struct.pack_into('<II',metadata,h,start,len(values[name]));metadata.extend(values[name])
    last=pe.sections[-1];need(last.PointerToRawData+last.SizeOfRawData==len(before) and last.Name.rstrip(b'\0')==b'.n29meta','Bounded append-only metadata section')
    start=writer.align(len(after),4);after.extend(b'\0'*(start-len(after)));after.extend(metadata)
    end=len(after);raw_size=writer.align(end-last.PointerToRawData,pe.OPTIONAL_HEADER.FileAlignment)
    after.extend(b'\0'*(last.PointerToRawData+raw_size-len(after)))
    sh=last.get_file_offset();opt=pe.OPTIONAL_HEADER.get_file_offset()
    updates={sh+8:end-last.PointerToRawData,sh+16:raw_size,opt+8:pe.OPTIONAL_HEADER.SizeOfInitializedData+raw_size-last.SizeOfRawData,opt+56:writer.align(last.VirtualAddress+end-last.PointerToRawData,pe.OPTIONAL_HEADER.SectionAlignment),opt+64:0,cli+8:last.VirtualAddress+start-last.PointerToRawData,cli+12:len(metadata)}
    for pos,value in updates.items():struct.pack_into('<I',after,pos,value)
    allowed={p+i for p in updates for i in range(4)}|set(range(at+8,at+12))|{c['file_offset']+i for c in changes for i in range(len(bytes.fromhex(c['before'])))}
    need(all(x==y or i in allowed for i,(x,y) in enumerate(zip(before,after))),'Whole original-prefix mutation boundary')
    output.parent.mkdir(exist_ok=True,parents=True);output.write_bytes(after)
    result=dict(status='CONSTRUCTED_NATIVE_DATAFLOW_RECOVERY_RUNTIME_PENDING',method_token='0x06000009',parent_sha256=sha(before),candidate_sha256=sha(after),candidate_bytes=len(after),site_changes=changes,
                old_local_signature=f'0x{local_token:08X}',new_local_signature=f'0x{new_token:08X}',old_local_signature_hex=signature.hex(),new_local_signature_hex=new_signature.hex(),
                local_change='V17 UnityEngine.Object -> BoardManager; all other 30 local type encodings identical',original_native_fields=field_evidence,
                code_size_maxstack_branches_eh_unchanged=True,all_other_method_bodies_unchanged=True,new_memberrefs=0,new_standalone_sigs=1,native_normal_cfg_entry='0x1802fd6e0',native_normal_cfg_instructions=199,
                exception_unwind_not_modeled=True,runtime_equivalence='PENDING',unity_or_ipa='NOT_RUN')
    report.write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in result.items() if k not in ('site_changes','original_native_fields')}))

if __name__=='__main__':
    need(len(sys.argv)==4,'parent-R4 fresh-candidate fresh-report');construct(*sys.argv[1:])
