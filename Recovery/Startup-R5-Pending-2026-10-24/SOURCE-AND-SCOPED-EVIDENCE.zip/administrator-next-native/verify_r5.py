from pathlib import Path
import hashlib,importlib.util,json,struct
W=Path(__file__).resolve().parent.parent;Q=W/'startup-r5'
spec=importlib.util.spec_from_file_location('independent_reader',W/'remaining-native/verify_r4.py')
reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
need=reader.need;sha=reader.sha;body=reader.body
parent=(W/'startup-r4/candidate3.dll').read_bytes();need(sha(parent)=='530550053cfae3d8be6ea886f87ee77b74e5c1cc8c2b96517b5ac18d3cbb4ec9','Pinned R4 pending parent')
pp,pm,pd,pr,pt=reader.read(parent)
ob,method_at,head=body(parent,pd,9);expected=bytearray(ob)
old_sig=pd.net.mdtables.StandAloneSig.rows[7].Signature.value
need(old_sig.hex()=='071f1281a402123812380e0e12814c12381280c412814c128218020e1280e01280c412821812381221123812380812380e02020e1280e01812081818','Exact original 31-local signature')
need(old_sig.count(bytes.fromhex('1221'))==1,'Unique original V17 UnityEngine.Object encoding')
new_sig=old_sig.replace(bytes.fromhex('1221'),bytes.fromhex('1280ec'))
new_token=0x11000000|len(pr[17])+1
struct.pack_into('<I',expected,8,new_token)
ranges=set(range(method_at+8,method_at+12))
for offset,field in [(371,0x040001ae),(379,0x040001af),(415,0x040001ae),(443,0x040001af)]:
    need(ob[head+offset]==0x72 and ob[head+offset+5:head+offset+8]==bytes.fromhex('2616d3'),'Exact lost dataflow span')
    expected[head+offset:head+offset+8]=bytes.fromhex('11117b')+struct.pack('<I',field)+b'\0'
    ranges.update(range(method_at+head+offset,method_at+head+offset+8))
for offset,after in [(654,bytes.fromhex('2869010006')),(149,bytes.fromhex('1111000000'))]:
    need(ob[head+offset:head+offset+5]==bytes.fromhex('7ead010004'),'Original singleton field read')
    expected[head+offset:head+offset+5]=after;ranges.update(range(method_at+head+offset,method_at+head+offset+5))
headers=[pp['sections'][-1]['header_offset']+8,pp['sections'][-1]['header_offset']+16,pp['opt_off']+8,pp['opt_off']+56,pp['opt_off']+64,pp['cli_off']+8,pp['cli_off']+12]
ranges.update(p+i for p in headers for i in range(4))

def audit(data):
    cp,cm,cd,cr,ct=reader.read(data)
    need(ct==pt,'Unchanged table tail')
    need(cm['streams'].keys()==pm['streams'].keys() and cm['heap_sizes']==pm['heap_sizes'] and cm['valid_mask']==pm['valid_mask'] and cm['sorted_mask']==pm['sorted_mask'],'Unchanged encoding/stream flags')
    for t,rows in pr.items():
        need(cr[t][:len(rows)]==rows,'Every existing table row unchanged '+str(t))
        need(len(cr[t])-len(rows)==int(t==17),'Only one StandAloneSig append')
    need(cr[17][-1]==[len(pm['streams']['#Blob']['bytes'])],'New standalone signature blob offset')
    for name in ['#Strings','#GUID','#US']:
        need(cm['streams'][name]['bytes']==pm['streams'][name]['bytes'],'Unchanged heap '+name)
    need(len(new_sig)<128 and cm['streams']['#Blob']['bytes']==pm['streams']['#Blob']['bytes']+bytes([len(new_sig)])+new_sig,'Exactly one appended local signature; all 30 other encodings retained')
    for rid,(old,new) in enumerate(zip(pd.net.mdtables.MethodDef.rows,cd.net.mdtables.MethodDef.rows),1):
        need(old.Rva==new.Rva,'No MethodDef RVA changes')
        old_body,_,_=body(parent,pd,rid);new_body,_,_=body(data,cd,rid)
        need(new_body==(bytes(expected) if rid==9 else old_body),'Exact body/header boundary '+hex(0x06000000|rid))
    need(cp['meta_off']==len(parent),'Append-only metadata relocation')
    need(all(a==b or i in ranges for i,(a,b) in enumerate(zip(parent,data))),'Whole original-prefix mutation boundary')
    need(data[cp['meta_off']+cp['meta_size']:]==b'\0'*(len(data)-cp['meta_off']-cp['meta_size']),'Zero append padding')
    return dict(scope='ADMINISTRATOR_DATAFLOW_BYTE_AND_METADATA_ISOLATION_ONLY',candidate_sha256=sha(data),direct_body_targets=1,untouched_methods_against_r4=2316,
                inherited_five_r4_bodies_unchanged=True,changed_local='V17 only',code_size_maxstack_branches_eh_unchanged=True,visibility_unchanged=True,runtime_qualified=False)

if __name__=='__main__':
    candidate=(Q/'candidate1.dll').read_bytes();result=audit(candidate)
    need(candidate==(Q/'candidate2.dll').read_bytes(),'Deterministic repeated construction')
    controls=[]
    def reject(name,change):
        data=bytearray(candidate);change(data)
        try:audit(bytes(data))
        except Exception as error:controls.append(dict(name=name,rejected=True,reason=str(error)));return
        raise AssertionError('False accept: '+name)
    _,_,cd,_,_=reader.read(candidate)
    reject('old-Object-local-signature-restored',lambda b:struct.pack_into('<I',b,method_at+8,0x11000008))
    reject('wrong-manager-field-same-Int32-stack-kind',lambda b:struct.pack_into('<I',b,method_at+head+371+3,0x040001af))
    reject('duplicate-singleton-read-restored',lambda b:b.__setitem__(slice(method_at+head+149,method_at+head+154),bytes.fromhex('2869010006')))
    reject('early-return-instead-of-config-load',lambda b:b.__setitem__(method_at+head,0x2a))
    source_row=cd.net.mdtables.StandAloneSig.rows[7].struct.get_field_absolute_offset('Signature_BlobIndex')
    reject('shared-original-local-signature-row-mutated',lambda b:b.__setitem__(source_row,b[source_row]^1))
    game_body,game_at,game_head=body(candidate,cd,0x526)
    reject('unrelated-GameStart-body',lambda b:b.__setitem__(game_at+game_head,b[game_at+game_head]^1))
    result['negative_controls']=controls
    (Q/'ISOLATION.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result,indent=2))
