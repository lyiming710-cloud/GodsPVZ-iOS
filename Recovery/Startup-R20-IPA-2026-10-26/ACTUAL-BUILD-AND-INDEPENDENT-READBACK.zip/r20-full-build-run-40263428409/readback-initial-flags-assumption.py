"""Independent byte readback of the actual successful export, Apple logs and IPA."""
from pathlib import Path
import collections,hashlib,json,plistlib,re,struct,subprocess,zipfile,zlib
from archive_support import sha,js
W=Path(__file__).resolve().parent;Q=W/'r20-full-build-run-40263428409';E=Q/'editor';A=Q/'apple';C=A/'actual-export-compiler';B=Q/'shaders';P=Q/'ipa/GodsPVZ_1.0.2_startup_r20_unsigned.ipa';F=Q/'forensics'
CANDIDATE='d887b370c95c2966dc40d80648d85c286bb42d85004c32d095f64f004e095b37';HEAD='c22560ed9e025f04d4e58bc38ba0f23df8b9feb4'
binding=json.loads((E/'startup-r20-export-binding.json').read_bytes());assert binding['candidate_sha256']==CANDIDATE and binding['workflow_head']==HEAD
export=json.loads((E/'actual-unity-build-report.json').read_bytes());assert export['build_report_found'] and export['result']=='Succeeded' and export['total_errors']==0 and not export['errors_ignored']
assert not [m for s in export['steps'] for m in s['messages'] if m['type'] in ['Error','Exception','Assert']]
assert (E/'ios-export-exit.txt').read_text().strip()==(E/'license-return-exit.txt').read_text().strip()=='0'
assert (E/'test-dll-after-reimport.sha256').read_text().strip()==CANDIDATE
assetcase=json.loads((E/'asset-case-import-audit.json').read_bytes());assert assetcase['assets']==12 and assetcase['failed']==0 and all(r['pass'] and r['observed_path']==r['expected_path'] and r['observed_name']==r['expected_name'] for r in assetcase['rows'])
transition=json.loads((E/'asset-case-transition.json').read_bytes());assert transition['case_collision_groups_after']==0 and transition['renamed_files']==24 and transition['all_asset_and_meta_byte_hashes_preserved']
startup=json.loads((E/'startup-play-probe.json').read_bytes());assert startup['pass'] and startup['frames']>=3 and startup['active_scene']=='MainMenu' and not startup['errors']
asset=json.loads((E/'startup-asset-audit.json').read_bytes());assert asset['pass'] and asset['missing_components']==0 and asset['resolved_plugin_scripts']==148 and asset['original_serialization_markers']==130
receipt=json.loads((F/'ARCHIVE.json').read_bytes());archive=F/receipt['file'];assert archive.stat().st_size==receipt['bytes'] and sha(archive.read_bytes())==receipt['sha256']
source_bytes={}
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None;files=json.loads(z.read('MANIFEST.json'));assert set(z.namelist())=={'MANIFEST.json'}|{r['file'] for r in files}
    for row in files:
        data=z.read(row['file']);assert len(data)==row['bytes'] and sha(data)==row['sha256'];source_bytes[row['file']]=data
    for row in binding['files']:
        data=source_bytes['xcode/'+row['path']];assert len(data)==row['bytes'] and sha(data)==row['sha256']
    raw_build=json.loads(source_bytes['evidence/actual-unity-build-report.json']);assert raw_build['result']=='Succeeded' and raw_build['total_errors']==0
generated={Path(r['path']).name:r for r in binding['files'] if r['path'].endswith(('.cpp','.c'))};assert len(generated)==324
rows=json.loads((C/'ALL-RESULTS.json').read_bytes());inventory=json.loads((C/'SOURCE-INVENTORY.json').read_bytes());assert len(rows)==len(inventory)==324 and {r['file'] for r in rows}=={r['file'] for r in inventory}==set(generated)
for r in rows:
    expected=generated[r['file']];assert r['bytes']==expected['bytes'] and r['sha256']==expected['sha256'] and r['exit_code']==r['error_count']==0 and not r['unparsed_errors']
    log=(C/'logs'/(r['file']+'.log')).read_text('utf-8',errors='replace');assert not re.search(r'\b(?:fatal )?error:',log)
    assert len(re.findall(r'\bwarning:',log))==r['warning_count'],r['file']
for r in inventory:assert r['bytes']==generated[r['file']]['bytes'] and r['sha256']==generated[r['file']]['sha256']
controls=json.loads((C/'COMPILER-CONTROLS.json').read_bytes())+json.loads((C/'C-COMPILER-CONTROLS.json').read_bytes());assert len(controls)==6 and all(r['expectation_met'] for r in controls)
for r in controls:
    data=(C/r['file']).read_bytes();assert len(data)==r['bytes'] and sha(data)==r['sha256'];log=(C/'logs'/(r['file']+'.log')).read_text('utf-8',errors='replace')
    assert len(re.findall(r'\b(?:fatal )?error:',log))==r['error_count']
assert sum(r['exit_code']!=0 for r in controls)==4 and sum(r['exit_code']==0 for r in controls)==2
for name in ['CPP-FLAGS.json','C-FLAGS.json']:
    flags=json.loads((C/name).read_bytes());assert any('/Xcode_16.4.app/' in s for s in flags) and '-fsyntax-only' in flags and any('iPhoneOS18.5.sdk' in s for s in flags) and any('arm64-apple-ios' in s for s in flags)
assert '** BUILD SUCCEEDED **' in (A/'build/xcodebuild.log').read_text('utf-8',errors='replace')

def mach(data,role):
    magic,cpu,subtype,kind,ncmds,cmdbytes,flags,reserved=struct.unpack_from('<8I',data);assert magic==0xfeedfacf and cpu==0x100000c and kind==role
    at=32;end=32+cmdbytes;assert end<=len(data);platforms=[];signature=False;encrypted=False
    for _ in range(ncmds):
        cmd,size=struct.unpack_from('<II',data,at);assert size>=8 and at+size<=end and size%8==0
        if cmd==0x1d:
            off,length=struct.unpack_from('<II',data,at+8);signature|=length>0;assert off+length<=len(data)
        if cmd==0x32:
            platform,minimum,sdk,ntools=struct.unpack_from('<4I',data,at+8);assert platform==2;platforms.append(dict(platform=platform,minimum_hex=hex(minimum),sdk_hex=hex(sdk)))
        if cmd==0x25:platforms.append(dict(legacy_ios=True))
        if cmd==0x2c:encrypted|=struct.unpack_from('<I',data,at+16)[0]!=0
        if cmd==0x19:
            off,length=struct.unpack_from('<QQ',data,at+40);assert off+length<=len(data)
        at+=size
    assert at==end and platforms and not signature and not encrypted
    return dict(bytes=len(data),sha256=sha(data),cpu_hex=hex(cpu),filetype=kind,platforms=platforms,nonempty_code_signature=signature,encrypted=encrypted)

v=json.loads((A/'ipa-output/IPA-VALIDATION.json').read_bytes());assert v['candidate_sha256']==CANDIDATE and v['workflow_head']==v['packaging_workflow_head']==HEAD
assert P.stat().st_size==v['ipa_bytes']==192091143 and sha(P.read_bytes())==v['ipa_sha256']=='f7334b1b330cdc7dc2cbeeb0c9851c8c233bc0fc923c69e6de36f38aeda56c75'
with zipfile.ZipFile(P) as z:
    assert z.testzip() is None;names=z.namelist();assert len(names)==len(set(names))==v['zip_entries'] and not any(n.startswith('/') or '..' in n.split('/') for n in names)
    root='Payload/GodsPVZ.app/';info=plistlib.loads(z.read(root+'Info.plist'));assert info['CFBundleIdentifier']=='com.tipsGodsStudio.godsPVZ' and info.get('CFBundleSupportedPlatforms')==['iPhoneOS']
    assert '/' not in info['CFBundleExecutable'];main=mach(z.read(root+info['CFBundleExecutable']),2);framework=mach(z.read(root+'Frameworks/UnityFramework.framework/UnityFramework'),6)
    assert main['sha256']==v['main_binary']['sha256'] and framework['sha256']==v['unity_framework']['sha256']
    assert not any('_CodeSignature' in n.split('/') or n.endswith('.mobileprovision') for n in names)
    metadata=[n for n in names if n.endswith('/Managed/Metadata/global-metadata.dat')];assert len(metadata)==1
    data=z.read(metadata[0]);assert data==source_bytes['xcode/Data/Managed/Metadata/global-metadata.dat'] and len(data)==v['metadata_bytes'] and sha(data)==v['metadata_sha256']

shader=json.loads((E/'custom-shader-audit.json').read_bytes());assert shader['pass'] and shader['negative_compile_control'] and not shader['errors'] and len(shader['compilations'])==76 and len(shader['pixels'])==20
assert collections.Counter(r['platform'] for r in shader['compilations'])=={'Metal':38,'OpenGLCore':38};raw_shader=[]
for row in shader['compilations']:
    prefix='game' if row['shader']=='Unlit/GameUnitShader' else 'brightness';suffix='_'.join(k[-1] for k in row['keywords'].split());name=f"shader-{prefix}-p{row['pass']}-{row['platform']}-{row['stage']}-{suffix}.bin";data=(B/name).read_bytes();assert row['success'] and len(data)==row['bytes'] and sha(data)==row['sha256'];raw_shader.append(name)
def pixel(path):
    b=path.read_bytes();assert b[:8]==b'\x89PNG\r\n\x1a\n';at=8;payload=b'';header=None
    while at<len(b):
        length=struct.unpack_from('>I',b,at)[0];tag=b[at+4:at+8];data=b[at+8:at+8+length];assert zlib.crc32(tag+data)&0xffffffff==struct.unpack_from('>I',b,at+8+length)[0];at+=12+length
        if tag==b'IHDR':header=struct.unpack('>IIBBBBB',data)
        if tag==b'IDAT':payload+=data
    assert header and header[:2]==(32,32) and header[2] in [8,16] and header[3]==6 and header[4:]==(0,0,0)
    width,height,depth,*_=header;bpp=4*(depth//8);stride=width*bpp;raw=zlib.decompress(payload);assert len(raw)==height*(stride+1);prior=bytearray(stride);rows=[]
    for y in range(height):
        start=y*(stride+1);kind=raw[start];row=bytearray(raw[start+1:start+1+stride]);assert kind in range(5)
        for x in range(stride):
            a=row[x-bpp] if x>=bpp else 0;b=prior[x];c=prior[x-bpp] if x>=bpp else 0
            if kind==1:add=a
            elif kind==2:add=b
            elif kind==3:add=(a+b)//2
            elif kind==4:
                p=a+b-c;da,db,dc=abs(p-a),abs(p-b),abs(p-c);add=a if da<=db and da<=dc else b if db<=dc else c
            else:add=0
            row[x]=(row[x]+add)&255
        rows.append(row);prior=row
    cell=rows[16][16*bpp:17*bpp];values=list(cell) if depth==8 else list(struct.unpack('>4H',cell));return [v/(255 if depth==8 else 65535) for v in values],depth
pngrows=[]
for row in shader['pixels']:
    path=B/('render-'+row['name']+'.png');rgba,depth=pixel(path);actual=[row['actual'][k] for k in ['r','g','b','a']];error=max(abs(x-y) for x,y in zip(rgba,actual));assert row['pass'] and row['max_error']<.003 and error<=1/255+.0001,(path.name,error,rgba,actual);raw_shader.append(path.name);pngrows.append(dict(file=path.name,depth=depth,center_rgba=rgba,reported_rgba=actual,quantization_error=error))
assert set(raw_shader)=={p.name for p in B.iterdir() if p.is_file()} and len(raw_shader)==96
run=json.loads(subprocess.check_output(['C:/Program Files/GitHub CLI/gh.exe','run','view','40263428409','--repo','lyiming710-cloud/GodsPVZ-iOS','--json','databaseId,status,conclusion,headSha,url,jobs']));assert run['headSha']==HEAD and run['conclusion']=='success' and all(j['conclusion'] in ['success','skipped'] for j in run['jobs']);assert next(j for j in run['jobs'] if j['name']=='build_ipa')['conclusion']=='success';js(Q/'RUN.json',run)
result=dict(scope='INDEPENDENT_DOWNLOADED_ACTUAL_IPA_EXPORT_SOURCE_COMPILER_AND_EDITOR_READBACK_NOT_DEVICE_ACCEPTANCE',run_id=40263428409,source_commit=HEAD,candidate_sha256=CANDIDATE,ipa_sha256=v['ipa_sha256'],ipa_bytes=P.stat().st_size,zip_entries=v['zip_entries'],bundle_id=info['CFBundleIdentifier'],main_binary=main,unity_framework=framework,metadata_sha256=v['metadata_sha256'],metadata_bytes=v['metadata_bytes'],packaged_metadata_exactly_equals_actual_export=True,actual_export_files_rehashed=len(files),binding_files_rehashed=len(binding['files']),actual_apple_sources_and_raw_logs=324,actual_apple_cpp=258,actual_apple_c=66,actual_apple_errors=0,actual_apple_warnings=sum(r['warning_count'] for r in rows),compiler_controls=6,compiler_positive_controls=2,compiler_negative_controls=4,actual_xcode_build_succeeded=True,unity_errors=0,unity_warnings=export['total_warnings'],mainmenu_frames=startup['frames'],mainmenu_errors=0,relocated_assets_guid_name_pass=12,raw_shader_and_png_files_rehashed=96,raw_png_centers_independently_decoded=pngrows,personal_seat_return_exit=0,device_execution=False,physical_audio=False,full_game_semantic_acceptance=False,r19_finite_methods=81,r19_pending_methods_including_known_failures=19)
js(Q/'INDEPENDENT-IPA-READBACK.json',result);print(json.dumps({k:v for k,v in result.items() if k!='raw_png_centers_independently_decoded'}))
