#!/usr/bin/env python3
"""
Static Isolation & Type Flow Gates for GodsPVZ Native Takeover (Bulk162 / Native110).

Ported directly from step1_and_3_bulk152.py & frozen_independent_isolation_bulk152.py:
  - 162 Body targets (152 inherited + 10 new).
  - 2155 Non-targets (100% byte-for-byte identical with parent Native93).
  - 70 MemberRefs (1100 -> 1170, verified against METADATA-ADDITIONS.json).
  - 107 StandAloneSigs (1765 -> 1872, verified against METADATA-ADDITIONS.json).
  - 30 Finally regions verified (clause boundaries, fat headers, endfinally 0xDC).
  - Full execution of all 14 negative controls on the isolation auditor.
  - True body comparison across RVAs (header bytes, IL, EH, padding) + InitLocals negative control.
  - CilExporter -> verify_types -> MemberAccess -> EagerVerifier static execution pipeline:
    * branch/EH boundary check across 162 methods
    * frozen 7 unsupported retained, all 10 new targets PASS
    * stack underflow negative control on verify_types
    * extended ldtoken/ldftn type checker passes all targets
    * MemberAccess check on 162 targets (0 rejected, 0 unresolved)
    * MemberAccess negative control (rejecting private PrepareUI.instance)
    * EagerVerifier resolution (1170 rows, 70 appended resolved, 0 unresolved).
"""

import copy
import hashlib
import json
import os
import pathlib
import shutil
import struct
import subprocess
import sys
import time

FINALLY_ALLOWLIST = {
    0x06000013: (106, 57, 163, 8),
    0x06000041: (135, 69, 204, 8),
    0x0600004C: (146, 34, 180, 8),
    0x0600014C: (47, 47, 94, 8),
    0x06000184: (44, 49, 93, 8),
    0x060001A2: (18, 35, 53, 8),
    0x060001F0: (14, 81, 95, 20),
    0x060001FF: (12, 60, 72, 8),
    0x06000276: (12, 91, 103, 8),
    0x06000288: (18, 93, 111, 8),
    0x06000324: (44, 102, 146, 8),
    0x06000330: (28, 50, 78, 8),
    0x060003B8: (44, 112, 156, 8),
    0x06000487: (40, 157, 197, 8),
    0x06000549: (12, 41, 53, 8),
    0x06000562: (14, 65, 79, 8),
    0x06000573: (12, 56, 68, 8),
    0x0600058B: (60, 70, 130, 8),
    0x060005AC: (14, 65, 79, 8),
    0x060005B1: (19, 77, 96, 8),
    0x060005B2: (19, 66, 85, 8),
    0x060005B3: (19, 66, 85, 8),
    0x0600060E: (12, 41, 53, 8),
    0x0600060F: (28, 103, 131, 8),
    0x06000633: (129, 35, 164, 8),
    0x0600068C: (54, 97, 151, 8),
    0x06000698: (12, 54, 66, 8),
    0x060006EA: (12, 41, 53, 8),
    0x060006EB: (17, 123, 140, 8),
    0x0600058F: (107, 71, 178, 8),
}

EXPECTED_USER_STRINGS = [
    (0x70032F12, 208658, 31, "PeaShooter_Head", 0),
    (0x70032F32, 208690, 49, "Zombie_polevaulter__head", 0),
    (0x70032F64, 208740, 41, "LadderSaboteurs_head", 0),
]

HISTORICAL_UNSUPPORTED_TYPE_TOKENS = {
    "0x06000069", "0x0600006A", "0x0600006B", "0x0600008D", "0x060001FB", "0x060008BD", "0x060008BE"
}

def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def align(x: int, a: int) -> int:
    return ((x + a - 1) // a) * a

def parse_pe_and_cli(b: bytes):
    pe_off = struct.unpack_from("<I", b, 0x3C)[0]
    assert b[pe_off:pe_off+4] == b"PE\x00\x00"
    num_sec = struct.unpack_from("<H", b, pe_off + 6)[0]
    opt_size = struct.unpack_from("<H", b, pe_off + 20)[0]
    opt_off = pe_off + 24
    sec_off = opt_off + opt_size
    sections = []
    for i in range(num_sec):
        s = sec_off + i * 40
        name = b[s:s+8].rstrip(b"\x00").decode("ascii", errors="replace")
        vsize, va, raw_size, raw_ptr, _, _, _, _, chars = struct.unpack_from("<IIIIIIHHI", b, s + 8)
        sections.append({
            "index": i, "header_offset": s, "name": name,
            "virtual_size": vsize, "virtual_address": va,
            "size_of_raw_data": raw_size, "pointer_to_raw_data": raw_ptr,
            "characteristics": chars
        })
    cli_rva, cli_size = struct.unpack_from("<II", b, opt_off + 208)
    def rva_to_off(rva: int) -> int:
        for sec in sections:
            if sec["virtual_address"] <= rva < sec["virtual_address"] + sec["size_of_raw_data"]:
                return sec["pointer_to_raw_data"] + (rva - sec["virtual_address"])
        raise ValueError(f"Unmapped RVA {rva:#x}")
    cli_off = rva_to_off(cli_rva)
    meta_rva, meta_size = struct.unpack_from("<II", b, cli_off + 8)
    meta_off = rva_to_off(meta_rva)
    return {
        "pe_off": pe_off, "opt_off": opt_off, "sec_off": sec_off,
        "sections": sections, "cli_off": cli_off,
        "meta_rva": meta_rva, "meta_size": meta_size, "meta_off": meta_off,
        "rva_to_off": rva_to_off
    }

def parse_metadata_root(b: bytes, meta_off: int, meta_size: int):
    root = b[meta_off:meta_off + meta_size]
    sig = struct.unpack_from("<I", root, 0)[0]
    assert sig == 0x424A5342
    ver_len = struct.unpack_from("<I", root, 12)[0]
    pos = align(16 + ver_len, 4)
    flags, num_streams = struct.unpack_from("<HH", root, pos)
    pos += 4
    streams = {}
    stream_headers = []
    for _ in range(num_streams):
        s_off, s_size = struct.unpack_from("<II", root, pos)
        end_name = root.index(b"\x00", pos + 8)
        s_name = root[pos+8:end_name].decode("ascii")
        streams[s_name] = {
            "rel_offset": s_off,
            "abs_offset": meta_off + s_off,
            "size": s_size,
            "bytes": root[s_off:s_off + s_size]
        }
        stream_headers.append((s_name, s_off, s_size))
        pos = align(end_name + 1, 4)
    t_bytes = streams["#~"]["bytes"]
    heap_sizes = t_bytes[6]
    valid_mask = struct.unpack_from("<Q", t_bytes, 8)[0]
    sorted_mask = struct.unpack_from("<Q", t_bytes, 16)[0]
    row_counts = {}
    rc_pos = 24
    for tid in range(64):
        if (valid_mask >> tid) & 1:
            row_counts[tid] = struct.unpack_from("<I", t_bytes, rc_pos)[0]
            rc_pos += 4
    return {
        "root_bytes": root,
        "streams": streams,
        "stream_headers": stream_headers,
        "heap_sizes": heap_sizes,
        "valid_mask": valid_mask,
        "sorted_mask": sorted_mask,
        "row_counts": row_counts,
        "tables_data_start": rc_pos
    }

def parse_raw_method_body_span(image: bytes, file_offset: int):
    b0 = image[file_offset]
    flags = b0 & 3
    if flags == 2:
        code_size = b0 >> 2
        return (1 + code_size, 1, code_size, 0, 0, 0, 0, 0, [])
    if flags == 3:
        flags_and_size, max_stack, code_size, local_sig = struct.unpack_from("<HHII", image, file_offset)
        header_size = (flags_and_size >> 12) * 4
        more_sects = (flags_and_size & 0x08) != 0
        pos = file_offset + header_size + code_size
        eh_start, eh_len, eh_clauses = 0, 0, 0
        clauses_list = []
        if more_sects:
            pad_end = align(pos, 4)
            pos = pad_end
            eh_start = pos
            while True:
                skind = image[pos]
                is_fat = (skind & 0x40) != 0
                has_more = (skind & 0x80) != 0
                if (skind & 0x3F) != 1:
                    raise ValueError(f"Unexpected EH section kind {skind:#x}")
                if is_fat:
                    sect_len = image[pos+1] | (image[pos+2] << 8) | (image[pos+3] << 16)
                    n_cl = (sect_len - 4) // 24
                    eh_clauses += n_cl
                    for ci in range(n_cl):
                        c_flags, t_off, t_len, h_off, h_len, c_tok = struct.unpack_from("<IIIIII", image, pos + 4 + ci * 24)
                        clauses_list.append((skind, sect_len, c_flags, t_off, t_len, h_off, h_len, c_tok))
                else:
                    sect_len = image[pos+1]
                    n_cl = (sect_len - 4) // 12
                    eh_clauses += n_cl
                    for ci in range(n_cl):
                        c_flags, t_off, t_len, h_off, h_len, c_tok = struct.unpack_from("<HHBHBI", image, pos + 4 + ci * 12)
                        clauses_list.append((skind, sect_len, c_flags, t_off, t_len, h_off, h_len, c_tok))
                pos += sect_len
                if not has_more: break
                pos = align(pos, 4)
            eh_len = pos - eh_start
        return (pos - file_offset, header_size, code_size, max_stack, local_sig, eh_start, eh_len, eh_clauses, clauses_list)
    raise ValueError(f"Invalid method header flags {flags} at {file_offset:#x}")

def decode_user_string_entry(us_bytes: bytes, offset: int):
    if offset < 0 or offset >= len(us_bytes):
        raise ValueError(f"US offset {offset} out of bounds")
    b0 = us_bytes[offset]
    if (b0 & 0x80) == 0:
        comp_len = b0
        hdr_len = 1
    elif (b0 & 0xC0) == 0x80:
        comp_len = ((b0 & 0x3F) << 8) | us_bytes[offset + 1]
        hdr_len = 2
    else:
        raise ValueError(f"Unsupported US compressed length header {b0:#x}")
    if comp_len < 1 or (comp_len % 2) != 1 or offset + hdr_len + comp_len > len(us_bytes):
        raise ValueError(f"Invalid US entry length {comp_len} at {offset}")
    utf16_bytes = us_bytes[offset + hdr_len : offset + hdr_len + comp_len - 1]
    term_flag = us_bytes[offset + hdr_len + comp_len - 1]
    text = utf16_bytes.decode("utf-16le")
    next_offset = offset + hdr_len + comp_len
    return hdr_len, comp_len, text, term_flag, next_offset

def audit_isolation_bulk162(parent_bytes: bytes, cand_bytes: bytes, body_targets: set, target_to_batch: dict, expected_new_locals: dict, meta_add: dict):
    import dnfile
    try:
        pe_p = parse_pe_and_cli(parent_bytes)
        pe_c = parse_pe_and_cli(cand_bytes)
    except Exception as e:
        return False, f"PE/CLI parse error: {e}", {}

    last_sec_hdr = pe_p["sections"][-1]["header_offset"]
    allowed_fields = {
        "section_last_VirtualSize": range(last_sec_hdr + 8, last_sec_hdr + 12),
        "section_last_SizeOfRawData": range(last_sec_hdr + 16, last_sec_hdr + 20),
        "opt_SizeOfInitializedData": range(pe_p["opt_off"] + 8, pe_p["opt_off"] + 12),
        "opt_SizeOfImage": range(pe_p["opt_off"] + 56, pe_p["opt_off"] + 60),
        "opt_CheckSum": range(pe_p["opt_off"] + 64, pe_p["opt_off"] + 68),
        "cli_Metadata_RVA": range(pe_p["cli_off"] + 8, pe_p["cli_off"] + 12),
        "cli_Metadata_Size": range(pe_p["cli_off"] + 12, pe_p["cli_off"] + 16),
    }
    allowed_set = set()
    for r in allowed_fields.values():
        allowed_set.update(r)
    changed_prefix = [i for i in range(len(parent_bytes)) if parent_bytes[i] != cand_bytes[i]]
    unauth_prefix = [i for i in changed_prefix if i not in allowed_set]
    if unauth_prefix:
        return False, f"Unauthorized prefix byte changes: {unauth_prefix[:10]}", {}

    mp = parse_metadata_root(parent_bytes, pe_p["meta_off"], pe_p["meta_size"])
    mc = parse_metadata_root(cand_bytes, pe_c["meta_off"], pe_c["meta_size"])

    if mp["heap_sizes"] != mc["heap_sizes"] or mp["valid_mask"] != mc["valid_mask"] or mp["sorted_mask"] != mc["sorted_mask"]:
        return False, "Metadata header mask/heap_sizes changed", {}

    for tid, cnt_p in mp["row_counts"].items():
        cnt_c = mc["row_counts"][tid]
        if tid == 0x0A:
            if cnt_p != 1100 or cnt_c != 1170:
                return False, f"Unexpected MemberRef row count: {cnt_p} -> {cnt_c} (expected 1100 -> 1170)", {}
        elif tid == 0x11:
            if cnt_p != 1765 or cnt_c != 1872:
                return False, f"Unexpected StandAloneSig row count: {cnt_p} -> {cnt_c} (expected 1765 -> 1872)", {}
        elif tid == 0x1B:
            if cnt_p != 173 or cnt_c != 175:
                return False, f"Unexpected TypeSpec row count: {cnt_p} -> {cnt_c} (expected 173 -> 175)", {}
        elif tid == 0x2B:
            if cnt_p != 185 or cnt_c != 187:
                return False, f"Unexpected MethodSpec row count: {cnt_p} -> {cnt_c} (expected 185 -> 187)", {}
        else:
            if cnt_p != cnt_c:
                return False, f"Table {tid:#x} row count changed: {cnt_p} -> {cnt_c}", {}

    if mp["streams"]["#GUID"]["bytes"] != mc["streams"]["#GUID"]["bytes"]:
        return False, "Heap #GUID modified!", {}

    us_p = mp["streams"]["#US"]["bytes"]
    us_c = mc["streams"]["#US"]["bytes"]
    if len(us_p) != 208658 or len(us_c) != 208658 + 124 or us_c[:208658] != us_p:
        return False, f"#US prefix or length mismatch: {len(us_p)} -> {len(us_c)}", {}

    appended_user_strings = []
    cur_us_off = 208658
    for exp_tok, exp_off, exp_comp_len, exp_text, exp_flag in EXPECTED_USER_STRINGS:
        if cur_us_off != exp_off or exp_tok != (0x70000000 | exp_off):
            return False, f"#US token/offset misalignment at {cur_us_off}", {}
        try:
            hdr_len, comp_len, text, term_flag, next_off = decode_user_string_entry(us_c, cur_us_off)
        except Exception as e:
            return False, f"#US decode error at {cur_us_off}: {e}", {}
        if hdr_len != 1 or comp_len != exp_comp_len or text != exp_text or term_flag != exp_flag:
            return False, f"#US entry mismatch at {exp_tok:#x}", {}
        appended_user_strings.append({
            "token": f"0x{exp_tok:08X}", "offset": exp_off, "text": text
        })
        cur_us_off = next_off
    if cur_us_off != len(us_c):
        return False, f"#US trailing unconsumed bytes: {cur_us_off} != {len(us_c)}", {}

    str_p = mp["streams"]["#Strings"]["bytes"]
    str_c = mc["streams"]["#Strings"]["bytes"]
    if len(str_c) < len(str_p) or str_c[:len(str_p)] != str_p:
        return False, "#Strings prefix mismatch", {}

    blob_p = mp["streams"]["#Blob"]["bytes"]
    blob_c = mc["streams"]["#Blob"]["bytes"]
    if len(blob_c) < len(blob_p) or blob_c[:len(blob_p)] != blob_p:
        return False, "#Blob prefix mismatch", {}

    tp = mp["streams"]["#~"]["bytes"]
    tc = mc["streams"]["#~"]["bytes"]
    dn_p = dnfile.dnPE(data=parent_bytes)
    dn_c = dnfile.dnPE(data=cand_bytes)

    pos_p = mp["tables_data_start"]
    pos_c = mc["tables_data_start"]
    appended_memberrefs = []
    appended_standalonesigs = []
    table_checks = {}

    for tbl_p, tbl_c in zip(dn_p.net.mdtables.tables_list, dn_c.net.mdtables.tables_list):
        tid = tbl_p.number
        nrows_p = tbl_p.num_rows
        nrows_c = tbl_c.num_rows
        rsize = tbl_p.row_size
        tname = tbl_p.name
        unauth_rows = []
        allowed_mods = []
        for r in range(1, nrows_p + 1):
            roff_p = pos_p + (r - 1) * rsize
            roff_c = pos_c + (r - 1) * rsize
            rp = tp[roff_p:roff_p + rsize]
            rc = tc[roff_c:roff_c + rsize]
            if rp != rc:
                if tid == 0x06 and (0x06000000 | r) in body_targets and rp[4:] == rc[4:]:
                    old_rva = struct.unpack_from("<I", rp, 0)[0]
                    new_rva = struct.unpack_from("<I", rc, 0)[0]
                    allowed_mods.append({"token": f"0x{0x06000000|r:08X}", "old_rva": old_rva, "new_rva": new_rva})
                else:
                    unauth_rows.append(r)
        if unauth_rows:
            return False, f"Unauthorized row modification in table {tname}: rows {unauth_rows[:10]}", {}

        if tid == 0x0A:
            for idx, mdef in enumerate(meta_add["member_definitions"]):
                rid = 1101 + idx
                mr_row = dn_c.net.mdtables.MemberRef.rows[rid - 1]
                sig_hex = bytes(mr_row.Signature.value).hex()
                exp_name = mdef["new_name"] or mdef["template_name"]
                if str(mr_row.Name) != exp_name or sig_hex != mdef["signature"]:
                    return False, f"Appended MemberRef {mdef['token']:#x} name/sig mismatch", {}
                appended_memberrefs.append({"token": f"0x{mdef['token']:08X}", "rid": rid, "name": str(mr_row.Name), "sig": sig_hex})
        elif tid == 0x11:
            for idx, exp_blob_hex in enumerate(meta_add["local_blobs"]):
                rid = 1766 + idx
                sa_row = dn_c.net.mdtables.StandAloneSig.rows[rid - 1]
                actual_blob_hex = bytes(sa_row.Signature.value).hex()
                if actual_blob_hex != exp_blob_hex:
                    return False, f"Appended StandAloneSig {0x11000000|rid:#x} blob mismatch", {}
                appended_standalonesigs.append({"token": f"0x{0x11000000|rid:08X}", "rid": rid, "blob": actual_blob_hex})

        table_checks[tname] = {"rows_before": nrows_p, "rows_after": nrows_c, "row_size": rsize, "authorized_modifications": allowed_mods}
        pos_p += nrows_p * rsize
        pos_c += nrows_c * rsize

    mrows_p = dn_p.net.mdtables.MethodDef.rows
    mrows_c = dn_c.net.mdtables.MethodDef.rows
    non_target_checked = 0
    non_target_with_rva = 0
    non_target_zero_rva = 0
    body_target_details = []
    finally_counts = 0

    for idx in range(len(mrows_p)):
        rid = idx + 1
        tok = 0x06000000 | rid
        mp_row = mrows_p[idx]
        mc_row = mrows_c[idx]
        p_rva = mp_row.Rva
        c_rva = mc_row.Rva
        if tok in body_targets:
            off_p = pe_p["rva_to_off"](p_rva)
            off_c = pe_c["rva_to_off"](c_rva)
            if (off_c % 4) != 0:
                return False, f"Target {tok:#x} body offset not 4-byte aligned", {}
            sp = parse_raw_method_body_span(parent_bytes, off_p)
            sc = parse_raw_method_body_span(cand_bytes, off_c)
            old_slot_untouched = (parent_bytes[off_p:off_p + sp[0]] == cand_bytes[off_p:off_p + sp[0]])
            exp_local_sig = expected_new_locals[tok]
            if not old_slot_untouched or sc[4] != exp_local_sig:
                return False, f"Target {tok:#x} old slot corrupted or local sig {sc[4]:#x} != {exp_local_sig:#x}", {}
            flags_word = struct.unpack_from("<H", cand_bytes, off_c)[0]
            has_more_sects = (flags_word & 0x08) != 0
            if tok in FINALLY_ALLOWLIST:
                finally_counts += 1
                if not has_more_sects or sc[7] != 1 or len(sc[8]) != 1:
                    return False, f"Finally target {tok:#x} missing MoreSects or clause count != 1", {}
                skind, sect_len, c_flags, t_off, t_len, h_off, h_len, c_tok = sc[8][0]
                exp_t_off, exp_t_len, exp_h_off, exp_h_len = FINALLY_ALLOWLIST[tok]
                if skind != 0x41 or sect_len != 28 or c_flags != 2 or c_tok != 0:
                    return False, f"Finally target {tok:#x} invalid fat EH header/flags", {}
                if (t_off, t_len, h_off, h_len) != (exp_t_off, exp_t_len, exp_h_off, exp_h_len):
                    return False, f"Finally target {tok:#x} EH bounds mismatch", {}
                il_c = cand_bytes[off_c + sc[1]:off_c + sc[1] + sc[2]]
                if il_c[h_off + h_len - 1] != 0xDC:
                    return False, f"Finally target {tok:#x} handler does not end with endfinally (0xDC)", {}
            else:
                if has_more_sects or sc[7] != 0:
                    return False, f"Non-finally target {tok:#x} unexpectedly has EH section", {}
            body_target_details.append({
                "token": f"0x{tok:08X}", "batch": target_to_batch.get(tok, "UNKNOWN"), "name": str(mc_row.Name),
                "old_rva": p_rva, "new_rva": c_rva,
                "new_local_sig_tok": f"0x{sc[4]:08X}",
                "eh_clauses": sc[7]
            })
        else:
            non_target_checked += 1
            if p_rva == 0:
                if c_rva != 0: return False, f"Zero-RVA method {tok:#x} changed RVA", {}
                non_target_zero_rva += 1
            else:
                if p_rva != c_rva: return False, f"Non-target method {tok:#x} RVA changed", {}
                off_p = pe_p["rva_to_off"](p_rva)
                off_c = pe_c["rva_to_off"](c_rva)
                sp = parse_raw_method_body_span(parent_bytes, off_p)
                sc = parse_raw_method_body_span(cand_bytes, off_c)
                if sp != sc or parent_bytes[off_p:off_p + sp[0]] != cand_bytes[off_c:off_c + sc[0]]:
                    return False, f"Non-target method {tok:#x} body changed", {}
                non_target_with_rva += 1

    return True, "PASS", {
        "parent_sha256": sha256_bytes(parent_bytes),
        "candidate_sha256": sha256_bytes(cand_bytes),
        "parent_bytes": len(parent_bytes),
        "candidate_bytes": len(cand_bytes),
        "body_targets_count": len(body_target_details),
        "finally_targets_verified_count": finally_counts,
        "non_target_methods_checked_total": non_target_checked,
        "non_target_methods_with_rva_identical": non_target_with_rva,
        "non_target_methods_zero_rva_identical": non_target_zero_rva,
        "appended_memberref_count": len(appended_memberrefs),
        "appended_standalonesig_count": len(appended_standalonesigs),
        "table_checks": table_checks,
        "body_targets": body_target_details
    }

def run_14_negative_controls(parent_bytes: bytes, cand_bytes: bytes, body_targets: set, target_to_batch: dict, expected_new_locals: dict, meta_add: dict) -> dict:
    import dnfile
    pe_c = parse_pe_and_cli(cand_bytes)
    mc = parse_metadata_root(cand_bytes, pe_c["meta_off"], pe_c["meta_size"])

    m1f0_rva = dnfile.dnPE(data=cand_bytes).net.mdtables.MethodDef.rows[0x1F0 - 1].Rva
    off_1f0 = pe_c["rva_to_off"](m1f0_rva)
    sc_1f0 = parse_raw_method_body_span(cand_bytes, off_1f0)
    eh_off_1f0 = align(off_1f0 + sc_1f0[1] + sc_1f0[2], 4)

    # 1. wrong EH flags
    m1 = bytearray(cand_bytes); m1[eh_off_1f0 + 4] = 0
    ok1, msg1, _ = audit_isolation_bulk162(parent_bytes, bytes(m1), body_targets, target_to_batch, expected_new_locals, meta_add)
    assert not ok1, "NC1: wrong EH flags was not rejected"

    # 2. wrong EH endpoints
    m2 = bytearray(cand_bytes); m2[eh_off_1f0 + 20] += 4
    ok2, msg2, _ = audit_isolation_bulk162(parent_bytes, bytes(m2), body_targets, target_to_batch, expected_new_locals, meta_add)
    assert not ok2, "NC2: wrong EH endpoints was not rejected"

    # 3. missing moresects
    m3 = bytearray(cand_bytes); m3[off_1f0] &= ~0x08
    ok3, msg3, _ = audit_isolation_bulk162(parent_bytes, bytes(m3), body_targets, target_to_batch, expected_new_locals, meta_add)
    assert not ok3, "NC3: missing moresects was not rejected"

    # 4. unaligned EH section
    m4 = bytearray(cand_bytes); m4[eh_off_1f0 - 1] = 0xFF
    ok4, msg4, _ = audit_isolation_bulk162(parent_bytes, bytes(m4), body_targets, target_to_batch, expected_new_locals, meta_add)
    assert not ok4, "NC4: unaligned EH section was not rejected"

    # 5. wrong local token
    m5 = bytearray(cand_bytes); m5[off_1f0 + 8] ^= 0x01
    ok5, msg5, _ = audit_isolation_bulk162(parent_bytes, bytes(m5), body_targets, target_to_batch, expected_new_locals, meta_add)
    assert not ok5, "NC5: wrong local token was not rejected"

    # 6. wrong typespec element
    m6 = bytearray(cand_bytes)
    idx_ts = m6.rfind(bytes.fromhex("041d1180dc"))
    assert idx_ts > 16033792
    m6[idx_ts + 4] ^= 0x01
    ok6, msg6, _ = audit_isolation_bulk162(parent_bytes, bytes(m6), body_targets, target_to_batch, expected_new_locals, meta_add)
    assert not ok6, "NC6: wrong typespec element was not rejected"

    # 7. wrong methodspec instantiation
    m7 = bytearray(cand_bytes)
    idx_ms = m7.rfind(bytes.fromhex("050a011180dc"))
    assert idx_ms > 16033792
    m7[idx_ms + 5] = 0xb1
    ok7, msg7, _ = audit_isolation_bulk162(parent_bytes, bytes(m7), body_targets, target_to_batch, expected_new_locals, meta_add)
    assert not ok7, "NC7: wrong methodspec instantiation was not rejected"

    # 8. wrong methodspec plant instantiation
    m8_bb = bytearray(cand_bytes)
    idx_bb = m8_bb.rfind(bytes.fromhex("050a01128210"))
    assert idx_bb > 16033792
    m8_bb[idx_bb + 4:idx_bb + 6] = bytes.fromhex("81f4")
    ok8_bb, msg8_bb, _ = audit_isolation_bulk162(parent_bytes, bytes(m8_bb), body_targets, target_to_batch, expected_new_locals, meta_add)
    assert not ok8_bb, "NC8: wrong methodspec plant instantiation was not rejected"

    # 9. wrong US compressed length
    us_abs_start = mc["streams"]["#US"]["abs_offset"]
    us_new_off = us_abs_start + 208658
    m_us_len = bytearray(cand_bytes); m_us_len[us_new_off] = 0x1D
    ok_us1, msg_us1, _ = audit_isolation_bulk162(parent_bytes, bytes(m_us_len), body_targets, target_to_batch, expected_new_locals, meta_add)
    assert not ok_us1, "NC9: wrong US compressed length was not rejected"

    # 10. wrong US utf16 char
    m_us_chr = bytearray(cand_bytes); m_us_chr[us_new_off + 1] ^= 0x01
    ok_us2, msg_us2, _ = audit_isolation_bulk162(parent_bytes, bytes(m_us_chr), body_targets, target_to_batch, expected_new_locals, meta_add)
    assert not ok_us2, "NC10: wrong US utf16 char was not rejected"

    # 11. wrong US terminal flag
    m_us_flg = bytearray(cand_bytes); m_us_flg[us_new_off + 31] = 0x01
    ok_us3, msg_us3, _ = audit_isolation_bulk162(parent_bytes, bytes(m_us_flg), body_targets, target_to_batch, expected_new_locals, meta_add)
    assert not ok_us3, "NC11: wrong US terminal flag was not rejected"

    # 12. wrong US old prefix mutation
    m_us_pre = bytearray(cand_bytes); m_us_pre[us_abs_start + 16] ^= 0x01
    ok_us4, msg_us4, _ = audit_isolation_bulk162(parent_bytes, bytes(m_us_pre), body_targets, target_to_batch, expected_new_locals, meta_add)
    assert not ok_us4, "NC12: wrong US old prefix mutation was not rejected"

    # 13. outside MemberRef signature mutation
    t_abs_start = mc["streams"]["#~"]["abs_offset"] + mc["tables_data_start"]
    dn_c = dnfile.dnPE(data=cand_bytes)
    mdef_off = t_abs_start
    mref_off = t_abs_start
    for tbl in dn_c.net.mdtables.tables_list:
        if tbl.number < 0x06: mdef_off += tbl.num_rows * tbl.row_size
        if tbl.number < 0x0A: mref_off += tbl.num_rows * tbl.row_size
    m8 = bytearray(cand_bytes); m8[mref_off + 4] ^= 0x01
    ok8, msg8, _ = audit_isolation_bulk162(parent_bytes, bytes(m8), body_targets, target_to_batch, expected_new_locals, meta_add)
    assert not ok8, "NC13: outside MemberRef signature mutation was not rejected"

    # 14. outside MethodDef RVA mutation
    m9 = bytearray(cand_bytes); m9[mdef_off] ^= 0x04
    ok9, msg9, _ = audit_isolation_bulk162(parent_bytes, bytes(m9), body_targets, target_to_batch, expected_new_locals, meta_add)
    assert not ok9, "NC14: outside MethodDef RVA mutation was not rejected"

    return {
        "nc_wrong_eh_flags": {"rejected": not ok1, "msg": msg1},
        "nc_wrong_eh_endpoints": {"rejected": not ok2, "msg": msg2},
        "nc_missing_moresects": {"rejected": not ok3, "msg": msg3},
        "nc_unaligned_eh_section": {"rejected": not ok4, "msg": msg4},
        "nc_wrong_local_token": {"rejected": not ok5, "msg": msg5},
        "nc_wrong_typespec_element": {"rejected": not ok6, "msg": msg6},
        "nc_wrong_methodspec_instantiation": {"rejected": not ok7, "msg": msg7},
        "nc_wrong_methodspec_plant_instantiation": {"rejected": not ok8_bb, "msg": msg8_bb},
        "nc_wrong_us_compressed_length": {"rejected": not ok_us1, "msg": msg_us1},
        "nc_wrong_us_utf16_char": {"rejected": not ok_us2, "msg": msg_us2},
        "nc_wrong_us_terminal_flag": {"rejected": not ok_us3, "msg": msg_us3},
        "nc_wrong_us_old_prefix_mutation": {"rejected": not ok_us4, "msg": msg_us4},
        "nc_outside_memberref_signature_mutation": {"rejected": not ok8, "msg": msg8},
        "nc_outside_methoddef_rva_mutation": {"rejected": not ok9, "msg": msg9},
    }

def compare_against_baseline(baseline_bytes: bytes, cand_bytes: bytes, expected_new_targets: set) -> dict:
    import dnfile
    pe_b = parse_pe_and_cli(baseline_bytes)
    pe_c = parse_pe_and_cli(cand_bytes)
    dn_b = dnfile.dnPE(data=baseline_bytes)
    dn_c = dnfile.dnPE(data=cand_bytes)
    mrows_b = dn_b.net.mdtables.MethodDef.rows
    mrows_c = dn_c.net.mdtables.MethodDef.rows
    assert len(mrows_b) == len(mrows_c) == 2317

    body_diff_methods = []
    identical_body_methods = 0

    for idx in range(len(mrows_b)):
        tok = 0x06000000 | (idx + 1)
        rb = mrows_b[idx]
        rc = mrows_c[idx]

        if rb.Rva == 0 and rc.Rva == 0:
            identical_body_methods += 1
            continue

        if (rb.Rva == 0) != (rc.Rva == 0):
            body_diff_methods.append({
                "token": f"0x{tok:08X}",
                "name": str(rc.Name),
                "baseline_rva": rb.Rva,
                "candidate_rva": rc.Rva,
                "reason": "RVA zero/nonzero mismatch",
                "is_expected_new_target": tok in expected_new_targets
            })
            continue

        off_b = pe_b["rva_to_off"](rb.Rva)
        off_c = pe_c["rva_to_off"](rc.Rva)
        sb = parse_raw_method_body_span(baseline_bytes, off_b)
        sc = parse_raw_method_body_span(cand_bytes, off_c)

        # Header byte comparison: direct byte slice covers flags, InitLocals, max_stack, code_size, local_sig
        hdr_b = baseline_bytes[off_b : off_b + sb[1]]
        hdr_c = cand_bytes[off_c : off_c + sc[1]]

        # IL bytecode comparison
        il_b = baseline_bytes[off_b + sb[1] : off_b + sb[1] + sb[2]]
        il_c = cand_bytes[off_c + sc[1] : off_c + sc[1] + sc[2]]

        # EH section & padding comparison (relative to method body)
        eh_identical = True
        if sb[7] != sc[7]:
            eh_identical = False
        elif sb[7] > 0:
            pad_b = baseline_bytes[off_b + sb[1] + sb[2] : sb[5]]
            pad_c = cand_bytes[off_c + sc[1] + sc[2] : sc[5]]
            eh_bytes_b = baseline_bytes[sb[5] : sb[5] + sb[6]]
            eh_bytes_c = cand_bytes[sc[5] : sc[5] + sc[6]]
            if pad_b != pad_c or eh_bytes_b != eh_bytes_c:
                eh_identical = False

        if hdr_b == hdr_c and il_b == il_c and eh_identical:
            identical_body_methods += 1
        else:
            body_diff_methods.append({
                "token": f"0x{tok:08X}",
                "name": str(rc.Name),
                "baseline_rva": rb.Rva,
                "candidate_rva": rc.Rva,
                "header_bytes_identical": (hdr_b == hdr_c),
                "il_bytes_identical": (il_b == il_c),
                "eh_identical": eh_identical,
                "is_expected_new_target": tok in expected_new_targets
            })

    differing_tokens = {int(m["token"], 16) for m in body_diff_methods}
    if differing_tokens != expected_new_targets:
        unexpected = differing_tokens - expected_new_targets
        missing = expected_new_targets - differing_tokens
        raise AssertionError(
            f"Baseline body diff mismatch! Unexpected diffs: {[hex(x) for x in unexpected]}, "
            f"Missing new targets: {[hex(x) for x in missing]}"
        )

    return {
        "baseline_sha256": sha256_bytes(baseline_bytes),
        "candidate_sha256": sha256_bytes(cand_bytes),
        "total_methods_compared": 2317,
        "identical_body_methods_count": identical_body_methods,
        "body_diff_methods_count": len(body_diff_methods),
        "body_diff_tokens": sorted(m["token"] for m in body_diff_methods),
        "all_other_2307_methods_identical": (identical_body_methods == 2307),
        "diff_methods": body_diff_methods
    }

def run_initlocals_negative_control(baseline_bytes: bytes, cand_bytes: bytes, expected_new_targets: set) -> dict:
    import dnfile
    pe_c = parse_pe_and_cli(cand_bytes)
    m_rva = dnfile.dnPE(data=cand_bytes).net.mdtables.MethodDef.rows[0x1F0 - 1].Rva
    off = pe_c["rva_to_off"](m_rva)
    mutated = bytearray(cand_bytes)
    mutated[off] ^= 0x10
    rejected = False
    msg = ""
    try:
        compare_against_baseline(baseline_bytes, bytes(mutated), expected_new_targets)
    except AssertionError as e:
        rejected = True
        msg = str(e)
    assert rejected, "InitLocals bit-flip negative control was NOT rejected by baseline comparator!"
    return {"rejected": True, "message": msg}

def run_type_flow_and_member_access_gates(cand_dll: pathlib.Path, support_dir: pathlib.Path, tools_dir: pathlib.Path, output_dir: pathlib.Path, new_target_tokens: set, all_target_tokens: set, cecil_dll: pathlib.Path) -> dict:
    results = {}
    res_dir = output_dir / "results"
    res_dir.mkdir(parents=True, exist_ok=True)

    invocation_count = 0
    expected_tokens = {f"0x{t:08X}" for t in all_target_tokens}
    assert len(expected_tokens) == 162

    def static_run(cmd, **kwargs):
        nonlocal invocation_count
        invocation_count += 1
        log = res_dir / f"static-invocation-{invocation_count:02d}"
        log.with_suffix(".argv.json").write_text(json.dumps(cmd, indent=2), encoding="utf-8")
        proc = subprocess.run(cmd, **kwargs)
        log.with_suffix(".stdout.log").write_text(proc.stdout or "", encoding="utf-8")
        log.with_suffix(".stderr.log").write_text(proc.stderr or "", encoding="utf-8")
        log.with_suffix(".exitcode.txt").write_text(str(proc.returncode), encoding="utf-8")
        return proc

    def assert_coverage(rows, expected, gate):
        actual = [row["token"] for row in rows]
        assert len(actual) == len(expected) and set(actual) == expected, f"{gate}: incomplete or duplicate method coverage"

    # 1. Verify tools exist
    vt_script = tools_dir / "frozen_verify_types.py"
    if not vt_script.exists(): vt_script = tools_dir / "verify_types_with_ldtoken_ldftn_copy.py"
    if not vt_script.exists(): raise FileNotFoundError(f"Missing verify_types script in {tools_dir}")

    vt_copy_script = tools_dir / "verify_types_with_ldtoken_ldftn_copy.py"
    if not vt_copy_script.exists(): raise FileNotFoundError(f"Missing verify_types_with_ldtoken_ldftn_copy.py in {tools_dir}")

    cil_exp_cs = tools_dir / "CilExporter.cs"
    if not cil_exp_cs.exists(): raise FileNotFoundError(f"Missing CilExporter.cs in {tools_dir}")

    eager_cs = tools_dir / "EagerVerifier.cs"
    if not eager_cs.exists(): raise FileNotFoundError(f"Missing EagerVerifier.cs in {tools_dir}")

    ma_dll = tools_dir / "member-access-bin/MemberAccess.dll"
    if not ma_dll.exists(): raise FileNotFoundError(f"Missing MemberAccess.dll in {tools_dir}")

    if not cecil_dll.exists(): raise FileNotFoundError(f"Missing Mono.Cecil.dll at {cecil_dll}")
    if not support_dir.exists(): raise FileNotFoundError(f"Missing support_dir at {support_dir}")

    # 2. Build CilExporter & EagerVerifier tools using dotnet
    tools_bin = output_dir / "tools_bin"
    tools_bin.mkdir(parents=True, exist_ok=True)

    def build_tool(cs_file: pathlib.Path, tool_name: str) -> pathlib.Path:
        t_dir = tools_bin / tool_name
        t_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(cs_file, t_dir / cs_file.name)
        csproj_txt = f"""<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <TargetFramework>net10.0</TargetFramework>
    <Nullable>disable</Nullable>
  </PropertyGroup>
  <ItemGroup>
    <Reference Include="Mono.Cecil" HintPath="{cecil_dll}" />
  </ItemGroup>
</Project>
"""
        (t_dir / f"{tool_name}.csproj").write_text(csproj_txt, encoding="utf-8")
        out_bin = t_dir / "bin"
        obj_bin = t_dir / "obj"
        r_bld = static_run([
            "dotnet", "build", str(t_dir / f"{tool_name}.csproj"),
            "-c", "Release",
            "-p:UseSharedCompilation=false",
            "--disable-build-servers",
            f"-p:BaseIntermediateOutputPath={obj_bin}/",
            f"-p:IntermediateOutputPath={obj_bin}/",
            "-o", str(out_bin),
            "--nologo"
        ], capture_output=True, text=True)
        if r_bld.returncode != 0:
            raise RuntimeError(f"Failed to build {tool_name}: {r_bld.stderr or r_bld.stdout}")
        target_dll = out_bin / f"{tool_name}.dll"
        if not target_dll.exists():
            raise FileNotFoundError(f"Expected compiled tool DLL not found: {target_dll}")
        return target_dll

    cil_exp_dll = build_tool(cil_exp_cs, "CilExporter")
    eager_dll = build_tool(eager_cs, "EagerVerifier")

    # 3. CilExporter export for all 162 target methods
    dump_162 = res_dir / "actual-candidate-162methods-dump.json"
    tok_list_str = ",".join(f"0x{t:08X}" for t in sorted(all_target_tokens))
    r_exp = static_run([
        "dotnet", str(cil_exp_dll), str(cand_dll), str(dump_162), str(support_dir), tok_list_str
    ], capture_output=True, text=True)
    if r_exp.returncode != 0 or not dump_162.exists():
        raise RuntimeError(f"CilExporter failed (exit {r_exp.returncode}): {r_exp.stderr or r_exp.stdout}")
    print(f"CilExporter exported {len(all_target_tokens)} targets to {dump_162.name}.")

    # 4. Branch and EH boundary check across all 162 methods
    d162_obj = json.loads(dump_162.read_text(encoding="utf-8"))
    assert_coverage(d162_obj["methods"], expected_tokens, "CilExporter")
    branch_eh_checked = 0
    eh_handlers_checked = 0
    for m in d162_obj["methods"]:
        ins_offsets = {ins["offset"] for ins in m["instructions"]}
        for ins in m["instructions"]:
            opnd = ins.get("operand")
            if isinstance(opnd, dict):
                if "target" in opnd:
                    assert opnd["target"] in ins_offsets, f"Branch target {opnd['target']} not in ins_offsets"
                    branch_eh_checked += 1
                if "targets" in opnd and isinstance(opnd["targets"], list):
                    for tgt in opnd["targets"]:
                        assert tgt in ins_offsets, f"Switch target {tgt} not in ins_offsets"
                        branch_eh_checked += 1
        for eh in m.get("handlers", []):
            assert eh["tryStart"] in ins_offsets and eh["tryEnd"] in ins_offsets and eh["handlerStart"] in ins_offsets
            eh_handlers_checked += 1
            branch_eh_checked += 1
    print(f"Branch and EH boundary check across 162 methods: PASS ({branch_eh_checked} targets/regions, {eh_handlers_checked} handlers)")

    # 5. Type flow check on all 162 methods (verify_types.py)
    r_vt = static_run([sys.executable, str(vt_script), str(dump_162)], capture_output=True, text=True)
    typed_json = dump_162.with_suffix(".typed.json")
    if not typed_json.exists():
        raise RuntimeError(f"verify_types.py did not produce .typed.json! {r_vt.stderr or r_vt.stdout}")
    vt162_doc = json.loads(typed_json.read_text(encoding="utf-8"))
    assert_coverage(vt162_doc, expected_tokens, "frozen type checker")
    assert r_vt.returncode == 1, "Frozen checker must return its documented rejection exit code for the seven unsupported methods"
    fails_162 = [m for m in vt162_doc if m.get("status") != "PASS"]
    failed_tokens = {f["token"] for f in fails_162}
    assert failed_tokens == HISTORICAL_UNSUPPORTED_TYPE_TOKENS, f"Unexpected type flow failure set: {failed_tokens} != {HISTORICAL_UNSUPPORTED_TYPE_TOKENS}"
    new_tok_strs = {f"0x{t:08X}" for t in new_target_tokens}
    assert not (failed_tokens & new_tok_strs), f"New targets in Native110 failed type flow: {failed_tokens & new_tok_strs}"
    print(f"Type flow check on 162 methods: PASS (exact 7 historical unsupported retained, all 10 new targets PASS).")

    # 6. Supported subset (162 - 7 = 155 methods) full PASS check
    d_supp_obj = {**d162_obj, "methods": [m for m in d162_obj["methods"] if m["token"] not in HISTORICAL_UNSUPPORTED_TYPE_TOKENS]}
    p_supp = res_dir / "actual-candidate-supported-155methods-dump.json"
    p_supp.write_text(json.dumps(d_supp_obj, indent=2), encoding="utf-8")
    r_supp = static_run([sys.executable, str(vt_script), str(p_supp)], capture_output=True, text=True)
    assert r_supp.returncode == 0, f"Supported 155 methods failed verify_types: {r_supp.stderr or r_supp.stdout}"
    print("Type flow supported subset (155 methods): PASS (exitcode 0).")

    # 7. Stack underflow negative control on verify_types
    bad_under = copy.deepcopy(d_supp_obj)
    bad_under["methods"][0]["instructions"].insert(0, {"offset": 0, "op": "pop", "operand": None})
    p_under = res_dir / "neg_control_bad_stack_dump.json"
    p_under.write_text(json.dumps(bad_under, indent=2), encoding="utf-8")
    r_under = static_run([sys.executable, str(vt_script), str(p_under)], capture_output=True, text=True)
    assert r_under.returncode == 1, "Stack underflow negative control was NOT rejected by verify_types!"
    print("Negative control (stack underflow rejection): PASS.")

    # 8. Extended ldtoken/ldftn type flow checker
    p_d162_copy = res_dir / "actual-candidate-162methods-ldtoken-ldftn-copy-dump.json"
    p_d162_copy.write_text(json.dumps(d162_obj, indent=2), encoding="utf-8")
    r_vt_copy = static_run([sys.executable, str(vt_copy_script), str(p_d162_copy)], capture_output=True, text=True)
    assert r_vt_copy.returncode == 0, f"Extended type flow checker failed: {r_vt_copy.stderr or r_vt_copy.stdout}"
    extended_doc = json.loads(p_d162_copy.with_suffix(".typed.json").read_text(encoding="utf-8"))
    assert_coverage(extended_doc, expected_tokens, "extended type checker")
    assert all(m["status"] == "PASS" for m in extended_doc)
    print("Extended ldtoken/ldftn type flow check across 162 methods: PASS (exitcode 0).")

    # 9. MemberAccess Gate on 162 targets
    targets_input_json = res_dir / "targets_162methods_input.json"
    targets_input_json.write_text(json.dumps({
        "methods": [{"token": f"0x{t:08X}", "name": "target"} for t in sorted(all_target_tokens)]
    }, indent=2), encoding="utf-8")
    ma162_out = res_dir / "MEMBER-ACCESS-162METHODS-AUTHENTIC.json"
    r_ma = static_run([
        "dotnet", str(ma_dll), str(cand_dll), str(support_dir), str(targets_input_json), str(ma162_out)
    ], capture_output=True, text=True)
    if r_ma.returncode != 0 or not ma162_out.exists():
        raise RuntimeError(f"MemberAccess gate failed (exit {r_ma.returncode}): {r_ma.stderr or r_ma.stdout}")
    ma_doc = json.loads(ma162_out.read_text(encoding="utf-8"))
    assert ma_doc.get("pass") is True and ma_doc.get("rejected") == 0 and ma_doc.get("unresolved") == 0, f"MemberAccess gate rejected: {ma_doc}"
    assert ma_doc.get("target_methods") == 162
    print(f"MemberAccess gate on 162 targets: PASS (pass=True, rejected=0, unresolved=0).")

    # 10. MemberAccess negative control (rejecting private PrepareUI.instance)
    b_c1 = bytearray(cand_dll.read_bytes())
    pat_call_677 = bytes([0x28, 0x77, 0x06, 0x00, 0x06])
    pat_ldsfld_885 = bytes([0x7E, 0x85, 0x08, 0x00, 0x04])
    idx_pat = b_c1.rfind(pat_call_677)
    assert idx_pat > 16033792, "Pattern for call 0x06000677 not found in candidate"
    b_c1[idx_pat:idx_pat+5] = pat_ldsfld_885
    neg_ma_dll = output_dir / "neg_control_private_prepareui_instance.dll"
    neg_ma_dll.write_bytes(b_c1)
    neg_ma_out = res_dir / "CONTROL-MEMBER-ACCESS-REJECT-PRIVATE-PREPAREUI-INSTANCE.json"
    r_neg_ma = static_run([
        "dotnet", str(ma_dll), str(neg_ma_dll), str(support_dir), str(targets_input_json), str(neg_ma_out)
    ], capture_output=True, text=True)
    assert r_neg_ma.returncode != 0, "MemberAccess negative control (private field access) was NOT rejected!"
    neg_ma_doc = json.loads(neg_ma_out.read_text(encoding="utf-8"))
    assert neg_ma_doc.get("pass") is False and neg_ma_doc.get("target_methods") == 162
    assert neg_ma_doc.get("rejected") == 1 and neg_ma_doc.get("unresolved") == 0
    assert any(m.get("allowed") is False and "PrepareUIController::" in m.get("member", "") for m in neg_ma_doc["members"])
    neg_ma_dll.unlink()
    print("Negative control (rejecting private PrepareUI.instance in MemberAccess): PASS.")

    # 11. EagerVerifier Gate (1170 MemberRefs, 70 appended resolved, unresolved=0)
    eager_out = res_dir / "EAGER-MEMBERREF-BULK162-AUTHENTIC.json"
    r_eag = static_run([
        "dotnet", str(eager_dll), str(cand_dll), str(support_dir), str(eager_out)
    ], capture_output=True, text=True)
    if r_eag.returncode != 0 or not eager_out.exists():
        raise RuntimeError(f"EagerVerifier failed (exit {r_eag.returncode}): {r_eag.stderr or r_eag.stdout}")
    eag_doc = json.loads(eager_out.read_text(encoding="utf-8"))
    assert eag_doc.get("total_member_refs") == 1170 and eag_doc.get("unresolved_count") == 0 and len(eag_doc.get("appended_64_resolved", [])) == 70, f"EagerVerifier resolution mismatch: {eag_doc}"
    print("EagerVerifier resolution on Bulk162 (1,170 rows including 70 appended, unresolved=0): PASS.")

    results["type_flow"] = {"status": "PASS", "unsupported_retained": list(failed_tokens)}
    results["branch_eh_boundary"] = {"status": "PASS", "checked": branch_eh_checked, "handlers": eh_handlers_checked}
    results["member_access"] = {"status": "PASS", "rejected": 0, "unresolved": 0}
    results["eager_verifier"] = {"status": "PASS", "total_refs": 1170, "appended_resolved": 70, "unresolved": 0}
    results["candidate_sha256"] = sha256_bytes(cand_dll.read_bytes())
    results["target_tokens"] = sorted(expected_tokens)
    results["qualification_scope"] = "static_only_not_semantic_acceptance"
    return results

