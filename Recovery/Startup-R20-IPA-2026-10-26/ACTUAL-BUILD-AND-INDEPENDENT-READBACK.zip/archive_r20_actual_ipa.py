"""Preserve the completed actual R20 build without promoting device acceptance."""
from pathlib import Path
import json
import shutil
import subprocess
from archive_support import js, pack, manifest, record, sha

W = Path(__file__).resolve().parent
R = W.parents[1] / 'audit/repo-native113'
Q = W / 'r20-full-build-run-40263428409'
D = R / 'Recovery/Startup-R20-IPA-2026-10-26'
P = W / 'r20-release-2026-10-26'
HEAD = 'c22560ed9e025f04d4e58bc38ba0f23df8b9feb4'
TAG = 'startup-r20-ipad-test-2026-10-26'
BASE = 'https://github.com/lyiming710-cloud/GodsPVZ-iOS'
RELEASE = BASE + '/releases/tag/' + TAG
READBACK = json.loads((Q / 'INDEPENDENT-IPA-READBACK.json').read_bytes())
RUN = json.loads((Q / 'RUN.json').read_bytes())
assert RUN['conclusion'] == 'success' and RUN['headSha'] == HEAD
assert READBACK['actual_xcode_build_succeeded'] and READBACK['unity_errors'] == 0
assert READBACK['actual_apple_errors'] == 0 and READBACK['actual_apple_sources_and_raw_logs'] == 324
assert not READBACK['device_execution'] and not READBACK['full_game_semantic_acceptance']
assert not D.exists() and not P.exists()
D.mkdir()
P.mkdir()
(D / '.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text\n*.md -text\n*.zip -text\n*.py -text\n')

items = []
for sub in ['editor', 'apple', 'shaders']:
    for p in sorted((Q / sub).rglob('*')):
        if p.is_file():
            items.append((f'r20-full-build-run-40263428409/{p.relative_to(Q).as_posix()}', p.read_bytes()))
for p in sorted(Q.iterdir()):
    if p.is_file():
        items.append(('r20-full-build-run-40263428409/' + p.name, p.read_bytes()))
for name in ['ARCHIVE.json', 'FORENSICS.json']:
    items.append(('r20-full-build-run-40263428409/forensics/' + name, (Q / 'forensics' / name).read_bytes()))
for name in ['archive_support.py', 'read_actual_r20_ipa.py', Path(__file__).name]:
    items.append((name, (W / name).read_bytes()))
# Keep exact build implementation and dependencies as of the actual CI head.
paths = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', HEAD, '--', 'scripts/actions'], cwd=R).decode().splitlines()
paths += [
    '.github/workflows/bulk401-startup-runtime-gate.yml',
    'Recovery/Startup-R3-2026-10-24/ios-support/Assets/Editor/GodsPVZIOSBuild.cs',
    'Recovery/Startup-R3-2026-10-24/ios-support/Assets/Editor/GodsPVZStartupAudit.cs',
    'Recovery/Startup-R20-Asset-Case-2026-10-26/ASSET-CASE-PLAN.json',
    'Recovery/Startup-R20-Asset-Case-2026-10-26/ASSET-CASE-IMPORT-NAMES.json',
    'Recovery/Startup-R20-Sites104-2026-10-26/STARTUP-R20-SITES104-CANDIDATE.zip',
]
for path in paths:
    items.append(('actual-build-source/' + path, subprocess.check_output(['git', 'show', HEAD + ':' + path], cwd=R)))
pack(D / 'ACTUAL-BUILD-AND-INDEPENDENT-READBACK.zip', items)
for name, src in [
    ('RUN.json', Q / 'RUN.json'),
    ('INDEPENDENT-IPA-READBACK.json', Q / 'INDEPENDENT-IPA-READBACK.json'),
    ('IPA-VALIDATION.json', Q / 'apple/ipa-output/IPA-VALIDATION.json'),
    ('ACTUAL-UNITY-BUILD-REPORT.json', Q / 'editor/actual-unity-build-report.json'),
    ('ACTUAL-EXPORT-APPLE-COMPILER.json', Q / 'apple/actual-export-compiler/REPORT.json'),
    ('ACTUAL-EXPORT-BINDING.json', Q / 'editor/startup-r20-export-binding.json'),
    ('ASSET-CASE-IMPORT-AUDIT.json', Q / 'editor/asset-case-import-audit.json'),
]:
    shutil.copyfile(src, D / name)

ipa = Q / 'ipa/GodsPVZ_1.0.2_startup_r20_unsigned.ipa'
source = Q / 'forensics/UNQUALIFIED-GENERATED-SOURCE-AND-BUILD-REPORT.zip'
source_dest = P / 'Startup-R20-Actual-Export-40263428409-generated-and-report.zip'
shutil.copyfile(source, source_dest)
assets = [
    dict(**record(ipa.name, ipa.read_bytes()), local=str(ipa), kind='UNSIGNED_IPAD_TEST_IPA'),
    dict(**record(source_dest.name, source_dest.read_bytes()), local=str(source_dest), kind='ACTUAL_EXPORT_SOURCE_WITH_UNCHANGED_DIAGNOSTIC_CAPTURE_LABEL'),
    dict(**record('Startup-R20-40263428409-build-and-readback.zip', (D / 'ACTUAL-BUILD-AND-INDEPENDENT-READBACK.zip').read_bytes()), local=str(D / 'ACTUAL-BUILD-AND-INDEPENDENT-READBACK.zip'), kind='RAW_COMPILER_EDITOR_SHADERS_READBACK_AND_EXACT_BUILD_SOURCE'),
]
assert assets[0]['sha256'] == READBACK['ipa_sha256'] and assets[0]['bytes'] == READBACK['ipa_bytes']
for row in assets:
    row['planned_download_url'] = BASE + '/releases/download/' + TAG + '/' + row['file']
js(D / 'RELEASE-ASSETS-LOCAL.json', dict(tag=TAG, source_commit=HEAD, release_url=RELEASE, uploaded=False, rows=assets))
js(D / 'PROGRESS.json', dict(
    status='ACTUAL_UNITY_EXPORT_APPLE_BUILD_AND_UNSIGNED_IPA_PASS_DEVICE_PENDING',
    run_id=40263428409, source_commit=HEAD, candidate_sha256=READBACK['candidate_sha256'],
    unity_errors=0, unity_warnings=1364, actual_apple_units=324, actual_apple_cpp=258, actual_apple_c=66,
    actual_apple_errors=0, actual_apple_warnings=3584, xcode_build='SUCCEEDED',
    ipa=dict(file=ipa.name, bytes=READBACK['ipa_bytes'], sha256=READBACK['ipa_sha256'], unsigned=True, architecture='arm64', platform='physical_iOS'),
    r20_repair_positions=104, r20_changed_methods=8, r19_finite_methods=81, r19_pending_methods=19,
    r21_proposed_positions=16, r21_constructed_positions=0, r21_proposals_in_this_ipa=False,
    ipad_execution=False, physical_audio=False, black_screen_flicker_resolution=False, whole_game_accepted=False,
    release_url=RELEASE, release_uploaded=False))
(D / 'README.md').write_bytes(f'''# R20 未签名 iPad 测试 IPA：真实构建通过

[实际构建 40263428409]({BASE}/actions/runs/40263428409) 已成功完成 Unity 导出、全部实际导出 C/C++ 检查、Xcode 编译链接及 IPA 打包。固定构建提交为 `{HEAD}`，游戏候选仍是 `{READBACK['candidate_sha256']}`。

下载入口：[R20 iPad 测试包 Release]({RELEASE})。IPA 为 `GodsPVZ_1.0.2_startup_r20_unsigned.ipa`，192,091,143 字节（约 183.2 MiB），SHA-256 `{READBACK['ipa_sha256']}`。未签名，沿用已有签名安装方式；本次没有请求或使用签名身份。

## 本次实际证据

- Unity BuildReport 为 Succeeded、0 errors、1,364 warnings；逐步骤也没有 Error/Exception/Assert。保留警告，不解释为零缺陷。
- 真实 Editor MainMenu 连续 1,862 帧，两个 Canvas、一个 MainUI，0 启动错误；148 个插件脚本绑定、130 个原序列化标记均保留，无缺失组件。这是 Editor 启动范围。
- 六组大小写冲突通过仅移动 12 份资源及 12 份 meta 解决；原始 basename、内容、GUID 保留，全部 6,842 个 Assets 文件 hash 保留。实际 Unity 对 12 份资源的 GUID、路径、LoadMainAsset.name 全部核验通过。
- 从本次真实导出取得 258 个 C++、66 个 C 文件，共 324 个。逐个源文件 hash、原始 Apple 编译日志已回读：0 errors，3,584 warnings。六个编译控制为两正四负，均符合预期。独立的真实 xcodebuild 最终记录 BUILD SUCCEEDED。
- IPA ZIP 共 647 项，CRC 完整；主程序和 UnityFramework 均为 thin arm64、physical iOS，无有效签名或 provisioning；实际 Mach-O 最低系统 12.0，SDK 18.5。包内 6,985,488 字节 metadata 与本次真实导出逐字节一致。
- 329 个原始导出归档文件、326 个导出绑定文件、324 个源文件/原始日志、96 个 shader 程序/PNG 均逐份核对。20 张受控渲染 PNG 中心像素另行解码核对；76 个 shader stage 检查通过。像素结果来自软件 OpenGL，不能据此代替 iPad Metal 实测。

Apple 的 syntax-only driver 保留历史 `-mios-version-min=10.12`，与最终链接 Mach-O 的 12.0 不同；原始 flags 全部保存，没有声称两组命令完全相同。真正 IPA 由之后的独立 xcodebuild 产生，已另行检查最终二进制。首次独立 reader 误假定 target 参数拼写，先在断言处停止，初始源代码和失败记录保留；修正为读取真实 arm64/SDK 参数后完成验证，没有更改产物。

## 证据如何保存

`ACTUAL-BUILD-AND-INDEPENDENT-READBACK.zip` 包含完整返回的 Editor/Apple/着色器原始文件、独立 reader、第一次 reader 假定失败、固定提交的 scripts/actions 与实际工作流、原始构建 helper、资源路径计划，以及固定输入候选包；内有逐文件 MANIFEST。生成 C/C++/metadata/剥离后程序集的原始大归档另存于 Release 的 `Startup-R20-Actual-Export-40263428409-generated-and-report.zip`。

大归档内历史捕获器的 qualified=false/UNQUALIFIED 名称原样保留，表示捕获器自身不授予资格；本目录单独以本次真实 BuildReport、Apple/Xcode 日志、导出绑定和 IPA 字节建立构建通过结论，没有改写原始标记为全游戏合格。较早的 40255311794/40259026509 失败、原报告和源文件继续保留在既有检查点。

## 当前验收边界及下一步

这次 R20 是先完成 104 个原生语义位置、8 个方法后集中检测的包，不是修复了 104 个独立 bug。R19 有 81 个有限输入 profile、31,812 条正常原版对照；另 19 个方法仍待验收，其中四个已有差异。新源队列有 16 个提案、5 个方法、0 个新构造位置，未包含在此 IPA；继续按超过 100 个实际源位置再集中检测。

尚未在用户的 iPad Pro M5 / iPadOS 27.0 运行新包，未证明此前黑屏、闪烁、无声音已解决。设备验收应记录启动后能否进入 MainMenu、画面是否持续稳定、按钮是否响应、是否能进入 Board、是否有实际声音；使用现有签名安装方法并保留存档。游戏行为与高还原验收仍开放，不能把本次构建成功提升为整个游戏语义恢复完成。
'''.encode())

notes = f'''本次实际 Unity → Xcode → 未签名 IPA 已构建成功，用于 iPad Pro M5 的新一轮真机反馈。

- 固定源码提交：`{HEAD}`；游戏候选：`{READBACK['candidate_sha256']}`。
- [真实工作流]({BASE}/actions/runs/40263428409)：Unity 0 errors；实际导出的全部 258 C++ / 66 C 检查通过，Xcode BUILD SUCCEEDED。
- 资源大小写冲突修复保持全部 6,842 个 Assets 文件内容 hash、GUID 和原 basename。
- IPA：192,091,143 bytes；arm64 / physical iOS / unsigned。主程序与 UnityFramework 的最低系统为 12.0；使用 Xcode 16.4 / SDK 18.5。
- IPA SHA-256：`{READBACK['ipa_sha256']}`。

下载 `.ipa` 后沿用现有签名安装方式。尚无新包 iPad 实测结果；请记录主菜单、持续画面、触控、进入 Board 和声音。没有宣称黑屏/闪烁已经解决。

原始导出源归档和完整独立回读包随附；每份文件有 SHA-256 清单。生成源归档内 qualified=false 的诊断捕获标记保持原样，构建结论另由实际报告、全部原始编译日志、导出绑定和 IPA 字节核对支持。

R19 当前 81 个有限 profile、19 个待验收；R21 的 16 个提案尚未构造、未包含在此包。该预发布不代表整个游戏或全部方法已高还原验收。
'''
(P / 'RELEASE-NOTES.md').write_bytes(notes.encode())
manifest(D)
print(json.dumps(dict(archived=D.name, raw_evidence_files=len(items), release_assets=[dict(file=r['file'], bytes=r['bytes'], sha256=r['sha256']) for r in assets])))
