"""Compare returned real Editor serialization against the original Plant plan.
No fixture values are used as actual observations. Every absent object/field or
unresolved persistent reference stays incomplete/failed. No game code writes.
"""
from pathlib import Path
import argparse,hashlib,json,re,struct,zipfile
G=Path(__file__).resolve().parent;W=G.parent
EXPECTED='75160a3233f1e1ab13a44f712efb4b47fdeb9b57bd38fa25f180276bb7b50e15'
PLAN='82e46ff8f080a25bb837cd557692ed586da1c7e42d22f2c45401c99992ba3e5b'
CAPTURE='a3186d405f1776ddf55be91069641df3538da8ce50b49084b230c5b990ab8f7f'
sha=lambda b:hashlib.sha256(b).hexdigest()

def compare(expected,actual,path,guid,passed,failed,unresolved):
 if isinstance(expected,dict)and'fileID'in expected:
  if not expected['fileID']:
   ok=actual is None or isinstance(actual,dict)and(actual.get('instanceID')==0 or actual.get('fileID')==0)
   (passed if ok else failed).append(dict(path=path,kind='null_reference',expected=expected,actual=actual));return
  if isinstance(actual,dict)and'fileID'in actual:
   wanted=expected.get('guid',guid);ok=actual['fileID']==expected['fileID']and actual.get('guid')==wanted and actual.get('type')==3
   (passed if ok else failed).append(dict(path=path,kind='persistent_reference',expected=dict(fileID=expected['fileID'],guid=wanted,type=3),actual=actual));return
  if isinstance(actual,dict)and actual.get('instanceID')==0:
   failed.append(dict(path=path,kind='EXPECTED_NON_NULL_REFERENCE_IS_NULL',expected=expected,actual=actual));return
  unresolved.append(dict(path=path,kind='PERSISTENT_GUID_OR_LOCAL_ID_UNOBSERVED',expected=expected,actual=actual));return
 if isinstance(expected,dict):
  if not isinstance(actual,dict):failed.append(dict(path=path,expected_kind='object',actual=actual));return
  for key,value in expected.items():
   if key not in actual:failed.append(dict(path=path+'.'+key,kind='MISSING_SERIALIZED_FIELD'))
   else:compare(value,actual[key],path+'.'+key,guid,passed,failed,unresolved)
  return
 if isinstance(expected,list):
  if not isinstance(actual,list)or len(actual)!=len(expected):failed.append(dict(path=path,kind='array_length',expected=len(expected),actual=actual));return
  passed.append(dict(path=path,kind='array_length',count=len(expected)))
  for i,value in enumerate(expected):compare(value,actual[i],path+'['+str(i)+']',guid,passed,failed,unresolved)
  return
 if isinstance(expected,float):
  try:ok=struct.pack('<f',expected)==struct.pack('<f',float(actual))
  except (TypeError,ValueError,OverflowError,struct.error):ok=False
 else:ok=expected==actual
 (passed if ok else failed).append(dict(path=path,kind='scalar_f32'if isinstance(expected,float)else'scalar',expected=expected,actual=actual))

def verify(probe,plan,source):
 assert probe['candidate_sha256']==plan['candidate_sha256']==EXPECTED
 rows=[];missing=[]
 for wanted in plan['plans']:
  meta=source.read(wanted['source_path']+'.meta');m=re.findall(rb'(?m)^guid: ([0-9a-f]{32})\r?$',meta);assert len(m)==1;guid=m[0].decode()
  for route in ['AssetDatabase','Resources']:
   found=[o for o in probe['objects']if o['phase']=='after-force-import'and o['route']==route and o['type']=='Plant'and o['path'].lower()==wanted['source_path'].lower()]
   if len(found)!=1:missing.append(dict(resource=wanted['resource'],route=route,actual_object_count=len(found)));continue
   o=found[0];passed=[];failed=[];unresolved=[]
   if not re.search(r' guid='+guid+r' localID='+str(wanted['source_owner'])+r'$',o['identity']):failed.append(dict(path='<owner>',kind='WRONG_OWNER_IDENTITY',actual=o['identity']))
   try:
    actual=json.loads(o['editor_json']);actual=actual.get('MonoBehaviour',actual);compare(wanted['fields'],actual,wanted['resource'],guid,passed,failed,unresolved)
   except (ValueError,TypeError)as e:failed.append(dict(path='<editor_json>',kind='INVALID_ACTUAL_DATA',error=repr(e)))
   rows.append(dict(resource=wanted['resource'],route=route,source_owner=wanted['source_owner'],original_game_fields=94,actual_leaf_checks_passed=len(passed),actual_leaf_checks_failed=len(failed),unresolved_references=len(unresolved),pass_field_comparison=not failed and not unresolved,checks=passed,failures=failed,unresolved=unresolved))
 complete=probe['collection_complete']and not probe.get('exceptions')and probe['source_bytes_unchanged']and probe['game_dll_unchanged']and len(rows)==18 and not missing
 return dict(scope='READBACK_OF_ACTUAL_UNITY_PLANT_SERIALIZED_FIELDS_ONLY_NOT_GAMEPLAY_OR_IPAD',candidate_sha256=EXPECTED,collection_complete=complete,all_18_resource_routes_match_original=complete and all(r['pass_field_comparison']for r in rows),actual_resource_routes=len(rows),actual_leaf_checks_passed=sum(r['actual_leaf_checks_passed']for r in rows),actual_leaf_checks_failed=sum(r['actual_leaf_checks_failed']for r in rows),unresolved_references=sum(r['unresolved_references']for r in rows),missing_objects=missing,objects=rows,gameplay_proven=False,qualified_methods_added=0)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--probe',required=True);p.add_argument('--output',required=True);a=p.parse_args();out=Path(a.output);assert not out.exists()
 plan_bytes=(G/'ORIGINAL-PLANT-BINDING-PLAN.json').read_bytes();assert sha(plan_bytes)==PLAN;capture=next((W/'r21-source-run-40368892424').rglob('r21-source-prefabs-scenes-audio-metadata.zip'));assert sha(capture.read_bytes())==CAPTURE
 probe=Path(a.probe).read_bytes();result=verify(json.loads(probe),json.loads(plan_bytes),zipfile.ZipFile(capture));result.update(actual_probe_sha256=sha(probe),original_plan_sha256=PLAN,source_capture_sha256=CAPTURE);out.write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in result.items()if k not in ['objects','missing_objects']}))
