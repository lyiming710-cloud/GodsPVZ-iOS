"""Read original Zombie resource bytes; do not edit project or game assemblies."""
from pathlib import Path
import hashlib,json,sys,zipfile
G=Path(__file__).resolve().parent;W=G.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'python-deps'))
import UnityPy
from UnityPy.helpers.TypeTreeNode import TypeTreeNode
from UnityPy.helpers import TypeTreeHelper as H
from UnityPy.streams import EndianBinaryReader,EndianBinaryWriter
sha=lambda b:hashlib.sha256(b).hexdigest()
nodes=json.loads((G/'ZOMBIE-TYPE-TREE-UNADAPTED.json').read_bytes());changes=[]
for i,n in enumerate(nodes):
 if n['m_Name']=='m_Enabled'and n['m_Level']==1:changes.append(dict(index=i,before=dict(n),reason='MonoBehaviour enabled byte alignment'));n['m_MetaFlag']|=16384
 if n['m_Type']=='string'and i+3<len(nodes)and nodes[i+1]['m_Name']=='Array'and nodes[i+3]['m_Name']=='data'and nodes[i+3]['m_Type']=='string':changes.append(dict(index=i,before=dict(n),reason='string array wrapper, not scalar string'));n['m_Type']='vector'
tree=TypeTreeNode.from_list([TypeTreeNode(n['m_Level'],n['m_Type'],n['m_Name'],0,0,m_MetaFlag=n['m_MetaFlag'])for n in nodes]);census=json.loads((W/'gameplay-complex-2026-10-27/EMPTY-ROOT-COMPONENT-DATA-CENSUS.json').read_bytes());targets=[r for r in census['leads']if r['owner']=='Zombie'];assert len(targets)==26
with zipfile.ZipFile(ROOT/'GodsPVZ_1.0.2.zip')as z:raw=z.read(next(n for n in z.namelist()if n.endswith('/resources.assets')))
assert sha(raw)=='b84c445e60b52b446ae1989557541b3206a518ffc9ea64d8abd1d2a3d8472317'
env=UnityPy.load(raw);objects={o.path_id:o for o in env.objects};rows=[];values={};gaps=[]
for row in targets:
 try:
  obj=objects[row['original_component']];b=obj.get_raw_data();assert sha(b)==row['original_component_sha256'];reader=EndianBinaryReader(b,endian='<');decoded=H.read_typetree(tree,reader,byte_size=len(b),check_read=True);writer=EndianBinaryWriter(endian='<');H.write_typetree(decoded,tree,writer);assert writer.bytes==b
  fields=[k for k in decoded if not k.startswith('m_')];assert len(fields)==115;values[row['resource']]=decoded
  rows.append(dict(resource=row['resource'],original_component=obj.path_id,original_component_bytes=len(b),original_component_sha256=sha(b),source_path=row['captured_source'],original_game_fields=115,original_ID=decoded['ID'],original_health=decoded['healthPoint'],original_speed=decoded['rSpeed'],original_animation_group=decoded['animationGroup'],byte_exact_round_trip=True))
 except Exception as e:gaps.append(dict(resource=row['resource'],status='UNMODELED_NO_REPAIR',error=repr(e)))
result=dict(scope='ORIGINAL_ZOMBIE_SERIALIZED_DATA_READ_ONLY_NOT_REPAIR_OR_BEHAVIOR_PASS',candidate_field_metadata_sha256=census['candidate_sha256'],original_resources_sha256=sha(raw),schema_adaptations=changes,original_root_targets=26,byte_exact_round_trip_components=len(rows),decoded_field_entries=sum(r['original_game_fields']for r in rows),rows=rows,unmodeled=gaps,project_changed=False,game_dll_changed=False,qualified_methods_added=0)
for name,data in [('ZOMBIE-TYPE-TREE-ADAPTED.json',nodes),('ORIGINAL-ZOMBIE-FIELD-CENSUS.json',result),('ORIGINAL-ZOMBIE-SERIALIZED-VALUES.json',values)]:
 (G/name).write_bytes((json.dumps(data,indent=2,ensure_ascii=False)+'\n').encode())
print(json.dumps({k:v for k,v in result.items()if k not in ['schema_adaptations','rows','unmodeled']}));print('UNMODELED',gaps)
