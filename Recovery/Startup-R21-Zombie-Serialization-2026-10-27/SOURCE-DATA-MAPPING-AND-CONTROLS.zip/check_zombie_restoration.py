"""Check the new Zombie source overlay composes with the nine Plant restores.
All operations use a new ordinary copy of the earlier isolated source fixture.
"""
from pathlib import Path
import copy,json,re,shutil,sys
G=Path(__file__).resolve().parent;W=G.parent;ROOT=W.parents[1];sys.path[:0]=[str(ROOT/'audit/repo-native113/scripts/actions'),str(W/'tool-deps')]
import yaml
from restore_startup_r21_zombie_fields import patch,restore,sha
plan_path=G/'ORIGINAL-ZOMBIE-BINDING-PLAN.json';plan=json.loads(plan_path.read_bytes());project=G/'composed-source-check';assert not project.exists();shutil.copytree(W/'gameplay-complex-2026-10-27/source-restoration-check-v2',project);before={row['source_path']:(project/row['source_path']).read_bytes()for row in plan['plans']}
restore(project,plan_path,G/'composed-source-check-output')
def compare(expected,actual,path):
 if isinstance(expected,dict):assert isinstance(actual,dict)and set(expected)==set(actual),(path,'keys');[compare(v,actual[k],path+'.'+k)for k,v in expected.items()]
 elif isinstance(expected,list):assert isinstance(actual,list)and len(expected)==len(actual),(path,'array');[compare(v,actual[i],path+'['+str(i)+']')for i,v in enumerate(expected)]
 elif isinstance(expected,(int,float)):assert float(expected)==float(actual),(path,expected,actual)
 elif expected is None:assert actual in [None,'null'],(path,expected,actual)
 else:assert expected==actual,(path,expected,actual)
for row in plan['plans']:
 text=(project/row['source_path']).read_bytes().decode();heads=list(re.finditer(r'(?m)^--- !u!(\d+) &(-?\d+)[^\r\n]*\r?$',text));i=next(i for i,h in enumerate(heads)if int(h[2])==row['source_owner']);d=yaml.load(text[heads[i].end():heads[i+1].start()if i+1<len(heads)else len(text)],Loader=yaml.BaseLoader)['MonoBehaviour'];compare(row['fields'],{k:v for k,v in d.items()if not k.startswith('m_')},row['resource'])
controls=[];row=plan['plans'][0];data=before[row['source_path']]
for name,change in [('wrong_owner',lambda r:r.update(source_owner=1)),('wrong_owner_hash',lambda r:r.update(source_owner_body_sha256='0'*64)),('missing_original_field',lambda r:r['fields'].pop('ID'))]:
 bad=copy.deepcopy(row);change(bad)
 try:patch(data,bad);raise AssertionError('Bad source accepted: '+name)
 except ValueError as e:controls.append(dict(name=name,gate='OWNER_BOUNDARY',rejected=True,error=str(e)))
for name,change in [('changed_original_ID',lambda p:p['plans'][0]['fields'].update(ID=999)),('changed_original_speed',lambda p:p['plans'][0]['fields']['rSpeed'].update(x=9999)),('discard_original_foreign_animator',lambda p:next(r for r in p['plans']if r['resource'].endswith('imperialvanguardharbinger'))['fields'].update(animator=dict(fileID=0)))]:
 bad=copy.deepcopy(plan);change(bad);path=G/('UNQUALIFIED-'+name+'.json');path.write_bytes((json.dumps(bad,indent=2)+'\n').encode());output=G/('must-not-create-'+name)
 try:restore(project,path,output);raise AssertionError('Unreviewed plan accepted: '+name)
 except ValueError as e:assert not output.exists();controls.append(dict(name=name,gate='IMMUTABLE_ORIGINAL_PLAN_HASH',rejected=True,error=str(e)))
plant_plan=json.loads((W/'gameplay-complex-2026-10-27/ORIGINAL-PLANT-BINDING-PLAN.json').read_bytes());plant_parent=W/'gameplay-complex-2026-10-27/source-restoration-check-v2';assert all((project/r['source_path']).read_bytes()==(plant_parent/r['source_path']).read_bytes()for r in plant_plan['plans'])
result=dict(scope='COPIED_SOURCE_26_ZOMBIE_RESTORATION_AND_COMPOSITION_WITH_NINE_PLANTS_NOT_UNITY_OR_GAMEPLAY',restored_zombie_prefabs=26,restored_zombie_fields=2990,original_plant_prefabs_preserved=9,original_plant_fields_preserved=846,combined_source_fields=3836,parsed_values_match_original_plan=True,original_cross_prefab_animator_preserved=True,controls=controls,candidate_sha256=sha((project/'Assets/Plugins/GodsPVZRuntime1.dll').read_bytes()),plan_sha256=sha(plan_path.read_bytes()),unity_started=False,game_dll_changed=False,qualified_methods_added=0)
(G/'SOURCE-RESTORATION-CHECK.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result))
