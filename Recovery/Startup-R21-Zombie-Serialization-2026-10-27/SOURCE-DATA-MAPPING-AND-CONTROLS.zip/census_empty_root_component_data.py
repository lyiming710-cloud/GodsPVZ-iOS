"""Read-only lead census: original root script has bytes, captured YAML has none.
No component bodies/fields are guessed, patched, or promoted by this census.
"""
from pathlib import Path
import collections,hashlib,json,re,struct,sys,zipfile
G=Path(__file__).resolve().parent;W=G.parent;ROOT=W.parents[1];sys.path[:0]=[str(W/'python-deps'),str(W/'tool-deps'),str(ROOT/'audit/stage9-native3/python-deps')]
import UnityPy,yaml,dnfile
sha=lambda b:hashlib.sha256(b).hexdigest()

def md4(data):
 data+=b'\x80'+b'\0'*((55-len(data))%64)+struct.pack('<Q',len(data)*8);state=[0x67452301,0xefcdab89,0x98badcfe,0x10325476]
 def rol(x,n):x&=0xffffffff;return ((x<<n)|(x>>(32-n)))&0xffffffff
 for at in range(0,len(data),64):
  words=struct.unpack('<16I',data[at:at+64]);v=state[:]
  for round_id in range(3):
   order=list(range(16))if round_id==0 else [j+4*i for j in range(4)for i in range(4)]if round_id==1 else[0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15]
   shifts=([3,7,11,19],[3,5,9,13],[3,9,11,15])[round_id]
   for i,k in enumerate(order):
    a=(-i)%4;b=(a+1)%4;c=(a+2)%4;d=(a+3)%4
    f=(v[b]&v[c])|(~v[b]&v[d])if round_id==0 else(v[b]&v[c])|(v[b]&v[d])|(v[c]&v[d])if round_id==1 else v[b]^v[c]^v[d]
    v[a]=rol(v[a]+f+words[k]+(0,0x5a827999,0x6ed9eba1)[round_id],shifts[i%4])
  state=[(a+b)&0xffffffff for a,b in zip(state,v)]
 return struct.pack('<4I',*state)

assert md4(b'').hex()=='31d6cfe0d16ae931b73c59d7e0c089c0'
assert md4(b'abc').hex()=='a448017aaf21d8525fc10ae87aa6729d'
fileid=lambda ns,name:int.from_bytes(md4(b's\0\0\0'+ns.encode()+name.encode())[:4],'little',signed=True)
assert fileid('','Plant')==313814881 and fileid('','Almanac_ZombieWindow')==-1828062448
candidate=W/'startup-r21-ui-batch100/authored1.dll';assert sha(candidate.read_bytes())=='75160a3233f1e1ab13a44f712efb4b47fdeb9b57bd38fa25f180276bb7b50e15'
pe=dnfile.dnPE(str(candidate));identities={};nested={r.NestedClass.row_index for r in pe.net.mdtables.NestedClass.rows}
for rid,t in enumerate(pe.net.mdtables.TypeDef.rows,1):
 if rid in nested:continue
 name,ns=str(t.TypeName),str(t.TypeNamespace);fid=fileid(ns,name);full=(ns+'.'if ns else'')+name
 assert fid not in identities;identities[fid]=full
source=zipfile.ZipFile(next((W/'r21-source-run-40368892424').rglob('r21-source-prefabs-scenes-audio-metadata.zip')));source_paths={n[len('Assets/Resources/'):-7].lower():n for n in source.namelist()if n.startswith('Assets/Resources/')and n.endswith('.prefab')}
with zipfile.ZipFile(ROOT/'GodsPVZ_1.0.2.zip')as z:raw=z.read(next(n for n in z.namelist()if n.endswith('/resources.assets')));gs=z.read(next(n for n in z.namelist()if n.endswith('/globalgamemanagers.assets')))
env=UnityPy.load(raw);objects={o.path_id:o for o in env.objects};scripts={o.path_id:o.read_typetree()for o in UnityPy.load(gs).objects if o.type.name=='MonoScript'};catalog=json.loads((W/'r21-device-interaction-2026-10-26/PC-RESOURCE-CONTAINER.json').read_bytes());rows=[];gaps=[];seen=set()
for resource,ptr in catalog['m_Container']:
 key=resource.lower()
 if not key.startswith('prefabs/')or key not in source_paths or ptr['m_PathID']not in objects or objects[ptr['m_PathID']].type.name!='GameObject':continue
 try:
  text=source.read(source_paths[key]).decode();heads=list(re.finditer(r'(?m)^--- !u!(\d+) &(-?\d+)[^\r\n]*\r?$',text));docs={}
  for i,h in enumerate(heads):
   body=text[h.end():heads[i+1].start()if i+1<len(heads)else len(text)];d=yaml.load(body,Loader=yaml.BaseLoader);docs[int(h[2])]=dict(kind=int(h[1]),body=next(iter(d.values())))
  transforms=[d['body']for d in docs.values()if d['kind']in[4,224]and int(d['body']['m_Father']['fileID'])==0];assert len(transforms)==1;source_root=int(transforms[0]['m_GameObject']['fileID']);source_owners=collections.defaultdict(list)
  for d in docs.values():
   if d['kind']!=114 or int(d['body']['m_GameObject']['fileID'])!=source_root:continue
   s=d['body']['m_Script']
   if s.get('guid')=='60b84a767c46ced9aacc93f38da4d2f3':source_owners[identities[int(s['fileID'])]].append(d['body'])
  go=objects[ptr['m_PathID']].read_typetree();ordinals=collections.Counter()
  for c in go['m_Component']:
   o=objects[c['component']['m_PathID']]
   if o.type.name!='MonoBehaviour':continue
   h=o.read_typetree(check_read=False);s=h['m_Script']
   if s['m_FileID']!=1 or s['m_PathID']not in scripts:continue
   script=scripts[s['m_PathID']];name=(script['m_Namespace']+'.'if script['m_Namespace']else'')+script['m_ClassName']
   if name not in source_owners:continue
   ordinal=ordinals[name];ordinals[name]+=1;assert ordinal<len(source_owners[name]);owner=source_owners[name][ordinal];fields=[k for k in owner if not k.startswith('m_')];base_size=32+((len(h['m_Name'].encode())+3)//4)*4
   identity=(o.path_id,source_paths[key],name,ordinal)
   if identity in seen:continue
   seen.add(identity);b=o.get_raw_data();rows.append(dict(resource=resource,owner=name,ordinal=ordinal,original_component=o.path_id,original_bytes=len(b),original_base_header_bytes=base_size,original_custom_bytes=len(b)-base_size,original_component_sha256=sha(b),captured_source=source_paths[key],source_game_field_count=len(fields),source_game_fields=fields,classification='MISSING_ALL_GAME_FIELDS_SOURCE_LEAD'if len(b)>base_size and not fields else'NOT_AN_EMPTY_GAME_BODY_LEAD'))
 except Exception as e:gaps.append(dict(resource=resource,error=repr(e)))
leads=[r for r in rows if r['classification']=='MISSING_ALL_GAME_FIELDS_SOURCE_LEAD'];result=dict(scope='READ_ONLY_ROOT_COMPONENT_DATA_LOSS_LEADS_NOT_TYPED_REPAIR_OR_GAMEPLAY_BUG_COUNT',candidate_sha256=sha(candidate.read_bytes()),original_resources_sha256=sha(raw),script_id_controls='RFC1320 empty/abc and actual Plant/Almanac_ZombieWindow IDs pass',matched_root_components=len(rows),missing_all_field_leads=len(leads),lead_counts_by_class=dict(collections.Counter(r['owner']for r in leads)),leads=leads,all_rows=rows,gaps=gaps,source_or_game_changed=False,qualified_methods_added=0)
(G/'EMPTY-ROOT-COMPONENT-DATA-CENSUS.json').write_bytes((json.dumps(result,indent=2,ensure_ascii=False)+'\n').encode());print(json.dumps({k:v for k,v in result.items()if k not in ['leads','all_rows','gaps']}));print('GAPS',len(gaps))
