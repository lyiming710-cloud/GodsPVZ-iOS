"""Source plan only. Bind original Zombie PPtrs by hierarchy, class and ordinal."""
from pathlib import Path
import ast,collections,hashlib,json,re,struct,sys,traceback,zipfile
G=Path(__file__).resolve().parent;W=G.parent;ROOT=W.parents[1];sys.path[:0]=[str(W/'python-deps'),str(W/'tool-deps'),str(ROOT/'audit/stage9-native3/python-deps')]
import UnityPy,yaml,dnfile
sha=lambda b:hashlib.sha256(b).hexdigest()
# Reuse only the independently controlled public metadata ID hash function.
source_code=W/'gameplay-complex-2026-10-27/census_empty_root_component_data.py';module=ast.parse(source_code.read_bytes());function=next(n for n in module.body if isinstance(n,ast.FunctionDef)and n.name=='md4');exec(compile(ast.Module(body=[function],type_ignores=[]),str(source_code),'exec'))
assert md4(b'').hex()=='31d6cfe0d16ae931b73c59d7e0c089c0';assert md4(b'abc').hex()=='a448017aaf21d8525fc10ae87aa6729d'
fileid=lambda ns,name:int.from_bytes(md4(b's\0\0\0'+ns.encode()+name.encode())[:4],'little',signed=True)
assert fileid('','Plant')==313814881 and fileid('','Almanac_ZombieWindow')==-1828062448
candidate=W/'startup-r21-ui-batch100/authored1.dll';assert sha(candidate.read_bytes())=='75160a3233f1e1ab13a44f712efb4b47fdeb9b57bd38fa25f180276bb7b50e15';pe=dnfile.dnPE(str(candidate));nested={r.NestedClass.row_index for r in pe.net.mdtables.NestedClass.rows};classes={}
for rid,t in enumerate(pe.net.mdtables.TypeDef.rows,1):
 if rid in nested:continue
 ns,name=str(t.TypeNamespace),str(t.TypeName);fid=fileid(ns,name);assert fid not in classes;classes[fid]=(ns+'.'if ns else'')+name
zombie_fileid=fileid('','Zombie');census=json.loads((G/'ORIGINAL-ZOMBIE-FIELD-CENSUS.json').read_bytes());values=json.loads((G/'ORIGINAL-ZOMBIE-SERIALIZED-VALUES.json').read_bytes());assert len(census['rows'])==26
source_zip=next((W/'r21-source-run-40368892424').rglob('r21-source-prefabs-scenes-audio-metadata.zip'));assert sha(source_zip.read_bytes())=='a3186d405f1776ddf55be91069641df3538da8ce50b49084b230c5b990ab8f7f';source=zipfile.ZipFile(source_zip)
with zipfile.ZipFile(ROOT/'GodsPVZ_1.0.2.zip')as z:raw=z.read(next(n for n in z.namelist()if n.endswith('/resources.assets')));gs=z.read(next(n for n in z.namelist()if n.endswith('/globalgamemanagers.assets')))
env=UnityPy.load(raw);objects={o.path_id:o for o in env.objects};scripts={o.path_id:o.read_typetree()for o in UnityPy.load(gs).objects if o.type.name=='MonoScript'}
catalog=json.loads((W/'r21-device-interaction-2026-10-26/PC-RESOURCE-CONTAINER.json').read_bytes());source_paths={n[len('Assets/Resources/'):-7].lower():n for n in source.namelist()if n.startswith('Assets/Resources/')and n.endswith('.prefab')}

def add(mapping,key,value):mapping[key]=value if key not in mapping else None

def original_graph(root):
 forward={};reverse={}
 def walk(gid,path):
  go=objects[gid].read_typetree();key=(path,'GameObject',0);add(forward,key,gid);reverse[gid]=key;counts=collections.Counter();transform=None
  for c in go['m_Component']:
   pid=c['component']['m_PathID'];o=objects[pid];h=o.read_typetree(check_read=False);kind=o.type.name
   if kind=='MonoBehaviour':
    p=h['m_Script']
    if p['m_FileID']==1 and p['m_PathID']in scripts:s=scripts[p['m_PathID']];kind=(s['m_Namespace']+'.'if s['m_Namespace']else'')+s['m_ClassName']
    else:kind='UNRESOLVED_AUXILIARY_SCRIPT:'+str((p['m_FileID'],p['m_PathID']))
   key=(path,kind,counts[kind]);counts[kind]+=1;add(forward,key,pid);reverse[pid]=key
   if kind in ['Transform','RectTransform']:transform=h
  assert transform is not None
  for c in transform['m_Children']:
   tid=c['m_PathID'];child=objects[tid].read_typetree()['m_GameObject']['m_PathID'];name=objects[child].read_typetree()['m_Name'];walk(child,(path+'/'if path else'')+name)
 walk(root,'');return forward,reverse

def parse_source(data):
 text=data.decode();heads=list(re.finditer(r'(?m)^--- !u!(\d+) &(-?\d+)[^\r\n]*\r?$',text));docs={}
 for i,h in enumerate(heads):
  body=text[h.end():heads[i+1].start()if i+1<len(heads)else len(text)];d=yaml.load(body,Loader=yaml.BaseLoader);assert len(d)==1;docs[int(h[2])]=dict(kind=int(h[1]),data=next(iter(d.values())),body=body)
 return docs

def source_graph(docs):
 result={};transforms={i:d['data']for i,d in docs.items()if d['kind']in[4,224]};roots=[i for i,d in transforms.items()if int(d['m_Father']['fileID'])==0];assert len(roots)==1;kindnames={k.value:k.name for k in UnityPy.enums.ClassIDType}
 def walk(tid,path):
  t=transforms[tid];gid=int(t['m_GameObject']['fileID']);go=docs[gid]['data'];add(result,(path,'GameObject',0),gid);counts=collections.Counter()
  for c in go['m_Component']:
   anchor=int(c['component']['fileID']);doc=docs[anchor];kind=kindnames[doc['kind']]
   if doc['kind']==114:
    p=doc['data']['m_Script'];kind=classes.get(int(p['fileID']),'UNOBSERVED_GAME_SCRIPT')if p.get('guid')=='60b84a767c46ced9aacc93f38da4d2f3'else'UNOBSERVED_PACKAGE_SCRIPT:'+str((p.get('guid'),p['fileID']))
   key=(path,kind,counts[kind]);counts[kind]+=1;add(result,key,anchor)
  for p in t['m_Children']or[]:
   child=int(p['fileID']);g=docs[int(transforms[child]['m_GameObject']['fileID'])]['data'];walk(child,(path+'/'if path else'')+g['m_Name'])
 walk(roots[0],'');return result

def cross_prefab_reference(pid):
 obj=objects[pid];header=obj.read_typetree(check_read=False);gid=pid if obj.type.name=='GameObject'else header['m_GameObject']['m_PathID'];chain=[];seen=set()
 while True:
  assert gid not in seen;seen.add(gid);go=objects[gid].read_typetree();chain.append(dict(path_id=gid,name=go['m_Name']));transform=next(objects[c['component']['m_PathID']].read_typetree()for c in go['m_Component']if objects[c['component']['m_PathID']].type.name in['Transform','RectTransform']);parent=transform['m_Father'];assert parent['m_FileID']==0
  if not parent['m_PathID']:break
  p=objects[parent['m_PathID']].read_typetree()['m_GameObject'];assert p['m_FileID']==0;gid=p['m_PathID']
 resources={source_paths[n.lower()]:n for n,p in catalog['m_Container']if n.lower().startswith('prefabs/')and n.lower()in source_paths and p['m_FileID']==4 and p['m_PathID']==gid};assert len(resources)==1,('CROSS_PREFAB_ROOT_NOT_UNIQUE',pid,resources);target_path=next(iter(resources));data=source.read(target_path);docs=parse_source(data);old,reverse=original_graph(gid);current=source_graph(docs);key=reverse[pid];assert old[key]is not None and current.get(key)is not None,('CROSS_PREFAB_TARGET_NOT_PROVED',pid,key);meta=source.read(target_path+'.meta');m=re.findall(rb'(?m)^guid: ([0-9a-f]{32})\r?$',meta);assert len(m)==1
 return dict(original_path_id=pid,target_class=key[1],relative_path=key[0],component_ordinal=key[2],source_local_file_id=current[key],source_guid=m[0].decode(),target_source_path=target_path,target_captured_prefab_sha256=sha(data),target_meta_sha256=sha(meta),original_parent_chain=chain,original_cross_prefab_reference_preserved=True)

plans=[];gaps=[]
for row in census['rows']:
 try:
  resource=row['resource'];decoded=values[resource];data=source.read(row['source_path']);docs=parse_source(data);current=source_graph(docs);old,reverse=original_graph(decoded['m_GameObject']['m_PathID']);key=('', 'Zombie',0);assert key in current and current[key]is not None;owner=current[key];body=docs[owner]['body'];assert not[k for k in docs[owner]['data']if not k.startswith('m_')];bindings=[]
  def convert(value,path):
   if isinstance(value,dict):
    if set(value)=={'m_FileID','m_PathID'}:
     assert value['m_FileID']==0 or not value['m_PathID'],('EXTERNAL_REFERENCE',path,value)
     if not value['m_PathID']:return dict(fileID=0)
     target=value['m_PathID']
     if target not in reverse:
      proof=cross_prefab_reference(target);bindings.append(dict(field=path,**proof));return dict(fileID=proof['source_local_file_id'],guid=proof['source_guid'],type=3)
     identity=reverse[target];assert old[identity]is not None and current.get(identity)is not None,('AMBIGUOUS_OR_UNPROVED_TARGET',path,identity);anchor=current[identity];bindings.append(dict(field=path,original_path_id=target,relative_path=identity[0],target_class=identity[1],component_ordinal=identity[2],source_local_file_id=anchor));return dict(fileID=anchor)
    return {k:convert(v,path+'.'+k)for k,v in value.items()}
   if isinstance(value,list):return[convert(v,path+'['+str(i)+']')for i,v in enumerate(value)]
   return value
  fields={k:convert(v,k)for k,v in decoded.items()if not k.startswith('m_')};assert len(fields)==115;meta=source.read(row['source_path']+'.meta');guid=re.findall(rb'(?m)^guid: ([0-9a-f]{32})\r?$',meta);assert len(guid)==1
  plans.append(dict(resource=resource,source_path=row['source_path'],captured_prefab_sha256=sha(data),source_owner=owner,source_guid=guid[0].decode(),source_meta_sha256=sha(meta),source_owner_body_sha256=sha(body.encode()),original_component=row['original_component'],original_component_sha256=row['original_component_sha256'],original_field_count=115,fields=fields,reference_bindings=bindings))
 except Exception as e:gaps.append(dict(resource=row['resource'],status='QUARANTINED_NO_REPAIR',error=repr(e),trace=traceback.format_exc()))
result=dict(scope='SOURCE_PLAN_ONLY_115_ORIGINAL_FIELDS_PER_PROVED_ZOMBIE_OWNER_NOT_GAMEPLAY_PASS',candidate_sha256=sha(candidate.read_bytes()),original_resources_sha256=sha(raw),source_capture_sha256=sha(source_zip.read_bytes()),metadata_script_id_function_sha256=sha(ast.get_source_segment(source_code.read_text('utf-8'),function).encode()),metadata_script_id_controls='RFC1320 empty/abc plus actual Plant and Almanac_ZombieWindow IDs',owner_type='Zombie',owner_script_file_id=zombie_fileid,planned_prefabs=len(plans),planned_field_entries=sum(p['original_field_count']for p in plans),plans=plans,quarantined=gaps,project_changed=False,game_dll_changed=False)
(G/'ORIGINAL-ZOMBIE-BINDING-PLAN.json').write_bytes((json.dumps(result,indent=2,ensure_ascii=False)+'\n').encode());print(json.dumps({k:v for k,v in result.items()if k not in['plans','quarantined']}));print(json.dumps([dict(resource=r['resource'],error=r['error'])for r in gaps]))
