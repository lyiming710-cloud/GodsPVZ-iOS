"""Corrupt copies of an actual successful resource observation, not game input.
These are readback-validator controls and are not physical behavior controls.
"""
from pathlib import Path
import copy,importlib.util,json
G=Path(__file__).resolve().parent;W=G.parent;ROOT=W.parents[1];script=ROOT/'audit/repo-native113/scripts/actions/verify_startup_r21_resource_values.py';spec=importlib.util.spec_from_file_location('r21_actual_values_guard',script);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
plan=m.fixed(G/'ORIGINAL-PLANT-BINDING-PLAN.json',m.PLANT);registry=m.fixed(G/'PLANT-SOURCE-IDENTITIES.json',m.IDENTITIES);guids={r['source_path']:r['guid']for r in registry['entries']};targets=[('Plant',r,guids[r['source_path']])for r in plan['plans']];path=W/'r21-gameplay-retry-run-40404766623/editor/r21-serialization-reimport-probe.json';actual=json.loads(path.read_bytes());baseline=m.verify(actual,targets);assert baseline['all_actual_fields_match_original']and baseline['actual_resource_routes']==18
controls=[]
for name in ['wrong_original_ID','null_animation_group','wrong_sprite_guid','wrong_owner_identity']:
 damaged=copy.deepcopy(actual);row=next(r for r in damaged['objects']if r['phase']=='after-force-import'and r['route']=='Resources'and r['type']=='Plant'and r['path'].lower().endswith('/peasniper.prefab'));fields=json.loads(row['editor_json']);body=fields.get('MonoBehaviour',fields)
 if name=='wrong_original_ID':body['ID']=999
 elif name=='null_animation_group':body['animationGroup']=dict(instanceID=0)
 elif name=='wrong_sprite_guid':assert body['UISprites1'][0]['fileID']!=0;body['UISprites1'][0]['guid']='0'*32
 else:row['identity']=row['identity'].replace(' guid=',' guid=unreviewed')
 row['editor_json']=json.dumps(fields);r=m.verify(damaged,targets);assert not r['all_actual_fields_match_original']and r['failed_leaf_checks']>0;controls.append(dict(name=name,rejected=True,gate='ACTUAL_RESOURCE_READBACK_VALIDATOR_ONLY',failed_leaf_checks=r['failed_leaf_checks']))
old_path=W/'r21-reimport-run-40374543207/editor/r21-serialization-reimport-probe.json';old=m.verify(json.loads(old_path.read_bytes()),targets);assert not old['all_actual_fields_match_original']and old['failed_leaf_checks']>0
report=dict(scope='ACTUAL_RESOURCE_READBACK_VALIDATOR_CONTROLS_NOT_GAMEPLAY_TESTS',real_successful_probe_sha256=m.sha(path.read_bytes()),actual_routes=18,actual_leaf_checks_passed=baseline['passed_leaf_checks'],corruption_controls=controls,real_historical_bad_probe_sha256=m.sha(old_path.read_bytes()),real_historical_bad_leaf_failures=old['failed_leaf_checks'],game_or_observation_inputs_changed=False,gameplay_proven=False)
(G/'ACTUAL-READBACK-GUARD-CONTROLS.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(report))
