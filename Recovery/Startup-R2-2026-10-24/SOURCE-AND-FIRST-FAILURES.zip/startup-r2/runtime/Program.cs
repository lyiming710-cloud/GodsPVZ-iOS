using System.Reflection;
using System.Reflection.Emit;
using System.Security.Cryptography;
using System.Text.Json;
using MC = Mono.Cecil;
using CIL = Mono.Cecil.Cil;

// Separate top-level owners retain real CLR private-member boundaries.
public class ObjectState { public bool Alive; public string Id = ""; }
public sealed class BoardState : ObjectState;

public static class Program
{
    public static readonly List<string> Trace = [];
    public static Action? FirstTruthHook;
    public static bool Truth(ObjectState? value)
    {
        Trace.Add("Truth:" + (value?.Id ?? "null"));
        bool result = value?.Alive ?? false;
        var callback = FirstTruthHook; FirstTruthHook = null; callback?.Invoke();
        return result;
    }
    static void Need(bool test, string why) { if (!test) throw new InvalidOperationException(why); }
    static readonly Dictionary<string, OpCode> Ops = typeof(OpCodes).GetFields(BindingFlags.Public | BindingFlags.Static)
        .Where(f => f.FieldType == typeof(OpCode)).Select(f => (OpCode)f.GetValue(null)!).ToDictionary(op => op.Name!);
    static Type Map(MC.TypeReference t, Type manager) => t.FullName switch {
        "System.Void" => typeof(void), "System.Boolean" => typeof(bool), "System.Object" => typeof(object),
        "System.Int32" => typeof(int), "System.IntPtr" => typeof(nint), "System.NullReferenceException" => typeof(NullReferenceException),
        "BoardManager" => manager, "Board" => typeof(BoardState),
        "UnityEngine.Object" => typeof(ObjectState), _ => throw new NotSupportedException(t.FullName)
    };
    static void Copy(MC.MethodDefinition method, ILGenerator il, Type manager, Dictionary<int,MethodInfo> copied, Dictionary<string,FieldInfo> fields)
    {
        Need(method.Body.ExceptionHandlers.Count == 0, "No exception handlers may be silently omitted");
        var locals = method.Body.Variables.Select(v => il.DeclareLocal(Map(v.VariableType,manager))).ToArray();
        var labels = method.Body.Instructions.ToDictionary(i => i, _ => il.DefineLabel());
        foreach (var i in method.Body.Instructions)
        {
            il.MarkLabel(labels[i]); var op = Ops[i.OpCode.Name];
            switch (i.Operand)
            {
                case null: il.Emit(op); break;
                case CIL.Instruction target: il.Emit(op, labels[target]); break;
                case CIL.VariableDefinition local: il.Emit(op, locals[local.Index]); break;
                case MC.ParameterDefinition p: il.Emit(op, (short)(p.Index + (method.HasThis ? 1 : 0))); break;
                case int n: il.Emit(op, n); break;
                case MC.FieldReference f:
                    Need(f.DeclaringType.FullName == "BoardManager", "Unexpected private-field owner");
                    string name = f.Name == "<Instance>k__BackingField" ? "instance" : f.Name == "board" ? "board" : throw new NotSupportedException(f.FullName);
                    il.Emit(op, fields[name]); break;
                case MC.MethodReference m:
                    if (m.DeclaringType.FullName == "UnityEngine.Object" && m.Name == "op_Implicit")
                        il.Emit(op, typeof(Program).GetMethod(nameof(Truth))!);
                    else if (m.DeclaringType.FullName == "System.NullReferenceException" && m.Name == ".ctor")
                        il.Emit(op, typeof(NullReferenceException).GetConstructor(Type.EmptyTypes)!);
                    else if (copied.TryGetValue(m.MetadataToken.ToInt32(), out var callee)) il.Emit(op, callee);
                    else throw new NotSupportedException(m.FullName);
                    break;
                default: throw new NotSupportedException(i.ToString());
            }
        }
    }
    sealed record Bound(Type ManagerType, Func<bool> Invoke, Action<ObjectState?> Install);
    static Bound Bind(MC.ModuleDefinition module, bool nullBoardGetter = false)
    {
        // Actual emitted classes retain the private field access checks.
        // A DynamicMethod(skipVisibility:false) falsely accepted the old CIL
        // on this CLR; that failed control is preserved rather than waived.
        var assembly=AssemblyBuilder.DefineDynamicAssembly(new AssemblyName("StartupCIL_"+Guid.NewGuid().ToString("N")),AssemblyBuilderAccess.Run);
        var dynamicModule=assembly.DefineDynamicModule("GameCIL");
        var manager=dynamicModule.DefineType("Rehosted.BoardManager",TypeAttributes.Public|TypeAttributes.Sealed,typeof(ObjectState));
        var global=dynamicModule.DefineType("Rehosted.GlobalStaticVars",TypeAttributes.Public|TypeAttributes.Sealed|TypeAttributes.Abstract);
        var fields=new Dictionary<string,FieldInfo> {
            ["instance"]=manager.DefineField("instance",manager,FieldAttributes.Private|FieldAttributes.Static),
            ["board"]=manager.DefineField("board",typeof(BoardState),FieldAttributes.Private)
        };
        var ctor=manager.DefineConstructor(MethodAttributes.Public,CallingConventions.Standard,[typeof(BoardState)]);
        var ci=ctor.GetILGenerator();ci.Emit(OpCodes.Ldarg_0);ci.Emit(OpCodes.Call,typeof(ObjectState).GetConstructor(Type.EmptyTypes)!);ci.Emit(OpCodes.Ldarg_0);ci.Emit(OpCodes.Ldarg_1);ci.Emit(OpCodes.Stfld,fields["board"]);ci.Emit(OpCodes.Ret);
        var install=manager.DefineMethod("Install",MethodAttributes.Public|MethodAttributes.Static,typeof(void),[manager]);
        var si=install.GetILGenerator();si.Emit(OpCodes.Ldarg_0);si.Emit(OpCodes.Stsfld,fields["instance"]);si.Emit(OpCodes.Ret);
        var copied = new Dictionary<int,MethodInfo>();
        foreach (int token in new[] { 0x06000169, 0x0600016F })
        {
            var method = (MC.MethodDefinition)module.LookupToken(token);
            var built=manager.DefineMethod(method.Name,MethodAttributes.Public|(method.IsStatic?MethodAttributes.Static:0),Map(method.ReturnType,manager),Type.EmptyTypes);
            built.InitLocals=method.Body.InitLocals;
            if (nullBoardGetter && token == 0x0600016F)
            {
                // Explicit type-correct semantic mutant, never written to DLL.
                var il = built.GetILGenerator(); il.Emit(OpCodes.Ldnull); il.Emit(OpCodes.Ret);
            }
            else Copy(method,built.GetILGenerator(),manager,copied,fields);
            copied[token]=built;
        }
        var caller=(MC.MethodDefinition)module.LookupToken(0x06000146);
        var call=global.DefineMethod("IsOnBoard",MethodAttributes.Public|MethodAttributes.Static,typeof(bool),Type.EmptyTypes);
        call.InitLocals=caller.Body.InitLocals;Copy(caller,call.GetILGenerator(),manager,copied,fields);
        var managerType=manager.CreateType()!;var globalType=global.CreateType()!;
        var invoke=(Func<bool>)globalType.GetMethod("IsOnBoard")!.CreateDelegate(typeof(Func<bool>));
        var installer=managerType.GetMethod("Install")!;
        return new Bound(managerType,invoke,value=>installer.Invoke(null,[value]));
    }
    static ObjectState Manager(Bound bound, bool alive, int boardKind, string suffix = "")
    {
        var board=boardKind<0?null:new BoardState {Alive=boardKind>0,Id="board"+suffix};
        var value=(ObjectState)Activator.CreateInstance(bound.ManagerType,[board])!;value.Alive=alive;value.Id="manager"+suffix;return value;
    }
    public static void Main(string[] args)
    {
        Need(args.Length == 3, "candidate.dll parent.dll report.json");
        byte[] bytes = File.ReadAllBytes(args[0]);
        Need(Convert.ToHexString(SHA256.HashData(bytes)).Equals("81815f178e1de70e1e2e5088afd856bb5292801c3ccdc1ffc60b9c24ba223823", StringComparison.OrdinalIgnoreCase), "Exact R2 input");
        using var module = MC.ModuleDefinition.ReadModule(args[0]);
        var bound=Bind(module);var invoke = bound.Invoke; var rows = new List<object>(); int assertions = 0;
        for (int kind = -1; kind <= 1; kind++)
        foreach (bool alive in new[] { false, true })
        {
            var manager = Manager(bound,alive, kind); bound.Install(manager); Trace.Clear(); FirstTruthHook = null;
            bool result = invoke(); Need(result == (alive && kind > 0), "Unity truthiness includes destroyed and null boards"); assertions++;
            var expectedTrace = alive ? new[] { "Truth:manager", kind < 0 ? "Truth:null" : "Truth:board" } : new[] { "Truth:manager" };
            Need(Trace.SequenceEqual(expectedTrace), "Original truthiness call order/short circuit"); assertions++;
            rows.Add(new { kind = "normal", manager_alive = alive, board_kind = kind, result, trace = Trace.ToArray() });
        }
        bound.Install(null); Trace.Clear(); Need(!invoke() && Trace.SequenceEqual(new[] { "Truth:null" }), "Null singleton short circuit"); assertions++;
        rows.Add(new { kind = "null_manager", result = false, trace = Trace.ToArray() });
        foreach (int kind in new[] { -1, 0, 1 })
        {
            bound.Install(Manager(bound,true, 1)); var replacement = Manager(bound,true, kind, "2");
            Trace.Clear(); FirstTruthHook = () => bound.Install(replacement);
            bool result = invoke(); Need(result == (kind > 0) && Trace.SequenceEqual(new[] { "Truth:manager", kind < 0 ? "Truth:null" : "Truth:board2" }), "Reload singleton after the controlled truthiness callback"); assertions++;
            rows.Add(new { kind = "replace_after_first_truth", board_kind = kind, result, trace = Trace.ToArray() });
        }
        bound.Install(Manager(bound,true,1)); Trace.Clear(); FirstTruthHook=()=>bound.Install(null);
        bool nullThrow = false; try { invoke(); } catch (NullReferenceException) { nullThrow = true; }
        Need(nullThrow, "Preserve explicit null failure after callback replacement"); assertions++;
        var controls = new List<object>();
        using (var parent = MC.ModuleDefinition.ReadModule(args[1]))
        {
            bool rejected = false;
            try { var old = Bind(parent); old.Install(Manager(old,true,1)); old.Invoke(); }
            catch (FieldAccessException) { rejected = true; }
            catch (MethodAccessException) { rejected = true; }
            Need(rejected, "Old private-field body must fail with visibility checks enabled");
            controls.Add(new { name="actual_parent_private_field_CIL",rejected });
        }
        var missing = Bind(module,true); missing.Install(Manager(missing,true,1)); Trace.Clear(); FirstTruthHook=null;
        bool wrong = missing.Invoke(); Need(!wrong,"Null-board getter mutant must lose the live-board result");
        controls.Add(new { name="type_correct_getter_returns_null", rejected=wrong!=true });
        using (var mutant = MC.ModuleDefinition.ReadModule(args[0]))
        {
            var m = (MC.MethodDefinition)mutant.LookupToken(0x06000146);
            var one = m.Body.Instructions.Single(i=>i.OpCode.Code==CIL.Code.Ldc_I4 && (int)i.Operand==1);
            one.Operand=0;
            var bad=Bind(mutant);bad.Install(Manager(bad,true,1));Trace.Clear();FirstTruthHook=null;
            bool result=bad.Invoke();Need(!result,"Wrong successful return mutant must fail positive input");
            controls.Add(new { name="type_correct_successful_return_zero",rejected=result!=true });
        }
        var report = new { scope="ACTUAL_THREE_METHOD_CIL_REHOSTED_IN_CONCRETE_CLASSES_WITH_CONTROLLED_UNITY_TRUTHINESS_ONLY", status="PASS_SCOPED_FIXTURE", candidate_sha256=Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant(), runtime=Environment.Version.ToString(), access_check_override=false, earlier_dynamic_method_false_accept_preserved=true, source_methods=new[]{"0x06000146","0x06000169","0x0600016F"}, normal_and_callback_cases=rows.Count, assertions, callback_null_exception_preserved=nullThrow, negative_controls=controls, cases=rows, unity_engine_executed=false, native_exception_unwind_modeled=false, device_execution=false, full_game_behavior_proven=false };
        File.WriteAllText(args[2],JsonSerializer.Serialize(report,new JsonSerializerOptions{WriteIndented=true}));
        Console.WriteLine(JsonSerializer.Serialize(new { report.status,report.normal_and_callback_cases,report.assertions,negative_controls=controls.Count,report.scope }));
    }
}
