"""Run the unchanged frozen stack checker over the actual new-method CIL."""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess

Q = Path(__file__).resolve().parent
R = Q.parents[2]
DOT = R / '.local/dotnet10/dotnet.exe'
EXPORT = R / 'audit/bulk250-r1-evidence-39702928368/bulk250-r1-run/tools_bin/CilExporter/bin/CilExporter.dll'
SUPPORT = R / 'audit/bulk350-root-verification-2026-10-22/authentic-support'
report = json.loads((Q/'construction1.json').read_text('utf-8-sig'))
tokens = sorted({s['token'] for s in report['site_changes']})
p = subprocess.run([str(DOT),str(EXPORT),str(Q/'candidate1.dll'),str(Q/'NEW-40-CIL.json'),str(SUPPORT),','.join(tokens)],capture_output=True,text=True)
(Q/'cil-export.log').write_text(p.stdout+p.stderr,encoding='utf-8')
if p.returncode:raise RuntimeError('CIL export failed: '+str(p.returncode))
f = R / 'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py'
checker_sha=hashlib.sha256(f.read_bytes()).hexdigest()
assert checker_sha=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14'
s=importlib.util.spec_from_file_location('frozen',f);v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
j=json.loads((Q/'NEW-40-CIL.json').read_text('utf-8-sig'));results=[]
for m in j['methods']:
    try:result=v.verify(m,j['types'])
    except Exception as e:result={'token':m['token'],'status':'FAIL_OR_UNSUPPORTED','error':str(e)}
    results.append(result)
output={'scope':'UNCHANGED_FROZEN_STACK_CHECKER_NOT_RUNTIME_OR_GAMEPLAY_ACCEPTANCE','checker_sha256':checker_sha,'candidate_sha256':report['candidate_sha256'],'total':len(results),'passed':sum(x.get('status')=='PASS' for x in results),'results':results,'first_45_method_failures_retained':'../startup-r1/FROZEN-STACK-FLOW.json'}
(Q/'FROZEN-STACK-FLOW.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in output.items() if k!='results'}))
assert output['total']==output['passed']==40
