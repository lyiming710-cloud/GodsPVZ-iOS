"""Construct Startup R1 from the immutable Bulk401 DLL.

Only 83 fixed-width field reads and 111 original SerializeField attributes
change. All algorithms, field visibility, type flags, method identities,
locals, MaxStack, branch/EH offsets and previous 401 bodies are preserved.
"""
from pathlib import Path
import collections
import hashlib
import json
import struct
import sys

W = Path(__file__).resolve().parent.parent
ROOT = W.parents[1]
sys.path.insert(0, str(ROOT / "audit/stage9-native3/python-deps"))
sys.path.insert(0, str(ROOT / "audit/bulk388-qualification-2026-10-23/width-check"))
import dnfile
from width_fixtures import SC, width

PARENT_SHA = "6de4db6c94b80a43876aea060b573ed60c1fa7170cff485103d2c808b94762ae"
ATTR_PLAN_SHA = "e85d5580843f06ad157d7a75b8eb9539b8f8c8b31b370af5f43cef8a1f43e29e"
ACCESS_PLAN_SHA = "05c7cc983d87488dc864e1399265237f0b3b77000e33173ca645edf6074a4de9"

def sha(b): return hashlib.sha256(b).hexdigest()
def align(n, a): return (n + a - 1) // a * a
def need(ok, message):
    if not ok: raise ValueError(message)

def checked_json(name, expected):
    data = (W / name).read_bytes()
    need(sha(data) == expected, "Evidence identity: " + name)
    return json.loads(data.decode("utf-8-sig"))

def tables_decode(data):
    flags = data[6]
    valid = struct.unpack_from("<Q", data, 8)[0]
    at = 24
    counts = {}
    for t in range(64):
        if valid >> t & 1:
            counts[t] = struct.unpack_from("<I", data, at)[0]; at += 4
    header = data[:at]
    rows = {}
    for t, count in counts.items():
        need(t in SC, "Unsupported metadata table")
        rows[t] = []
        for _ in range(count):
            row = []
            for col in SC[t]:
                n = width(col, flags, counts)
                row.append(int.from_bytes(data[at:at+n], "little")); at += n
            rows[t].append(row)
    return header, rows, data[at:], counts

def tables_encode(header, rows, tail, counts):
    old_counts = dict(counts)
    counts = {t: len(r) for t, r in rows.items()}
    flags = header[6]
    for t in counts:
        for col in SC[t]:
            need(width(col, flags, old_counts) == width(col, flags, counts), "New index width requires a separate reviewed encoder")
    result = bytearray(header[:24])
    for count in counts.values(): result.extend(struct.pack("<I", count))
    for t, values in rows.items():
        for row in values:
            for col, value in zip(SC[t], row): result.extend(value.to_bytes(width(col, flags, counts), "little"))
    return bytes(result) + tail

def metadata_root(data):
    need(data[:4] == b"BSJB", "CLR metadata signature")
    version_size = struct.unpack_from("<I", data, 12)[0]
    at = align(16 + version_size, 4)
    count = struct.unpack_from("<H", data, at+2)[0]; at += 4
    streams = []
    for _ in range(count):
        off, size = struct.unpack_from("<II", data, at)
        end = data.index(0, at+8)
        name = data[at+8:end].decode("ascii")
        need(off+size <= len(data), "Bounded metadata stream")
        streams.append((name, at, data[off:off+size])); at = align(end+1, 4)
    return data[:at], streams

def construct(parent, output, report_path):
    parent = Path(parent).resolve(); output = Path(output).resolve(); report_path = Path(report_path).resolve()
    need(len({parent, output, report_path}) == 3 and not output.exists() and not report_path.exists(), "Fresh distinct output paths")
    before = parent.read_bytes()
    need(len(before) == 17563648 and sha(before) == PARENT_SHA, "Exact Bulk401 parent required")
    a = checked_json("ORIGINAL-ATTRIBUTE-ROSTERS.json", ATTR_PLAN_SHA)
    q = checked_json("PRIVATE-ACCESS-CLASSIFICATION.json", ACCESS_PLAN_SHA)
    need(a["candidate_sha256"] == q["input_sha256"] == PARENT_SHA, "Evidence parent binding")
    sf = [r for r in a["serialize_field_targets"] if not r["already_has_serialize_field"]]
    sites = q["proposed_sites"]
    need(len(sf) == 111 and len(sites) == 83 and len({s["token"] for s in sites}) == 45, "Explicit restoration scope")
    pe = dnfile.dnPE(data=before)
    old = bytearray(before)
    changed = []
    for s in sites:
        method = pe.net.mdtables.MethodDef.rows[(int(s["token"],16) & 0xFFFFFF)-1]
        need(str(method.Name) != ".ctor", "Do not rewrite constructor initialization by a getter rule")
        at = pe.get_offset_from_rva(method.Rva)
        head = 1 if before[at] & 3 == 2 else (struct.unpack_from("<H",before,at)[0] >> 12)*4
        il = int(s["offset"][3:],16)
        loc = at + head + il
        need(before[loc] == {"ldfld":0x7B,"ldsfld":0x7E}[s["op"]], "Exact field opcode")
        field_token = struct.unpack_from("<I", before, loc+1)[0]
        need(field_token == int(s["field_token"],16), "This fork only changes direct nongeneric FieldDef reads")
        getter = int(s["getter"]["method_token"],16)
        gm = pe.net.mdtables.MethodDef.rows[(getter & 0xFFFFFF)-1]
        need(gm.Flags.mdPublic and not gm.Flags.mdVirtual, "Public direct getter only")
        replacement = b"\x28" + struct.pack("<I",getter)
        need(loc+5 <= len(before), "Bounded replacement")
        old[loc:loc+5] = replacement
        changed.append({**s,"file_offset":loc,"before_hex":before[loc:loc+5].hex(),"after_hex":replacement.hex()})
    need(len({s["file_offset"] for s in changed}) == len(sites), "Unique fixed-width sites")

    cli = pe.get_offset_from_rva(pe.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress)
    meta_rva, meta_size = struct.unpack_from("<II",before,cli+8)
    meta_at = pe.get_offset_from_rva(meta_rva)
    root_header, streams = metadata_root(before[meta_at:meta_at+meta_size])
    values = {n:b for n, _, b in streams}
    table_header, rows, tail, counts = tables_decode(values["#~"])
    need(counts[12] == 19, "Pinned original CustomAttribute rows")
    need(all(r.Type.row_index == 475 and r.Type.table.name == "MemberRef" and r.Value.value == bytes.fromhex("01000000") for r in pe.net.mdtables.CustomAttribute.rows), "Existing SerializeField constructor/value")
    need(str(pe.net.mdtables.MemberRef.rows[474].Class.row.TypeName) == "SerializeField", "Exact attribute ctor owner")
    need(pe.net.mdtables.MemberRef.rows[474].Signature.value == bytes.fromhex("200001"), "Parameterless instance void ctor")
    old_ca = list(rows[12])
    ctor, blob = old_ca[0][1:]
    need(ctor == (475 << 3 | 3), "CustomAttributeType MemberRef tag")
    for r in sf:
        token = int(r["token"],16)
        need(token >> 24 == 4, "Field token required")
        field = pe.net.mdtables.Field.rows[(token & 0xFFFFFF)-1]
        need(str(field.Name) == r["field"]["name"], "Original field identity")
        need(not field.Flags.fdStatic and not field.Flags.fdLiteral, "Instance serialization field")
        rows[12].append([((token & 0xFFFFFF) << 5) | 1, ctor, blob])
    rows[12].sort(key=lambda r:r[0])
    need(len(rows[12]) == 130 and len({r[0] for r in rows[12]}) == 130, "Original 130-field marker set, no duplicates")
    values["#~"] = tables_encode(table_header, rows, tail, counts)
    # Preserve every stream name/version/header byte except its offset/size;
    # existing heaps are reused byte-for-byte, including the marker blob.
    new_meta = bytearray(root_header)
    for name, header_at, _ in streams:
        start = align(len(new_meta),4); new_meta.extend(b"\0"*(start-len(new_meta)))
        struct.pack_into("<II",new_meta,header_at,start,len(values[name])); new_meta.extend(values[name])
    last = pe.sections[-1]
    need(last.Name.rstrip(b"\0") == b".n29meta" and last.Characteristics == 0x40000040, "Original readonly append section")
    need(last.PointerToRawData + last.SizeOfRawData == len(before) and last.Misc_VirtualSize <= last.SizeOfRawData, "No overwritten overlay or virtual tail")
    new_at = align(len(old),4)
    old.extend(b"\0"*(new_at-len(old))); old.extend(new_meta)
    end = len(old); new_raw_size = align(end-last.PointerToRawData,pe.OPTIONAL_HEADER.FileAlignment)
    old.extend(b"\0"*(last.PointerToRawData+new_raw_size-len(old)))
    sh = last.get_file_offset(); opt = pe.OPTIONAL_HEADER.get_file_offset()
    updates = {
        sh+8:end-last.PointerToRawData,
        sh+16:new_raw_size,
        opt+8:pe.OPTIONAL_HEADER.SizeOfInitializedData+new_raw_size-last.SizeOfRawData,
        opt+56:align(last.VirtualAddress+end-last.PointerToRawData,pe.OPTIONAL_HEADER.SectionAlignment),
        opt+64:0,
        cli+8:last.VirtualAddress+new_at-last.PointerToRawData,
        cli+12:len(new_meta),
    }
    for at,value in updates.items(): struct.pack_into("<I",old,at,value)
    allowed = {loc+i for loc in updates for i in range(4)} | {s["file_offset"]+i for s in changed for i in range(5)}
    need(all(x==y or i in allowed for i,(x,y) in enumerate(zip(before,old))), "Exact original-prefix mutation boundary")
    result = {"status":"CONSTRUCTED_NOT_RUNTIME_QUALIFIED", "parent_sha256":PARENT_SHA,"candidate_sha256":sha(old),"parent_bytes":len(before),"candidate_bytes":len(old),"fixed_width_read_sites":len(changed),"new_body_targets":len({s['token'] for s in changed}),"cumulative_body_targets":446,"restored_serialize_field_markers":111,"total_original_serialize_field_markers":130,"old_custom_attribute_rows_preserved_as_values":True,"custom_attribute_rows_sorted_by_parent":True,"new_memberrefs":0,"field_and_type_visibility_changed":False,"locals_branches_eh_changed":False,"site_changes":changed,"metadata": {"appended_root_offset":new_at,"appended_root_bytes":len(new_meta),"attribute_plan_sha256":ATTR_PLAN_SHA,"access_plan_sha256":ACCESS_PLAN_SHA},"unrepaired_private_field_sites":q['held_sites'],"device_acceptance":False}
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open("xb") as f:f.write(old)
    with report_path.open("x",encoding="utf-8") as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write("\n")
    print(json.dumps({k:v for k,v in result.items() if k not in ("site_changes","unrepaired_private_field_sites")}))
    return result

if __name__ == "__main__":
    need(len(sys.argv)==4,"Usage: construct.py bulk401.dll fresh-startup-r1.dll fresh-report.json")
    construct(*sys.argv[1:])
