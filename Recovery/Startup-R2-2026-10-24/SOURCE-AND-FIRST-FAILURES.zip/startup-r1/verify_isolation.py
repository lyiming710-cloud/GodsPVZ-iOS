"""Independent reopened binary audit. Does not import the constructor.

Original marker membership is re-read from global-metadata.dat, not accepted
from the construction report. Raw CLI/PE readers and dnfile both reopen bytes.
"""
from pathlib import Path
import collections
import copy
import hashlib
import importlib.util
import json
import struct
import sys

Q = Path(__file__).resolve().parent
W = Q.parent
ROOT = W.parents[1]
sys.dont_write_bytecode = True
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
sys.path.insert(0,str(ROOT/'audit/bulk388-qualification-2026-10-23/width-check'))
import dnfile
from width_fixtures import SC, width
f = ROOT/'audit/native111-publication-2026-10-20/repository/scripts/actions/static_gates.py'
spec = importlib.util.spec_from_file_location('independent_raw',f)
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
sha = lambda b: hashlib.sha256(b).hexdigest()

def need(value,message):
    if not value: raise ValueError(message)

before=(ROOT/'audit/bulk400-generic-repair-2026-10-24/candidates/candidate1.dll').read_bytes()
need(sha(before)=='6de4db6c94b80a43876aea060b573ed60c1fa7170cff485103d2c808b94762ae','Parent identity')
access_bytes=(W/'PRIVATE-ACCESS-CLASSIFICATION.json').read_bytes()
need(sha(access_bytes)=='05c7cc983d87488dc864e1399265237f0b3b77000e33173ca645edf6074a4de9','Reviewed access map')
plan=json.loads(access_bytes.decode('utf-8-sig'))['proposed_sites']
targets={int(s['token'],16) for s in plan}
prior=json.loads((ROOT/'audit/bulk400-generic-repair-2026-10-24/all-targets.json').read_text('utf-8-sig'))
prior_targets={int(m['token'],16) for m in prior['methods']}
need(len(targets)==45 and len(prior_targets)==401 and not targets & prior_targets,'Disjoint method scope')

def metadata(data):
    pe=h.parse_pe_and_cli(data)
    return pe,h.parse_metadata_root(data,pe['meta_off'],pe['meta_size']),dnfile.dnPE(data=data)

pp,pm,pd=metadata(before)
def decode(data):
    flags=data[6];mask=struct.unpack_from('<Q',data,8)[0];at=24;counts={}
    for t in range(64):
        if mask>>t&1:counts[t]=struct.unpack_from('<I',data,at)[0];at+=4
    rows={}
    for t,n in counts.items():
        rows[t]=[]
        for _ in range(n):
            r=[]
            for col in SC[t]:
                size=width(col,flags,counts);r.append(int.from_bytes(data[at:at+size],'little'));at+=size
            rows[t].append(r)
    return rows,data[at:]

old_rows,old_tail=decode(pm['streams']['#~']['bytes'])
original=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/global-metadata.dat').read_bytes()
need(sha(original)=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9','Original metadata identity')
need(struct.unpack_from('<II',original)==(0xFAB11BAF,31),'Metadata version')
get=lambda at:struct.unpack_from('<I',original,at)[0]
strings=get(24)
def string(index):return original[strings+index:original.index(0,strings+index)].decode('utf-8')
types=get(160);methods=get(48);ctor=methods+36*37158
owner=types+88*get(ctor+4)
need(string(get(owner))=='SerializeField' and string(get(owner+4))=='UnityEngine' and string(get(ctor))=='.ctor' and struct.unpack_from('<H',original,ctor+34)[0]==0,'Original parameterless marker constructor')
image_start,image_size=struct.unpack_from('<II',original,168)
images=[struct.unpack_from('<10I',original,at) for at in range(image_start,image_start+image_size,40)]
image=next(row for row in images if string(row[0])=='Assembly-CSharp.dll')
attribute_data=get(200);ranges=get(208);sf=set()
for ix in range(image[8],image[8]+image[9]):
    token,start=struct.unpack_from('<II',original,ranges+8*ix)
    count=original[attribute_data+start]
    need(count<128,'Bounded small constructor count')
    ctor_ids=struct.unpack_from('<'+'I'*count,original,attribute_data+start+1)
    if 37158 in ctor_ids:
        need(token>>24==4,'SerializeField belongs to a field');sf.add(token)
need(len(sf)==130,'Original marker census')

def raw_body(data,pe,row):
    at=pe.get_offset_from_rva(row.Rva)
    span=h.parse_raw_method_body_span(data,at)
    return data[at:at+span[0]],at

expected={}
site_ranges=set()
for s in plan:
    tok=int(s['token'],16);row=pd.net.mdtables.MethodDef.rows[(tok&0xFFFFFF)-1]
    body,at=raw_body(before,pd,row)
    if tok not in expected:expected[tok]=bytearray(body)
    header=1 if body[0]&3==2 else (struct.unpack_from('<H',body)[0]>>12)*4
    offset=header+int(s['offset'][3:],16)
    need(body[offset] in (0x7B,0x7E) and struct.unpack_from('<I',body,offset+1)[0]==int(s['field_token'],16),'Independently pinned original field read')
    expected[tok][offset:offset+5]=bytes([0x28])+struct.pack('<I',int(s['getter']['method_token'],16))
    site_ranges.update(range(at+offset,at+offset+5))

def audit(data):
    cp,cm,cd=metadata(data)
    need(cm['streams'].keys()==pm['streams'].keys(),'Metadata stream set')
    need(cm['heap_sizes']==pm['heap_sizes'] and cm['valid_mask']==pm['valid_mask'] and cm['sorted_mask']==pm['sorted_mask'],'Original metadata encoding flags')
    for name in ['#GUID','#Strings','#US','#Blob']:
        need(cm['streams'][name]['bytes']==pm['streams'][name]['bytes'],'Byte-identical original heap '+name)
    rows,tail=decode(cm['streams']['#~']['bytes'])
    need(tail==old_tail and rows.keys()==old_rows.keys(),'Tables and trailing bytes')
    for t,r in old_rows.items():
        if t!=12:need(rows[t]==r,'Unchanged metadata table '+str(t))
    need(len(rows[12])==130 and len(rows[12])-len(old_rows[12])==111,'Marker row count')
    need([r[0] for r in rows[12]]==sorted(r[0] for r in rows[12]),'CustomAttribute sort order')
    need(all(collections.Counter(map(tuple,rows[12]))[tuple(r)]==1 for r in old_rows[12]),'Existing markers retained exactly once')
    markers=[]
    for r in cd.net.mdtables.CustomAttribute.rows:
        need(r.Parent.table.name=='Field' and r.Type.table.name=='MemberRef' and r.Type.row_index==475,'Exact field marker parent/ctor')
        need(r.Value.value==b'\x01\x00\x00\x00','Exact marker value')
        markers.append(0x04000000|r.Parent.row_index)
    need(len(set(markers))==130 and set(markers)==sf,'Exact original SerializeField membership')
    unchanged=changed=inherited=zero=0
    for rid,(old,new) in enumerate(zip(pd.net.mdtables.MethodDef.rows,cd.net.mdtables.MethodDef.rows),1):
        token=0x06000000|rid
        need(old.Rva==new.Rva,'Original RVA unchanged')
        if not old.Rva:zero+=1;unchanged+=1;continue
        ob,_=raw_body(before,pd,old);nb,_=raw_body(data,cd,new)
        if token in targets:need(nb==bytes(expected[token]),'Exact target body '+hex(token));changed+=1
        else:need(ob==nb,'Non-target raw body '+hex(token));unchanged+=1
        if token in prior_targets:need(ob==nb,'Inherited 401 body');inherited+=1
    need(changed==45 and inherited==401 and unchanged==2272 and zero==20,'Full method census')
    header_offsets=[pp['sections'][-1]['header_offset']+8,pp['sections'][-1]['header_offset']+16,pp['opt_off']+8,pp['opt_off']+56,pp['opt_off']+64,pp['cli_off']+8,pp['cli_off']+12]
    permitted=site_ranges|{at+i for at in header_offsets for i in range(4)}
    need(all(x==y or i in permitted for i,(x,y) in enumerate(zip(before,data))),'Whole original-prefix byte isolation')
    need(cp['meta_off']==len(before) and len(data)>len(before),'Metadata appended at original EOF')
    need(data[cp['meta_off']+cp['meta_size']:]==b'\0'*(len(data)-cp['meta_off']-cp['meta_size']),'Zero append padding only')
    return {'scope':'SCOPED_BYTE_AND_METADATA_ISOLATION_NOT_GAMEPLAY_QUALIFICATION','candidate_sha256':sha(data),'new_body_targets':changed,'unchanged_methods_against_bulk401':unchanged,'zero_rva_methods':zero,'inherited_401_bodies_identical':inherited,'cumulative_body_targets':446,'cumulative_untargeted_methods_against_native93':1871,'original_serialize_field_markers':len(markers),'restored_marker_rows':111,'other_tables_and_heaps_unchanged':True,'field_visibility_unchanged':True,'device_execution':False}

if __name__=='__main__':
    candidate=(Q/'candidate1.dll').read_bytes()
    result=audit(candidate)
    need(candidate==(Q/'candidate2.dll').read_bytes(),'Deterministic reconstruction')
    controls=[]
    def reject(name,change):
        b=bytearray(candidate);change(b)
        try:audit(bytes(b))
        except Exception as e:controls.append({'name':name,'rejected':True,'reason':str(e)[:240]});return
        raise AssertionError('False accept: '+name)
    cp,cm,cd=metadata(candidate)
    first=plan[0];row=cd.net.mdtables.MethodDef.rows[(int(first['token'],16)&0xFFFFFF)-1];body,at=raw_body(candidate,cd,row)
    hs=1 if body[0]&3==2 else (struct.unpack_from('<H',body)[0]>>12)*4
    il=at+hs+int(first['offset'][3:],16)
    reject('wrong_getter_target',lambda b:struct.pack_into('<I',b,il+1,0x06000169 if int(first['getter']['method_token'],16)!=0x06000169 else 0x06000636))
    reject('skip_required_getter_call',lambda b:b.__setitem__(il,0x00))
    inherited_token=next(t for t in sorted(prior_targets) if cd.net.mdtables.MethodDef.rows[(t&0xFFFFFF)-1].Rva)
    ir=cd.net.mdtables.MethodDef.rows[(inherited_token&0xFFFFFF)-1];_,ia=raw_body(candidate,cd,ir)
    reject('inherited_body_header_mutation',lambda b:b.__setitem__(ia+2,b[ia+2]^1))
    fr=cd.net.mdtables.Field.rows[1].struct.get_file_offset()
    reject('private_field_made_public',lambda b:struct.pack_into('<H',b,fr,6))
    cr=cd.net.mdtables.CustomAttribute.rows[0].struct.get_file_offset()
    reject('marker_on_unproven_original_field',lambda b:struct.pack_into('<I',b,cr,(1<<5)|1))
    reject('original_metadata_slot_modified',lambda b:b.__setitem__(pp['meta_off'],0))
    result.update(status='PASS_SCOPED_ISOLATION_ONLY',deterministic=True,negative_controls=controls,full_game_semantics='UNPROVEN',remaining_private_field_sites=60)
    (Q/'ISOLATION.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result))
