"""Save source, first failures and scoped evidence without game promotion."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

W=Path(__file__).resolve().parent
R=W.parent/'repo-native113'
D=R/'Recovery/Startup-R2-2026-10-24'
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(path,value):path.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))

files={}
for name in ['inspect_original_attributes.py','classify_private_access.py','author_startup_r2_gate.py','save_startup_r2_checkpoint.py']:
    files['tools/'+name]=(W/name).read_bytes()
for name in ['Inspect.csproj','Program.cs']:
    files['read-only-cil/'+name]=(W/'read-only-cil'/name).read_bytes()
for name in ['ORIGINAL-ATTRIBUTE-ROSTERS.json','PRIVATE-ACCESS-CLASSIFICATION.json','READ-ONLY-STARTUP-CIL-EXPANDED.json']:
    files['evidence/'+name]=(W/name).read_bytes()
for sub in ['startup-r1','startup-r2']:
    for path in sorted((W/sub).iterdir()):
        if path.is_file() and path.suffix in ('.py','.json','.log'):
            files[sub+'/'+path.name]=path.read_bytes()
for path in sorted((W/'attribute-reader-source').iterdir()):
    if path.is_file():files['primary-reader-layout-reference/'+path.name]=path.read_bytes()
for name in ['bind_startup_r2_diagnostic.py','prepare_startup_r2_plugin.py','prepare_startup_r2_unity.py']:
    files['scripts/actions/'+name]=(R/'scripts/actions'/name).read_bytes()
for path in sorted((D/'ios-support/Assets/Editor').glob('*.cs')):
    files['ios-support/Assets/Editor/'+path.name]=path.read_bytes()
for name in ['startup-r2-editor-diagnostic.yml','startup-r2-editor-preflight.yml']:
    files['workflows/'+name]=(R/'.github/workflows'/name).read_bytes()
manifest=[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())]
files['ARCHIVE-MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(D/'SOURCE-AND-FIRST-FAILURES.zip','w',zipfile.ZIP_DEFLATED) as z:
    for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(D/'SOURCE-AND-FIRST-FAILURES.zip') as z:
    assert z.testzip() is None
    for row in manifest:assert sha(z.read(row['path']))==row['sha256']
first=(W/'startup-r1/candidate1.dll').read_bytes()
with zipfile.ZipFile(D/'FIRST-R1-CANDIDATE-TYPE-FLOW-FAILED.zip','w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('DIAGNOSTIC-ONLY-NOT-QUALIFIED-STARTUP-R1.dll',first)

(D/'.gitattributes').write_bytes(b'*.json -text whitespace=trailing-space,space-before-tab,cr-at-eol\n*.md -text whitespace=trailing-space,space-before-tab,cr-at-eol\n*.zip -text\n*.cs -text whitespace=trailing-space,space-before-tab,cr-at-eol\n')
(D/'README.md').write_bytes('''# Startup R2 - original field schema and legal getter calls

The previously delivered Bulk401 IPA failed user-observed iPad startup. It is preserved; this checkpoint does not replace or requalify it. R2 is an Editor diagnostic candidate, not an accepted game or IPA.

Candidate: `81815f178e1de70e1e2e5088afd856bb5292801c3ccdc1ffc60b9c24ba223823`, 17,996,800 bytes. Parent: exact Bulk401 `6de4db6c94b80a43876aea060b573ed60c1fa7170cff485103d2c808b94762ae`.

Original PC global-metadata.dat v31 contains 130 SerializeField markers in the Assembly-CSharp image; the parent retained 19. R2 restores exactly the 111 missing field markers using the existing parameterless UnityEngine.SerializeField constructor/value. Field/type flags and visibility are unchanged. All 319 original game type flags were separately compared and already match the PC metadata. Other original custom attributes have not been universally restored; the constructor census is preserved, including RequireComponent and other potentially relevant attributes.

The raw field census found 143 cross-type private-field access instructions in 56 methods outside the earlier 401-target scope. R2 replaces 66 read instructions in 40 methods with existing public pure field getters; candidate getter CIL and original PC machine code/field offsets are preserved in the source archive. Every replacement has the same five-byte size and stack effect. Branches, EH, MaxStack and local signatures remain unchanged. Writes, managed addresses, events, and generic calls needing more proof remain held. A reopened census is still required to record the exact residual distribution; the known residual site count is 77. This is not a whole-assembly access PASS.

The first R1 candidate changed 83 sites in 45 methods and passed scoped byte/metadata isolation, but the frozen type-flow checker rejected five pre-existing method bodies. Those five were not counted as passed or silently repaired: 06000009 Administrator.Start_关卡配置文件, 060002AD Board.Update_isWon, 060005E7 BuffUIController_Zombie.FixedUpdate, 060007B7/060007B8 TMP_TextEventCheck.OnEnable/OnDisable. Their first candidate, actual CIL and failure report are retained. R2 leaves those five method bodies exactly as in Bulk401 while their native-backed full recovery is queued.

R2 deterministic construction and independent reopened isolation pass. All 401 earlier target bodies and 2,277 direct non-target methods (including 20 zero-RVA methods) are byte-identical to Bulk401. The cumulative construction roster is 441 body targets, with 1,876 methods outside it; these counts are not 441 behavior-qualified methods. The unchanged frozen type checker passes 40/40 new targets. Six isolation mutants reject wrong getter calls, skipped calls, inherited-body changes, widened field visibility, invented markers and overwritten original metadata. Frozen checkers were not edited.

The new manual-only workflow `startup-r2-editor-diagnostic.yml` compiles the exact helper sources before seat acquisition, reconstructs the same pinned R3/B001 inputs, binds child provenance separately from parent compiler evidence, verifies all 130 markers through real Editor reflection, and executes normal MainMenu Play Mode. It reports actual Administrator/TextLink field bindings in addition to errors, frame advancement, main UI and Canvas creation. It contains no iOS export, Apple build or IPA packaging steps. A diagnostic success cannot become a compiler, Metal, gameplay, physical audio or device PASS.

Remaining: the held methods/access sites, original behavioral custom attributes, Shader Graphs/Brightness and Unlit/GameUnitShader, fresh child compilation/export when appropriate, and actual iPad startup/gameplay acceptance. Do not suppress exceptions, make fields public globally, substitute dummy shaders or inherit Bulk401 compiler success for this child.

STARTUP-R2-CANDIDATE.zip is the current diagnostic input. FIRST-R1-CANDIDATE-TYPE-FLOW-FAILED.zip is quarantined historical evidence. SOURCE-AND-FIRST-FAILURES.zip contains reproduction sources, full first failures, raw native getter evidence and all scoped reports. No new IPA exists in this checkpoint.
'''.encode('utf-8'))

status={'state':'PREPARED_FOR_EDITOR_DIAGNOSTIC_NOT_GAMEPLAY_OR_COMPILER_QUALIFIED','candidate_sha256':'81815f178e1de70e1e2e5088afd856bb5292801c3ccdc1ffc60b9c24ba223823','parent_sha256':'6de4db6c94b80a43876aea060b573ed60c1fa7170cff485103d2c808b94762ae','restored_original_markers':111,'new_target_methods':40,'fixed_width_read_sites':66,'cumulative_body_targets':441,'prior_401_bodies_unchanged':True,'first_stack_flow_failed_methods_quarantined':5,'remaining_private_field_sites':77,'editor_runtime':'PENDING','child_cpp_compilation':'NOT_EXECUTED','child_unity_ios_export':'NOT_EXECUTED','child_ipa':None,'device_execution':False}
if not (D/'CURRENT-RESULT.json').exists():save(D/'CURRENT-RESULT.json',status)
manifest=[]
for path in sorted(D.rglob('*')):
    if path.is_file() and path.name!='MANIFEST.json':
        data=path.read_bytes();manifest.append({'path':path.relative_to(D).as_posix(),'bytes':len(data),'sha256':sha(data)})
save(D/'MANIFEST.json',manifest)
print(json.dumps({'checkpoint':str(D),'files':len(manifest),'source_archive_bytes':(D/'SOURCE-AND-FIRST-FAILURES.zip').stat().st_size,'candidate_bytes':(D/'STARTUP-R2-CANDIDATE.zip').stat().st_size,'first_failed_candidate_sha256':sha(first)}))
