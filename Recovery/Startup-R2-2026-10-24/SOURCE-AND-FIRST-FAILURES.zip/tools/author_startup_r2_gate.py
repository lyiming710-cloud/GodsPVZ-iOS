"""Create a separate manual Editor diagnostic; no export, Xcode or IPA jobs."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import zipfile

W=Path(__file__).resolve().parent
R=W.parent/'repo-native113'
D=R/'Recovery/Startup-R2-2026-10-24'
D.mkdir(exist_ok=False)
PARENT='6de4db6c94b80a43876aea060b573ed60c1fa7170cff485103d2c808b94762ae'
CANDIDATE='81815f178e1de70e1e2e5088afd856bb5292801c3ccdc1ffc60b9c24ba223823'
src=R/'Recovery/iPad-Startup-2026-10-24/ios-support/Assets/Editor'
dst=D/'ios-support/Assets/Editor';dst.mkdir(parents=True)
for name in ['GodsPVZStartupAudit.cs','GodsPVZIOSBuild.cs','GodsPVZPackageReferenceMigrator.cs']:
    shutil.copyfile(src/name,dst/name)
code=(dst/'GodsPVZStartupAudit.cs').read_text('utf-8')
code=code.replace('[Serializable] public class Report\n', '[Serializable] public class OriginalMarkerField { public string name; }\n    [Serializable] public class OriginalMarkerRow { public string token; public OriginalMarkerField field; }\n    [Serializable] public class OriginalMarkerPlan { public OriginalMarkerRow[] serialize_field_targets; }\n    [Serializable] public class RuntimeBinding { public string owner, field, instance; public bool assigned; public int collection_count; }\n    [Serializable] public class Report\n')
code=code.replace('public int plugin_scripts, resolved_plugin_scripts,', 'public int original_serialization_markers;\n        public int plugin_scripts, resolved_plugin_scripts,')
code=code.replace('public string active_scene, audio_scope', 'public List<RuntimeBinding> restored_runtime_fields = new List<RuntimeBinding>();\n        public string active_scene, audio_scope')
anchor='            report.main_ui_components = UnityEngine.Object.FindObjectsOfType<MonoBehaviour>().Count(c => c != null && c.GetType().FullName == "MainUIController");'
assert code.count(anchor)==1
code=code.replace(anchor,anchor+'''
            foreach (var component in UnityEngine.Object.FindObjectsOfType<MonoBehaviour>().Where(c => c != null && c.isActiveAndEnabled))
            {
                string name = component.GetType().FullName;
                string[] fields = name == "Administrator" ? new[] { "mainSystem", "systems" } : name == "TextLink" ? new[] { "TMP_Text" } : new string[0];
                foreach (string fieldName in fields)
                {
                    var field = component.GetType().GetField(fieldName, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                    object value = field == null ? null : field.GetValue(component);
                    bool assigned = value is UnityEngine.Object ? (UnityEngine.Object)value != null : value != null;
                    var collection = value as System.Collections.ICollection;
                    report.restored_runtime_fields.Add(new RuntimeBinding { owner=name, field=fieldName, instance=component.name, assigned=assigned, collection_count=collection == null ? -1 : collection.Count });
                    if (!assigned) report.errors.Add("Restored serialized startup reference is null: " + name + "::" + fieldName);
                }
            }''')
anchor='            var runtime = AppDomain.CurrentDomain.GetAssemblies().Single(a => a.GetName().Name == "GodsPVZRuntime1");'
assert code.count(anchor)==1
code=code.replace(anchor,anchor+'''
            var markerPlan = JsonUtility.FromJson<OriginalMarkerPlan>(File.ReadAllText("Recovery/original-serialization-marker-proof.json"));
            if (markerPlan.serialize_field_targets == null || markerPlan.serialize_field_targets.Length != 130)
                throw new InvalidOperationException("Original 130-field marker proof required");
            foreach (var row in markerPlan.serialize_field_targets)
            {
                int token = Int32.Parse(row.token.Substring(2), System.Globalization.NumberStyles.HexNumber);
                var field = runtime.ManifestModule.ResolveField(token);
                if (field.Name != row.field.name || field.IsStatic || field.GetCustomAttributes(typeof(SerializeField), false).Length != 1)
                    throw new InvalidOperationException("Original field marker not restored: " + row.token);
                report.original_serialization_markers++;
            }
            int allMarkers = runtime.GetTypes().SelectMany(t => t.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly)).Count(f => f.IsDefined(typeof(SerializeField), false));
            if (allMarkers != 130) throw new InvalidOperationException("Unexpected original serialization marker set: " + allMarkers);''')
(dst/'GodsPVZStartupAudit.cs').write_bytes(code.replace('\r\n','\n').encode())
shutil.copyfile(R/'Recovery/iPad-Startup-2026-10-24/EMPTY-DYNAMIC-FONT-ATLAS-EVIDENCE.json',D/'EMPTY-DYNAMIC-FONT-ATLAS-EVIDENCE.json')
shutil.copyfile(W/'ORIGINAL-ATTRIBUTE-ROSTERS.json',D/'ORIGINAL-ATTRIBUTE-ROSTERS.json')
shutil.copyfile(W/'PRIVATE-ACCESS-CLASSIFICATION.json',D/'PRIVATE-ACCESS-CLASSIFICATION.json')
for name in ['ISOLATION.json','FROZEN-STACK-FLOW.json','construction1.json']:
    shutil.copyfile(W/'startup-r2'/name,D/name)
for base,other in [('prepare_bulk401_unity.py','prepare_startup_r2_unity.py'),('prepare_bulk401_startup.py','prepare_startup_r2_plugin.py')]:
    source=(R/'scripts/actions'/base).read_text('utf-8')
    assert source.count(PARENT)==1
    (R/'scripts/actions'/other).write_bytes(source.replace(PARENT,CANDIDATE).replace('\r\n','\n').encode())
candidate=(W/'startup-r2/candidate1.dll').read_bytes()
assert hashlib.sha256(candidate).hexdigest()==CANDIDATE
with zipfile.ZipFile(D/'STARTUP-R2-CANDIDATE.zip','w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('STARTUP-R2.dll',candidate)

old=(R/'.github/workflows/bulk401-startup-runtime-gate.yml').read_text('utf-8')
t=old.split('\n  build_ipa:')[0]
t=t[:t.index('      - name: Upload unsigned Xcode project archive')]
start=t.index('      - name: Export unsigned iOS Xcode project with bulk401 candidate')
end=t.index('      - name: Return Personal seat')
t=t[:start]+t[end:]
start=t.index('\n  apple_preflight:');end=t.index('\n  export:',start)
t=t[:start]+t[end:]
t=re.sub(r'\non:\n[\s\S]*?\npermissions:', '\non:\n  workflow_dispatch:\n\npermissions:',t,count=1)
t=t.replace(t.splitlines()[0],'name: Startup R2 original serialization and actual Editor startup diagnostic',1)
t=t.replace('group: bulk401-startup-real-ios-ipa','group: startup-r2-editor-diagnostic')
t=t.replace('needs: [conversion_binding, apple_preflight, editor_helper_preflight]','needs: [conversion_binding, editor_helper_preflight]')
t=t.replace('uses: ./.github/workflows/bulk401-startup-editor-preflight.yml','uses: ./.github/workflows/startup-r2-editor-preflight.yml')
t=t.replace('stage9-bulk401-ios','stage9-startup-r2')
t=t.replace('Stage9-bulk401-conversion-qualified','Startup-R2-PARENT-Bulk401-compiler-input')
t=t.replace('name: Bind exact compiler input; no semantic promotion','name: Bind immutable parent compiler input only; diagnostic child has no compiler promotion')
t=t.replace('name: Download same-run conversion-qualified bulk401 candidate','name: Download hash-qualified parent input; not child compiler qualification')
t=t.replace('name: Verify bulk401 candidate provenance and exact hash','name: Verify Bulk401 parent provenance and exact hash')
t=t.replace("TEST_DLL_SHA256: '"+PARENT+"'", "PARENT_DLL_SHA256: '"+PARENT+"'\n      TEST_DLL_SHA256: '"+CANDIDATE+"'")
t=t.replace('python3 - "$OUT" "$TEST_DLL_SHA256" "$GITHUB_SHA"', 'python3 - "$OUT" "$PARENT_DLL_SHA256" "$GITHUB_SHA"',1)
t=t.replace('Recovery/iPad-Startup-2026-10-24/','Recovery/Startup-R2-2026-10-24/')
t=t.replace('scripts/actions/prepare_bulk401_unity.py','scripts/actions/prepare_startup_r2_unity.py')
t=t.replace('scripts/actions/prepare_bulk401_startup.py','scripts/actions/prepare_startup_r2_plugin.py')
t=t.replace('name: Bulk401-STARTUP-UNITY-EVIDENCE','name: STARTUP-R2-EDITOR-DIAGNOSTIC-EVIDENCE')
anchor='      - name: Download exact cached R3 archive'
assert t.count(anchor)==1
insert='''      - name: Bind diagnostic child separately from parent compiler results
        shell: bash
        run: |
          set -euo pipefail
          python3 scripts/actions/bind_startup_r2_diagnostic.py --output "$RUNNER_TEMP/stage9-startup-r2" --source "$GITHUB_SHA"

'''
t=t.replace(anchor,insert+anchor)
anchor='          cp "$GITHUB_WORKSPACE/Recovery/Startup-R2-2026-10-24/EMPTY-DYNAMIC-FONT-ATLAS-EVIDENCE.json" "$PROJECT/Recovery/empty-dynamic-font-atlas-evidence.json"'
assert t.count(anchor)==1
t=t.replace(anchor,anchor+'\n          cp "$GITHUB_WORKSPACE/Recovery/Startup-R2-2026-10-24/ORIGINAL-ATTRIBUTE-ROSTERS.json" "$PROJECT/Recovery/original-serialization-marker-proof.json"')
assert 'inputs.audit_only' not in t and 'xcodebuild' not in t and 'ExportIOS' not in t and 'build_ipa:' not in t
(R/'.github/workflows/startup-r2-editor-diagnostic.yml').write_bytes((t.replace('\r\n','\n').rstrip()+'\n').encode())

t=(R/'.github/workflows/bulk401-startup-editor-preflight.yml').read_text('utf-8')
t=re.sub(r'\non:\n[\s\S]*?\npermissions:', '\non:\n  workflow_dispatch:\n  workflow_call:\n\npermissions:',t,count=1)
t=t.replace(t.splitlines()[0],'name: Startup R2 exact Editor helper compilation only',1)
t=t.replace('Recovery/iPad-Startup-2026-10-24/','Recovery/Startup-R2-2026-10-24/')
t=t.replace('Bulk389-EXACT-EDITOR-HELPER-PREFLIGHT','STARTUP-R2-EXACT-EDITOR-HELPER-PREFLIGHT')
(R/'.github/workflows/startup-r2-editor-preflight.yml').write_bytes((t.replace('\r\n','\n').rstrip()+'\n').encode())
print(json.dumps({'candidate_sha256':CANDIDATE,'workflow':'startup-r2-editor-diagnostic.yml','full_export_possible':False,'source_files':len(list(dst.iterdir()))}))
