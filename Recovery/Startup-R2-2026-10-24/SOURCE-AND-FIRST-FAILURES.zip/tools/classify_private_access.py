"""Classify the census and bind direct public getter replacements to PC code."""
from pathlib import Path
import collections
import hashlib
import json
import struct
import sys

W = Path(__file__).resolve().parent
I = W.parent / "offline-test-handoff-2026-10-14/payload/inputs"
sys.path.insert(0, str(W.parent / "stage9-native3/python-deps"))
import pefile
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

raw = (I / "original-pc/GameAssembly.dll").read_bytes()
assert hashlib.sha256(raw).hexdigest() == "9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d"
pe = pefile.PE(data=raw)
base = pe.OPTIONAL_HEADER.ImageBase
md = Cs(CS_ARCH_X86, CS_MODE_64)
report = json.loads((W / "READ-ONLY-STARTUP-CIL-EXPANDED.json").read_text("utf-8-sig"))
native_fields = {int(f["token"], 16): f for f in json.loads((I / "maps/native-fields.json").read_text("utf-8-sig")) if 5088 <= f["typeIndex"] < 5407}
methods = {m["token"]: m for t in report["all_type_metadata"] for m in t["methods"]}
accessors = {a["field_token"]: a for a in report["simple_public_field_getters"]}
evidence = []
for a in accessors.values():
    if a["declaring_type_is_generic"]:
        continue  # A shared generic pointer needs its own instantiation binding.
    rid = int(a["method_token"], 16) & 0xFFFFFF
    va = int.from_bytes(pe.get_data(0x181B82D60-base+(rid-1)*8, 8), "little")
    assert base <= va < base + pe.OPTIONAL_HEADER.SizeOfImage
    rf = next((e.struct for e in pe.DIRECTORY_ENTRY_EXCEPTION if e.struct.BeginAddress == va-base), None)
    # Leaf getters may have no .pdata entry; stop at the first RET, without
    # pretending that subsequent bytes belong to the function.
    candidate = pe.get_data(va-base, rf.EndAddress-rf.BeginAddress if rf else 256)
    ins = []
    for i in md.disasm(candidate, va):
        ins.append(i)
        if rf is None and i.mnemonic == "ret":
            break
    if rf is None:
        assert ins and ins[-1].mnemonic == "ret", a
        candidate = candidate[:ins[-1].address + ins[-1].size - va]
    field = native_fields[int(a["field_token"], 16)]
    evidence.append({**a, "native_va": f"0x{va:X}", "native_bytes": len(candidate), "native_sha256": hashlib.sha256(candidate).hexdigest(), "native_field": field, "has_pdata": rf is not None, "instructions": [{"va":f"0x{i.address:X}","op":i.mnemonic,"operands":i.op_str,"bytes":i.bytes.hex()} for i in ins]})

proposed = []
held = []
for s in report["private_field_sites"]:
    a = accessors.get(s["field_token"])
    reason = None
    if s["op"] not in ("ldfld", "ldsfld"): reason = "WRITE_OR_MANAGED_ADDRESS_REQUIRES_NATIVE_BODY_RECOVERY"
    elif a is None: reason = "NO_PURE_PUBLIC_GETTER"
    elif methods[s["token"]]["Name"] == ".ctor": reason = "CONSTRUCTOR_THIS_INITIALIZATION_REQUIRES_SEPARATE_PROOF"
    elif a["declaring_type_is_generic"]: reason = "GENERIC_ACCESSOR_REQUIRES_CLOSED_REFERENCE_AND_NATIVE_BINDING"
    if reason: held.append({**s,"reason":reason})
    else: proposed.append({**s,"getter":a})

output = {"scope":"PROPOSED_SAME_WIDTH_GETTER_CALL_REPAIRS_NOT_EXECUTED", "input_sha256":report["input_sha256"], "original_native_sha256":hashlib.sha256(raw).hexdigest(), "proposed_sites":proposed, "held_sites":held,"getter_native_evidence":evidence}
(W / "PRIVATE-ACCESS-CLASSIFICATION.json").write_text(json.dumps(output,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"proposed_sites":len(proposed),"proposed_methods":len({s['token'] for s in proposed}),"held_sites":len(held),"held_reasons":dict(collections.Counter(s['reason'] for s in held)),"native_getters":len(evidence)}))
for e in evidence:
    if any(s['getter']['method_token']==e['method_token'] for s in proposed):
        print(e['method_token'],e['method'],e['native_va'],'field_offset',e['native_field']['offset'],'; '.join(i['op']+' '+i['operands'] for i in e['instructions'])[:1500])
