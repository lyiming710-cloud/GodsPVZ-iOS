"""Read only v31 attribute constructor rosters, without guessing argument data.

Layout cross-check: Cpp2IL LibCpp2IL/Metadata/Il2CppCustomAttributeDataRange.cs
and Cpp2IL.Core/Utils/V29AttributeUtils.cs. Only the bounded constructor roster
is decoded here. Non-marker attribute arguments remain opaque and unmodified.
"""
from pathlib import Path
import hashlib
import json
import struct

W = Path(__file__).resolve().parent
I = W.parent / "offline-test-handoff-2026-10-14/payload/inputs"
b = (I / "original-pc/global-metadata.dat").read_bytes()
assert hashlib.sha256(b).hexdigest() == "ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9"
assert struct.unpack_from("<II", b) == (0xFAB11BAF, 31)

def section(at):
    start, size = struct.unpack_from("<II", b, at)
    assert start + size <= len(b)
    return start, size

so, ss = section(24)
mo, ms = section(48)
fo, fs = section(96)
io, ins = section(168)
ado, ads = section(200)
aro, ars = section(208)
assert ms % 36 == fs % 12 == ins % 40 == ars % 8 == 0

def string(index):
    assert 0 <= index < ss
    end = b.index(0, so + index, so + ss)
    return b[so + index:end].decode("utf-8")

types = json.loads((I / "maps/native-types.json").read_text("utf-8-sig"))
owners = {}
for t in types:
    for index in range(t["methodStart"], t["methodStart"] + t["methods"]):
        assert index not in owners
        owners[index] = t
images = []
for at in range(io, io + ins, 40):
    values = struct.unpack_from("<10I", b, at)
    images.append((string(values[0]), values))
name, image = next(x for x in images if x[0] == "Assembly-CSharp.dll")
game_types = types[image[2]:image[2] + image[3]]
fields = {}
for t in game_types:
    for ix in range(t["fieldStart"], t["fieldStart"] + t["fields"]):
        ni, ti, token = struct.unpack_from("<III", b, fo + 12 * ix)
        assert token not in fields
        fields[token] = {"owner": t["namespace"] + ("." if t["namespace"] else "") + t["name"], "owner_token": f"0x{int(t['token'], 16):08X}", "name": string(ni), "type_index": ti}

c = json.loads((W / "READ-ONLY-STARTUP-CIL-EXPANDED.json").read_text("utf-8-sig"))
current = {int(f["token"], 16): (t, f) for t in c["all_type_metadata"] for f in t["fields"]}
rows = []
sf = []
for ix in range(image[8], image[8] + image[9]):
    token, start = struct.unpack_from("<II", b, aro + 8 * ix)
    end = struct.unpack_from("<I", b, aro + 8 * (ix + 1) + 4)[0] if ix + 1 < ars // 8 else ads
    assert 0 <= start < end <= ads
    raw = b[ado + start:ado + end]
    count = raw[0]
    assert count < 128, "Unsupported compressed constructor count"
    assert 1 + 4 * count <= len(raw)
    ctors = []
    for index in struct.unpack_from("<" + "I" * count, raw, 1):
        assert 0 <= index < ms // 36 and index in owners
        owner = owners[index]
        method_name = string(struct.unpack_from("<I", b, mo + 36 * index)[0])
        assert method_name == ".ctor"
        ctors.append({"method_index": index, "type": owner["namespace"] + ("." if owner["namespace"] else "") + owner["name"], "method": method_name})
    row = {"token": f"0x{token:08X}", "range_index": ix, "data_offset": ado + start, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(), "raw_hex": raw.hex(), "constructors": ctors}
    if token in fields:
        row["field"] = fields[token]
    rows.append(row)
    if any(x["type"] == "UnityEngine.SerializeField" for x in ctors):
        assert token in fields and token in current
        t, f = current[token]
        assert f["Name"] == fields[token]["name"]
        # Nested name separators differ between global metadata and Cecil;
        # bind the owner token as well as the original field token/name.
        assert fields[token]["owner_token"] == t["token"]
        sf.append({**row, "candidate_owner": t["type"], "candidate_field_type": f["type"], "candidate_flags": f["attributes"], "already_has_serialize_field": "UnityEngine.SerializeField" in f["custom_attributes"]})

report = {
    "scope": "ORIGINAL_PC_V31_CUSTOM_ATTRIBUTE_CONSTRUCTOR_ROSTERS_ONLY",
    "metadata_sha256": hashlib.sha256(b).hexdigest(),
    "candidate_sha256": c["input_sha256"],
    "image": name,
    "image_type_start": image[2], "image_types": image[3],
    "attribute_range_start": image[8], "attribute_range_count": image[9],
    "constructor_type_counts": {},
    "serialize_field_targets": sf,
    "attribute_rosters": rows,
    "arguments_decoded": False,
    "candidate_modified": False,
}
for row in rows:
    for ctor in row["constructors"]:
        name = ctor["type"]
        report["constructor_type_counts"][name] = report["constructor_type_counts"].get(name, 0) + 1
(W / "ORIGINAL-ATTRIBUTE-ROSTERS.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"ranges": len(rows), "types": report["constructor_type_counts"], "original_serialize_field_targets": len(sf), "already_present": sum(x["already_has_serialize_field"] for x in sf), "startup_fields": [{"token": x['token'], "field": x['field'], "already_present": x['already_has_serialize_field']} for x in sf if x['candidate_owner'] in ['TextLink','Administrator','BoardManager']]}, ensure_ascii=True))
