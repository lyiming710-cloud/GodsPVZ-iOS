"""Record the rejected actual export and retain stricter diagnostics for one replay."""
from pathlib import Path
import json,re,subprocess,sys
sys.dont_write_bytecode=True
from archive_support import sha,js,pack,manifest
W=Path(__file__).resolve().parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113';Q=W/'r20-build-error4-forensics-2026-10-26';raw=W/'r20-full-build-run-40255311794';D=R/'Recovery/Startup-R20-Export-Error4-2026-10-26';F=R/'Recovery/Startup-R20-IPA-Build-2026-10-26';T=R/'Recovery/Startup-R20-Sites104-2026-10-26'
assert not D.exists();D.mkdir();(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text\n*.md -text\n*.zip -text\n*.yml -text\n')
gh=Path('C:/Program Files/GitHub CLI/gh.exe');cmd=[str(gh),'run','view','40255311794','--repo','lyiming710-cloud/GodsPVZ-iOS','--json','status,conclusion,headSha,jobs,url'];j=json.loads(subprocess.check_output(cmd));js(raw/'RUN.json',j)
assert j['headSha']=='8d9f91486d973c6d63e0a2fea145366060e05970' and j['status']=='completed' and j['conclusion']=='failure'
jobs={r['name']:r for r in j['jobs']};assert jobs['export']['conclusion']=='failure' and jobs['build_ipa']['conclusion']=='skipped'
e=raw/'editor-evidence';log=(e/'ios-export.log').read_text('utf-8',errors='replace');match=re.search(r'GodsPVZ iOS export summary: result=(\w+), errors=(\d+), warnings=(\d+), size=(\d+)',log);assert match and match.groups()==('Succeeded','4','1370','1652996032')
assert 'iOS Unity build failed: Succeeded, errors=4' in log and (e/'ios-export-exit.txt').read_text().strip()=='1'
assert (e/'license-return-exit.txt').read_text().strip()=='0'
assert (e/'test-dll-after-reimport.sha256').read_text().split()[0]=='d887b370c95c2966dc40d80648d85c286bb42d85004c32d095f64f004e095b37'
api=json.loads((Q/'HELPER-API.json').read_bytes());control=json.loads((Q/'CAPTURE-TOOL-CONTROLS.json').read_bytes());assert api['exit']==0 and api['exact_editor_modules_independently_bound'] and control['canaries']==5 and control['workflow_guards_pass']
source_parent=subprocess.check_output(['git','show',j['headSha']+':.github/workflows/bulk401-startup-runtime-gate.yml'],cwd=R);(D/'FAILED-RUN-WORKFLOW.yml').write_bytes(source_parent)
oldhelper=subprocess.check_output(['git','show',j['headSha']+':Recovery/Startup-R3-2026-10-24/ios-support/Assets/Editor/GodsPVZIOSBuild.cs'],cwd=R);assert sha(oldhelper)=='a6b85524d8b0789f2255448271243fe6cb6f7f158bdbac3a1b1977279b8b5445';(D/'UNCHANGED-ORIGINAL-BUILD-HELPER.cs').write_bytes(oldhelper)
receipt=dict(status='ACTUAL_UNITY_EXPORT_REJECTED_FOUR_ERRORS_NOT_QUALIFIED',run_id=40255311794,url=j['url'],source_commit=j['headSha'],candidate_sha256='d887b370c95c2966dc40d80648d85c286bb42d85004c32d095f64f004e095b37',unity_process_exit=1,workflow_step_exit=69,unity_summary_result='Succeeded',unity_summary_total_errors=4,unity_summary_total_warnings=1370,unity_summary_output_size=1652996032,exact_four_error_details='UNAVAILABLE_IN_OLD_HELPER_OUTPUT_REPLAY_REQUIRED',xcode='NOT_STARTED_JOB_SKIPPED',ipa=None,seat_return_exit=0,serialization_depth_messages=log.count('Serialization depth limit'),new_monobehaviour_messages=log.count("using the 'new' keyword"),warning_counts_not_equal_actual_summary_error_count=True,root_cause_not_inferred_from_summary=True,replay_prepared_not_started=True,new_game_changes=0,errors_ignored=False,ipad_acceptance=False)
js(D/'ACTUAL-FAILURE-READBACK.json',receipt);js(D/'LOCAL-HELPER-API.json',api);js(D/'CAPTURE-TOOL-CONTROLS.json',control);js(D/'RUN.json',j)
pack(D/'ACTUAL-FAILED-RUN-40255311794.zip',[(p.relative_to(raw).as_posix(),p.read_bytes()) for p in sorted(raw.rglob('*')) if p.is_file()])
names=['GodsPVZBuildReportCapture.cs','instrument_startup_r20_build_helper.py','preflight_build_capture_editor.py','capture_startup_r20_export_forensics.py'];files=[('scripts/actions/'+n,(R/'scripts/actions'/n).read_bytes()) for n in names]
files += [('workflow/'+n,(R/'.github/workflows'/n).read_bytes()) for n in ['bulk401-startup-runtime-gate.yml','startup-r20-real-ios-test-build.yml','startup-r2-editor-preflight.yml']]
files += [('local-api-and-controls/'+p.relative_to(Q).as_posix(),p.read_bytes()) for p in sorted(Q.rglob('*')) if p.is_file()]
files += [(p.name,p.read_bytes()) for p in [W/'check_build_capture_api.py',W/'check_build_capture_forensics.py',Path(__file__)]]
pack(D/'CAPTURE-IMPLEMENTATION-AND-LOCAL-CONTROLS.zip',files)
(D/'README.md').write_bytes('''# R20 真实 iOS 导出被四条 BuildReport 错误阻止

运行40255311794（提交8d9f91486d973c6d63e0a2fea145366060e05970）使用精确d887b370候选完成重导入、资产/着色器/PlayMode检查后执行真实iOS BuildPipeline。日志报告result=Succeeded，但totalErrors=4、warnings=1370、输出大小1,652,996,032字节。原有helper据此抛异常，Unity退出1、工作流step退出69，export失败、build_ipa跳过；没有新IPA。席位已实际归还，退出0。

旧helper只打印summary，未序列化report.steps.messages。原始日志包含1221处序列化深度提示和56处new MonoBehaviour提示，但这些计数不是那四条BuildReport错误的逐项证明；不从数量反推根因。源工程和已生成C++没有在失败后保留，所以本次实际导出的源码也不能拿此前可移植编译/Apple语法检查替代验收。

新增观察工具只在原始BuildIOS的BuildPlayer返回后插入一条Record(report)调用；移除该唯一调用后，整个原helper字节完全相同（SHA a6b85524…），原result/totalErrors判定和异常保持。新wrapper通过finally保存真实report全部steps/messages及Error/Exception/Assert日志，即使helper抛异常也保留。安装在原来三个helper源的预编译结束之后，额外helper使用缓存的精确Editor API在授权和完整setup之前独立编译。原始R3 helper文件没有覆盖。

实际导出失败时将另外保存完整生成源码、metadata、pbx与实际裁剪runtime清单，全部SHA/ZIP回读，不贴export成功标签，也不自动进入Mac。原来的成功Xcode/签名禁用/arm64/候选绑定/实际全量源码编译规则、错误门和always席位归还保持。

本机精确Unity模块API编译通过；本地修正了两个在真正Unity启动前已检出的API兼容问题（internal GetLatestReport不可调用、计数字段应为int），失败源与日志都保留，最终方案只用公开API与显式传入report。五个工具canary覆盖原helper篡改、重复注入、Succeeded+4 errors仍保持unqualified、报告缺失仍不接受；合成内容只测试记录/状态保真，未冒充游戏构建。此处准备一次带完整证据的复现，尚未启动。

游戏DLL没有新改动。R20仍是104处/8方法已构造的启动测试候选；R19有限profile80/26,772正常记录，另20个profile待完成，包含两处已发现的浮点差异。设备黑屏未验收，未达到全游戏高还原验收。
'''.encode())
s=json.loads((F/'PROGRESS.json').read_bytes());s.update(status='ACTUAL_EXPORT_FAILED_FOUR_BUILDREPORT_ERRORS_FORENSIC_REPLAY_PREPARED',run_id=40255311794,source_commit=j['headSha'],url=j['url'],unity_export='REJECTED_SUCCEEDED_SUMMARY_WITH_4_ERRORS',unity_summary_errors=4,actual_export_apple_compilation='NOT_STARTED',xcode_link='NOT_STARTED',ipa=None,report_capture_followup='../'+D.name);js(F/'PROGRESS.json',s)
p=F/'README.md';v=p.read_text('utf-8');v+='\n## 实际导出结果\n\n[40255311794失败回读及记录器](../Startup-R20-Export-Error4-2026-10-26/README.md)：Unity summary=Succeeded但4 errors，原门判失败，Mac跳过，没有IPA。已补完整逐项报告和失败生成源码留存，尚待复现定位；未忽略错误或改游戏候选。\n';p.write_bytes(v.encode())
s=json.loads((T/'PROGRESS.json').read_bytes());s.update(real_ios_export='REJECTED_4_BUILDREPORT_ERRORS_RUN_40255311794',real_ios_summary_result='Succeeded',real_ios_summary_errors=4,xcode='NOT_STARTED',ipa=None,whole_game_accepted=False);js(T/'PROGRESS.json',s)
p=R/'Recovery/STATUS.md';v=p.read_text('utf-8');marker='## Latest checkpoint - 2026-10-26\n';v=v.replace(marker,marker+'\n[R20 actual export failure](Startup-R20-Export-Error4-2026-10-26/README.md): run40255311794 produced summary Succeeded with4 errors; original gate rejected it and Mac was skipped. No newIPA. A complete BuildReport/source capture is prepared; error decisions and gameDLL are unchanged.\n',1);p.write_bytes(v.encode())
for folder in [D,F,T]:manifest(folder)
print(json.dumps(receipt))
