"""Tool canaries: Succeeded+4errors must remain unqualified; unknown errors stay unknown."""
from pathlib import Path
import ast,json,shutil,sys,tempfile
sys.dont_write_bytecode=True
from archive_support import sha,js,pack
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';Q=W/'r20-build-error4-forensics-2026-10-26';sys.path.insert(0,str(R/'scripts/actions'));sys.path.insert(0,str(W.parents[1]/'audit/stage9-native3/python-deps'));sys.path.insert(0,str(W/'tool-deps'))
from instrument_startup_r20_build_helper import instrument
from capture_startup_r20_export_forensics import capture
import yaml
original=(R/'Recovery/Startup-R3-2026-10-24/ios-support/Assets/Editor/GodsPVZIOSBuild.cs').read_bytes();derived=instrument(original);assert derived.replace(b'        GodsPVZBuildReportCapture.Record(report);'+(b'\r\n' if b'\r\n' in original else b'\n'),b'',1)==original
controls=[]
for name,data in [('removed_error_gate',original.replace(b'report.summary.totalErrors != 0',b'false')),('unrelated_byte_change',original+b' '),('already_instrumented',derived)]:
    error=None
    try:instrument(data)
    except AssertionError as ex:error=str(ex)
    assert error;controls.append(dict(name=name,rejected=True,error=error))
root=Path(tempfile.mkdtemp(prefix='build-capture-tool-controls-',dir=W)).resolve();assert root.is_relative_to(W.resolve())
try:
    out=root/'succeeded-with-four-errors';e=out/'evidence';e.mkdir(parents=True);project=root/'NO_GAME_PROJECT';project.mkdir()
    js(e/'actual-unity-build-report.json',dict(result='Succeeded',total_errors=4,total_warnings=0,steps=[dict(name='SYNTHETIC_DIAGNOSTIC_CANARY_NOT_GAME_BUILD',messages=[dict(type='Error',content=f'controlled error {i}') for i in range(4)])],logs=[],exception='SYNTHETIC original error gate rejection'))
    (e/'ios-export-exit.txt').write_text('1\n');source=out/'xcode/Il2CppOutputProject/Source/il2cppOutput';source.mkdir(parents=True)
    for name in ['Canary.cpp','Canary.c']:(source/name).write_bytes(b'// SYNTHETIC_TOOL_CANARY_NEVER_SENT_TO_COMPILER\n')
    a=capture(out,project);assert a['qualified'] is False and a['summary_errors']==4 and len(a['report_error_messages'])==4 and a['unity_exit']=='1' and a['observed_plugin_sha256'] is None and a['actual_generated_cpp']==a['actual_generated_c']==1
    controls.append(dict(name='succeeded_with_four_errors_stays_unqualified',passed=True,synthetic_evidence_not_game=True,all_four_error_messages_retained=True))
    a=capture(root/'missing-report',project);assert a['qualified'] is False and a['actual_report_found'] is False and a['captured_files']==0 and a['unity_exit'] is None
    controls.append(dict(name='missing_report_not_accepted',passed=True))
finally:
    assert root.is_relative_to(W.resolve());shutil.rmtree(root)
for name in ['bulk401-startup-runtime-gate.yml','startup-r20-real-ios-test-build.yml','startup-r2-editor-preflight.yml']:
    p=R/'.github/workflows'/name;b=p.read_text('utf-8');j=yaml.safe_load(b);assert isinstance(j['jobs'],dict)
    if name=='startup-r2-editor-preflight.yml':assert b.count('preflight_build_capture_editor.py')==1;continue
    steps=j['jobs']['export']['steps'];names=[s.get('name') for s in steps];install=next(i for i,s in enumerate(steps) if 'instrument_startup_r20_build_helper.py' in s.get('run',''))
    preflight=names.index('Compile both helper states and verify licensing CLI before activation');assert install>preflight
    step=steps[install];assert step['name']=='Export unsigned iOS Xcode project with exact R20 candidate' and '-executeMethod GodsPVZBuildReportCapture.ExportIOS' in step['run'] and '[ "$RC" -eq 0 ] || exit 69' in step['run']
    assert steps[names.index('Return Personal seat')]['if']=='always()'
    assert steps[names.index('Upload unsigned Xcode project archive')]['if']=="always() && steps.xcode_audit.outcome == 'success'"
    assert 'needs' in j['jobs']['build_ipa'] and 'export' in j['jobs']['build_ipa']['needs']
    assert 'CODE_SIGNING_ALLOWED=NO' in b and 'CODE_SIGNING_REQUIRED=NO' in b
for name in ['instrument_startup_r20_build_helper.py','preflight_build_capture_editor.py','capture_startup_r20_export_forensics.py']:ast.parse((R/'scripts/actions'/name).read_text('utf-8'))
report=dict(scope='TOOL_CAPTURE_AND_WORKFLOW_GUARDS_ONLY',controls=controls,canaries=len(controls),workflow_guards_pass=True,new_game_changes=0,unity_executed=False,ipa=False)
js(Q/'CAPTURE-TOOL-CONTROLS.json',report);print(json.dumps(report))
