from pathlib import Path
import hashlib,json,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;root=W.parents[1];repo=root/'audit/repo-native113';sys.path.insert(0,str(repo/'scripts/actions'))
from instrument_startup_r20_build_helper import instrument
r=root/'audit/local-preflight/exact-editor-tools/resolver';a=root/'audit/local-preflight/exact-editor-tools/aot-resolver';out=W/'r20-build-error4-forensics-2026-10-26'
refs=[a/n for n in ('mscorlib.dll','System.dll','System.Core.dll','netstandard.dll')]+[r/n for n in ('UnityEditor.CoreModule.dll','UnityEngine.CoreModule.dll','UnityEngine.JSONSerializeModule.dll')]
original=repo/'Recovery/Startup-R3-2026-10-24/ios-support/Assets/Editor/GodsPVZIOSBuild.cs';derived=out/'GodsPVZIOSBuild-Instrumented.cs';derived.write_bytes(instrument(original.read_bytes()));sources=[derived,repo/'scripts/actions/GodsPVZBuildReportCapture.cs']
cmd=[str(root/'.local/dotnet10/dotnet.exe'),str(root/'.local/dotnet10/sdk/10.0.402/Roslyn/bincore/csc.dll'),'/noconfig','/nostdlib','/target:library','/langversion:9.0','/utf8output','/preferreduilang:en-US','/define:UNITY_EDITOR','/out:'+str(out/'BuildCapture.dll')]+['/r:'+str(p) for p in refs]+[str(s) for s in sources]
proc=subprocess.run(cmd,capture_output=True);(out/'helper-api.log').write_bytes(proc.stdout+proc.stderr)
prior=json.loads((W/'asset-audit-40081048209/HELPER-COMPILATION.json').read_bytes());known={Path(row['path']).name:row['sha256'] for row in prior['references']};assert all(hashlib.sha256(p.read_bytes()).hexdigest()==known[p.name] for p in refs[4:])
j=dict(scope='EXACT_LOCAL_EDITOR_API_COMPILE_ONLY_ORIGINAL_BUILD_GATE_UNCHANGED',exit=proc.returncode,exact_editor_modules_independently_bound=True,reference_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in refs},sources=[dict(file=str(s.relative_to(root)),sha256=hashlib.sha256(s.read_bytes()).hexdigest()) for s in sources],unity_executed=False,original_helper_sha256=hashlib.sha256(original.read_bytes()).hexdigest())
(out/'HELPER-API.json').write_text(json.dumps(j,indent=2)+'\n');print((proc.stdout+proc.stderr).decode('utf-8',errors='replace'));print(json.dumps(j));raise SystemExit(proc.returncode)
