"""Restore only SwfList<T> two constructors and shared empty-array initializer."""
from pathlib import Path
import hashlib,importlib.util,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
def module(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
writer=module('metadata_only',W/'startup-r2/construct.py');IL=module('il_labels_only',W/'startup-r13/construct.py').IL;sha=lambda b:hashlib.sha256(b).hexdigest()
def build(output,report_path):
    output=Path(output);report_path=Path(report_path);assert not output.exists() and not report_path.exists();before=(W/'startup-r14/candidate1.dll').read_bytes();assert sha(before)=='9b53867fb47378190f147f9b474ed24525b15dde44ce753143e56934aaf2c491';pe=dnfile.dnPE(data=before);out=bytearray(before);evidence=json.loads((Q/'RESEARCH.json').read_bytes());assert evidence['raw_registration_rows_rechecked']
    cil=json.loads((W/'startup-r14/ALL-CIL.json').read_text('utf-8-sig'));methods={int(m['token'],16)&0xffffff:m for m in cil['methods']};targets={0x8e3,0x8e4,0x8f1}
    def body(rid):
        row=pe.net.mdtables.MethodDef.rows[rid-1];at=pe.get_offset_from_rva(row.Rva);assert sum(r.Rva==row.Rva for r in pe.net.mdtables.MethodDef.rows)==1;h=(struct.unpack_from('<H',before,at)[0]>>12)*4;assert h==12;size=struct.unpack_from('<I',before,at+4)[0];return at,h,before[at+h:at+h+size]
    cli=pe.get_offset_from_rva(pe.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress);mrva,msize=struct.unpack_from('<II',before,cli+8);mat=pe.get_offset_from_rva(mrva);root,streams=writer.metadata_root(before[mat:mat+msize]);values={n:b for n,_,b in streams};header,rows,tail,counts=writer.tables_decode(values['#~'])
    data_ref=next(r for r in evidence['existing_memberrefs'] if r.get('owner_typespec')=='151284d8011300' and r['name']=='_data');size_ref=next(r for r in evidence['existing_memberrefs'] if r.get('owner_typespec')=='151284d8011300' and r['name']=='_size');assert data_ref['signature']=='061d1300' and size_ref['signature']=='0608'
    parent_ref=rows[10][(int(data_ref['token'],16)&0xffffff)-1];name=b'_emptyData\0';idx=values['#Strings'].find(name);assert idx>=0 and values['#Strings'][idx-1]==0
    rows[10].append([parent_ref[0],idx,parent_ref[2]]);empty=0xa000000|len(rows[10]);data=int(data_ref['token'],16);size=int(size_ref['token'],16);array_type=next(int(r['token'],16) for r in evidence['existing_typespecs'] if r['signature']=='1300');base_ctor=next(int(r['token'],16) for r in evidence['existing_memberrefs'] if r.get('owner_name')=='Object' and r['signature']=='200001');exception=next(int(r['token'],16) for r in evidence['existing_memberrefs'] if r.get('owner_name')=='ArgumentOutOfRangeException' and r['signature']=='2002010e0e')
    tokens={};_,_,old=body(0x8e4)
    for i in methods[0x8e4]['instructions']:
        if i['opcode']=='ldstr':
            assert old[i['offset']]==0x72;tokens[i['operand']]=int.from_bytes(old[i['offset']+1:i['offset']+5],'little')
    strings={r['value'] for m in evidence['methods'] for r in m['strings']};assert strings=={'capacity','capacity must be >= 0'} and strings<=tokens.keys()
    bodies={0x8f1:IL().op('16').token(0x8d,array_type).token(0x80,empty).op('2a').finish(),0x8e3:IL().arg(0).token(0x28,base_ctor).arg(0).token(0x7e,empty).token(0x7d,data).arg(0).op('16').token(0x7d,size).op('2a').finish()}
    b=IL().arg(0).token(0x28,base_ctor).arg(1).op('16').branch(0x3c,'valid').token(0x72,tokens['capacity']).token(0x72,tokens['capacity must be >= 0']).token(0x73,exception).op('7a')
    b.mark('valid').arg(0).arg(1).branch(0x3a,'allocate').token(0x7e,empty).branch(0x38,'assign').mark('allocate').arg(1).token(0x8d,array_type).mark('assign').token(0x7d,data).arg(0).op('16').token(0x7d,size).op('2a');bodies[0x8e4]=b.finish();allowed=set();changes=[]
    for rid,code in bodies.items():
        at,h,old=body(rid);assert len(code)<=len(old) and methods[rid]['handlers']==[];out[at+h:at+h+len(code)]=code;struct.pack_into('<I',out,at+4,len(code));allowed.update(range(at+4,at+8));allowed.update(range(at+h,at+h+len(code)));changes.append(dict(token=f'0x{0x6000000|rid:08X}',file_offset=at,rva=hex(pe.net.mdtables.MethodDef.rows[rid-1].Rva),old_code_size=len(old),new_code_size=len(code),code=code.hex(),unused_old_slot_preserved=True))
    values['#~']=writer.tables_encode(header,rows,tail,counts);meta=bytearray(root)
    for name,at,_ in streams:
        start=writer.align(len(meta),4);meta.extend(b'\0'*(start-len(meta)));struct.pack_into('<II',meta,at,start,len(values[name]));meta.extend(values[name])
    last=pe.sections[-1];assert last.Name.rstrip(b'\0')==b'.n29meta' and last.Characteristics==0x40000040 and last.PointerToRawData+last.SizeOfRawData==len(before);start=writer.align(len(out),4);out.extend(b'\0'*(start-len(out)));out.extend(meta);end=len(out);raw_size=writer.align(end-last.PointerToRawData,pe.OPTIONAL_HEADER.FileAlignment);out.extend(b'\0'*(last.PointerToRawData+raw_size-len(out)));sh=last.get_file_offset();opt=pe.OPTIONAL_HEADER.get_file_offset();updates={sh+8:end-last.PointerToRawData,sh+16:raw_size,opt+8:pe.OPTIONAL_HEADER.SizeOfInitializedData+raw_size-last.SizeOfRawData,opt+56:writer.align(last.VirtualAddress+end-last.PointerToRawData,pe.OPTIONAL_HEADER.SectionAlignment),opt+64:0,cli+8:last.VirtualAddress+start-last.PointerToRawData,cli+12:len(meta)}
    for at,value in updates.items():struct.pack_into('<I',out,at,value);allowed.update(range(at,at+4))
    assert all(x==y or i in allowed for i,(x,y) in enumerate(zip(before,out)));output.write_bytes(out);report=dict(scope='THREE_NATIVE_BACKED_GENERIC_INITIALIZERS_CONSTRUCTED_RUNTIME_PENDING',parent_sha256=sha(before),candidate_sha256=sha(out),bytes=len(out),method_targets=3,unchanged_methoddefs=2314,new_memberref=dict(token=f'0x{empty:08X}',name='_emptyData',owner_coded=parent_ref[0],signature='061d1300'),changes=changes,header_updates={str(k):v for k,v in updates.items()},new_local_signatures=0,new_methoddefs=0,visibility_changed=False,runtime='PENDING',unity_or_ipa=False);report_path.write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in report.items() if k not in ['changes','header_updates']},indent=2))
if __name__=='__main__':build(*sys.argv[1:])
