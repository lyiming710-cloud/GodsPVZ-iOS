from pathlib import Path
import collections,hashlib,json,struct,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];O=Q/'runtime-results';sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
raw=(Q/'candidate1.dll').read_bytes();digest=hashlib.sha256(raw).hexdigest();assert digest=='261068dda5af1f6915ea7c2183fa8b2b0d69092db6777e5643a39552669ccba1';dot=ROOT/'.local/dotnet10/dotnet.exe';fixture=Q/'runtime/bin/Release/net10.0/Fixture.dll';native=json.loads((O/'NATIVE.json').read_bytes());cil=json.loads((O/'ACTUAL-CIL.json').read_bytes());neg=json.loads((O/'MANAGED-NEGATIVE.json').read_bytes());assert cil['candidate_sha256']==neg['candidate_sha256']==digest
a=native['results'];b=cil['results'];diff=[dict(native=x,cil=y) for x,y in zip(a,b) if x!=y];(O/'BASELINE.json').write_bytes((json.dumps(dict(constructor_cases=len(a),differences=diff,static_initializer_match=native['automatic_initialization']==cil['automatic_initialization']),indent=2)+'\n').encode());assert not diff and len(a)==len(b)==504 and native['automatic_initialization']==cil['automatic_initialization'] and len(cil['automatic_initialization'])==3
assert all(r==dict(value_type=r['value_type'],shared_length=0,has_shared=True,error=None) for r in cil['automatic_initialization']);assert cil['readonly_static_field_not_modified_by_fixture'] and 'InitOnly' in cil['static_field_attributes'] and all(r['status']=='JIT_PREPARED_NO_EXECUTION' for r in cil['closed_jit']) and len(cil['closed_jit'])==9
for r in neg['results']:assert r['error']=='System.ArgumentOutOfRangeException' and r['param']=='capacity' and r['message'].startswith('capacity must be >= 0') and r['state']==dict(size=9,data_length=3,data_same_old=True,data_same_shared=False,shared_same_old=True,shared_length=0,all_default=False)
assert len(neg['results'])==9
pe=dnfile.dnPE(data=raw);methods={int(m['token'],16)&0xffffff:m for m in json.loads((Q/'METHOD-CIL.json').read_bytes())['methods']};mutants={}
def body(data,rid):
    at=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[rid-1].Rva);h=(struct.unpack_from('<H',data,at)[0]>>12)*4;n=struct.unpack_from('<I',data,at+4)[0];return at,h,data[at+h:at+h+n]
def rewrite(name,rid,replacements):
    at,h,old=body(raw,rid);ins=methods[rid]['instructions'];out=bytearray();mapping={};branches=[]
    for k,i in enumerate(ins):
        p=i['offset'];end=ins[k+1]['offset'] if k+1<len(ins) else len(old);mapping[p]=len(out);chunk=replacements.get(p,old[p:end])
        if isinstance(i['operand'],dict) and 'target' in i['operand']:assert len(chunk)==5;branches.append((len(out),i['operand']['target']))
        out.extend(chunk)
    for p,target in branches:struct.pack_into('<i',out,p+1,mapping[target]-(p+5))
    replace(name,rid,bytes(out))
def replace(name,rid,code):
    parent=(W/'startup-r14/candidate1.dll').read_bytes();at,h,old=body(raw,rid);assert len(code)<=len(body(parent,rid)[2]);data=bytearray(raw);data[at+h:at+h+len(code)]=code;struct.pack_into('<I',data,at+4,len(code));mutants[name]=bytes(data)
def find(rid,op):return next(i for i in methods[rid]['instructions'] if i['opcode']==op)
rewrite('cctor-allocates-one',0x8f1,{0:b'\x17'});rewrite('cctor-omits-shared-assignment',0x8f1,{find(0x8f1,'stsfld')['offset']:b'\x26'})
load=find(0x8e3,'ldsfld')['offset'];rewrite('default-allocates-instead-of-sharing',0x8e3,{load:bytes.fromhex('168d9e00001b')});rewrite('default-retains-old-data',0x8e3,{load:bytes.fromhex('027bcd03000a')});reset=find(0x8e3,'ldc.i4.0')['offset'];rewrite('default-size-one',0x8e3,{reset:b'\x17'})
reset=next(i['offset'] for i in reversed(methods[0x8e4]['instructions']) if i['opcode']=='ldc.i4.0');rewrite('capacity-size-one',0x8e4,{reset:b'\x17'});branch=find(0x8e4,'brtrue')['offset'];at,h,code=body(raw,0x8e4);rewrite('capacity-zero-branch-inverted',0x8e4,{branch:b'\x39'+code[branch+1:branch+5]});guard=find(0x8e4,'bge')['offset'];rewrite('capacity-negative-unsigned-guard',0x8e4,{guard:b'\x41'+code[guard+1:guard+5]})
call=find(0x8e4,'call')['offset'];rewrite('capacity-resets-before-negative-throw',0x8e4,{call:code[call:call+5]+bytes.fromhex('02167dce03000a')});strings=[i['offset'] for i in methods[0x8e4]['instructions'] if i['opcode']=='ldstr'];rewrite('capacity-exception-arguments-swapped',0x8e4,{strings[0]:code[strings[1]:strings[1]+5],strings[1]:code[strings[0]:strings[0]+5]})
parent=(W/'startup-r14/candidate1.dll').read_bytes();bad=bytearray(raw)
for rid in methods:
    at,h,code=body(parent,rid);bad[at+h:at+h+len(code)]=code;struct.pack_into('<I',bad,at+4,len(code))
mutants['historical-placeholder-initializers-restored']=bytes(bad);controls=[]
for name,data in mutants.items():
    dll=O/(name+'.dll');dll.write_bytes(data);outputs=[]
    for group,cases in [('normal','CASES.json'),('negative','NEGATIVE-CASES.json')]:
        output=O/(name+'-'+group+'.json');p=subprocess.run([str(dot),str(fixture),str(dll),str(O/cases),str(output)],capture_output=True,timeout=40);(O/(name+'-'+group+'.stdout.log')).write_bytes(p.stdout);(O/(name+'-'+group+'.stderr.log')).write_bytes(p.stderr);assert p.returncode==0,(name,p.returncode,p.stderr[-1000:]);r=json.loads(output.read_bytes());assert r['candidate_sha256']==hashlib.sha256(data).hexdigest();outputs.append(r)
    n,g=outputs;assert len(n['results'])==504 and len(g['results'])==9;normal=sum(x!=y for x,y in zip(a,n['results']));automatic=sum(x!=y for x,y in zip(native['automatic_initialization'],n['automatic_initialization']));negative=sum(x!=y for x,y in zip(neg['results'],g['results']));assert normal+automatic+negative>0,name;controls.append(dict(name=name,mutant_sha256=hashlib.sha256(data).hexdigest(),constructor_differences=normal,automatic_init_differences=automatic,managed_negative_differences=negative,native_negative_throw_not_executed=True))
result=dict(scope='THREE_COMPLETE_SHARED_GENERIC_NATIVE_CALLERS_VS_DIRECT_ACTUAL_DLL_CLOSED_CLR_METHODS',candidate_sha256=digest,pass_=True,constructor_cases=504,automatic_static_initializer_cases=3,total_native_cil_observations=507,managed_negative_cases=9,closed_contexts=['System.Int32','System.String','24_BYTE_VALUE_TYPE'],closed_jit_prepared=9,constructor_counts=dict(collections.Counter(r['kind'] for r in a)),differences=[],negative_controls=controls,readonly_static_field_preserved=True,reflection_emit_used=False,source_instructions_removed=False,initial_fixture_readonly_fieldaccess_failure_preserved=True,real_gc_allocator_contract=False,native_class_init_and_seh=False,real_unity_execution=False,whole_game=False,ipa=None);(O/'RESULT.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in result.items() if k!='negative_controls'},indent=2));print('Physical semantic faults detected',len(controls))
