# Input-bound R6 invocation derived from supplement_interface_facts.py sha256=354c30beaf5ca483d12be8e7e200d28de4ef0ed3273a53fe233b630bed42ac88; frozen verifier unchanged.
"""Read-only InterfaceImpl facts omitted by CilExporter; frozen checker untouched.

Original export and original failing census stay intact. This supplements only
actual direct nongeneric InterfaceImpl rows in this exact candidate, never a
guessed assignment rule. Generic interface instances are recorded as unmodeled.
"""
from pathlib import Path
import hashlib,importlib.util,json,sys,collections,copy
W=Path(__file__).resolve().parent.parent;ROOT=W.parents[1];Q=W/'startup-r15'
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
candidate=Q/'candidate1.dll';digest=hashlib.sha256(candidate.read_bytes()).hexdigest()
assert digest=='261068dda5af1f6915ea7c2183fa8b2b0d69092db6777e5643a39552669ccba1'
pe=dnfile.dnPE(data=candidate.read_bytes());nested={r.NestedClass.row_index:r.EnclosingClass.row_index for r in pe.net.mdtables.NestedClass.rows}
def typedef(rid):
    row=pe.net.mdtables.TypeDef.rows[rid-1]
    if rid in nested:return typedef(nested[rid])+'/'+str(row.TypeName)
    return (str(row.TypeNamespace)+'.' if str(row.TypeNamespace) else '')+str(row.TypeName)
def typeref(rid):
    row=pe.net.mdtables.TypeRef.rows[rid-1]
    if row.ResolutionScope.table and row.ResolutionScope.table.name=='TypeRef':return typeref(row.ResolutionScope.row_index)+'/'+str(row.TypeName)
    return (str(row.TypeNamespace)+'.' if str(row.TypeNamespace) else '')+str(row.TypeName)
original=json.loads((Q/'ALL-CIL.json').read_text('utf-8-sig'));enriched=copy.deepcopy(original);facts=[];skipped=[]
for index,row in enumerate(pe.net.mdtables.InterfaceImpl.rows,1):
    owner=typedef(row.Class.row_index)
    if row.Interface.table.name not in ('TypeRef','TypeDef'):
        skipped.append(dict(interfaceimpl_row=index,owner=owner,kind=row.Interface.table.name,signature=row.Interface.row.Signature.value.hex()));continue
    interface=typeref(row.Interface.row_index) if row.Interface.table.name=='TypeRef' else typedef(row.Interface.row_index)
    # The exporter also omits unused external interface nodes. Do not invent
    # their properties; only add the actual edge for an existing owner node.
    applied=owner in enriched['types']
    if applied:
        entries=enriched['types'][owner].setdefault('interfaces',[])
        if interface not in entries:entries.append(interface)
    facts.append(dict(interfaceimpl_row=index,owner=owner,interface=interface,applied_to_existing_owner=applied))
facts_report=dict(scope='EXACT_CANDIDATE_DIRECT_NONGENERIC_INTERFACEIMPL_METADATA_FACTS_ONLY',candidate_sha256=digest,rows=facts,generic_interface_rows_not_modeled=skipped)
(Q/'INTERFACE-FACTS.json').write_bytes((json.dumps(facts_report,indent=2)+'\n').encode())
(Q/'ALL-CIL-WITH-INTERFACE-FACTS.json').write_bytes((json.dumps(enriched,indent=2)+'\n').encode())
f=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py'
assert hashlib.sha256(f.read_bytes()).hexdigest()=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14'
spec=importlib.util.spec_from_file_location('unchanged_frozen',f);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
results=[]
for method in enriched['methods']:
    try:result=v.verify(method,enriched['types'])
    except Exception as error:result=dict(token=method['token'],method=method['name'],status='FAIL_OR_UNSUPPORTED',error=str(error))
    results.append(result)
counts=collections.Counter(r['status'] for r in results)
prior=json.loads((Q/'FROZEN-STACK-ALL-2297.json').read_bytes())
old={r['token']:r for r in prior['results']};changed=[dict(token=r['token'],old=old[r['token']]['status'],new=r['status']) for r in results if old[r['token']]['status']!=r['status']]
report=dict(scope='ADDITIONAL_UNCHANGED_FROZEN_CHECKER_WITH_EXACT_INTERFACE_FACTS_NOT_RUNTIME_PROOF',candidate_sha256=digest,checker_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),
            original_census_preserved=True,original_counts=prior['counts'],counts=dict(counts),total=len(results),changed_results=changed,results=results)
(Q/'FROZEN-WITH-INTERFACE-FACTS.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
print(json.dumps({k:v for k,v in report.items() if k not in ('results','changed_results')},indent=2));print('direct interface rows',len(facts),'unmodeled generic rows',len(skipped),'changed',len(changed))
