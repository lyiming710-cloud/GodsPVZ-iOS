"""Read-only original generic registration binding and complete caller CFGs."""
from pathlib import Path
import hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile,pefile
from capstone import *
from capstone.x86_const import X86_OP_IMM,X86_OP_MEM,X86_REG_RIP
I=ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs';raw=(I/'original-pc/GameAssembly.dll').read_bytes();metadata=(I/'original-pc/global-metadata.dat').read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest();assert sha(raw)=='9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d' and sha(metadata)=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9'
p=pefile.PE(data=raw);base=p.OPTIONAL_HEADER.ImageBase;read=lambda at,n:p.get_data(at-base,n)
mv=struct.unpack('<16Q',read(0x1818c6d00,128));cv=struct.unpack('<17Q',read(0x1815e88c0,136));mo=struct.unpack_from('<I',metadata,48)[0];so=struct.unpack_from('<I',metadata,24)[0];lo,ls,ld=struct.unpack_from('<III',metadata,8)
old=ROOT/'audit/bulk400-generic-repair-2026-10-24/evidence/original-generic-bindings.json';historical=json.loads(old.read_bytes());targets={0x8e3,0x8e4,0x8f1};bindings=[]
for r in historical['methods']:
    rid=int(r['token'],16)&0xffffff
    if rid not in targets:continue
    si=r['method_spec_index'];gi=r['generic_pointer_index'];assert 0<=si<mv[8] and 0<=gi<cv[2];definition,ci,mi=struct.unpack('<iii',read(mv[9]+si*12,12));assert (definition,ci,mi)==(r['definition_index'],r['class_inst_index'],r['method_inst_index']);assert struct.unpack_from('<I',metadata,mo+definition*36+24)[0]==int(r['token'],16)
    found=[]
    for k in range(mv[4]):
        row=struct.unpack('<iiii',read(mv[5]+k*16,16))
        if row[0]==si:found.append(row)
    assert len(found)==1 and found[0][1]==gi and int.from_bytes(read(cv[3]+gi*8,8),'little')==int(r['va'],16);bindings.append(r)
assert len(bindings)==6 and {r['class_args'][0] for r in bindings}=={'object','Unity.IL2CPP.Metadata.__Il2CppFullySharedGenericType'}
dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True;summary=[]
for rid in sorted(targets):
    entry={int(r['va'],16) for r in bindings if int(r['token'],16)&0xffffff==rid};assert len(entry)==1;entry=entry.pop();pending=[entry];ins={};tails=[]
    while pending:
        at=pending.pop()
        while at not in ins:
            i=next(dis.disasm(read(at,15),at));ins[at]=i;assert len(ins)<350
            if i.group(CS_GRP_RET) or i.mnemonic in ['int3','ud2']:break
            if i.group(CS_GRP_JUMP):
                assert i.operands[0].type==X86_OP_IMM;dest=i.operands[0].imm
                if dest==0x18024f360:tails.append(dict(source=hex(at),target=hex(dest)))
                else:pending.append(dest)
                if i.mnemonic=='jmp':break
            at+=i.size
    rows=[dict(va=hex(i.address),op=i.mnemonic,operands=i.op_str,bytes=i.bytes.hex()) for i in sorted(ins.values(),key=lambda x:x.address)];strings=[]
    for i in ins.values():
        if i.mnemonic!='lea':continue
        for o in i.operands:
            if o.type!=X86_OP_MEM or o.mem.base!=X86_REG_RIP:continue
            slot=i.address+i.size+o.mem.disp;enc=int.from_bytes(read(slot,8),'little')
            if enc>>29!=5:continue
            index=(enc&0x1fffffff)>>1;assert index*8<ls;n,start=struct.unpack_from('<II',metadata,lo+8*index);strings.append(dict(instruction=hex(i.address),slot=hex(slot),encoded=hex(enc),index=index,value=metadata[ld+start:ld+start+n].decode()))
    cfg=dict(token=f'0x{0x6000000|rid:08X}',entry=hex(entry),scope='COMPLETE_DIRECT_CALLER_CFG_INCLUDING_NATIVE_NEGATIVE_EXCEPTION_BRANCH_NO_SEH',instructions=rows,tail_targets=tails,strings=strings);(Q/f'{rid:04X}.native.json').write_bytes((json.dumps(cfg,indent=2)+'\n').encode());(Q/f'{rid:04X}.native.txt').write_text('\n'.join(f"{r['va']} {r['bytes']:22} {r['op']} {r['operands']}" for r in rows)+'\n');summary.append(dict(token=cfg['token'],entry=cfg['entry'],instructions=len(rows),strings=strings,calls=[r['operands'] for r in rows if r['op']=='call']))
assert read(0x180302170,3)==bytes.fromhex('c20000')
candidate=(W/'startup-r14/candidate1.dll').read_bytes();assert sha(candidate)=='9b53867fb47378190f147f9b474ed24525b15dde44ce753143e56934aaf2c491';a=dnfile.dnPE(data=candidate);members=[];types=[]
for k,r in enumerate(a.net.mdtables.MemberRef.rows,1):
    if str(r.Name) in ['_data','_size','_emptyData','.ctor']:
        if r.Class.table.name=='TypeSpec':
            sig=r.Class.row.Signature.value.hex()
            if ('84d8' in sig) or str(r.Name)=='_emptyData':members.append(dict(token=hex(0xa000000|k),name=str(r.Name),signature=r.Signature.value.hex(),owner_coded=r.Class.row_index*8+4,owner_typespec=sig))
        elif str(r.Name)=='.ctor' and str(getattr(r.Class.row,'TypeName','')) in ['ArgumentOutOfRangeException','Object']:members.append(dict(token=hex(0xa000000|k),name=str(r.Name),signature=r.Signature.value.hex(),owner_name=str(r.Class.row.TypeName),owner_coded=r.Class.row_index*8+(1 if r.Class.table.name=='TypeRef' else 0)))
for k,r in enumerate(a.net.mdtables.TypeSpec.rows,1):
    if r.Signature.value in [bytes.fromhex('1300'),bytes.fromhex('151284d8011300')]:types.append(dict(token=hex(0x1b000000|k),signature=r.Signature.value.hex()))
report=dict(original_sha256=sha(raw),metadata_sha256=sha(metadata),historical_binding_sha256=sha(old.read_bytes()),code_registration=hex(0x1815e88c0),metadata_registration=hex(0x1818c6d00),raw_registration_rows_rechecked=True,bindings=bindings,methods=summary,existing_memberrefs=members,existing_typespecs=types,object_ctor_original_helper_bytes='c20000',runtime='PENDING');(Q/'RESEARCH.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in report.items() if k not in ['bindings']},indent=2))
