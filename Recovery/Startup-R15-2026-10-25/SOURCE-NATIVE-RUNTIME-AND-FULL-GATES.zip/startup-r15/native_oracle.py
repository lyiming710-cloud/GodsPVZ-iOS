"""Execute original reference/shared initializer bodies, not their CLR model.
Array allocation, GC write barriers and class setup are controlled contracts.
Native negative exception construction/throw/SEH remain outside execution.
"""
from pathlib import Path
import ctypes as C,hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;sys.dont_write_bytecode=True;sys.path.insert(0,str(Q.parent/'startup-r5'))
from native_runtime_common import *
im=NativeImage();state={};rows=[];initial=[]
def array(n,fill):
    assert 0<=n<=32;p=im.alloc(32+state['element_size']*n);put64(p,state['array_class']);put64(p+0x18,n)
    if fill:C.memset(p+32,0x19,state['element_size']*n)
    return p
def allocate(cls,n):assert cls==state['array_class'];state['allocations'].append(n);return array(n,False)
def barrier(at,value):assert get64(at)==(value or 0);state['barriers']+=1
def reject(*args):raise AssertionError('Unmodeled class initialization or native exception')
try:
    cfgs={rid:json.loads((Q/f'{rid:04X}.native.json').read_bytes()) for rid in [0x8e3,0x8e4,0x8f1]};evidence=json.loads((Q/'RESEARCH.json').read_bytes())
    for rid,cfg in cfgs.items():
        assert any(int(r['token'],16)&0xffffff==rid and int(r['va'],16)==int(cfg['entry'],16) for r in evidence['bindings'])
        for i in cfg['instructions']:assert C.string_at(int(i['va'],16),len(bytes.fromhex(i['bytes'])))==bytes.fromhex(i['bytes'])
    assert C.string_at(0x180302170,3)==bytes.fromhex('c20000')
    im.hook(0x18024f3e0,P,[P,C.c_uint64],allocate);im.hook(0x18024f360,None,[P,P],barrier);im.hook(0x180258a80,P,[P],reject);im.hook(0x1802501e0,None,[P],reject);im.hook(0x180250110,None,[P,P],reject)
    for cfg in cfgs.values():
        for i in cfg['instructions']:assert C.string_at(int(i['va'],16),len(bytes.fromhex(i['bytes'])))==bytes.fromhex(i['bytes'])
    default=C.CFUNCTYPE(None,P,P)(0x1809d56d0);capacity=C.CFUNCTYPE(None,P,I,P)(0x1809d5770);cctor=C.CFUNCTYPE(None,P)(0x180805210)
    def setup(value_type):
        state.clear();state.update(element_size={'int':4,'string':8,'wide':24}[value_type],allocations=[],barriers=0);method=im.alloc(128);klass=im.alloc(512);ctx=im.alloc(128);statics=im.alloc(128);ac=im.alloc(512);state['array_class']=ac;put64(method+0x20,klass);put64(klass+0xc0,ctx);put64(klass+0xb8,statics);put32(klass+0xe0,1);C.c_ubyte.from_address(klass+0x135).value=1;C.c_ubyte.from_address(ac+0x135).value=1;put32(ac+0x104,state['element_size']);put64(ctx+0x10,klass);put64(ctx+0x18,ac);return method,statics
    for value_type in ['int','string','wide']:
        method,statics=setup(value_type);assert get64(statics)==0;cctor(method);shared=get64(statics);assert not im.errors and state['allocations']==[0] and state['barriers']==1;initial.append(dict(value_type=value_type,shared_length=get64(shared+0x18) if shared else None,has_shared=bool(shared),error=None))
    for c in json.loads(Path(sys.argv[1]).read_bytes()):
        assert c['capacity']>=0;method,statics=setup(c['value_type']);old_shared=array(0,False);put64(statics,old_shared);old_data=array(c['old_data_length'],True) if c['old_data_length']>=0 else 0;owner=im.alloc(64);put64(owner+0x10,old_data);put32(owner+0x18,c['seed_size'])
        if c['kind']=='default':default(owner,method)
        elif c['kind']=='capacity':capacity(owner,c['capacity'],method)
        else:raise AssertionError('Unexpected constructor case')
        assert not im.errors,im.errors;data=get64(owner+0x10);shared=get64(statics);length=get64(data+0x18) if data else None;after=dict(size=get32(owner+0x18),data_length=length,data_same_old=data==old_data,data_same_shared=data==shared,shared_same_old=shared==old_shared,shared_length=get64(shared+0x18) if shared else None,all_default=bool(data) and not any(C.string_at(data+32,state['element_size']*length)))
        rows.append(dict(name=c['name'],kind=c['kind'],value_type=c['value_type'],state=after,error=None,param=None,message=None))
    result=dict(scope='THREE_COMPLETE_ORIGINAL_PC_SHARED_GENERIC_INITIALIZERS_CONTROLLED_ARRAY_ALLOC_AND_GC_CLASS_CONTRACTS',original_sha256=PC_SHA,original_caller_bytes_preserved=True,original_object_ctor_ret0_bytes_preserved=True,actual_native_throw_or_seh=False,real_unity_execution=False,callback_errors=im.errors,automatic_initialization=initial,results=rows);Path(sys.argv[2]).write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(dict(constructor_cases=len(rows),static_initializer_cases=len(initial))))
finally:im.close()
