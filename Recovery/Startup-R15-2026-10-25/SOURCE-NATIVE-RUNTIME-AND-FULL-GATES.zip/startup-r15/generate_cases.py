from pathlib import Path
import json
Q=Path(__file__).resolve().parent;O=Q/'runtime-results';O.mkdir(exist_ok=True);rows=[]
for t in ['int','string','wide']:
    for old_length in [-1,0,1,3]:
        for size in [-2147483648,-17,-1,0,1,9,2147483647]:
            for kind,capacity in [('default',0),('capacity',0),('capacity',1),('capacity',2),('capacity',5),('capacity',17)]:rows.append(dict(name=f'case-{len(rows):04d}',kind=kind,value_type=t,old_data_length=old_length,seed_size=size,capacity=capacity))
negative=[dict(name=f'negative-{t}-{cap}',kind='capacity',value_type=t,old_data_length=3,seed_size=9,capacity=cap) for t in ['int','string','wide'] for cap in [-2147483648,-17,-1]]
(O/'CASES.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode());(O/'NEGATIVE-CASES.json').write_bytes((json.dumps(negative,indent=2)+'\n').encode());print('NATIVE_NORMAL_CASES',len(rows),'MANAGED_NEGATIVE_CASES',len(negative))
