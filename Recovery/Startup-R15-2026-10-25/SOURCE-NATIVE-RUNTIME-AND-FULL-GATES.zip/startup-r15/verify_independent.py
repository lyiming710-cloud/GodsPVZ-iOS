"""Check complete CIL shapes and raw append boundary independently of writer."""
from pathlib import Path
import hashlib,importlib.util,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
def mod(name,path):s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
writer=mod('raw_metadata_read',W/'startup-r2/construct.py');reader=mod('raw_body_read',ROOT/'audit/native111-publication-2026-10-20/repository/scripts/actions/static_gates.py');sha=lambda b:hashlib.sha256(b).hexdigest()
a=(W/'startup-r14/candidate1.dll').read_bytes();b=(Q/'candidate1.dll').read_bytes();assert sha(a)=='9b53867fb47378190f147f9b474ed24525b15dde44ce753143e56934aaf2c491' and sha(b)=='261068dda5af1f6915ea7c2183fa8b2b0d69092db6777e5643a39552669ccba1' and b==(Q/'candidate2.dll').read_bytes();pp=dnfile.dnPE(data=a);cp=dnfile.dnPE(data=b);targets={0x8e3,0x8e4,0x8f1};allowed=set();changed=[]
def meta(data,p):
    cli=p.get_offset_from_rva(p.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress);rva,size=struct.unpack_from('<II',data,cli+8);at=p.get_offset_from_rva(rva);_,streams=writer.metadata_root(data[at:at+size]);values={n:v for n,_,v in streams};_,rows,_,_=writer.tables_decode(values['#~']);return at,values,rows
_,pv,pr=meta(a,pp)
def metadata_check(data,p):
    at,cv,cr=meta(data,p);assert at==len(a) and set(cv)==set(pv) and set(cr)==set(pr)
    for n in pv:
        if n!='#~':assert cv[n]==pv[n],n
    for t in pr:
        if t==10:assert cr[t][:-1]==pr[t] and len(cr[t])==len(pr[t])+1
        else:assert cr[t]==pr[t],t
    ref=p.net.mdtables.MemberRef.rows[-1];assert str(ref.Name)=='_emptyData' and ref.Signature.value==bytes.fromhex('061d1300') and ref.Class.table.name=='TypeSpec' and ref.Class.row.Signature.value==bytes.fromhex('151284d8011300')
    assert cr[10][-1][0]==1244 and cr[10][-1][2]==pr[10][0x3cd-1][2]
metadata_check(b,cp)
cil=json.loads((Q/'ALL-CIL.json').read_text('utf-8-sig'));methods={int(m['token'],16)&0xffffff:m for m in cil['methods']};old=json.loads((W/'startup-r14/ALL-CIL.json').read_text('utf-8-sig'));old={int(m['token'],16)&0xffffff:m for m in old['methods']}
for rid,(x,y) in enumerate(zip(pp.net.mdtables.MethodDef.rows,cp.net.mdtables.MethodDef.rows),1):
    assert x.Rva==y.Rva
    if not x.Rva:continue
    at=pp.get_offset_from_rva(x.Rva);n=reader.parse_raw_method_body_span(a,at)[0];m=reader.parse_raw_method_body_span(b,at)[0]
    if a[at:at+n]!=b[at:at+m]:changed.append(rid)
    if rid not in targets:assert n==m and a[at:at+n]==b[at:at+m];continue
    assert a[at]&3==b[at]&3==3;h=(struct.unpack_from('<H',a,at)[0]>>12)*4;assert h==12;n=struct.unpack_from('<I',a,at+4)[0];m=struct.unpack_from('<I',b,at+4)[0];assert 0<m<n and a[at:at+4]==b[at:at+4] and a[at+8:at+h]==b[at+8:at+h] and a[at+h+m:at+h+n]==b[at+h+m:at+h+n];allowed.update(range(at+4,at+8));allowed.update(range(at+h,at+h+m))
    assert methods[rid]['locals']==old[rid]['locals'] and methods[rid]['maxStack']==old[rid]['maxStack'] and methods[rid]['handlers']==old[rid]['handlers']==[]
assert set(changed)==targets
sh=pp.sections[-1].get_file_offset();opt=pp.OPTIONAL_HEADER.get_file_offset();cli=pp.get_offset_from_rva(pp.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress);allowed.update(at+i for at in [sh+8,sh+16,opt+8,opt+56,opt+64,cli+8,cli+12] for i in range(4));assert pp.sections[-1].Characteristics==cp.sections[-1].Characteristics==0x40000040
def boundary(data):
    assert len(data)==len(b) and not any(x!=y and k not in allowed for k,(x,y) in enumerate(zip(a,data))),'Out of scope prefix mutation';metadata_check(data,dnfile.dnPE(data=data))
boundary(b);shape=[]
for rid in sorted(targets):
    m=methods[rid];ins=m['instructions'];ops=[i['opcode'] for i in ins]
    if rid==0x8e3:assert ops==['ldarg.0','call','ldarg.0','ldsfld','stfld','ldarg.0','ldc.i4.0','stfld','ret']
    elif rid==0x8e4:
        assert ops==['ldarg.0','call','ldarg.1','ldc.i4.0','bge','ldstr','ldstr','newobj','throw','ldarg.0','ldarg.1','brtrue','ldsfld','br','ldarg.1','newarr','stfld','ldarg.0','ldc.i4.0','stfld','ret']
        assert ins[4]['operand']['target']==ins[9]['offset'] and ins[11]['operand']['target']==ins[14]['offset'] and ins[13]['operand']['target']==ins[16]['offset'];assert [ins[k]['operand'] for k in [5,6]]==['capacity','capacity must be >= 0'] and ins[7]['operand']['identity']=='System.Void System.ArgumentOutOfRangeException::.ctor(System.String,System.String)'
    else:assert ops==['ldc.i4.0','newarr','stsfld','ret'] and not m['hasThis']
    for i in ins:
        if i['opcode'] in ['ldsfld','stsfld']:assert i['operand']['identity']=='T[] FTRuntime.Internal.SwfList`1<T>::_emptyData'
        if i['opcode']=='stfld':assert i['operand']['identity'] in ['T[] FTRuntime.Internal.SwfList`1<T>::_data','System.Int32 FTRuntime.Internal.SwfList`1<T>::_size']
        if i['opcode']=='newarr':assert i['operand']['type']=='T'
        if i['opcode']=='call':assert i['operand']['identity']=='System.Void System.Object::.ctor()'
    shape.append(dict(token=m['token'],all_decoded_instructions_checked=True))
controls=[]
for name,at in [('unrelated-body',pp.get_offset_from_rva(pp.net.mdtables.MethodDef.rows[0x526-1].Rva)+12),('old-metadata',pp.get_offset_from_rva(pp.net.struct.MetaDataRva)),('target-maxstack',pp.get_offset_from_rva(pp.net.mdtables.MethodDef.rows[0x8e3-1].Rva)+2),('appended-metadata-string',None)]:
    if name=='appended-metadata-string':
        mat,_,_=meta(b,cp);_,ss=writer.metadata_root(b[mat:mat+cp.net.struct.MetaDataSize]);header=next(h for n,h,_ in ss if n=='#Strings');off=struct.unpack_from('<I',b,mat+header)[0];at=mat+off+1
    bad=bytearray(b);bad[at]^=1
    try:boundary(bad)
    except (AssertionError,ValueError):controls.append(dict(name=name,rejected=True));continue
    raise AssertionError('Raw isolation false accept')
result=dict(scope='INDEPENDENT_ALL_METHODDEF_WHOLE_PREFIX_METADATA_TABLE_AND_CIL_SPECIFICATION',candidate_sha256=sha(b),parent_sha256=sha(a),pass_=True,methoddefs=2317,bodies=2297,changed_methods=3,unchanged_methoddefs=2314,rvas_locals_maxstack_visibility_and_readonly_flags_unchanged=True,old_metadata_all_rows_and_heaps_preserved=True,new_memberrefs=1,new_private_signatures=0,unused_old_code_slots_preserved=True,negative_isolation_controls=controls,shape_rows=shape,whole_game=False);(Q/'ISOLATION-AND-CIL-SPEC.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());(Q/'METHOD-CIL.json').write_bytes((json.dumps(dict(methods=[methods[rid] for rid in sorted(targets)],types=cil['types']),indent=2)+'\n').encode());print(json.dumps({k:v for k,v in result.items() if k!='shape_rows'},indent=2))
