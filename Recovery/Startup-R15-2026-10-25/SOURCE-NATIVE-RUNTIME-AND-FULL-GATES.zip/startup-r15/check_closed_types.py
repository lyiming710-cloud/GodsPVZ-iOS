"""Finite concrete model facts only. Frozen checker and actual DLL unchanged."""
from pathlib import Path
import copy,hashlib,importlib.util,json,re,sys
Q=Path(__file__).resolve().parent;ROOT=Q.parents[2];sys.dont_write_bytecode=True
f=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py';assert hashlib.sha256(f.read_bytes()).hexdigest()=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14';s=importlib.util.spec_from_file_location('frozen',f);v=importlib.util.module_from_spec(s);s.loader.exec_module(v);source=json.loads((Q/'ALL-CIL.json').read_text('utf-8-sig'));targets={0x60008e3,0x60008e4,0x60008f1};results=[];models=[]
for m in source['methods']:
    if int(m['token'],16) not in targets:continue
    for value in ['System.Int32','System.String']:
        def bind(x):
            if isinstance(x,str):return re.sub(r'(?<![\w.])T(?!\w)',value,x)
            if isinstance(x,list):return [bind(a) for a in x]
            if isinstance(x,dict):return {bind(k):bind(a) for k,a in x.items()}
            return x
        d=bind(copy.deepcopy(m));types=bind(copy.deepcopy(source['types']));d['owner']=m['owner']+'<'+value+'>'
        for k in types:
            if k in source['types']:types[k]=copy.deepcopy(source['types'][k])
        if d['owner'] not in types:
            fact=copy.deepcopy(source['types'][m['owner']]);fact.pop('unbound',None);fact.pop('unresolved',None);types[d['owner']]=fact
        try:r=v.verify(d,types)
        except Exception as e:r=dict(token=d['token'],status='FAIL_OR_UNSUPPORTED',error=str(e))
        results.append(dict(r,context=value));models.append((d,types,value))
controls=[]
for name,token,value,alter in [('wrong-closed-receiver','0x060008E3','System.String',lambda d:d.update(owner='FTRuntime.Internal.SwfList`1<System.Int32>')),('wrong-newarr-element','0x060008F1','System.String',lambda d:next(i for i in d['instructions'] if i['opcode']=='newarr')['operand'].update(type='System.Int32')),('wrong-size-width','0x060008E3','System.Int32',lambda d:next(i for i in reversed(d['instructions']) if i['opcode']=='ldc.i4.0').update(opcode='ldc.i8',operand=0))]:
    d,t,_=copy.deepcopy(next(x for x in models if x[0]['token']==token and x[2]==value))
    alter(d)
    try:r=v.verify(d,t);rejected=r['status']!='PASS';why=r
    except Exception as e:rejected=True;why=str(e)
    controls.append(dict(name=name,rejected=rejected,reason=why))
report=dict(scope='UNCHANGED_FROZEN_CHECKER_FINITE_INT32_STRING_CLOSED_MODELS_ONLY',candidate_sha256=hashlib.sha256((Q/'candidate1.dll').read_bytes()).hexdigest(),checker_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),checker_modified=False,global_census_not_overwritten=True,passed=sum(r['status']=='PASS' for r in results),total=len(results),results=results,negative_controls=controls,universal_generic_proof=False);(Q/'CLOSED-TYPES-THREE.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(report,indent=2));assert report['passed']==report['total']==6 and all(r['rejected'] for r in controls)
