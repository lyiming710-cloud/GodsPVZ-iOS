using System.Reflection;using System.Runtime.CompilerServices;using System.Runtime.Loader;using System.Security.Cryptography;using System.Text.Json;
public record struct WideValue(long A,long B,long C);
public class Case{public string name{get;set;}="";public string kind{get;set;}="";public string value_type{get;set;}="";public int capacity{get;set;}public int old_data_length{get;set;}public int seed_size{get;set;}}
public static class Program
{
    static readonly BindingFlags Instance=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance;static readonly BindingFlags Static=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Static;
    static Exception Root(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;return e;}
    static FieldInfo Field(Type t,string n)=>t.GetField(n,Instance|Static)!;
    static Array? ArrayFor(Type t,int n){if(n<0)return null;var a=Array.CreateInstance(t,n);for(int i=0;i<n;i++)a.SetValue(t==typeof(int)?17:t==typeof(string)?"seed":new WideValue(1,2,3),i);return a;}
    static bool Defaults(Array? a){if(a==null)return false;object? z=a.GetType().GetElementType()!.IsValueType?Activator.CreateInstance(a.GetType().GetElementType()!):null;foreach(var x in a)if(!Equals(x,z))return false;return true;}
    public static void Main(string[] args)
    {
        var context=new AssemblyLoadContext("ActualGenericInitializers_"+Guid.NewGuid(),true);var assembly=context.LoadFromAssemblyPath(Path.GetFullPath(args[0]));var def=assembly.GetType("FTRuntime.Internal.SwfList`1",true)!;var rows=new List<object>();var initial=new List<object>();var jit=new List<object>();var closed=new Dictionary<string,Type>();
        foreach(var pair in new[]{("int",typeof(int)),("string",typeof(string)),("wide",typeof(WideValue))})
        {
            var t=def.MakeGenericType(pair.Item2);closed[pair.Item1]=t;string? error=null;int? len=null;bool hasShared=false;try{var shared=(Array?)Field(t,"_emptyData").GetValue(null);len=shared?.Length;hasShared=shared!=null;}catch(Exception e){error=Root(e).GetType().FullName;}initial.Add(new{value_type=pair.Item1,shared_length=len,has_shared=hasShared,error});
            foreach(var m in t.GetConstructors(Instance).Cast<MethodBase>().Append(t.TypeInitializer!)){try{RuntimeHelpers.PrepareMethod(m.MethodHandle);jit.Add(new{token=$"0x{m.MetadataToken:X8}",closed_type=t.ToString(),status="JIT_PREPARED_NO_EXECUTION",il_sha256=Convert.ToHexString(SHA256.HashData(m.GetMethodBody()!.GetILAsByteArray()!)).ToLowerInvariant()});}catch(Exception e){jit.Add(new{token=$"0x{m.MetadataToken:X8}",closed_type=t.ToString(),status="REJECTED",error=Root(e).ToString()});}}
        }
        foreach(var c in JsonSerializer.Deserialize<List<Case>>(File.ReadAllText(args[1]))!)
        {
            Type t=closed[c.value_type],element=t.GenericTypeArguments[0];Array? oldShared=null,oldData=null,data=null,shared=null;object? obj=null;string? error=null,param=null,message=null;int? size=null;
            try
            {
                // Respect the original readonly static field. Its actual type
                // initializer above supplies the legal shared empty array.
                oldShared=(Array?)Field(t,"_emptyData").GetValue(null);obj=RuntimeHelpers.GetUninitializedObject(t);oldData=ArrayFor(element,c.old_data_length);Field(t,"_data").SetValue(obj,oldData);Field(t,"_size").SetValue(obj,c.seed_size);
                // MethodBase.Invoke(target,args) invokes the real constructor on
                // this seeded receiver; no source instructions are re-emitted.
                var ctor=t.GetConstructor(Instance,null,c.kind=="default"?Type.EmptyTypes:new[]{typeof(int)},null)!;ctor.Invoke(obj,c.kind=="default"?Array.Empty<object>():new object[]{c.capacity});
            }catch(Exception e){e=Root(e);error=e.GetType().FullName;if(e is ArgumentOutOfRangeException range){param=range.ParamName;message=range.Message.Split(new[]{'\r','\n'},StringSplitOptions.RemoveEmptyEntries)[0];}}
            try{if(obj!=null){data=(Array?)Field(t,"_data").GetValue(obj);size=(int)Field(t,"_size").GetValue(obj)!;}shared=(Array?)Field(t,"_emptyData").GetValue(null);}catch(Exception e){error??=Root(e).GetType().FullName;}
            rows.Add(new{name=c.name,kind=c.kind,value_type=c.value_type,state=new{size,data_length=data?.Length,data_same_old=ReferenceEquals(data,oldData),data_same_shared=ReferenceEquals(data,shared),shared_same_old=ReferenceEquals(shared,oldShared),shared_length=shared?.Length,all_default=Defaults(data)},error,param,message});
        }
        File.WriteAllText(args[2],JsonSerializer.Serialize(new{scope="ACTUAL_UNMODIFIED_CANDIDATE_CLOSED_GENERIC_METHODS_DIRECT_CLR_INVOCATION",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),reflection_emit_used=false,source_instructions_removed=false,static_field_attributes=Field(closed["int"],"_emptyData").Attributes.ToString(),readonly_static_field_not_modified_by_fixture=true,automatic_initialization=initial,closed_jit=jit,results=rows,unity_execution=false},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{cases=rows.Count}));context.Unload();
    }
}
