"""Read returned runner evidence and rehash every source for the exact fifty batch.

No physical staged DLL is claimed returned. This does not qualify Unity or iOS.
"""
from pathlib import Path, PurePosixPath
import json, tarfile
from archive_support import sha, js, pack, manifest

W = Path(__file__).resolve().parent
R = W.parents[1] / 'audit/repo-native113'
D = R / 'Recovery/Startup-R18-Batch50-2026-10-25'
A = W / 'r18-compiler-run-40172961231'
Q = A / 'startup-r18'
expected = 'a6aa9f91087db194251c4c989fd80ffd982b3b7a59413b0745592bc43b548abb'
head = 'a9fd97253ecb866ee6ac22473f34819f400ea763'
run = 40172961231
meta = json.loads((A/'RUN.json').read_bytes())
assert meta['headSha'] == head and meta['status'] == 'completed' and meta['conclusion'] == 'success'
report = json.loads((Q/'STARTUP-R18-BATCH50-COMPILER-REPORT.json').read_bytes())
assert report['candidate_sha256'] == expected and report['pass'] and report['conversion']['exit_code'] == 0
cpp = json.loads((Q/'ALL-CPP-RESULTS.json').read_bytes())
c = json.loads((Q/'ALL-C-RESULTS.json').read_bytes())
assert len(cpp) == report['cpp']['attempted'] == report['cpp']['passed'] == report['conversion']['total_cpp_count']
assert len(c) == report['c']['attempted'] and cpp and c
assert report['cpp']['failed'] == report['c']['failed'] == 0
assert all(x['file'].endswith('.cpp') for x in cpp) and all(x['file'].endswith('.c') for x in c)
files = {x['file']: x for x in cpp+c}
assert len(files) == len(cpp)+len(c)
found = {}
with tarfile.open(A/'startup-r18-generated.tar.gz', 'r|gz') as t:
    for m in t:
        p = PurePosixPath(m.name)
        assert '..' not in p.parts and not p.is_absolute()
        if not m.isfile() or not m.name.startswith('il2cppOutput/cpp/'):
            continue
        assert p.name in files and p.name not in found and p.suffix in ['.cpp', '.c']
        data = t.extractfile(m).read()
        row = files[p.name]
        assert len(data) == row['bytes'] and sha(data) == row['sha256'] and row['exit_code'] == row['error_count'] == 0
        found[p.name] = dict(file=m.name, bytes=len(data), sha256=sha(data))
assert set(found) == set(files)
staged, items, returned_dlls = [], [], []
with tarfile.open(A/'startup-r18-evidence.tar.gz', 'r|gz') as t:
    for m in t:
        p = PurePosixPath(m.name)
        assert '..' not in p.parts and not p.is_absolute()
        if not m.isfile():
            continue
        data = t.extractfile(m).read()
        if p.suffix == '.dll':
            returned_dlls.append(dict(file=m.name, bytes=len(data), sha256=sha(data)))
        if m.name.endswith('COHERENT-PLAYER-INPUT-ASSEMBLIES.json'):
            value = json.loads(data)
            row = next(x for x in value['files'] if x['name'] == 'GodsPVZRuntime1.dll')
            staged.append(dict(path=m.name, sha256=row['sha256'], bytes=row['bytes'], assemblies=value['count']))
        items.append((m.name.lstrip('./'), data))
assert any(x['sha256'] == expected and x['bytes'] == 21900800 and '/candidate/' in x['path'] for x in staged)
assert any(x['sha256'] == 'ef1992326d1ee494a389bc2c78bdfab131721434c0b08ab5f41dbc3e506c4e48' for x in staged)
damaged = report['damaged_r4_control']
assert sum(x['error_count'] for x in damaged['units']) == 37 and all(x['exit_code'] != 0 for x in damaged['units'])
assert len(report['compiler_controls']) == 6 and all((x['exit_code'] != 0) == x['expected_nonzero'] for x in report['compiler_controls'])
items += [('top-level/'+p.name, p.read_bytes()) for p in sorted(Q.glob('*.json'))]
items += [(p.name, p.read_bytes()) for p in [A/'startup-r18-restore-receipt.json', A/'RUN.json', Path(__file__)]]
pack(D/f'ACTUAL-COMPILER-EVIDENCE-{run}.zip', items)
result = dict(scope='ACTUAL_R18_FIFTY_BATCH_FRESH_IL2CPP_ALL_GENERATED_SOURCES_LINUX_SYNTAX_ONLY', run_id=run,
    url=f'https://github.com/lyiming710-cloud/GodsPVZ-iOS/actions/runs/{run}', source_commit=head,
    candidate_sha256=expected, pass_=True, conversion=report['conversion'], cpp=report['cpp'], c=report['c'],
    compiler_controls=report['compiler_controls'], damaged_r4_errors=37, raw_generated_sources_rehashed=len(found),
    source_rows=[found[k] for k in sorted(found)], raw_staged_manifest_readbacks=staged,
    staged_physical_dlls_returned=returned_dlls, staged_dll_identity_evidence='RUNNER_MANIFEST_READBACK_NOT_PHYSICAL_STAGED_DLL_DOWNLOAD',
    downloaded_archives=[dict(file=p.name, bytes=p.stat().st_size, sha256=sha(p.read_bytes())) for p in A.glob('*.tar.gz')],
    unity_editor=False, apple_compiler=False, linking=False, ipa=None)
js(D/f'ACTUAL-COMPILER-{run}.json', result)
status = json.loads((D/'CURRENT-RESULT.json').read_bytes())
assert status['r18_il2cpp'] == 'NOT_RUN'
status['r18_il2cpp'] = f'PASS_FRESH_LINUX_COMPILER_ONLY_RUN_{run}'
status['r18_linux_all_sources'] = dict(cpp=len(cpp), c=len(c), failed=0, independently_rehashed=len(found))
js(D/'CURRENT-RESULT.json', status)
p = D/'README.md'
text = p.read_text('utf-8')
marker = f'## Actual R18 compiler readback: run {run}'
assert marker not in text
text += f'\n{marker}\n\nExact source commit `{head}` completed fresh R18 IL2CPP conversion and all {len(cpp)} C++/{len(c)} C Linux syntax checks. All {len(found)} returned generated source sizes/hashes were independently rechecked against their zero-error compiler records. The raw runner manifests bind GodsPVZRuntime1.dll to the exact fifty-method candidate and 21,900,800 bytes; these are runner-manifest readbacks, not a physical staged DLL download. All six compiler controls meet expectations and the real damaged R4 control still produces 37 errors. Actual raw logs, sources identities and downloaded archive hashes are retained. No Unity Editor import, Apple compilation, player linking, IPA or iPad acceptance is implied. Wider semantic/type/access queues remain held.\n'
p.write_bytes(text.encode())
manifest(D)
print(json.dumps(dict(run_id=run, pass_=True, cpp=len(cpp), c=len(c), independently_rehashed=len(found), physical_staged_dlls_returned=len(returned_dlls), ipa=None)))
