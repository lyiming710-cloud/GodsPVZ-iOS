"""Enable one shared round only after fifty concrete method changes exist."""
from pathlib import Path
import hashlib,json,shutil
Q=Path(__file__).resolve().parent;W=Q.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
report=json.loads((Q/'CONSTRUCTION.json').read_bytes());repeat=json.loads((Q/'CONSTRUCTION-REPEAT.json').read_bytes())
assert len(report['changes'])==report['new_unique_methods']==50
digest=report['candidate_sha256'];assert sha((Q/'candidate1.dll').read_bytes())==sha((Q/'candidate2.dll').read_bytes())==digest==repeat['candidate_sha256']
assert report['first_fifty_constructed_before_tests'] and not report['tests_run']
old='d2a645ad0d8164af5fbdcbd9fcaa578d5a28b27e7b13f3012cdb51e63a256091';derived=[]
for name in ['full_type_census_r17.py','interface_facts_r17.py','census_lexical_tails.py','full_member_access.py','run_changed_exact_jit.py']:
    src=W/'startup-r17-batch50'/name;b=src.read_bytes();text=b.decode().replace(old,digest).replace('startup-r17-batch50','startup-r18-batch50').replace('candidate3.dll','candidate1.dll')
    dest=Q/name.replace('_r17','_r18');dest.write_bytes(text.encode());derived.append(dict(source=str(src.relative_to(W)),source_sha256=sha(b),derived=str(dest.relative_to(W)),derived_sha256=sha(dest.read_bytes()),changes='Exact candidate/output binding only; checker, failure handling and JIT algorithm unchanged'))
shutil.copy2(W/'startup-r17-batch50/ALL-METHODS.json',Q/'ALL-METHODS.json')
def save(name,obj):(Q/name).write_bytes((json.dumps(obj,indent=2)+'\n').encode())
save('ACTIVE-INPUT.json',dict(candidate_file='candidate1.dll',candidate_sha256=digest,construction='CONSTRUCTION.json',repeat_file='candidate2.dll'))
save('SHARED-TEST-START.json',dict(scope='SHARED_TEST_START_AFTER_FIFTY_NEW_CONSTRUCTIONS',candidate_sha256=digest,constructed_methods=50,source_constructed_before_any_new_test=True,formal_qualified_methods=0))
save('DRIVER-DERIVATION.json',derived)
print(json.dumps(dict(shared_tests_enabled=True,constructed_before_tests=50,candidate_sha256=digest)))
