from pathlib import Path
import itertools,json,struct
Q=Path(__file__).resolve().parent
rows=json.loads((Q/'SOURCE-ROSTER.json').read_bytes())['rows'];cases=[]
bits=lambda x:struct.pack('>f',x).hex().upper()
def add(token,**kw):cases.append(dict(name=f'{token}-{len(cases):05d}',token=token,**kw))
for r in rows:
    t=r['token'];rid=int(t,16)&0xffffff
    if r['group'].startswith('SWF'):
        name=r['name'];arg_type='string_int' if 'System.String,System.Int32)' in name else 'string' if name.endswith('System.String)') else 'bool' if name.endswith('System.Boolean)') else 'int'
        for live,playing,boolean,mask in itertools.product([0,1,2],[False,True],[False,True],[0,1,2,7]):
            add(t,kind='swf',arg_type=arg_type,clip_state=live,playing=playing,arg_bool=boolean,arg_int=-2 if boolean else 7,arg_string='seq-new' if boolean else None,event_mask=mask,manager_state=live,auto_play=True,app_play=True,seq_count=3,flag1=boolean,flag2=playing,flag3=True,mode='none')
        for mode in ['rewind-toggles-play','clip-event-clears-next','controller-event-toggles-play','change-frame-clears-event','manager-flips-auto','app-flips-playing','implicit-replaces-clip']:
            for playing in [False,True]:add(t,kind='swf',arg_type=arg_type,clip_state=1,playing=playing,arg_bool=True,arg_int=4,arg_string='seq-new',event_mask=7,manager_state=1,auto_play=True,app_play=True,seq_count=3,flag1=True,flag2=True,flag3=True,mode=mode)
        if rid==0x83a:
            for count in [-2,-1,0,1,9]:add(t,kind='swf',arg_type=arg_type,clip_state=1,playing=False,arg_bool=True,arg_int=3,arg_string='seq-new',event_mask=7,manager_state=1,seq_count=count,mode='none')
    elif rid==0x4a5:
        for rest,stant,time,delta,mode in itertools.product([False,True],[False,True],[-1,0,9,9.5,10,float('nan')],[0,0.5,1,float('nan')],['none','delta-mutates-rest']):add(t,kind='scalar',rest=rest,stant=stant,rest_time=bits(time),delta=bits(delta),mode=mode)
    elif rid==0x311:
        for id_,occupy,word in itertools.product([0,8,12,99],[-1,0,2,4],[None,'device','plant']):add(t,kind='scalar',device_id=id_,occupy=occupy,target=word,mode='none')
    elif rid==0x719:
        for n,p in itertools.product([-1,0,3,99],[-1,0,2,17]):add(t,kind='scalar',normal_value=n,placeholder_value=p,mode='none')
    elif rid==0x6d7:
        for level,locked,mode in itertools.product([-2147483648,-1,0,1,9,2147483647],[False,True],['none','active-replaces-text']):add(t,kind='scalar',level=level,locked=locked,mode=mode)
    elif rid==0x43c:
        for word,value in itertools.product([None,'body','armor2','other'],[-1,0,1.25,float('nan')]):add(t,kind='scalar',target=word,time=bits(value),intensity=bits(value*2),mode='none')
    elif rid==0x17d:
        for x,y,key,mode in itertools.product([-2147483648,-1,0,2147483647],[-1,5],[None,'','entry-key'],['none','allocation-mutates-entry']):add(t,kind='scalar',grid_x=x,grid_y=y,entry=key,mode=mode)
    elif rid==0x380:
        for order,health,mode in itertools.product([-1,0,1,2],[-5,0,100,float('nan')],['none','animator-flips-order']):add(t,kind='scalar',order=order,health=bits(health),mode=mode)
    elif rid==0x59b:
        for index in [-1,0,1,2]:add(t,kind='scalar',index=index,mode='none')
    elif rid==0x569:
        for index,mode in itertools.product([0,1,2,3],['none','state-mutates-id']):add(t,kind='scalar',index=index,mode=mode)
    elif rid==0x344:
        for value,mode in itertools.product([-1,0,0.5,float('nan')],['none','material-replaces-renderer']):add(t,kind='scalar',intensity=bits(value),mode=mode)
    else:
        for jump in [False,True]:add(t,kind='scalar',test_jump=jump,mode='none')
assert len({c['token'] for c in cases})==50
(Q/'CASES.json').write_bytes((json.dumps(cases,indent=2)+'\n').encode())
print(json.dumps(dict(methods=50,records=len(cases),swf=sum(c['kind']=='swf' for c in cases),scalar=sum(c['kind']=='scalar' for c in cases))))
