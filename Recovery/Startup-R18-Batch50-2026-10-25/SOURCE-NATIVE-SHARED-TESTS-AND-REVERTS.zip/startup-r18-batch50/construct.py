"""Construct fifty complete/native-backed method changes before shared testing."""
from pathlib import Path
import importlib.util, json, struct, sys
import source_common as s
Q=s.Q;W=s.W;sha=s.sha
def mod(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
writer=mod('metadata_writer_r18',W/'startup-r2/construct.py')
labels=mod('il_builder_r18',W/'startup-r13/construct.py')
class IL(labels.IL):
    def arg(self,n):return self.emit(bytes([2+n])) if n<4 else self.emit(bytes([0x0e,n]))
    def addr(self,n):return self.emit(bytes([0x0f,n]))
    def loca(self,n):return self.emit(bytes([0x12,n]))

def build(output,report_path):
    output=Path(output);report_path=Path(report_path)
    assert not output.exists() and not report_path.exists()
    before=s.parent;pe=s.pe;out=bytearray(before)
    roster=json.loads((Q/'SOURCE-ROSTER.json').read_bytes())
    assert len(roster['rows'])==50 and len({r['token'] for r in roster['rows']})==50
    cli=pe.get_offset_from_rva(pe.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress)
    mrva,msize=struct.unpack_from('<II',before,cli+8);mat=pe.get_offset_from_rva(mrva)
    root,streams=writer.metadata_root(before[mat:mat+msize]);values={n:b for n,_,b in streams}
    th,rows,tail,counts=writer.tables_decode(values['#~']);new_refs=[];changes=[];allowed=set()
    field_tokens={};method_tokens={}
    for token,m in s.methods.items():
        for ins in m['instructions']:
            v=ins['operand']
            if ins['opcode'] in ['ldfld','ldsfld','stfld','stsfld','ldflda','ldsflda']:
                field_tokens.setdefault((v['owner'],v['identity'].rsplit('::',1)[-1]),s.operand_token(token,ins))
            if ins['opcode'] in ['call','callvirt','newobj']:
                method_tokens.setdefault((v['owner'],v['name'],tuple(v['args'])),s.operand_token(token,ins))
    def fld(owner,name):
        if (owner,name) in field_tokens:return field_tokens[(owner,name)]
        # A genuinely lost field load has no surviving CIL instruction to copy.
        hits=[r for r in s.field_rows if (r['namespace']+'.' if r['namespace'] else '')+r['type']==owner and r['name']==name]
        assert len(hits)==1,(owner,name)
        token=int(hits[0]['token'],16);assert str(pe.net.mdtables.Field.rows[(token&0xffffff)-1].Name)==name
        field_tokens[(owner,name)]=token;return token
    def meth(owner,name,args=()):
        hits=[int(t,16) for t,m in s.methods.items() if m['owner']==owner and str(pe.net.mdtables.MethodDef.rows[(int(t,16)&0xffffff)-1].Name)==name and m['args']==list(args)]
        assert len(hits)<=1
        return hits[0] if hits else method_tokens[(owner,name,tuple(args))]
    def name_index(name):
        v=name.encode()+b'\0';at=values['#Strings'].find(v)
        if at>=0 and (at==0 or values['#Strings'][at-1]==0):return at
        at=len(values['#Strings']);values['#Strings']+=v;return at
    def public_ref(owner,name,signature):
        tr=next(k for k,r in enumerate(pe.net.mdtables.TypeRef.rows,1) if str(r.TypeNamespace)+'.'+str(r.TypeName)==owner)
        coded=(tr<<3)|1
        for k,r in enumerate(pe.net.mdtables.MemberRef.rows,1):
            if rows[10][k-1][0]==coded and str(r.Name)==name and r.Signature.value==signature:return 0xa000000|k
        sig=next((rows[10][k-1][2] for k,r in enumerate(pe.net.mdtables.MemberRef.rows,1) if r.Signature.value==signature),None)
        if sig is None:
            sig=len(values['#Blob']);values['#Blob']+=labels.comp(len(signature))+signature
        rows[10].append([coded,name_index(name),sig]);token=0xa000000|len(rows[10]);new_refs.append(dict(token=f'0x{token:08X}',owner=owner,name=name,signature=signature.hex()));return token
    renderer_get=public_ref('UnityEngine.Renderer','get_material',pe.net.mdtables.MemberRef.rows[(meth('UnityEngine.Renderer','GetMaterial')&0xffffff)-1].Signature.value)
    dropdown_get=public_ref('TMPro.TMP_Dropdown','get_value',bytes.fromhex('200008'))
    def text(token,value):
        found=[i for i in s.methods[token]['instructions'] if i['opcode']=='ldstr' and i['operand']==value];assert found,(token,value)
        return s.operand_token(token,found[0])
    def bool_local(m):return m['locals'].index('System.Boolean')
    def receiver_field(b,owner,name):return b.arg(0).token(0x7b,fld(owner,name))
    def set_arg_field(b,owner,name,arg):return b.arg(0).arg(arg).token(0x7d,fld(owner,name))
    clip='FTRuntime.SwfClip';ctrl='FTRuntime.SwfClipController';manager='FTRuntime.SwfManager'
    clip_invoke=meth('System.Action`1<FTRuntime.SwfClip>','Invoke',[clip])
    ctrl_invoke=meth('System.Action`1<FTRuntime.SwfClipController>','Invoke',[ctrl])
    implicit=meth('UnityEngine.Object','op_Implicit',['UnityEngine.Object'])
    def invoke_event(b,owner,name,tag):
        receiver_field(b,owner,name).branch(0x39,tag)
        receiver_field(b,owner,name).arg(0).token(0x6f,clip_invoke if owner==clip else ctrl_invoke).mark(tag)
        return b
    def sequence_if_live(b):
        receiver_field(b,ctrl,'_clip').token(0x28,implicit).branch(0x39,'after_sequence')
        receiver_field(b,ctrl,'_clip').arg(1).token(0x6f,meth(clip,'set_sequence',['System.String'])).mark('after_sequence')
        return b
    def transition(b,want,local,rewind_arg=None):
        receiver_field(b,ctrl,'_isPlaying').store(local).loc(local).branch(0x3a if want else 0x39,'after_transition')
        b.arg(0).i4(int(want)).token(0x7d,fld(ctrl,'_isPlaying')).arg(0).r4(0).token(0x7d,fld(ctrl,'_tickTimer')).mark('after_transition')
        if rewind_arg is not None:b.arg(rewind_arg).branch(0x39,'after_rewind').arg(0).token(0x28,meth(ctrl,'Rewind')).mark('after_rewind')
        b.loc(local).branch(0x3a if want else 0x39,'end_transition_event')
        invoke_event(b,ctrl,'OnPlayStoppedEvent' if want else 'OnStopPlayingEvent','end_transition_event')
        return b
    base_ctor=meth('System.Object','.ctor')
    for item in roster['rows']:
        token=item['token'];rid=int(token,16)&0xffffff;m=s.methods[token];slot=s.body(token)
        assert not m['handlers'] and slot['header']==12
        old=slot['code'];b=IL();needed=m['maxStack'];kind='COMPLETE_BODY';why=''
        if 0x8aa<=rid<=0x8b9:
            action=m['name'].split('::')[1].split('(')[0]
            name='Stop' if action=='StopAndWaitPlay' else 'GotoAndStop' if action.startswith('GotoAndStop') else 'GotoAndPlay' if action.startswith('GotoAndPlay') else 'Play'
            for n in range(len(m['args'])):b.arg(n)
            b.token(0x6f,meth(ctrl,name,m['args'][1:])).arg(0)
            ctor=next(i for i in m['instructions'] if i['opcode']=='newobj' and i['operand']['owner']==m['ret'])
            b.token(0x73,s.operand_token(token,ctor)).op('2a');needed=max(2,len(m['args']));why='Restore one action, then one wait constructor(controller); no duplicate private Subscribe.'
        elif rid in [0x82f,0x831,0x839,0x83a,0x847,0x84a]:
            code=bytearray(old);used=[]
            for k,i in enumerate(m['instructions']):
                if i['opcode']!='ldstr' or not str(i['operand']).startswith('Indirect call:'):continue
                prev=m['instructions'][k-1];nxt=m['instructions'][k+1]
                assert prev['opcode']=='stloc' and nxt['opcode']=='pop' and i['offset']==prev['offset']+4
                local=prev['operand']['index'];assert not any(x['opcode'].startswith('ldloc') and x['operand']==dict(index=local) for x in m['instructions'])
                at=prev['offset'];end=nxt['offset']+1;replacement=IL().arg(0).token(0x6f,clip_invoke).finish();assert end-at==10
                code[at:end]=replacement+b'\0'*(end-at-len(replacement));used.append(dict(start=at,end=end,old=old[at:end].hex(),new=bytes(code[at:end]).hex()))
            assert used;b.emit(code);kind='FIXED_WIDTH_LOST_DELEGATE_BLOCKS';why='Restore original Action<SwfClip>.Invoke(this) at each lost indirect-call block; all branch/EH offsets are preserved.'
        elif rid in [0x86e,0x870,0x872,0x874]:
            sequence_if_live(b)
            b.arg(0)
            if rid in [0x86e,0x870]:b.arg(2).token(0x28,meth(ctrl,'GotoAndStop' if rid==0x86e else 'GotoAndPlay',['System.Int32']))
            else:b.i4(1).token(0x28,meth(ctrl,'Stop' if rid==0x872 else 'Play',['System.Boolean']))
            b.op('2a');needed=2;why='Recover valid external tail to the integer/bool overload after conditional sequence assignment.'
        elif rid in [0x871,0x873]:
            transition(b,rid==0x873,bool_local(m),1).op('2a');needed=2;why='Capture playing state before writes and Rewind; transition event uses that captured state.'
        elif rid in [0x86d,0x86f]:
            receiver_field(b,ctrl,'_clip').token(0x28,implicit).branch(0x39,'after_frame')
            receiver_field(b,ctrl,'_clip').arg(1).token(0x6f,meth(clip,'set_currentFrame',['System.Int32'])).mark('after_frame')
            transition(b,rid==0x86f,bool_local(m)).op('2a');needed=2;why='Call the legal public frame setter, retaining frame-event order before playing-state transition.'
        elif rid in [0x84b,0x84c,0x87a,0x87b]:
            enabled=rid in [0x84b,0x87a];controller=rid in [0x87a,0x87b]
            if rid==0x87b:b.arg(0).i4(0).token(0x28,meth(ctrl,'Stop',['System.Boolean']))
            local=m['locals'].index(manager)
            b.i4(int(enabled)).token(0x28,meth(manager,'GetInstance',['System.Boolean'])).store(local).loc(local).token(0x28,implicit).branch(0x39,'registered')
            b.loc(local).arg(0).token(0x6f,meth(manager,('Add' if enabled else 'Remove')+('Controller' if controller else 'Clip'),[ctrl if controller else clip])).mark('registered')
            if rid==0x87a:
                receiver_field(b,ctrl,'_autoPlay').branch(0x39,'done').token(0x28,meth('UnityEngine.Application','get_isPlaying')).branch(0x39,'done')
                b.arg(0).i4(0).token(0x28,meth(ctrl,'Play',['System.Boolean'])).mark('done')
            b.op('2a');needed=2;why='Use legal manager registration methods; preserve controller stop-before-unregister and register-before-autoplay order.'
        elif rid in [0x4b4,0x497,0x4a0]:
            receiver_field(b,'Zombie','animator')
            if rid!=0x4b4:b.arg(0).i4(1).token(0x7d,fld('Zombie','ladderZombie_place' if rid==0x497 else 'poleZombie_jump'))
            value='WheelSpeed' if rid==0x4b4 else 'PlaceTrigger' if rid==0x497 else 'JumpTrigger';b.token(0x72,text(token,value))
            if rid==0x4b4:b.r4(0).token(0x6f,meth('UnityEngine.Animator','SetFloat',['System.String','System.Single']))
            else:b.token(0x6f,meth('UnityEngine.Animator','SetTrigger',['System.String']))
            b.op('2a');needed=3;why='Remove fabricated metadata-pointer logic and retain native animator capture, state write and trigger order.'
        elif rid==0x77c:
            strings=[i for i in m['instructions'] if i['opcode']=='ldstr' and not str(i['operand']).startswith('Unmanaged')];assert len(strings)==2
            for field,i in zip(['label01','label02'],strings):b.arg(0).token(0x72,s.operand_token(token,i)).token(0x7d,fld(m['owner'],field))
            b.arg(0).token(0x28,meth('UnityEngine.MonoBehaviour','.ctor')).op('2a');needed=2;why='Restore literal field initialization before the actual MonoBehaviour base constructor.'
        elif rid==0x344:
            for field in ['spriteRenderer0','spriteRenderer1']:
                receiver_field(b,m['owner'],field).token(0x6f,renderer_get).token(0x72,text(token,'_Brightness')).arg(1).token(0x6f,meth('UnityEngine.Material','SetFloat',['System.String','System.Single']))
            b.op('2a');needed=3;why='Use the public material getter with the same player GetMaterial contract and preserve sequential renderer reloads.'
        elif rid==0x59b:
            receiver_field(b,m['owner'],'talentDescription').arg(1).i4(-1).branch(0x3b,'default')
            receiver_field(b,m['owner'],'plantSave').token(0x7b,fld('PlantSave','talents')).arg(1).op('9a').branch(0x38,'apply')
            default=next(i for i in m['instructions'] if i['opcode']=='ldstr' and not str(i['operand']).startswith('Unmanaged'))
            b.mark('default').token(0x72,s.operand_token(token,default)).mark('apply').i4(1).token(0x6f,meth('TMPro.TMP_Text','SetText',['System.String','System.Boolean'])).op('2a');needed=3;why='Capture text receiver before plant-save/array reads, preserving native argument and exception order.'
        elif rid==0x6d7:
            receiver_field(b,m['owner'],'text_Level').token(0x6f,meth('UnityEngine.Component','get_gameObject')).arg(2).i4(1).op('61').token(0x6f,meth('UnityEngine.GameObject','SetActive',['System.Boolean']))
            receiver_field(b,m['owner'],'text_Level').token(0x72,text(token,'Lv.')).addr(3).token(0x28,meth('System.Int32','ToString')).token(0x28,meth('System.String','Concat',['System.String','System.String'])).i4(1).token(0x6f,meth('TMPro.TMP_Text','SetText',['System.String','System.Boolean']))
            b.arg(0).arg(1).arg(2).token(0x28,meth(m['owner'],'LoadSprite',['UnityEngine.Sprite','System.Boolean'])).op('2a');needed=4;why='Use the actual level argument, not an uninitialized Int32 local; capture the reloaded text receiver before formatting.'
        elif rid==0x380:
            receiver_field(b,'Plant','animator').token(0x72,text(token,'DevourTrigger')).token(0x6f,meth('UnityEngine.Animator','SetTrigger',['System.String']))
            b.arg(0).i4(1).token(0x7d,fld('Plant','pC_chomperviking_devour')).arg(1).branch(0x3a,'zombie_present')
            b.token(0x73,meth('System.NullReferenceException','.ctor')).op('7a').mark('zombie_present')
            receiver_field(b,'Plant','order').i4(1).branch(0x3f,'destroy').arg(0).arg(1).token(0x7b,fld('Zombie','healthPoint')).r4(0.4).op('5a')
            receiver_field(b,'Plant','pT_chomperviking_devourPoint').op('58').token(0x7d,fld('Plant','pT_chomperviking_devourPoint'))
            b.mark('destroy').arg(1).token(0x6f,meth('Zombie','DestroyZombie')).op('2a');needed=3;why='Restore native null-throw point and float32 devour accumulation before destruction.'
        elif rid==0x719:
            receiver_field(b,m['owner'],'text');receiver_field(b,m['owner'],'dropdownWithPlaceholder').token(0x6f,dropdown_get).i4(-1).branch(0x3e,'error')
            b.token(0x72,text(token,'Selected values:\n'));receiver_field(b,m['owner'],'dropdownWithoutPlaceholder').token(0x6f,dropdown_get).store(9).loca(9).token(0x28,meth('System.Int32','ToString'))
            b.token(0x72,text(token,' - '));receiver_field(b,m['owner'],'dropdownWithPlaceholder').token(0x6f,dropdown_get).store(9).loca(9).token(0x28,meth('System.Int32','ToString')).token(0x28,meth('System.String','Concat',['System.String']*4)).branch(0x38,'set_text')
            b.mark('error').token(0x72,text(token,'Error: Please make a selection')).mark('set_text').token(0x6f,meth('TMPro.TMP_Text','set_text',['System.String'])).op('2a');needed=5;why='Use public dropdown values and both actual selections; retain initial text capture and the later placeholder reload.'
        elif rid==0x311:
            receiver_field(b,'Device','ID').op('25').i4(8).branch(0x3b,'id8').i4(12).branch(0x3b,'id12').i4(1).op('2a')
            b.mark('id8').op('26').arg(1).i4(2).op('fe0116fe012a').mark('id12').arg(2).token(0x72,text(token,'device')).token(0x28,meth('System.String','op_Equality',['System.String','System.String'])).op('16fe012a');needed=3;why='Restore a single native ID read and exact occupied/device-string decisions.'
        elif rid==0x43c:
            for word,fields in [('body',['brightEffectTime','brightTime','brightIntensity']),('armor2',['brightEffectTime_Armor2','brightTime_Armor2','brightIntensity_Armor2'])]:
                b.arg(3).token(0x72,text(token,word)).token(0x28,meth('System.String','op_Equality',['System.String','System.String'])).branch(0x39,'after_'+word)
                for name,arg in zip(fields,[1,1,2]):set_arg_field(b,'Zombie',name,arg)
                b.mark('after_'+word)
            b.op('2a');needed=2;why='Restore both independent native string decisions and ordered float assignments.'
        elif rid==0x4a5:
            receiver_field(b,'Zombie','snowbeast_isRest').branch(0x3a,'tick');receiver_field(b,'Zombie','isStant').branch(0x39,'done')
            b.mark('tick');receiver_field(b,'Zombie','snowbeast_restTime').token(0x28,meth('UnityEngine.Time','get_deltaTime')).op('58').store(4)
            b.arg(0).loc(4).token(0x7d,fld('Zombie','snowbeast_restTime')).loc(4).r4(10).branch(0x44,'done')
            receiver_field(b,'Zombie','animator').arg(0).r4(10).token(0x7d,fld('Zombie','snowbeast_restTime')).arg(0).i4(0).token(0x7d,fld('Zombie','snowbeast_isRest')).token(0x72,text(token,'rest')).i4(0).token(0x6f,meth('UnityEngine.Animator','SetBool',['System.String','System.Boolean'])).mark('done').op('2a');needed=3;why='Capture old rest time before deltaTime; unordered/NaN follows the native JB return path, then preserve animator capture before state reset.'
        elif rid==0x17d:
            b.arg(0).token(0x7e,fld('System.String','Empty')).token(0x7d,fld('PreDevice','entryKey')).arg(0).i4(-1).token(0x73,meth('DeviceData','.ctor',['System.Int32'])).token(0x7d,fld('PreDevice','data')).arg(0).token(0x28,base_ctor)
            for name,arg in [('gridX',1),('gridY',2),('data',3),('entryKey',4)]:set_arg_field(b,'PreDevice',name,arg)
            b.op('2a');needed=2;why='Preserve the overwritten default DeviceData(-1) allocation and base call, then store the actual fourth entry-key argument.'
        elif rid==0x2d2:
            b.arg(0).token(0x28,base_ctor)
            for name in ['cardPlantType','cardDeviceType']:b.arg(0).i4(-1).token(0x7d,fld('PreCard',name))
            b.arg(0).token(0x73,meth('PreCard/PlantData','.ctor')).token(0x7d,fld('PreCard','plantData')).arg(0).token(0x73,meth('Card/CardDeviceData','.ctor')).token(0x7d,fld('PreCard','deviceData')).op('2a');needed=2;why='Restore Object constructor and Int32 enum sentinels; reuse the real nested constructors that initialize camp/number once.'
        elif rid==0x569:
            set_arg_field(b,m['owner'],'deviceID',2).arg(0).arg(1).token(0x7b,fld('Save','almanac_DeviceLock')).arg(2).op('91').token(0x28,meth(m['owner'],'SetState',['System.Boolean']))
            b.arg(0).arg(2).token(0x28,meth('ResourceManager','Load_deviceInfo',['System.Int32'])).token(0x7d,fld(m['owner'],'deviceInfo')).op('2a');needed=4;why='Restore the actual Boolean array element and original index/null exceptions before resource loading.'
        elif rid==0x4a4:
            b.arg(0).token(0x28,meth('Zombie','ZC_PoleTestJump')).branch(0x39,'done').arg(0).token(0x28,meth('Zombie','ZC_PoleJump')).mark('done').op('2a');needed=1;why='Restore conditional jump test and its original inlined jump-start body via the same repaired method.'
        else:raise ValueError(token)
        code=b.finish();assert len(code)<=len(old) and code!=old,(token,len(code),len(old))
        at=slot['offset'];h=slot['header'];out[at+h:at+h+len(code)]=code;allowed.update(range(at+h,at+h+len(code)))
        maxstack=max(m['maxStack'],needed)
        if len(code)!=len(old):struct.pack_into('<I',out,at+4,len(code));allowed.update(range(at+4,at+8))
        if maxstack!=m['maxStack']:struct.pack_into('<H',out,at+2,maxstack);allowed.update(range(at+2,at+4))
        changes.append(dict(token=token,name=m['name'],group=item['group'],kind=kind,reason=why,rva=hex(pe.net.mdtables.MethodDef.rows[rid-1].Rva),file_offset=at,old_code_size=len(old),new_code_size=len(code),old_maxstack=m['maxStack'],new_maxstack=maxstack,old_code_sha256=sha(old),new_code_sha256=sha(code),new_code=code.hex(),source_native_entry=item['native_entry'],qualification='CONSTRUCTED_UNTESTED'))
    assert len(changes)==len({r['token'] for r in changes})==50
    values['#~']=writer.tables_encode(th,rows,tail,counts);metadata=bytearray(root)
    for name,header,_ in streams:
        start=writer.align(len(metadata),4);metadata.extend(b'\0'*(start-len(metadata)));struct.pack_into('<II',metadata,header,start,len(values[name]));metadata.extend(values[name])
    last=pe.sections[-1];assert last.Name.rstrip(b'\0')==b'.n29meta' and last.Characteristics==0x40000040 and last.PointerToRawData+last.SizeOfRawData==len(before)
    start=writer.align(len(out),4);out.extend(b'\0'*(start-len(out)));out.extend(metadata);end=len(out)
    raw_size=writer.align(end-last.PointerToRawData,pe.OPTIONAL_HEADER.FileAlignment);out.extend(b'\0'*(last.PointerToRawData+raw_size-len(out)))
    sh=last.get_file_offset();opt=pe.OPTIONAL_HEADER.get_file_offset();updates={sh+8:end-last.PointerToRawData,sh+16:raw_size,opt+8:pe.OPTIONAL_HEADER.SizeOfInitializedData+raw_size-last.SizeOfRawData,opt+56:writer.align(last.VirtualAddress+end-last.PointerToRawData,pe.OPTIONAL_HEADER.SectionAlignment),opt+64:0,cli+8:last.VirtualAddress+start-last.PointerToRawData,cli+12:len(metadata)}
    for at,value in updates.items():struct.pack_into('<I',out,at,value);allowed.update(range(at,at+4))
    assert all(x==y or i in allowed for i,(x,y) in enumerate(zip(before,out)))
    output.write_bytes(out)
    report=dict(scope='FIFTY_NEW_METHODS_CONSTRUCTED_BEFORE_ANY_NEW_SHARED_TEST',parent_sha256=sha(before),candidate_sha256=sha(out),bytes=len(out),new_unique_methods=50,unchanged_methoddefs_expected=2267,new_memberrefs=new_refs,changes=changes,header_updates=updates,tests_run=False,first_fifty_constructed_before_tests=True,qualified_methods=0,unity_or_ipa=False)
    report_path.write_bytes((json.dumps(report,indent=2)+'\n').encode());(Q/'METHODS.json').write_bytes((json.dumps(dict(methods=[dict(token=r['token']) for r in changes]),indent=2)+'\n').encode())
    print(json.dumps({k:v for k,v in report.items() if k not in ['changes','header_updates']},indent=2))
if __name__=='__main__':build(sys.argv[1],sys.argv[2])
