"""Fifty physical historical-body reversions; retain complementary detections."""
from pathlib import Path
import collections,concurrent.futures,hashlib,importlib.util,json,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1]
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
sha=lambda b:hashlib.sha256(b).hexdigest()
base=(Q/'candidate1.dll').read_bytes();parent=(W/'startup-r17-batch50/candidate3.dll').read_bytes()
assert sha(base)=='a6aa9f91087db194251c4c989fd80ffd982b3b7a59413b0745592bc43b548abb'
meta=dnfile.dnPE(data=parent);O=Q/'physical-reverts';O.mkdir(exist_ok=True)
roster=json.loads((Q/'SOURCE-ROSTER.json').read_bytes())['rows'];cases=json.loads((Q/'CASES.json').read_bytes());expected={x['name']:x for x in json.loads((Q/'ORIGINAL-NATIVE.json').read_bytes())['results']}
f=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py';assert sha(f.read_bytes())=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14'
sp=importlib.util.spec_from_file_location('frozen_physical',f);v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
types=json.loads((Q/'ALL-CIL-WITH-INTERFACE-FACTS.json').read_bytes())['types']
dot=ROOT/'.local/dotnet10/dotnet.exe';exporter=ROOT/'audit/bulk250-r1-evidence-39702928368/bulk250-r1-run/tools_bin/CilExporter/bin/CilExporter.dll';support=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support';access=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/member-bin/MemberAccess.dll';fixture=Q/'runtime/bin/Release/net10.0/Fixture.dll'
def one(r):
    token=r['token'];rid=int(token,16)&0xffffff;row=meta.net.mdtables.MethodDef.rows[rid-1];at=meta.get_offset_from_rva(row.Rva)
    import struct
    h=(struct.unpack_from('<H',parent,at)[0]>>12)*4;n=struct.unpack_from('<I',parent,at+4)[0];assert h==12
    data=bytearray(base);data[at:at+h+n]=parent[at:at+h+n];p=O/(token+'.dll');p.write_bytes(data)
    local=[x for x in cases if x['token']==token];casepath=Q/('REVERT-CASES-'+token+'.json');casepath.write_bytes((json.dumps(local,indent=2)+'\n').encode())
    outfile=O/(token+'.runtime.json');run=subprocess.run([str(dot),str(fixture),str(p),str(casepath),str(outfile)],capture_output=True,timeout=60)
    (O/(token+'.runtime.log')).write_bytes(run.stdout+run.stderr)
    if run.returncode or not outfile.exists():runtime=dict(status='PROCESS_FAILURE_NOT_A_SEMANTIC_PASS',exit_code=run.returncode,different=None)
    else:
        value=json.loads(outfile.read_bytes());assert value['candidate_sha256']==sha(data);bad=[dict(original=expected[x['name']],actual=x) for x in value['results'] if expected[x['name']]!=x]
        runtime=dict(status='DIFFERENCE_DETECTED' if bad else 'NO_RUNTIME_DIFFERENCE',records=len(value['results']),different=len(bad));(O/(token+'.differences.json')).write_bytes((json.dumps(bad,indent=2)+'\n').encode())
    target=O/(token+'.cil.json');run=subprocess.run([str(dot),str(exporter),str(p),str(target),str(support),token],capture_output=True,timeout=30);(O/(token+'.export.log')).write_bytes(run.stdout+run.stderr);assert run.returncode==0
    method=json.loads(target.read_bytes())['methods'];assert len(method)==1
    try:frozen=v.verify(method[0],types)
    except Exception as e:frozen=dict(status='FAIL_OR_UNSUPPORTED',error=str(e))
    select=O/(token+'.methods.json');select.write_text(json.dumps(dict(methods=[dict(token=token)])))
    output=O/(token+'.access.json');run=subprocess.run([str(dot),str(access),str(p),str(support),str(select),str(output)],capture_output=True,timeout=30);(O/(token+'.access.log')).write_bytes(run.stdout+run.stderr);ar=json.loads(output.read_bytes());assert run.returncode in [0,2]
    forbidden=[x for x in ar['members'] if not x['allowed']];assert run.returncode==(2 if forbidden else 0)
    result=dict(token=token,physical_sha256=sha(data),reverted_only_header_and_original_body=True,runtime=runtime,frozen=frozen,access_actual_exit=run.returncode,access_rejected=len(forbidden),detected=runtime['status']=='DIFFERENCE_DETECTED' or frozen['status']!='PASS' or bool(forbidden))
    (O/(token+'.RESULT.json')).write_bytes((json.dumps(result,indent=2)+'\n').encode());return result
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(one,roster))
result=dict(scope='FIFTY_PHYSICAL_HISTORICAL_BODY_REVERT_CONTROLS_WITH_UNCHANGED_FROZEN_AND_ACCESS_GATES',candidate_sha256=sha(base),controls=len(results),all_detected=all(r['detected'] for r in results),runtime_detected=sum(r['runtime']['status']=='DIFFERENCE_DETECTED' for r in results),runtime_no_difference=sum(r['runtime']['status']=='NO_RUNTIME_DIFFERENCE' for r in results),runtime_process_failures=sum(r['runtime']['status']=='PROCESS_FAILURE_NOT_A_SEMANTIC_PASS' for r in results),frozen_rejected=sum(r['frozen']['status']!='PASS' for r in results),access_rejected=sum(r['access_rejected']>0 for r in results),rows=results)
(Q/'PHYSICAL-REVERT-CONTROLS.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2));assert result['all_detected'] and not result['runtime_process_failures']
