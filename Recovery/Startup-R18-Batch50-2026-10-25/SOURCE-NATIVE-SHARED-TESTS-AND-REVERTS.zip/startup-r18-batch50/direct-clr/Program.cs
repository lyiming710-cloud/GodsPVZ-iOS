using System.Reflection;using System.Runtime.CompilerServices;using System.Runtime.Loader;using System.Security.Cryptography;using System.Text.Json;
public static class Program
{
    const BindingFlags BF=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance|BindingFlags.Static;
    static FieldInfo F(Type t,string n)=>t.GetField(n,BF)!;
    static string Bits(float x)=>float.IsNaN(x)?"NaN":BitConverter.SingleToUInt32Bits(x).ToString("X8");
    static float Float(JsonElement c,string n,float d)=>c.TryGetProperty(n,out var x)?BitConverter.UInt32BitsToSingle(Convert.ToUInt32(x.GetString(),16)):d;
    static string? S(JsonElement c,string n)=>c.TryGetProperty(n,out var x)&&x.ValueKind!=JsonValueKind.Null?x.GetString():null;
    static int N(JsonElement c,string n)=>c.GetProperty(n).GetInt32();
    static Exception Root(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;return e;}
    static object Make(Assembly a,string type)=>RuntimeHelpers.GetUninitializedObject(a.GetType(type.Replace('/','+'),true)!);
    public static void Main(string[] args)
    {
        var alc=new AssemblyLoadContext("R18ActualDll_"+Guid.NewGuid(),true);string support=Path.GetFullPath(args[1]);alc.Resolving+=(c,n)=>{foreach(string ext in new[]{".dll",".exe"}){string path=Path.Combine(support,n.Name+ext);if(!File.Exists(path))continue;if(AssemblyName.GetAssemblyName(path).FullName!=n.FullName)throw new FileLoadException("Identity mismatch "+path);return c.LoadFromAssemblyPath(path);}return null;};var a=alc.LoadFromAssemblyPath(Path.GetFullPath(args[0]));
        var expected=JsonDocument.Parse(File.ReadAllText(args[3])).RootElement.GetProperty("results").EnumerateArray().ToDictionary(x=>x.GetProperty("name").GetString()!,x=>x.GetProperty("state"));
        var rows=new List<object>();int failures=0;
        foreach(var c in JsonDocument.Parse(File.ReadAllText(args[2])).RootElement.EnumerateArray())
        {
            int token=Convert.ToInt32(c.GetProperty("token").GetString(),16),rid=token&0xffffff;if(rid is not(0x311 or 0x43c or 0x17d or 0x2d2)||S(c,"mode")!="none")continue;
            string name=c.GetProperty("name").GetString()!;var original=expected[name];var values=new Dictionary<string,object?>();string? error=null;bool pass=false;
            try
            {
                var method=a.ManifestModule.ResolveMethod(token)!;Type owner=method.DeclaringType!;object self=RuntimeHelpers.GetUninitializedObject(owner);
                if(rid==0x311){F(owner,"ID").SetValue(self,N(c,"device_id"));object occupy=Enum.ToObject(method.GetParameters()[0].ParameterType,N(c,"occupy"));values["result"]=method.Invoke(self,new[]{occupy,S(c,"target")});}
                else if(rid==0x43c){F(owner,"snowbeast_restTime").SetValue(self,9.5f);method.Invoke(self,new object?[]{Float(c,"time",1.25f),Float(c,"intensity",2.5f),S(c,"target")});foreach(var (key,field) in new[]{("body_effect","brightEffectTime"),("body_time","brightTime"),("body_intensity","brightIntensity"),("armor_effect","brightEffectTime_Armor2"),("armor_time","brightTime_Armor2"),("armor_intensity","brightIntensity_Armor2")})values[key]=Bits((float)F(owner,field).GetValue(self)!);}
                else if(rid==0x17d){F(owner,"gridX").SetValue(self,99);F(owner,"gridY").SetValue(self,98);F(owner,"entryKey").SetValue(self,"before");object supplied=Make(a,"DeviceData");method.Invoke(self,new object?[]{N(c,"grid_x"),N(c,"grid_y"),supplied,S(c,"entry")});values["x"]=F(owner,"gridX").GetValue(self);values["y"]=F(owner,"gridY").GetValue(self);values["key"]=F(owner,"entryKey").GetValue(self);values["data"]=ReferenceEquals(F(owner,"data").GetValue(self),supplied)?"supplied":"WRONG_IDENTITY";}
                else {method.Invoke(self,null);values["plant_type"]=Convert.ToInt32(F(owner,"cardPlantType").GetValue(self));values["device_type"]=Convert.ToInt32(F(owner,"cardDeviceType").GetValue(self));values["plant_data"]=F(owner,"plantData").GetValue(self)!=null;object data=F(owner,"deviceData").GetValue(self)!;values["camp"]=Convert.ToInt32(F(data.GetType(),"camp").GetValue(data));values["number"]=F(data.GetType(),"number").GetValue(data);}
                pass=values.All(kv=>JsonSerializer.Serialize(kv.Value)==original.GetProperty(kv.Key).GetRawText());
            }
            catch(Exception e){error=Root(e).ToString();}
            if(!pass)failures++;rows.Add(new{name,token=c.GetProperty("token").GetString(),actual=values,pass,error});
        }
        File.WriteAllText(args[4],JsonSerializer.Serialize(new{scope="FOUR_REAL_DLL_METHODS_DIRECT_REFLECTION_INVOCATION_NO_EMISSION_OR_ENGINE_CALLEE_STUBS",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),executions=rows.Count,distinct_methods=rows.Select(x=>x).Count()>0?4:0,failures,pass=failures==0,rows,actual_unity=false},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{executions=rows.Count,failures}));alc.Unload();
    }
}
