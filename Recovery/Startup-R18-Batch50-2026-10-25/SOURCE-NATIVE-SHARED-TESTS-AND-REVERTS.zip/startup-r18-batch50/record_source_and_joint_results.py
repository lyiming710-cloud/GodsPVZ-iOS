"""Bind source registration evidence and retain every narrower/unsupported result."""
from pathlib import Path
import collections,json,struct
import source_common as s
Q=s.Q
def js(name,value):(Q/name).write_bytes((json.dumps(value,indent=2)+'\n').encode())
native=json.loads((Q/'ORIGINAL-NATIVE.json').read_bytes());cil=json.loads((Q/'ACTUAL-CIL.json').read_bytes());neg=json.loads((Q/'PHYSICAL-REVERT-CONTROLS.json').read_bytes())
assert native['results']==cil['results'] and len(native['results'])==2521 and len({r['token'] for r in native['results']})==50
assert neg['all_detected'] and neg['controls']==50 and neg['runtime_process_failures']==0
# Independently recover the CoreModule CodeGenModule pointer table from its
# native image-name reference; do not trust a copied method-map VA alone.
module_name=b'UnityEngine.CoreModule.dll\0';start=0;tables=[]
while True:
    at=s.raw.find(module_name,start)
    if at<0:break
    start=at+1;va=s.base+s.pc.get_rva_from_offset(at);needle=struct.pack('<Q',va);pos=0
    while True:
        ref=s.raw.find(needle,pos)
        if ref<0:break
        pos=ref+1;count=struct.unpack_from('<I',s.raw,ref+8)[0];ptr=struct.unpack_from('<Q',s.raw,ref+16)[0]
        if not 0x397<=count<10000 or not s.base<ptr<s.base+s.pc.OPTIONAL_HEADER.SizeOfImage:continue
        private=int.from_bytes(s.pc.get_data(ptr-s.base+(0x382-1)*8,8),'little');public=int.from_bytes(s.pc.get_data(ptr-s.base+(0x397-1)*8,8),'little')
        if private==public==0x1812fae70:tables.append(dict(codegen_module_va=hex(s.base+s.pc.get_rva_from_offset(ref)),pointer_count=count,method_pointers_va=hex(ptr),private_token='0x06000382',public_token='0x06000397',both_native_va=hex(public)))
assert len(tables)==1,tables
sdk=json.loads((Q/'SOURCE-SDK-CONTRACTS.json').read_bytes());assert all(r['public'] for r in sdk)
assert next(r for r in sdk if r['owner']=='TMP_Dropdown')['direct_target']==['m_Value']
js('SOURCE-ACCESSOR-BINDING.json',dict(scope='ORIGINAL_PC_PUBLIC_PRIVATE_RENDERER_ALIAS_AND_CURRENT_SDK_API_BOUNDARY',original_pc_sha256=s.sha(s.raw),core_registration=tables,sdk_contracts=sdk,
    original_player_public_getter_same_native_bytes_as_private_icall=True,current_sdk_editor_getter_has_persistent_object_guard=True,
    controlled_profile_precondition='Nonpersistent gameplay renderer instances; SDK internals are controlled callees.',
    persistent_asset_or_real_unity_behavior='UNPROVEN_NOT_CLAIMED',private_visibility_not_changed=True))
direct=json.loads((Q/'DIRECT-ACTUAL-CLR.json').read_bytes());passed=[r for r in direct['rows'] if r['pass']];unsupported=[r for r in direct['rows'] if not r['pass']]
parent_direct=json.loads((Q/'PARENT-DIRECT-ACTUAL-CLR.json').read_bytes());parent_bad=[r for r in parent_direct['rows'] if not r['pass']];parent_values=[r for r in parent_bad if r['error'] is None]
assert len(parent_bad)==32 and len(parent_values)==16 and {r['token'] for r in parent_values}=={'0x0600017D'}
assert len(passed)==74 and len(unsupported)==16 and {r['token'] for r in unsupported}=={'0x0600043C'}
assert all("Zombie..cctor" in r['error'] and 'Animator.StringToHash' in r['error'] and 'ECall methods must be packaged into a system module' in r['error'] for r in unsupported)
js('DIRECT-CLR-SUMMARY.json',dict(scope='DIRECT_REAL_DLL_SUPPLEMENT_RETAINS_RAW_FAILURES',candidate_sha256=cil['candidate_sha256'],attempted_cases=90,passed_cases=74,passed_distinct_methoddefs=len({r['token'] for r in passed}),
    unsupported_cases=16,unsupported_method='0x0600043C Zombie.Flashing',reason='Real Zombie type initializer needs Unity Animator.StringToHash ECall unavailable in stock CLR; method body is not reached.',
    raw_report_pass=False,raw_failures_preserved=True,type_initializer_not_removed_or_stubbed=True,parent_attempted=len(parent_direct['rows']),parent_failures=len(parent_bad),parent_unity_cctor_blocks=16,parent_actual_value_mismatches=16,parent_mismatch_method='0x0600017D PreDevice::.ctor',unity_player_acceptance=False))
access=json.loads((Q/'MEMBER-ACCESS-ALL-2297.json').read_bytes());bad=[r for r in access['members'] if not r['allowed']]
frozen=json.loads((Q/'FROZEN-WITH-INTERFACE-FACTS.json').read_bytes());type_rows=[r for r in frozen['results'] if r['status']!='PASS'];targets={r['token'] for r in json.loads((Q/'SOURCE-ROSTER.json').read_bytes())['rows']}
assert not any(r['token'] in targets for r in bad+type_rows)
union={r['token'] for r in bad+type_rows}
js('REMAINING-QUEUES.json',dict(scope='OVERLAPPING_REVIEW_QUEUES_NOT_CONFIRMED_GAMEPLAY_BUG_TOTAL',candidate_sha256=cil['candidate_sha256'],type_fail_or_unsupported=len(type_rows),access_rejected_sites=len(bad),access_rejected_methods=len({r['token'] for r in bad}),method_union=len(union),type_rows=type_rows,access_rows=bad,next_work='Continue source recovery in groups of fifty before shared tests; preserve unsupported engine and checker limitations.'))
js('SHARED-RUNTIME-RESULT.json',dict(scope='FIFTY_SOURCE_CHANGES_FINITE_COMPLETE_CIL_ORIGINAL_NATIVE_PROFILES_AND_COMPLEMENTARY_REVERT_CONTROLS',candidate_sha256=cil['candidate_sha256'],pass_=True,methods=50,unchanged_cil_dependencies_executed=5,original_native_cil_records=2521,different_records=0,physical_reverts=50,reverts_runtime_different=37,reverts_runtime_no_difference=13,reverts_frozen_rejected=16,reverts_access_rejected=24,all_reverts_detected=True,
    direct_real_dll_passed_cases=74,direct_real_dll_methods=3,direct_real_dll_engine_blocked_cases=16,
    engine_allocation_dictionary_subscription_and_game_leaf_calls_are_controlled=True,model_fields_are_public_access_checked_separately=True,
    native_seh_real_gc_concurrency_real_engine_behavior='UNPROVEN',whole_game_promotion=False,ipa=None))
js('TEST-SETUP-NOTES.json',dict(candidate_changed_for_fixture_fixes=False,notes=[
    'Initial lexical-tail driver was invoked before its ALL-CIL dependency was ready; rerun after export succeeded with zero tails. No candidate change.',
    'Fixture class Mono shadowed Mono.Cecil namespace; renamed model to MonoBase. Frozen Rehost.cs unchanged; candidate unchanged.',
    'Native nested type namespace lookup corrected to the original metadata empty nested namespace before caller execution. Candidate unchanged.',
    'Provisional leaf addresses resolved from original method pointers/call sites before execution; no caller bytes patched.',
    'Direct actual DLL retains all sixteen real Zombie cctor/ECall failures as unsupported; no cctor removal, substitution or green rewrite.',
    'Current SDK Renderer.material editor guard is documented separately; original PC public/private aliases are independently verified and fixture scope excludes persistent assets.'
]))
print(json.dumps(dict(native_cil_records=2521,physical_reverts_detected=50,direct_passed=74,direct_engine_unsupported=16,type_queue=len(type_rows),access_sites=len(bad),access_methods=len({r['token'] for r in bad}),method_union=len(union))))
