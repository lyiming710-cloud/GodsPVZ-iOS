using System.Reflection;using System.Runtime.CompilerServices;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public class Obj(string id){public string Id=id;public bool Live=true;}
public class Asset(string id):Obj(id){}
public class Frame{}
public class Sequence{public List<Frame>? Frames;}
public class Clip(string id):Obj(id)
{
    public Asset? _clip;public string? _sequence="old";public int _currentFrame=5;public Sequence? _curSequence;
    public Action<Clip>? OnChangeClipEvent,OnChangeSequenceEvent,OnChangeCurrentFrameEvent;
    public void set_sequence(string? x)=>Program.Go(0x831,this,x);public void set_currentFrame(int x)=>Program.Go(0x833,this,x);
    public void ChangeClip()=>Program.Leaf("ChangeClip",this);public void ChangeSequence()=>Program.Leaf("ChangeSequence",this);public void ChangeCurrentFrame()=>Program.Leaf("ChangeFrame",this);
}
public class Ctrl(string id):Obj(id)
{
    public Clip? _clip;public bool _isPlaying,_autoPlay;public float _tickTimer=3.25f;
    public Action<Ctrl>? OnPlayStoppedEvent,OnStopPlayingEvent;
    public void Play(bool x)=>Program.Go(0x873,this,x);public void Play(string? x)=>Program.Go(0x874,this,x);
    public void Stop(bool x)=>Program.Go(0x871,this,x);public void Stop(string? x)=>Program.Go(0x872,this,x);
    public void GotoAndPlay(int x)=>Program.Go(0x86f,this,x);public void GotoAndPlay(string? s,int x)=>Program.Go(0x870,this,s,x);
    public void GotoAndStop(int x)=>Program.Go(0x86d,this,x);public void GotoAndStop(string? s,int x)=>Program.Go(0x86e,this,s,x);
    public void Rewind(){Program.Trace.Add("Rewind");if(Program.Mode=="rewind-toggles-play")_isPlaying=!_isPlaying;}
    public Clip? get_clip()=>_clip;public bool get_isPlaying()=>_isPlaying;
}
public class Assoc<T>(string name){public string Name=name;public void Add(T x)=>Program.Register(Name,"Add",x!);public void Remove(T x)=>Program.Register(Name,"Remove",x!);}
public class Manager(string id):Obj(id)
{
    public Assoc<Clip> _clips=new("clips");public Assoc<Ctrl> _controllers=new("controllers");
    public void AddClip(Clip c)=>Program.Go(0x892,this,c);public void RemoveClip(Clip c)=>Program.Go(0x893,this,c);
    public void AddController(Ctrl c)=>Program.Go(0x895,this,c);public void RemoveController(Ctrl c)=>Program.Go(0x896,this,c);
}
public abstract class WaitBase
{
    public Ctrl? Target;public string Kind="";
    protected WaitBase(Ctrl? c,string kind){Kind=kind;Program.Trace.Add("AllocateWait:"+kind);Assign(c);}
    protected void Assign(Ctrl? c){Program.Trace.Add("Subscribe:"+Kind+":"+(c?.Id??"null"));Target=c;}
}
public class StopWait(Ctrl? c):WaitBase(c,"Stop"){public StopWait Subscribe(Ctrl? x){Assign(x);return this;}}
public class RewindWait(Ctrl? c):WaitBase(c,"Rewind"){public RewindWait Subscribe(Ctrl? x){Assign(x);return this;}}
public class StopOrRewindWait(Ctrl? c):WaitBase(c,"StopOrRewind"){public StopOrRewindWait Subscribe(Ctrl? x){Assign(x);return this;}}
public class PlayWait(Ctrl? c):WaitBase(c,"Play"){public PlayWait Subscribe(Ctrl? x){Assign(x);return this;}}
public class Animator(string id):Obj(id)
{
    public void SetTrigger(string s){Program.Trace.Add("Trigger:"+Id+":"+s);if(Program.Mode=="animator-flips-order")Program.Plant.order=Program.Plant.order>0?0:2;}
    public void SetBool(string s,bool b)=>Program.Trace.Add("AnimBool:"+Id+":"+s+":"+(b?1:0));
    public void SetFloat(string s,float f)=>Program.Trace.Add("AnimFloat:"+Id+":"+s+":"+Program.Bits(f));
}
public class Zombie
{
    public Animator? animator;public bool ladderZombie_place,poleZombie_jump,isStant,snowbeast_isRest;
    public float healthPoint=100,snowbeast_restTime,brightEffectTime,brightTime,brightIntensity,brightEffectTime_Armor2,brightTime_Armor2,brightIntensity_Armor2;
    public bool ZC_PoleTestJump(){Program.Trace.Add("PoleTest");return Program.B("test_jump");}
    public void ZC_PoleJump()=>Program.Go(0x4a0,this);
    public void DestroyZombie()=>Program.Trace.Add("DestroyZombie");
}
public class Plant{public Animator? animator;public bool pC_chomperviking_devour;public int order;public float pT_chomperviking_devourPoint=5.5f;}
public class Device{public int ID;}
public class MonoBase{public MonoBase(){if(Program.Tele!=null)Program.Trace.Add("MonoCtor:"+Program.Tele.label01+"|"+Program.Tele.label02);}}
public class Tele:MonoBase{public string? label01,label02;}
public class Material(string id):Obj(id){public void SetFloat(string key,float value){Program.Trace.Add("MaterialFloat:"+Id+":"+key+":"+Program.Bits(value));if(Program.Mode=="material-replaces-renderer")Program.Ice.spriteRenderer1=Program.Renderer2;}}
public class Renderer(string id,Material mat):Obj(id){public Material Mat=mat;public Material material{get{Program.Trace.Add("Material:"+Id);return Mat;}}public Material GetMaterial()=>material;}
public class Ice{public Renderer? spriteRenderer0,spriteRenderer1;}
public class GameObj(string id):Obj(id){public void SetActive(bool b){Program.Trace.Add("Active:"+Id+":"+(b?1:0));if(Program.Mode=="active-replaces-text")Program.Skill.text_Level=Program.Text1;}}
public class Text(string id):Obj(id)
{
    public GameObj Game=new(id+"-game");public string? Last;
    public GameObj gameObject{get{Program.Trace.Add("GameObject:"+Id);return Game;}}
    public void SetText(string? s,bool parse){Last=s;Program.Trace.Add("Text:"+Id+":"+s+":"+(parse?1:0));}
    public string? text{set{Last=value;Program.Trace.Add("TextOne:"+Id+":"+value);}}
}
public class PlantSave{public string[]? talents;}
public class Talent{public Text? talentDescription;public PlantSave? plantSave;}
public class Sprite(string id):Obj(id){}
public class Skill{public Text? text_Level;public void LoadSprite(Sprite? s,bool b)=>Program.Trace.Add("Sprite:"+(s?.Id??"null")+":"+(b?1:0));}
public class Dropdown{public int m_Value;public int value=>m_Value;}
public class DropdownSample{public Text? text;public Dropdown? dropdownWithPlaceholder,dropdownWithoutPlaceholder;}
public class Data
{
    public string Id="default";
    public Data(int x){Program.Trace.Add("AllocateData:"+x);if(Program.Mode=="allocation-mutates-entry")Program.PreDevice.entryKey="changed";}
}
public class PreDevice{public int gridX,gridY;public string? entryKey;public Data? data;}
public class PlantData{public PlantData(){Program.Trace.Add("AllocatePlantData");}}
public class CardData{public int camp=1,number=1;public CardData(){Program.Trace.Add("AllocateCardData");}}
public class PreCard{public int cardPlantType,cardDeviceType;public PlantData? plantData;public CardData? deviceData;}
public class Save{public bool[]? almanac_DeviceLock;}
public class Info(string id){public string Id=id;}
public class Window{public int deviceID;public Info? deviceInfo;public void SetState(bool x){Program.Trace.Add("WindowState:"+(x?1:0));if(Program.Mode=="state-mutates-id")deviceID=-7;}}
public static class Program
{
    public static JsonElement Current;public static List<string> Trace=[];public static Dictionary<int,MethodInfo> Code=[];
    public static string Mode=>S("mode")??"none";public static string? S(string n,string? d=null)=>Current.TryGetProperty(n,out var x)?x.ValueKind==JsonValueKind.Null?null:x.GetString():d;
    public static int N(string n,int d=0)=>Current.TryGetProperty(n,out var x)?x.GetInt32():d;public static bool B(string n,bool d=false)=>Current.TryGetProperty(n,out var x)?x.GetBoolean():d;
    public static float F(string n,float d=0)=>S(n) is string x?BitConverter.UInt32BitsToSingle(Convert.ToUInt32(x,16)):d;
    public static string Bits(float x)=>float.IsNaN(x)?"NaN":BitConverter.SingleToUInt32Bits(x).ToString("X8");
    public static Clip Clip0=null!,Clip1=null!;public static Ctrl Ctrl=null!;public static Manager? Manager;public static Zombie Zombie=null!;public static Plant Plant=null!;public static Tele? Tele;public static Ice Ice=null!;public static Renderer Renderer2=null!;public static Skill Skill=null!;public static Text Text0=null!,Text1=null!;public static PreDevice PreDevice=null!;public static Window Window=null!;
    public static object? Go(int rid,params object?[] args){try{return Code[rid].Invoke(null,args);}catch(TargetInvocationException e)when(e.InnerException!=null){System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(e.InnerException).Throw();throw;}}
    public static bool Implicit(Obj? x){Trace.Add("Live:"+(x?.Id??"null")+":"+(x?.Live==true?1:0));bool v=x?.Live==true;if(Mode=="implicit-replaces-clip"&&x is Clip)Ctrl._clip=Clip1;return v;}
    public static Manager? GetManager(bool create){Trace.Add("Manager:"+(create?1:0));return Manager;}
    public static bool App(){Trace.Add("App:"+(B("app_play")?1:0));if(Mode=="app-flips-playing")Ctrl._isPlaying=!Ctrl._isPlaying;return B("app_play");}
    public static void Register(string name,string op,object value){Trace.Add(op+":"+name+":"+((Obj)value).Id);if(Mode=="manager-flips-auto")Ctrl._autoPlay=!Ctrl._autoPlay;}
    public static void Leaf(string op,Clip c){Trace.Add(op+":"+c.Id+":"+c._currentFrame+":"+c._sequence);if(Mode=="change-frame-clears-event")c.OnChangeCurrentFrameEvent=null;}
    public static void ClipEvent(Clip c,string kind){Trace.Add("Event:"+c.Id+":"+kind+":"+c._currentFrame+":"+c._sequence);if(Mode=="clip-event-clears-next"&&kind=="clip")c.OnChangeSequenceEvent=null;}
    public static void CtrlEvent(Ctrl c,string kind){Trace.Add("CtrlEvent:"+kind+":"+(c._isPlaying?1:0)+":"+Bits(c._tickTimer));if(Mode=="controller-event-toggles-play")c._isPlaying=!c._isPlaying;}
    public static float Delta(){Trace.Add("Delta:"+Bits(F("delta",0.5f)));if(Mode=="delta-mutates-rest")Zombie.snowbeast_restTime=999;return F("delta",0.5f);}
    public static Info LoadInfo(int x){Trace.Add("LoadInfo:"+x);return new("info:"+x);}
    static Type Map(MC.TypeReference t)
    {
        if(t is MC.ByReferenceType br)return Map(br.ElementType).MakeByRefType();if(t is MC.ArrayType ar)return Map(ar.ElementType).MakeArrayType();
        if(t is MC.GenericInstanceType g){Type o=g.ElementType.FullName switch{"System.Action`1"=>typeof(Action<>),"System.Collections.Generic.List`1"=>typeof(List<>),"FTRuntime.Internal.SwfAssocList`1"=>typeof(Assoc<>),_=>throw new NotSupportedException(t.FullName)};return o.MakeGenericType(g.GenericArguments.Select(Map).ToArray());}
        return t.FullName switch{
            "System.Void"=>typeof(void),"System.Boolean"=>typeof(bool),"System.Int32" or "PlantType" or "DeviceType" or "Camp" or "OccupyState"=>typeof(int),"System.Single"=>typeof(float),"System.String"=>typeof(string),"System.Object"=>typeof(object),"System.IntPtr"=>typeof(IntPtr),"System.NullReferenceException"=>typeof(NullReferenceException),
            "FTRuntime.SwfClip"=>typeof(Clip),"FTRuntime.SwfClipController"=>typeof(Ctrl),"FTRuntime.SwfClipAsset"=>typeof(Asset),"FTRuntime.SwfClipAsset/Frame"=>typeof(Frame),"FTRuntime.SwfClipAsset/Sequence"=>typeof(Sequence),"FTRuntime.SwfManager"=>typeof(Manager),
            "FTRuntime.Yields.SwfWaitStopPlaying"=>typeof(StopWait),"FTRuntime.Yields.SwfWaitRewindPlaying"=>typeof(RewindWait),"FTRuntime.Yields.SwfWaitStopOrRewindPlaying"=>typeof(StopOrRewindWait),"FTRuntime.Yields.SwfWaitPlayStopped"=>typeof(PlayWait),
            "Zombie"=>typeof(Zombie),"Plant"=>typeof(Plant),"Device"=>typeof(Device),"Device/ICEUIController"=>typeof(Ice),"UnityEngine.Animator"=>typeof(Animator),"UnityEngine.Material"=>typeof(Material),"UnityEngine.Renderer" or "UnityEngine.SpriteRenderer"=>typeof(Renderer),"UnityEngine.Object"=>typeof(Obj),"UnityEngine.Component" or "TMPro.TextMeshProUGUI" or "TMPro.TMP_Text"=>typeof(Text),"UnityEngine.GameObject"=>typeof(GameObj),"UnityEngine.Sprite"=>typeof(Sprite),
            "TMPro.TMP_Dropdown"=>typeof(Dropdown),"DropdownSample"=>typeof(DropdownSample),"TMPro.Examples.TeleType"=>typeof(Tele),"UnityEngine.MonoBehaviour"=>typeof(MonoBase),"Almanac_TalentSystem"=>typeof(Talent),"PlantSave"=>typeof(PlantSave),"SkillButtonController"=>typeof(Skill),"DeviceData"=>typeof(Data),"PreDevice"=>typeof(PreDevice),"PreCard"=>typeof(PreCard),"PreCard/PlantData"=>typeof(PlantData),"Card/CardDeviceData"=>typeof(CardData),"Save"=>typeof(Save),"DeviceInfo"=>typeof(Info),"Almanac_DeviceWindow"=>typeof(Window),_=>throw new NotSupportedException(t.FullName)};
    }
    static FieldInfo Field(MC.FieldReference f)=>Map(f.DeclaringType).GetField(f.Name)!;
    static MethodBase Method(MC.MethodReference m)
    {
        if(m.DeclaringType.FullName=="UnityEngine.Object"&&m.Name=="op_Implicit")return typeof(Program).GetMethod(nameof(Implicit))!;
        if(m.DeclaringType.FullName=="FTRuntime.SwfManager"&&m.Name=="GetInstance")return typeof(Program).GetMethod(nameof(GetManager))!;
        if(m.DeclaringType.FullName=="UnityEngine.Application")return typeof(Program).GetMethod(nameof(App))!;
        if(m.DeclaringType.FullName=="UnityEngine.Time")return typeof(Program).GetMethod(nameof(Delta))!;
        if(m.DeclaringType.FullName=="ResourceManager")return typeof(Program).GetMethod(nameof(LoadInfo))!;
        Type owner=Map(m.DeclaringType);Type[] args=m.Parameters.Select(x=>Map(x.ParameterType is MC.GenericParameter p?((MC.GenericInstanceType)m.DeclaringType).GenericArguments[p.Position]:x.ParameterType)).ToArray();
        return m.Name==".ctor"?owner.GetConstructor(args)!:owner.GetMethod(m.Name,BindingFlags.Public|BindingFlags.Instance|BindingFlags.Static,null,args,null)!;
    }
    static Clip MakeClip(string id,int count,int mask){var c=new Clip(id){_curSequence=count==-1?null:new(){Frames=count==-2?null:Enumerable.Range(0,count).Select(_=>new Frame()).ToList()}};if((mask&1)!=0)c.OnChangeClipEvent=x=>ClipEvent(x,"clip");if((mask&2)!=0)c.OnChangeSequenceEvent=x=>ClipEvent(x,"sequence");if((mask&4)!=0)c.OnChangeCurrentFrameEvent=x=>ClipEvent(x,"frame");return c;}
    static object ClipState(Clip c)=>new{id=c.Id,frame=c._currentFrame,sequence=c._sequence,asset=c._clip?.Id,event_sequence=c.OnChangeSequenceEvent!=null,event_frame=c.OnChangeCurrentFrameEvent!=null};
    static object SwfState(WaitBase? wait)=>new{playing=Ctrl._isPlaying,tick=Bits(Ctrl._tickTimer),auto=Ctrl._autoPlay,ctrl_clip=Ctrl._clip?.Id,clip0=ClipState(Clip0),clip1=ClipState(Clip1),wait_kind=wait?.Kind,wait_target=wait?.Target?.Id};
    static object? Run(int rid)
    {
        if(S("kind")=="swf")
        {
            Clip0=MakeClip("clip0",N("seq_count",3),N("event_mask",7));Clip1=MakeClip("clip1",N("seq_count",3),N("event_mask",7));Clip0.Live=N("clip_state",1)==1;
            Ctrl=new("ctrl"){_clip=N("clip_state",1)==0?null:Clip0,_isPlaying=B("playing"),_autoPlay=B("auto_play")};
            if((N("event_mask",7)&1)!=0)Ctrl.OnPlayStoppedEvent=x=>CtrlEvent(x,"play");if((N("event_mask",7)&2)!=0)Ctrl.OnStopPlayingEvent=x=>CtrlEvent(x,"stop");
            Manager=N("manager_state",1)==0?null:new("manager"){Live=N("manager_state",1)==1};
            object? result=null;
            if(rid>=0x8aa){var arg=S("arg_type")=="bool"?(object)B("arg_bool"):S("arg_type")=="int"?N("arg_int"):S("arg_string");result=S("arg_type")=="string_int"?Go(rid,Ctrl,S("arg_string"),N("arg_int")):Go(rid,Ctrl,arg);}
            else if(rid is 0x86d or 0x86f)Go(rid,Ctrl,N("arg_int"));else if(rid is 0x86e or 0x870)Go(rid,Ctrl,S("arg_string"),N("arg_int"));else if(rid is 0x871 or 0x873)Go(rid,Ctrl,B("arg_bool"));else if(rid is 0x872 or 0x874)Go(rid,Ctrl,S("arg_string"));else if(rid is 0x87a or 0x87b)Go(rid,Ctrl);else if(rid==0x82f)Go(rid,Clip0,new Asset("asset"));else if(rid==0x831)Go(rid,Clip0,S("arg_string"));else if(rid==0x847)Go(rid,Clip0,B("flag1"),B("flag2"),B("flag3"));else Go(rid,Clip0);
            return SwfState(result as WaitBase);
        }
        Zombie=new(){animator=new("anim0"),isStant=B("stant"),snowbeast_isRest=B("rest"),snowbeast_restTime=F("rest_time",9.5f),healthPoint=F("health",100)};
        Plant=new(){animator=new("anim0"),order=N("order",1)};Text0=new("text0");Text1=new("text1");Skill=new(){text_Level=Text0};Window=new();
        switch(rid)
        {
            case 0x4b4:case 0x497:case 0x4a0:case 0x4a4:case 0x4a5:Go(rid,Zombie);break;
            case 0x43c:Go(rid,Zombie,F("time",1.25f),F("intensity",2.5f),S("target"));break;
            case 0x380:Go(rid,Plant,Zombie);break;
            case 0x311:return new{result=Go(rid,new Device{ID=N("device_id")},N("occupy"),S("target"))};
            case 0x77c:Tele=(Tele)RuntimeHelpers.GetUninitializedObject(typeof(Tele));Go(rid,Tele);return new{label1=Tele.label01,label2=Tele.label02};
            case 0x344:Renderer2=new("renderer2",new("material2"));Ice=new(){spriteRenderer0=new("renderer0",new("material0")),spriteRenderer1=new("renderer1",new("material1"))};Go(rid,Ice,F("intensity",2.5f));return new{renderer1=Ice.spriteRenderer1?.Id};
            case 0x59b:var talent=new Talent{talentDescription=Text0,plantSave=new(){talents=["talent0","talent1","talent2"]}};Go(rid,talent,N("index"));return new{text0=Text0.Last};
            case 0x6d7:Go(rid,Skill,new Sprite("sprite"),B("locked"),N("level"));return new{text0=Text0.Last,text1=Text1.Last,owner_text=Skill.text_Level?.Id};
            case 0x719:var drop=new DropdownSample{text=Text0,dropdownWithoutPlaceholder=new(){m_Value=N("normal_value")},dropdownWithPlaceholder=new(){m_Value=N("placeholder_value")}};Go(rid,drop);return new{text0=Text0.Last};
            case 0x17d:PreDevice=new(){gridX=99,gridY=98,entryKey="before"};Data arg=(Data)RuntimeHelpers.GetUninitializedObject(typeof(Data));arg.Id="supplied";Go(rid,PreDevice,N("grid_x"),N("grid_y"),arg,S("entry"));return new{x=PreDevice.gridX,y=PreDevice.gridY,key=PreDevice.entryKey,data=PreDevice.data?.Id};
            case 0x2d2:var card=new PreCard{cardPlantType=99,cardDeviceType=98};Go(rid,card);return new{plant_type=card.cardPlantType,device_type=card.cardDeviceType,plant_data=card.plantData!=null,camp=card.deviceData?.camp,number=card.deviceData?.number};
            case 0x569:Go(rid,Window,new Save{almanac_DeviceLock=[false,true,false,true]},N("index"));return new{id=Window.deviceID,info=Window.deviceInfo?.Id};
            default:throw new NotSupportedException(rid.ToString("X"));
        }
        return new{ladder=Zombie.ladderZombie_place,jump=Zombie.poleZombie_jump,rest=Zombie.snowbeast_isRest,rest_time=Bits(Zombie.snowbeast_restTime),body_time=Bits(Zombie.brightTime),body_effect=Bits(Zombie.brightEffectTime),body_intensity=Bits(Zombie.brightIntensity),armor_time=Bits(Zombie.brightTime_Armor2),armor_effect=Bits(Zombie.brightEffectTime_Armor2),armor_intensity=Bits(Zombie.brightIntensity_Armor2),devour=Plant.pC_chomperviking_devour,order=Plant.order,devour_point=Bits(Plant.pT_chomperviking_devourPoint)};
    }
    public static void Main(string[] args)
    {
        using var module=MC.ModuleDefinition.ReadModule(args[0]);var roster=JsonDocument.Parse(File.ReadAllText(Path.Combine(Path.GetDirectoryName(args[1])!,"SOURCE-ROSTER.json"))).RootElement.GetProperty("rows");var ids=roster.EnumerateArray().Select(x=>Convert.ToInt32(x.GetProperty("token").GetString(),16)&0xffffff).Concat(new[]{0x833,0x892,0x893,0x895,0x896}).Distinct().ToArray();
        foreach(int rid in ids)Code[rid]=ActualCil.Emit((MC.MethodDefinition)module.LookupToken(0x6000000|rid),Map,Field,Method);
        var rows=new List<object>();foreach(var c in JsonDocument.Parse(File.ReadAllText(args[1])).RootElement.EnumerateArray())
        {Current=c;Trace=[];Tele=null;object? state=null;string? error=null;try{state=Run(Convert.ToInt32(S("token"),16)&0xffffff);}catch(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;error=e.GetType().FullName;}rows.Add(new{name=S("name"),token=S("token"),kind=S("kind"),trace=Trace.ToArray(),state,error});}
        File.WriteAllText(args[2],JsonSerializer.Serialize(new{scope="FIFTY_COMPLETE_ACTUAL_CANDIDATE_CIL_CALLERS_PLUS_FIVE_UNCHANGED_DEPENDENCIES_WITH_CONTROLLED_ENGINE_CALLEES",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),all_source_instructions_emitted=true,private_access_bypass=false,actual_unity=false,results=rows},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{methods=ids.Length,records=rows.Count}));
    }
}
