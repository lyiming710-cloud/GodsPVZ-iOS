"""Read authentic SDK member visibility and full getter bytes; do not execute."""
from pathlib import Path
import hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;ROOT=Q.parents[2];sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
support=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support';out=[]
for filename,owner,name in [('UnityEngine.CoreModule.dll','Renderer','get_material'),('Unity.TextMeshPro.dll','TMP_Dropdown','get_value')]:
    p=support/filename;data=p.read_bytes();pe=dnfile.dnPE(data=data);td=next(t for t in pe.net.mdtables.TypeDef.rows if str(t.TypeName)==owner);mi=next(m for m in td.MethodList if str(m.row.Name)==name);m=mi.row;at=pe.get_offset_from_rva(m.Rva);h=1 if data[at]&3==2 else (struct.unpack_from('<H',data,at)[0]>>12)*4;n=data[at]>>2 if h==1 else struct.unpack_from('<I',data,at+4)[0];code=data[at+h:at+h+n];targets=[]
    if len(code)==7 and code[0]==2 and code[1] in [0x28,0x7b] and code[-1]==0x2a:
        token=int.from_bytes(code[2:6],'little');targets.append(str(pe.net.mdtables.tables[token>>24].rows[(token&0xffffff)-1].Name))
    out.append(dict(file=filename,sha256=hashlib.sha256(data).hexdigest(),owner=owner,name=name,token=hex(0x6000000|mi.row_index),public=m.Flags.mdPublic,signature=m.Signature.value.hex(),body=code.hex(),direct_target=targets))
(Q/'SOURCE-SDK-CONTRACTS.json').write_bytes((json.dumps(out,indent=2)+'\n').encode());print(json.dumps(dict(authentic_getters=len(out),all_public=all(x['public'] for x in out))))
