"""Immutable source inspection helpers. Importing executes no validation suites."""
from pathlib import Path
import hashlib, json, struct, sys
Q=Path(__file__).resolve().parent; W=Q.parent; ROOT=W.parents[1]
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile, pefile
from capstone import Cs,CS_ARCH_X86,CS_MODE_64,CS_GRP_RET,CS_GRP_JUMP
from capstone.x86_const import X86_OP_IMM
sha=lambda data:hashlib.sha256(data).hexdigest()
parent=(W/'startup-r17-batch50/candidate3.dll').read_bytes()
assert sha(parent)=='d2a645ad0d8164af5fbdcbd9fcaa578d5a28b27e7b13f3012cdb51e63a256091'
pe=dnfile.dnPE(data=parent)
cil=json.loads((W/'startup-r17-batch50/ALL-CIL.json').read_bytes())
methods={m['token']:m for m in cil['methods']}
I=ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs'
raw=(I/'original-pc/GameAssembly.dll').read_bytes()
assert sha(raw)=='9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d'
pc=pefile.PE(data=raw);base=pc.OPTIONAL_HEADER.ImageBase
field_rows=json.loads((I/'maps/native-fields.json').read_text('utf-8-sig'))
field_map={int(r['token'],16):r for r in field_rows}
dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True
def tok(rid):return f'0x{0x6000000|rid:08X}'
def pointer(token):return int.from_bytes(pc.get_data(0x181b82d60-base+((int(token,16)&0xffffff)-1)*8,8),'little')
def body(token):
    row=pe.net.mdtables.MethodDef.rows[(int(token,16)&0xffffff)-1];at=pe.get_offset_from_rva(row.Rva)
    h=1 if parent[at]&3==2 else (struct.unpack_from('<H',parent,at)[0]>>12)*4
    n=parent[at]>>2 if h==1 else struct.unpack_from('<I',parent,at+4)[0]
    return dict(offset=at,header=h,code_size=n,code=parent[at+h:at+h+n])
def operand_token(token,ins):
    b=body(token)['code'];at=ins['offset']
    return int.from_bytes(b[at+1:at+5],'little')
def native(token=None,entry=None,complete=False):
    entry=entry or pointer(token)
    assert entry
    fn=next(x.struct for x in pc.DIRECTORY_ENTRY_EXCEPTION if x.struct.BeginAddress<=entry-base<x.struct.EndAddress)
    runtime_end=base+fn.EndAddress
    bound=min(pointer(tok(n)) for n in range(1,len(pe.net.mdtables.MethodDef.rows)+1) if pointer(tok(n))>entry) if complete else runtime_end
    end=bound; pending=[entry]; ins={};outside=[];indirect=[];crossings=set()
    while pending:
        at=pending.pop()
        while at not in ins:
            if not entry<=at<end:
                outside.append(dict(target=hex(at),kind='OUTSIDE_DECLARED_RUNTIME_FUNCTION'));break
            if at>=runtime_end:crossings.add(at)
            i=next(dis.disasm(pc.get_data(at-base,15),at));ins[at]=i
            assert len(ins)<2000
            if i.group(CS_GRP_RET) or i.mnemonic in ['int3','ud2']:break
            if i.group(CS_GRP_JUMP):
                if i.operands[0].type==X86_OP_IMM:
                    target=i.operands[0].imm
                    if entry<=target<end:pending.append(target)
                    else:outside.append(dict(source=hex(at),target=hex(target),kind='EXTERNAL_TAIL_OR_SEPARATE_FUNCLET_REVIEW'))
                else:indirect.append(dict(source=hex(at),operand=i.op_str))
                if i.mnemonic=='jmp':break
            at+=i.size
    return dict(token=token,entry=hex(entry),runtime_begin=hex(base+fn.BeginAddress),runtime_end=hex(runtime_end),next_distinct_method_pointer=hex(bound) if complete else None,
        scope='METHOD_POINTER_BOUNDED_CFG_WITH_EXPLICIT_PDATA_CROSSINGS_AND_EXTERNAL_TAILS' if complete else 'DECLARED_RUNTIME_FUNCTION_CFG_EXPLICIT_UNFOLLOWED_BOUNDARIES',
        instructions=[dict(va=hex(i.address),op=i.mnemonic,operands=i.op_str,bytes=i.bytes.hex()) for i in sorted(ins.values(),key=lambda i:i.address)],
        outside_boundaries=outside,indirect_jumps=indirect,pdata_crossing_instruction_count=len(crossings))
def save_native(token,complete=False):
    d=Q/('native-source-complete' if complete else 'native-source');d.mkdir(exist_ok=True);cfg=native(token,complete=complete)
    (d/(token+'.json')).write_bytes((json.dumps(cfg,indent=2)+'\n').encode())
    (d/(token+'.txt')).write_text('\n'.join(f"{x['va']} {x['op']} {x['operands']}" for x in cfg['instructions'])+'\n')
    (Q/(token+'.parent-cil.json')).write_bytes((json.dumps(methods[token],indent=2)+'\n').encode())
    return cfg
if __name__=='__main__':
    swf=list(range(0x8aa,0x8ba))+[0x86d,0x86e,0x86f,0x870,0x871,0x872,0x873,0x874]+[0x82f,0x831,0x839,0x83a,0x847,0x84a]+[0x84b,0x84c,0x87a,0x87b]
    scalar=[0x4b4,0x497,0x4a0,0x77c,0x344,0x59b,0x6d7,0x380,0x719,0x311,0x43c,0x4a5,0x17d,0x2d2,0x569,0x4a4]
    assert len(swf)==34 and len(set(swf+scalar))==50
    rows=[]
    for rid in swf+scalar:
        token=tok(rid);cfg=save_native(token)
        rows.append(dict(token=token,name=methods[token]['name'],group='SWF_EVENT_AND_PUBLIC_CALL_RECONSTRUCTION' if rid in swf else 'ORIGINAL_NATIVE_SHORT_METHOD_RECONSTRUCTION',
            native_entry=cfg['entry'],native_instructions=len(cfg['instructions']),native_boundaries=cfg['outside_boundaries'],tests_run=False))
    (Q/'SOURCE-ROSTER.json').write_bytes((json.dumps(dict(scope='FIFTY_SOURCE_TARGETS_NOT_YET_CONSTRUCTED_OR_TESTED',parent_sha256=sha(parent),rows=rows),indent=2)+'\n').encode())
    print(json.dumps(dict(source_targets=len(rows),native_instructions=sum(x['native_instructions'] for x in rows),tests_run=False)))
