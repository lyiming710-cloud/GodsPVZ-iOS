"""Independent all-body/metadata isolation and decoded target contracts."""
from pathlib import Path
import hashlib,importlib.util,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1]
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
def mod(n,p):
    spec=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
writer=mod('raw_metadata_read_r18',W/'startup-r2/construct.py')
reader=mod('raw_body_read_r18',ROOT/'audit/native111-publication-2026-10-20/repository/scripts/actions/static_gates.py')
sha=lambda b:hashlib.sha256(b).hexdigest()
a=(W/'startup-r17-batch50/candidate3.dll').read_bytes();b=(Q/'candidate1.dll').read_bytes()
assert sha(a)=='d2a645ad0d8164af5fbdcbd9fcaa578d5a28b27e7b13f3012cdb51e63a256091'
assert sha(b)=='a6aa9f91087db194251c4c989fd80ffd982b3b7a59413b0745592bc43b548abb' and b==(Q/'candidate2.dll').read_bytes()
pp=dnfile.dnPE(data=a);cp=dnfile.dnPE(data=b)
def meta(data,p):
    cli=p.get_offset_from_rva(p.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress);rva,size=struct.unpack_from('<II',data,cli+8);at=p.get_offset_from_rva(rva)
    _,streams=writer.metadata_root(data[at:at+size]);values={n:v for n,_,v in streams};_,rows,_,_=writer.tables_decode(values['#~']);return at,values,rows
_,pv,pr=meta(a,pp)
def metadata_check(data,p):
    at,values,rows=meta(data,p);assert at==len(a) and set(values)==set(pv) and set(rows)==set(pr)
    for k,v in pv.items():
        if k!='#~':assert values[k]==v
    for table,old in pr.items():
        assert (rows[table][:-1]==old and len(rows[table])==len(old)+1) if table==10 else rows[table]==old
    r=p.net.mdtables.MemberRef.rows[-1];assert str(r.Name)=='get_value' and r.Signature.value==bytes.fromhex('200008') and str(r.Class.row.TypeName)=='TMP_Dropdown' and str(r.Class.row.TypeNamespace)=='TMPro'
metadata_check(b,cp)
swf=list(range(0x8aa,0x8ba))+[0x86d,0x86e,0x86f,0x870,0x871,0x872,0x873,0x874,0x82f,0x831,0x839,0x83a,0x847,0x84a,0x84b,0x84c,0x87a,0x87b]
scalar=[0x4b4,0x497,0x4a0,0x77c,0x344,0x59b,0x6d7,0x380,0x719,0x311,0x43c,0x4a5,0x17d,0x2d2,0x569,0x4a4]
targets={f'0x{0x6000000|n:08X}' for n in swf+scalar};assert len(targets)==50
old_cil=json.loads((W/'startup-r17-batch50/ALL-CIL.json').read_bytes());new_cil=json.loads((Q/'ALL-CIL.json').read_bytes())
old={x['token']:x for x in old_cil['methods']};new={x['token']:x for x in new_cil['methods']}
allowed=set();changed=[];maxstack=[]
def loc(data,p,rid):
    row=p.net.mdtables.MethodDef.rows[rid-1];at=p.get_offset_from_rva(row.Rva);h=1 if data[at]&3==2 else (struct.unpack_from('<H',data,at)[0]>>12)*4;n=data[at]>>2 if h==1 else struct.unpack_from('<I',data,at+4)[0];return at,h,n
for rid,(x,y) in enumerate(zip(pp.net.mdtables.MethodDef.rows,cp.net.mdtables.MethodDef.rows),1):
    assert x.Rva==y.Rva
    if not x.Rva:continue
    token=f'0x{0x6000000|rid:08X}';at,h,n=loc(a,pp,rid);bt,j,m=loc(b,cp,rid)
    ns=reader.parse_raw_method_body_span(a,at)[0];ms=reader.parse_raw_method_body_span(b,bt)[0]
    if a[at:at+ns]!=b[bt:bt+ms]:changed.append(token)
    if token not in targets:assert ns==ms and a[at:at+ns]==b[bt:bt+ms];continue
    assert at==bt and h==j==12 and m<=n and old[token]['locals']==new[token]['locals'] and old[token]['handlers']==new[token]['handlers']==[]
    assert a[at:at+2]==b[at:at+2] and a[at+8:at+12]==b[at+8:at+12]
    assert a[at+h+m:at+h+n]==b[at+h+m:at+h+n]
    assert new[token]['maxStack']>=old[token]['maxStack']
    if new[token]['maxStack']!=old[token]['maxStack']:maxstack.append(dict(token=token,old=old[token]['maxStack'],new=new[token]['maxStack']))
    allowed.update(range(at+2,at+8));allowed.update(range(at+h,at+h+m))
assert set(changed)==targets
for token in targets:
    ins=new[token]['instructions'];assert not any(i['opcode']=='ldstr' and any(v in str(i['operand']) for v in ['Unmanaged memory','Indirect call:','Invalid instruction:','Unknown call','Method not found']) for i in ins)
    rid=int(token,16)&0xffffff
    if 0x8aa<=rid<=0x8b9:
        calls=[i for i in ins if i['opcode'] in ['call','callvirt','newobj']]
        assert len(calls)==2 and calls[0]['opcode']=='callvirt' and calls[0]['operand']['owner']=='FTRuntime.SwfClipController'
        assert calls[1]['opcode']=='newobj' and calls[1]['operand']['owner']==new[token]['ret'] and calls[1]['operand']['args']==['FTRuntime.SwfClipController'] and ins[-1]['opcode']=='ret'
    if rid in [0x82f,0x831,0x839,0x83a,0x847,0x84a]:
        expected={0x82f:3,0x831:2,0x839:1,0x83a:1,0x847:3,0x84a:3}[rid]
        assert sum(i['opcode']=='callvirt' and i['operand']['name']=='Invoke' for i in ins)==expected
    if rid==0x6d7:assert any(i['opcode']=='ldarga.s' and i['operand']==dict(index=3) for i in ins)
    if rid==0x719:
        assert sum(i['opcode']=='callvirt' and i['operand']['name']=='get_value' for i in ins)==3
        assert any(i['opcode']=='ldfld' and i['operand']['identity'].endswith('::dropdownWithoutPlaceholder') for i in ins)
    if rid==0x17d:assert any(i['opcode']=='ldarg.s' and i['operand']==dict(index=4) for i in ins)
    if rid==0x4a5:assert any(i['opcode']=='blt.un' for i in ins)
sh=pp.sections[-1].get_file_offset();opt=pp.OPTIONAL_HEADER.get_file_offset();cli=pp.get_offset_from_rva(pp.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress)
allowed.update(at+i for at in [sh+8,sh+16,opt+8,opt+56,opt+64,cli+8,cli+12] for i in range(4))
assert pp.sections[-1].Characteristics==cp.sections[-1].Characteristics==0x40000040
def boundary(data):
    assert len(data)==len(b) and all(x==y or i in allowed for i,(x,y) in enumerate(zip(a,data)))
    metadata_check(data,dnfile.dnPE(data=data))
boundary(b);controls=[]
for name,at in [('non-target-body',loc(a,pp,0x526)[0]+12),('old-metadata',pp.get_offset_from_rva(pp.net.struct.MetaDataRva)),('old-field-row',pp.net.mdtables.Field.rows[0].struct.get_file_offset())]:
    bad=bytearray(b);bad[at]^=1
    try:boundary(bad)
    except AssertionError:controls.append(dict(name=name,rejected=True));continue
    raise AssertionError('Out-of-scope physical fault accepted')
frozen=json.loads((Q/'FROZEN-WITH-INTERFACE-FACTS.json').read_bytes());assert all(r['status']=='PASS' for r in frozen['results'] if r['token'] in targets)
result=dict(scope='INDEPENDENT_ALL_METHODDEF_METADATA_AND_DECODED_FIFTY_CONTRACTS',candidate_sha256=sha(b),parent_sha256=sha(a),pass_=True,changed_methods=50,unchanged_methoddefs=2267,new_memberrefs=1,new_methoddefs=0,new_locals=0,all_rvas_locals_visibility_readonly_unchanged=True,target_maxstack_increases=maxstack,old_metadata_rows_and_all_heaps_preserved=True,unused_old_slots_preserved=True,out_of_scope_controls=controls,changed_frozen_pass=50,whole_game_acceptance=False)
(Q/'ISOLATION-AND-CIL-SPEC.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());(Q/'METHOD-CIL.json').write_bytes((json.dumps(dict(types=new_cil['types'],methods=[new[t] for t in sorted(targets)]),indent=2)+'\n').encode())
print(json.dumps(result,indent=2))
