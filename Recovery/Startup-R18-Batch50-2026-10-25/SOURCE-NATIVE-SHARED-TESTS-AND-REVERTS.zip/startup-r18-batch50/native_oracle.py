"""Execute all fifty original PC callers with explicit controlled leaf callees.

Original selected caller bytes, including split pdata ranges, stay untouched.
This does not model native exceptions/SEH, Unity internals, real GC or scheduling.
"""
from pathlib import Path
import ctypes as C,hashlib,json,struct,sys,functools
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1]
sys.dont_write_bytecode=True;sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
im=NativeImage();state={};dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True
field_rows=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_bytes())
@functools.lru_cache(None)
def off(owner,name):
    namespace,_,kind=owner.rpartition('.');kind=kind.rsplit('/',1)[-1]
    if '/' in owner:namespace=''
    rows=[r for r in field_rows if r['type']==kind and r['name']==name and r['namespace']==namespace]
    assert len(rows)==1,(owner,name,rows);return rows[0]['offset']
def u8(p):return C.c_ubyte.from_address(p).value
def set8(p,v):C.c_ubyte.from_address(p).value=int(v)
def ptr(p,name,owner):return get64(p+off(owner,name))
def getstring(p):return C.string_at(p+0x14,get32(p+0x10)*2).decode('utf-16-le') if p else None
def string(value):
    if value is None:return 0
    data=value.encode('utf-16-le');p=im.alloc(24+len(data));put32(p+0x10,len(data)//2);C.memmove(p+0x14,data,len(data));return p
def ident(p):return state['ids'].get(p or 0,'null')
def obj(name,size=1024):p=im.alloc(size);state['ids'][p]=name;return p
def mode():return state['case'].get('mode','none')
def fcase(name,default):return struct.unpack('>f',bytes.fromhex(state['case'][name]))[0] if name in state['case'] else default
def strtail(p):return getstring(p) or ''
def live(p,method):
    assert not method;value=state['live'].get(p or 0,False);state['trace'].append('Live:'+ident(p)+':'+str(int(value)))
    if mode()=='implicit-replaces-clip' and ident(p).startswith('clip'):put64(state['ctrl']+off('FTRuntime.SwfClipController','_clip'),state['clip1'])
    return value
def getmanager(create,method):assert not method;state['trace'].append('Manager:'+str(int(create)));return state['manager']
def app(method):
    assert not method;c=state['case'];state['trace'].append('App:'+str(int(c.get('app_play',False))))
    if mode()=='app-flips-playing':p=state['ctrl']+off('FTRuntime.SwfClipController','_isPlaying');set8(p,not u8(p))
    return c.get('app_play',False)
def register(p,value,method,op):
    state['trace'].append(op+':'+state['assocs'][p]+':'+ident(value))
    if mode()=='manager-flips-auto':p=state['ctrl']+off('FTRuntime.SwfClipController','_autoPlay');set8(p,not u8(p))
def rewind(p,method):
    assert not method and p==state['ctrl'];state['trace'].append('Rewind')
    if mode()=='rewind-toggles-play':at=p+off('FTRuntime.SwfClipController','_isPlaying');set8(at,not u8(at))
def leaf(p,method,op):
    assert not method;state['trace'].append(op+':'+ident(p)+':'+str(get32(p+off('FTRuntime.SwfClip','_currentFrame')))+':'+strtail(ptr(p,'_sequence','FTRuntime.SwfClip')))
    if mode()=='change-frame-clears-event':put64(p+off('FTRuntime.SwfClip','OnChangeCurrentFrameEvent'),0)
def event(target,arg,method):
    kind,owner=state['events'][target]
    if owner=='clip':
        state['trace'].append('Event:'+ident(arg)+':'+kind+':'+str(get32(arg+off('FTRuntime.SwfClip','_currentFrame')))+':'+strtail(ptr(arg,'_sequence','FTRuntime.SwfClip')))
        if mode()=='clip-event-clears-next' and kind=='clip':put64(arg+off('FTRuntime.SwfClip','OnChangeSequenceEvent'),0)
    else:
        at=arg+off('FTRuntime.SwfClipController','_isPlaying');state['trace'].append('CtrlEvent:'+kind+':'+str(int(bool(u8(at))))+':'+bits(getf(arg+off('FTRuntime.SwfClipController','_tickTimer'))))
        if mode()=='controller-event-toggles-play':set8(at,not u8(at))
def event_object(kind,owner):
    p=im.alloc(128);target=im.alloc(64);state['events'][target]=(kind,owner);put64(p+0x18,event_pointer);put64(p+0x40,target);return p
def allocation(cls):
    p=obj('allocated');put64(p,cls);c=state['case'];rid=int(c['token'],16)&0xffffff
    if rid>=0x8aa:
        state['wait']=p;state['trace'].append('AllocateWait:'+state['wait_kind'])
    elif rid==0x17d:state['ids'][p]='default'
    elif rid==0x2d2:
        n=state['alloc_count'];state['trace'].append('AllocatePlantData' if n==0 else 'AllocateCardData');state['alloc_count']+=1
    else:raise AssertionError(('Unexpected allocation',hex(rid)))
    return p
def subscribe(p,c,method,kind):
    assert not method;state['trace'].append('Subscribe:'+kind+':'+ident(c));put64(p+0x10,c);return p
def delta(method):
    assert not method;value=fcase('delta',0.5);state['trace'].append('Delta:'+bits(value))
    if mode()=='delta-mutates-rest':putf(state['zombie']+off('Zombie','snowbeast_restTime'),999)
    return value
def trigger(p,key,method):
    assert not method;state['trace'].append('Trigger:'+ident(p)+':'+getstring(key))
    if mode()=='animator-flips-order':at=state['plant']+off('Plant','order');put32(at,0 if get32(at)>0 else 2)
def anim_bool(p,key,value,method):assert not method;state['trace'].append('AnimBool:'+ident(p)+':'+getstring(key)+':'+str(int(bool(value))))
def anim_float(p,key,value,method):assert not method;state['trace'].append('AnimFloat:'+ident(p)+':'+getstring(key)+':'+bits(value))
def material(p,method):assert not method;state['trace'].append('Material:'+ident(p));return state['materials'][p]
def material_float(p,key,value,method):
    assert not method;state['trace'].append('MaterialFloat:'+ident(p)+':'+getstring(key)+':'+bits(value))
    if mode()=='material-replaces-renderer':put64(state['owner']+off('Device/ICEUIController','spriteRenderer1'),state['renderer2'])
def game_object(p,method):assert not method;state['trace'].append('GameObject:'+ident(p));return state['games'][p]
def active(p,value,method):
    assert not method;state['trace'].append('Active:'+ident(p)+':'+str(int(bool(value))))
    if mode()=='active-replaces-text':put64(state['owner']+off('SkillButtonController','text_Level'),state['text1'])
def settext(p,value,parse,method):assert not method;state['text_values'][p]=getstring(value);state['trace'].append('Text:'+ident(p)+':'+strtail(value)+':'+str(int(bool(parse))))
def settext_one(p,value,method):assert not method;state['text_values'][p]=getstring(value);state['trace'].append('TextOne:'+ident(p)+':'+strtail(value))
def intstr(p,method):assert not method;return string(str(get32(p)))
def concat2(a,b,method):assert not method;return string(strtail(a)+strtail(b))
def concat4(a,b,c,d,method):assert not method;return string(strtail(a)+strtail(b)+strtail(c)+strtail(d))
def equal(a,b,method):assert not method;return getstring(a)==getstring(b)
def load_sprite(p,s,locked,method):assert not method;state['trace'].append('Sprite:'+ident(s)+':'+str(int(bool(locked))))
def pole_test(p,method):assert not method;state['trace'].append('PoleTest');return state['case'].get('test_jump',False)
def destroy(p,method):assert not method;state['trace'].append('DestroyZombie')
def mono_ctor(p,method):assert not method;state['trace'].append('MonoCtor:'+strtail(ptr(p,'label01','TMPro.Examples.TeleType'))+'|'+strtail(ptr(p,'label02','TMPro.Examples.TeleType')))
def data_ctor(p,value,method):
    assert not method and value==-1;state['trace'].append('AllocateData:'+str(value))
    if mode()=='allocation-mutates-entry':put64(state['owner']+off('PreDevice','entryKey'),string('changed'))
def window_state(p,value,method):
    assert not method;state['trace'].append('WindowState:'+str(int(bool(value))))
    if mode()=='state-mutates-id':put32(p+off('Almanac_DeviceWindow','deviceID'),-7)
def load_info(value,method):assert not method;state['trace'].append('LoadInfo:'+str(value));return obj('info:'+str(value))
def barrier(at,value):assert get64(at)==(value or 0)
def reject(*args):raise AssertionError('Native exceptional path is outside this normal-path profile')
metadata=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/global-metadata.dat').read_bytes()
assert hashlib.sha256(metadata).hexdigest()=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9'
so,sn,do,dn=struct.unpack_from('<4I',metadata,8)
cfgs={r['token']:json.loads((Q/'native-source-complete'/(r['token']+'.json')).read_bytes()) for r in json.loads((Q/'SOURCE-ROSTER.json').read_bytes())['rows']}
try:
    strings={};classes=set()
    for cfg in cfgs.values():
        for row in cfg['instructions']:
            i=next(dis.disasm(bytes.fromhex(row['bytes']),int(row['va'],16)))
            if i.mnemonic not in ['mov','lea']:continue
            for op in i.operands:
                if op.type!=X86_OP_MEM or op.mem.base!=X86_REG_RIP:continue
                at=i.address+i.size+op.mem.disp;encoded=int.from_bytes(im.pe.get_data(at-im.base,8),'little')
                if encoded>0xffffffff or encoded>>29 not in range(1,8):continue
                if encoded>>29==5:
                    index=(encoded&0x1fffffff)>>1;assert index<sn//8;length,pos=struct.unpack_from('<II',metadata,so+index*8);value=metadata[do+pos:do+pos+length].decode('utf-8');strings[at]=value
                else:classes.add(at)
    empty=string('')
    for at in classes:cls=im.class_slot(at);put64(get64(cls+0xb8),empty)
    for at,value in strings.items():put64(at,string(value))
    def init(slot):
        if slot in strings:return
        assert slot in classes,hex(slot);im.class_slot(slot)
    im.hook(0x18024fef0,None,[P],init);im.hook(0x1802501e0,None,[P],lambda p:None);im.hook(0x180250100,P,[P],allocation);im.hook(0x18024f360,None,[P,P],barrier)
    im.hook(0x18131f870,C.c_bool,[P,P],live);im.hook(0x1803c9170,P,[C.c_bool,P],getmanager);im.hook(0x1812df370,C.c_bool,[P],app)
    im.hook(0x1803c6970,None,[P,P],rewind)
    for va,op in [(0x1803c7360,'ChangeClip'),(0x1803c74f0,'ChangeSequence'),(0x1803c7420,'ChangeFrame')]:im.hook(va,None,[P,P],lambda p,m,op=op:leaf(p,m,op))
    # Exact native generic call sites for manager add/remove are resolved below.
    for token in ['0x0600084B','0x0600084C','0x0600087A','0x0600087B']:
        calls=[r for r in cfgs[token]['instructions'] if r['op']=='call' and r['operands'].startswith('0x1809')]
        assert len(calls)==1,(token,calls);va=int(calls[0]['operands'],16);op='Add' if token in ['0x0600084B','0x0600087A'] else 'Remove'
        im.hook(va,None,[P,P,P],lambda p,v,m,op=op:register(p,v,m,op))
    for va,kind in [(0x1803cbd20,'Stop'),(0x1803cb7f0,'Rewind'),(0x1803cba50,'StopOrRewind'),(0x1803cb470,'Play')]:im.hook(va,P,[P,P,P],lambda p,c,m,kind=kind:subscribe(p,c,m,kind))
    im.hook(0x18132c2f0,F,[P],delta);im.hook(0x1812dbc00,None,[P,P,P],trigger);im.hook(0x1812dba00,None,[P,P,C.c_bool,P],anim_bool);im.hook(0x1812dbab0,None,[P,P,F,P],anim_float)
    im.hook(0x1812fae70,P,[P,P],material);im.hook(0x1812efc70,None,[P,P,F,P],material_float);im.hook(0x1813044d0,P,[P,P],game_object);im.hook(0x18131bad0,None,[P,C.c_bool,P],active);im.hook(0x1811af070,None,[P,P,C.c_bool,P],settext)
    im.hook(0x180ca3820,P,[P,P],intstr);im.hook(0x180b74270,P,[P,P,P],concat2);im.hook(0x180b73950,P,[P,P,P,P,P],concat4);im.hook(0x180b76170,C.c_bool,[P,P,P],equal)
    im.hook(0x1803acbc0,None,[P,P,C.c_bool,P],load_sprite);im.hook(0x180371750,C.c_bool,[P,P],pole_test);im.hook(0x18035e470,None,[P,P],destroy);im.hook(0x1812e22a0,None,[P,P],mono_ctor);im.hook(0x180345e10,None,[P,I,P],data_ctor);im.hook(0x18038a700,None,[P,C.c_bool,P],window_state);im.hook(0x1803388c0,P,[I,P],load_info)
    im.hook(0x180250150,None,[P],reject);im.hook(0x180250140,None,[P],reject)
    def guarded_event(a,b,c):
        try:event(a,b,c)
        except Exception as e:im.errors.append(dict(callback='event',error=repr(e)))
    ecb=C.CFUNCTYPE(None,P,P,P)(guarded_event);im.callbacks.append(ecb);event_pointer=C.cast(ecb,P).value
    tcb=C.CFUNCTYPE(None,P,P,P)(settext_one);im.callbacks.append(tcb);text_pointer=C.cast(tcb,P).value
    for token,cfg in cfgs.items():im.verify_caller(int(token,16)&0xffffff,int(cfg['entry'],16),cfg)
    assert C.string_at(0x180302170,3)==bytes.fromhex('c20000') and C.string_at(0x18030f300,7)==im.pe.get_data(0x30f300,7)
    def clip(name,count,mask):
        p=obj(name);put32(p+off('FTRuntime.SwfClip','_currentFrame'),5);put64(p+off('FTRuntime.SwfClip','_sequence'),string('old'))
        if count!=-1:
            seq=obj(name+'-seq');put64(p+off('FTRuntime.SwfClip','_curSequence'),seq)
            if count!=-2:ls=obj(name+'-frames');put32(ls+0x18,count);put64(seq+off('FTRuntime.SwfClipAsset/Sequence','Frames'),ls)
        for flag,kind,name_ in [(1,'clip','OnChangeClipEvent'),(2,'sequence','OnChangeSequenceEvent'),(4,'frame','OnChangeCurrentFrameEvent')]:
            if mask&flag:put64(p+off('FTRuntime.SwfClip',name_),event_object(kind,'clip'))
        return p
    def clipstate(p):return dict(id=ident(p),frame=get32(p+off('FTRuntime.SwfClip','_currentFrame')),sequence=getstring(ptr(p,'_sequence','FTRuntime.SwfClip')),asset=None if not ptr(p,'_clip','FTRuntime.SwfClip') else ident(ptr(p,'_clip','FTRuntime.SwfClip')),event_sequence=bool(ptr(p,'OnChangeSequenceEvent','FTRuntime.SwfClip')),event_frame=bool(ptr(p,'OnChangeCurrentFrameEvent','FTRuntime.SwfClip')))
    def maketext(name):
        p=obj(name);cls=im.alloc(2048);put64(cls+0x558,text_pointer);put64(p,cls);state['text_values'][p]=None;state['games'][p]=obj(name+'-game');return p
    rows=[]
    for c in json.loads(Path(sys.argv[1]).read_bytes()):
        state.clear();state.update(case=c,trace=[],ids={0:'null'},events={},live={},assocs={},alloc_count=0,text_values={},games={},materials={})
        token=c['token'];rid=int(token,16)&0xffffff;entry=int(cfgs[token]['entry'],16);owner=obj('owner');state['owner']=owner
        if c['kind']=='swf':
            p0=clip('clip0',c.get('seq_count',3),c.get('event_mask',7));p1=clip('clip1',c.get('seq_count',3),c.get('event_mask',7));ctrl=obj('ctrl');state.update(ctrl=ctrl,clip0=p0,clip1=p1)
            state['live'].update({p0:c.get('clip_state',1)==1,p1:True});put64(ctrl+off('FTRuntime.SwfClipController','_clip'),p0 if c.get('clip_state',1) else 0);set8(ctrl+off('FTRuntime.SwfClipController','_isPlaying'),c.get('playing',False));set8(ctrl+off('FTRuntime.SwfClipController','_autoPlay'),c.get('auto_play',False));putf(ctrl+off('FTRuntime.SwfClipController','_tickTimer'),3.25)
            for flag,kind,name_ in [(1,'play','OnPlayStoppedEvent'),(2,'stop','OnStopPlayingEvent')]:
                if c.get('event_mask',7)&flag:put64(ctrl+off('FTRuntime.SwfClipController',name_),event_object(kind,'ctrl'))
            mgr=obj('manager') if c.get('manager_state',1) else 0;state['manager']=mgr;state['live'][mgr]=c.get('manager_state',1)==1
            if mgr:
                for name_ in ['clips','controllers']:ls=obj(name_);state['assocs'][ls]=name_;put64(mgr+off('FTRuntime.SwfManager','_'+name_),ls)
            value=0
            if rid>=0x8aa:
                state['wait_kind']='Play' if rid>=0x8b6 else 'Rewind' if rid in [0x8ac,0x8ad,0x8b2,0x8b3] else 'StopOrRewind' if rid in [0x8ae,0x8af,0x8b4,0x8b5] else 'Stop'
                typ=c['arg_type']
                if typ=='bool':value=C.CFUNCTYPE(P,P,C.c_bool,P)(entry)(ctrl,c['arg_bool'],None)
                elif typ=='int':value=C.CFUNCTYPE(P,P,I,P)(entry)(ctrl,c['arg_int'],None)
                elif typ=='string':value=C.CFUNCTYPE(P,P,P,P)(entry)(ctrl,string(c.get('arg_string')),None)
                else:value=C.CFUNCTYPE(P,P,P,I,P)(entry)(ctrl,string(c.get('arg_string')),c['arg_int'],None)
            elif rid in [0x86d,0x86f]:C.CFUNCTYPE(None,P,I,P)(entry)(ctrl,c['arg_int'],None)
            elif rid in [0x86e,0x870]:C.CFUNCTYPE(None,P,P,I,P)(entry)(ctrl,string(c.get('arg_string')),c['arg_int'],None)
            elif rid in [0x871,0x873]:C.CFUNCTYPE(None,P,C.c_bool,P)(entry)(ctrl,c['arg_bool'],None)
            elif rid in [0x872,0x874]:C.CFUNCTYPE(None,P,P,P)(entry)(ctrl,string(c.get('arg_string')),None)
            elif rid in [0x87a,0x87b]:C.CFUNCTYPE(None,P,P)(entry)(ctrl,None)
            elif rid==0x82f:C.CFUNCTYPE(None,P,P,P)(entry)(p0,obj('asset'),None)
            elif rid==0x831:C.CFUNCTYPE(None,P,P,P)(entry)(p0,string(c.get('arg_string')),None)
            elif rid==0x847:C.CFUNCTYPE(None,P,C.c_bool,C.c_bool,C.c_bool,P)(entry)(p0,c['flag1'],c['flag2'],c['flag3'],None)
            else:C.CFUNCTYPE(None,P,P)(entry)(p0,None)
            result=dict(playing=bool(u8(ctrl+off('FTRuntime.SwfClipController','_isPlaying'))),tick=bits(getf(ctrl+off('FTRuntime.SwfClipController','_tickTimer'))),auto=bool(u8(ctrl+off('FTRuntime.SwfClipController','_autoPlay'))),ctrl_clip=ident(ptr(ctrl,'_clip','FTRuntime.SwfClipController')) if ptr(ctrl,'_clip','FTRuntime.SwfClipController') else None,clip0=clipstate(p0),clip1=clipstate(p1),wait_kind=state['wait_kind'] if value else None,wait_target=ident(get64(value+0x10)) if value and get64(value+0x10) else None)
        else:
            z=obj('zombie');p=obj('plant');anim=obj('anim0');state.update(zombie=z,plant=p);put64(z+off('Zombie','animator'),anim);put64(p+off('Plant','animator'),anim)
            for name_,value in [('isStant',c.get('stant',False)),('snowbeast_isRest',c.get('rest',False))]:set8(z+off('Zombie',name_),value)
            putf(z+off('Zombie','snowbeast_restTime'),fcase('rest_time',9.5));putf(z+off('Zombie','healthPoint'),fcase('health',100));put32(p+off('Plant','order'),c.get('order',1));putf(p+off('Plant','pT_chomperviking_devourPoint'),5.5)
            if rid in [0x4b4,0x497,0x4a0,0x4a4,0x4a5]:C.CFUNCTYPE(None,P,P)(entry)(z,None)
            elif rid==0x43c:C.CFUNCTYPE(None,P,F,F,P,P)(entry)(z,fcase('time',1.25),fcase('intensity',2.5),string(c.get('target')),None)
            elif rid==0x380:C.CFUNCTYPE(None,P,P,P)(entry)(p,z,None)
            elif rid==0x311:put32(owner+off('Device','ID'),c['device_id']);result=dict(result=bool(C.CFUNCTYPE(C.c_bool,P,I,P,P)(entry)(owner,c['occupy'],string(c.get('target')),None)))
            elif rid==0x77c:C.CFUNCTYPE(None,P,P)(entry)(owner,None);result=dict(label1=getstring(ptr(owner,'label01','TMPro.Examples.TeleType')),label2=getstring(ptr(owner,'label02','TMPro.Examples.TeleType')))
            elif rid==0x344:
                render=[]
                for n in range(3):r=obj('renderer'+str(n));mat=obj('material'+str(n));state['materials'][r]=mat;render.append(r)
                state['renderer2']=render[2];put64(owner+off('Device/ICEUIController','spriteRenderer0'),render[0]);put64(owner+off('Device/ICEUIController','spriteRenderer1'),render[1]);C.CFUNCTYPE(None,P,F,P)(entry)(owner,fcase('intensity',2.5),None);result=dict(renderer1=ident(ptr(owner,'spriteRenderer1','Device/ICEUIController')))
            elif rid in [0x59b,0x6d7,0x719]:
                text0=maketext('text0');text1=maketext('text1');state['text1']=text1
                if rid==0x59b:
                    save=obj('plantSave');arr=im.alloc(64);put64(arr+0x18,3)
                    for n in range(3):put64(arr+32+8*n,string('talent'+str(n)))
                    put64(save+off('PlantSave','talents'),arr);put64(owner+off('Almanac_TalentSystem','talentDescription'),text0);put64(owner+off('Almanac_TalentSystem','plantSave'),save);C.CFUNCTYPE(None,P,I,P)(entry)(owner,c['index'],None);result=dict(text0=state['text_values'][text0])
                elif rid==0x6d7:
                    put64(owner+off('SkillButtonController','text_Level'),text0);sprite=obj('sprite');C.CFUNCTYPE(None,P,P,C.c_bool,I,P)(entry)(owner,sprite,c['locked'],c['level'],None);result=dict(text0=state['text_values'][text0],text1=state['text_values'][text1],owner_text=ident(ptr(owner,'text_Level','SkillButtonController')))
                else:
                    put64(owner+off('DropdownSample','text'),text0)
                    for name_,key in [('dropdownWithoutPlaceholder','normal_value'),('dropdownWithPlaceholder','placeholder_value')]:d=obj(name_);put32(d+0x130,c[key]);put64(owner+off('DropdownSample',name_),d)
                    C.CFUNCTYPE(None,P,P)(entry)(owner,None);result=dict(text0=state['text_values'][text0])
            elif rid==0x17d:
                put32(owner+off('PreDevice','gridX'),99);put32(owner+off('PreDevice','gridY'),98);put64(owner+off('PreDevice','entryKey'),string('before'));supplied=obj('supplied');C.CFUNCTYPE(None,P,I,I,P,P,P)(entry)(owner,c['grid_x'],c['grid_y'],supplied,string(c.get('entry')),None);result=dict(x=get32(owner+off('PreDevice','gridX')),y=get32(owner+off('PreDevice','gridY')),key=getstring(ptr(owner,'entryKey','PreDevice')),data=ident(ptr(owner,'data','PreDevice')))
            elif rid==0x2d2:
                put32(owner+off('PreCard','cardPlantType'),99);put32(owner+off('PreCard','cardDeviceType'),98);C.CFUNCTYPE(None,P,P)(entry)(owner,None);d=ptr(owner,'deviceData','PreCard');result=dict(plant_type=get32(owner+off('PreCard','cardPlantType')),device_type=get32(owner+off('PreCard','cardDeviceType')),plant_data=bool(ptr(owner,'plantData','PreCard')),camp=get32(d+off('Card/CardDeviceData','camp')),number=get32(d+off('Card/CardDeviceData','number')))
            elif rid==0x569:
                save=obj('save');arr=im.alloc(64);put64(arr+0x18,4)
                for n in range(4):set8(arr+32+n,n%2)
                put64(save+off('Save','almanac_DeviceLock'),arr);C.CFUNCTYPE(None,P,P,I,P)(entry)(owner,save,c['index'],None);result=dict(id=get32(owner+off('Almanac_DeviceWindow','deviceID')),info=ident(ptr(owner,'deviceInfo','Almanac_DeviceWindow')))
            else:raise AssertionError(hex(rid))
            if rid in [0x4b4,0x497,0x4a0,0x4a4,0x4a5,0x43c,0x380]:
                result=dict(ladder=bool(u8(z+off('Zombie','ladderZombie_place'))),jump=bool(u8(z+off('Zombie','poleZombie_jump'))),rest=bool(u8(z+off('Zombie','snowbeast_isRest'))),rest_time=bits(getf(z+off('Zombie','snowbeast_restTime'))),body_time=bits(getf(z+off('Zombie','brightTime'))),body_effect=bits(getf(z+off('Zombie','brightEffectTime'))),body_intensity=bits(getf(z+off('Zombie','brightIntensity'))),armor_time=bits(getf(z+off('Zombie','brightTime_Armor2'))),armor_effect=bits(getf(z+off('Zombie','brightEffectTime_Armor2'))),armor_intensity=bits(getf(z+off('Zombie','brightIntensity_Armor2'))),devour=bool(u8(p+off('Plant','pC_chomperviking_devour'))),order=get32(p+off('Plant','order')),devour_point=bits(getf(p+off('Plant','pT_chomperviking_devourPoint'))))
        assert not im.errors,im.errors;rows.append(dict(name=c['name'],token=token,kind=c['kind'],trace=list(state['trace']),state=result,error=None))
    report=dict(scope='FIFTY_ORIGINAL_PC_CALLERS_CONTROLLED_ENGINE_AND_ALLOCATION_CALLEES',original_sha256=PC_SHA,all_fifty_original_caller_bytes_verified_after_hooks=True,pdata_split_ranges_included=True,actual_unity=False,native_exception_execution=False,callback_errors=im.errors,results=rows)
    Path(sys.argv[2]).write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(dict(methods=len({r['token'] for r in rows}),records=len(rows))))
finally:im.close()
