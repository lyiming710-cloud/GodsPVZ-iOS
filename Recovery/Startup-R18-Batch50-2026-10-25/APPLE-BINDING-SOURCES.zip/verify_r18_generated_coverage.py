"""Explain the changed TU count using returned source/registration coverage."""
from pathlib import Path
import hashlib,json,re,tarfile
W=Path(__file__).resolve().parent;Q=W/'startup-r18-batch50';D=W.parents[1]/'audit/repo-native113/Recovery/Startup-R18-Batch50-2026-10-25'
def read(label,run):
    archive=W/f'{label}-compiler-run-{run}'/f'startup-{label}-generated.tar.gz';files={}
    with tarfile.open(archive,'r|gz') as z:
        for m in z:
            if m.isfile() and m.name.startswith('il2cppOutput/cpp/GodsPVZRuntime1'):
                files[Path(m.name).name]=z.extractfile(m).read().decode('utf-8-sig')
    reg=files['GodsPVZRuntime1_CodeGen.c'];match=re.search(r's_methodPointers\[(\d+)\]\s*=\s*\{(.*?)\};',reg,re.S);assert match
    entries=[x.strip().rstrip(',') for x in match[2].splitlines() if x.strip()];assert len(entries)==int(match[1])==2317
    symbols={}
    pattern=re.compile(r'^IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR[^\n]*?\b([A-Za-z0-9_]+_m[0-9A-Fa-f]{40}(?:_gshared)?)\s*\([^\n]*\)\s*\n\{',re.M)
    for name,text in files.items():
        if not name.endswith('.cpp'):continue
        for m in pattern.finditer(text):
            assert m[1] not in symbols,m[1];symbols[m[1]]=name
    return entries,symbols,files
old,od,of=read('r17',40166633598);new,nd,nf=read('r18',40172961231)
assert old==new,'Original method-pointer registration identities must remain complete and unchanged'
assert set(od)==set(nd),'All original generated game definitions must still be present'
roster=json.loads((Q/'SOURCE-ROSTER.json').read_bytes())['rows'];target=[]
for r in roster:
    symbol=new[(int(r['token'],16)&0xffffff)-1];assert symbol!='NULL' and symbol in nd
    target.append(dict(token=r['token'],symbol=symbol,cpp_file=nd[symbol]))
removed=sorted(set(of)-set(nf));assert removed==['GodsPVZRuntime1__13.cpp']
relocated=[dict(symbol=k,old_file=od[k],new_file=nd[k]) for k in od if od[k]=='GodsPVZRuntime1__13.cpp'];assert relocated and all(r['new_file'] in nf for r in relocated)
actual=json.loads((D/'ACTUAL-COMPILER-40172961231.json').read_bytes());assert actual['cpp']['attempted']==755 and actual['c']['attempted']==274 and actual['raw_generated_sources_rehashed']==1029
report=dict(scope='GENERATED_TU_REPACKING_NOT_MISSING_METHODS',candidate_sha256=actual['candidate_sha256'],old_cpp=756,new_cpp=755,c_files=274,raw_sources_rehashed=1029,registered_method_rows=2317,method_pointer_entries_identical=True,game_definition_sets_identical=True,game_generated_definitions=len(nd),all_fifty_registered_and_defined=True,fifty_targets=target,removed_tu=removed,definitions_from_old_last_tu_relocated=relocated,
    initial_apple_preparation='Stopped before mutation on stale 1030-file parent inventory; actual returned inventory is 1029 and is independently complete.',
    compiler_controls_or_flags_changed=False,new_unity_export=False,ipa=None)
for p in [Q/'GENERATED-SOURCE-COVERAGE.json',D/'GENERATED-SOURCE-COVERAGE.json']:p.write_bytes((json.dumps(report,indent=2)+'\n').encode())
print(json.dumps({k:v for k,v in report.items() if k not in ['fifty_targets','definitions_from_old_last_tu_relocated']},indent=2));print('last TU definitions preserved',len(relocated))
