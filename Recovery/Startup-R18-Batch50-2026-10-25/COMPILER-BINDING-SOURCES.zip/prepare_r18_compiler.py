"""Input-only next-fifty binding of the existing fresh compiler census."""
from pathlib import Path
import ast,json
from archive_support import sha,js,pack,manifest
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';D=R/'Recovery/Startup-R18-Batch50-2026-10-25'
status=json.loads((D/'CURRENT-RESULT.json').read_bytes());assert status['new_unique_methods']==50 and status['native_complete_cil_records']==2521 and status['all_reverts_detected']
old='d2a645ad0d8164af5fbdcbd9fcaa578d5a28b27e7b13f3012cdb51e63a256091';new=status['candidate_sha256']
src=R/'scripts/actions/check_startup_r17_compiler.py';parent=src.read_bytes();text=parent.decode().replace(old,new).replace('STARTUP_R17','STARTUP_R18').replace('STARTUP-R17-BATCH50','STARTUP-R18-BATCH50').replace('Startup R17 Batch50','Startup R18 Batch50')
ast.parse(text);dest=R/'scripts/actions/check_startup_r18_compiler.py';assert not dest.exists();dest.write_bytes(text.encode())
p=R/'.github/workflows/bulk401-generic-compiler-check.yml';before=p.read_bytes();snapshot=D/'PARENT-R17-COMPILER-WORKFLOW.yml';assert not snapshot.exists();snapshot.write_bytes(before)
text=before.decode().replace(old,new).replace('startup-r17','startup-r18').replace('Startup R17','Startup R18').replace('STARTUP-R17','STARTUP-R18').replace('Startup-R17','Startup-R18').replace('exact R17','exact R18').replace('check_startup_r17_compiler.py','check_startup_r18_compiler.py');assert old not in text and new in text and 'secrets.' not in text;p.write_bytes(text.encode())
js(D/'COMPILER-DRIVER-DERIVATION.json',dict(scope='NEXT_FIFTY_INPUT_ONLY_FRESH_ALL_GENERATED_SOURCE_CENSUS',candidate_sha256=new,parent_driver_sha256=sha(parent),driver_sha256=sha(dest.read_bytes()),parent_workflow_sha256=sha(before),workflow_sha256=sha(p.read_bytes()),controls_and_algorithm_unchanged=True,fifty_source_threshold_satisfied=True,unity_or_ipa=False))
pack(D/'COMPILER-BINDING-SOURCES.zip',[(f.relative_to(R).as_posix(),f.read_bytes()) for f in [src,dest,p,R/'scripts/actions/restore_bulk152_checkpoint.py',R/'scripts/actions/verify_bulk152_portable.py']]+[(Path(__file__).name,Path(__file__).read_bytes())]);manifest(D);print('Exact R18 Batch50 compiler census prepared')
