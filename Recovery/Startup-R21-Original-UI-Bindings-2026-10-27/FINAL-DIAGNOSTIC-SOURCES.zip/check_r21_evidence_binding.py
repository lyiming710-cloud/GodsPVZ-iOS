"""Reject false promotion and wrong candidate identities even with rehashed manifests."""
from pathlib import Path
import hashlib,importlib.util,json,shutil,sys,tempfile
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];tools=ROOT/'audit/repo-native113/scripts/actions';sys.path.insert(0,str(tools));sys.path.insert(0,str(W));from archive_support import js,manifest
import bind_startup_r21_diagnostic as binder
data,proof=binder.validate_checkpoint();rows=[]
with tempfile.TemporaryDirectory(prefix='r21-invalid-evidence-') as tmp:
 d=Path(tmp)/'checkpoint';shutil.copytree(binder.CHECKPOINT,d);p=d/'PROGRESS.json';original=p.read_bytes()
 for name,key,value in [('wrong_candidate','candidate_sha256','0'*64),('false_device_pass','ipad_acceptance',True),('false_game_pass','whole_game_accepted',True),('false_formal_promotion','qualified_methods',7),('unverified_ipa','ipa',{'status':'OK'})]:
  j=json.loads(original);j[key]=value;js(p,j);manifest(d)
  try:binder.validate_checkpoint(d)
  except ValueError as e:rows.append(dict(name=name,rejected=True,reason=str(e),manifest_rehashed_before_validation=True));continue
  raise AssertionError('Invalid promotion accepted '+name)
(Q/'R21-DIAGNOSTIC-BINDING-CONTROLS.json').write_bytes((json.dumps(dict(candidate_sha256=binder.CANDIDATE,positive_exact_checkpoint_pass=True,controls=rows),indent=2)+'\n').encode());print('Exact evidence binding pass; five rehashed false states rejected')
