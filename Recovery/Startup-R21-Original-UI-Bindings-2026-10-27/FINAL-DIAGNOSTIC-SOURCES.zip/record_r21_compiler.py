"""Read exact runner inputs, rehash every returned C/C++ source and raw log.

A green job for an earlier candidate is recorded as that earlier candidate.
No physical staged DLL, Unity export, link, IPA or device success is inferred.
"""
from pathlib import Path,PurePosixPath
import json,re,subprocess,sys,tarfile
from archive_support import sha,js,pack,manifest
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';D=R/'Recovery/Startup-R21-UI139-2026-10-27';A=Path(sys.argv[1]).resolve();run=int(sys.argv[2]);expected=sys.argv[3];head=sys.argv[4]
gh=r'C:\Program Files\GitHub CLI\gh.exe';meta=json.loads(subprocess.check_output([gh,'run','view',str(run),'--repo','lyiming710-cloud/GodsPVZ-iOS','--json','headSha,status,conclusion,url,jobs']))
assert meta['headSha']==head and meta['status']=='completed' and meta['conclusion']=='success';js(A/'RUN.json',meta)
Q=A/'startup-r21';report=json.loads((Q/'STARTUP-R21-UI139-COMPILER-REPORT.json').read_bytes());assert report['candidate_sha256']==expected and report['pass'] and report['conversion']['exit_code']==0
cpp=json.loads((Q/'ALL-CPP-RESULTS.json').read_bytes());c=json.loads((Q/'ALL-C-RESULTS.json').read_bytes());assert len(cpp)==report['cpp']['attempted']==report['cpp']['passed']==report['conversion']['total_cpp_count'] and len(c)==report['c']['attempted'];files={r['file']:r for r in cpp+c};assert len(files)==len(cpp)+len(c) and cpp and c and all(r['exit_code']==r['error_count']==0 for r in files.values())
found={}
with tarfile.open(A/'startup-r21-generated.tar.gz','r|gz') as t:
 for m in t:
  p=PurePosixPath(m.name);assert '..' not in p.parts and not p.is_absolute()
  if not m.isfile() or not m.name.startswith('il2cppOutput/cpp/'):continue
  data=t.extractfile(m).read();assert p.name in files and p.name not in found;r=files[p.name];assert len(data)==r['bytes'] and sha(data)==r['sha256'];found[p.name]=dict(file=m.name,bytes=len(data),sha256=sha(data))
assert set(found)==set(files)
items=[];staged=[];returned=[];logs={}
with tarfile.open(A/'startup-r21-evidence.tar.gz','r|gz') as t:
 for m in t:
  p=PurePosixPath(m.name);assert '..' not in p.parts and not p.is_absolute()
  if not m.isfile():continue
  data=t.extractfile(m).read();items.append((m.name.lstrip('./'),data))
  if p.suffix=='.dll':returned.append(dict(file=m.name,bytes=len(data),sha256=sha(data)))
  if m.name.endswith('COHERENT-PLAYER-INPUT-ASSEMBLIES.json'):
   v=json.loads(data);r=next(r for r in v['files'] if r['name']=='GodsPVZRuntime1.dll');staged.append(dict(path=m.name,sha256=r['sha256'],bytes=r['bytes'],assemblies=v['count']))
  if '/candidate/' in m.name and p.name.endswith(('.cpp.log','.c.log')):
   n=p.name[:-4];assert n not in logs and n in files;s=data.decode('utf-8',errors='replace');errors=sum(bool(re.search(r': (?:fatal )?error:',x)) for x in s.splitlines());assert errors==files[n]['error_count']==0;logs[n]=dict(file=m.name,bytes=len(data),sha256=sha(data),error_count=errors,warning_count=s.count(': warning:'))
assert set(logs)==set(files),(len(logs),len(files))
assert any(r['sha256']==expected and r['bytes']==23218688 and '/candidate/' in r['path'] for r in staged)
assert any(r['sha256']=='ef1992326d1ee494a389bc2c78bdfab131721434c0b08ab5f41dbc3e506c4e48' for r in staged)
assert len(report['compiler_controls'])==6 and all((r['exit_code']!=0)==r['expected_nonzero'] for r in report['compiler_controls'])
damaged=report['damaged_r4_control'];assert sum(r['error_count'] for r in damaged['units'])==37 and all(r['exit_code']!=0 for r in damaged['units'])
items += [('top-level/'+p.name,p.read_bytes()) for p in Q.glob('*.json')]+[(p.name,p.read_bytes()) for p in [A/'RUN.json',A/'startup-r21-restore-receipt.json',Path(__file__)]]
pack(D/f'ACTUAL-COMPILER-EVIDENCE-{run}.zip',items)
result=dict(scope='EXACT_R21_CANDIDATE_FRESH_LINUX_IL2CPP_AND_ALL_GENERATED_SOURCE_SYNTAX_ONLY',run_id=run,url=meta['url'],source_commit=head,candidate_sha256=expected,pass_=True,conversion=report['conversion'],cpp=report['cpp'],c=report['c'],compiler_controls=6,damaged_r4_errors=37,raw_generated_sources_rehashed=len(found),raw_source_logs_rechecked=len(logs),warnings=sum(r['warning_count'] for r in logs.values()),source_rows=[found[n] for n in sorted(found)],log_rows=[logs[n] for n in sorted(logs)],raw_staged_manifest_readbacks=staged,staged_physical_dlls_returned=returned,staged_dll_identity_evidence='RUNNER_MANIFEST_READBACK_NOT_PHYSICAL_STAGED_DLL',downloaded_archives=[dict(file=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in A.glob('*.tar.gz')],unity_editor=False,apple_compiler=False,linking=False,ipa=None)
js(D/f'ACTUAL-COMPILER-{run}.json',result);manifest(D);print(json.dumps({k:v for k,v in result.items() if k not in ['source_rows','log_rows','raw_staged_manifest_readbacks']},indent=2))
