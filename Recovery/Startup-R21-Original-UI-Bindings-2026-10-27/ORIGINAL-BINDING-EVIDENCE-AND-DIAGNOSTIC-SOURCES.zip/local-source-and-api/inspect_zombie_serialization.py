"""Read exact raw prefab component bytes; never infer a custom tree from base-only decode."""
from pathlib import Path
import hashlib,json,sys,zipfile
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'python-deps'));import UnityPy
rows=[]
archives=[('PC',ROOT/'GodsPVZ_1.0.2.zip',16473),('R20',next((W/'r20-full-build-run-40263428409/ipa').glob('*.ipa')),18650)]
for label,path,component_id in archives:
 with zipfile.ZipFile(path) as z:
  member=next(n for n in z.namelist() if n.endswith('/resources.assets'));raw=z.read(member);env=UnityPy.load(raw);objects={o.path_id:o for o in env.objects};obj=objects[component_id];assert obj.type.name=='MonoBehaviour'
  header=obj.read_typetree(check_read=False);data=obj.get_raw_data();(Q/(label+'-ZombieWindow-component.bin')).write_bytes(data)
  pointers=[]
  # Record every aligned potential pointer separately from its interpretation.
  for at in range(32,len(data)-11,4):
   file_id=int.from_bytes(data[at:at+4],'little',signed=True);path_id=int.from_bytes(data[at+4:at+12],'little',signed=True)
   if file_id==0 and path_id in objects:
    target=objects[path_id];tree=target.read_typetree(check_read=False)
    pointers.append(dict(offset=at,file_id=file_id,path_id=path_id,type=target.type.name,name=tree.get('m_Name'),game_object=tree.get('m_GameObject'),script=tree.get('m_Script')))
  script=header.get('m_Script');script_info=None
  if script and script['m_FileID']==0 and script['m_PathID'] in objects:script_info=objects[script['m_PathID']].read_typetree()
  rows.append(dict(origin=label,archive_file=str(path),resources_sha256=hashlib.sha256(raw).hexdigest(),component_path_id=component_id,component_bytes=len(data),component_sha256=hashlib.sha256(data).hexdigest(),partial_header_only=header,script=script_info,aligned_reference_candidates_not_full_typed_decode=pointers,raw_hex=data.hex(),externals=[str(x) for x in obj.assets_file.externals]))
(Q/'ZOMBIE-WINDOW-RAW-SERIALIZATION.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');print(json.dumps([{k:v for k,v in r.items() if k not in ['raw_hex','externals','script']} for r in rows],ensure_ascii=True))
