"""Derive the actual UI diagnostic from the exercised R20 path; no export allowed yet."""
from pathlib import Path
import ast,hashlib,json,sys
Q=Path(__file__).resolve().parent;W=Q.parent;R=W.parents[1]/'audit/repo-native113';sys.path.insert(0,str(W));from archive_support import js,pack,manifest,sha
D=R/'Recovery/Startup-R21-Original-UI-Bindings-2026-10-27';assert not D.exists();D.mkdir();(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text\n*.md -text\n*.zip -text\n*.py -text\n*.yml -text\n*.prefab -text\n')
changes=[];files=[];oldhash='d887b370c95c2966dc40d80648d85c286bb42d85004c32d095f64f004e095b37';newhash='75160a3233f1e1ab13a44f712efb4b47fdeb9b57bd38fa25f180276bb7b50e15'
for name in ['prepare_startup_r20_unity.py','prepare_startup_r20_plugin.py']:
 src=R/'scripts/actions'/name;dest=src.with_name(name.replace('r20','r21'));assert not dest.exists();text=src.read_text('utf-8');assert text.count(oldhash)==1;text=text.replace(oldhash,newhash);ast.parse(text);dest.write_bytes(text.encode());changes.append(dict(source=name,source_sha256=sha(src.read_bytes()),derived=dest.name,derived_sha256=sha(dest.read_bytes()),only_changed_expected_candidate_hash=True));files += [('old-tools/'+name,src.read_bytes()),('tools/'+dest.name,dest.read_bytes())]
wf=R/'.github/workflows/bulk401-startup-runtime-gate.yml';old=wf.read_bytes();(D/'PARENT-R20-INTERACTION-WORKFLOW.yml').write_bytes(old);text=old.decode();edits=[]
def replace(a,b):
 global text
 assert a in text,a;edits.append(dict(before=a,after=b,occurrences=text.count(a)));text=text.replace(a,b)
for a,b in [(oldhash,newhash),('Startup R20 exact candidate - unsigned iOS test build','Startup R21 UI139 - actual interaction diagnosis'),('Diagnose unchanged R20 plant choice, almanac and Board callbacks; requires audit_only','Exercise R21 actual UI paths and original zombie prefab bindings; requires audit_only'),('Recovery/Startup-R20-Sites104-2026-10-26','Recovery/Startup-R21-UI139-2026-10-27'),('STARTUP-R20-SITES104','STARTUP-R21-UI139'),('python3 scripts/actions/validate_startup_r20_build_inputs.py','python3 scripts/actions/bind_startup_r21_diagnostic.py --validate-only'),('bind_startup_r20_diagnostic.py','bind_startup_r21_diagnostic.py'),('prepare_startup_r20_unity.py','prepare_startup_r21_unity.py'),('prepare_startup_r20_plugin.py','prepare_startup_r21_plugin.py'),('Diagnose unchanged R20 UI paths','Diagnose R21 actual UI paths'),('r20-interaction-audit','r21-interaction-audit'),('r20-after-interaction-dll','r21-after-interaction-dll'),('Actual R20 interaction failures','Actual R21 interaction failures')]:replace(a,b)
anchor='      - name: Reject exact candidates with already proven compiler failures before setup\n';require='''      - name: Keep R21 restricted to actual UI diagnosis until its new Editor result is reviewed
        if: ${{ !inputs.assets_only }}
        env:
          AUDIT: ${{ inputs.audit_only }}
          INTERACTION: ${{ inputs.interaction_audit }}
        run: '[ "$AUDIT" = true ] && [ "$INTERACTION" = true ]'
''';replace(anchor,require+anchor)
anchor='      - name: Verify every relocated resource GUID, path and original imported name\n';step='''      - name: Restore six original serialized zombie-window component references after candidate reimport
        shell: bash
        run: |
          set -euo pipefail
          OUT="$RUNNER_TEMP/stage9-startup-r2"
          PROJECT="$(cat "$OUT/project-path.txt")"
          python3 scripts/actions/restore_startup_r21_zombie_bindings.py --project "$PROJECT" --plan "$GITHUB_WORKSPACE/Recovery/Startup-R21-Original-UI-Bindings-2026-10-27/ZOMBIE-WINDOW-BINDING-PLAN.json" --output "$OUT/evidence"
''';replace(anchor,step+anchor)
anchor='      - name: Diagnose R21 actual UI paths';at=text.index(anchor);part=text[at:];a='          GODSPVZ_STARTUP_EVIDENCE: ${{ runner.temp }}/stage9-startup-r2/evidence\n';assert a in part;part=part.replace(a,a+"          GODSPVZ_INTERACTION_CANDIDATE_SHA256: ${{ env.TEST_DLL_SHA256 }}\n          GODSPVZ_INTERACTION_PREFIX: 'r21'\n",1);text=text[:at]+part
wf.write_bytes(text.encode());files.append(('workflow/'+wf.name,wf.read_bytes()));files.extend(('tools/'+n,(R/'scripts/actions'/n).read_bytes()) for n in ['GodsPVZInteractionAudit.cs','bind_startup_r21_diagnostic.py','restore_startup_r21_zombie_bindings.py'])
for name in ['ZOMBIE-WINDOW-BINDING-PLAN.json','ZOMBIE-WINDOW-RAW-SERIALIZATION.json','ZOMBIE-WINDOW-HIERARCHY.json','ZOMBIE-WINDOW-SCRIPT-IDENTITIES.json','BINDING-PATCHER-CONTROLS.json']:(D/name).write_bytes((Q/name).read_bytes())
for p in sorted(Q.glob('*')):
 if p.is_file() and (p.suffix in ['.py','.bin'] or p.name.startswith('INTERACTION-HELPER-API')):files.append(('local-source-and-api/'+p.name,p.read_bytes()))
pack(D/'ORIGINAL-BINDING-EVIDENCE-AND-DIAGNOSTIC-SOURCES.zip',files);js(D/'DERIVATION.json',dict(candidate_sha256=newhash,previous_workflow_sha256=sha(old),current_workflow_sha256=sha(wf.read_bytes()),script_derivations=changes,workflow_replacements=edits,diagnostic_only_guard_added=True,source_binding_patch_after_actual_candidate_reimport=True,original_script_guids_and_unrelated_prefab_bytes_preserved=True,extra_method_repairs=0,source_bindings=6,real_source_patch_not_executed_yet=True,unity_licensing_return_shader_and_original_assertions_preserved=True))
js(D/'PROGRESS.json',dict(status='PREPARED_ORIGINAL_SIX_REFERENCE_RESTORE_AND_ACTUAL_R21_UI_DIAGNOSTIC',candidate_sha256=newhash,method_repairs=139,changed_methods=7,additional_resource_reference_sites=6,actual_source_asset_patch='PENDING_REAL_R3_WORKCOPY',actual_unity_import='PENDING',actual_interaction='PENDING',ipad_acceptance=False,ipa=None))
(D/'README.md').write_bytes('''# R21：僵尸图鉴原始资源绑定与真实界面复测

原版PC resources.assets中的Almanac_ZombieWindow组件208字节，头部之后至136字节的标量/嵌套数据与实际R20 IPA一致；136–208六个序列化PPtr在原版分别指向Portrait.Image、QMark.Image、CMark.Image、EMark.Image、BMark.Image、Portrait.Button，在实际R20 IPA中全部为0。两侧同名层级与六个目标组件均仍存在；globalgamemanagers.assets的MonoScript独立确认实际类为Almanac_ZombieWindow、UnityEngine.UI.Image、UnityEngine.UI.Button。原始二进制与层级/脚本身份报告已保存。不能把只读base类型树或候选指针扫描当成完整自定义类型树解析。

修复工具仅在隔离工作副本、实际候选重新导入后，按原版根相对路径恢复六个本地fileID数字。保留其余所有预制体字节、全部其他Assets文件、meta/GUID及原UnityEvents；拒绝不同非空目标、重复路径、丢失字段、类型特征不匹配与越界路径。不创建占位对象、不隐藏异常、不改Awake控制流、不在运行时填游戏字段。局部解析/逆变换/重复读回和五个错误输入负控制已过；真实R3文件上的执行、重新导入和游戏效果尚待工作流。

更新的Editor诊断补上正常OpenPlantHome，跟踪同一个被点击卡片，读取真实gameStart/senarioState字段、全部音效列表和图鉴组件引用，增加选卡确认后界面关闭断言，并从实际显示的主菜单文字沿父级查找正常指针处理组件。仍通过EventSystem.RaycastAll判断遮挡并ExecuteHierarchy投递指针，直接公开回调作为单独诊断。预制体加载后会独立核对六个字段的实际类型/目标。helper已用精确Editor API编译，运行时SHA由实际插件读取并与工作流参数核对。

已登记入口沿用bulk401-startup-runtime-gate.yml，并限制audit_only=true、interaction_audit=true才可执行Editor模式。资格绑定须验证R21自己的139处/7方法、344条有限对照、15物理语义负控制和新Linux/Apple完整源码结果；R20父证据分开保留，不把父编译成绩移植给子候选。已有着色器、脚本/资源、席位归还和失败保存检查保持。本轮准备不等于真实UI、iPad或新IPA通过。
'''.encode());manifest(D);print(json.dumps(dict(checkpoint=D.name,source_bindings=6,method_repairs=139,diagnostic_workflow_prepared=True)))
