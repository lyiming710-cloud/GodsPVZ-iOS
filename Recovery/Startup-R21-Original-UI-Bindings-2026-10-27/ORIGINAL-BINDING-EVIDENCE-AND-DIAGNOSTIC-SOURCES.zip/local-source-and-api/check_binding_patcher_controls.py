"""Bounded parser/isolation controls; not original prefab or Unity acceptance."""
from pathlib import Path
import copy,importlib.util,json,tempfile
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];script=ROOT/'audit/repo-native113/scripts/actions/restore_startup_r21_zombie_bindings.py';spec=importlib.util.spec_from_file_location('repair',script);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);plan=json.loads((Q/'ZOMBIE-WINDOW-BINDING-PLAN.json').read_bytes())
def doc(kind,anchor,body):return f'--- !u!{kind} &{anchor}\nObject:\n'+body
text='%YAML 1.1\n%TAG !u! tag:unity3d.com,2011:\n'+doc(1,1,'  m_Name: ZombieWindow\n')+doc(224,2,'  m_GameObject: {fileID: 1}\n  m_Father: {fileID: 0}\n')+doc(114,3,'  m_GameObject: {fileID: 1}\n  zombieID: -1\n  zombieInfo:\n    healthPoint: 270\n'+''.join('  '+field+': {fileID: 0}\n' for field in m.FIELDS))
for i,name in enumerate(['Portrait','QMark','CMark','EMark','BMark'],1):
 gid=10*i;tid=gid+1;image=gid+2;text+=doc(1,gid,'  m_Name: '+name+'\n')+doc(224,tid,f'  m_GameObject: {{fileID: {gid}}}\n  m_Father: {{fileID: 2}}\n')+doc(114,image,f'  m_GameObject: {{fileID: {gid}}}\n  m_Script: {{fileID: 11500000, guid: '+('1'*32)+', type: 3}\n  m_Sprite: {fileID: 0}\n  m_Type: 0\n  m_PreserveAspect: 1\n')
 if name=='Portrait':text+=doc(114,13,'  m_GameObject: {fileID: 10}\n  m_Script: {fileID: 11500000, guid: '+('2'*32)+', type: 3}\n  m_Interactable: 1\n  m_OnClick:\n    m_PersistentCalls:\n      m_Calls: []\n')
raw=text.encode();out,changes=m.patch(raw,plan);assert len(changes)==6 and all(c['changed'] for c in changes);again,changes2=m.patch(out,plan);assert again==out and all(not c['changed'] for c in changes2)
controls=[]
for name,b,p in [('different_nonnull',raw.replace(b'zombiePortrait: {fileID: 0}',b'zombiePortrait: {fileID: 999}'),plan),('missing_component',raw.replace(b'  m_PreserveAspect: 1\n',b'  unknown: 1\n',1),plan),('ambiguous_path',raw.replace(b'  m_Name: QMark',b'  m_Name: Portrait'),plan),('missing_field',raw.replace(b'  bossMark:',b'  removedField:'),plan),('changed_scope',raw,dict(plan,owner_type='DifferentType'))]:
 try:m.patch(b,p)
 except ValueError as e:controls.append(dict(name=name,rejected=True,reason=str(e)));continue
 raise AssertionError('Invalid source accepted '+name)
with tempfile.TemporaryDirectory(prefix='godspvz-r21-bindings-') as tmp:
 root=Path(tmp)/'project';(root/'ProjectSettings').mkdir(parents=True);(root/'ProjectSettings/ProjectVersion.txt').write_bytes(b'm_EditorVersion: 2022.3.44f1c1\n');a=root/'Assets/Resources/Prefabs/UI/SmallObjects';a.mkdir(parents=True);(a/'ZombieWindow.prefab').write_bytes(raw);(a/'ZombieWindow.prefab.meta').write_bytes(b'guid: '+b'3'*32+b'\n');(root/'Assets/unrelated.asset').write_bytes(b'unchanged\r\n');r=m.repair(root,Q/'ZOMBIE-WINDOW-BINDING-PLAN.json',Path(tmp)/'evidence');assert r['all_other_prefab_bytes_preserved'] and r['all_other_asset_bytes_preserved'] and len(r['changed_asset_paths'])==1 and len(r['changes'])==6
(Q/'BINDING-PATCHER-CONTROLS.json').write_bytes((json.dumps(dict(scope='SYNTHETIC_PARSER_AND_BYTE_ISOLATION_CONTROLS_NOT_UNITY_OR_ACTUAL_ASSET_ACCEPTANCE',six_value_patch_and_inverse=True,idempotent_readback=True,other_asset_and_meta_bytes_preserved=True,negative_controls=controls),indent=2)+'\n').encode());print('binding controls: 3 positive paths, 5 rejected malformed inputs')
