"""Read original callers and the exact shipped R20 CIL; no game tests."""
from pathlib import Path
import hashlib, json, sys
Q=Path(__file__).resolve().parent;W=Q.parent;sys.dont_write_bytecode=True
source=(W/'startup-r20-sites100/source_common.py').read_text('utf-8')
source=source.replace("W/'startup-r19-batch100/candidate9.dll'", "W/'startup-r20-sites100/authored3.dll'")
source=source.replace('0ba5bc7ec9603d14a1c0bde6d784d232aa78efaa1700304e75e4f2b56ef7dec2','d887b370c95c2966dc40d80648d85c286bb42d85004c32d095f64f004e095b37')
source=source.replace("W/'whole-program-census-2026-10-26/run3/ALL-CIL.json'", "W/'startup-r20-sites100/shared-authored3/ALL-CIL.json'")
source=source.replace('fn=next(x.struct for x in pc.DIRECTORY_ENTRY_EXCEPTION if x.struct.BeginAddress<=entry-base<x.struct.EndAddress);','fn=next((x.struct for x in pc.DIRECTORY_ENTRY_EXCEPTION if x.struct.BeginAddress<=entry-base<x.struct.EndAddress),None);').replace('runtime_end=hex(base+fn.EndAddress)','runtime_end=hex(base+fn.EndAddress) if fn is not None else None')
p=Q/'source_common.py'
if p.exists():assert p.read_bytes()==source.encode()
else:p.write_bytes(source.encode())
import source_common as s
tokens=[0x2a8,0x2a9,0x2b4,0x2bd,0x2c2,0x2c8,0x193,0x194,0x195,0x198,0x2f2,0x2f3,0x2f4,0x2f5,0x548,0x54e,0x57e,0x57f,0x580,0x5ad,0x5af,0x67e,0x67f,0x6b4,0x6bd,0x6c2]
rows=[]
for rid in tokens:
 token=s.tok(rid);m=s.methods[token];n=s.save_native(rid)
 (Q/(token+'.cil.json')).write_bytes((json.dumps(m,indent=2)+'\n').encode())
 lines=[m['name'], 'LOCALS '+str(m['locals']), 'HANDLERS '+str(m['handlers'])]
 for i in m['instructions']:
  v=i['operand'];v=v.get('identity',v) if isinstance(v,dict) else v
  lines.append(f"{i['offset']:04X} {i['opcode']} {v}")
 (Q/(token+'.cil.txt')).write_bytes(('\n'.join(lines)+'\n').encode())
 slot=s.body(token)
 rows.append(dict(token=token,method=m['name'],native_entry=n['entry'],native_instructions=len(n['instructions']),native_indirect_jumps=n['indirect_jumps'],native_boundaries=n['outside_boundaries'],cil_sha256=s.sha(slot['code']),cil_bytes=slot['code_size']))
(Q/'SOURCE-IDENTITIES.json').write_bytes((json.dumps(dict(candidate_sha256=s.sha(s.parent),methods=rows,game_tests=False,constructed_positions=0),indent=2)+'\n').encode())
print(json.dumps(dict(methods=len(rows),candidate_sha256=s.sha(s.parent),game_tests=False)))
