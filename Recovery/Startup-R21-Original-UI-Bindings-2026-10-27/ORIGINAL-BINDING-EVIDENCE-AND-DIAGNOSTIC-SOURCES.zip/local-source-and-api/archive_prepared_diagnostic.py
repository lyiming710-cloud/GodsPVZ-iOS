from pathlib import Path
import hashlib,json,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;R=W.parents[1]/'audit/repo-native113';sys.path.insert(0,str(W))
from archive_support import js,manifest,pack
import source_common as s
D=R/'Recovery/Startup-R20-Interaction-Diagnostic-2026-10-26';assert not D.exists();D.mkdir()
(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text\n*.md -text\n*.zip -text\n*.py -text\n*.cs -text\n*.yml -text\n')
rows=[]
for p in sorted((Q/'native-source-complete').glob('*.json')):
 token=p.stem;m=s.methods[token];js(Q/(token+'.cil.json'),m);rows.append(dict(token=token,name=m['name'],cil_code_sha256=s.sha(s.body(token)['code']),native_cfg_sha256=s.sha(p.read_bytes())))
js(Q/'CURRENT-SOURCE-ROSTER.json',dict(scope='SOURCE_INSPECTION_ONLY_NO_GAME_TEST',candidate_sha256=s.sha(s.parent),methods=rows))
js(Q/'UNTRUSTED-PROBE-EXCLUSIONS.json',dict(excluded=[dict(file='0x18047ba80.bounded-native.json',reason='Manually requested address was inside another pdata function; invalid entry. Not used for any reconstruction or semantic conclusion.')],no_game_code_changed=True))
js(Q/'PRE-COMPILER-REFERENCE-ASSUMPTION.json',dict(attempt='Before first compiler invocation',failure='UnityEditor.SceneManagementModule.dll not present; EditorSceneManager is available from the exact CoreModule',actual_compiler_then_passed_with_bound_core_modules=True,game_tests=False))
js(D/'DEVICE-REPORT.json',json.loads((Q/'DEVICE-REPORT.json').read_bytes()))
js(D/'PROGRESS.json',dict(status='DEVICE_UI_FAILURE_REPORTED_R20_BASELINE_INTERACTION_DIAGNOSTIC_PREPARED',candidate_sha256=s.sha(s.parent),prior_authored_positions=104,prior_changed_methods=8,current_game_changes=0,new_candidate_tests=0,diagnostic_scope='Existing shipped R20 after explicit device failures; no new R21 game candidate',source_methods_inspected=len(rows),helper_api_compilation='PASS_EXACT_EDITOR_MODULES',workflow_status='NOT_DISPATCHED',ipad_acceptance=False,device_binary_identity_independently_verified=False,r21_constructed_positions=0))
files=[('local-observations/'+p.relative_to(Q).as_posix(),p.read_bytes()) for p in sorted(Q.rglob('*')) if p.is_file() and '__pycache__' not in p.parts]
for name in ['GodsPVZInteractionAudit.cs','bind_startup_r20_diagnostic.py','preflight_build_capture_editor.py']:
 p=R/'scripts/actions'/name;files.append(('diagnostic-source/'+name,p.read_bytes()))
files.append(('diagnostic-source/bulk401-startup-runtime-gate.yml',(R/'.github/workflows/bulk401-startup-runtime-gate.yml').read_bytes()))
old=subprocess.check_output(['git','show','fd77f63aef740e16706ca6904c08cfb30948be3d:scripts/actions/bind_startup_r20_diagnostic.py'],cwd=R)
files.append(('previous-binder/bind_startup_r20_diagnostic.py',old))
pack(D/'DEVICE-FEEDBACK-SOURCE-INSPECTION-AND-DIAGNOSTIC.zip',files)
(D/'README.md').write_bytes('''# R20 真机交互失败反馈与原包诊断

用户在2026-10-26报告：选植物和确定按钮无效；进入关卡后无法正常操作，对话结束仍只有场景，主菜单按钮无效而倍速可用；图鉴点击植物后卡片消失，没有详情；僵尸图鉴为空。四张截图显示MainMenu/设置/卡片/Board地形已经渲染，选卡上方出现NaN。当前按最近交付R20的上下文记录，尚未从设备独立读取所安装IPA的SHA；不把截图当成全部设备状态或黑屏已解决的证明。

本轮不修改游戏DLL，固定d887b370…095b37；只新增现有R20的Editor交互诊断。R20已满足104处修复/8方法后共享检测的门槛，此次扩展是对用户实际失败路径的复现。R21仍是16个提案、0构造位置，没有在新游戏修复未超过100处前启动新候选的测试。

已读取31个相关完整当前CIL/原版调用方源记录，并读取原版和实际IPA的Resources目录。关键三个预制体路径在两侧均存在，资源容器目标类型同为GameObject；不能仅凭这些证据声称其组件加载一定成功。UI排序中set_position与原版调用一致，Almanac.Awake没有写canvas也与原版相同，均没有猜改。UnityPy对自定义MonoBehaviour缺类型树的读取错误保持为解析限制；手工误选的函数内部地址反汇编被显式排除，未作为恢复依据。

GodsPVZInteractionAudit会从实际MainMenu进入Play Mode，使用当前存档或正常公开游戏API在CI创建新存档，分开记录EventSystem射线/指针分发和直接调用既有公开回调的结果。流程包括植物图鉴、僵尸图鉴、冒险准备、卡片选择/确定、开局、逐次推进真实对话、关卡菜单和返回。记录实际字段、列表、可见NaN文本、UI持久事件和异常堆栈。不会给游戏字段喂fixture，不替换方法或资源，不绕过被遮挡的射线，不把直接回调诊断当成iPad触控通过。Editor合成指针分发仍不等于真实设备输入。

新增helper已用hash绑定的真实Editor模块编译通过，CI也会在获取席位前再用完整精确API编译。旧绑定器把ipa=None作为硬条件，这在实际测试IPA已产生后过时；现改为有IPA时核验已保存的真实构建/字节身份，并继续保留游戏和设备未验收。错误SHA、大小、签名声明、模拟器和CPU五个负控制均被拒绝；历史未导出状态继续接受。没有降低冻结CIL验证器的标准。

工作流interaction_audit默认false，仅允许与audit_only=true且assets_only=false组合；诊断后不导出/链接新IPA。任何观察检查失败保留报告并令该步失败，归还席位和保存日志仍走原always流程。此检查点仅表示准备和工具/API检查通过，真实交互结果以之后的run与原始报告为准。
'''.encode());manifest(D)
feedback=dict(status='USER_REPORTED_UI_INTERACTION_FAILURE',date='2026-10-26',checkpoint='../'+D.name,device_binary_sha_verified=False,new_game_dll_changes=0)
for name in ['Startup-R20-IPA-2026-10-26','Startup-R20-IPA-Build-2026-10-26','Startup-R20-Sites104-2026-10-26']:
 d=R/'Recovery'/name;j=json.loads((d/'PROGRESS.json').read_bytes());j.update(current_device_feedback=feedback,ipad_acceptance=False);js(d/'PROGRESS.json',j);manifest(d)
p=R/'README.md';v=p.read_text('utf-8');needle='Latest [R20 IPA]';at=v.index(needle);v=v[:at]+'Latest device feedback: menus and terrain render, but plant selection/confirmation, almanac details and Board interactions fail. [Unchanged-R20 interaction diagnosis](Recovery/'+D.name+'/README.md) is prepared; game DLL remains fixed and no gameplay acceptance is claimed.\n\n'+v[at:];p.write_bytes(v.encode())
p=R/'Recovery/STATUS.md';v=p.read_text('utf-8');anchor='## Latest checkpoint - 2026-10-26\n\n';v=v.replace(anchor,anchor+'[Device UI failure report and unchanged-R20 diagnostic]('+D.name+'/README.md): selection/confirm, almanac detail and Board/menu interactions reported broken; speed works; NaN visible. Added actual EventSystem/public-callback observation helper, exact API compilation and mode guards. No game DLL change or new IPA, real diagnostic not dispatched yet.\n\n',1);p.write_bytes(v.encode())
print(json.dumps(dict(checkpoint=D.name,source_methods=len(rows),game_changes=0,helper='PREPARED',candidate_sha256=s.sha(s.parent))))
