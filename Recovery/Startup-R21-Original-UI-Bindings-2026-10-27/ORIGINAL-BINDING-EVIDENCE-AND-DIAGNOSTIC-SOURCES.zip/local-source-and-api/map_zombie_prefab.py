"""Bind lost serialized references to original root-relative hierarchy identities."""
from pathlib import Path
import hashlib,json,sys,zipfile
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'python-deps'));import UnityPy
out=[]
for label,path,component_id in [('PC',ROOT/'GodsPVZ_1.0.2.zip',16473),('R20',next((W/'r20-full-build-run-40263428409/ipa').glob('*.ipa')),18650)]:
 with zipfile.ZipFile(path) as z:
  member=next(n for n in z.namelist() if n.endswith('/resources.assets'));env=UnityPy.load(z.read(member));objects={o.path_id:o for o in env.objects};root_component=objects[component_id];head=root_component.read_typetree(check_read=False);root=objects[head['m_GameObject']['m_PathID']];root_go=root.read_typetree();nodes=[]
  def walk(go_id,parent_path):
   go=objects[go_id].read_typetree();full=parent_path+'/'+go['m_Name'] if parent_path else go['m_Name'];components=[];transform=None
   for c in go['m_Component']:
    cid=c['component']['m_PathID'];obj=objects[cid];tree=obj.read_typetree(check_read=False)
    components.append(dict(path_id=cid,type=obj.type.name,script=tree.get('m_Script')))
    if obj.type.name in ['Transform','RectTransform']:transform=tree
   nodes.append(dict(path=full,game_object_id=go_id,components=components))
   assert transform is not None
   for c in transform['m_Children']:
    child=objects[c['m_PathID']].read_typetree();walk(child['m_GameObject']['m_PathID'],full)
  walk(root.path_id,'');out.append(dict(origin=label,root_component_path_id=component_id,root_name=root_go['m_Name'],resources_sha256=hashlib.sha256(z.read(member)).hexdigest(),hierarchy=nodes,externals=[dict(path=e.path,name=getattr(e,'name',None)) for e in root_component.assets_file.externals]))
(Q/'ZOMBIE-WINDOW-HIERARCHY.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps(out))
