from pathlib import Path
import hashlib,json,sys,zipfile
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'python-deps'));import UnityPy
rows=[]
for label,path in [('PC',ROOT/'GodsPVZ_1.0.2.zip'),('R20',next((W/'r20-full-build-run-40263428409/ipa').glob('*.ipa')))]:
 with zipfile.ZipFile(path) as z:
  name=next(n for n in z.namelist() if n.endswith('/globalgamemanagers.assets'));raw=z.read(name);env=UnityPy.load(raw);scripts={o.path_id:o.read_typetree() for o in env.objects if o.type.name=='MonoScript'}
  ids=[953,1840,601] if label=='PC' else [98,968,419]
  rows.append(dict(origin=label,file=name,sha256=hashlib.sha256(raw).hexdigest(),scripts=[dict(path_id=i,**scripts[i]) for i in ids]))
(Q/'ZOMBIE-WINDOW-SCRIPT-IDENTITIES.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print(json.dumps(rows))
