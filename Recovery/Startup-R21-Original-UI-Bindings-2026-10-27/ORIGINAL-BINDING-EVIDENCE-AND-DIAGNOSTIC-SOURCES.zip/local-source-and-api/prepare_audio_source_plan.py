"""Decode the original ordered audio registration, not a folder enumeration."""
from pathlib import Path
import collections,json,struct,sys
Q=Path(__file__).resolve().parent;sys.path.insert(0,str(Q));import source_common as s
from capstone.x86_const import X86_OP_REG,X86_OP_MEM,X86_OP_IMM,X86_REG_RIP
meta=(s.I/'original-pc/global-metadata.dat').read_bytes();assert s.sha(meta)=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9'
lo,ln,ld,ldn=struct.unpack_from('<4I',meta,8);strings=struct.unpack_from('<I',meta,24)[0];mo=struct.unpack_from('<I',meta,48)[0]
types=json.loads((s.I/'maps/native-types.json').read_bytes())
mv=struct.unpack('<16Q',s.pc.get_data(0x1818c6d00-s.base,128));cv=struct.unpack('<17Q',s.pc.get_data(0x1815e88c0-s.base,136))
assert mv[6]==27557 and mv[10]==mv[12]==len(types)==7696
read=lambda va,n:s.pc.get_data(va-s.base,n)
qword=lambda va:struct.unpack('<Q',read(va,8))[0]
def text(index):return meta[strings+index:meta.index(0,strings+index)].decode('utf-8')
def typename(ptr):
 data,bits=struct.unpack('<QI',read(ptr,12));kind=(bits>>16)&255
 if kind in [0x11,0x12]:
  t=types[data];return (t['namespace']+'.' if t['namespace'] else '')+t['name']
 return {1:'System.Void',0xe:'System.String',0x1c:'System.Object'}.get(kind,'kind:'+hex(kind))
def slot(i):
 va=i.address+i.size+i.operands[1].mem.disp;encoded=qword(va);kind=encoded>>29;index=(encoded&0x1fffffff)>>1
 if kind==5:
  assert index<ln//8;n,start=struct.unpack_from('<II',meta,lo+8*index);assert start+n<=ldn
  return ('string',meta[ld+start:ld+start+n].decode('utf-8'),dict(slot_va=hex(va),encoded=hex(encoded),literal_index=index,bytes=n,data_offset=start))
 if kind==1:
  assert index<mv[6];return ('class',typename(qword(mv[7]+8*index)),dict(slot_va=hex(va),type_index=index))
 if kind==6:return ('methodspec',index,dict(slot_va=hex(va),encoded=hex(encoded)))
 return ('unknown',hex(encoded),dict(slot_va=hex(va)))
modules={}
for k in range(cv[15]):
 p=qword(cv[16]+8*k);name=read(qword(p),150).split(b'\0')[0].decode();modules[name]=(qword(p+8),qword(p+16))
path=next(t for t in types if t['name']=='Path' and t['namespace']=='System.IO');matches=[]
for k in range(path['methodStart'],path['methodStart']+path['methods']):
 at=mo+36*k;name=text(struct.unpack_from('<I',meta,at)[0]);token=struct.unpack_from('<I',meta,at+24)[0];rid=token&0xffffff
 if name=='Combine' and rid<=modules['mscorlib.dll'][0] and qword(modules['mscorlib.dll'][1]+8*(rid-1))==0x180c84600:matches.append(dict(image='mscorlib.dll',owner='System.IO.Path',method=name,token=hex(token),parameters=struct.unpack_from('<H',meta,at+34)[0],va='0x180c84600'))
assert len(matches)==1 and matches[0]['parameters']==2
cfg=json.loads((Q/'native-source-complete/0x0600021B.json').read_bytes());assert not cfg['indirect_jumps']
registers={};entries=[];combines=[];loads=[];field_by_offset={r['offset']:r for r in s.field_rows if r['type']=='ResourceManager' and r['namespace']=='' and r['type_index']==7534}
current_folder=None;last_join=None
def regname(i,operand):return i.reg_name(operand.reg)
def getreg(i,operand):return registers.get(regname(i,operand))
def write(i,name,value):registers[name]=value
for row in cfg['instructions']:
 i=next(s.dis.disasm(bytes.fromhex(row['bytes']),int(row['va'],16)));ops=i.operands
 if i.mnemonic=='mov' and len(ops)==2 and ops[0].type==X86_OP_REG:
  dst=regname(i,ops[0]);v=None
  if ops[1].type==X86_OP_REG:v=getreg(i,ops[1])
  elif ops[1].type==X86_OP_MEM:
   if ops[1].mem.base==X86_REG_RIP:v=slot(i)
   else:
    base=registers.get(i.reg_name(ops[1].mem.base));off=ops[1].mem.disp
    if base and base[:2]==('class','ResourceManager') and off==0xb8:v=('staticfields','ResourceManager',base[2])
    elif base and base[:2]==('staticfields','ResourceManager') and off in field_by_offset:
     f=field_by_offset[off];v=('list',f['name'],dict(token=f['token'],static_offset=off,field_load_va=hex(i.address),static_type_proof=base[2]))
  write(i,dst,v)
 elif i.mnemonic=='call' and ops and ops[0].type==X86_OP_IMM:
  va=ops[0].imm
  if va==0x180c84600:
   left=registers.get('rcx');right=registers.get('rdx');assert left and right and left[0] in ['string','path'] and right[0]=='string',(row,left,right)
   parts=([left[1]] if left[0]=='string' else left[1])+[right[1]];proof=dict(call_va=hex(i.address),parts=parts,left=left,right=right);combines.append(proof);v=('path',parts,proof);last_join=proof
  elif va==0x18047ba00:
   path=registers.get('rcx');spec=registers.get('rdx');lst=registers.get('rdi');assert path and path[0]=='path' and spec and spec[0]=='methodspec' and lst and lst[0]=='list',(row,path,spec,lst)
   assert len(path[1])==3 and path[1][0]=='audioClips';entries.append(dict(field=lst[1],field_proof=lst[2],path_parts=path[1],path='/'.join(path[1]),path_combine=path[2],load_va=hex(i.address),methodspec=spec[1],method_info_slot=spec[2]));loads.append(spec[1]);v=('audio',len(entries)-1,{})
  else:v=None
  for name in ['rax','rcx','rdx','r8','r9','r10','r11']:registers[name]=None
  registers['rax']=v
 elif ops and ops[0].type==X86_OP_REG and i.mnemonic not in ['cmp','test','push']:
  registers[regname(i,ops[0])]=None
assert len(entries)==126 and len(combines)==136 and len(set(loads))==1
specindex=loads[0];assert specindex<mv[8];definition,ci,mi=struct.unpack('<3i',read(mv[9]+12*specindex,12));assert ci==-1 and mi>=0
at=mo+36*definition;name=text(struct.unpack_from('<I',meta,at)[0]);owner=types[struct.unpack_from('<I',meta,at+4)[0]];assert owner['name']=='InternalResourceLoader' and name=='Load'
inst=qword(mv[3]+8*mi);n,ptr=struct.unpack('<2Q',read(inst,16));assert n==1;argument=typename(qword(ptr));assert argument=='UnityEngine.AudioClip'
functions=[struct.unpack('<4i',read(mv[5]+16*k,16)) for k in range(mv[4])];canonical=[]
for f in functions:
 d,c,m=struct.unpack('<3i',read(mv[9]+12*f[0],12))
 if d!=definition or qword(cv[3]+8*f[1])!=0x18047ba00:continue
 assert c==-1 and m>=0;inst=qword(mv[3]+8*m);n,p=struct.unpack('<2Q',read(inst,16));assert n==1
 canonical.append(dict(method_spec_index=f[0],argument=typename(qword(p)),generic_pointer_index=f[1],registered_va='0x18047ba00'))
assert canonical and all(r['argument']=='System.Object' for r in canonical),canonical
current=s.methods['0x0600021B'];old=[];field=None;path=None
for i in current['instructions']:
 if i['opcode']=='ldsfld':field=i['operand']['identity'].rsplit('::',1)[-1]
 if i['opcode']=='ldstr':path=i['operand']
 if i['opcode']=='call' and i['operand']['owner']=='InternalResourceLoader' and i['operand']['name']=='Load':old.append((field,path))
assert len(old)==len(set(old))==11
keys={(r['field'],r['path']) for r in entries};assert set(old)<=keys
for r in entries:r['omitted_in_shipped_cil']=(r['field'],r['path']) not in set(old)
assert sum(r['omitted_in_shipped_cil'] for r in entries)==115
events=[dict(kind='FOLDER',native_va=r['call_va'],parts=r['parts']) for r in combines if len(r['parts'])==2]
events += [dict(kind='ENTRY',native_va=r['load_va'],entry=k) for k,r in enumerate(entries)]
events.sort(key=lambda r:int(r['native_va'],16));assert len(events)==136
result=dict(scope='ORIGINAL_PC_EXACT_LITERAL_METHODSPEC_STATIC_FIELD_AND_ORDER_PLAN_ONLY',token='0x0600021B',native_input_sha256=s.sha(s.raw),metadata_sha256=s.sha(meta),candidate_sha256=s.sha(s.parent),path_combine_binding=matches[0],load_binding=dict(method_spec_index=specindex,definition_index=definition,owner='InternalResourceLoader',method='Load',argument=argument,original_va='0x18047ba00',same_definition_canonical_reference_bindings=canonical,actual_requested_type_taken_from_each_callsite_methodinfo=True),native_entries=len(entries),current_entries=len(old),omitted_load_positions=115,group_counts=dict(collections.Counter(r['field'] for r in entries)),current_clear_calls_are_not_in_native=True,folder_events_including_unused_device_folder=10,events=events,rows=entries,new_tests_started=False)
(Q/'ORIGINAL-AUDIO-ORDERED-PLAN.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in result.items() if k!='rows'}))
