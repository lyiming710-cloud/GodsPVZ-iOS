"""Six bindings are supported by exact original raw slots and resolved script identities."""
from pathlib import Path
import hashlib,json,struct
Q=Path(__file__).resolve().parent;pc=(Q/'PC-ZombieWindow-component.bin').read_bytes();current=(Q/'R20-ZombieWindow-component.bin').read_bytes();hier=json.loads((Q/'ZOMBIE-WINDOW-HIERARCHY.json').read_bytes());scripts=json.loads((Q/'ZOMBIE-WINDOW-SCRIPT-IDENTITIES.json').read_bytes())
assert len(pc)==len(current)==208 and pc[32:136]==current[32:136]
assert hashlib.sha256(pc).hexdigest()=='ec7e63cbe4f1fdaa67afc4d35c4023b7e0fb35721092a999cc3c3f0eb9f4d3b6'
mapping=[('zombiePortrait','Portrait','UnityEngine.UI.Image',17069,17123),('questionMark','QMark','UnityEngine.UI.Image',16695,18317),('checkMark','CMark','UnityEngine.UI.Image',16028,18361),('eliteMark','EMark','UnityEngine.UI.Image',16416,19247),('bossMark','BMark','UnityEngine.UI.Image',17706,17509),('button','Portrait','UnityEngine.UI.Button',17988,16841)];rows=[]
for i,(field,child,kind,original_id,new_id) in enumerate(mapping):
 at=136+12*i;assert struct.unpack_from('<iq',pc,at)==(0,original_id) and current[at:at+12]==b'\0'*12
 for j,pid in [(0,original_id),(1,new_id)]:
  node=next(n for n in hier[j]['hierarchy'] if n['path']=='ZombieWindow/'+child);component=next(c for c in node['components'] if c['path_id']==pid);script=next(s for s in scripts[j]['scripts'] if s['path_id']==component['script']['m_PathID']);assert script['m_Namespace']+'.'+script['m_ClassName']==kind
 rows.append(dict(field=field,relative_gameobject_path=child,component_type=kind,original_byte_offset=at,original_file_id=0,original_component_path_id=original_id,r20_corresponding_component_path_id=new_id,r20_actual_field_is_null=True))
plan=dict(scope='SIX_ORIGINAL_ZOMBIE_WINDOW_SERIALIZED_COMPONENT_REFERENCE_BINDINGS_ONLY',owner_type='Almanac_ZombieWindow',root_name='ZombieWindow',resource_path='prefabs/ui/smallobjects/zombiewindow',original_component_sha256=hashlib.sha256(pc).hexdigest(),r20_component_sha256=hashlib.sha256(current).hexdigest(),entries=rows,not_a_method_repair_count=True,no_new_game_method_changes=True)
(Q/'ZOMBIE-WINDOW-BINDING-PLAN.json').write_bytes((json.dumps(plan,indent=2)+'\n').encode());print('original-bound missing reference sites',len(rows))
