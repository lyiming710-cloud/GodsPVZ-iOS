"""Read-only game FieldDef type survey against original IL2CPP field metadata."""
from pathlib import Path
import collections,hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;sys.path.insert(0,str(Q));import source_common as s
types=json.loads((s.I/'maps/native-types.json').read_bytes());mv=struct.unpack('<16Q',s.pc.get_data(0x1818c6d00-s.base,128));assert mv[6]==27557
meta=(s.I/'original-pc/global-metadata.dat').read_bytes();type_offset,type_bytes=struct.unpack_from('<II',meta,160);gp_offset,gp_bytes=struct.unpack_from('<II',meta,104);gc_offset,gc_bytes=struct.unpack_from('<II',meta,120);assert type_bytes==len(types)*88 and gp_bytes%16==gc_bytes%16==0
images_offset,images_bytes=struct.unpack_from('<II',meta,168);strings_offset=struct.unpack_from('<I',meta,24)[0];assert images_bytes%40==0;image_rows=[]
for at in range(images_offset,images_offset+images_bytes,40):
 row=struct.unpack_from('<10I',meta,at);label=meta[strings_offset+row[0]:meta.index(0,strings_offset+row[0])].decode('utf-8')
 if label=='Assembly-CSharp.dll':image_rows.append(dict(name=label,type_start=row[2],type_count=row[3]))
assert len(image_rows)==1;game_image=image_rows[0]
def read(va,n):return s.pc.get_data(va-s.base,n)
def u64(va):return struct.unpack('<Q',read(va,8))[0]
def name(index):
 t=types[index];parent=struct.unpack_from('<i',meta,type_offset+88*index+12)[0]
 if parent!=-1:
  assert 0<=parent<mv[6];return native_type(u64(mv[7]+8*parent))+'/'+t['name']
 return (t['namespace']+'.' if t['namespace'] else '')+t['name']
primitive={1:'System.Void',2:'System.Boolean',3:'System.Char',4:'System.SByte',5:'System.Byte',6:'System.Int16',7:'System.UInt16',8:'System.Int32',9:'System.UInt32',10:'System.Int64',11:'System.UInt64',12:'System.Single',13:'System.Double',14:'System.String',24:'System.IntPtr',25:'System.UIntPtr',28:'System.Object'}
def native_type(ptr,depth=0):
 assert depth<20;data,bits=struct.unpack('<QI',read(ptr,12));kind=(bits>>16)&255
 if kind in primitive:return primitive[kind]
 if kind in [0x11,0x12]:assert data<len(types);return name(data)
 if kind==0x1d:return native_type(data,depth+1)+'[]'
 if kind==0x15:
  inner=u64(data);inst=u64(data+8);n,argv=struct.unpack('<2Q',read(inst,16));assert n<30;return native_type(inner,depth+1)+'<'+','.join(native_type(u64(argv+8*i),depth+1) for i in range(n))+'>'
 if kind==0x14:
  elem=u64(data);rank=read(data+8,1)[0];return native_type(elem,depth+1)+'['+','*(rank-1)+']'
 if kind==0xf:return native_type(data,depth+1)+'*'
 if kind==0x10:return native_type(data,depth+1)+'&'
 if kind in [0x13,0x1e]:
  assert 0<=data<gp_bytes//16;owner,_,_,_,num,_=struct.unpack_from('<iiHHHH',meta,gp_offset+16*data);assert 0<=owner<gc_bytes//16;container=struct.unpack_from('<4i',meta,gc_offset+16*owner);assert container[2]==int(kind==0x1e) and container[3]+num==data and num<container[1]
  return ('!' if kind==0x13 else '!!')+str(num)
 raise ValueError('Unsupported native type kind '+hex(kind))
pe=s.pe;nested={r.NestedClass.row_index:r.EnclosingClass.row_index for r in pe.net.mdtables.NestedClass.rows}
def td(rid):
 row=pe.net.mdtables.TypeDef.rows[rid-1];return td(nested[rid])+'/'+str(row.TypeName) if rid in nested else ((str(row.TypeNamespace)+'.') if str(row.TypeNamespace) else '')+str(row.TypeName)
def tr(rid):
 row=pe.net.mdtables.TypeRef.rows[rid-1];return tr(row.ResolutionScope.row_index)+'/'+str(row.TypeName) if row.ResolutionScope.table and row.ResolutionScope.table.name=='TypeRef' else ((str(row.TypeNamespace)+'.') if str(row.TypeNamespace) else '')+str(row.TypeName)
def compressed(data,at):
 a=data[at]
 if a<128:return a,at+1
 if a<192:return ((a&63)<<8)|data[at+1],at+2
 return ((a&31)<<24)|(data[at+1]<<16)|(data[at+2]<<8)|data[at+3],at+4
def current_type(data,at):
 kind=data[at];at+=1
 if kind in primitive:return primitive[kind],at
 if kind in [0x11,0x12]:
  val,at=compressed(data,at);rid=val>>2;tag=val&3;return td(rid) if tag==0 else tr(rid) if tag==1 else 'TYPESPEC:'+str(rid),at
 if kind in [0x1d,0xf,0x10]:v,at=current_type(data,at);return v+{0x1d:'[]',0xf:'*',0x10:'&'}[kind],at
 if kind==0x15:
  inner,at=current_type(data,at);n,at=compressed(data,at);args=[]
  for i in range(n):v,at=current_type(data,at);args.append(v)
  return inner+'<'+','.join(args)+'>',at
 if kind in [0x13,0x1e]:n,at=compressed(data,at);return ('!' if kind==0x13 else '!!')+str(n),at
 raise ValueError('Unsupported managed type '+hex(kind))
byowner=collections.defaultdict(dict)
for f in s.field_rows:
 if not game_image['type_start']<=f['typeIndex']<game_image['type_start']+game_image['type_count']:continue
 owner=name(f['typeIndex']);assert f['name'] not in byowner[owner];byowner[owner][f['name']]=f
rows=[];gaps=[]
for rid,t in enumerate(pe.net.mdtables.TypeDef.rows,1):
 owner=td(rid)
 if owner not in byowner:continue
 for index in t.FieldList:
  field=index.row;fieldname=str(field.Name);original=byowner[owner].get(fieldname)
  if not original:gaps.append(dict(owner=owner,field=fieldname,status='NO_ORIGINAL_OWNER_QUALIFIED_FIELD'));continue
  try:
   sig=field.Signature.value;assert sig[0]==6;current,end=current_type(sig,1);assert end==len(sig);original_type=native_type(u64(mv[7]+8*original['type_index']))
  except Exception as e:gaps.append(dict(owner=owner,field=fieldname,status='UNMODELED_SIGNATURE',error=repr(e)));continue
  rows.append(dict(owner=owner,field=fieldname,token=f'0x{0x4000000|index.row_index:08X}',signature=sig.hex(),current=current,original=original_type,match=current==original_type,native_type_index=original['type_index'],public=field.Flags.fdPublic,static=field.Flags.fdStatic,not_serialized=field.Flags.fdNotSerialized))
different=[r for r in rows if not r['match']];report=dict(scope='READ_ONLY_OWNER_QUALIFIED_DECLARED_FIELD_TYPE_SURVEY_NOT_AUTOMATIC_REPAIR',candidate_sha256=s.sha(s.parent),original_pc_sha256=s.sha(s.raw),original_game_image=game_image,matched_fields=len(rows),equal=sum(r['match'] for r in rows),differences=different,unmodeled=gaps,all_rows=rows,no_metadata_changed=True,limitations=['Runtime handle/intptr and Unity serializer semantics need more than a display-name comparison.','Differences are source leads until native generic encoding and candidate signatures are independently validated.','This does not check serialized field values, method behavior, runtime engine loading or actual device input.'])
(Q/'NATIVE-FIELD-TYPE-SURVEY.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(dict(matched_fields=len(rows),equal=report['equal'],different=len(different),unmodeled=len(gaps),differences=different),ensure_ascii=True))
