"""Read-only cross-build discovery. Raw-slot candidates are NOT typed field proof.

Match exact resource path, root-relative GameObject path, resolved owner script
and component ordinal. Require equal byte length and the expected target
component still existing. Never patch or count these as confirmed game bugs.
"""
from pathlib import Path
import collections,hashlib,json,struct,sys,zipfile
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'python-deps'));import UnityPy
wanted={'UnityEngine.UI.Image','UnityEngine.UI.Button','UnityEngine.UI.Toggle','UnityEngine.UI.Slider','UnityEngine.UI.ScrollRect','UnityEngine.UI.RawImage','TMPro.TextMeshProUGUI','TMPro.TMP_Dropdown'}
def load(label,path):
 z=zipfile.ZipFile(path);raw=z.read(next(n for n in z.namelist() if n.endswith('/resources.assets')));env=UnityPy.load(raw);objects={o.path_id:o for o in env.objects};g=z.read(next(n for n in z.namelist() if n.endswith('/globalgamemanagers.assets')));genv=UnityPy.load(g);scripts={o.path_id:o.read_typetree() for o in genv.objects if o.type.name=='MonoScript'};catalog=json.loads((Q/(label+'-RESOURCE-CONTAINER.json')).read_bytes());cache={};headers={}
 def header(pid):
  if pid not in headers:headers[pid]=objects[pid].read_typetree(check_read=False)
  return headers[pid]
 def cls(pid):
  obj=objects[pid]
  if obj.type.name!='MonoBehaviour':return obj.type.name
  s=header(pid).get('m_Script');assert s and s['m_FileID']==1 and s['m_PathID'] in scripts,(label,pid,s);t=scripts[s['m_PathID']];return (t['m_Namespace']+'.' if t['m_Namespace'] else '')+t['m_ClassName']
 def hierarchy(root_id):
  if root_id in cache:return cache[root_id]
  components={};reverse={};seen=set()
  def walk(go_id,path):
   assert go_id not in seen;seen.add(go_id);go=header(go_id);transform=None;counts=collections.Counter()
   for c in go['m_Component']:
    pid=c['component']['m_PathID'];kind=cls(pid);key=(path,kind,counts[kind]);counts[kind]+=1;components[key]=pid;reverse[pid]=key
    if kind in ['Transform','RectTransform']:transform=header(pid)
   assert transform is not None
   names=collections.Counter(header(header(c['m_PathID'])['m_GameObject']['m_PathID'])['m_Name'] for c in transform['m_Children'])
   for c in transform['m_Children']:
    child=header(c['m_PathID'])['m_GameObject']['m_PathID'];name=header(child)['m_Name']
    # Duplicate sibling names need a separate identity model; retain a gap.
    if names[name]>1:continue
    walk(child,(path+'/' if path else '')+name)
  walk(root_id,'');cache[root_id]=(components,reverse);return cache[root_id]
 roots={}
 for name,ptr in catalog['m_Container']:
  pid=ptr['m_PathID']
  if pid in objects and objects[pid].type.name=='GameObject':roots[name]=pid
 z.close();return dict(objects=objects,cls=cls,hierarchy=hierarchy,roots=roots,resources_sha256=hashlib.sha256(raw).hexdigest())
pc=load('PC',ROOT/'GodsPVZ_1.0.2.zip');current=load('R20',next((W/'r20-full-build-run-40263428409/ipa').glob('*.ipa')));results=[];gaps=[];scanned=0;seen=set()
for resource in sorted(set(pc['roots'])&set(current['roots'])):
 try:old,reverse=pc['hierarchy'](pc['roots'][resource]);new,nreverse=current['hierarchy'](current['roots'][resource])
 except Exception as e:gaps.append(dict(resource=resource,error=repr(e)));continue
 for key,pid in old.items():
  if key not in new or key[1] in wanted or pc['objects'][pid].type.name!='MonoBehaviour':continue
  # Engine/UI scripts are not reconstructed game-owner fields for this survey.
  if key[1].startswith(('UnityEngine.','TMPro.')):continue
  new_pid=new[key];a=pc['objects'][pid].get_raw_data();b=current['objects'][new_pid].get_raw_data()
  if len(a)!=len(b):gaps.append(dict(resource=resource,owner=list(key),old_bytes=len(a),current_bytes=len(b),status='UNMODELED_LAYOUT_LENGTH_CHANGE'));continue
  scanned+=1
  for at in range(32,len(a)-11,4):
   f,target=struct.unpack_from('<iq',a,at)
   if f!=0 or target not in reverse:continue
   target_key=reverse[target]
   if target_key[1] not in wanted or target_key not in new:continue
   actual_file,actual_id=struct.unpack_from('<iq',b,at)
   if actual_file==0 and actual_id==new[target_key]:continue
   identity=(pid,at)
   if identity in seen:continue
   seen.add(identity);results.append(dict(resource=resource,owner_gameobject_path=key[0],owner_class=key[1],owner_component_ordinal=key[2],original_owner_path_id=pid,current_owner_path_id=new_pid,owner_bytes=len(a),raw_byte_offset=at,original_target_component_path_id=target,target_gameobject_path=target_key[0],target_class=target_key[1],expected_current_component_path_id=new[target_key],actual_current_file_id=actual_file,actual_current_component_path_id=actual_id,classification='RAW_ALIGNED_SLOT_ZERO_CANDIDATE_NEEDS_TYPED_FIELD_PROOF' if actual_file==actual_id==0 else 'RAW_SLOT_DIFFERENCE_NEEDS_TYPED_FIELD_PROOF'))
report=dict(scope='READ_ONLY_RAW_SLOT_DISCOVERY_NOT_TYPED_SERIALIZATION_OR_REPAIR_PROOF',original_resources_sha256=pc['resources_sha256'],r20_resources_sha256=current['resources_sha256'],shared_resource_roots=len(set(pc['roots'])&set(current['roots'])),matched_equal_size_owner_components=scanned,candidate_slots=len(results),counts_by_class=dict(collections.Counter(r['owner_class'] for r in results)),results=results,unmodeled=gaps,candidate_is_unchanged=True,no_auto_repair=True,qualified_methods=0,limitations=['Four-byte-aligned patterns can accidentally equal object IDs; each site needs typed field layout proof.','Duplicate sibling-name subtrees are skipped; length changes retained as gaps.','Field name, intended runtime use and current importer source are not proved by a raw match.','This is not a whole-game bug count or an actual R21 runtime test.'])
(Q/'UI-RAW-REFERENCE-DISCOVERY.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in report.items() if k not in ['results','unmodeled','limitations']},ensure_ascii=True));print('unmodeled',len(gaps))
