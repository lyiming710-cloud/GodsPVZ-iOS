"""Decode only four independently typed prefix fields; no layout guessing beyond them."""
from pathlib import Path
import hashlib,json,struct,sys,zipfile
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'python-deps'));import UnityPy
survey=json.loads((Q/'NATIVE-FIELD-TYPE-SURVEY.json').read_bytes());fields=[r for r in survey['all_rows'] if r['owner']=='ZombieManager'];assert [f['field'] for f in fields[:4]]==['board','audioClip_zombie','zombiePrefabList','zombieList'] and all(f['match'] and f['public'] and not f['static'] for f in fields[:4]);rows=[]
for label,path in [('PC',ROOT/'GodsPVZ_1.0.2.zip'),('R20',next((W/'r20-full-build-run-40263428409/ipa').glob('*.ipa')))]:
 catalog=json.loads((Q/(label+'-RESOURCE-CONTAINER.json')).read_bytes());ptr=next(p for name,p in catalog['m_Container'] if name=='prefabs/managers/zombiemanager')
 with zipfile.ZipFile(path) as z:
  env=UnityPy.load(z.read(next(n for n in z.namelist() if n.endswith('/resources.assets'))));objects={o.path_id:o for o in env.objects};go=objects[ptr['m_PathID']].read_typetree();components=[objects[c['component']['m_PathID']] for c in go['m_Component']];owner=next(o for o in components if o.type.name=='MonoBehaviour');data=owner.get_raw_data();header=owner.read_typetree(check_read=False);assert header['m_Name']=='';at=32;values={};values['board']=dict(zip(['file_id','path_id'],struct.unpack_from('<iq',data,at)));at+=12
  for field in ['audioClip_zombie','zombiePrefabList','zombieList']:
   count=struct.unpack_from('<i',data,at)[0];at+=4;assert 0<=count<=1000 and at+12*count<=len(data);items=[dict(zip(['file_id','path_id'],struct.unpack_from('<iq',data,at+12*k))) for k in range(count)];at+=12*count;values[field]=dict(count=count,items=items)
  rows.append(dict(origin=label,component_path_id=owner.path_id,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),typed_prefix_end=at,remaining_bytes_not_decoded=len(data)-at,values=values))
cil=json.loads((W/'startup-r21-ui-batch100/shared-authored1/ALL-CIL.json').read_bytes());refs={}
for name in ['audioClip_zombie','zombiePrefabList','zombieList']:
 refs[name]=[dict(token=m['token'],method=m['name'],accesses=[i['opcode'] for i in m['instructions'] if isinstance(i.get('operand'),dict) and i['operand'].get('identity','').endswith('ZombieManager::'+name)]) for m in cil['methods'] if any(isinstance(i.get('operand'),dict) and i['operand'].get('identity','').endswith('ZombieManager::'+name) for i in m['instructions'])]
report=dict(scope='FOUR_TYPED_ZOMBIE_MANAGER_PREFIX_FIELDS_ONLY',candidate_for_declared_field_schema=survey['candidate_sha256'],rows=rows,current_direct_cil_accesses=refs,not_a_runtime_failure_claim=True,limitations=['Other fields and serialized layout after the prefix are not decoded.','Prefab values can be overwritten by Awake; source differences require lifecycle/use-def analysis.','No asset, DLL or workflow changed by this script.'])
(Q/'ZOMBIE-MANAGER-SERIALIZED-PREFIX.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(dict(counts=[dict(origin=r['origin'],counts={k:v['count'] for k,v in r['values'].items() if 'count' in v},remaining=r['remaining_bytes_not_decoded']) for r in rows],direct_cil_use_counts={k:len(v) for k,v in refs.items()})))
