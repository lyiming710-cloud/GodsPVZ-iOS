"""Input-only derivative of R18 census; no compiler controls or flags removed."""
from pathlib import Path
import ast,json
from archive_support import sha,js,pack,manifest
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';D=R/'Recovery/Startup-R19-Batch100-2026-10-25'
progress=json.loads((D/'PROGRESS.json').read_bytes());assert progress['new_unique_methods']==100 and progress['first_test_after_hundred'] and not progress['full_batch_semantic_acceptance']
old='a6aa9f91087db194251c4c989fd80ffd982b3b7a59413b0745592bc43b548abb';new=progress['candidate_sha256']
src=R/'scripts/actions/check_startup_r18_compiler.py';raw=src.read_bytes();text=raw.decode().replace(old,new).replace('STARTUP_R18','STARTUP_R19').replace('STARTUP-R18-BATCH50','STARTUP-R19-BATCH100').replace('Startup R18 Batch50','Startup R19 Batch100').replace('Fixed Startup R18 Batch50','Fixed Startup R19 Batch100')
ast.parse(text);dest=R/'scripts/actions/check_startup_r19_compiler.py';assert not dest.exists();dest.write_bytes(text.encode())
src_workflow=R/'.github/workflows/bulk401-generic-compiler-check.yml';before=src_workflow.read_bytes();text=before.decode().replace(old,new).replace('startup-r18','startup-r19').replace('Startup R18 Batch50','Startup R19 Batch100').replace('STARTUP-R18-BATCH50','STARTUP-R19-BATCH100').replace('Startup-R18-Batch50','Startup-R19-Batch100').replace('exact R18 Batch50','exact R19 Batch100').replace('check_startup_r18_compiler.py','check_startup_r19_compiler.py')
assert old not in text and new in text and 'secrets.' not in text
workflow=R/'.github/workflows/startup-r19-compiler-check.yml';assert not workflow.exists();workflow.write_bytes(text.encode())
js(D/'COMPILER-DRIVER-DERIVATION.json',dict(scope='HUNDRED_INPUT_ONLY_COMPILER_DIAGNOSTIC_NOT_SEMANTIC_PROMOTION',candidate_sha256=new,parent_driver_sha256=sha(raw),driver_sha256=sha(dest.read_bytes()),parent_workflow_sha256=sha(before),workflow_sha256=sha(workflow.read_bytes()),controls_and_flags_unchanged=True,hundred_before_shared_tests=True,remaining_runtime_profiles=65,unity_export_or_ipa=False))
pack(D/'COMPILER-BINDING-SOURCES.zip',[(f.relative_to(R).as_posix(),f.read_bytes()) for f in [src,dest,src_workflow,workflow,R/'scripts/actions/restore_bulk152_checkpoint.py',R/'scripts/actions/verify_bulk152_portable.py']]+[(Path(__file__).name,Path(__file__).read_bytes())]);manifest(D)
print('R19 compiler-only binding ready; old R18 workflow and driver preserved')
