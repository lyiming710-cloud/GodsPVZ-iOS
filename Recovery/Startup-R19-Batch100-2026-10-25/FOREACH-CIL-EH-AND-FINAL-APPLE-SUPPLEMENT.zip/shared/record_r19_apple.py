"""Check the returned Apple records, raw logs, source identities and controls."""
from pathlib import Path, PurePosixPath
import json, re
from archive_support import sha, js, pack, manifest

W = Path(__file__).resolve().parent
R = W.parents[1]/'audit/repo-native113'
D = R/'Recovery/Startup-R19-Batch100-2026-10-25'
A = W/'r19-apple-run-40197688048'
run = 40197688048
head = '08927452ca614e7f432b16b1431842850bcf3d1a'
expected = '0ba5bc7ec9603d14a1c0bde6d784d232aa78efaa1700304e75e4f2b56ef7dec2'
meta = json.loads((A/'RUN.json').read_bytes())
assert meta['headSha'] == head and meta['status'] == 'completed' and meta['conclusion'] == 'success'
actual = json.loads((A/'APPLE-REPORT.json').read_bytes())
rows = json.loads((A/'ALL-APPLE-RESULTS.json').read_bytes())
base = json.loads((D/'ACTUAL-COMPILER-40195582520.json').read_bytes())
assert actual['candidate_sha256'] == expected == base['candidate_sha256']
assert actual['source_conversion_run'] == base['run_id'] == 40195582520
assert actual['apple_audit_source_commit'] == head and actual['header_export_run'] == 39988665189
assert actual['attempted'] == len(rows) == 1029 and actual['cpp'] == 755 and actual['c'] == 274
assert actual['failed'] == actual['diagnostics'] == actual['unparsed_error_lines'] == 0
assert not actual['actual_unity_export_for_new_candidate'] and not actual['linked'] and actual['ipa'] is None
files = {PurePosixPath(x['file']).name: x for x in base['source_rows']}
assert len(files) == len(rows) == len({x['file'] for x in rows})
assert set(files) == {x['file'] for x in rows}
log_identities = []
for row in rows:
    prior = files[row['file']]
    assert row['bytes'] == prior['bytes'] and row['sha256'] == prior['sha256']
    assert row['exit_code'] == row['error_count'] == 0 and not row['unparsed_errors']
    log = A/'logs'/(row['file']+'.log')
    data = log.read_bytes()
    text = data.decode('utf-8', errors='replace')
    assert not re.search(r': (?:fatal )?error:', text)
    assert sum(': warning:' in x for x in text.splitlines()) == row['warning_count']
    log_identities.append(dict(file=log.relative_to(A).as_posix(), bytes=len(data), sha256=sha(data)))
flags = json.loads((A/'APPLE-CPP-FLAGS.json').read_bytes())
cflags = json.loads((A/'APPLE-C-FLAGS.json').read_bytes())
for f in [flags, cflags]:
    assert '/Xcode_16.4.app/' in f[0]
    assert f[f.index('-arch')+1] == 'arm64'
    assert f[f.index('-isysroot')+1].endswith('/iPhoneOS18.5.sdk')
    assert '-fsyntax-only' in f and '-ferror-limit=0' in f
assert '-std=c++11' in flags and '-std=c11' in cflags and cflags[cflags.index('-x')+1] == 'c'
cpp_controls = json.loads((A/'COMPILER-CONTROLS.json').read_bytes())
c_controls = json.loads((A/'C-COMPILER-CONTROLS.json').read_bytes())
assert len(cpp_controls) == 4 and len(c_controls) == 2
assert all(x['expectation_met'] and ((x['exit_code'] == 0) == x['expected_success']) for x in cpp_controls)
cc = {x['file']: x for x in c_controls}
assert cc['valid_c_mode.c']['exit_code'] == 0 and cc['bad_c_identifier.c']['exit_code'] != 0
assert all(x['expectation_met'] for x in c_controls)
damaged = json.loads((A/'DAMAGED-R4-CONTROL.json').read_bytes())
assert damaged['exit_code'] != 0 and damaged['error_count'] == 34
result = dict(scope='ACTUAL_R19_HUNDRED_BATCH_ALL_FRESH_PORTABLE_SOURCES_APPLE_ARM64_SYNTAX_ONLY',
    run_id=run, url=f'https://github.com/lyiming710-cloud/GodsPVZ-iOS/actions/runs/{run}', pass_=True,
    actual=actual, source_records_rechecked=len(rows), raw_source_logs_rechecked=len(log_identities),
    log_identities=log_identities, compiler='Xcode 16.4 Apple Clang', sdk='iPhoneOS18.5', architecture='arm64',
    compiler_controls=cpp_controls+c_controls, damaged_control_errors=34,
    warning_count=sum(x['warning_count'] for x in rows), new_unity_export=False, linked=False, ipa=None, ipad_acceptance=False)
items = [(p.relative_to(A).as_posix(), p.read_bytes()) for p in sorted(A.rglob('*')) if p.is_file()]
pack(D/f'ACTUAL-APPLE-EVIDENCE-{run}.zip', items+[(Path(__file__).name, Path(__file__).read_bytes())])
js(D/f'ACTUAL-APPLE-{run}.json', result)
status = json.loads((D/'PROGRESS.json').read_bytes())
assert status['current_candidate_apple'] == 'PREPARED_NOT_RUN'
status['current_candidate_apple'] = f'PASS_ALL_1029_ARM64_SYNTAX_ONLY_RUN_{run}'
status['current_candidate_apple_linked'] = False
js(D/'PROGRESS.json', status)
p = D/'README.md'
text = p.read_text('utf-8')
marker = f'## Actual R19 Apple readback: run {run}'
assert marker not in text
text += f'\n{marker}\n\nAll 755 C++/274 C sources from exact R19 conversion run 40195582520 passed physical iOS arm64 Apple syntax checks under Xcode 16.4/iPhoneOS18.5. All 1,029 source records match independently rehashed Linux input; every returned source log was independently checked for errors and warning totals. Six compiler controls meet expectations and the damaged Apple R4 unit still has 34 errors. The raw reports retain {result["warning_count"]:,} warnings. Flags and runtime-header validation are unchanged from the prior Apple driver; historical headers are reused with newly generated R19 code. This is a fresh R19 Apple syntax precheck, without a new Unity Editor export, runtime/Objective-C compilation, player linking, IPA or iPad acceptance. Broader semantic, type and member-access queues remain open.\n'
p.write_bytes(text.encode())
manifest(D)
print(json.dumps(dict(run_id=run, pass_=True, cpp=755, c=274, source_records_rechecked=len(rows), raw_logs_rechecked=len(log_identities), warnings=result['warning_count'], ipa=None)))
