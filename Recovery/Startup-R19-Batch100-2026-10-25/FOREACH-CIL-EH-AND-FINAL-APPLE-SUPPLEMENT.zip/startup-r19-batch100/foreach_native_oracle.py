"""Original ReloadPlantData normal caller; native unwind remains unsupported.

Enumerator construction/MoveNext and ReloadPlantSaveData are explicit controlled
contracts. Native normal Dispose alias is the original 302170 empty body.
"""
from pathlib import Path
import ctypes as C,functools,hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
im=NativeImage();state={};cfg=json.loads((Q/'native-source-complete/0x0600006D.json').read_bytes());fields=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_bytes())
@functools.lru_cache(None)
def off(owner,name):
 rs=[r for r in fields if r['type']==owner and r['namespace']=='' and r['name']==name];assert len(rs)==1,(owner,name,rs);return rs[0]['offset']
def string(s):
 if s is None:return 0
 b=s.encode('utf-16-le');p=im.alloc(24+len(b));put32(p+0x10,len(b)//2);C.memmove(p+0x14,b,len(b));return p
def text(p):return None if not p else C.string_at(p+0x14,get32(p+0x10)*2).decode('utf-16-le')
def listing(items):
 a=im.alloc(32+8*len(items));put32(a+0x18,len(items));p=im.alloc(64);put64(p+0x10,a);put32(p+0x18,len(items));put32(p+0x1c,7)
 for k,value in enumerate(items):
  obj=0 if value is None else im.alloc(64)
  if obj:state['ids'][obj]=value
  put64(a+0x20+8*k,obj)
 return p
def enumerator(ret,list_,method):
 assert list_;put64(ret,list_);put32(ret+8,0);put32(ret+12,get32(list_+0x1c));put64(ret+16,0);return ret
def move_next(p,method):
 ls=get64(p);assert ls and get32(p+12)==get32(ls+0x1c),'Native exceptional MoveNext outside this profile'
 index=get32(p+8);count=get32(ls+0x18)
 if index<count:put64(p+16,get64(get64(ls+0x10)+0x20+index*8));put32(p+8,index+1);return True
 put32(p+8,count+1);put64(p+16,0);return False
def reload(manager,p,method):
 assert not method;state['trace'].append('Reload:'+state['ids'][manager]+':'+state['ids'].get(p or 0,'null'));mode=state['q']['mode']
 if mode=='swap-manager':put64(state['lawn']+off('LawnApp','savesManager'),state['m1'])
 if mode=='replace-list':put64(state['save']+off('Save','plantSaves'),listing(['new']))
def log(p,method):assert not method;state['trace'].append('Log:'+str(text(p)))
try:
 meta=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/global-metadata.dat').read_bytes();assert hashlib.sha256(meta).hexdigest()=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9'
 so,sn,do,dn=struct.unpack_from('<4I',meta,8);dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True;slots=set();global_at=None
 for row in cfg['instructions']:
  i=next(dis.disasm(bytes.fromhex(row['bytes']),int(row['va'],16)))
  if i.mnemonic not in ['mov','lea']:continue
  for op in i.operands:
   if op.type!=X86_OP_MEM or op.mem.base!=X86_REG_RIP:continue
   at=i.address+i.size+op.mem.disp;raw=im.pe.get_data(at-im.base,8)
   if len(raw)!=8:continue
   code=int.from_bytes(raw,'little')
   if code>0xffffffff or code>>29 not in range(1,8):continue
   slots.add(at);kind,index=code>>29,(code&0x1fffffff)>>1
   if kind==5:n,pos=struct.unpack_from('<II',meta,so+8*index);put64(at,string(meta[do+pos:do+pos+n].decode('utf-8')))
   else:cls=im.class_slot(at);put64(get64(cls+0xb8),string(''))
   if i.address==0x180309b3e:global_at=at
 assert global_at in im.classes;static=get64(im.classes[global_at]+0xb8)
 def init(at):assert at in slots,hex(at)
 im.hook(0x18024fef0,None,[P],init);im.hook(0x1802501e0,None,[P],lambda p:None)
 im.hook(0x1808197f0,P,[P,P,P],enumerator);im.hook(0x180669280,C.c_bool,[P,P],move_next);im.hook(0x180340020,None,[P,P,P],reload);im.hook(0x1812e68f0,None,[P,P],log)
 im.verify_caller(0x6d,int(cfg['entry'],16),cfg);assert C.string_at(0x180302170,3)==bytes.fromhex('c20000')
 rows=[]
 for q in json.loads((Q/'FOREACH-CASES.json').read_bytes()):
  if not q['native_supported']:continue
  state.clear();state.update(q=q,trace=[],ids={0:'null'})
  lawn,save,m0,m1=[im.alloc(512) for _ in range(4)];state.update(lawn=lawn,save=save,m0=m0,m1=m1);state['ids'].update({m0:'m0',m1:'m1'})
  put64(static,lawn);put64(lawn+off('LawnApp','savesManager'),m0);put64(m0+off('SavesManager','playerSave'),save);put64(save+off('Save','plantSaves'),listing(q['items']))
  C.CFUNCTYPE(None,P,P)(int(cfg['entry'],16))(im.alloc(32),None);assert not im.errors,im.errors
  rows.append(dict(name=q['name'],error=None,trace=list(state['trace']),global_manager=state['ids'][get64(lawn+off('LawnApp','savesManager'))],original_manager_list_count=get32(get64(save+off('Save','plantSaves'))+0x18)))
 actual=json.loads(Path(sys.argv[1]).read_bytes());byname={r['name']:r for r in actual['results']};diff=[dict(original=r,actual=byname[r['name']]) for r in rows if r!=byname[r['name']]]
 managed=[r for r in actual['results'] if r['name'] not in {r['name'] for r in rows}];assert len(managed)==6 and all(r['error']=='System.InvalidOperationException' and not any(s.startswith('Log:') for s in r['trace']) for r in managed)
 assert actual['binding']['identical_eh_graph'] and len(actual['binding']['source_eh'])==1 and actual['binding']['source_eh'][0]['kind']=='Finally'
 report=dict(scope='ORIGINAL_RELOADPLANTDATA_NORMAL_CALLER_VS_COMPLETE_CANDIDATE_CIL_WITH_REAL_FINALLY_CLAUSE',candidate_sha256=actual['candidate_sha256'],original_pc_sha256=hashlib.sha256(im.raw).hexdigest(),token='0x0600006D',original_caller_bytes_checked=True,normal_comparison_records=len(rows),differences=diff,results=rows,managed_exception_cases_not_native_unwind_proof=managed,real_finally_graph_preserved=True,controlled_leaves=['Enumerator construction/MoveNext','Manager.ReloadPlantSaveData','Debug.Log','metadata'],native_normal_dispose_alias_original_empty_body=True,native_exception_unwind='UNSUPPORTED',dispose_side_effect_observability='NONE_FOR_EMPTY_DISPOSE; EH preservation checked independently',unity_or_product_acceptance=False)
 Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k not in ['results','differences','managed_exception_cases_not_native_unwind_proof']},indent=2));assert not diff
finally:im.close()
