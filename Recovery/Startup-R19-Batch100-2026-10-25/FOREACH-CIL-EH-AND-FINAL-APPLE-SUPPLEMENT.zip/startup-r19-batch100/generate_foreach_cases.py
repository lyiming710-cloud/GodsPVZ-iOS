from pathlib import Path
import json,itertools
Q=Path(__file__).resolve().parent;rows=[]
for items,mode in itertools.product([[],['a'],['a','b'],['a',None,'c']],['none','swap-manager','replace-list']):rows.append(dict(name='e'+str(len(rows)).zfill(3),items=items,mode=mode,native_supported=True))
for items,mode in itertools.product([['a'],['a','b'],['a',None,'c']],['throw-first','mutate-list']):rows.append(dict(name='e'+str(len(rows)).zfill(3),items=items,mode=mode,native_supported=False))
(Q/'FOREACH-CASES.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print('foreach cases',len(rows))
