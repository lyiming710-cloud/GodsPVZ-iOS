using System.Reflection;using System.Runtime.Loader;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;using CIL=Mono.Cecil.Cil;
public class System0{}
public class PlantSave{public string? Id;}
public class Save{public List<PlantSave?> plantSaves=[];}
public class Lawn{public Manager? savesManager;}
public static class Global{public static Lawn? gLawnApp;}
public class Manager
{
    public string Id="";public Save playerSave=new();
    public void ReloadPlantSaveData(PlantSave? p)
    {
        Program.Trace.Add("Reload:"+Id+":"+(p?.Id??"null"));Program.Calls++;
        if(Program.Mode=="swap-manager")Global.gLawnApp!.savesManager=Program.Other;
        if(Program.Mode=="replace-list")playerSave.plantSaves=[new(){Id="new"}];
        if(Program.Mode=="throw-first")throw new InvalidOperationException("controlled leaf failure");
        if(Program.Mode=="mutate-list")playerSave.plantSaves.Add(new(){Id="added"});
    }
}
public static class Program
{
    public static List<string> Trace=[];public static string Mode="";public static Manager Other=null!;public static int Calls;
    public static void Log(object? s)=>Trace.Add("Log:"+s);
    static Type Map(MC.TypeReference t)
    {
        if(t is MC.ByReferenceType b)return Map(b.ElementType).MakeByRefType();
        if(t is MC.GenericInstanceType g)
        {
            Type generic=g.ElementType.FullName switch{"System.Collections.Generic.List`1"=>typeof(List<>),"System.Collections.Generic.List`1/Enumerator"=>typeof(List<>.Enumerator),_=>throw new NotSupportedException(t.FullName)};return generic.MakeGenericType(g.GenericArguments.Select(Map).ToArray());
        }
        return t.FullName switch{"System.Void"=>typeof(void),"System.Boolean"=>typeof(bool),"System.Int32"=>typeof(int),"System.String"=>typeof(string),"System.Object"=>typeof(object),"System.IntPtr"=>typeof(IntPtr),"System0"=>typeof(System0),"PlantSave"=>typeof(PlantSave),"Save"=>typeof(Save),"SavesManager"=>typeof(Manager),"GlobalStaticVars/LawnApp"=>typeof(Lawn),"GlobalStaticVars"=>typeof(Global),_=>throw new NotSupportedException(t.FullName)};
    }
    static MC.TypeReference Close(MC.TypeReference t,MC.MethodReference m)
    {
        if(t is MC.GenericParameter p&&p.Type==MC.GenericParameterType.Type&&m.DeclaringType is MC.GenericInstanceType g)return g.GenericArguments[p.Position];
        if(t is MC.GenericInstanceType gi){var r=new MC.GenericInstanceType(gi.ElementType);foreach(var a in gi.GenericArguments)r.GenericArguments.Add(Close(a,m));return r;}
        return t;
    }
    static MethodBase Method(MC.MethodReference m)
    {
        if(m.DeclaringType.FullName=="UnityEngine.Debug"&&m.Name=="Log")return typeof(Program).GetMethod(nameof(Log))!;
        Type owner=Map(m.DeclaringType);return owner.GetMethod(m.Name,BindingFlags.Public|BindingFlags.Static|BindingFlags.Instance,null,m.Parameters.Select(p=>Map(Close(p.ParameterType,m))).ToArray(),null)!;
    }
    static object[] EH(MC.MethodDefinition m)=>m.Body.ExceptionHandlers.Select(e=>(object)new{kind=e.HandlerType.ToString(),tryStart=m.Body.Instructions.IndexOf(e.TryStart),tryEnd=e.TryEnd==null?-1:m.Body.Instructions.IndexOf(e.TryEnd),handlerStart=m.Body.Instructions.IndexOf(e.HandlerStart),handlerEnd=e.HandlerEnd==null?-1:m.Body.Instructions.IndexOf(e.HandlerEnd),filterStart=e.FilterStart==null?-1:m.Body.Instructions.IndexOf(e.FilterStart)}).ToArray();
    static string Graph(MC.MethodDefinition m)=>JsonSerializer.Serialize(m.Body.Instructions.Select(i=>new{op=i.OpCode.Name,operand=i.Operand is CIL.Instruction j?(object)m.Body.Instructions.IndexOf(j):i.Operand is CIL.Instruction[] js?js.Select(k=>m.Body.Instructions.IndexOf(k)).ToArray():i.Operand is CIL.VariableDefinition v?(object)("local:"+v.Index):i.Operand is MC.ParameterDefinition p?(object)("arg:"+p.Index):i.Operand is MC.IMetadataTokenProvider?(object)"mapped_metadata_reference":i.Operand}));
    static (MethodInfo method,object binding) Clone(MC.MethodDefinition source,string output)
    {
        using var bridge=MC.AssemblyDefinition.CreateAssembly(new MC.AssemblyNameDefinition("R19ExactBody_"+Guid.NewGuid().ToString("N"),new Version(1,0)),"Bridge",MC.ModuleKind.Dll);var module=bridge.MainModule;
        var owner=new MC.TypeDefinition("Rehosted","Caller",MC.TypeAttributes.Public|MC.TypeAttributes.Abstract|MC.TypeAttributes.Sealed,module.ImportReference(typeof(object)));module.Types.Add(owner);
        var target=new MC.MethodDefinition("Execute",MC.MethodAttributes.Public|MC.MethodAttributes.Static,module.ImportReference(Map(source.ReturnType)));owner.Methods.Add(target);
        if(source.HasThis)target.Parameters.Add(new MC.ParameterDefinition("self",MC.ParameterAttributes.None,module.ImportReference(Map(source.DeclaringType))));
        foreach(var p in source.Parameters)target.Parameters.Add(new MC.ParameterDefinition(p.Name,p.Attributes,module.ImportReference(Map(p.ParameterType))));
        target.Body.InitLocals=source.Body.InitLocals;target.Body.MaxStackSize=source.Body.MaxStackSize;
        foreach(var v in source.Body.Variables)target.Body.Variables.Add(new CIL.VariableDefinition(module.ImportReference(Map(v.VariableType))));
        var instructions=source.Body.Instructions.ToDictionary(i=>i,_=>CIL.Instruction.Create(CIL.OpCodes.Nop));foreach(var i in source.Body.Instructions)target.Body.Instructions.Add(instructions[i]);var contracts=new List<object>();
        foreach(var i in source.Body.Instructions)
        {
            var n=instructions[i];n.OpCode=i.OpCode;
            n.Operand=i.Operand switch
            {
                CIL.Instruction j=>instructions[j],CIL.Instruction[] js=>js.Select(j=>instructions[j]).ToArray(),CIL.VariableDefinition v=>target.Body.Variables[v.Index],MC.ParameterDefinition p=>target.Parameters[p.Index+(source.HasThis?1:0)],
                MC.TypeReference t=>module.ImportReference(Map(t)),MC.FieldReference f=>ImportField(f),MC.MethodReference m=>ImportMethod(m),_=>i.Operand
            };
        }
        MC.FieldReference ImportField(MC.FieldReference f){var mapped=Map(f.DeclaringType).GetField(f.Name,BindingFlags.Public|BindingFlags.Static|BindingFlags.Instance)!;if(mapped.FieldType!=Map(f.FieldType))throw new Exception("Changed field type "+f.FullName);contracts.Add(new{source=f.FullName,mapped=mapped.ToString()});return module.ImportReference(mapped);}
        MC.MethodReference ImportMethod(MC.MethodReference m){var mapped=Method(m)??throw new Exception("Missing method "+m.FullName);if(m.HasThis==mapped.IsStatic||!mapped.GetParameters().Select(p=>p.ParameterType).SequenceEqual(m.Parameters.Select(p=>Map(Close(p.ParameterType,m)))))throw new Exception("Changed method contract "+m.FullName);if(mapped is MethodInfo mi&&mi.ReturnType!=Map(Close(m.ReturnType,m)))throw new Exception("Changed return contract "+m.FullName);contracts.Add(new{source=m.FullName,mapped=mapped.ToString()});return module.ImportReference(mapped);}
        foreach(var e in source.Body.ExceptionHandlers)target.Body.ExceptionHandlers.Add(new CIL.ExceptionHandler(e.HandlerType){TryStart=instructions[e.TryStart],TryEnd=e.TryEnd==null?null:instructions[e.TryEnd],HandlerStart=instructions[e.HandlerStart],HandlerEnd=e.HandlerEnd==null?null:instructions[e.HandlerEnd],FilterStart=e.FilterStart==null?null:instructions[e.FilterStart],CatchType=e.CatchType==null?null:module.ImportReference(Map(e.CatchType))});
        module.Write(output);using var readback=MC.AssemblyDefinition.ReadAssembly(output);var saved=readback.MainModule.Types.Single(t=>t.FullName=="Rehosted.Caller").Methods.Single();if(Graph(saved)!=Graph(source)||JsonSerializer.Serialize(EH(saved))!=JsonSerializer.Serialize(EH(source)))throw new Exception("Instruction/branch/EH graph changed");
        var loaded=AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.GetFullPath(output));var method=loaded.GetType("Rehosted.Caller")!.GetMethod("Execute")!;if(!method.GetMethodBody()!.LocalVariables.Select(v=>v.LocalType).SequenceEqual(source.Body.Variables.Select(v=>Map(v.VariableType))))throw new Exception("Changed local contracts");
        return(method,new{scope="COMPLETE_CIL_CLONE_OPERAND_BINDING_ONLY_REAL_EXCEPTION_CLAUSES_RETAINED",source_token="0x"+source.MetadataToken.ToUInt32().ToString("X8"),source_instructions=source.Body.Instructions.Count,bridge_instructions=saved.Body.Instructions.Count,source_code_size=source.Body.CodeSize,bridge_code_size=saved.Body.CodeSize,identical_opcode_branch_switch_graph=true,identical_eh_graph=true,source_eh=EH(source),mapped_locals_verified=true,callee_and_field_contracts=contracts,dead_code_pruned=false,ret_appended=false,skip_visibility=false});
    }
    public static void Main(string[] args)
    {
        var resolver=new MC.DefaultAssemblyResolver();resolver.AddSearchDirectory(args[1]);using var game=MC.AssemblyDefinition.ReadAssembly(args[0],new MC.ReaderParameters{AssemblyResolver=resolver});var source=(MC.MethodDefinition)game.MainModule.LookupToken(0x0600006D);var (method,binding)=Clone(source,args[4]);using var cases=JsonDocument.Parse(File.ReadAllText(args[2]));var rows=new List<object>();
        foreach(var q in cases.RootElement.EnumerateArray())
        {
            Mode=q.GetProperty("mode").GetString()!;Trace.Clear();Calls=0;var manager=new Manager{Id="m0"};Other=new Manager{Id="m1"};Global.gLawnApp=new Lawn{savesManager=manager};manager.playerSave.plantSaves=q.GetProperty("items").EnumerateArray().Select(i=>i.ValueKind==JsonValueKind.Null?null:new PlantSave{Id=i.GetString()}).ToList();string? error=null;try{method.Invoke(null,new object?[]{new System0()});}catch(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;error=e.GetType().FullName;}
            rows.Add(new{name=q.GetProperty("name").GetString(),error,trace=Trace.ToArray(),global_manager=Global.gLawnApp!.savesManager!.Id,original_manager_list_count=manager.playerSave.plantSaves.Count});
        }
        File.WriteAllText(args[3],JsonSerializer.Serialize(new{scope="COMPLETE_ACTUAL_CANDIDATE_FOREACH_CIL_WITH_ORIGINAL_FINALLY_GRAPH_CONTROLLED_MANAGER_DEBUG",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),token="0x0600006D",binding,results=rows,original_native_unwind="UNSUPPORTED",unity_or_product_acceptance=false},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{methods=1,records=rows.Count,finally_preserved=true}));
    }
}
