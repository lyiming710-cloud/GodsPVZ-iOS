"""Physical omitted callback and missing-finally controls for exact foreach body."""
from pathlib import Path
import hashlib,importlib.util,json,struct,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];stem=sys.argv[1] if len(sys.argv)>1 else 'candidate9';P=Q/('shared-'+stem);O=P/'foreach-controls';O.mkdir(exist_ok=True);sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
base=(Q/(stem+'.dll')).read_bytes();pe=dnfile.dnPE(data=base);rid=0x6d;at=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[rid-1].Rva);h=(struct.unpack_from('<H',base,at)[0]>>12)*4;assert h==12
cil=json.loads((P/'ALL-CIL.json').read_bytes());method=next(m for m in cil['methods'] if m['token']=='0x0600006D');assert method['handlers']==[dict(kind='Finally',tryStart=31,tryEnd=67,handlerStart=67,handlerEnd=75,catchType=None)]
spec=importlib.util.spec_from_file_location('foreach_raw_reader',ROOT/'audit/native111-publication-2026-10-20/repository/scripts/actions/static_gates.py');reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
def eh_contract(data):
 info=reader.parse_raw_method_body_span(data,at);assert data[at:at+2]==base[at:at+2] and info==reader.parse_raw_method_body_span(base,at),'Exact source finally/header contract changed'
 n=struct.unpack_from('<I',data,at+4)[0];eh=(at+h+n+3)&~3;assert data[eh:at+info[0]]==base[eh:at+info[0]],'Finally section changed'
eh_contract(base)
cases=json.loads((Q/'FOREACH-CASES.json').read_bytes());expected={r['name']:r for r in json.loads((P/'NATIVE-FOREACH.json').read_bytes())['results']}
data=bytearray(base);i=next(i for i in method['instructions'] if i['opcode']=='callvirt' and i['operand']['name']=='ReloadPlantSaveData');p=at+h+i['offset'];assert data[p]==0x6f;data[p:p+5]=bytes.fromhex('2626000000');eh_contract(data);file=O/'omitted-reload.dll';file.write_bytes(data)
out=O/'omitted-reload.runtime.json';dot=ROOT/'.local/dotnet10/dotnet.exe';fixture=Q/'runtime-foreach/bin/Release/net10.0/Fixture.dll';support=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'
run=subprocess.run([str(dot),str(fixture),str(file),str(support),str(Q/'FOREACH-CASES.json'),str(out),str(O/'OmittedReloadBody.dll')],capture_output=True,timeout=45);(O/'omitted-reload.stdout.log').write_bytes(run.stdout);(O/'omitted-reload.stderr.log').write_bytes(run.stderr);assert run.returncode==0,'Process failure is not a semantic detection'
observed=json.loads(out.read_bytes());assert observed['candidate_sha256']==hashlib.sha256(data).hexdigest();different=[dict(original=expected[r['name']],actual=r) for r in observed['results'] if r['name'] in expected and expected[r['name']]!=r];assert different
bad=bytearray(base);flags=struct.unpack_from('<H',bad,at)[0];assert flags&8;struct.pack_into('<H',bad,at,flags&~8);(O/'finally-header-removed.dll').write_bytes(bad)
try:eh_contract(bad)
except AssertionError:eh_rejected=True
else:raise AssertionError('Missing-finally false acceptance')
report=dict(scope='EXACT_FOREACH_PHYSICAL_CALLBACK_FAULT_AND_SOURCE_FINALLY_GUARD',candidate_sha256=hashlib.sha256(base).hexdigest(),omitted_callback=dict(physical_sha256=hashlib.sha256(data).hexdigest(),normal_records=len(expected),different_records=len(different),status='RUNTIME_DIFFERENCE_DETECTED',differences=different),missing_finally=dict(physical_sha256=hashlib.sha256(bad).hexdigest(),raw_source_guard_rejected=eh_rejected,runtime_dispose_side_effect_proof=False),native_unwind='UNSUPPORTED',formal_or_product_acceptance=False)
(P/'FOREACH-CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k!='omitted_callback'},indent=2));print('omitted callback runtime differences',len(different))
