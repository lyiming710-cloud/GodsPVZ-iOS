"""Native operand-width and float32 state-machine recovery; construction only."""
import struct
from construction import IL
import source_common as s
from source_dispatch import constant
def populate(c):
    sentinel={0xb8:[0xe8],0x1c6:[0x60],0x3a8:[0x2f2,0x3f9],0x3ab:[0xa4,0x144],0x598:[0xfe],0x5e8:[0x2b,0x168,0x181,0x19a,0x1a9],0x686:[0xe4]}
    for rid,sites in sentinel.items():
        token=s.tok(rid);code=bytearray(s.body(token)['code'])
        for at in sites:
            assert bytes(code[at:at+9])==b'\x21'+struct.pack('<q',0xffffffff)
            code[at:at+9]=IL().i4(-1).op('00000000').finish()
        if rid==0x5e8:
            assert code[0x3f:0x44]==b'\x20\0\0\0\0';code[0x3f:0x44]=b'\x22\0\0\0\0'
        c.add(rid,code,'Original native MOV r32,FFFFFFFF passes an Int32 -1 sentinel, not positive Int64 4294967295; fixed-width replacement preserves every existing branch/EH target.',group='native-int32-width')
    # The VFX duration comparisons are explicitly COMISS against XORPS zero.
    token=s.tok(0xc3);code=bytearray(s.body(token)['code'])
    for at in [0x8a,0xca]:
        assert code[at:at+5]==b'\x20\0\0\0\0';code[at:at+5]=b'\x22\0\0\0\0'
    c.add(0xc3,code,'Recover Single zero at both original duration comparisons without changing the integer/Boolean comparisons.',group='float32-operands')
    # Captured maximum precedes Random.Range in both native bodies.
    for rid in [0x265,0x268]:
        b=IL().arg(0).token(0x7b,c.fld('SunManager','sunFallTimeMax')).store(0).r4(0).r4(1).token(0x28,c.meth('UnityEngine.Random','Range',['System.Single','System.Single'])).loc(0).r4(0.5).op('5a6b586b').arg(0).token(0x7b,c.fld('SunManager','sunFallCount')).op('6b586b').store(5)
        b.loc(5).r4(0).branch(0x3f,'zero').loc(5).arg(0).token(0x7b,c.fld('SunManager','sunFallTimeMax')).branch(0x3d,'bounded').branch(0x38,'minimum')
        b.mark('bounded').arg(0).token(0x7b,c.fld('SunManager','sunFallTimeMax')).store(5).branch(0x38,'minimum').mark('zero').r4(0).store(5)
        b.mark('minimum').arg(0).token(0x7b,c.fld('SunManager','sunFallTimeMax')).store(2).loc(2).loc(5).branch(0x3f,'max_is_less').loc(5).branch(0x38,'selected').mark('max_is_less').loc(2).mark('selected')
        if rid==0x268:b.store(7).arg(0).loc(7).token(0x7d,c.fld('SunManager','sunFallTimeOnce')).arg(0).loc(7).token(0x7d,c.fld('SunManager','sunFallTime'))
        b.op('2a');c.add(rid,b,'Restore the native captured maximum before Random, float32 clamp including unordered branches, final MINSS source selection, and ordered timer writes.',maxstack=3,group='float32-state')
    # ICE Start forwards an explicit false visual-effects argument.
    owner='Device/ICEUIController';b=IL().arg(0).token(0x7b,c.fld(owner,'gameObject')).op('14').token(0x28,c.meth('UnityEngine.Object','op_Inequality',['UnityEngine.Object','UnityEngine.Object'])).branch(0x39,'done')
    b.r4(0).arg(1).branch(0x3c,'inactive').arg(0).token(0x7b,c.fld(owner,'gameObject')).i4(1).token(0x6f,c.meth('UnityEngine.GameObject','SetActive',['System.Boolean']))
    b.arg(3).token(0x7b,c.fld('Device','animator')).token(0x28,c.meth('UnityEngine.Object','op_Implicit',['UnityEngine.Object'])).branch(0x39,'update').arg(3).token(0x7b,c.fld('Device','animator')).r4(0).token(0x6f,c.meth('UnityEngine.Animator','set_speed',['System.Single']))
    b.mark('update').arg(0).arg(1).arg(2).arg(3).i4(0).token(0x28,c.meth(owner,'Update',['System.Single','System.Single','Device','System.Boolean'])).branch(0x38,'done').mark('inactive').arg(0).token(0x7b,c.fld(owner,'gameObject')).i4(0).token(0x6f,c.meth('UnityEngine.GameObject','SetActive',['System.Boolean'])).mark('done').op('2a')
    c.add(0x341,b,'Restore float-zero and NaN branch, explicit false Update argument, Unity object truthiness and original renderer/animator reloads.',maxstack=5,group='float32-state')
    # Zombie path state machine: read waitingTime before deltaTime callback.
    b=IL().arg(0).token(0x28,c.meth('Zombie','IsDisabled')).branch(0x3a,'done').arg(0).token(0x7b,c.fld('Zombie','isStant')).branch(0x3a,'waiting')
    b.arg(0).token(0x28,c.meth('Zombie','Path_Test')).branch(0x39,'done').arg(0).token(0x28,c.meth('Zombie','Path_Finding')).op('262a')
    b.mark('waiting').arg(0).token(0x7b,c.fld('Zombie','waitingTime')).store(6).loc(6).r4(0).branch(0x43,'done').loc(6).token(0x28,c.meth('UnityEngine.Time','get_deltaTime')).op('596b').store(11).arg(0).loc(11).token(0x7d,c.fld('Zombie','waitingTime')).r4(0).loc(11).branch(0x44,'done')
    b.arg(0).token(0x28,c.meth('Zombie','Path_Finding')).branch(0x3a,'walk').arg(0).token(0x28,c.meth('UnityEngine.Time','get_deltaTime')).token(0x7d,c.fld('Zombie','waitingTime')).branch(0x38,'done').mark('walk').arg(0).token(0x28,c.meth('Zombie','TranToWalk')).mark('done').op('2a')
    c.add(0x428,b,'Restore native waiting-state flow, captured waitingTime, original time callback order, NaN JB behavior and path result handling.',maxstack=3,group='float32-state')
    # Living time captures the old value before reading Time. Two independent timers.
    b=IL().arg(0).arg(0).token(0x7b,c.fld('Zombie','livingTime')).token(0x28,c.meth('UnityEngine.Time','get_deltaTime')).op('586b').token(0x7d,c.fld('Zombie','livingTime'))
    for n,field in enumerate(['stiffnessTime','snowbeast_impactCD']):
        after='timer'+str(n);b.arg(0).token(0x7b,c.fld('Zombie',field)).store(0).loc(0).r4(0).branch(0x43,after).loc(0).token(0x28,c.meth('UnityEngine.Time','get_deltaTime')).op('596b').store(1).arg(0).loc(1).token(0x7d,c.fld('Zombie',field)).r4(0).loc(1).branch(0x44,after).arg(0).r4(0).token(0x7d,c.fld('Zombie',field)).mark(after)
    b.op('2a');c.add(0x42c,b,'Restore float32 timer thresholds, pre-callback captures, second timer independence and exact unordered clamp branches.',maxstack=3,group='float32-state')
    # Shooting captures deltaTime, then updateRate, then shootingTime.
    b=IL().arg(0).token(0x28,c.meth('Zombie','IsDisabled')).branch(0x3a,'done').arg(0).token(0x7b,c.fld('Zombie','shootingInterval')).r4(0).branch(0x43,'done')
    b.token(0x28,c.meth('UnityEngine.Time','get_deltaTime')).arg(0).token(0x7b,c.fld('Zombie','updateRate')).op('5a6b').arg(0).token(0x7b,c.fld('Zombie','shootingTime')).op('586b').store(3).arg(0).loc(3).token(0x7d,c.fld('Zombie','shootingTime')).loc(3).arg(0).token(0x7b,c.fld('Zombie','shootingInterval')).branch(0x44,'done')
    b.arg(0).r4(0).token(0x7d,c.fld('Zombie','shootingTime')).arg(0).token(0x7b,c.fld('Zombie','animator')).token(0x72,c.text(0x42b,'ShootingTrigger')).token(0x6f,c.meth('UnityEngine.Animator','SetTrigger',['System.String'])).mark('done').op('2a')
    c.add(0x42b,b,'Restore float32 interval tests, accumulation and unordered native return path; remove fabricated metadata control flow before the real trigger.',maxstack=3,group='float32-state')
