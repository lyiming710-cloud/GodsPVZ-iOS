"""Freeze the first hundred construction and enable the shared test round."""
from pathlib import Path
import json,hashlib,shutil,sys
Q=Path(__file__).resolve().parent;W=Q.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
first,second=sys.argv[1:] if len(sys.argv)>1 else ['candidate1','candidate2']
a=json.loads((Q/(first+'.json')).read_bytes());b=json.loads((Q/(second+'.json')).read_bytes())
assert a['new_unique_methods']==b['new_unique_methods']==100 and a['candidate_sha256']==b['candidate_sha256']
assert (Q/(first+'.dll')).read_bytes()==(Q/(second+'.dll')).read_bytes() and sha((Q/(first+'.dll')).read_bytes())==a['candidate_sha256']
assert not a['tests_run'] and not b['tests_run']
targets=sorted(r['token'] for r in a['changes']);inventory=json.loads((Q/'SOURCE-INVENTORY.json').read_bytes());assert set(targets)=={r['token'] for r in inventory['source_targets']}
def write(name,value):(Q/name).write_bytes((json.dumps(value,indent=2)+'\n').encode())
write('METHODS.json',dict(methods=[dict(token=t) for t in targets]))
shutil.copy2(W/'startup-r18-batch50/ALL-METHODS.json',Q/'ALL-METHODS.json')
write('SHARED-TEST-START.json',dict(scope='FIRST_SHARED_TEST_ENABLED_ONLY_AFTER_ONE_HUNDRED_DISTINCT_NATIVE_BACKED_CONSTRUCTIONS',candidate_sha256=a['candidate_sha256'],constructed_methods=100,repeat_identical=True,tests_run_before_this_marker=False,qualified_methods=0,whole_game_acceptance=False))
write('ACTIVE-INPUT.json',dict(candidate_file=first+'.dll',report_file=first+'.json',candidate_sha256=a['candidate_sha256'],test_output='shared-'+first))
print(json.dumps(dict(shared_tests_enabled=True,constructed_methods=100,candidate_sha256=a['candidate_sha256'])))
