using System.Collections;using System.Reflection;using System.Runtime.CompilerServices;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public class MonoBase{public MonoBase()=>Program.Trace.Add("MonoCtorControlled");}
public class DeviceManager:MonoBase{public object? board;public List<object>? devicePrefabList,deviceList,preDeviceList,effectBoardEntries;public bool display_Ban_device;public DeviceEntry? boardEntryData;}
public class ZombieManager:MonoBase{public object? board;public List<object>? audioClip_zombie,zombiePrefabList,zombieList,effectBoardEntries;public int numOfTotalZombie,ladderTimes;public float ladderCountDown;public bool ladderTrigger;public ZombieEntry? boardEntryData;}
public class DeviceEntry{public float magnification_Atk,magnification_Hp,magnification_Def;public DeviceEntry()=>Program.Go(0x191,this);}
public class ZombieEntry{public float magnification_Atk,magnification_Hp,magnification_Def,toughness,elementalResistance;public ZombieEntry()=>Program.Go(0x27f,this);}
public class CardData{public string? name,synopsis,characteristicText;public int plantID,stars,level,levelOrder;public Skill? skill;public object? hormon;public float attackPoint,armorPoint,defensePoint,healthPoint,maxHealthPoint,attackInterva,characteristicTicking,characteristicMaxTicking;public string[]? talentNames,talents;}
public class Skill{public string? name,description;public int ID,ChargeType,type,skillTriggerType,chargedLayer,maxChargedLayer;public bool unlock,needManualSeek,isPerpetual,isPreventCharge;public float duration,chargeTicking,maxChargeTicking;public float[]? value_float;public Skill()=>Program.Go(0x4e6,this);}
public static class Program
{
    public static List<string> Trace=[];static Dictionary<int,MethodInfo> Code=[];
    static Dictionary<string,Type> Names=new(){{"DeviceManager",typeof(DeviceManager)},{"DeviceManager/BoardEntryData",typeof(DeviceEntry)},{"ZombieManager",typeof(ZombieManager)},{"ZombieManager/BoardEntryData",typeof(ZombieEntry)},{"Card/PlantData",typeof(CardData)},{"Skill",typeof(Skill)}};
    public static void Go(int rid,object self){try{Code[rid].Invoke(null,new[]{self});}catch(TargetInvocationException e)when(e.InnerException!=null){System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(e.InnerException).Throw();}}
    static Type Map(MC.TypeReference t)
    {
        if(t is MC.ArrayType ar)return Map(ar.ElementType).MakeArrayType();if(t is MC.ByReferenceType br)return Map(br.ElementType).MakeByRefType();
        if(t is MC.GenericInstanceType g){if(g.ElementType.FullName!="System.Collections.Generic.List`1")throw new NotSupportedException(t.FullName);return typeof(List<>).MakeGenericType(g.GenericArguments.Select(Map).ToArray());}
        if(Names.TryGetValue(t.FullName,out var known))return known;
        return t.FullName switch{"System.Void"=>typeof(void),"System.Object"=>typeof(object),"System.String"=>typeof(string),"System.Int32"=>typeof(int),"System.IntPtr"=>typeof(IntPtr),"System.Single"=>typeof(float),"System.Boolean"=>typeof(bool),"UnityEngine.MonoBehaviour"=>typeof(MonoBase),"SkillChargeType" or "SkillType" or "SkillTriggerType"=>typeof(int),"Board" or "Device" or "PreDevice" or "BoardEntry" or "Zombie" or "UnityEngine.AudioClip" or "Hormon"=>typeof(object),_=>throw new NotSupportedException(t.FullName)};
    }
    static FieldInfo Field(MC.FieldReference f)=>Map(f.DeclaringType).GetField(f.Name,BindingFlags.Public|BindingFlags.Static|BindingFlags.Instance)!;
    static MethodBase Method(MC.MethodReference m){if(m.Name!=".ctor")throw new NotSupportedException(m.FullName);return Map(m.DeclaringType).GetConstructor(m.Parameters.Select(p=>Map(p.ParameterType)).ToArray())!;}
    static object? Snapshot(object? v)
    {
        if(v==null)return null;Type t=v.GetType();if(v is string||v is bool||v is int)return v;if(v is float f)return new{f32=BitConverter.SingleToUInt32Bits(f).ToString("X8")};
        if(v is Array a){Type e=t.GetElementType()!;object? z=e.IsValueType?Activator.CreateInstance(e):null;return new{kind="array",length=a.Length,all_default=a.Cast<object?>().All(x=>Equals(x,z))};}
        if(v is IList list)return new{kind="list",count=list.Count,capacity=(int)t.GetProperty("Capacity")!.GetValue(v)!};
        string name=Names.Single(p=>p.Value==t).Key;return new{type=name,fields=t.GetFields(BindingFlags.Public|BindingFlags.Instance|BindingFlags.DeclaredOnly).ToDictionary(f=>f.Name,f=>Snapshot(f.GetValue(v)))};
    }
    public static void Main(string[] args)
    {
        var resolver=new MC.DefaultAssemblyResolver();resolver.AddSearchDirectory(args[1]);using var asm=MC.AssemblyDefinition.ReadAssembly(args[0],new MC.ReaderParameters{AssemblyResolver=resolver});int[] roots={0x190,0x27e,0x2ed,0x4e6},all={0x191,0x27f,0x4e6,0x190,0x27e,0x2ed};
        foreach(int rid in all)Code[rid]=ActualCil.Emit((MC.MethodDefinition)asm.MainModule.LookupToken(0x6000000|rid),Map,Field,Method);
        var rows=new List<object>();foreach(int rid in roots){var source=(MC.MethodDefinition)asm.MainModule.LookupToken(0x6000000|rid);object target=RuntimeHelpers.GetUninitializedObject(Map(source.DeclaringType));Trace.Clear();string? error=null;try{Go(rid,target);}catch(Exception e){error=e.ToString();}rows.Add(new{token="0x"+(0x6000000|rid).ToString("X8"),value=0,error,state=Snapshot(target),trace=Trace.ToArray()});}
        File.WriteAllText(args[2],JsonSerializer.Serialize(new{scope="FOUR_COMPLETE_CANDIDATE_CTOR_BODIES_CONTROLLED_MONO_BASE_WITHOUT_GAME_STATIC_INITIALIZERS",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),methods=4,uncounted_complete_cil_dependencies=new[]{"0x06000191","0x0600027F"},results=rows,actual_unmodified_dll_engine_blocks_unchanged=true,limitations=new[]{"Opaque references used only as unused/null fields or empty list element types","This models constructor bodies and explicit base contract; it does not validate game cctors or Unity base internals","No allocation order or GC acceptance","No Unity player/IPA proof"}},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{methods=4,records=rows.Count}));
    }
}
