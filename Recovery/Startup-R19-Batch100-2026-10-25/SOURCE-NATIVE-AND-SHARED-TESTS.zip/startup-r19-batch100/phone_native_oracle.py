"""Original phone validator body, controlled string/Debug/GC leaves only."""
from pathlib import Path
import ctypes as C,hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
im=NativeImage();trace=[];cfg=json.loads((Q/'native-source-complete/0x06000728.json').read_bytes())
def string(s):
    if s is None:return 0
    b=s.encode('utf-16-le');p=im.alloc(24+len(b));put32(p+0x10,len(b)//2);C.memmove(p+0x14,b,len(b));return p
def text(p):return None if not p else C.string_at(p+0x14,get32(p+0x10)*2).decode('utf-16-le')
def barrier(at,p):assert get64(at)==(p or 0)
try:
    meta=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/global-metadata.dat').read_bytes();assert hashlib.sha256(meta).hexdigest()=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9'
    so,sn,do,dn=struct.unpack_from('<4I',meta,8);dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True;slots=set()
    for row in cfg['instructions']:
        i=next(dis.disasm(bytes.fromhex(row['bytes']),int(row['va'],16)))
        for op in i.operands:
            if op.type!=X86_OP_MEM or op.mem.base!=X86_REG_RIP:continue
            at=i.address+i.size+op.mem.disp;raw=im.pe.get_data(at-im.base,8)
            if len(raw)!=8:continue
            code=int.from_bytes(raw,'little')
            if code>0xffffffff or code>>29 not in range(1,8):continue
            slots.add(at);kind,index=code>>29,(code&0x1fffffff)>>1
            if kind==5:n,pos=struct.unpack_from('<II',meta,so+8*index);put64(at,string(meta[do+pos:do+pos+n].decode('utf-8')))
            else:cls=im.class_slot(at);put64(get64(cls+0xb8),string(''))
    def init(slot):assert slot in slots,hex(slot)
    im.hook(0x18024fef0,None,[P],init);im.hook(0x1802501e0,None,[P],lambda p:None);im.hook(0x18024f360,None,[P,P],barrier)
    im.hook(0x1812e68f0,None,[P,P],lambda s,m:trace.append('Log:'+str(text(s))))
    im.hook(0x180b85b80,P,[P,P],lambda p,m:string(chr(C.c_uint16.from_address(p).value)))
    im.hook(0x180b74270,P,[P,P,P],lambda a,b,m:string((text(a)or'')+(text(b)or'')))
    im.hook(0x180b73f50,P,[P,P,P,P],lambda a,b,c,m:string((text(a)or'')+(text(b)or'')+(text(c)or'')))
    im.verify_caller(0x728,int(cfg['entry'],16),cfg)
    rows=[]
    for q in json.loads((Q/'PHONE-CASES.json').read_bytes()):
        if not q['native_supported']:continue
        trace.clear();s,p=im.alloc(8),im.alloc(4);put64(s,string(q['text']));put32(p,q['position'])
        result=C.CFUNCTYPE(C.c_uint16,P,P,P,C.c_uint16,P)(int(cfg['entry'],16))(im.alloc(32),s,p,q['character'],None)
        assert not im.errors,im.errors;rows.append(dict(name=q['name'],error=None,result=result,text=text(get64(s)),position=get32(p),trace=list(trace)))
    actual=json.loads(Path(sys.argv[1]).read_bytes());byname={r['name']:r for r in actual['results']};deltas=[dict(original=r,actual=byname[r['name']]) for r in rows if r!=byname[r['name']]]
    report=dict(scope='ORIGINAL_PC_COMPLETE_PHONE_VALIDATOR_VS_FULL_CANDIDATE_CIL_CONTROLLED_STRING_AND_DEBUG_LEAVES',candidate_sha256=actual['candidate_sha256'],original_pc_sha256=hashlib.sha256(im.raw).hexdigest(),caller_bytes_checked=True,normal_records=len(rows),differences=deltas,results=rows,callback_errors=im.errors,native_exception_unwind='UNSUPPORTED',unity_or_product_acceptance=False)
    Path(sys.argv[2]).write_text(json.dumps(report,indent=2,ensure_ascii=True)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k not in ['results','differences']}));print('differences',len(deltas));assert not deltas
finally:im.close()
