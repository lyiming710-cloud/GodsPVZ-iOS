"""Execute original constructors; compare complete declared field snapshots.

GC, metadata, allocation, List ctor and Mono/Map leaves have explicit contracts.
Selected caller bytes and selected nested ctor bytes stay original. Field state
does not prove allocation order, GC, Unity base construction or exception unwind.
"""
from pathlib import Path
import ctypes as C, functools, hashlib, json, struct, sys

Q = Path(__file__).resolve().parent
W = Q.parent
ROOT = W.parents[1]
sys.path.insert(0, str(W / 'startup-r5'))
from native_runtime_common import NativeImage, P, I, get32, get64, put32, put64
from capstone import Cs, CS_ARCH_X86, CS_MODE_64
from capstone.x86_const import X86_OP_MEM, X86_REG_RIP

stem = sys.argv[2] if len(sys.argv) > 2 else 'candidate5'
actual = json.loads((Q / ('shared-' + stem) / 'DIRECT-CONSTRUCTORS.json').read_bytes())
contracts = actual['contracts']
fields = json.loads((ROOT / 'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_bytes())
types = json.loads((ROOT / 'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-types.json').read_bytes())
im = NativeImage()
meta = (ROOT / 'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/global-metadata.dat').read_bytes()
assert hashlib.sha256(meta).hexdigest() == 'ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9'
mv = struct.unpack('<16Q', im.pe.get_data(0x18c6d00, 128))
assert mv[6] > 20000
read = lambda va, n: im.pe.get_data(va - im.base, n)
nq = lambda va: struct.unpack('<Q', read(va, 8))[0]
arrays = {}
class_names = {}
slots = {}
trace = []


@functools.lru_cache(None)
def original_type(name):
    d = contracts[name]
    leaf = name.rsplit('/', 1)[-1].rsplit('.', 1)[-1]
    rows = [t for t in types if t['name'] == leaf and int(t['token'], 16) == int(d['token'], 16)]
    assert len(rows) == 1, (name, rows)
    return rows[0]['index']


native_names = {original_type(name): name for name in contracts if not name.startswith('Cpp2ILInjected.')}


def type_name(ptr):
    data, flags = struct.unpack('<QI', read(ptr, 12))
    kind = (flags >> 16) & 255
    if kind in [0x11, 0x12]:
        t = types[data]
        return native_names.get(data, (t['namespace'] + '.' if t['namespace'] else '') + t['name'])
    if kind == 0x15:
        tp, ci, mi, cached = struct.unpack('<4Q', read(data, 32))
        n, at = struct.unpack('<QQ', read(ci, 16))
        return type_name(tp) + '<' + ','.join(type_name(nq(at + 8 * k)) for k in range(n)) + '>'
    if kind == 0x1d:
        return type_name(data) + '[]'
    return {1: 'System.Void', 2: 'System.Boolean', 3: 'System.Char', 8: 'System.Int32', 0xa: 'System.Int64',
            0xc: 'System.Single', 0xd: 'System.Double', 0xe: 'System.String', 0x1c: 'System.Object'}.get(kind, f'kind{kind:x}:{data:x}')


def string(value):
    b = value.encode('utf-16-le')
    p = im.alloc(24 + len(b))
    put32(p + 0x10, len(b) // 2)
    C.memmove(p + 0x14, b, len(b))
    return p


def array(cls, n):
    assert 0 <= n < 10000
    p = im.alloc(32 + 16 * n)
    put64(p, cls)
    put32(p + 0x18, n)
    arrays[p] = n
    trace.append(['Array', class_names.get(cls), n])
    return p


def allocation(cls):
    assert cls in class_names, hex(cls)
    p = im.alloc(4096)
    put64(p, cls)
    trace.append(['New', class_names[cls]])
    return p


def list_ctor(p, method):
    assert class_names[get64(p)].startswith('System.Collections.Generic.List`1<')
    put64(p + 0x10, array(0, 0))
    put32(p + 0x18, 0)
    trace.append(['ListCtor', class_names[get64(p)]])


def barrier(at, p):
    assert get64(at) == (p or 0)


@functools.lru_cache(None)
def offset(owner, f):
    index = original_type(owner)
    rows = [r for r in fields if r['typeIndex'] == index and r['name'] == f]
    assert len(rows) == 1, (owner, f, rows)
    return rows[0]['offset']


def snapshot_value(at, f, depth):
    name = f['type']
    if name == 'System.Boolean':
        return bool(C.c_ubyte.from_address(at).value)
    if name in ['System.Int32', 'System.UInt32'] or f['is_enum']:
        return get32(at)
    if name == 'System.Int64':
        return C.c_int64.from_address(at).value
    if name == 'System.Single':
        return dict(f32=C.string_at(at, 4)[::-1].hex().upper())
    if name == 'System.Double':
        return dict(f64=C.string_at(at, 8)[::-1].hex().upper())
    if name in ['System.Byte', 'System.SByte']:
        return C.c_ubyte.from_address(at).value
    if name == 'UnityEngine.Vector3':
        return dict(type=name, fields={axis: dict(f32=C.string_at(at + 4 * k, 4)[::-1].hex().upper()) for k, axis in enumerate('xyz')})
    assert not f['is_value'], f
    p = get64(at)
    if not p:
        return None
    if name == 'System.String':
        return C.string_at(p + 0x14, get32(p + 0x10) * 2).decode('utf-16-le')
    if p in arrays:
        n = arrays[p]
        return dict(kind='array', length=n, all_default=not any(C.string_at(p + 0x20, 16 * n)))
    if name.startswith('System.Collections.Generic.List`1'):
        return dict(kind='list', count=get32(p + 0x18), capacity=arrays[get64(p + 0x10)])
    return snapshot(p, name, depth + 1)


def snapshot(p, name, depth=0):
    assert name in contracts
    if name == 'Map':
        return dict(type='Map', controlled_scope='presence_and_caller_written_cameraSize',
                    cameraSize=dict(f32=C.string_at(p + offset(name, 'cameraSize'), 4)[::-1].hex().upper()))
    if depth >= 5:
        return dict(type=name, depth_limited=True)
    return dict(type=name, fields={f['name']: snapshot_value(p + offset(name, f['name']), f, depth) for f in contracts[name]['fields']})


try:
    changes = json.loads((Q / (stem + '.json')).read_bytes())['changes']
    cfgs = {r['token']: json.loads((Q / 'native-source-complete' / (r['token'] + '.json')).read_bytes()) for r in changes if r['group'] == 'constructors'}
    dis = Cs(CS_ARCH_X86, CS_MODE_64)
    dis.detail = True
    literal_table, literal_count, literal_data, literal_bytes = struct.unpack_from('<4I', meta, 8)
    for cfg in cfgs.values():
        for row in cfg['instructions']:
            i = next(dis.disasm(bytes.fromhex(row['bytes']), int(row['va'], 16)))
            for op in i.operands:
                if op.type != X86_OP_MEM or op.mem.base != X86_REG_RIP:
                    continue
                at = i.address + i.size + op.mem.disp
                raw = read(at, 8)
                if len(raw) != 8:
                    continue  # zero-initialized native BSS guard, not a usage slot
                code = int.from_bytes(raw, 'little')
                if code > 0xffffffff or code >> 29 not in range(1, 8):
                    continue
                kind, index = code >> 29, (code & 0x1fffffff) >> 1
                slots[at] = (kind, index)
    empty = string('')
    for at, (kind, index) in slots.items():
        if kind == 5:
            n, pos = struct.unpack_from('<II', meta, literal_table + index * 8)
            put64(at, string(meta[literal_data + pos:literal_data + pos + n].decode('utf-8')))
        else:
            cls = im.class_slot(at)
            class_names[cls] = type_name(nq(mv[7] + index * 8)) if kind == 1 else 'MethodInfoContract'
            put64(get64(cls + 0xb8), empty)
    def init(slot):
        assert slot in slots, hex(slot)
    def map_ctor(p, x, y, method):
        assert (x, y) == (12, 7) and not method
        trace.append(['MapCtor', x, y])
    def mono_ctor(p, method):
        assert not method
        trace.append(['MonoCtorControlled'])
    im.hook(0x18024fef0, None, [P], init)
    im.hook(0x180250100, P, [P], allocation)
    im.hook(0x18024f3e0, P, [P, C.c_size_t], array)
    im.hook(0x1808053d0, None, [P, P], list_ctor)
    im.hook(0x18024f360, None, [P, P], barrier)
    im.hook(0x18032d290, None, [P, I, I, P], map_ctor)
    im.hook(0x1812e22a0, None, [P, P], mono_ctor)
    for token, cfg in cfgs.items():
        im.verify_caller(int(token, 16) & 0xffffff, int(cfg['entry'], 16), cfg)
    assert C.string_at(0x180302170, 3) == bytes.fromhex('c20000')
    rows = []
    mismatches = []
    blockers = []
    names = {r['token']: r['name'].split(' ')[1].split('::')[0] for r in changes if r['group'] == 'constructors'}
    for r in actual['results']:
        trace.clear()
        token, value = r['token'], r['value']
        p = im.alloc(4096)
        entry = int(cfgs[token]['entry'], 16)
        rid = int(token, 16) & 0xffffff
        if rid == 0x155:
            C.CFUNCTYPE(None, P, I, I, P)(entry)(p, value, value, None)
        elif rid in [0x255, 0x258, 0x259, 0x2fb, 0x4d5]:
            C.CFUNCTYPE(None, P, I, P)(entry)(p, value, None)
        elif rid == 0x855:
            labels, mesh, materials = array(0, 2), im.alloc(4096), array(0, 2)
            put64(labels + 0x20, string('alpha'))
            put64(labels + 0x28, string('beta'))
            C.CFUNCTYPE(None, P, P, P, P, P)(entry)(p, labels, mesh, materials, None)
        else:
            C.CFUNCTYPE(None, P, P)(entry)(p, None)
        assert not im.errors, (token, im.errors)
        state = snapshot(p, names[token])
        rows.append(dict(token=token, value=value, state=state, controlled_leaf_trace=list(trace)))
        if r['error'] or r['snapshot_error']:
            blockers.append(dict(token=token, value=value, status='ACTUAL_CLR_UNSUPPORTED_UNITY_BASE_OR_STATIC_INITIALIZATION', error=r['error'], snapshot_error=r['snapshot_error']))
        elif r['state'] != state:
            mismatches.append(dict(token=token, value=value, original=state, actual=r['state']))
    report = dict(scope='ORIGINAL_PC_29_CONSTRUCTOR_FIELD_STATES_WITH_EXPLICIT_CONTROLLED_LEAVES_VS_ACTUAL_DLL',
                  candidate_sha256=actual['candidate_sha256'], original_pc_sha256=hashlib.sha256(im.raw).hexdigest(),
                  original_callers_byte_verified=29, native_records=len(rows), comparable_records=len(rows) - len(blockers),
                  comparable_methods=len({r['token'] for r in actual['results'] if not r['error'] and not r['snapshot_error']}),
                  mismatches=mismatches, blockers=blockers, results=rows, metadata_slots=len(slots), callback_errors=im.errors,
                  controlled_leaves=['metadata resolution', 'object/array allocation', 'List constructor', 'GC barrier', 'Map constructor (only cameraSize compared)', 'MonoBehaviour base (native only, actual CLR unsupported)'],
                  limitations=['No allocation order observation on actual CLR', 'No memory exhaustion/GC/native exceptions/SEH', 'Unity base and Skill cctor failures retained', 'No player/IPA proof'])
    Path(sys.argv[1]).write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in report.items() if k not in ['results', 'blockers', 'mismatches']}, indent=2))
    print('mismatches', len(mismatches), 'blocked records', len(blockers))
    assert not mismatches
finally:
    im.close()
