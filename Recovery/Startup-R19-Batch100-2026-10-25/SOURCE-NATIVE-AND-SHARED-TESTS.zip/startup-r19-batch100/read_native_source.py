"""Read all pointer-bounded original bytes, including switch case islands.

This is explicitly a linear source listing, not a proof that data is code.
Jump-table case entries are documented separately by callers.
"""
import sys,json
import source_common as s
for arg in sys.argv[1:]:
    token=s.tok(int(arg,16));start=s.pointer(token)
    stop=min(s.pointer(s.tok(n)) for n in range(1,2318) if s.pointer(s.tok(n))>start)
    data=s.pc.get_data(start-s.base,stop-start)
    assert 0<len(data)<65536
    ins=[dict(va=hex(i.address),op=i.mnemonic,operands=i.op_str,bytes=i.bytes.hex()) for i in s.dis.disasm(data,start)]
    out=dict(token=token,entry=hex(start),bound=hex(stop),scope='LINEAR_ORIGINAL_SOURCE_CASE_ISLANDS_AND_EMBEDDED_DATA_NOT_ALL_BYTES_ARE_INSTRUCTIONS',raw_sha256=s.sha(data),raw_bytes=data.hex(),instructions=ins)
    d=s.Q/'native-source-linear';d.mkdir(exist_ok=True)
    (d/(token+'.json')).write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
    (d/(token+'.txt')).write_text('\n'.join(f"{i['va']} {i['op']} {i['operands']}" for i in ins)+'\n')
    print(token,'native bytes',len(data),'decoded',len(ins))
