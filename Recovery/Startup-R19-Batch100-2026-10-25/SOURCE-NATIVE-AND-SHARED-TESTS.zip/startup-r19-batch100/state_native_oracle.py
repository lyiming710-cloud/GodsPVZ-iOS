"""Ten original state callers, real round/CRT/max/clamp, controlled engine leaves.

Callers and math helpers are checked after every hook installation. No original
exception/SEH, engine internals, real GC, scheduling or NaN payload claim.
"""
from pathlib import Path
import ctypes as C,functools,hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
im=NativeImage();state={};ids=[0x265,0x268,0x2cf,0x368,0x369,0x381,0x428,0x42b,0x42c,0x499]
cfgs={rid:json.loads((Q/'native-source-complete'/f'0x{0x6000000|rid:08X}.json').read_bytes()) for rid in ids}
fields=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_bytes())
@functools.lru_cache(None)
def off(owner,name):
    rs=[r for r in fields if r['type']==owner and r['namespace']=='' and r['name']==name];assert len(rs)==1,(owner,name,rs);return rs[0]['offset']
def f(q,n,d=0):return struct.unpack('>f',bytes.fromhex(q[n]))[0] if n in q else d
def put8(p,v):C.c_ubyte.from_address(p).value=int(v)
def get8(p):return bool(C.c_ubyte.from_address(p).value)
def string(s):
    if s is None:return 0
    b=s.encode('utf-16-le');p=im.alloc(24+len(b));put32(p+0x10,len(b)//2);C.memmove(p+0x14,b,len(b));return p
def text(p):return None if not p else C.string_at(p+0x14,get32(p+0x10)*2).decode('utf-16-le')
def mode():return state['q']['mode']
def sf(owner,name,v):putf(state[owner]+off(owner,name),v)
def gf(owner,name):return getf(state[owner]+off(owner,name))
def si(owner,name,v):put32(state[owner]+off(owner,name),v)
def gi(owner,name):return get32(state[owner]+off(owner,name))
def sb(owner,name,v):put8(state[owner]+off(owner,name),v)
def gb(owner,name):return get8(state[owner]+off(owner,name))
def delta(method):
    assert not method;state['times']+=1;v=f(state['q'],'delta',.5);state['trace'].append('Delta:'+str(state['times'])+':'+bits(v))
    if mode()=='delta-fields':
        for n in ['waitingTime','livingTime','stiffnessTime','snowbeast_impactCD','shootingTime']:sf('Zombie',n,100)
        sf('Zombie','updateRate',10)
    if mode()=='delta-shooting':sf('Zombie','shootingTime',100)
    return v
def random(a,b,method):
    assert a==0 and b==1 and not method;v=f(state['q'],'random');state['trace'].append('Random:'+bits(v))
    if mode()=='random-max':sf('SunManager','sunFallTimeMax',-3)
    if mode()=='random-count':si('SunManager','sunFallCount',50)
    return v
def disabled(p,method):
    assert not method and p==state['Zombie'];v=state['q'].get('disabled',False);state['trace'].append('Disabled:'+str(int(v)));return v
def bool_leaf(p,method,key,label):
    assert not method and p==state['Zombie'];v=state['q'].get(key,False);state['trace'].append(label+':'+str(int(v)));return v
def void_leaf(p,method,label):
    assert not method and p==state['Zombie'];state['trace'].append(label)
    if label=='PlaceC4' and mode()=='place-countdown':sf('Zombie','ladderSaboteurs_detonationCountDown',.25)
def trigger(p,s,method):assert not method and p==state['animator'];state['trace'].append('Trigger:'+text(s))
def increment(p,value,key,method):
    assert not method and p==state['buff'];state['trace'].append('Increment:'+text(key)+':'+bits(value))
    if mode()=='increment-mutates':sf('Plant','armorPoint',99);sf('Plant','defensePoint',-99)
    return f(state['q'],'increment')
def settext(p,s,method):
    assert not method and p==state['text'];value=text(s);state['last_text']=value;state['trace'].append('Text:'+str(value))
    if mode()=='text-pauses':sb('Board','gamePause',True)
    if mode()=='text-speed':sf('Board','gameSpeed',9)
def scale(value,method):assert not method;state['scale']=value;state['trace'].append('TimeScale:'+bits(value))
def barrels(p,method):assert not method and p==state['Plant'];state['trace'].append('Barrels:'+bits(gf('Plant','pT_chomperviking_barrelsPoint')))
def snapshot(rid):
    if rid in [0x265,0x268]:return dict(max=bits(gf('SunManager','sunFallTimeMax')),count=gi('SunManager','sunFallCount'),once=bits(gf('SunManager','sunFallTimeOnce')),timer=bits(gf('SunManager','sunFallTime')))
    if rid==0x2cf:return dict(speed=bits(gf('Board','gameSpeed')),pause=gb('Board','gamePause'),detail=gb('Board','onDetailPage'),text=state['last_text'],scale=bits(state['scale']))
    if rid in [0x368,0x369,0x381]:return dict(armor=bits(gf('Plant','armorPoint')),defense=bits(gf('Plant','defensePoint')),barrels=bits(gf('Plant','pT_chomperviking_barrelsPoint')),devour=bits(gf('Plant','pT_chomperviking_devourPoint')),eating=gb('Plant','pC_chomperviking_devour'))
    return dict(living=bits(gf('Zombie','livingTime')),stiffness=bits(gf('Zombie','stiffnessTime')),impact=bits(gf('Zombie','snowbeast_impactCD')),waiting=bits(gf('Zombie','waitingTime')),shooting=bits(gf('Zombie','shootingTime')),rate=bits(gf('Zombie','updateRate')),countdown=bits(gf('Zombie','ladderSaboteurs_detonationCountDown')),placed=gb('Zombie','ladderZombie_place'),c4=gi('Zombie','ladderSaboteurs_C4'))
try:
    helpers=[json.loads((W/'startup-r13'/(n+'-HELPER-CFG.json')).read_bytes()) for n in ['ROUND','MODF','CEILF']]+[json.loads((Q/'CLAMP-HELPER-CFG.json').read_bytes())]
    # Math.Max(float,float) is a 24-byte leaf without a pdata entry.
    maxraw=im.pe.get_data(0xca5fc0,24);assert maxraw[-1]==0xc3
    meta=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/global-metadata.dat').read_bytes();assert hashlib.sha256(meta).hexdigest()=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9'
    so,sn,do,dn=struct.unpack_from('<4I',meta,8);dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True;slots=set()
    for cfg in list(cfgs.values())+helpers:
        for row in cfg['instructions']:
            i=next(dis.disasm(bytes.fromhex(row['bytes']),int(row['va'],16)))
            if i.mnemonic not in ['mov','lea']:continue
            for op in i.operands:
                if op.type!=X86_OP_MEM or op.mem.base!=X86_REG_RIP:continue
                at=i.address+i.size+op.mem.disp;raw=im.pe.get_data(at-im.base,8)
                if len(raw)!=8:continue
                code=int.from_bytes(raw,'little')
                if code>0xffffffff or code>>29 not in range(1,8):continue
                slots.add(at);kind,index=code>>29,(code&0x1fffffff)>>1
                if kind==5:n,pos=struct.unpack_from('<II',meta,so+8*index);put64(at,string(meta[do+pos:do+pos+n].decode('utf-8')))
                else:cls=im.class_slot(at);put64(get64(cls+0xb8),string(''))
    def init(at):assert at in slots,hex(at)
    im.hook(0x18024fef0,None,[P],init);im.hook(0x1802501e0,None,[P],lambda p:None)
    im.hook(0x18132c2f0,F,[P],delta);im.hook(0x18130d350,F,[F,F,P],random);im.hook(0x18132c500,None,[F,P],scale)
    im.hook(0x1803659e0,C.c_bool,[P,P],disabled);im.hook(0x180366030,C.c_bool,[P,P],lambda p,m:bool_leaf(p,m,'path_test','PathTest'));im.hook(0x180365ea0,C.c_bool,[P,P],lambda p,m:bool_leaf(p,m,'path_find','PathFind'))
    im.hook(0x18036a8c0,None,[P,P],lambda p,m:void_leaf(p,m,'Walk'));im.hook(0x180370890,None,[P,P],lambda p,m:void_leaf(p,m,'PlaceC4'));im.hook(0x1803705b0,None,[P,P],lambda p,m:void_leaf(p,m,'Boom'));im.hook(0x180370c70,C.c_bool,[P,P],lambda p,m:bool_leaf(p,m,'ladder_test','LadderTest'));im.hook(0x1812dbc00,None,[P,P,P],trigger)
    im.hook(0x180310420,F,[P,F,P,P],increment);im.hook(0x180352570,None,[P,P],barrels)
    def guarded_text(a,b,c):
        try:settext(a,b,c)
        except Exception as e:im.errors.append(dict(callback='TMP.text',error=repr(e)))
    text_cb=C.CFUNCTYPE(None,P,P,P)(guarded_text);im.callbacks.append(text_cb);text_entry=C.cast(text_cb,P).value
    for rid,cfg in cfgs.items():im.verify_caller(rid,int(cfg['entry'],16),cfg)
    for cfg in helpers:
        for i in cfg['instructions']:assert C.string_at(int(i['va'],16),len(bytes.fromhex(i['bytes'])))==bytes.fromhex(i['bytes'])
    assert C.string_at(0x180ca5fc0,len(maxraw))==maxraw
    rows=[]
    for q in json.loads((Q/'STATE-CASES.json').read_bytes()):
        state.clear();state.update(q=q,trace=[],times=0,scale=-7,last_text=None)
        for owner in ['SunManager','Board','Plant','Zombie']:state[owner]=im.alloc(2048)
        state['buff']=im.alloc(64);put64(state['Plant']+off('Plant','buffManager'),state['buff']);state['animator']=im.alloc(64);put64(state['Zombie']+off('Zombie','animator'),state['animator'])
        sf('SunManager','sunFallTimeMax',f(q,'max',8));si('SunManager','sunFallCount',q.get('count',0));sf('SunManager','sunFallTimeOnce',19);sf('SunManager','sunFallTime',23)
        sf('Board','gameSpeed',f(q,'speed',1));sb('Board','gamePause',q.get('pause',False));sb('Board','onDetailPage',q.get('detail',False))
        for field,key,default in [('livingTime','living',2),('stiffnessTime','stiffness',0),('snowbeast_impactCD','impact',0),('waitingTime','waiting',0),('shootingInterval','interval',1),('shootingTime','shooting',0),('updateRate','rate',1),('ladderSaboteurs_detonationCountDown','countdown',0)]:sf('Zombie',field,f(q,key,default))
        sb('Zombie','isStant',q.get('stant',False));sb('Zombie','ladderZombie_place',q.get('placed',False));si('Zombie','ladderSaboteurs_C4',q.get('c4',0))
        for field,key,default in [('armorPoint','value',0),('defensePoint','value',0),('pT_chomperviking_barrelsPoint','barrels',0),('pT_chomperviking_devourPoint','devour',0),('maxHealthPoint','health',10)]:sf('Plant',field,f(q,key,default))
        si('Plant','order',q.get('order',0));sb('Plant','pC_chomperviking_devour',True)
        state['text']=im.alloc(64);cls=im.alloc(2048);put64(state['text'],cls);put64(cls+0x558,text_entry)
        rid=int(q['token'],16)&0xffffff;entry=int(cfgs[rid]['entry'],16);result=None
        if rid in [0x265,0x368,0x369]:result=bits(C.CFUNCTYPE(F,P,P)(entry)(state['SunManager' if rid==0x265 else 'Plant'],None))
        elif rid==0x268:C.CFUNCTYPE(None,P,P)(entry)(state['SunManager'],None)
        elif rid==0x2cf:C.CFUNCTYPE(None,P,P,P)(entry)(state['Board'],state['text'],None)
        else:C.CFUNCTYPE(None,P,P)(entry)(state['Plant' if rid==0x381 else 'Zombie'],None)
        assert not im.errors,(q,im.errors);rows.append(dict(name=q['name'],token=q['token'],error=None,result=result,trace=list(state['trace']),state=snapshot(rid)))
    actual=json.loads(Path(sys.argv[1]).read_bytes());byname={r['name']:r for r in actual['results']};diff=[dict(original=r,actual=byname[r['name']]) for r in rows if r!=byname[r['name']]]
    report=dict(scope='TEN_ORIGINAL_STATE_CALLERS_AND_REAL_ROUND_CRT_CLAMP_MAX_VS_COMPLETE_CANDIDATE_CIL',candidate_sha256=actual['candidate_sha256'],original_pc_sha256=hashlib.sha256(im.raw).hexdigest(),caller_bytes_verified=10,records=len(rows),differences=diff,results=rows,callback_errors=im.errors,math_helpers_replaced=False,controlled_leaves=['Time.deltaTime/timeScale','Random.Range','Zombie disabled/path/C4/ladder leaves','Buff.GetIncrement','Animator trigger','TMP text setter','Plant.UpdateBarrels','metadata'],limitations=['No engine internals, null/native exceptions or SEH','No NaN payload equivalence','Controlled callback profiles do not prove universal equivalence','No Unity/player/IPA proof'])
    Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k not in ['differences','results']},indent=2));print('differences',len(diff));assert not diff
finally:im.close()
