"""Five byte-exact original callers with explicit string/array/math contracts.

The math leaf contract is host libm Pow/Exp, not original libm implementation
proof. All finite observed integer reward outputs are compared exactly.
"""
from pathlib import Path
import ctypes as C,functools,hashlib,json,math,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1]
sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
im=NativeImage();arrays={};cfgs={f'0x{0x6000000|r:08X}':json.loads((Q/'native-source-complete'/f'0x{0x6000000|r:08X}.json').read_bytes()) for r in [0x144,0x18f,0x4d0,0x609,0x257]}
fields=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_bytes())
@functools.lru_cache(None)
def off(owner,name):
    rs=[r for r in fields if r['type']==owner and r['namespace']=='' and r['name']==name];assert len(rs)==1,(owner,name,rs);return rs[0]['offset']
def string(s):
    if s is None:return 0
    b=s.encode('utf-16-le');p=im.alloc(24+len(b));put32(p+0x10,len(b)//2);C.memmove(p+0x14,b,len(b));return p
def text(p):return None if not p else C.string_at(p+0x14,get32(p+0x10)*2).decode('utf-16-le')
def array(cls,n):
    assert 0<=n<1000;p=im.alloc(32+8*n);put32(p+0x18,n);arrays[p]=n;return p
def barrier(at,value):assert get64(at)==(value or 0)
def pow_(a,b,method):
    assert not method
    try:return math.pow(a,b)
    except OverflowError:return math.inf
def exp_(a):
    try:return math.exp(a)
    except OverflowError:return math.inf
try:
    meta=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/global-metadata.dat').read_bytes();assert hashlib.sha256(meta).hexdigest()=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9'
    so,sn,do,dn=struct.unpack_from('<4I',meta,8);dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True;slots=set()
    for cfg in cfgs.values():
        for row in cfg['instructions']:
            i=next(dis.disasm(bytes.fromhex(row['bytes']),int(row['va'],16)))
            for op in i.operands:
                if op.type!=X86_OP_MEM or op.mem.base!=X86_REG_RIP:continue
                at=i.address+i.size+op.mem.disp;raw=im.pe.get_data(at-im.base,8)
                if len(raw)!=8:continue
                code=int.from_bytes(raw,'little')
                if code>0xffffffff or code>>29 not in range(1,8):continue
                kind,index=code>>29,(code&0x1fffffff)>>1;slots.add(at)
                if kind==5:n,pos=struct.unpack_from('<II',meta,so+8*index);put64(at,string(meta[do+pos:do+pos+n].decode('utf-8')))
                else:cls=im.class_slot(at);put64(get64(cls+0xb8),string(''))
    def init(at):assert at in slots,hex(at)
    im.hook(0x18024fef0,None,[P],init);im.hook(0x1802501e0,None,[P],lambda p:None);im.hook(0x180250100,P,[P],lambda cls:im.alloc(512));im.hook(0x18024f3e0,P,[P,C.c_size_t],array);im.hook(0x18024f360,None,[P,P],barrier)
    im.hook(0x180b7cc30,C.c_bool,[P,P,P],lambda a,b,m:text(a)!=text(b));im.hook(0x180b76170,C.c_bool,[P,P,P],lambda a,b,m:text(a)==text(b))
    im.hook(0x180ca60d0,C.c_double,[C.c_double,C.c_double,P],pow_);im.hook(0x1802cb340,C.c_double,[C.c_double],exp_)
    for token,cfg in cfgs.items():im.verify_caller(int(token,16)&0xffffff,int(cfg['entry'],16),cfg)
    rows=[]
    for q in json.loads((Q/'LEAF-CASES.json').read_bytes()):
        rid=int(q['token'],16)&0xffffff;entry=int(cfgs[q['token']]['entry'],16);p=im.alloc(512)
        if rid==0x144:state=text(C.CFUNCTYPE(P,I,P)(entry)(q['value'],None))
        elif rid==0x18f:state=C.CFUNCTYPE(I,I,P)(entry)(q['value'],None)
        elif rid==0x4d0:
            a=array(0,len(q['talents']))
            for k,v in enumerate(q['talents']):put64(a+0x20+8*k,string(v))
            put64(p+off('PlantSave','talentNames'),a);put32(p+off('PlantSave','stars'),q['stars']);state=C.CFUNCTYPE(I,P,I,P)(entry)(p,q['order'],None)
        elif rid==0x609:
            b=im.alloc(512);put32(b+off('BoardConfig','flagsNum'),q['flags']);put32(p+off('BoardEntry','boardEntryType'),q['entry_type']);put32(p+off('BoardEntry','level'),q['level']);put64(p+off('BoardEntry','key'),string(q['key']));result=C.CFUNCTYPE(P,P,P,P)(entry)(p,b,None)
            state={n:get32(result+off('Loot',n)) for n in ['suppliesID','quantity','frequency','maxQuantity','specialContent']};state['probability']=dict(f32=C.string_at(result+off('Loot','probability'),4)[::-1].hex().upper());state['firstPass']=bool(C.c_ubyte.from_address(result+off('Loot','firstPass')).value)
        elif rid==0x257:
            C.CFUNCTYPE(None,P,I,P)(entry)(p,q['value'],None);state={n:[get32(get64(p+off('PlantLevelUpSupplies',n))+0x20+4*k) for k in range(7)] for n in ['coins','supplies']}
        else:raise AssertionError(rid)
        assert not im.errors,im.errors;rows.append(dict(name=q['name'],token=q['token'],error=None,state=state))
    observed=json.loads(Path(sys.argv[1]).read_bytes());byname={r['name']:r for r in observed['results']};deltas=[dict(original=r,actual=byname[r['name']]) for r in rows if r!=byname[r['name']]]
    report=dict(scope='ORIGINAL_PC_FIVE_SCALAR_REWARD_CALLERS_VS_DIRECT_ACTUAL_DLL_FINITE_CASES',candidate_sha256=observed['candidate_sha256'],original_pc_sha256=hashlib.sha256(im.raw).hexdigest(),original_caller_bytes_checked=5,records=len(rows),per_method={token:sum(r['token']==token for r in rows) for token in cfgs},differences=deltas,results=rows,callback_errors=im.errors,controlled_leaves=['metadata','strings equality/inequality','object/array allocation','GC barrier','host libm Pow/Exp'],limitations=['Original libm implementation not executed','No exceptions/SEH/player/IPA proof'])
    Path(sys.argv[2]).write_text(json.dumps(report,indent=2,ensure_ascii=True)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k not in ['results','differences']},indent=2));print('differences',len(deltas));assert not deltas
finally:im.close()
