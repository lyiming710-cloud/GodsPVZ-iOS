using System.Reflection;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public class Sun{public float sunFallTimeMax,sunFallTimeOnce,sunFallTime;public int sunFallCount;}
public class Text{public string? Last;public string? text{set{Last=value;Program.Trace.Add("Text:"+value);if(Program.Mode=="text-pauses")Program.Board.gamePause=true;if(Program.Mode=="text-speed")Program.Board.gameSpeed=9;}}}
public class Board{public float gameSpeed;public bool gamePause,onDetailPage;}
public class Animator{public void SetTrigger(string s)=>Program.Trace.Add("Trigger:"+s);}
public class Zombie
{
    public bool isStant,ladderZombie_place;public float livingTime,stiffnessTime,snowbeast_impactCD,waitingTime,shootingInterval,shootingTime,updateRate,ladderSaboteurs_detonationCountDown;public int ladderSaboteurs_C4;public Animator? animator=new();
    public bool IsDisabled(){Program.Trace.Add("Disabled:"+(Program.B("disabled")?1:0));return Program.B("disabled");}
    public bool Path_Test(){Program.Trace.Add("PathTest:"+(Program.B("path_test")?1:0));return Program.B("path_test");}
    public bool Path_Finding(){Program.Trace.Add("PathFind:"+(Program.B("path_find")?1:0));return Program.B("path_find");}
    public void TranToWalk()=>Program.Trace.Add("Walk");
    public void ZC_LadderSaboteursPlaceC4(){Program.Trace.Add("PlaceC4");if(Program.Mode=="place-countdown")ladderSaboteurs_detonationCountDown=0.25f;}
    public void ZC_LadderSaboteursBoom()=>Program.Trace.Add("Boom");
    public bool ZC_LadderTestPlace(){Program.Trace.Add("LadderTest:"+(Program.B("ladder_test")?1:0));return Program.B("ladder_test");}
}
public class Buff
{
    public float GetIncrement(float value,string key){Program.Trace.Add("Increment:"+key+":"+Program.Bits(value));if(Program.Mode=="increment-mutates"){Program.Plant.armorPoint=99;Program.Plant.defensePoint=-99;}return Program.F("increment");}
}
public class Plant
{
    public float armorPoint,defensePoint,pT_chomperviking_barrelsPoint,pT_chomperviking_devourPoint,maxHealthPoint;public bool pC_chomperviking_devour;public int order;public Buff buffManager=new();
    public void PC_ChompervikingUpdateBarrels()=>Program.Trace.Add("Barrels:"+Program.Bits(pT_chomperviking_barrelsPoint));
}
public static class Program
{
    public static JsonElement Case;public static List<string> Trace=[];public static Sun Sun=null!;public static Board Board=null!;public static Zombie Zombie=null!;public static Plant Plant=null!;public static int Times;public static float TimeScale;
    public static string Mode=>Case.GetProperty("mode").GetString()!;
    public static bool B(string n,bool d=false)=>Case.TryGetProperty(n,out var v)?v.GetBoolean():d;
    public static int N(string n,int d=0)=>Case.TryGetProperty(n,out var v)?v.GetInt32():d;
    public static float F(string n,float d=0)=>Case.TryGetProperty(n,out var v)?BitConverter.UInt32BitsToSingle(Convert.ToUInt32(v.GetString(),16)):d;
    public static string Bits(float f)=>float.IsNaN(f)?"NaN":BitConverter.SingleToUInt32Bits(f).ToString("X8");
    public static float Range(float a,float b){if(a!=0||b!=1)throw new Exception("Range contract");float f=F("random");Trace.Add("Random:"+Bits(f));if(Mode=="random-max")Sun.sunFallTimeMax=-3;if(Mode=="random-count")Sun.sunFallCount=50;return f;}
    public static float Delta(){Times++;float f=F("delta",0.5f);Trace.Add("Delta:"+Times+":"+Bits(f));if(Mode=="delta-fields"){Zombie.waitingTime=100;Zombie.livingTime=100;Zombie.stiffnessTime=100;Zombie.snowbeast_impactCD=100;Zombie.shootingTime=100;Zombie.updateRate=10;}if(Mode=="delta-shooting")Zombie.shootingTime=100;return f;}
    public static void SetScale(float f){TimeScale=f;Trace.Add("TimeScale:"+Bits(f));}
    static Type Map(MC.TypeReference t)
    {
        if(t is MC.ByReferenceType b)return Map(b.ElementType).MakeByRefType();
        return t.FullName switch{"System.Void"=>typeof(void),"System.Boolean"=>typeof(bool),"System.Int32"=>typeof(int),"System.Int64"=>typeof(long),"System.Single"=>typeof(float),"System.Double"=>typeof(double),"System.String"=>typeof(string),"System.Object"=>typeof(object),"System.IntPtr"=>typeof(IntPtr),"System.Math"=>typeof(Math),"SunManager"=>typeof(Sun),"Board"=>typeof(Board),"Zombie"=>typeof(Zombie),"Plant"=>typeof(Plant),"BuffManager"=>typeof(Buff),"UnityEngine.Animator"=>typeof(Animator),"TMPro.TextMeshProUGUI" or "TMPro.TMP_Text"=>typeof(Text),_=>throw new NotSupportedException(t.FullName)};
    }
    static FieldInfo Field(MC.FieldReference f)=>Map(f.DeclaringType).GetField(f.Name)!;
    static MethodBase Method(MC.MethodReference m)
    {
        if(m.DeclaringType.FullName=="UnityEngine.Random")return typeof(Program).GetMethod(nameof(Range))!;
        if(m.DeclaringType.FullName=="UnityEngine.Time")return typeof(Program).GetMethod(m.Name=="get_deltaTime"?nameof(Delta):nameof(SetScale))!;
        return Map(m.DeclaringType).GetMethod(m.Name,BindingFlags.Public|BindingFlags.Instance|BindingFlags.Static,null,m.Parameters.Select(p=>Map(p.ParameterType)).ToArray(),null)!;
    }
    static object State(int rid,Text text)=>rid is 0x265 or 0x268?new{max=Bits(Sun.sunFallTimeMax),count=Sun.sunFallCount,once=Bits(Sun.sunFallTimeOnce),timer=Bits(Sun.sunFallTime)}:rid==0x2cf?new{speed=Bits(Board.gameSpeed),pause=Board.gamePause,detail=Board.onDetailPage,text=text.Last,scale=Bits(TimeScale)}:rid is 0x368 or 0x369 or 0x381?new{armor=Bits(Plant.armorPoint),defense=Bits(Plant.defensePoint),barrels=Bits(Plant.pT_chomperviking_barrelsPoint),devour=Bits(Plant.pT_chomperviking_devourPoint),eating=Plant.pC_chomperviking_devour}:new{living=Bits(Zombie.livingTime),stiffness=Bits(Zombie.stiffnessTime),impact=Bits(Zombie.snowbeast_impactCD),waiting=Bits(Zombie.waitingTime),shooting=Bits(Zombie.shootingTime),rate=Bits(Zombie.updateRate),countdown=Bits(Zombie.ladderSaboteurs_detonationCountDown),placed=Zombie.ladderZombie_place,c4=Zombie.ladderSaboteurs_C4};
    public static void Main(string[] args)
    {
        var resolver=new MC.DefaultAssemblyResolver();resolver.AddSearchDirectory(args[1]);using var asm=MC.AssemblyDefinition.ReadAssembly(args[0],new MC.ReaderParameters{AssemblyResolver=resolver});int[] ids={0x265,0x268,0x2cf,0x368,0x369,0x381,0x428,0x42b,0x42c,0x499};var code=ids.ToDictionary(r=>r,r=>ActualCil.Emit((MC.MethodDefinition)asm.MainModule.LookupToken(0x6000000|r),Map,Field,Method));using var cases=JsonDocument.Parse(File.ReadAllText(args[2]));var rows=new List<object>();
        foreach(var q in cases.RootElement.EnumerateArray())
        {
            Case=q;Trace.Clear();Times=0;TimeScale=-7;Sun=new(){sunFallTimeMax=F("max",8),sunFallCount=N("count"),sunFallTimeOnce=19,sunFallTime=23};Board=new(){gameSpeed=F("speed",1),gamePause=B("pause"),onDetailPage=B("detail")};Zombie=new(){isStant=B("stant"),ladderZombie_place=B("placed"),livingTime=F("living",2),stiffnessTime=F("stiffness"),snowbeast_impactCD=F("impact"),waitingTime=F("waiting"),shootingInterval=F("interval",1),shootingTime=F("shooting"),updateRate=F("rate",1),ladderSaboteurs_detonationCountDown=F("countdown"),ladderSaboteurs_C4=N("c4")};Plant=new(){armorPoint=F("value"),defensePoint=F("value"),pT_chomperviking_barrelsPoint=F("barrels"),pT_chomperviking_devourPoint=F("devour"),maxHealthPoint=F("health",10),pC_chomperviking_devour=true,order=N("order")};var text=new Text();int rid=Convert.ToInt32(q.GetProperty("token").GetString(),16)&0xffffff;object?[] call=rid==0x2cf?new object?[]{Board,text}:new object?[]{rid is 0x265 or 0x268?Sun:rid is 0x368 or 0x369 or 0x381?Plant:Zombie};string? error=null,result=null;
            try{object? value=code[rid].Invoke(null,call);if(value is float f)result=Bits(f);}catch(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;error=e.GetType().FullName;}
            rows.Add(new{name=q.GetProperty("name").GetString(),token=q.GetProperty("token").GetString(),error,result,trace=Trace.ToArray(),state=State(rid,text)});
        }
        File.WriteAllText(args[3],JsonSerializer.Serialize(new{scope="TEN_COMPLETE_ACTUAL_CANDIDATE_CIL_STATE_BODIES_CONTROLLED_ENGINE_LEAVES",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),methods=10,results=rows,eh_removed=false,private_access_bypass=false,unity_or_product_acceptance=false},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{records=rows.Count,methods=10}));
    }
}
