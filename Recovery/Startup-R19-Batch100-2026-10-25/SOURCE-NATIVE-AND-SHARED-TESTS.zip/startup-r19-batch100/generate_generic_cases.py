from pathlib import Path
import json,itertools
Q=Path(__file__).resolve().parent;cases=[]
def add(rid,**kw):
    q=dict(name='g'+str(len(cases)).zfill(4),token=f'0x{0x6000000|rid:08X}',source_length=3,source_size=2,dest_length=3,dest_size=1,argument=0,null_data=False,null_destination=False,alias=False,shared_array=False,native_supported=True)
    q.update(kw);cases.append(q)
for length in [0,1,3,5]:
    for size in range(length+1):
        for index in [-2147483648,-1,0,size-1,size,length,2147483647]:add(0x8eb,source_length=length,source_size=size,argument=index,native_supported=0<=index<size)
        for capacity in sorted({-1,size-1,size,size+1,size+4,length}):add(0x8ee,source_length=length,source_size=size,argument=capacity,native_supported=capacity>=size)
for rid in [0x8db,0x8dc,0x8f0]:
    for sl,dl in itertools.product([0,1,3,5],[0,1,3,5]):
        for ss,ds in itertools.product(sorted({0,sl}),sorted({0,dl})):add(rid,source_length=sl,source_size=ss,dest_length=dl,dest_size=ds)
    if rid!=0x8db:
        for length in [0,1,3,5]:
            for size in range(length+1):add(rid,source_length=length,source_size=size,dest_length=length,dest_size=size,alias=True)
        for ss,ds in [(0,3),(1,3),(3,1)]:add(rid,source_length=3,source_size=ss,dest_length=3,dest_size=ds,shared_array=True)
    add(rid,null_destination=True,native_supported=False)
for index in [-1,0,2]:add(0x8eb,null_data=True,argument=index,native_supported=False)
(Q/'GENERIC-CASES.json').write_bytes((json.dumps(cases,indent=2)+'\n').encode());print(json.dumps(dict(cases=len(cases),native_supported=sum(q['native_supported'] for q in cases))))
