"""Source reconstruction for frame displays, level setup and ice VFX."""
from construction import IL
from source_dispatch import constant,instruction
from source_tables import literal,rip_value
import source_common as s
def populate(c):
    for rid,shift in [(0x7b4,0),(0x7d2,0x5030)]:
        owner=s.methods[s.tok(rid)]['owner'];anchor=next(i for i in s.methods[s.tok(rid)]['instructions'] if i['opcode']=='call' and i['operand']['name']=='Set_FrameCounter_Position')
        b=IL().arg(0).token(0x7b,c.fld(owner,'AnchorPosition')).arg(0).token(0x7b,c.fld(owner,'last_AnchorPosition')).branch(0x3b,'anchored').arg(0).arg(0).token(0x7b,c.fld(owner,'AnchorPosition')).token(0x28,s.operand_token(s.tok(rid),anchor)).mark('anchored')
        b.arg(0).arg(0).token(0x7b,c.fld(owner,'m_Frames')).i4(1).op('58').token(0x7d,c.fld(owner,'m_Frames')).arg(0).arg(0).token(0x7b,c.fld(owner,'AnchorPosition')).token(0x7d,c.fld(owner,'last_AnchorPosition'))
        b.token(0x28,c.meth('UnityEngine.Time','get_realtimeSinceStartup')).store(3).loc(3).arg(0).token(0x7b,c.fld(owner,'m_LastInterval')).arg(0).token(0x7b,c.fld(owner,'UpdateInterval')).op('586b').branch(0x43,'done')
        b.arg(0).token(0x7b,c.fld(owner,'m_Frames')).op('6b').loc(3).arg(0).token(0x7b,c.fld(owner,'m_LastInterval')).op('596b5b6b').store(7)
        epsilon=constant(0x1803b6139+shift)
        b.loc(7).r4(epsilon).branch(0x3d,'use_fps').r4(epsilon).branch(0x38,'denominator').mark('use_fps').loc(7).mark('denominator').store(9).r4(1000).loc(9).op('5b6b').store(10)
        # Preserve the original native order, including its unusual color choices.
        b.r4(constant(0x1803b611e+shift)).loc(7).branch(0x3d,'color_a').r4(constant(0x1803b6148+shift)).loc(7).branch(0x3d,'color_b').branch(0x38,'color_c')
        for label,address in [('color_a',0x1803b617d),('color_b',0x1803b6169),('color_c',0x1803b6155)]:
            color=literal(rip_value(instruction(address+shift)))['value'];b.mark(label).arg(0).token(0x72,c.string(color)).token(0x7d,c.fld(owner,'htmlColorTag')).branch(0x38,'display')
        fmt=next(i['operand'] for i in s.methods[s.tok(rid)]['instructions'] if i['opcode']=='ldstr' and '{0:2}' in str(i['operand']))
        b.mark('display').arg(0).token(0x7b,c.fld(owner,'m_TextMeshPro')).arg(0).token(0x7b,c.fld(owner,'htmlColorTag')).token(0x72,c.text(rid,fmt)).token(0x28,c.meth('System.String','Concat',['System.String','System.String'])).loc(7).loc(10).token(0x6f,c.meth('TMPro.TMP_Text','SetText',['System.String','System.Single','System.Single']))
        b.arg(0).loc(3).token(0x7d,c.fld(owner,'m_LastInterval')).arg(0).i4(0).token(0x7d,c.fld(owner,'m_Frames')).mark('done').op('2a')
        c.add(rid,b,'Restore real native epsilon, FPS thresholds, original color branch order, float32 elapsed time and frame/text update order.',maxstack=4,group='frame-display')
    # Resolution property calls were completely lost from Test.Start.
    b=IL().token(0x28,c.meth('UnityEngine.Screen','get_currentResolution')).store(0)
    for local,name in [(1,'get_width'),(2,'get_height')]:b.loca(0).token(0x28,c.public_ref('UnityEngine.Resolution',name,bytes.fromhex('200008'))).store(local)
    b.loc(1).loc(2).i4(0).loca(0).token(0x28,c.meth('UnityEngine.Resolution','get_refreshRateRatio')).token(0x28,c.meth('UnityEngine.Screen','SetResolution',['System.Int32','System.Int32','UnityEngine.FullScreenMode','UnityEngine.RefreshRate']))
    b.i4(1280).i4(720).i4(3).token(0x28,c.meth('UnityEngine.Screen','SetResolution',['System.Int32','System.Int32','UnityEngine.FullScreenMode'])).op('2a')
    c.add(0x713,b,'Restore actual resolution width, height and refresh-rate reads before the two original SetResolution calls.',maxstack=4,group='lost-properties')
    # LevelItem: source null-throw condition, three challenge-specific sprite lists, tail refresh.
    b=IL().token(0x7e,c.fld('GlobalStaticVars','gLawnApp')).token(0x7b,c.fld('GlobalStaticVars/LawnApp','savesManager')).branch(0x3a,'manager').token(0x73,c.meth('System.NullReferenceException','.ctor')).op('7a').mark('manager').arg(0).arg(1).token(0x7d,c.fld('LevelItem','level'))
    b.arg(2).switch(['a','r','text','ba']).branch(0x38,'text')
    for label,offset in [('a',0x98),('r',0xa0),('ba',0xc0)]:
        b.mark(label).arg(0).token(0x7b,c.fld('LevelItem','image_inside')).token(0x7e,c.field_at('ResourceManager',offset)).arg(1).token(0x6f,c.meth('System.Collections.Generic.List`1<UnityEngine.Sprite>','get_Item',['System.Int32'])).token(0x6f,c.meth('UnityEngine.UI.Image','set_sprite',['UnityEngine.Sprite'])).branch(0x38,'text')
    refresh=next(int(t,16) for t in s.methods if s.pointer(t)==0x18039ee10)
    b.mark('text').arg(0).token(0x7b,c.fld('LevelItem','text_Name')).arg(3).i4(1).token(0x6f,c.meth('TMPro.TMP_Text','SetText',['System.String','System.Boolean'])).arg(0).token(0x28,refresh).op('2a')
    c.add(0x62b,b,'Restore original challenge dispatch, list/image receiver order, actual text argument, prerequisite native null throw and final refresh tail.',maxstack=3,group='lost-tail-and-dispatch')
    # ICE Update: ratio drives two repeated increment paths, or final Broken.
    owner='Device/ICEUIController';b=IL().r4(1).arg(1).arg(2).op('5b6b596b').store(11).r4(1).loc(11).r4(3).op('5a6b').branch(0x3d,'done')
    b.r4(2).loc(11).r4(3).op('5a6b').branch(0x3d,'level1').r4(1).loc(11).branch(0x3d,'level2').arg(0).arg(3).arg(4).token(0x28,c.meth(owner,'Broken',['Device','System.Boolean'])).branch(0x38,'done')
    for level,sprites in [(2,[5,4]),(1,[3,2])]:
        label='level'+str(level);b.mark(label).arg(0).token(0x7b,c.fld(owner,'brokenLevel')).i4(level).branch(0x3c,'done').mark('increment'+str(level)).arg(0).arg(0).token(0x7b,c.fld(owner,'brokenLevel')).i4(1).op('58').token(0x7d,c.fld(owner,'brokenLevel'))
        for k,sprite in enumerate(sprites):
            b.arg(0).token(0x7b,c.fld(owner,'spriteRenderer'+str(k))).token(0x7e,c.fld('ResourceManager','vfxSprites')).i4(sprite).token(0x6f,c.meth('System.Collections.Generic.List`1<UnityEngine.Sprite>','get_Item',['System.Int32'])).token(0x6f,c.meth('UnityEngine.SpriteRenderer','set_sprite',['UnityEngine.Sprite']))
        b.arg(4).branch(0x39,'after_effects'+str(level)).token(0x28,c.meth('ParticlesManager','get_instance')).i4(10).token(0x6f,c.meth('ParticlesManager','CreatNewParticle',['ParticleState'])).store(41).loc(41).token(0x28,c.meth('UnityEngine.Object','op_Implicit',['UnityEngine.Object'])).branch(0x39,'sound'+str(level))
        b.loc(41).token(0x6f,c.meth('UnityEngine.GameObject','get_transform')).arg(0).token(0x7b,c.fld(owner,'gameObject')).token(0x6f,c.meth('UnityEngine.GameObject','get_transform')).token(0x6f,c.meth('UnityEngine.Transform','get_position')).token(0x6f,c.meth('UnityEngine.Transform','set_position',['UnityEngine.Vector3']))
        b.mark('sound'+str(level)).token(0x7e,c.fld('ResourceManager','particleClips')).i4(13).token(0x6f,c.meth('System.Collections.Generic.List`1<UnityEngine.AudioClip>','get_Item',['System.Int32'])).token(0x28,c.meth('UnityEngine.Camera','get_main')).token(0x6f,c.meth('UnityEngine.Component','get_transform')).token(0x6f,c.meth('UnityEngine.Transform','get_position')).token(0x28,c.meth('GlobalStaticVars','AudioVolume')).token(0x28,c.meth('GlobalStaticVars','CreateAudioAtPoint',['UnityEngine.AudioClip','UnityEngine.Vector3','System.Single'])).op('26')
        b.mark('after_effects'+str(level)).arg(0).token(0x7b,c.fld(owner,'brokenLevel')).i4(level).branch(0x3f,'increment'+str(level)).branch(0x38,'done')
    b.mark('done').op('2a');c.add(0x342,b,'Restore actual Device and show-effects arguments, float32 ratio branches including NaN, repeated increment paths, singleton access and by-value Vector3 VFX/audio calls.',maxstack=4,group='lost-calls-and-arguments')
