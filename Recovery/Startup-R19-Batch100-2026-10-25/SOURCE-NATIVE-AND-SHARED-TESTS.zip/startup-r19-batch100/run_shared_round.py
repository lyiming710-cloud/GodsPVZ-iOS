"""Run the current finite suites concurrently; keep every raw report separate.

Successful subprocesses mean execution completed, not universal qualification.
Frozen unsupported entries and actual engine initialization blocks remain held.
"""
from pathlib import Path
import concurrent.futures,hashlib,json,subprocess,sys,time
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];stem=sys.argv[1]
candidate=Q/(stem+'.dll');report=json.loads((Q/(stem+'.json')).read_bytes());digest=hashlib.sha256(candidate.read_bytes()).hexdigest();assert report['candidate_sha256']==digest and report['new_unique_methods']==100 and (Q/'SHARED-TEST-START.json').exists()
P=Q/('shared-'+stem);P.mkdir(exist_ok=True);L=P/'driver-logs';L.mkdir(exist_ok=True)
dot=ROOT/'.local/dotnet10/dotnet.exe';support=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'
py=lambda name,*args:[sys.executable,str(Q/name),*[str(x) for x in args]]
fixture=lambda name,cases,out:[str(dot),str(Q/name/'bin/Release/net10.0/Fixture.dll'),str(candidate),str(support),str(cases),str(out)]
groups={
 'type-interface':[py('run_static.py',stem,'frozen'),py('supplement_interface_facts.py',stem)],
 'access-isolation':[py('run_static.py',stem,'member'),py('verify_isolation.py',stem)],
 'exact-jit':[py('run_exact_jit.py',stem)],
 'generics':[fixture('direct-generics',Q/'GENERIC-CASES.json',P/'DIRECT-GENERICS.json'),py('generic_native_oracle.py',P/'NATIVE-GENERICS.json'),py('compare_generics.py',stem),py('generic_revert_controls.py',stem)],
 'constructors':[fixture('direct-constructors',Q/(stem+'.json'),P/'DIRECT-CONSTRUCTORS.json'),py('constructor_native_oracle.py',P/'NATIVE-CONSTRUCTORS.json',stem)],
 'leaves':[fixture('direct-leaves',Q/'LEAF-CASES.json',P/'DIRECT-LEAVES.json'),py('leaf_native_oracle.py',P/'DIRECT-LEAVES.json',P/'NATIVE-LEAVES.json')],
 'phone':[fixture('runtime-phone',Q/'PHONE-CASES.json',P/'FULL-CIL-PHONE.json'),py('phone_native_oracle.py',P/'FULL-CIL-PHONE.json',P/'NATIVE-PHONE.json')],
 'state':[fixture('runtime-state',Q/'STATE-CASES.json',P/'FULL-CIL-STATE.json'),py('state_native_oracle.py',P/'FULL-CIL-STATE.json',P/'NATIVE-STATE.json')]
}
def one(pair):
 name,commands=pair;rows=[];start=time.monotonic()
 for k,args in enumerate(commands):
  run=subprocess.run(args,capture_output=True,timeout=180);(L/f'{name}-{k}.stdout.log').write_bytes(run.stdout);(L/f'{name}-{k}.stderr.log').write_bytes(run.stderr);rows.append(dict(argv=args,exit_code=run.returncode))
  if run.returncode:break
 result=dict(group=name,status='EXECUTION_COMPLETE_NOT_UNIVERSAL_PASS' if all(r['exit_code']==0 for r in rows) else 'SUBPROCESS_FAILED',seconds=round(time.monotonic()-start,3),commands=rows)
 print(json.dumps({k:v for k,v in result.items() if k!='commands'}),flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(one,groups.items()))
assert hashlib.sha256(candidate.read_bytes()).hexdigest()==digest
out=dict(scope='CURRENT_EXACT_HUNDRED_SHARED_FINITE_SUITES_EXECUTION_RECEIPT_NOT_PROMOTION',candidate_sha256=digest,groups=results,all_commands_completed=all(r['status']=='EXECUTION_COMPLETE_NOT_UNIVERSAL_PASS' for r in results),qualified_methods=0,ipa=None)
(P/'SHARED-EXECUTION-RECEIPT.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');assert out['all_commands_completed']
