using System.Reflection;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public class Phone{}
public static class Program
{
    public static List<string> Trace=[];
    public static void Log(object? x)=>Trace.Add("Log:"+x);
    static Type Map(MC.TypeReference t)
    {
        if(t is MC.ByReferenceType b)return Map(b.ElementType).MakeByRefType();
        return t.FullName switch{"System.Void"=>typeof(void),"System.String"=>typeof(string),"System.Int32"=>typeof(int),"System.Char"=>typeof(char),"System.Object"=>typeof(object),"TMPro.TMP_PhoneNumberValidator"=>typeof(Phone),_=>throw new NotSupportedException(t.FullName)};
    }
    static MethodBase Method(MC.MethodReference m)=>m.DeclaringType.FullName=="UnityEngine.Debug"&&m.Name=="Log"?typeof(Program).GetMethod(nameof(Log))!:Map(m.DeclaringType).GetMethod(m.Name,BindingFlags.Public|BindingFlags.Instance|BindingFlags.Static,null,m.Parameters.Select(p=>Map(p.ParameterType)).ToArray(),null)!;
    public static void Main(string[] args)
    {
        var resolver=new MC.DefaultAssemblyResolver();resolver.AddSearchDirectory(args[1]);using var a=MC.AssemblyDefinition.ReadAssembly(args[0],new MC.ReaderParameters{AssemblyResolver=resolver});var source=(MC.MethodDefinition)a.MainModule.LookupToken(0x06000728);var method=ActualCil.Emit(source,Map,f=>throw new NotSupportedException(f.FullName),Method);using var cases=JsonDocument.Parse(File.ReadAllText(args[2]));var rows=new List<object>();
        foreach(var q in cases.RootElement.EnumerateArray())
        {
            Trace.Clear();object?[] values={new Phone(),q.GetProperty("text").ValueKind==JsonValueKind.Null?null:q.GetProperty("text").GetString(),q.GetProperty("position").GetInt32(),(char)q.GetProperty("character").GetInt32()};string? error=null;int? result=null;
            try{result=(char)method.Invoke(null,values)!;}catch(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;error=e.GetType().FullName;}
            rows.Add(new{name=q.GetProperty("name").GetString(),error,result,text=values[1],position=values[2],trace=Trace.ToArray()});
        }
        File.WriteAllText(args[3],JsonSerializer.Serialize(new{scope="COMPLETE_CANDIDATE_CIL_PHONE_BODY_CONTROLLED_DEBUG_LEAF",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),token="0x06000728",instructions=source.Body.Instructions.Count,eh_removed=false,private_access_bypass=false,results=rows,unity_or_product_acceptance=false},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{records=rows.Count,instructions=source.Body.Instructions.Count}));
    }
}
