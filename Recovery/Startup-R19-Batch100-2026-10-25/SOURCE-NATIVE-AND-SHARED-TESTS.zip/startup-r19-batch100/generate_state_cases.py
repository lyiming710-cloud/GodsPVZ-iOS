from pathlib import Path
import itertools,json,struct
Q=Path(__file__).resolve().parent;rows=[]
def f(n):return struct.pack('>f',n).hex().upper()
vals=[f(-1),f(0),'80000000',f(0.25),f(1),f(5),'7F800000','FF800000','7FC00001']
def add(rid,**kw):
    q=dict(name='s'+str(len(rows)).zfill(5),token=f'0x{0x6000000|rid:08X}',mode='none',native_supported=True);q.update(kw);rows.append(q)
for rid in [0x265,0x268]:
    for m,c,r,mode in itertools.product(vals,[-2,0,3,2147483647],[f(0),f(.5),f(1),'7FC00001'],['none','random-max','random-count']):add(rid,max=m,count=c,random=r,**{'mode':mode})
for speed,pause,detail,mode in itertools.product([f(-1),f(0),f(1),f(1.5),f(2),f(2.5),f(3),'7F800000','7FC00001'],[False,True],[False,True],['none','text-pauses','text-speed']):add(0x2cf,speed=speed,pause=pause,detail=detail,**{'mode':mode})
for rid in [0x368,0x369]:
    numbers=vals+[f(x) for x in [-4.5,-3.5,-2.5,-1.5,-.5,.5,1.5,2.5,3.5,4.5,8388607,8388608]]+['3EFFFFFF','3F000001','BF000001','BEFFFFFF']
    for value,inc,mode in itertools.product(numbers,[f(0),f(.5),f(-.5),'7FC00001'],['none','increment-mutates']):add(rid,value=value,increment=inc,**{'mode':mode})
for order,barrels,devour,health in itertools.product([-1,0,1,2],vals,[f(-1),f(0),f(3),'7FC00001'],[f(0),f(5),'7F800000','7FC00001']):add(0x381,order=order,barrels=barrels,devour=devour,health=health)
for disabled,stant,waiting,pt,pf,delta,mode in itertools.product([False,True],[False,True],vals,[False,True],[False,True],[f(.25),f(1),'7FC00001'],['none','delta-fields']):add(0x428,disabled=disabled,stant=stant,waiting=waiting,path_test=pt,path_find=pf,delta=delta,**{'mode':mode})
for disabled,interval,shooting,rate,delta,mode in itertools.product([False,True],[f(-1),f(0),f(.5),f(1),'7FC00001'],[f(0),f(.5),f(1),'7FC00001'],[f(-1),f(0),f(1)],[f(.5),f(1),'7FC00001'],['none','delta-fields','delta-shooting']):add(0x42b,disabled=disabled,interval=interval,shooting=shooting,rate=rate,delta=delta,**{'mode':mode})
for living,stiffness,impact,delta,mode in itertools.product([f(0),'7FC00001'],vals,vals,[f(.25),f(1),'7FC00001'],['none','delta-fields']):add(0x42c,living=living,stiffness=stiffness,impact=impact,delta=delta,**{'mode':mode})
for disabled,c4,countdown,placed,test,delta,mode in itertools.product([False,True],[0,1],vals,[False,True],[False,True],[f(.25),f(1),'7FC00001'],['none','place-countdown','delta-fields']):add(0x499,disabled=disabled,c4=c4,countdown=countdown,placed=placed,ladder_test=test,delta=delta,**{'mode':mode})
(Q/'STATE-CASES.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print('state cases',len(rows))
