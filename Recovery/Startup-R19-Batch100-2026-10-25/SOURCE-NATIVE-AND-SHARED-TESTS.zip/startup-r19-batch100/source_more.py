"""Additional source-backed gameplay/UI restoration before the hundred gate."""
import json
from construction import IL
import source_common as s
def emit_round(b,c,value,integral,adjusted,done):
    b.loc(value).op('6c').token(0x28,c.meth('System.Math','Truncate',['System.Double'])).store(integral).loc(value).r4(0).op('fe05').branch(0x3a,'negative')
    b.loc(value).op('6c').loc(integral).op('59').r8(0.5).op('fe01').branch(0x3a,'positive_tie')
    b.loc(value).r4(0.5).op('586b').store(adjusted).loc(adjusted).op('6c').token(0x28,c.meth('System.Math','Floor',['System.Double'])).op('6b').branch(0x38,done)
    b.mark('positive_tie').loc(integral).op('6a').i8(1).op('5f').i8(0).op('fe01').branch(0x3a,'even').loc(integral).op('6b').r4(1).op('586b').branch(0x38,done)
    b.mark('negative').loc(value).op('6c').loc(integral).op('59').r8(-0.5).op('fe01').branch(0x3a,'negative_tie')
    b.loc(value).r4(0.5).op('596b').store(adjusted).loc(adjusted).op('6c').token(0x28,c.meth('System.Math','Ceiling',['System.Double'])).op('6b').branch(0x38,done)
    b.mark('negative_tie').loc(integral).op('6a').i8(1).op('5f').i8(0).op('fe01').branch(0x3a,'even').loc(integral).op('6b').r4(1).op('596b').branch(0x38,done).mark('even').loc(integral).op('6b').mark(done)
    return b
def populate(c):
    # The original speed button partitions around 1.5; comparisons are ordered.
    idx,sig=c.append_locals(0x2cf,[b'\x0c'])
    b=IL().arg(0).token(0x7b,c.fld('Board','gameSpeed')).store(idx).r4(1.5).loc(idx).branch(0x3c,'low').loc(idx).r4(2).branch(0x3b,'two').loc(idx).r4(2.5).branch(0x3b,'twohalf').branch(0x38,'time')
    b.mark('low').loc(idx).r4(1).branch(0x3b,'one').loc(idx).r4(1.5).branch(0x3b,'onehalf').branch(0x38,'time')
    for label,speed,text in [('two',2.5,'X2.5'),('twohalf',1,'X1'),('one',1.5,'X1.5'),('onehalf',2,'X2')]:
        b.mark(label).arg(0).r4(speed).token(0x7d,c.fld('Board','gameSpeed')).arg(1).token(0x72,c.text(0x2cf,text)).token(0x6f,c.meth('TMPro.TMP_Text','set_text',['System.String'])).branch(0x38,'time')
    b.mark('time').arg(0).token(0x7b,c.fld('Board','gamePause')).branch(0x3a,'done').arg(0).token(0x7b,c.fld('Board','onDetailPage')).branch(0x3a,'done').arg(0).token(0x7b,c.fld('Board','gameSpeed')).token(0x28,c.meth('UnityEngine.Time','set_timeScale',['System.Single'])).mark('done').op('2a')
    c.add(0x2cf,b,'Recover native speed cycling, ordered equality including NaN, text receiver calls and pause/detail-dependent timeScale update.',maxstack=2,local_token=sig,group='complete-state-machine')
    # Preview: native unsigned ID <= 2 and a count snapshot before any UI callback.
    o='Almanac_TalentSystem';b=IL().arg(0).arg(1).token(0x7d,c.fld(o,'previewID')).arg(0).token(0x7b,c.fld(o,'plantSave')).token(0x6f,c.meth('PlantSave','GetTalentNum_Unlocked')).store(2).arg(1).i4(2).branch(0x42,'default')
    b.i4(0).store(3).branch(0x38,'disable_test').mark('disable').arg(0).token(0x7b,c.fld(o,'buttons')).loc(3).token(0x6f,c.meth('System.Collections.Generic.List`1<UnityEngine.UI.Button>','get_Item',['System.Int32'])).i4(0).token(0x6f,c.meth('UnityEngine.Behaviour','set_enabled',['System.Boolean'])).loc(3).i4(1).op('58').store(3)
    b.mark('disable_test').loc(3).loc(2).branch(0x3f,'disable').arg(0).token(0x7b,c.fld(o,'talentDescription')).arg(0).token(0x7b,c.fld(o,'plantSave')).token(0x7b,c.fld('PlantSave','talents')).arg(1).op('9a').i4(1).token(0x6f,c.meth('TMPro.TMP_Text','SetText',['System.String','System.Boolean'])).op('2a')
    value=next(i['operand'] for i in s.methods[s.tok(0x599)]['instructions'] if i['opcode']=='ldstr' and not str(i['operand']).startswith('Unmanaged'))
    b.mark('default').arg(0).token(0x7b,c.fld(o,'talentDescription')).token(0x72,c.text(0x599,value)).i4(1).token(0x6f,c.meth('TMPro.TMP_Text','SetText',['System.String','System.Boolean'])).i4(0).store(4).branch(0x38,'enable_test')
    b.mark('enable').arg(0).token(0x7b,c.fld(o,'buttons')).loc(4).token(0x6f,c.meth('System.Collections.Generic.List`1<UnityEngine.UI.Button>','get_Item',['System.Int32'])).i4(1).token(0x6f,c.meth('UnityEngine.Behaviour','set_enabled',['System.Boolean']))
    b.arg(0).token(0x7b,c.fld(o,'select')).loc(4).token(0x6f,c.meth('System.Collections.Generic.List`1<System.Boolean>','get_Item',['System.Int32'])).branch(0x39,'next').arg(0).loc(4).token(0x28,c.meth(o,'UpdateTalentTexts',['System.Int32'])).mark('next').loc(4).i4(1).op('58').store(4).mark('enable_test').loc(4).loc(2).branch(0x3f,'enable').op('2a')
    c.add(0x599,b,'Restore original unsigned preview partitions, captured unlocked count, callback order and array exception behavior; remove fake metadata conditions.',maxstack=3,group='complete-state-machine')
    # Ladder C4 cooldown and placement are independent paths.
    b=IL().arg(0).token(0x7b,c.fld('Zombie','ladderSaboteurs_C4')).i4(0).branch(0x3e,'cooldown').arg(0).token(0x28,c.meth('Zombie','IsDisabled')).branch(0x3a,'cooldown').arg(0).token(0x28,c.meth('Zombie','ZC_LadderSaboteursPlaceC4'))
    b.mark('cooldown').arg(0).token(0x7b,c.fld('Zombie','ladderSaboteurs_detonationCountDown')).r4(0).branch(0x43,'placement').arg(0).token(0x28,c.meth('Zombie','IsDisabled')).branch(0x3a,'placement')
    b.arg(0).token(0x7b,c.fld('Zombie','updateRate')).store(10).arg(0).token(0x7b,c.fld('Zombie','ladderSaboteurs_detonationCountDown')).token(0x28,c.meth('UnityEngine.Time','get_deltaTime')).loc(10).op('5a6b596b').store(12).arg(0).loc(12).token(0x7d,c.fld('Zombie','ladderSaboteurs_detonationCountDown')).r4(0).loc(12).branch(0x44,'placement').arg(0).r4(0).token(0x7d,c.fld('Zombie','ladderSaboteurs_detonationCountDown')).arg(0).token(0x28,c.meth('Zombie','ZC_LadderSaboteursBoom'))
    b.mark('placement').arg(0).token(0x7b,c.fld('Zombie','ladderZombie_place')).branch(0x3a,'done').arg(0).token(0x28,c.meth('Zombie','ZC_LadderTestPlace')).branch(0x39,'done').arg(0).token(0x7b,c.fld('Zombie','animator')).arg(0).i4(1).token(0x7d,c.fld('Zombie','ladderZombie_place')).token(0x72,c.text(0x499,'PlaceTrigger')).token(0x6f,c.meth('UnityEngine.Animator','SetTrigger',['System.String'])).mark('done').op('2a')
    c.add(0x499,b,'Restore original independent C4, cooldown and ladder-placement paths, pre-Time captures and float32/NaN branches, retaining animator capture before state write.',maxstack=4,group='complete-state-machine')
    for rid,field,text in [(0x368,'armorPoint','Arm'),(0x369,'defensePoint','Def')]:
        idx,sig=c.append_locals(rid,[b'\x0d',b'\x0c']);b=IL().arg(0).token(0x7b,c.fld('Plant','buffManager')).arg(0).token(0x7b,c.fld('Plant',field)).op('25').store(6).token(0x72,c.text(rid,text)).token(0x6f,c.meth('BuffManager','GetIncrement',['System.Single','System.String'])).loc(6).op('586b').store(4)
        emit_round(b,c,4,idx,idx+1,'rounded').r4(0).token(0x28,c.meth('System.Math','Max',['System.Single','System.Single'])).op('2a')
        c.add(rid,b,'Restore missing shared native rounding helper using the R13 float32-half-neighbor algorithm, and capture base stat before BuffManager callback.',maxstack=4,local_token=sig,group='native-rounding')
    # Portal count was lost; use the same List<Int32>.Count contract and one manager capture.
    zfield=c.fld('Board','zombieManager');ztype=s.pe.net.mdtables.Field.rows[(zfield&0xffffff)-1].Signature.value[1:];idx,sig=c.append_locals(0x31a,[ztype])
    b=IL().arg(0).token(0x7b,c.fld('Device','board')).op('14').token(0x28,c.meth('UnityEngine.Object','op_Equality',['UnityEngine.Object','UnityEngine.Object'])).branch(0x3a,'done')
    b.arg(0).token(0x7b,c.fld('Device','board')).token(0x7b,c.fld('Board','enemyManager')).token(0x7b,c.field_at('EnemyManager',0x30)).store(3).loc(3).i4(0).loc(3).token(0x6f,c.meth('System.Collections.Generic.List`1<System.Int32>','get_Count')).token(0x28,c.meth('UnityEngine.Random','Range',['System.Int32','System.Int32'])).token(0x6f,c.meth('System.Collections.Generic.List`1<System.Int32>','get_Item',['System.Int32'])).store(5)
    b.arg(0).token(0x7b,c.fld('Device','board')).token(0x7b,zfield).store(idx).loc(idx).op('14').token(0x28,c.meth('UnityEngine.Object','op_Inequality',['UnityEngine.Object','UnityEngine.Object'])).branch(0x39,'done')
    b.loc(idx).loc(5).arg(0).token(0x7b,c.fld('Device','gridX')).arg(0).token(0x7b,c.fld('Device','gridY')).token(0x6f,c.meth('ZombieManager','PlaceNewZombie',['System.Int32','System.Int32','System.Int32'])).store(11).loc(11).token(0x28,c.meth('UnityEngine.Object','op_Implicit',['UnityEngine.Object'])).branch(0x39,'done')
    b.i4(0).loc(11).token(0x73,c.meth('Hide','.ctor',['System.Boolean','Zombie'])).store(12).loc(11).token(0x7b,c.fld('Zombie','buffManager')).loc(12).token(0x6f,c.meth('BuffManager','AddBuff',['Buff'])).mark('done').op('2a')
    c.add(0x31a,b,'Restore actual enemy-type list Count for Random, captured list and manager receivers, original Unity comparisons and Hide buff creation order.',maxstack=4,local_token=sig,group='lost-argument')
    # Chomper barrels use the real System.Math.Clamp Single overload.
    b=IL().arg(0).i4(0).token(0x7d,c.fld('Plant','pC_chomperviking_devour')).arg(0).token(0x7b,c.fld('Plant','order')).i4(1).branch(0x3f,'done')
    b.arg(0).token(0x7b,c.fld('Plant','pT_chomperviking_barrelsPoint')).arg(0).token(0x7b,c.fld('Plant','pT_chomperviking_devourPoint')).op('586b').store(5).arg(0).r4(0).token(0x7d,c.fld('Plant','pT_chomperviking_devourPoint')).arg(0).token(0x7b,c.fld('Plant','maxHealthPoint')).store(6).arg(0).loc(5).token(0x7d,c.fld('Plant','pT_chomperviking_barrelsPoint'))
    b.arg(0).loc(5).r4(0).loc(6).loc(6).op('586b').token(0x28,c.meth('System.Math','Clamp',['System.Single']*3)).token(0x7d,c.fld('Plant','pT_chomperviking_barrelsPoint')).arg(0).token(0x28,c.meth('Plant','PC_ChompervikingUpdateBarrels')).mark('done').op('2a')
    c.add(0x381,b,'Restore missing Math.Clamp and the native pre-clamp accumulator write; use twice maxHealthPoint rather than accumulator-plus-max.',maxstack=5,group='lost-call')
    # Clone once invokes the recovered real PlantSave constructor, not duplicate allocations.
    b=IL().token(0x73,c.meth('PlantSave','.ctor')).store(2)
    fields=['name','synopsis','description','characteristicText','plantType','stars','ID','clique','isUnlocked','order','level','skillLevel','sunPrice','replantCD','healthPoint','maxHealthPoint','attackPoint','armorPoint','defensePoint','attackInterva','characteristicTicking','characteristicMaxTicking']
    for name in fields:b.loc(2).arg(0).token(0x7b,c.fld('PlantSave',name)).token(0x7d,c.fld('PlantSave',name))
    for name in ['skill1','skill2','skill3']:b.loc(2).arg(0).token(0x7b,c.fld('PlantSave',name)).token(0x6f,c.meth('Skill','Copy')).token(0x7d,c.fld('PlantSave',name))
    for name in ['defaultSkillID','hormon','fashionSerialNumber']:b.loc(2).arg(0).token(0x7b,c.fld('PlantSave',name)).token(0x7d,c.fld('PlantSave',name))
    b.i4(0).store(7).mark('copy')
    for name in ['talentNames','talents']:
        # Load source element first: native faults on source before destination.
        b.arg(0).token(0x7b,c.fld('PlantSave',name)).loc(7).op('9a').store(0).loc(2).token(0x7b,c.fld('PlantSave',name)).loc(7).loc(0).op('74').emit((c.type('System.String')).to_bytes(4,'little')).op('a2')
    b.loc(7).i4(1).op('58').store(7).loc(7).i4(3).branch(0x3f,'copy').loc(2).op('2a')
    c.add(0x4ca,b,'Use one real PlantSave construction, original ordered scalar and Skill.Copy writes, then three ordered source-before-destination string-array element copies.',maxstack=3,group='lost-constructor')
