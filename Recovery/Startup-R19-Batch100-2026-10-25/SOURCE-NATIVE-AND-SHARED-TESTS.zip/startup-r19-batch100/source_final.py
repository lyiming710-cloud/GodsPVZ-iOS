"""The final three original-native source reconstructions in the R19 roster."""
import json
from construction import IL,labels
from source_dispatch import constant,instruction
from source_tables import literal,rip_value
import source_common as s
def populate(c):
    # Restore the lost foreach and its real finally, not a normal-path Dispose only.
    plant=next(k for k,r in enumerate(s.pe.net.mdtables.TypeDef.rows,1) if str(r.TypeName)=='PlantSave')
    en=next(k for k,r in enumerate(s.pe.net.mdtables.TypeRef.rows,1) if str(r.TypeName)=='Enumerator' and r.ResolutionScope.table.name=='TypeRef' and str(r.ResolutionScope.row.TypeName)=='List`1')
    enum_sig=b'\x15\x11'+labels.comp((en<<2)|1)+b'\x01\x12'+labels.comp(plant<<2)
    idx,sig=c.append_locals(0x6d,[enum_sig]);enum='System.Collections.Generic.List`1/Enumerator<PlantSave>'
    b=IL().token(0x7e,c.fld('GlobalStaticVars','gLawnApp')).token(0x7b,c.fld('GlobalStaticVars/LawnApp','savesManager')).store(1).loc(1).token(0x7b,c.fld('SavesManager','playerSave')).token(0x7b,c.fld('Save','plantSaves')).token(0x6f,c.meth('System.Collections.Generic.List`1<PlantSave>','GetEnumerator')).store(idx)
    b.mark('try').branch(0x38,'test').mark('loop').loc(1).loca(idx).token(0x28,c.meth(enum,'get_Current')).token(0x6f,c.meth('SavesManager','ReloadPlantSaveData',['PlantSave'])).mark('test').loca(idx).token(0x28,c.meth(enum,'MoveNext')).branch(0x3a,'loop').branch(0xdd,'after')
    b.mark('try_end').mark('finally').loca(idx).token(0x28,c.meth(enum,'Dispose')).op('dc').mark('finally_end').mark('after')
    message=next(i['operand'] for i in s.methods[s.tok(0x6d)]['instructions'] if i['opcode']=='ldstr' and not str(i['operand']).startswith('Method not found'))
    b.token(0x72,c.text(0x6d,message)).token(0x28,c.meth('UnityEngine.Debug','Log',['System.Object'])).op('2a')
    eh=[dict(kind='finally',try_start=b.labels['try'],try_end=b.labels['try_end'],handler_start=b.labels['finally'],handler_end=b.labels['finally_end'])]
    c.add(0x6d,b,'Restore one closed PlantSave enumerator, Current/MoveNext flow and real finally Dispose, then the original success log. Native unwind execution remains a separate gate.',maxstack=2,local_token=sig,new_eh=eh,group='lost-foreach')
    # Case zero's nonempty path joins the position-2 tail, not case one's
    # formatting body. The original loop visits case one separately.
    idx,sig=c.append_locals(0x728,[b'\x08',b'\x08',b'\x08']);length,index,limit=idx,idx+1,idx+2
    to_string=c.public_ref('System.Char','ToString',bytes.fromhex('20000e'))
    b=IL().token(0x72,c.text(0x728,'Trying to validate...')).token(0x28,c.meth('UnityEngine.Debug','Log',['System.Object'])).arg(1).op('50').token(0x6f,c.meth('System.String','get_Length')).store(length).loc(length).i4(1).op('58').store(limit).i4(0).store(index).branch(0x38,'loop_test').mark('loop').loc(index).switch(['p'+str(k) for k in range(14)]).branch(0x38,'next')
    def append(prefix=None,suffix=None,replace=False):
        b.arg(1)
        if replace:b.token(0x72,c.string(prefix))
        else:
            b.arg(1).op('50')
            if prefix is not None:b.token(0x72,c.string(prefix))
        b.addr(3).token(0x28,to_string)
        if suffix is not None:b.token(0x72,c.string(suffix))
        count=2+int(prefix is not None and not replace)+int(suffix is not None)
        b.token(0x28,c.meth('System.String','Concat',['System.String']*count)).op('51')
    def set_position(n):b.arg(2).i4(n).op('54').branch(0x38,'next')
    p0=literal(rip_value(instruction(0x1803b6331)))['value'];p3=literal(rip_value(instruction(0x1803b6405)))['value'];p4=literal(rip_value(instruction(0x1803b6461)))['value'];p5=literal(rip_value(instruction(0x1803b64a5)))['value'];dash=literal(rip_value(instruction(0x1803b6587)))['value']
    b.mark('p0').loc(length).branch(0x3a,'pos2');append(prefix=p0,replace=True);b.branch(0x38,'pos2')
    b.mark('p1').loc(length).i4(1).branch(0x40,'pos2');append();b.mark('pos2');set_position(2)
    for n,pos,prefix,suffix in [(2,3,None,None),(3,6,None,p3),(4,7,p4,None),(5,7,p5,None),(6,7,None,None),(7,8,None,None),(8,10,None,dash),(9,11,dash,None),(10,11,None,None),(11,12,None,None),(12,13,None,None),(13,14,None,None)]:
        b.mark('p'+str(n)).loc(length).i4(n).branch(0x40,'pos'+str(n)+'end');append(prefix=prefix,suffix=suffix);b.mark('pos'+str(n)+'end');set_position(pos)
    b.mark('next').loc(index).i4(1).op('58').store(index).mark('loop_test').loc(index).loc(limit).branch(0x3f,'loop').arg(3).op('2a')
    c.add(0x728,b,'Restore all fourteen native formatting cases, literal punctuation, original reference/position writes, loop bound and unchanged returned character; no invented digit filtering.',maxstack=5,local_token=sig,group='lost-formatting-body')
    # HeadDrop: armor, optional audio/particles, then head and blocking plant.
    def class_sig(name,value=False):
        token=c.type(name);assert token>>24 in [1,2];coded=((token&0xffffff)<<2)|(1 if token>>24==1 else 0)
        return bytes([0x11 if value else 0x12])+labels.comp(coded)
    idx,sig=c.append_locals(0x453,[class_sig('UnityEngine.AudioClip'),class_sig('UnityEngine.Vector3',True),b'\x08',b'\x0c',b'\x08',class_sig('UnityEngine.GameObject'),b'\x12'+labels.comp(next(k for k,r in enumerate(s.pe.net.mdtables.TypeDef.rows,1) if str(r.TypeName)=='Plant')<<2)])
    clip,pos,state,volume,ident,particle,plantlocal=range(idx,idx+7)
    b=IL().arg(0).token(0x7b,c.fld('Zombie','armor1Type')).branch(0x39,'armor_done').arg(0).arg(1).token(0x28,c.meth('Zombie','Drop_Armor1',['System.Boolean'])).mark('armor_done').arg(1).branch(0x3a,'hide')
    b.token(0x28,c.meth('GlobalStaticVars','AudioVolume')).store(volume).op('14').store(clip).token(0x28,c.meth('UnityEngine.Vector3','get_zero')).store(pos).i4(0).store(state).arg(0).token(0x7b,c.fld('Zombie','ID')).store(ident)
    b.loc(ident).switch(['common','common','common','other','common','common']).mark('other')
    for n in [14,15,1,10]:b.loc(ident).i4(n).branch(0x3b,'common')
    b.branch(0x38,'special')
    def select_head(particle_state,string_va):
        b.token(0x7e,c.field_at('ResourceManager',0x120)).i4(4).token(0x6f,c.meth('System.Collections.Generic.List`1<UnityEngine.AudioClip>','get_Item',['System.Int32'])).store(clip)
        b.arg(0).token(0x7b,c.fld('Zombie','animationSprites')).loc(volume).r4(constant(0x180361b5a)).op('5a6b').store(volume).token(0x72,c.string(literal(rip_value(instruction(string_va)))['value'])).token(0x28,c.meth('GlobalStaticVars','GetAnimationSpritePosition',['System.Collections.Generic.List`1<UnityEngine.GameObject>','System.String'])).store(pos).i4(particle_state).store(state)
    b.mark('common');select_head(39,0x180361c0d)
    b.mark('special').arg(0).token(0x7b,c.fld('Zombie','ID')).store(ident)
    for n,label in [(3,'pole'),(16,'ladder'),(23,'commander')]:b.loc(ident).i4(n).branch(0x3b,label)
    b.branch(0x38,'audio')
    for label,ps,va in [('pole',41,0x180361ca7),('ladder',40,0x180361d3b),('commander',42,0x180361dcf)]:b.mark(label);select_head(ps,va);b.branch(0x38,'audio')
    b.mark('audio').loc(clip).token(0x28,c.meth('UnityEngine.Object','op_Implicit',['UnityEngine.Object'])).branch(0x39,'particle').loc(clip).token(0x28,c.meth('UnityEngine.Camera','get_main')).token(0x6f,c.meth('UnityEngine.Component','get_transform')).token(0x6f,c.meth('UnityEngine.Transform','get_position')).loc(volume).token(0x28,c.meth('GlobalStaticVars','CreateAudioAtPoint',['UnityEngine.AudioClip','UnityEngine.Vector3','System.Single'])).op('26')
    b.mark('particle').loc(state).branch(0x39,'hide').token(0x28,c.meth('ParticlesManager','get_instance')).loc(state).token(0x6f,c.meth('ParticlesManager','CreatNewParticle',['ParticleState'])).store(particle).loc(particle).op('14').token(0x28,c.meth('UnityEngine.Object','op_Inequality',['UnityEngine.Object','UnityEngine.Object'])).branch(0x39,'hide').loc(particle).token(0x6f,c.meth('UnityEngine.GameObject','get_transform')).loc(pos).token(0x6f,c.meth('UnityEngine.Transform','set_position',['UnityEngine.Vector3']))
    component=next((token,i) for token,m in s.methods.items() for i in m['instructions'] if i['opcode'] in ['call','callvirt'] and i['operand']['owner']=='UnityEngine.GameObject' and i['operand']['name']=='GetComponent' and i['operand']['ret']=='UnityEngine.Rendering.SortingGroup')
    b.loc(particle).token(0x6f,s.operand_token(*component)).token(0x72,c.string('Particles')).token(0x6f,c.meth('UnityEngine.Rendering.SortingGroup','set_sortingLayerName',['System.String']))
    b.mark('hide').arg(0).token(0x7b,c.field_at('Zombie',0x1a8)).i4(0).token(0x6f,c.meth('UnityEngine.GameObject','SetActive',['System.Boolean'])).arg(0).token(0x7b,c.field_at('Zombie',0x170)).store(plantlocal).loc(plantlocal).branch(0x39,'done').loc(plantlocal).arg(0).i4(0).token(0x6f,c.meth('Plant','BlockZombie',['Zombie','System.Boolean'])).mark('done').op('2a')
    c.add(0x453,b,'Restore armor call, original ID groups and later ID reload, audio-volume scaling, sprite-bound head positions, particles/sorting group, unconditional head hide and optional blocking-plant callback.',maxstack=4,local_token=sig,group='lost-head-drop-body')
