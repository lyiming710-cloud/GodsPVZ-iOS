"""Build the complete R19 hundred before executing any shared test suite."""
import sys
from construction import Context
import source_constructors,source_dispatch,source_numeric,source_access,source_more,source_views,source_generics,source_rules,source_projectiles,source_final
def build(stem):
    c=Context()
    for module in [source_constructors,source_dispatch,source_numeric,source_access,source_more,source_views,source_generics,source_rules,source_projectiles,source_final]:module.populate(c)
    assert len(c.bodies)==100
    c.save(stem)
if __name__=='__main__':build(sys.argv[1])
