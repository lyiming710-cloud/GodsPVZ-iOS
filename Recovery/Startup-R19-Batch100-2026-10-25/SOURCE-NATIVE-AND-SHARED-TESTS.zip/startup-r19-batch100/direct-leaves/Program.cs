using System.Reflection;using System.Runtime.CompilerServices;using System.Runtime.Loader;using System.Security.Cryptography;using System.Text.Json;
public static class Program
{
    const BindingFlags BF=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance|BindingFlags.Static;
    static Assembly Game=null!;
    static object Blank(string name)=>RuntimeHelpers.GetUninitializedObject(Game.GetType(name,true)!);
    static FieldInfo F(object o,string n)=>o.GetType().GetField(n,BF)!;
    static void Set(object o,string n,object? value){var f=F(o,n);f.SetValue(o,f.FieldType.IsEnum?Enum.ToObject(f.FieldType,value!):value);}
    static Exception Root(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;return e;}
    static object? Scalar(object? v)=>v is float f?new{f32=BitConverter.SingleToUInt32Bits(f).ToString("X8")}:v;
    static int N(JsonElement q,string name)=>q.GetProperty(name).GetInt32();
    public static void Main(string[] args)
    {
        string file=Path.GetFullPath(args[0]),support=Path.GetFullPath(args[1]);var alc=new AssemblyLoadContext("ExactR19Leaves_"+Guid.NewGuid(),true);
        alc.Resolving+=(c,n)=>{foreach(string ext in new[]{".dll",".exe"}){string path=Path.Combine(support,n.Name+ext);if(!File.Exists(path))continue;if(AssemblyName.GetAssemblyName(path).FullName!=n.FullName)throw new FileLoadException("Identity mismatch "+path);return c.LoadFromAssemblyPath(path);}return null;};
        Game=alc.LoadFromAssemblyPath(file);using var cases=JsonDocument.Parse(File.ReadAllText(args[2]));var rows=new List<object>();
        foreach(var q in cases.RootElement.EnumerateArray())
        {
            string name=q.GetProperty("name").GetString()!,token=q.GetProperty("token").GetString()!;int rid=Convert.ToInt32(token,16)&0xffffff;string? error=null;object? state=null;
            try
            {
                var m=Game.ManifestModule.ResolveMethod(Convert.ToInt32(token,16))!;
                if(rid is 0x144 or 0x18f)state=((MethodInfo)m).Invoke(null,new object?[]{N(q,"value")});
                else if(rid==0x4d0){object p=Blank("PlantSave");Set(p,"stars",N(q,"stars"));Set(p,"talentNames",q.GetProperty("talents").EnumerateArray().Select(x=>x.ValueKind==JsonValueKind.Null?null:x.GetString()).ToArray());state=((MethodInfo)m).Invoke(p,new object?[]{N(q,"order")});}
                else if(rid==0x609){object p=Blank("BoardEntry"),b=Blank("BoardConfig");Set(p,"boardEntryType",N(q,"entry_type"));Set(p,"level",N(q,"level"));Set(p,"key",q.GetProperty("key").ValueKind==JsonValueKind.Null?null:q.GetProperty("key").GetString());Set(b,"flagsNum",N(q,"flags"));object result=((MethodInfo)m).Invoke(p,new[]{b})!;state=result.GetType().GetFields(BF|BindingFlags.DeclaredOnly).Where(f=>!f.IsStatic).OrderBy(f=>f.MetadataToken).ToDictionary(f=>f.Name,f=>Scalar(f.GetValue(result)));}
                else if(rid==0x257){object result=((ConstructorInfo)m).Invoke(new object?[]{N(q,"value")});state=new{coins=F(result,"coins").GetValue(result),supplies=F(result,"supplies").GetValue(result)};}
                else throw new NotSupportedException(token);
            }
            catch(Exception e){error=Root(e).ToString();}
            rows.Add(new{name,token,error,state});
        }
        File.WriteAllText(args[3],JsonSerializer.Serialize(new{scope="DIRECT_UNMODIFIED_ACTUAL_DLL_FIVE_SCALAR_AND_REWARD_METHODS",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(file))).ToLowerInvariant(),reflection_emit_used=false,cil_rewritten=false,results=rows,unity_execution=false},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{records=rows.Count,methods=5}));
    }
}
