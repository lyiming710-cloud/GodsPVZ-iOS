"""Restore original closed Projectile.Initial calls from native stack arguments."""
from construction import IL
from source_dispatch import constant
import source_common as s
V='UnityEngine.Vector3';F='System.Single'
def reassemble(token,patches,original=None):
    m=s.methods[token];assert not m['handlers']
    old=original if original is not None else s.body(token)['code'];ins=m['instructions'];b=IL();skip=set()
    for start,(end,new) in patches.items():
        assert start<end and any(i['offset']==start for i in ins)
        skip.update(i['offset'] for i in ins if start<i['offset']<end)
    for k,i in enumerate(ins):
        at=i['offset']
        if at in skip:continue
        b.mark('old'+str(at))
        if at in patches:b.emit(patches[at][1]);continue
        end=ins[k+1]['offset'] if k+1<len(ins) else len(old);op=i['opcode'];v=i['operand']
        if isinstance(v,dict) and 'target' in v:
            assert v['target'] not in skip,(token,i)
            opcode=old[at]
            if 0x2b<=opcode<=0x37:opcode+=0xd
            if opcode==0xde:opcode=0xdd
            assert opcode in range(0x38,0x45) or opcode==0xdd,(token,i)
            b.branch(opcode,'old'+str(v['target']))
        elif op=='switch':
            assert all(t not in skip for t in v['targets']);b.switch(['old'+str(t) for t in v['targets']])
        else:b.emit(old[at:end])
    return b.finish()
def populate(c):
    ctor=c.meth(V,'.ctor',[F,F,F]);zero=c.meth(V,'get_zero')
    def vector(b,x,y=0,z=0):
        for v in [x,y,z]:
            if callable(v):v(b)
            else:b.r4(v)
        return b.token(0x73,ctor)
    specs={
      0xba:[(8,7,constant(0x180306c0b),constant(0x180306c2d),4,'Plant')],
      0x37e:[(7,None,0,constant(0x1803522c4),0,'Plant')],
      0x3ae:[(5,7,constant(0x180358207),constant(0x18035822b),0,'Plant')],
      0x49b:[(3,None,0,constant(0x18037098d),0,'Zombie')],
      0x4a2:[(2,5,None,constant(0x18037142a),1,'Zombie')],
      0x504:[(9,10,constant(0x180383a67),constant(0x180383a4d),0,'Plant'),(16,17,constant(0x180383bd0),constant(0x180383a4d),0,'Plant')],
      0x3a8:[(33,35,constant(0x180359985),constant(0x1803599a9),0,'Plant')],
    }
    for rid,rows in specs.items():
        token=s.tok(rid);m=s.methods[token];holes=[(k,i) for k,i in enumerate(m['instructions']) if i['opcode']=='ldstr' and str(i['operand']).startswith('Method not found @1804A2')]
        assert len(holes)==len(rows),(token,holes,rows);patches={}
        for index,((k,i),row) in enumerate(zip(holes,rows)):
            projectile,position,speed,duration,track,owner=row;b=IL()
            if rid==0xba:
                # Original x adjustment precedes Initial; preserve the captured y/z.
                b.loca(position).loc(position).token(0x7b,c.fld(V,'x')).r4(constant(0x180306ba7)).op('586b').token(0x7d,c.fld(V,'x'))
            b.loc(projectile)
            if position is not None:b.loc(position)
            else:
                arg=1 if rid==0x37e else 0
                vector(b,lambda q:q.arg(arg).token(0x7b,c.fld('Zombie','fX')),lambda q:q.arg(arg).token(0x7b,c.fld('Zombie','fY')).r4(20).op('586b'),0)
            if rid==0x4a2:
                b.arg(0).token(0x7b,c.field_at('Zombie',0x13c)).r4(constant(0x1803713b0)).token(0x28,c.meth(V,'op_Multiply',[V,F]))
            elif speed==0:b.token(0x28,zero)
            else:vector(b,speed)
            b.token(0x28,zero).r4(duration)
            if rid==0x4a2:b.r4(constant(0x180371455))
            elif rid==0x504:b.r4(0)
            b.i4(track)
            if rid==0x504:b.r4(0).r4(constant(0x180383a93 if index==0 else 0x180383c02)).r4(0)
            if rid==0xba:b.arg(0).token(0x7b,c.fld('PlantAnimationEvent','plant'))
            else:b.arg(0)
            args=[V,V,V,F]+([F] if rid in [0x4a2,0x504] else [])+['System.Int32']+([F,F,F] if rid==0x504 else [])+[owner]
            definition={6:0x3ed,7:0x3ee,10:0x3ef}[len(args)]
            assert s.methods[s.tok(definition)]['args'][:-1]+[owner]==args
            b.token(0x6f,c.generic_spec(definition,owner));nxt=m['instructions'][k+1];assert nxt['opcode']=='pop'
            patches[i['offset']]=(nxt['offset']+1,b.finish())
        previous=c.bodies.get(token);code=reassemble(token,patches,previous['code'] if previous else None)
        reason='Restore original Projectile.Initial<T> MethodSpec and all Vector3/scalar/owner operands from the native ABI, rebuilding branch displacements rather than relying on old offsets.'
        if previous:
            previous['code']=code;previous['maxstack']=max(previous['maxstack'],11);previous['reason']+=' '+reason
        else:c.add(rid,code,reason,maxstack=11,group='lost-projectile-initialization')
