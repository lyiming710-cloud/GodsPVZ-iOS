"""Reject warning-only methods whose behavior is already recovered."""
from pathlib import Path
import json
Q=Path(__file__).resolve().parent;before=json.loads((Q/'SOURCE-INVENTORY.json').read_bytes())
assert not (Q/'SOURCE-INVENTORY-INITIAL.json').exists();(Q/'SOURCE-INVENTORY-INITIAL.json').write_bytes((Q/'SOURCE-INVENTORY.json').read_bytes())
excluded=[r for r in before['source_targets'] if r['group']=='ITERATOR_RESET_EXCEPTION'];assert len(excluded)==17
for r in excluded:
    m=json.loads((Q/(r['token']+'.parent-cil.json')).read_bytes());assert any(i['opcode']=='newobj' and i['operand']['owner']=='System.NotSupportedException' for i in m['instructions']) and any(i['opcode']=='throw' for i in m['instructions'])
    r['reason']='Existing complete CIL already creates and throws NotSupportedException; diagnostic strings/dead tails alone are not a new repair.';r['status']='EXCLUDED_ALREADY_BEHAVIORALLY_RECOVERED'
rows=[r for r in before['source_targets'] if r not in excluded]
allcil=json.loads((Q.parent/'startup-r18-batch50/ALL-CIL.json').read_bytes());methods={m['token']:m for m in allcil['methods']}
extra=[0x6f,0x333,0x3a5,0x3e4,0x578,0x579,0x584,0x5cf,0x626,0x70f,0x762,0x315,0x319,0x30a,0x423,0x48d,0x3ab]
for rid in extra:
    token=f'0x{0x6000000|rid:08X}';m=methods[token];rows.append(dict(token=token,name=m['name'],group='NATIVE_ACCESS_AND_NUMERIC_CALL_CHAIN_RECONSTRUCTION',instructions=len(m['instructions']),status='SOURCE_REVIEW_NOT_CONSTRUCTED'))
assert len(rows)==len({r['token'] for r in rows})==100
before['source_targets']=rows;before['excluded_warning_only_methods']=excluded
(Q/'SOURCE-INVENTORY.json').write_bytes((json.dumps(before,indent=2)+'\n').encode());print(json.dumps(dict(source_targets=100,already_correct_excluded=17,constructed=0,tests_run=False)))
