from pathlib import Path
import itertools,json
Q=Path(__file__).resolve().parent;rows=[]
for text,pos,ch in itertools.product(['x'*n for n in range(31)]+['(123) 456-7890','abc','中文'],[-1,0,7,2147483647],[0,ord('5'),ord('A'),0x4e2d]):rows.append(dict(name='p'+str(len(rows)).zfill(4),text=text,position=pos,character=ch,native_supported=True))
for ch in [0,ord('A')]:rows.append(dict(name='p'+str(len(rows)).zfill(4),text=None,position=7,character=ch,native_supported=False))
(Q/'PHONE-CASES.json').write_text(json.dumps(rows,indent=2,ensure_ascii=True)+'\n',encoding='utf-8');print('phone cases',len(rows))
