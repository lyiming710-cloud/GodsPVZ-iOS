"""Original reference-type generic callers, with explicit array/GC contracts.

No exception or Windows SEH emulation. Only normal cases marked supported run.
The five callers and the original AssignTo(List<T>) dependency remain byte exact.
"""
from pathlib import Path
import ctypes as C, hashlib, json, struct, sys

Q = Path(__file__).resolve().parent
W = Q.parent
sys.path.insert(0, str(W / 'startup-r5'))
from native_runtime_common import NativeImage, P, I, get32, get64, put32, put64

ENTRY = {0x8db: 0x1809d3520, 0x8dc: 0x1809d3550, 0x8eb: 0x1809d5cb0,
         0x8ee: 0x1809d5a00, 0x8f0: 0x1809d4890}
im = NativeImage()
arrays = {}
labels = {0: None}
calls = []


def array(n, start=None):
    assert 0 <= n < 1000, n
    p = im.alloc(32 + 8 * n)
    put32(p + 0x18, n)
    arrays[p] = n
    for k in range(n):
        if start is not None:
            v = im.alloc(16)
            labels[v] = 'v' + str(start + k)
            put64(p + 0x20 + 8 * k, v)
    return p


def values(p):
    if not p:
        return None
    assert p in arrays
    return [labels[get64(p + 0x20 + k * 8)] for k in range(arrays[p])]


def new_array(cls, n):
    assert cls == array_class
    calls.append(['ArrayNew', n])
    return array(n)


def clear(p, index, count, method):
    assert not method and p in arrays and 0 <= index <= arrays[p] and 0 <= count <= arrays[p] - index
    calls.append(['ArrayClear', index, count])
    C.memset(p + 0x20 + 8 * index, 0, 8 * count)


def copy(a, b, count, method):
    assert not method and a in arrays and b in arrays and 0 <= count <= min(arrays[a], arrays[b])
    calls.append(['ArrayCopy', count])
    C.memmove(b + 0x20, a + 0x20, 8 * count)


def capacity(p, method):
    a = get64(p + 0x10)
    assert a in arrays
    return arrays[a]


def set_capacity(p, n, method):
    a = get64(p + 0x10)
    count = get32(p + 0x18)
    assert a in arrays and n >= count
    b = array(n)
    C.memmove(b + 0x20, a + 0x20, 8 * count)
    put64(p + 0x10, b)
    calls.append(['ListCapacity', n])


def barrier(at, value):
    assert get64(at) == (value or 0)


try:
    array_class = im.alloc(512)
    C.c_ubyte.from_address(array_class + 0x135).value = 1
    empty_class = im.alloc(512)
    C.c_ubyte.from_address(empty_class + 0x135).value = 1
    put32(empty_class + 0xe0, 1)
    static = im.alloc(128)
    put64(empty_class + 0xb8, static)
    put64(static, array(0))
    list_mi, list_rgctx, list_context = [im.alloc(512) for _ in range(3)]
    put64(list_mi + 0x20, list_rgctx)
    put64(list_rgctx + 0xc0, list_context)
    put64(list_context + 0x10, empty_class)
    put64(list_context + 0x18, array_class)
    assoc_mi, assoc_rgctx, assoc_context = [im.alloc(512) for _ in range(3)]
    put64(assoc_mi + 0x20, assoc_rgctx)
    put64(assoc_rgctx + 0xc0, assoc_context)
    put64(assoc_context + 0xd0, list_mi)
    put64(assoc_context + 0xd8, list_mi)
    im.hook(0x18024f360, None, [P, P], barrier)
    im.hook(0x18024f3e0, P, [P, C.c_size_t], new_array)
    im.hook(0x180cb86f0, None, [P, I, I, P], clear)
    im.hook(0x180cb8c90, None, [P, P, I, P], copy)
    im.hook(0x18065baa0, I, [P, P], capacity)
    im.hook(0x180805920, None, [P, I, P], set_capacity)
    bound = []
    for rid, entry in ENTRY.items():
        evidence = json.loads((Q / 'native-source-complete' / f'0x{0x6000000 | rid:08X}.json').read_bytes())
        variant = next(v for v in evidence['variants'] if int(v['binding']['va'], 16) == entry)
        raw = bytes.fromhex(variant['raw_bytes'])
        assert variant['binding']['class_args'] == ['object']
        assert hashlib.sha256(raw).hexdigest() == variant['raw_sha256']
        assert im.pe.get_data(entry - im.base, len(raw)) == raw
        assert C.string_at(entry, len(raw)) == raw
        bound.append(dict(token=f'0x{0x6000000 | rid:08X}', entry=hex(entry), sha256=variant['raw_sha256']))
    # This existing, uncounted dependency is entered by the first wrapper.
    dep = im.pe.get_data(0x9d4710, 0x180)
    assert C.string_at(0x1809d4710, len(dep)) == dep
    bound.append(dict(token='0x060008EF', entry='0x1809d4710', scope='UNCOUNTED_UNMODIFIED_DEPENDENCY', sha256=hashlib.sha256(dep).hexdigest()))
    rows = []
    for q in json.loads((Q / 'GENERIC-CASES.json').read_bytes()):
        if not q['native_supported']:
            continue
        calls.clear()
        rid = int(q['token'], 16) & 0xffffff
        sa = array(q['source_length'], 0)
        da = sa if q['shared_array'] else array(q['dest_length'], 20)
        source, dest = im.alloc(64), im.alloc(64)
        put64(source + 0x10, sa)
        put32(source + 0x18, q['source_size'])
        put64(dest + 0x10, da)
        put32(dest + 0x18, q['dest_size'])
        put32(dest + 0x1c, 7)
        if q['alias']:
            dest = source
        receiver = source
        mi = list_mi
        if rid in [0x8db, 0x8dc]:
            receiver = im.alloc(64)
            put64(receiver + 0x10, source)
            mi = assoc_mi
        if rid == 0x8eb:
            v = im.alloc(16)
            labels[v] = 'v99'
            C.CFUNCTYPE(None, P, I, P, P)(ENTRY[rid])(receiver, q['argument'], v, mi)
        elif rid == 0x8ee:
            C.CFUNCTYPE(None, P, I, P)(ENTRY[rid])(receiver, q['argument'], mi)
        else:
            C.CFUNCTYPE(None, P, P, P)(ENTRY[rid])(receiver, dest, mi)
        assert not im.errors, im.errors
        source_data, dest_data = get64(source + 0x10), get64(dest + 0x10)
        rows.append(dict(name=q['name'], token=q['token'], context='string', error=None,
                         source_size=get32(source + 0x18), source_data=values(source_data), source_same=source_data == sa,
                         dest_size=get32(dest + 0x18), dest_data=values(dest_data), dest_same=dest_data == da,
                         dest_version=get32(dest + 0x1c) if rid == 0x8db else None, controlled_leaf_calls=list(calls)))
    assert len(rows) == sum(x['native_supported'] for x in json.loads((Q / 'GENERIC-CASES.json').read_bytes()))
    result = dict(scope='ORIGINAL_PC_FIVE_REFERENCE_GENERIC_CALLERS_NORMAL_PATH_CONTROLLED_ARRAY_AND_GC_CONTRACTS',
                  original_pc_sha256=hashlib.sha256(im.raw).hexdigest(), caller_bytes_rechecked=bound,
                  cases=len(rows), results=rows, callback_errors=im.errors,
                  controlled_leaves=['Array.New', 'Array.Clear', 'Array.Copy', 'GC.WriteBarrier', 'List.Capacity.get/set'],
                  limitations=['No native exception or SEH emulation', 'No GC correctness claim', 'Reference ABI only; no native value-type ABI claim', 'No Unity or player execution'])
    Path(sys.argv[1]).write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(cases=len(rows), methods=5, original_bytes_checked=len(bound), callback_errors=len(im.errors))))
finally:
    im.close()
