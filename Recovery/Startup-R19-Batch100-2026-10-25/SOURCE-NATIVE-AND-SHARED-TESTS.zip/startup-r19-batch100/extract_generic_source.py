"""Read pinned original registration tables; never execute generated code."""
import struct,json
import source_common as s
read=lambda va,n:s.pc.get_data(va-s.base,n)
nq=lambda va:struct.unpack('<Q',read(va,8))[0]
mv=struct.unpack('<16Q',read(0x1818c6d00,128));cv=struct.unpack('<17Q',read(0x1815e88c0,136))
assert (mv[4],mv[8],cv[2])==(61280,74797,61118)
specs=[struct.unpack('<iii',read(mv[9]+12*i,12)) for i in range(mv[8])]
funcs=[struct.unpack('<iiii',read(mv[5]+16*i,16)) for i in range(mv[4])]
pointers=list(struct.unpack('<'+'Q'*cv[2],read(cv[3],8*cv[2])))
gi=[nq(mv[3]+8*i) for i in range(mv[2])]
meta=(s.I/'original-pc/global-metadata.dat').read_bytes();so,mo=struct.unpack_from('<I',meta,24)[0],struct.unpack_from('<I',meta,48)[0]
types=json.loads((s.I/'maps/native-types.json').read_text('utf-8-sig'))
def string(i):return meta[so+i:meta.index(0,so+i)].decode()
def inst(ptr):
    if not ptr:return []
    n,at=struct.unpack('<QQ',read(ptr,16));return [type_name(nq(at+8*i)) for i in range(n)]
def type_name(ptr):
    data,bits=struct.unpack('<QI',read(ptr,12));kind=(bits>>16)&255
    if kind in [0x11,0x12]:
        t=types[data];return (t['namespace']+'.' if t['namespace'] else '')+t['name']
    if kind==0x15:
        tp,ci,mi,cached=struct.unpack('<4Q',read(data,32));return type_name(tp)+'<'+','.join(inst(ci))+'>'
    if kind==0x1d:return type_name(data)+'[]'
    return {1:'void',2:'bool',8:'int32',0xe:'string',0x1c:'object',0x13:'!'+str(data),0x1e:'!!'+str(data)}.get(kind,f'kind{kind:x}:{data:x}')
def row(si,mi):
    definition,ci,ii=specs[si];at=mo+definition*36;t=types[struct.unpack_from('<I',meta,at+4)[0]]
    return dict(spec_index=si,pointer_index=mi,va=hex(pointers[mi]),definition_index=definition,owner=(t['namespace']+'.' if t['namespace'] else '')+t['name'],name=string(struct.unpack_from('<I',meta,at)[0]),token=hex(struct.unpack_from('<I',meta,at+24)[0]),class_args=inst(gi[ci]) if ci>=0 else [],method_args=inst(gi[ii]) if ii>=0 else [])
rows=[]
for si,mi,iv,ad in funcs:
    r=row(si,mi)
    if r['owner'] in ['Projectile','FTRuntime.Internal.SwfList`1','FTRuntime.Internal.SwfAssocList`1'] or pointers[mi] in [0x1804a25f0,0x1804a24e0,0x1804a2700,0x1802fb100,0x1808197f0]:rows.append(r)
(s.Q/'ORIGINAL-GENERIC-BINDINGS.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
for rid in [0x8db,0x8dc,0x8eb,0x8ee,0x8f0]:
    token=s.tok(rid);matches=[r for r in rows if int(r['token'],16)==int(token,16)];variants=[]
    for r in matches:
        start=int(r['va'],16);stop=min(p for p in pointers if p>start);data=read(start,stop-start)
        variants.append(dict(binding=r,bound=hex(stop),raw_sha256=s.sha(data),raw_bytes=data.hex(),instructions=[dict(va=hex(i.address),op=i.mnemonic,operands=i.op_str,bytes=i.bytes.hex()) for i in s.dis.disasm(data,start)]))
    evidence=dict(token=token,scope='ORIGINAL_GENERIC_REGISTRATION_AND_BOUNDED_LINEAR_CODE_VARIANTS_NOT_EXECUTION',variants=variants)
    (s.Q/'native-source-complete'/(token+'.json')).write_text(json.dumps(evidence,indent=2)+'\n',encoding='utf-8')
    (s.Q/(token+'.parent-cil.json')).write_text(json.dumps(s.methods[token],indent=2)+'\n',encoding='utf-8')
for r in rows:
    if r['va'] in ['0x1804a25f0','0x1804a24e0','0x1804a2700','0x1802fb100','0x1808197f0']:print(r)
print('rows',len(rows))
