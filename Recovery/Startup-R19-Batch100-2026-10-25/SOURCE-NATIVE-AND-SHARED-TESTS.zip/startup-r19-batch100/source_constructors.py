"""Original-PC constructor source recovery; not execution or qualification."""
from construction import IL
import source_common as s
def populate(c):
    base=c.meth('System.Object','.ctor');empty=c.fld('System.String','Empty')
    simple={
      0x112:[('i','anti_ground_able',1),('new','element_Subs'),('new','elements'),('new','buffs_additional'),('base',)],
      0x130:[('new','enemies_preList'),('base',)],
      0x155:[('empty','boardName'),('empty','boardInfo'),('new','zombieTypes'),('i','enemyPoint_Base',4),('i','flagsNum',1),('i','wavesNum',10),('i','baseSunPoint',200),('new','lootList'),('new','preEnemies'),('new','preDevices'),('new','preCards'),('new','boardEntries'),('new','boardDialogues'),('base',),('map',)],
      0x164:[('new','supplies'),('new','newPlants'),('base',)],
      0x190:[('new','deviceList'),('new','preDeviceList'),('i','display_Ban_device',1),('new','effectBoardEntries'),('new','boardEntryData'),('mono',)],
      0x1a0:[('empty','entryKey'),('base',),('new','myPath')],
      0x1ae:[('new','zombieSelects'),('base',)],
      0x250:[('new','plantsInitialValue'),('base',)],
      0x254:[('new','plantsInitialValue'),('new','plantsDatas'),('new','plantLevelUpSupplies'),('new','plantOrderUpSupplies'),('new','plantSkillUpSupplies'),('base',)],
      0x255:[('arr','sunPrice',5),('arr','replantCD',5),('arr','maxHealthPoint',200),('arr','attackPoint',200),('arr','armorPoint',5),('arr','defensePoint',200),('arr','attackInterva',5),('arr','characteristicTicking',5),('arr','characteristicMaxTicking',5),('base',),('arg','ID',1)],
      0x258:[*[('new','supplies'+str(i)) for i in range(1,5)],('base',),('arg','id',1)],
      0x259:[('arr','suppliesList',8),('base',),('arg','id',1)],
      0x25a:[('new','supplies'),('base',)],
      0x25b:[*[('new','supplies'+str(i)) for i in range(1,9)],('base',)],
      0x27e:[('new','audioClip_zombie'),('new','zombieList'),('new','effectBoardEntries'),('new','boardEntryData'),('mono',)],
      0x2ed:[('new','skill'),('arr','talentNames',3),('arr','talents',3),('base',)],
      0x2fb:[('i','camp',1),('i','associationGridX',-1),('i','associationGridY',-1),('base',),('empty','name'),('i','camp',0),('arg','ID',1),('new','content'),('r','icePoint',0),('r','maxIcePoint',6000)],
      0x300:[('empty','name'),('i','camp',1),('base',)],
      0x4c7:[('str','administratorMode',''),('str','playerName','Somebody'),('i','lenthOfSeedBank',8),('i','lenthOfPropBank',1),('arr','rescuePassNum',128),('arr','minigamePassNum',128),('arr','adventureHardMaxStarNum',128),('arr','adventureHardPassed',128),('new','plantSaves'),('new','propSaves'),('new','supplies'),('arr','almanac_ZombieLock',128),('arr','almanac_DeviceLock',128),('arr','key_Tutorial',256),('new','teams'),('r','BGMVolume',0.4),('r','audioVlume',0.4),('i','fullscreen',1),('offsetbool',0xb1,1),('base',)],
      0x4c9:[('new','saveList'),('base',)],
      0x4d4:[('arr','talentNames',3),('arr','talents',3),('base',)],
      0x4d5:[('arr','talentNames',3),('arr','talents',3),('base',),('arg','ID',1)],
      0x4e6:[('r','duration',0.5),('i','isPreventCharge',1),('r','maxChargeTicking',1),('i','maxChargedLayer',1),('arr','value_float',9),('base',),('empty','name'),('empty','description'),('arr','value_float',9)],
      0x60b:[('empty','key'),('empty','descrption'),('base',)],
      0x6c9:[*[('new',n) for n in ['infoButtons','Buttons','dataUIControllers','skillTexts','skillButton','characteristicTexts','talentTexts']],('base',)],
      0x853:[*[('arr',n,0) for n in ['SubMeshes','Vertices','UVs','AddColors','MulColors']],('base',)],
      0x854:[('arr','Labels',0),('new','MeshData'),('arr','Materials',0),('base',),('arr','Labels',0),('new','MeshData'),('arr','Materials',0)],
      0x855:[('arr','Labels',0),('new','MeshData'),('arr','Materials',0),('base',),('arg','Labels',1),('arg','MeshData',2),('arg','Materials',3)],
      0x857:[('empty','Name'),('new','Frames'),('base',)],
    }
    for rid,ops in simple.items():
        owner=s.methods[s.tok(rid)]['owner'];b=IL()
        for op in ops:
            kind=op[0]
            if kind in ['base','mono']:
                b.arg(0).token(0x28,base if kind=='base' else c.meth('UnityEngine.MonoBehaviour','.ctor'));continue
            if kind=='map':
                b.arg(0).i4(12).i4(7).token(0x73,c.meth('Map','.ctor',['System.Int32','System.Int32'])).op('25').r4(540).token(0x7d,c.fld('Map','cameraSize')).token(0x7d,c.fld(owner,'map'));continue
            name=op[1]
            if kind=='offsetbool':
                match=[r for r in s.field_rows if r['type']==owner and r['offset']==name];assert len(match)==1,match;name=match[0]['name']
                field=c.fld(owner,name);assert s.pe.net.mdtables.Field.rows[(field&0xffffff)-1].Signature.value==b'\x06\x02'
            b.arg(0)
            if kind=='new':b.token(0x73,c.meth(c.field_types[(owner,name)],'.ctor'))
            elif kind=='arr':b.i4(op[2]).token(0x8d,c.type(c.field_types[(owner,name)][:-2]))
            elif kind=='empty':b.token(0x7e,empty)
            elif kind=='str':b.token(0x72,c.text(rid,op[2]))
            elif kind in ['i','offsetbool']:b.i4(op[2])
            elif kind=='r':b.r4(op[2])
            elif kind=='arg':b.arg(op[2])
            else:raise ValueError(op)
            b.token(0x7d,c.fld(owner,name))
        b.op('2a')
        c.add(rid,b,'Restore original ordered initializers and the real base constructor; preserve native overwritten allocations, remove duplicate calls introduced by inlining, and recover all packed fields.',maxstack=4,group='constructors')
if __name__=='__main__':
    from construction import Context
    import sys
    c=Context();populate(c);c.save(sys.argv[1])
