"""R19 source construction. No verifier, JIT, fixture or compiler is invoked."""
import importlib.util, json, struct
from pathlib import Path
import source_common as s
def mod(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
writer=mod('r19_metadata_writer',s.W/'startup-r2/construct.py')
labels=mod('r19_labels',s.W/'startup-r13/construct.py')
class IL(labels.IL):
    def arg(self,n):return self.emit(bytes([2+n])) if n<4 else self.emit(bytes([0x0e,n]))
    def addr(self,n):return self.emit(bytes([0x0f,n]))
    def loca(self,n):return self.emit(bytes([0x12,n]))
class Context:
    def __init__(self):
        self.bodies={};self.fields={};self.field_types={};self.calls={};self.types={}
        pe=s.pe;self.cli=pe.get_offset_from_rva(pe.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress)
        mrva,msize=struct.unpack_from('<II',s.parent,self.cli+8);mat=pe.get_offset_from_rva(mrva)
        self.root,self.streams=writer.metadata_root(s.parent[mat:mat+msize]);self.values={n:b for n,_,b in self.streams}
        self.th,self.rows,self.tail,self.counts=writer.tables_decode(self.values['#~'])
        self.new_refs=[];self.new_sigs=[];self.new_specs=[]
        for token,m in s.methods.items():
            for i in m['instructions']:
                op=i['opcode'];v=i['operand']
                if op in ['ldfld','stfld','ldsfld','stsfld','ldflda','ldsflda']:
                    key=(v['owner'],v['identity'].rsplit('::',1)[-1]);self.fields[key]=s.operand_token(token,i);self.field_types[key]=v['type']
                if op in ['call','callvirt','newobj']:
                    self.calls.setdefault((v['owner'],v['name'],tuple(v['args'])),s.operand_token(token,i))
                if op in ['newarr','box','unbox.any','castclass','isinst','ldobj','stobj','initobj'] and isinstance(v,dict) and 'type' in v:
                    self.types[v['type']]=s.operand_token(token,i)
    def fld(self,owner,name):
        key=(owner,name)
        if key not in self.fields:
            leaf=owner.rsplit('/',1)[-1].rsplit('.',1)[-1]
            found=[r for r in s.field_rows if r['type']==leaf and r['name']==name]
            assert len(found)==1,key
            t=int(found[0]['token'],16);assert str(s.pe.net.mdtables.Field.rows[(t&0xffffff)-1].Name)==name
            self.fields[key]=t
        return self.fields[key]
    def meth(self,owner,name,args=()):
        own=[int(t,16) for t,m in s.methods.items() if m['owner']==owner and m['args']==list(args) and str(s.pe.net.mdtables.MethodDef.rows[(int(t,16)&0xffffff)-1].Name)==name]
        assert len(own)<=1,(owner,name,args)
        return own[0] if own else self.calls[(owner,name,tuple(args))]
    def field_at(self,owner,offset):
        # Field tokens are module-relative. The global map contains many modules
        # with identical token values; never key their offsets by token alone.
        leaf=owner.rsplit('/',1)[-1].rsplit('.',1)[-1]
        found=[r for r in s.field_rows if r['type']==leaf and r['offset']==offset and (owner,r['name']) in self.fields]
        if not found:found=[r for r in s.field_rows if r['type']==leaf and r['offset']==offset and r['namespace']==(owner.rsplit('.',1)[0] if '.' in owner else '')]
        assert len(found)==1,(owner,offset,found)
        return self.fld(owner,found[0]['name'])
    def type(self,name):
        if name in self.types:return self.types[name]
        found=[0x1000000|k for k,r in enumerate(s.pe.net.mdtables.TypeRef.rows,1) if str(r.TypeNamespace)+'.'+str(r.TypeName)==name]
        assert len(found)==1,name
        return found[0]
    def text(self,rid,value):
        token=s.tok(rid)
        i=next(i for i in s.methods[token]['instructions'] if i['opcode']=='ldstr' and i['operand']==value)
        return s.operand_token(token,i)
    def blob(self,value):
        at=len(self.values['#Blob']);self.values['#Blob']+=labels.comp(len(value))+value;return at
    def string(self,value):
        for token,m in s.methods.items():
            for i in m['instructions']:
                if i['opcode']=='ldstr' and i['operand']==value:return s.operand_token(token,i)
        data=value.encode('utf-16-le');flag=any(ord(ch)<0x20 and ch not in '\t\r\n' or ord(ch)>0x7e or ch in "'\"\\" for ch in value)
        payload=data+bytes([int(flag)]);at=len(self.values['#US']);self.values['#US']+=labels.comp(len(payload))+payload
        return 0x70000000|at
    def name(self,value):
        value=value.encode()+b'\0';at=self.values['#Strings'].find(value)
        if at>=0 and (at==0 or self.values['#Strings'][at-1]==0):return at
        at=len(self.values['#Strings']);self.values['#Strings']+=value;return at
    def public_ref(self,owner,name,sig):
        tr=next(k for k,r in enumerate(s.pe.net.mdtables.TypeRef.rows,1) if str(r.TypeNamespace)+'.'+str(r.TypeName)==owner);coded=(tr<<3)|1
        for k,r in enumerate(s.pe.net.mdtables.MemberRef.rows,1):
            if self.rows[10][k-1][0]==coded and str(r.Name)==name and r.Signature.value==sig:return 0xa000000|k
        for r in self.new_refs:
            if r['owner']==owner and r['name']==name and r['signature']==sig.hex():return int(r['token'],16)
        self.rows[10].append([coded,self.name(name),self.blob(sig)]);token=0xa000000|len(self.rows[10]);self.new_refs.append(dict(token=f'0x{token:08X}',owner=owner,name=name,signature=sig.hex()));return token
    def closed_ref(self,owner,name,sig):
        for key,tok in self.calls.items():
            if key[0]==owner and tok>>24==10:
                coded=self.rows[10][(tok&0xffffff)-1][0];break
        else:raise KeyError(owner)
        for k,r in enumerate(s.pe.net.mdtables.MemberRef.rows,1):
            if self.rows[10][k-1][0]==coded and str(r.Name)==name and r.Signature.value==sig:return 0xa000000|k
        for r in self.new_refs:
            if r['owner']==owner and r['name']==name and r['signature']==sig.hex():return int(r['token'],16)
        self.rows[10].append([coded,self.name(name),self.blob(sig)]);token=0xa000000|len(self.rows[10]);self.new_refs.append(dict(token=hex(token),owner=owner,name=name,signature=sig.hex()));return token
    def generic_spec(self,rid,type_name):
        matches=[k for k,r in enumerate(s.pe.net.mdtables.TypeDef.rows,1) if str(r.TypeName)==type_name and not str(r.TypeNamespace)];assert len(matches)==1,type_name
        signature=b'\x0a\x01\x12'+labels.comp(matches[0]<<2);coded=rid<<1
        for k,r in enumerate(s.pe.net.mdtables.MethodSpec.rows,1):
            if self.rows[43][k-1][0]==coded and r.Instantiation.value==signature:return 0x2b000000|k
        for r in self.new_specs:
            if r['definition']==s.tok(rid) and r['argument']==type_name:return int(r['token'],16)
        self.rows[43].append([coded,self.blob(signature)]);token=0x2b000000|len(self.rows[43]);self.new_specs.append(dict(token=hex(token),definition=s.tok(rid),argument=type_name,signature=signature.hex()));return token
    def append_locals(self,rid,encodings):
        token=s.tok(rid);m=s.methods[token];slot=s.body(token)
        oldtok=int.from_bytes(s.parent[slot['offset']+8:slot['offset']+12],'little') if slot['header']==12 else 0;old=s.pe.net.mdtables.StandAloneSig.rows[(oldtok&0xffffff)-1].Signature.value if oldtok else b'\x07\x00'
        assert old[0]==7 and old[1]<128 and old[1]+len(encodings)<128
        new=bytes([7,old[1]+len(encodings)])+old[2:]+b''.join(encodings);self.rows[17].append([self.blob(new)]);nt=0x11000000|len(self.rows[17])
        self.new_sigs.append(dict(method=token,old_token=hex(oldtok),new_token=hex(nt),old=old.hex(),new=new.hex()))
        return len(m['locals']),nt
    def add(self,rid,b,reason,maxstack=8,local_token=None,group='native-source-reconstruction',new_eh=None):
        token=s.tok(rid);assert token not in self.bodies
        code=b.finish() if isinstance(b,IL) else bytes(b);assert code and code!=s.body(token)['code'],token
        native_file=s.Q/'native-source-complete'/(token+'.json')
        assert native_file.exists(),('Missing original native evidence',token)
        self.bodies[token]=dict(code=code,reason=reason,maxstack=maxstack,local_token=local_token,group=group,native_evidence_sha256=s.sha(native_file.read_bytes()),new_eh=new_eh)
    def save(self,stem):
        pe=s.pe;out=bytearray(s.parent);allowed=set();changes=[];last=pe.sections[-1]
        assert last.Name.rstrip(b'\0')==b'.n29meta' and last.Characteristics==0x40000040 and last.PointerToRawData+last.SizeOfRawData==len(out)
        for token,v in sorted(self.bodies.items()):
            rid=int(token,16)&0xffffff;slot=s.body(token);at=slot['offset'];h=slot['header'];code=v['code'];m=s.methods[token]
            assert h in [1,12]
            if m['handlers']:assert h==12 and len(code)==slot['code_size'],('Existing EH boundaries require fixed-width source edits',token)
            assert sum(r.Rva==pe.net.mdtables.MethodDef.rows[rid-1].Rva for r in pe.net.mdtables.MethodDef.rows)==1
            locals_=v['local_token'] or (int.from_bytes(s.parent[at+8:at+12],'little') if h==12 else 0);stack=max(m['maxStack'],v['maxstack'])
            oldrva=pe.net.mdtables.MethodDef.rows[rid-1].Rva
            if h==12 and len(code)<=slot['code_size'] and not v.get('new_eh'):
                out[at+h:at+h+len(code)]=code;allowed.update(range(at+h,at+h+len(code)))
                for off,fmt,value in [(2,'<H',stack),(4,'<I',len(code)),(8,'<I',locals_)]:
                    struct.pack_into(fmt,out,at+off,value);allowed.update(range(at+off,at+off+struct.calcsize(fmt)))
                newrva=oldrva;kind='inplace_complete_body_unused_old_slot_preserved'
            else:
                start=writer.align(len(out),4);out.extend(b'\0'*(start-len(out)));newrva=last.VirtualAddress+start-last.PointerToRawData
                flags=(0x3013 if locals_ else 0x3003)|(8 if v.get('new_eh') else 0)
                out.extend(struct.pack('<HHII',flags,stack,len(code),locals_)+code)
                if v.get('new_eh'):
                    out.extend(b'\0'*(writer.align(len(out),4)-len(out)));n=len(v['new_eh']);out.extend(bytes([0x41])+(4+24*n).to_bytes(3,'little'))
                    for region in v['new_eh']:
                        assert region['kind']=='finally';out.extend(struct.pack('<6I',2,region['try_start'],region['try_end']-region['try_start'],region['handler_start'],region['handler_end']-region['handler_start'],0))
                self.rows[6][rid-1][0]=newrva;kind='relocated_CIL_body_original_slot_preserved'
            changes.append(dict(token=token,name=m['name'],old_rva=hex(oldrva),new_rva=hex(newrva),kind=kind,old_code_size=slot['code_size'],new_code_size=len(code),old_maxstack=m['maxStack'],new_maxstack=stack,local_sig=hex(locals_),old_code_sha256=s.sha(slot['code']),new_code_sha256=s.sha(code),new_code=code.hex(),reason=v['reason'],group=v['group'],new_eh=v.get('new_eh'),native_evidence_sha256=v['native_evidence_sha256'],qualification='CONSTRUCTED_UNTESTED'))
        self.values['#~']=writer.tables_encode(self.th,self.rows,self.tail,self.counts);metadata=bytearray(self.root)
        for name,header,_ in self.streams:
            start=writer.align(len(metadata),4);metadata.extend(b'\0'*(start-len(metadata)));struct.pack_into('<II',metadata,header,start,len(self.values[name]));metadata.extend(self.values[name])
        start=writer.align(len(out),4);out.extend(b'\0'*(start-len(out)));out.extend(metadata);end=len(out)
        rawsize=writer.align(end-last.PointerToRawData,pe.OPTIONAL_HEADER.FileAlignment);out.extend(b'\0'*(last.PointerToRawData+rawsize-len(out)))
        sh=last.get_file_offset();opt=pe.OPTIONAL_HEADER.get_file_offset();updates={sh+8:end-last.PointerToRawData,sh+16:rawsize,opt+8:pe.OPTIONAL_HEADER.SizeOfInitializedData+rawsize-last.SizeOfRawData,opt+56:writer.align(last.VirtualAddress+end-last.PointerToRawData,pe.OPTIONAL_HEADER.SectionAlignment),opt+64:0,self.cli+8:last.VirtualAddress+start-last.PointerToRawData,self.cli+12:len(metadata)}
        for at,value in updates.items():struct.pack_into('<I',out,at,value);allowed.update(range(at,at+4))
        assert all(a==b or k in allowed for k,(a,b) in enumerate(zip(s.parent,out)))
        path=s.Q/(stem+'.dll');assert not path.exists();path.write_bytes(out)
        report=dict(parent_sha256=s.sha(s.parent),candidate_sha256=s.sha(out),bytes=len(out),new_unique_methods=len(changes),changes=changes,new_memberrefs=self.new_refs,new_local_signatures=self.new_sigs,new_methodspecs=self.new_specs,header_updates=updates,tests_run=False,qualified_methods=0,shared_test_threshold=100,unity_or_ipa=False)
        (s.Q/(stem+'.json')).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
        print(json.dumps({k:v for k,v in report.items() if k not in ['changes','header_updates']},indent=2))
