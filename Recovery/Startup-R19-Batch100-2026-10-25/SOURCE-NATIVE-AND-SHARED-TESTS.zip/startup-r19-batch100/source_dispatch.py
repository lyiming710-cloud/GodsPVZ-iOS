"""Recover lost native tail calls, switches and ordered field effects."""
import json,struct
from construction import IL
import source_common as s
from source_tables import literal,rip_value
def instruction(va):return next(s.dis.disasm(s.pc.get_data(va-s.base,15),va))
def constant(va):
    i=instruction(va);return struct.unpack('<f',s.pc.get_data(rip_value(i)-s.base,4))[0]
def populate(c):
    tables=json.loads((s.Q/'ORIGINAL-SWITCH-TABLES.json').read_bytes())
    for rid,field,tail in [(0x38,'preDevice','LoadData'),(0x5f,'enemyPath','LoadData'),(0x6f0,'supplies','SetInfo')]:
        owner=s.methods[s.tok(rid)]['owner'];b=IL().arg(0).arg(1).token(0x7d,c.fld(owner,field))
        if rid==0x6f0:
            b.arg(0).arg(1).branch(0x39,'null').arg(1).token(0x7b,c.fld('Supplies','ID')).token(0x28,c.meth('ResourceManager','GetSuppliesInfo',['System.Int32'])).branch(0x38,'info').mark('null').op('14').mark('info').token(0x7d,c.fld(owner,'suppliesInfo'))
        b.arg(0).token(0x28,c.meth(owner,tail)).op('2a')
        c.add(rid,b,'Restore the original external tail after the field writes, with original null-dependent supplies lookup.',maxstack=3,group='lost-tail')
    b=IL().arg(2).arg(1).arg(0).token(0x6f,c.meth('Plant','Healed',['System.Single','Plant'])).op('2a')
    c.add(0x377,b,'Native receiver is the second Plant argument; forward amount and healer to Healed, retaining the receiver null throw.',maxstack=3,group='lost-tail')
    owner=s.methods[s.tok(0x762)]['owner'];old=s.methods[s.tok(0x762)]
    component=next(i for i in old['instructions'] if i['opcode']=='call' and i['operand']['name']=='GetComponent')
    getter=c.public_ref('UnityEngine.Renderer','get_material',s.pe.net.mdtables.MemberRef.rows[(c.meth('UnityEngine.Renderer','GetMaterial')&0xffffff)-1].Signature.value)
    b=IL().arg(0).arg(0).token(0x28,s.operand_token(s.tok(0x762),component)).token(0x7d,c.fld(owner,'m_Renderer')).arg(0).arg(0).token(0x7b,c.fld(owner,'m_Renderer')).token(0x6f,getter).token(0x7d,c.fld(owner,'m_Material')).op('2a')
    c.add(0x762,b,'Use legal public Renderer.material, bound to the same original player GetMaterial native entry; nonpersistent gameplay renderer scope as in R18.',maxstack=3,group='public-contract')
    # Painter literals come directly from metadata; retain even original U+FFFD.
    values=tables[s.tok(0x144)]['literals'];b=IL().arg(0).switch(['p'+str(n) for n in range(9)]).token(0x72,c.string(values[9]['value'])).op('2a')
    for n,item in enumerate(values[:9]):b.mark('p'+str(n)).token(0x72,c.string(item['value'])).op('2a')
    c.add(0x144,b,'Restore all nine native painter choices and the out-of-range default using original string bytes.',maxstack=1,group='lost-switch')
    values=tables[s.tok(0x18f)]['values'];b=IL().arg(0).i4(4).op('59').switch(['v'+str(n) for n in range(11)]).i4(0).op('2a')
    for n,v in enumerate(values):b.mark('v'+str(n)).i4(v).op('2a')
    c.add(0x18f,b,'Recover eleven unsigned (id-4) dispatch entries and default zero from the leaf native table.',maxstack=2,group='lost-switch')
    b=IL().arg(0).token(0x7b,c.fld('Project','projectType')).switch(['direct','silver','silver','gold','silver','done','done','done','silver']).branch(0x38,'done')
    for name,kind in [('direct',None),('gold',1),('silver',0)]:
        b.mark(name).arg(0).token(0x28,c.meth('Project','Collect'))
        if kind is not None:b.arg(0).token(0x7b,c.fld('Project','board')).token(0x7b,c.fld('Board','projectManager')).i4(kind).token(0x6f,c.meth('ProjectManager','Awake_MoneyBank',['System.Int32']))
        b.arg(0).token(0x7b,c.fld('Project','projectManager')).arg(0).token(0x6f,c.meth('ProjectManager','PlayAudio_Click',['Project'])).branch(0x38,'done')
    b.mark('done').op('2a');c.add(0x3c2,b,'Restore the nine native ProjectType actions; retain Collect, optional bank update, then audio and manager reload order.',maxstack=2,group='lost-switch')
    # Damage by ID: float32 operations in the exact native order.
    targets=tables[s.tok(0x445)]['targets'];labels_={v:'case'+v[-5:] for v in set(targets)};end=labels_['0x180360856']
    b=IL().arg(0).token(0x28,c.meth('Zombie','GetATK')).store(1).arg(0).token(0x7b,c.fld('Zombie','ID')).i4(3).op('59').switch([labels_[v] for v in targets]).branch(0x38,end)
    for va,condition in [(0x1803607e6,True),(0x18036082d,True)]:
        b.mark(labels_[hex(va)]).arg(2).i4(0).branch(0x3f,end).loc(1).r4(constant(va+4)).op('5a6b').store(1).branch(0x38,end)
    b.mark(labels_['0x1803607f4']).loc(1).r4(constant(0x1803607f4)).op('5a6b').store(1).branch(0x38,end)
    b.mark(labels_['0x1803607fe']).arg(0).token(0x28,c.meth('Zombie','GetMS')).loc(1).op('5a6b25').op('586b').store(1).branch(0x38,end)
    b.mark(labels_['0x180360815']).arg(2).i4(0).branch(0x3c,'normal_target').loc(1).r4(constant(0x180360819)).op('5a6b').store(1).branch(0x38,end)
    b.mark('normal_target').loc(1).r4(constant(0x180360823)).op('5a6b').store(1).branch(0x38,end)
    b.mark(labels_['0x18036083b']).arg(3).branch(0x3a,'impact1').loc(1).r4(constant(0x18036083f)).op('5a6b').store(1).branch(0x38,end)
    b.mark('impact1').arg(3).i4(1).branch(0x40,end).loc(1).r4(constant(0x18036084e)).op('5a6b').store(1)
    b.mark(end).arg(1).op('50').loc(1).token(0x7d,c.fld('Damage','damagePoint')).op('2a')
    c.add(0x445,b,'Recover all twenty ID dispatch entries, signed target partitions and impact variants, then write through the actual Damage& argument.',maxstack=3,group='lost-switch')
    # Almanac painter text, including null PlantSave and special plant ID 49.
    rid=0x56d;owner=s.methods[s.tok(rid)]['owner'];idx,sig=c.append_locals(rid,[b'\x08',b'\x0e']);i=idx;stringidx=idx+1
    table=tables[s.tok(rid)]['targets'];names={v:'a'+v[-5:] for v in sorted(set(table))}
    prefix=literal(rip_value(instruction(0x18038a981)))['value']
    b=IL().arg(1).branch(0x3a,'present').arg(0).token(0x7b,c.fld(owner,'painter')).token(0x7e,c.fld('System.String','Empty')).i4(1).token(0x6f,c.meth('TMPro.TMP_Text','SetText',['System.String','System.Boolean'])).op('2a')
    b.mark('present').arg(1).token(0x7b,c.fld('PlantSave','ID')).store(i).loc(i).switch([names[v] for v in table]).loc(i).i4(49).branch(0x3b,names['0x18038a97a']).token(0x7e,c.fld('System.String','Empty')).branch(0x38,'picked')
    for address,label in names.items():
        value=literal(rip_value(instruction(int(address,16))))['value'];b.mark(label).token(0x72,c.string(value)).branch(0x38,'picked')
    b.mark('picked').store(stringidx).arg(0).token(0x7b,c.fld(owner,'painter')).token(0x72,c.string(prefix)).loc(stringidx).token(0x28,c.meth('System.String','Concat',['System.String','System.String'])).i4(1).token(0x6f,c.meth('TMPro.TMP_Text','SetText',['System.String','System.Boolean'])).op('2a')
    c.add(rid,b,'Restore original plant-ID painter table, prefix concatenation, special ID 49 and null save behavior with original literals.',maxstack=4,local_token=sig,group='lost-switch')
    # Loot construction and complete type dispatch.
    def lf(b,name):return b.loc(0).token(0x7b,c.fld('Loot',name))
    def seti(b,name,n):return b.loc(0).i4(n).token(0x7d,c.fld('Loot',name))
    def setr(b,name,bits):return b.loc(0).r4(bits=bits).token(0x7d,c.fld('Loot',name))
    def level(b):return b.arg(0).token(0x7b,c.fld('BoardEntry','level'))
    idx,sig=c.append_locals(0x609,[b'\x08'])
    b=IL().token(0x73,c.meth('Loot','.ctor')).store(0);seti(b,'suppliesID',0);setr(b,'probability','3f000000')
    b.loc(0).arg(1).token(0x7b,c.fld('BoardConfig','flagsNum')).token(0x7d,c.fld('Loot','frequency')).arg(0).token(0x7b,c.fld('BoardEntry','boardEntryType')).op('25').store(idx)
    targets=tables[s.tok(0x609)]['targets'];names={v:'l'+v[-5:] for v in set(targets)};done=names['0x180394aa8']
    b.switch([names[v] for v in targets]).loc(idx).i4(33).branch(0x40,done).arg(0).token(0x7b,c.fld('BoardEntry','key')).token(0x72,c.string(literal(rip_value(instruction(0x180394a66)))['value'])).token(0x28,c.meth('System.String','op_Equality',['System.String','System.String'])).branch(0x39,done)
    seti(b,'suppliesID',26);seti(b,'quantity',1);b.loc(0);level(b).op('6b').r4(constant(0x180394a93)).op('5a6b').r4(constant(0x180394a9b)).op('586b').token(0x7d,c.fld('Loot','probability')).branch(0x38,done)
    specs=[(0x18039493d,None,'3f4ccccd',4),(0x180394952,28,'3f400000',2),(0x18039496d,34,'3f400000',2),(0x180394988,8,'3f4ccccd',1),(0x1803949a1,23,'3f0ccccd',2),(0x1803949bc,5,'3ecccccd',1),(0x1803949d5,23,'3ee66666',2),(0x1803949f0,34,'3f0ccccd',2),(0x180394a39,3,'3f4ccccd',2),(0x180394a51,10,'3eb33333',None)]
    for va,supply,bits,mult in specs:
        b.mark(names[hex(va)])
        if supply is not None:seti(b,'suppliesID',supply)
        setr(b,'probability',bits)
        if mult is not None:
            b.loc(0);level(b)
            if mult!=1:b.i4(mult).op('5a')
            b.token(0x7d,c.fld('Loot','quantity'))
        b.branch(0x38,done)
    b.mark(names['0x180394a0b']).loc(0);level(b).i4(27).op('58').token(0x7d,c.fld('Loot','suppliesID'));seti(b,'quantity',2)
    b.loc(0).r4(constant(0x180394a0e));level(b).op('6b').r4(constant(0x180394a2b)).op('5a6b596b').token(0x7d,c.fld('Loot','probability')).branch(0x38,done)
    b.mark(done).loc(0);lf(b,'quantity').arg(1).token(0x7b,c.fld('BoardConfig','flagsNum')).op('5a').token(0x7d,c.fld('Loot','maxQuantity')).loc(0).op('2a')
    c.add(0x609,b,'Recover all 26 table entries plus key-dependent type 33, ordered float32 reward formulas and final quantity-times-flags maximum.',maxstack=5,local_token=sig,group='lost-switch')
