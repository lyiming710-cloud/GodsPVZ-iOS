"""Source recovery for selection, talent counts and supply formulas."""
import struct,json
from construction import IL
from source_dispatch import instruction
from source_tables import rip_value
import source_common as s
def dconstant(va):return struct.unpack('<d',s.pc.get_data(rip_value(instruction(va))-s.base,8))[0]
def sconstant(va):return struct.unpack('<f',s.pc.get_data(rip_value(instruction(va))-s.base,4))[0]
def cvtt32(b,local,label):
    b.store(local).loc(local).r8(-2147483648).branch(0x44,label+'invalid').loc(local).r8(2147483648).branch(0x41,label+'invalid').loc(local).op('69').branch(0x38,label+'converted').mark(label+'invalid').i4(-2147483648).mark(label+'converted');return b
def populate(c):
    implicit=c.meth('UnityEngine.Object','op_Implicit',['UnityEngine.Object'])
    b=IL().arg(0).token(0x28,c.meth('MouseManager','GetPlantUnderMouse')).store(1).loc(1).op('14').token(0x28,c.meth('UnityEngine.Object','op_Equality',['UnityEngine.Object','UnityEngine.Object'])).branch(0x3a,'empty')
    b.loc(1).token(0x7b,c.fld('Plant','elementManager')).i4(0).token(0x6f,c.meth('ElementManager','GetElement',['ElementType'])).store(4).loc(4).branch(0x39,'shovel').loc(4).token(0x7b,c.fld('Element','burstTime')).r4(0).branch(0x43,'shovel').loc(4).token(0x7b,c.fld('Element','point')).r4(0).branch(0x43,'shovel').arg(0).i4(6).token(0x28,c.meth('MouseManager','AudioPlay',['System.Int32'])).op('2a')
    b.mark('shovel').arg(0).token(0x7b,c.fld('MouseManager','propOnHand')).store(3).loc(1).loc(3).token(0x7b,c.fld('Prop','level')).loc(3).token(0x7b,c.fld('Prop','specialType')).token(0x6f,c.meth('Plant','PlantDie_Shovel',['System.Int32','System.Int32']))
    b.arg(0).token(0x7b,c.fld('MouseManager','propOnHand')).token(0x28,implicit).branch(0x39,'reset').arg(0).token(0x7b,c.fld('MouseManager','propOnHand')).token(0x6f,c.meth('Prop','DropDown')).mark('reset').arg(0).token(0x28,c.meth('MouseManager','ResetMouseState')).arg(0).i4(10).token(0x28,c.meth('MouseManager','AudioPlay',['System.Int32'])).op('2a')
    b.mark('empty').arg(0).token(0x7b,c.fld('MouseManager','propOnHand')).token(0x28,implicit).branch(0x39,'empty_reset').arg(0).token(0x7b,c.fld('MouseManager','propOnHand')).token(0x6f,c.meth('Prop','DropDown')).mark('empty_reset').arg(0).token(0x28,c.meth('MouseManager','ResetMouseState')).op('2a')
    c.add(0x1da,b,'Restore GetPlant selection, element thresholds, captured shovel parameters, distinct empty/success cleanup and both original AudioPlay tails.',maxstack=3,group='selection-state')
    o='Card_Choose';b=IL().arg(0).token(0x7b,c.fld(o,'seedChooserScreen')).token(0x28,implicit).branch(0x3a,'chooser').arg(0).token(0x7b,c.fld(o,'almanacUIController')).token(0x28,implicit).branch(0x39,'done').arg(0).token(0x7b,c.fld(o,'almanacUIController')).arg(0).token(0x7b,c.fld(o,'plantID')).token(0x6f,c.meth('AlmanacUIController','OpenPlant',['System.Int32'])).branch(0x38,'done')
    b.mark('chooser').arg(0).token(0x7b,c.fld(o,'seedChooserScreen')).token(0x6f,c.meth('UnityEngine.Component','get_gameObject')).token(0x6f,c.meth('UnityEngine.GameObject','get_activeSelf')).store(1).arg(0).token(0x7b,c.fld(o,'seedChooserScreen')).store(5).loc(1).branch(0x3a,'active')
    b.loc(5).token(0x7b,c.fld('SeedChooserScreen','mouseManager')).i4(8).token(0x6f,c.meth('MouseManager','AudioPlay',['System.Int32'])).arg(0).token(0x7b,c.fld(o,'seedChooserScreen')).token(0x7b,c.fld('SeedChooserScreen','prepareUIController')).arg(0).token(0x7b,c.fld(o,'plantID')).token(0x6f,c.meth('PrepareUIController','SeedChoose',['System.Int32'])).branch(0x38,'done')
    b.mark('active').loc(5).token(0x7b,c.fld('SeedChooserScreen','mouseManager')).i4(8).token(0x6f,c.meth('MouseManager','AudioPlay',['System.Int32'])).arg(0).token(0x7b,c.fld(o,'isChosen')).branch(0x39,'choose').arg(0).token(0x28,c.meth(o,'Choose_Reset')).branch(0x38,'done').mark('choose').arg(0).token(0x28,c.meth(o,'Choose_Being')).mark('done').op('2a')
    c.add(0x2f3,b,'Restore both actual selection tails, native chooser capture after activeSelf, post-audio reloads and inactive chooser SeedChoose forwarding.',maxstack=2,group='selection-state')
    # Count nonempty talent names from one captured array, then original rarity dispatch.
    idx,sig=c.append_locals(0x4d0,[bytes.fromhex('1d0e'),b'\x08',b'\x08']);arr,counter,count=idx,idx+1,idx+2
    b=IL().arg(0).token(0x7b,c.fld('PlantSave','talentNames')).store(arr).i4(0).store(counter).i4(0).store(count).branch(0x38,'count_test').mark('count_loop').loc(arr).loc(counter).op('9a').token(0x7e,c.fld('System.String','Empty')).token(0x28,c.meth('System.String','op_Inequality',['System.String','System.String'])).branch(0x39,'count_next').loc(count).i4(1).op('58').store(count).mark('count_next').loc(counter).i4(1).op('58').store(counter).mark('count_test').loc(counter).loc(arr).op('8e69').branch(0x3f,'count_loop')
    targets=json.loads((s.Q/'ORIGINAL-SWITCH-TABLES.json').read_bytes())[s.tok(0x4d0)]['targets'];labels={v:'t'+v[-5:] for v in set(targets)}
    b.arg(0).token(0x7b,c.field_at('PlantSave',0x44)).switch([labels[v] for v in targets]).branch(0x38,'zero')
    # Read the table entries rather than assuming which rarity maps to each rule.
    b.mark(labels['0x180376065']).arg(1).op('2a')
    b.mark(labels['0x180376069']).loc(count).i4(1).branch(0x40,'c2').arg(1).i4(1).branch(0x3b,'one').arg(1).i4(2).branch(0x3b,'one').branch(0x38,'zero').mark('c2').loc(count).i4(2).branch(0x40,'zero').arg(1).op('2a')
    b.mark(labels['0x180376083']).loc(count).i4(1).branch(0x40,'d2')
    for n in [1,2,3]:b.arg(1).i4(n).branch(0x3b,'one')
    b.branch(0x38,'zero').mark('d2').loc(count).i4(2).branch(0x40,'zero').arg(1).i4(1).branch(0x3b,'one').arg(1).i4(2).branch(0x3b,'two').arg(1).i4(3).branch(0x3b,'two').branch(0x38,'zero')
    b.mark(labels['0x1803760d5']).arg(1).i4(1).op('58').i4(2).op('5b2a')
    b.mark(labels['0x1803760e1']).loc(count).i4(2).branch(0x3b,labels['0x1803760d5']).loc(count).i4(3).branch(0x40,'zero')
    b.mark(labels['0x1803760eb'])
    for n,label in [(1,'one'),(2,'one'),(3,'two')]:b.arg(1).i4(n).branch(0x3b,label)
    b.arg(1).i4(4).branch(0x40,'zero').i4(3).op('2a')
    # Default table target shares the exact zero-return epilogue.
    b.mark(labels['0x180376099']).mark('zero').i4(0).op('2a').mark('one').i4(1).op('2a').mark('two').i4(2).op('2a')
    c.add(0x4d0,b,'Recover original nonempty-name count, seven-entry rarity table and signed order formulas; retain null-name inequality and captured array semantics.',maxstack=2,local_token=sig,group='lost-switch')
    # Supply arrays: two real double-precision exponential formulas.
    idx,sig=c.append_locals(0x257,[b'\x08',b'\x08',b'\x08',b'\x0d',b'\x0d',b'\x0c']);group,ident,i,tmp,tmp2,factor=range(idx,idx+6)
    b=IL().arg(0).token(0x28,c.meth('System.Object','.ctor'))
    for name in ['coins','supplies']:b.arg(0).i4(7).token(0x8d,c.type('System.Int32')).token(0x7d,c.fld('PlantLevelUpSupplies',name))
    b.arg(1).store(ident)
    for g,bound,subtract in [(0,19,0),(1,48,19),(2,87,48),(3,136,87)]:
        b.arg(1).i4(bound).branch(0x3e,'group'+str(g))
    b.i4(4).store(group).arg(1).i4(136).op('59').store(ident).branch(0x38,'arrays')
    for g,subtract in [(0,0),(1,19),(2,48),(3,87)]:
        b.mark('group'+str(g)).i4(g).store(group)
        if subtract:b.arg(1).i4(subtract).op('59').store(ident)
        b.branch(0x38,'arrays')
    b.mark('arrays')
    for name in ['coins','supplies']:b.arg(0).token(0x7b,c.fld('PlantLevelUpSupplies',name)).i4(0).i4(0).op('9e')
    b.loc(ident).i4(1).op('596c').store(tmp2).loc(group).i4(1).op('586b').r4(sconstant(0x18032df75)).op('5a6b').store(factor).i4(1).store(i).mark('loop')
    b.arg(0).token(0x7b,c.fld('PlantLevelUpSupplies','coins')).loc(i).r8(dconstant(0x18032df5b)).loc(i).op('6c').token(0x28,c.meth('System.Math','Pow',['System.Double','System.Double'])).loc(tmp2).op('5a').loc(group).op('6c').r8(dconstant(0x18032df63)).op('5a58').r8(dconstant(0x18032df6c)).op('5b').token(0x28,c.meth('System.Math','Exp',['System.Double'])).loc(factor).op('6c5a')
    cvtt32(b,tmp,'coins').op('9e')
    b.arg(0).token(0x7b,c.fld('PlantLevelUpSupplies','supplies')).loc(i).r8(dconstant(0x18032df7e)).loc(i).op('6c').token(0x28,c.meth('System.Math','Pow',['System.Double','System.Double'])).loc(ident).op('6c5a').r8(dconstant(0x18032df87)).op('5b').token(0x28,c.meth('System.Math','Exp',['System.Double'])).r8(dconstant(0x18032df90)).op('5a')
    cvtt32(b,tmp,'supplies').op('9e').loc(i).i4(1).op('58').store(i).loc(i).i4(7).branch(0x3f,'loop').op('2a')
    c.add(0x257,b,'Restore Object ctor, seven-element Int32 arrays, signed ID groups, original Pow/Exp double coefficients, float32 group multiplier and x64 CVTT Int32 overflow/NaN sentinel.',maxstack=6,local_token=sig,group='native-double-formulas')
