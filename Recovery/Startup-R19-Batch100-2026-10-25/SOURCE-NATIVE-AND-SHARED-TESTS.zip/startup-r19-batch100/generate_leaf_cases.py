from pathlib import Path
import itertools,json
Q=Path(__file__).resolve().parent;rows=[]
def add(rid,**kw):rows.append(dict(name='l'+str(len(rows)).zfill(5),token=f'0x{0x6000000|rid:08X}',**kw))
for rid in [0x144,0x18f]:
    for n in [-2147483648,-2,-1,*range(151),2147483647]:add(rid,value=n)
talents=[[],[''],['a'],[None],['','a'],['a','b'],['','a',None],['a','b','c'],[None,None,None]]
for stars,tal,order in itertools.product([-2147483648,-1,*range(8),2147483647],talents,[-2147483648,-2,-1,*range(9),2147483647]):add(0x4d0,stars=stars,talents=tal,order=order)
cil=json.loads((Q/'shared-candidate5/ALL-CIL.json').read_bytes());m=next(m for m in cil['methods'] if m['token']=='0x06000609');special=next(i['operand'] for i in m['instructions'] if i['opcode']=='ldstr')
for typ,level,flags,key in itertools.product([-2147483648,-1,*range(36),2147483647],[-2,0,1,5,2147483647],[-1,0,3,2147483647],[None,'',special]):add(0x609,entry_type=typ,level=level,flags=flags,key=key)
for n in [-2147483648,-1,*range(161),2147483647]:add(0x257,value=n)
(Q/'LEAF-CASES.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(cases=len(rows),special_key=special)))
