"""Compare actual DLL observations to an independent finite state model and native.

This model is a test expectation, not independent proof of original semantics.
The separate original machine-code normal-path comparison supplies that layer.
"""
from pathlib import Path
import collections, hashlib, json, sys

Q = Path(__file__).resolve().parent
P = Q / ('shared-' + (sys.argv[1] if len(sys.argv) > 1 else 'candidate5'))
cases = json.loads((Q / 'GENERIC-CASES.json').read_bytes())
observed = json.loads((P / 'DIRECT-GENERICS.json').read_bytes())


def expected(q, context):
    sa = ['v' + str(k) for k in range(q['source_length'])]
    da = sa if q['shared_array'] else ['v' + str(20 + k) for k in range(q['dest_length'])]
    source = {'data': None if q['null_data'] else sa, 'size': q['source_size']}
    dest = source if q['alias'] else {'data': da, 'size': q['dest_size']}
    rid = int(q['token'], 16) & 0xffffff
    error = None
    version = 7 if rid == 0x8db else None
    arg = q['argument']
    if rid == 0x8eb:
        if (arg & 0xffffffff) >= (source['size'] & 0xffffffff):
            error = 'System.IndexOutOfRangeException'
        elif source['data'] is None:
            error = 'System.NullReferenceException'
        elif arg < 0 or arg >= len(source['data']):
            error = 'System.IndexOutOfRangeException'
        else:
            source['data'][arg] = 'v99'
    elif rid == 0x8ee:
        if arg < source['size']:
            error = 'System.ArgumentOutOfRangeException'
        elif source['data'] is None:
            error = 'System.NullReferenceException'
        elif arg != len(source['data']):
            data = [None] * arg if arg > 0 else []
            if arg > 0 and source['size'] > 0:
                data[:source['size']] = source['data'][:source['size']]
            source['data'] = data
    elif q['null_destination']:
        error = 'System.NullReferenceException'
    elif rid == 0x8db:
        count = dest['size']
        dest['size'] = 0
        version += 1
        # CoreCLR List<T>.Clear retains backing value-type cells without refs.
        # The object native oracle clears refs; no native value-type claim here.
        if context == 'string':
            dest['data'][:count] = [None] * count
        if len(dest['data']) < source['size']:
            dest['data'] = [None] * (2 * source['size'])
        count = source['size']
        for k in range(count):
            dest['data'][dest['size']] = source['data'][k]
            dest['size'] += 1
            version += 1
    else:
        data = dest['data']
        if len(data) < source['size']:
            new = [None] * (source['size'] * 2)
            new[:source['size']] = source['data'][:source['size']]
            dest['data'] = new
        else:
            if source['size'] < dest['size']:
                data[source['size']:dest['size']] = [None] * (dest['size'] - source['size'])
            if source['size'] > 0:
                data[:source['size']] = source['data'][:source['size']]
        dest['size'] = source['size']
    return dict(name=q['name'], token=q['token'], context=context, error=error,
                source_size=source['size'], source_data=source['data'], source_same=source['data'] is sa,
                dest_size=dest['size'], dest_data=dest['data'], dest_same=dest['data'] is da, dest_version=version)


results = {(r['name'], r['context']): r for r in observed['results']}
assert len(results) == 3 * len(cases)
model_diffs = []
for q in cases:
    for context in ['string', 'int32', 'wide24']:
        want = expected(q, context)
        actual = results[(q['name'], context)]
        delta = {k: [v, actual.get(k)] for k, v in want.items() if v != actual.get(k)}
        if delta:
            model_diffs.append(dict(name=q['name'], context=context, differences=delta))
native_file = P / 'NATIVE-GENERICS.json'
native_diffs = []
native_count = 0
if native_file.exists():
    native = json.loads(native_file.read_bytes())
    assert not native['callback_errors']
    for r in native['results']:
        native_count += 1
        actual = results[(r['name'], 'string')]
        delta = {k: [v, actual.get(k)] for k, v in r.items() if k != 'controlled_leaf_calls' and v != actual.get(k)}
        if delta:
            native_diffs.append(dict(name=r['name'], differences=delta))
report = dict(scope='FINITE_ACTUAL_DLL_CLOSED_GENERIC_OBSERVATIONS_VS_EXPECTATION_AND_ORIGINAL_NATIVE_REFERENCE_NORMAL_PATHS',
              candidate_sha256=observed['candidate_sha256'], methods=5, closed_contexts=3,
              jit_counts=dict(collections.Counter(r['status'] for r in observed['jit'])),
              actual_runtime_records=len(results), expected_state_mismatches=model_diffs,
              original_native_normal_cases=native_count, native_vs_candidate_mismatches=native_diffs,
              model_revision='System.List.Clear storage effect is element-kind dependent; retained first ref-only model mismatch report',
              native_exception_paths='UNSUPPORTED_NOT_EXECUTED', full_semantic_or_product_acceptance=False)
(P / 'GENERIC-COMPARISON.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, indent=2))
assert not model_diffs and not native_diffs
