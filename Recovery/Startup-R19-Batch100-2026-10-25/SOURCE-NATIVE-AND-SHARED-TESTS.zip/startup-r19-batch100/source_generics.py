"""Native SwfList and SwfAssocList recovery with legal closed-owner calls."""
from construction import IL
import source_common as s
def populate(c):
    assoc='FTRuntime.Internal.SwfAssocList`1<T>';lst='FTRuntime.Internal.SwfList`1<T>'
    for rid,delegate in [(0x8db,0x8ef),(0x8dc,0x8f0)]:
        signature=s.pe.net.mdtables.MethodDef.rows[delegate-1].Signature.value
        ref=c.closed_ref(lst,'AssignTo',signature)
        b=IL().arg(0).token(0x7b,c.fld(assoc,'_list')).arg(1).token(0x6f,ref).op('2a')
        c.add(rid,b,'Restore original public AssignTo delegation through the captured _list and correctly instantiated SwfList<T> owner; no cross-class private fields.',maxstack=2,group='generic-source')
    item=next(i for i in s.methods[s.tok(0x8eb)]['instructions'] if i['opcode']=='stelem.any');tt=s.operand_token(s.tok(0x8eb),item)
    assert tt>>24==27 and s.pe.net.mdtables.TypeSpec.rows[(tt&0xffffff)-1].Signature.value==bytes.fromhex('1300')
    b=IL().arg(1).arg(0).token(0x7b,c.fld(lst,'_size')).branch(0x44,'valid').token(0x73,c.meth('System.IndexOutOfRangeException','.ctor')).op('7a').mark('valid').arg(0).token(0x7b,c.fld(lst,'_data')).arg(1).arg(2).token(0xa4,tt).op('2a')
    c.add(0x8eb,b,'Restore the native unsigned index-vs-size rejection before touching _data, so negative index plus null data raises IndexOutOfRange rather than NullReference.',maxstack=3,group='generic-source')
    idx,sig=c.append_locals(0x8ee,[bytes.fromhex('1d1300')]);b=IL().arg(1).arg(0).token(0x7b,c.fld(lst,'_size')).branch(0x3f,'invalid').arg(1).arg(0).token(0x7b,c.fld(lst,'_data')).op('8e69').branch(0x3b,'done').arg(1).i4(0).branch(0x3d,'allocate')
    b.arg(0).token(0x7e,c.fld(lst,'_emptyData')).token(0x7d,c.fld(lst,'_data')).branch(0x38,'done').mark('allocate').arg(1).token(0x8d,tt).store(idx).arg(0).token(0x7b,c.fld(lst,'_size')).i4(0).branch(0x3e,'store')
    b.arg(0).token(0x7b,c.fld(lst,'_data')).loc(idx).arg(0).token(0x7b,c.fld(lst,'_size')).token(0x28,c.meth('System.Array','Copy',['System.Array','System.Array','System.Int32'])).mark('store').arg(0).loc(idx).token(0x7d,c.fld(lst,'_data')).branch(0x38,'done')
    b.mark('invalid').token(0x72,c.text(0x8ee,'capacity')).token(0x73,c.meth('System.ArgumentOutOfRangeException','.ctor',['System.String'])).op('7a').mark('done').op('2a')
    c.add(0x8ee,b,'Restore typed T[] allocation, unchanged-capacity early return, original capacity rejection and _emptyData selection; retain copy-before-field-write order.',maxstack=3,local_token=sig,group='generic-source')
    idx,sig=c.append_locals(0x8f0,[bytes.fromhex('1d1300'),bytes.fromhex('1d1300')]);dest=idx+1;b=IL().arg(1).token(0x7b,c.fld(lst,'_data')).store(dest).loc(dest).op('8e69').arg(0).token(0x7b,c.fld(lst,'_size')).branch(0x3f,'grow')
    b.arg(0).token(0x7b,c.fld(lst,'_size')).arg(1).token(0x7b,c.fld(lst,'_size')).branch(0x3c,'copy').loc(dest).arg(0).token(0x7b,c.fld(lst,'_size')).arg(1).token(0x7b,c.fld(lst,'_size')).arg(0).token(0x7b,c.fld(lst,'_size')).op('59').token(0x28,c.meth('System.Array','Clear',['System.Array','System.Int32','System.Int32']))
    b.mark('copy').arg(0).token(0x7b,c.fld(lst,'_size')).i4(0).branch(0x3e,'size').arg(0).token(0x7b,c.fld(lst,'_data')).arg(1).token(0x7b,c.fld(lst,'_data')).arg(0).token(0x7b,c.fld(lst,'_size')).token(0x28,c.meth('System.Array','Copy',['System.Array','System.Array','System.Int32'])).branch(0x38,'size')
    b.mark('grow').arg(0).token(0x7b,c.fld(lst,'_size')).arg(0).token(0x7b,c.fld(lst,'_size')).op('58').token(0x8d,tt).store(idx).arg(0).token(0x7b,c.fld(lst,'_data')).loc(idx).arg(0).token(0x7b,c.fld(lst,'_size')).token(0x28,c.meth('System.Array','Copy',['System.Array','System.Array','System.Int32'])).arg(1).loc(idx).token(0x7d,c.fld(lst,'_data'))
    b.mark('size').arg(1).arg(0).token(0x7b,c.fld(lst,'_size')).token(0x7d,c.fld(lst,'_size')).op('2a')
    c.add(0x8f0,b,'Restore real destination length, doubled-size typed allocation, tail clearing, copy ordering and final source-size reload, retaining alias behavior.',maxstack=4,local_token=sig,group='generic-source')
