"""Physical parent-body reverts in exact DLLs, executed in fresh processes.

Each reverted body's complete raw span and MethodDef RVA are restored; no
fixture-side method replacement. Process failure is retained, never a pass.
"""
from pathlib import Path
import concurrent.futures, hashlib, importlib.util, json, struct, subprocess, sys

Q = Path(__file__).resolve().parent
W = Q.parent
ROOT = W.parents[1]
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'audit/stage9-native3/python-deps'))
import dnfile

O = Q / 'shared-candidate5/generic-reverts'
O.mkdir(exist_ok=True)
sha = lambda b: hashlib.sha256(b).hexdigest()
base = (Q / 'candidate5.dll').read_bytes()
parent = (W / 'startup-r18-batch50/candidate1.dll').read_bytes()
ap, bp = dnfile.dnPE(data=parent), dnfile.dnPE(data=base)
spec = importlib.util.spec_from_file_location('body_reader_generic_reverts', ROOT / 'audit/native111-publication-2026-10-20/repository/scripts/actions/static_gates.py')
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)
reference = json.loads((Q / 'shared-candidate5/DIRECT-GENERICS.json').read_bytes())
expected = {(r['name'], r['context']): r for r in reference['results']}
dot = ROOT / '.local/dotnet10/dotnet.exe'
fixture = Q / 'direct-generics/bin/Release/net10.0/Fixture.dll'
support = ROOT / 'audit/bulk350-root-verification-2026-10-22/authentic-support'


def one(rid):
    token = f'0x{0x6000000 | rid:08X}'
    x, y = ap.net.mdtables.MethodDef.rows[rid - 1], bp.net.mdtables.MethodDef.rows[rid - 1]
    at = ap.get_offset_from_rva(x.Rva)
    count = reader.parse_raw_method_body_span(parent, at)[0]
    data = bytearray(base)
    data[at:at + count] = parent[at:at + count]
    struct.pack_into('<I', data, y.struct.get_file_offset(), x.Rva)
    file = O / (token + '.dll')
    file.write_bytes(data)
    output = O / (token + '.runtime.json')
    run = subprocess.run([str(dot), str(fixture), str(file), str(support), str(Q / 'GENERIC-CASES.json'), str(output)], capture_output=True, timeout=45)
    (O / (token + '.stdout.log')).write_bytes(run.stdout)
    (O / (token + '.stderr.log')).write_bytes(run.stderr)
    if run.returncode or not output.exists():
        return dict(token=token, physical_sha256=sha(data), status='PROCESS_FAILURE_NOT_SEMANTIC_DETECTION', exit_code=run.returncode)
    observed = json.loads(output.read_bytes())
    assert observed['candidate_sha256'] == sha(data)
    rows = [r for r in observed['results'] if r['token'] == token]
    delta = []
    for r in rows:
        want = expected[(r['name'], r['context'])]
        differences = {k: [v, r.get(k)] for k, v in want.items() if v != r.get(k)}
        if differences:
            delta.append(dict(name=r['name'], context=r['context'], differences=differences))
    (O / (token + '.differences.json')).write_text(json.dumps(delta, indent=2) + '\n', encoding='utf-8')
    return dict(token=token, physical_sha256=sha(data), status='RUNTIME_DIFFERENCE_DETECTED' if delta else 'NO_RUNTIME_DIFFERENCE',
                records=len(rows), differences=len(delta), only_one_parent_body_and_its_rva_restored=True,
                jit=next(r for r in observed['jit'] if r['token'] == token))


with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    results = list(pool.map(one, [0x8db, 0x8dc, 0x8eb, 0x8ee, 0x8f0]))
report = dict(scope='FIVE_PHYSICAL_PARENT_BODY_REVERT_CONTROLS_ON_UNMODIFIED_ACTUAL_DLL_FIXTURE',
              candidate_sha256=sha(base), results=results, semantic_or_product_acceptance=False)
(O.parent / 'GENERIC-REVERT-CONTROLS.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, indent=2))
assert all(r['status'] == 'RUNTIME_DIFFERENCE_DETECTED' for r in results)
