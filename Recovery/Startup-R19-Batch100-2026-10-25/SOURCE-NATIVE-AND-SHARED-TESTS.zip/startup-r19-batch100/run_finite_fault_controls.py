"""Physical behavior faults for the other 45 methods with finite profiles.

Each keeps metadata/flags/branches fixed or restores one exact historical body.
No process failure or undecided runtime record is accepted as semantic detection.
"""
from pathlib import Path
import concurrent.futures,hashlib,importlib.util,json,struct,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];stem=sys.argv[1] if len(sys.argv)>1 else 'candidate9';supplement=sys.argv[2] if len(sys.argv)>2 else '';assert supplement in ['', 'frame-supplement','device-supplement'];P=Q/('shared-'+stem);O=P/('finite-faults-'+supplement if supplement else 'finite-faults');O.mkdir(exist_ok=True);sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
base=(Q/(stem+'.dll')).read_bytes();pe=dnfile.dnPE(data=base);cil=json.loads((P/'ALL-CIL.json').read_bytes());methods={m['token']:m for m in cil['methods']};sha=lambda b:hashlib.sha256(b).hexdigest()
spec=importlib.util.spec_from_file_location('fault_body_reader',ROOT/'audit/native111-publication-2026-10-20/repository/scripts/actions/static_gates.py');reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
dot=ROOT/'.local/dotnet10/dotnet.exe';support=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'
ctor=json.loads((P/'NATIVE-CONSTRUCTORS.json').read_bytes());leaf=json.loads((P/'NATIVE-LEAVES.json').read_bytes());state=json.loads((P/'NATIVE-STATE.json').read_bytes());phone=json.loads((P/'NATIVE-PHONE.json').read_bytes())
ctor_targets={int(x['token'],16)&0xffffff for x in ctor['results']};leaf_targets={int(x,16)&0xffffff for x in leaf['per_method']};state_targets={int(x['token'],16)&0xffffff for x in state['results']}
modeled={0x190,0x27e,0x2ed,0x4e6}

def location(raw,metadata,rid):
 row=metadata.net.mdtables.MethodDef.rows[rid-1];at=metadata.get_offset_from_rva(row.Rva);h=1 if raw[at]&3==2 else (struct.unpack_from('<H',raw,at)[0]>>12)*4;return at,h

def mutation(rid):
 token=f'0x{0x6000000|rid:08X}';m=methods[token];at,h=location(base,pe,rid);data=bytearray(base);start=at+h;kind=''
 if supplement:
  assert rid in ([0x2fb] if supplement=='device-supplement' else [0x854,0x855])
  field='ID' if supplement=='device-supplement' else 'Labels'
  sites=[i for i in m['instructions'] if i['opcode']=='stfld' and i['operand']['identity'].endswith('::'+field)];assert len(sites)==(1 if supplement=='device-supplement' else 2)
  for i in sites:
   pos=start+i['offset'];assert data[pos]==0x7d;data[pos:pos+5]=bytes.fromhex('2626000000')
  kind='Omit supplied Device ID store; overwritten initial camp-store non-detection retained' if supplement=='device-supplement' else 'Omit both Labels stores; original first-overwritten-store-only non-detection remains retained'
 elif rid in ctor_targets:
  ins=next(i for i in m['instructions'] if i['opcode']=='stfld');pos=start+ins['offset'];assert data[pos]==0x7d;data[pos:pos+5]=bytes.fromhex('2626000000');kind='Omit first actual initializer store while balancing its two inputs'
 elif rid in [0x728,0x42b]:
  old=(Q/('candidate5.dll' if rid==0x728 else 'candidate7.dll')).read_bytes();oldpe=dnfile.dnPE(data=old);oa,oh=location(old,oldpe,rid);n=reader.parse_raw_method_body_span(old,oa)[0];assert oa==at;data[at:at+n]=old[oa:oa+n];kind='Restore observed incorrect phone join' if rid==0x728 else 'Restore observed post-Time shootingTime read'
 elif rid==0x144:
  ins=[i for i in m['instructions'] if i['opcode']=='ldstr'];a,b=ins[:2];pa,pb=start+a['offset'],start+b['offset'];assert data[pa]==data[pb]==0x72;data[pa+1:pa+5]=data[pb+1:pb+5];kind='Replace default painter by another valid painter literal'
 elif rid in [0x18f,0x4d0]:
  i=next(i for i in m['instructions'] if i['opcode']=='ldc.i4');pos=start+i['offset'];assert data[pos]==0x20;v=struct.unpack_from('<i',data,pos+1)[0];struct.pack_into('<i',data,pos+1,v+1);kind='Shift device selector' if rid==0x18f else 'Start talent-name scan at index one'
 elif rid==0x257:
  i=next(i for i in m['instructions'] if i['opcode']=='ldc.r8');pos=start+i['offset'];assert data[pos]==0x23;v=struct.unpack_from('<d',data,pos+1)[0];struct.pack_into('<d',data,pos+1,v*1.5);kind='Change the real supply exponential coefficient'
 elif rid in [0x428,0x499]:
  i=next(i for i in m['instructions'] if i['opcode']=='call' and i['operand']['name']=='IsDisabled');pos=start+i['offset'];assert data[pos]==0x28;data[pos:pos+5]=bytes.fromhex('2617000000');kind='Suppress the real disability callback and force disabled'
 elif rid in [0x42c,0x381]:
  i=next(i for i in m['instructions'] if i['opcode']=='add');pos=start+i['offset'];assert data[pos]==0x58;data[pos]=0x59;kind='Replace one real float addition with subtraction'
 else:
  choices=[i for i in m['instructions'] if i['opcode']=='ldc.r4' and struct.unpack_from('<f',data,start+i['offset']+1)[0] not in [0,1]]
  assert choices,(token,'No genuine nonzero coefficient');i=choices[0];pos=start+i['offset'];assert data[pos]==0x22;v=struct.unpack_from('<f',data,pos+1)[0];struct.pack_into('<f',data,pos+1,v/2);kind='Change one actual float threshold or multiplier'
 assert data!=base
 return data,kind

def one(rid):
 token=f'0x{0x6000000|rid:08X}';data,kind=mutation(rid);file=O/(token+'.dll');file.write_bytes(data);output=O/(token+'.runtime.json');
 if rid in ctor_targets:
  fixture=Q/('runtime-constructors' if rid in modeled else 'direct-constructors')/'bin/Release/net10.0/Fixture.dll';args=[str(dot),str(fixture),str(file),str(support)]
  if rid not in modeled:args.append(str(Q/(stem+'.json')))
  args.append(str(output));expected={(r['token'],r['value']):dict(error=None,state=r['state']) for r in ctor['results']};key=lambda r:(r['token'],r['value']);select=lambda r:r['token']==token;normalize=lambda r:dict(error=r['error'] or r.get('snapshot_error'),state=r['state'])
 else:
  name,case,reference=('direct-leaves','LEAF-CASES.json',leaf) if rid in leaf_targets else ('runtime-phone','PHONE-CASES.json',phone) if rid==0x728 else ('runtime-state','STATE-CASES.json',state)
  fixture=Q/name/'bin/Release/net10.0/Fixture.dll';args=[str(dot),str(fixture),str(file),str(support),str(Q/case),str(output)]
  expected={r['name']:r for r in reference['results']};key=lambda r:r['name'];select=lambda r:rid==0x728 or r['token']==token;normalize=lambda r:r
 run=subprocess.run(args,capture_output=True,timeout=90);(O/(token+'.stdout.log')).write_bytes(run.stdout);(O/(token+'.stderr.log')).write_bytes(run.stderr)
 if run.returncode or not output.exists():return dict(token=token,physical_sha256=sha(data),fault=kind,status='PROCESS_FAILURE_NOT_SEMANTIC_DETECTION',exit_code=run.returncode)
 observed=json.loads(output.read_bytes());assert observed['candidate_sha256']==sha(data);diff=[];count=0
 for row in observed['results']:
  if not select(row) or key(row) not in expected:continue
  count+=1;want=expected[key(row)];actual=normalize(row)
  if want!=actual:diff.append(dict(key=key(row),original=want,actual=actual))
 (O/(token+'.differences.json')).write_text(json.dumps(diff,indent=2)+'\n',encoding='utf-8')
 return dict(token=token,physical_sha256=sha(data),fault=kind,status='RUNTIME_DIFFERENCE_DETECTED' if diff else 'NO_RUNTIME_DIFFERENCE',compared_records=count,different_records=len(diff),scope='Declared finite body/snapshot profile, with existing controlled leaf and cctor/base boundaries')

targets=([0x2fb] if supplement=='device-supplement' else [0x854,0x855]) if supplement else sorted(ctor_targets|leaf_targets|state_targets|{0x728});assert len(targets)==((1 if supplement=='device-supplement' else 2) if supplement else 45)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 results=[]
 for r in pool.map(one,targets):results.append(r);print(json.dumps(r),flush=True)
report=dict(scope='SUPPLEMENTARY_DEVICE_ID_FIELD_FAULT' if supplement=='device-supplement' else 'SUPPLEMENTARY_TWO_FRAME_LABEL_FIELD_FAULTS' if supplement else 'FORTY_FIVE_PHYSICAL_BEHAVIOR_FAULTS_VS_ORIGINAL_REFERENCE_PROFILES',candidate_sha256=sha(base),controls=len(results),runtime_detected=sum(r['status']=='RUNTIME_DIFFERENCE_DETECTED' for r in results),process_failures=sum(r['status']=='PROCESS_FAILURE_NOT_SEMANTIC_DETECTION' for r in results),results=results,formal_or_product_acceptance=False)
(P/('SUPPLEMENTARY-DEVICE-FAULT-CONTROLS.json' if supplement=='device-supplement' else 'SUPPLEMENTARY-FRAME-FAULT-CONTROLS.json' if supplement else 'FINITE-FAULT-CONTROLS.json')).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');assert report['runtime_detected']==len(targets) and not report['process_failures']
