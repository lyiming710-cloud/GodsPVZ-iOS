"""Restore legal public calls at inlined private-member sites."""
import struct,json
from construction import IL
import source_common as s
def populate(c):
    zeroes={0x30a:[0xb,0x54,0x111],0x315:[0x7c,0xbc],0x319:[0x4b,0x8b,0xf9,0x149],0x423:[0xb,0x54,0x109,0x149,0x1f8,0x261],0x48d:[0x146,0x197,0x269,0x285],0x626:[0x170,0x20e,0x370,0x387,0x457,0x569,0x5b4,0x612]}
    targets=set(zeroes)|{0x6f,0x333,0x3a5,0x3e4,0x578,0x579,0x584,0x5cf,0x70f}
    clear_methods={0x6f,0x3a5,0x578,0x579,0x584,0x5cf}
    for rid in sorted(targets):
        token=s.tok(rid);m=s.methods[token];ins=m['instructions'];code=bytearray(s.body(token)['code']);reasons=[]
        for at in zeroes.get(rid,[]):
            assert code[at:at+5]==b'\x20\0\0\0\0',(token,hex(at));code[at:at+5]=b'\x22\0\0\0\0'
        if rid in zeroes:reasons.append('Restore Single zero at documented native COMISS sites; preserve all Boolean/integer zero sites.')
        if rid in clear_methods:
            starts=[k for k,i in enumerate(ins) if i['opcode']=='ldfld' and i['operand']['identity'].endswith('::_version')]
            assert starts
            for k in starts:
                first=ins[k-1];assert first['opcode']=='ldloc';start=first['offset'];local=first['operand']['index'];owner=ins[k]['operand']['owner']
                arrayclear=next(j for j in range(k,len(ins)) if ins[j]['opcode']=='call' and ins[j]['operand']['owner']=='System.Array' and ins[j]['operand']['name']=='Clear')
                ending=next(j for j in range(arrayclear+1,len(ins)) if ins[j]['opcode']=='br');last=ins[ending];end=last['offset']+5;exit_=last['operand']['target']
                for i in ins:
                    if start<=i['offset']<end:continue
                    destinations=[i['operand']['target']] if i['opcode'].startswith('br') and isinstance(i['operand'],dict) and 'target' in i['operand'] else i['operand'].get('targets',[]) if i['opcode']=='switch' else []
                    assert all(not start<t<end for t in destinations),(token,hex(start),i)
                replacement=IL().loc(local).token(0x6f,c.closed_ref(owner,'Clear',bytes.fromhex('200001'))).finish()
                replacement+=b'\x38'+struct.pack('<i',exit_-(start+len(replacement)+5))
                assert len(replacement)<=end-start;code[start:end]=replacement+b'\0'*(end-start-len(replacement))
            reasons.append('Replace broken inlined List.Clear private-field mutation with the real public Clear call, preserving entry/exit branch targets and captured receiver.')
        for i in ins:
            if i['opcode'] in ['call','callvirt'] and i['operand']['owner']=='UnityEngine.Transform' and i['operand']['name']=='set_parentInternal':
                original=s.operand_token(token,i);sig=s.pe.net.mdtables.MemberRef.rows[(original&0xffffff)-1].Signature.value
                ref=c.public_ref('UnityEngine.Transform','set_parent',sig);at=i['offset'];code[at:at+5]=b'\x6f'+struct.pack('<I',ref)
                reasons.append('Use public Transform.parent with the original world-position-preserving SetParent contract.')
            if i['opcode'] in ['ldfld','ldflda'] and i['operand']['owner']=='Zombie' and i['operand']['identity'].endswith('::previousPosition'):
                if i['opcode']=='ldflda':
                    following=ins[ins.index(i)+1];assert following['opcode']=='ldfld' and following['operand']['owner']=='UnityEngine.Vector3'
                at=i['offset'];code[at:at+5]=b'\x6f'+struct.pack('<I',c.meth('Zombie','PreviousPosition'))
                reasons.append('Call the existing public Vector3 PreviousPosition accessor instead of reading another class private field.')
            if i['opcode']=='ldsfld' and i['operand']['owner']=='UnityEngine.Quaternion' and i['operand']['identity'].endswith('::identityQuaternion'):
                getter=c.meth('UnityEngine.Quaternion','get_identity');at=i['offset'];code[at:at+5]=b'\x28'+struct.pack('<I',getter)
                reasons.append('Use Quaternion.identity getter instead of the SDK private backing field.')
            if i['opcode']=='ldfld' and i['operand']['owner']=='UnityEngine.UI.Image' and i['operand']['identity'].endswith('::m_FillAmount'):
                getter=c.public_ref('UnityEngine.UI.Image','get_fillAmount',bytes.fromhex('20000c'));at=i['offset'];code[at:at+5]=b'\x6f'+struct.pack('<I',getter)
                reasons.append('Use public Image.fillAmount getter, which loads the same field.')
        c.add(rid,code,' '.join(dict.fromkeys(reasons)),group='native-numeric-and-legal-access')
