using System.Collections;using System.Reflection;using System.Runtime.CompilerServices;using System.Runtime.Loader;using System.Security.Cryptography;using System.Text.Json;
public static class Program
{
    const BindingFlags BF=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance|BindingFlags.Static;
    static Assembly Game=null!;
    static string Name(Type t)=>t.FullName!.Replace('+','/');
    static Exception Root(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;return e;}
    static object? Snapshot(object? o,int depth=0)
    {
        if(o==null)return null;Type t=o.GetType();if(o is string||o is bool||o is int||o is long||o is uint||o is short||o is byte)return o;
        if(t.IsEnum)return Convert.ToInt64(o);
        if(o is float f)return new{f32=BitConverter.SingleToUInt32Bits(f).ToString("X8")};
        if(o is double d)return new{f64=BitConverter.DoubleToUInt64Bits(d).ToString("X16")};
        if(o is Array a){Type e=t.GetElementType()!;object? zero=e.IsValueType?Activator.CreateInstance(e):null;bool defaults=a.Cast<object?>().All(v=>Equals(v,zero));return new{kind="array",length=a.Length,all_default=defaults};}
        if(t.IsGenericType&&t.GetGenericTypeDefinition()==typeof(List<>))return new{kind="list",count=((IList)o).Count,capacity=(int)t.GetProperty("Capacity")!.GetValue(o)!};
        if(Name(t)=="Map")return new{type="Map",controlled_scope="presence_and_caller_written_cameraSize",cameraSize=Snapshot(t.GetField("cameraSize",BF)!.GetValue(o),depth+1)};
        if(depth>=5)return new{type=Name(t),depth_limited=true};
        return new{type=Name(t),fields=t.GetFields(BF|BindingFlags.DeclaredOnly).Where(f=>!f.IsStatic).OrderBy(f=>f.MetadataToken).ToDictionary(f=>f.Name,f=>Snapshot(f.GetValue(o),depth+1))};
    }
    static object? Argument(Type t,int value)
    {
        if(t==typeof(int))return value;if(t.IsEnum)return Enum.ToObject(t,value);
        if(t.IsArray){Array a=Array.CreateInstance(t.GetElementType()!,2);if(t.GetElementType()==typeof(string)){a.SetValue("alpha",0);a.SetValue("beta",1);}return a;}
        return RuntimeHelpers.GetUninitializedObject(t);
    }
    public static void Main(string[] args)
    {
        string file=Path.GetFullPath(args[0]),support=Path.GetFullPath(args[1]);var alc=new AssemblyLoadContext("ExactR19Constructors_"+Guid.NewGuid(),true);
        alc.Resolving+=(c,n)=>{foreach(string ext in new[]{".dll",".exe"}){string path=Path.Combine(support,n.Name+ext);if(!File.Exists(path))continue;if(AssemblyName.GetAssemblyName(path).FullName!=n.FullName)throw new FileLoadException("Identity mismatch "+path);return c.LoadFromAssemblyPath(path);}return null;};
        Game=alc.LoadFromAssemblyPath(file);using var report=JsonDocument.Parse(File.ReadAllText(args[2]));var rows=new List<object>();
        foreach(var q in report.RootElement.GetProperty("changes").EnumerateArray().Where(q=>q.GetProperty("group").GetString()=="constructors"))
        {
            string token=q.GetProperty("token").GetString()!;var ctor=(ConstructorInfo)Game.ManifestModule.ResolveMethod(Convert.ToInt32(token,16))!;
            foreach(int value in ctor.GetParameters().Length==0?new[]{0}:new[]{-1,0,7,int.MaxValue})
            {
                string? error=null,snapshotError=null;object? obj=null,state=null;try{obj=ctor.Invoke(ctor.GetParameters().Select(p=>Argument(p.ParameterType,value)).ToArray());}catch(Exception e){error=Root(e).ToString();}
                if(obj!=null)try{state=Snapshot(obj);}catch(Exception e){snapshotError=Root(e).ToString();}
                rows.Add(new{token,value,error,snapshot_error=snapshotError,state});
            }
        }
        var contracts=Game.GetTypes().Where(t=>!t.ContainsGenericParameters).ToDictionary(Name,t=>new{token="0x"+t.MetadataToken.ToString("X8"),fields=t.GetFields(BF|BindingFlags.DeclaredOnly).Where(f=>!f.IsStatic).Select(f=>new{name=f.Name,token="0x"+f.MetadataToken.ToString("X8"),type=Name(f.FieldType),is_enum=f.FieldType.IsEnum,is_value=f.FieldType.IsValueType}).ToArray()});
        File.WriteAllText(args[3],JsonSerializer.Serialize(new{scope="DIRECT_ACTUAL_DLL_CONSTRUCTORS_ZERO_INITIALIZED_OBJECTS_FIELD_SNAPSHOTS",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(file))).ToLowerInvariant(),reflection_emit_used=false,cil_rewritten=false,results=rows,contracts,limitations=new[]{"Field snapshots do not observe allocation order or memory exhaustion","Unity base constructors may be unsupported outside Unity","This is not a player run"}},new JsonSerializerOptions{WriteIndented=true}));
        Console.WriteLine(JsonSerializer.Serialize(new{methods=29,records=rows.Count}));
    }
}
