using System.Collections;using System.Reflection;using System.Runtime.CompilerServices;using System.Runtime.Loader;using System.Security.Cryptography;using System.Text.Json;
public record struct WideValue(long A,long B,long C);
public static class Program
{
    const BindingFlags BF=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance|BindingFlags.Static;
    static FieldInfo F(Type t,string n)=>t.GetField(n,BF)!;
    static Exception Root(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;return e;}
    static object? Value(Type t,int n)=>t==typeof(string)?"v"+n:t==typeof(int)?100+n:new WideValue(100+n,200+n,300+n);
    static string? Label(object? v)=>v switch{null=>null,string x=>x,int x=>x==0?null:"v"+(x-100),WideValue x=>x==default?null:"v"+(x.A-100),_=>throw new Exception("Unexpected value type")};
    static Array Values(Type t,int n,int start){var a=Array.CreateInstance(t,n);for(int k=0;k<n;k++)a.SetValue(Value(t,start+k),k);return a;}
    public static void Main(string[] args)
    {
        string file=Path.GetFullPath(args[0]),support=Path.GetFullPath(args[1]);var alc=new AssemblyLoadContext("ExactR19Closed_"+Guid.NewGuid(),true);
        alc.Resolving+=(c,n)=>{foreach(string ext in new[]{".dll",".exe"}){string path=Path.Combine(support,n.Name+ext);if(!File.Exists(path))continue;if(AssemblyName.GetAssemblyName(path).FullName!=n.FullName)throw new FileLoadException("Identity mismatch "+path);return c.LoadFromAssemblyPath(path);}return null;};
        var asm=alc.LoadFromAssemblyPath(file);using var cases=JsonDocument.Parse(File.ReadAllText(args[2]));var rows=new List<object>();var jit=new List<object>();
        foreach(Type element in new[]{typeof(string),typeof(int),typeof(WideValue)})
        {
            Type list=asm.GetType("FTRuntime.Internal.SwfList`1",true)!.MakeGenericType(element),assoc=asm.GetType("FTRuntime.Internal.SwfAssocList`1",true)!.MakeGenericType(element),system=typeof(List<>).MakeGenericType(element);
            foreach(int token in new[]{0x060008DB,0x060008DC,0x060008EB,0x060008EE,0x060008F0})
            {
                var method=(token==0x060008DB||token==0x060008DC?assoc:list).GetMethods(BF).Single(m=>m.MetadataToken==token);
                try{RuntimeHelpers.PrepareMethod(method.MethodHandle);jit.Add(new{token="0x"+token.ToString("X8"),context=element.FullName,status="JIT_PREPARED_NO_EXECUTION",il_sha256=Convert.ToHexString(SHA256.HashData(method.GetMethodBody()!.GetILAsByteArray()!)).ToLowerInvariant()});}
                catch(Exception e){jit.Add(new{token="0x"+token.ToString("X8"),context=element.FullName,status="REJECTED",error=Root(e).ToString()});}
            }
            foreach(var q in cases.RootElement.EnumerateArray())
            {
                string name=q.GetProperty("name").GetString()!,tokenText=q.GetProperty("token").GetString()!;int token=Convert.ToInt32(tokenText,16);int sl=q.GetProperty("source_length").GetInt32(),ss=q.GetProperty("source_size").GetInt32(),dl=q.GetProperty("dest_length").GetInt32(),ds=q.GetProperty("dest_size").GetInt32();
                Array sourceArray=Values(element,sl,0),destArray=Values(element,dl,20);object source=RuntimeHelpers.GetUninitializedObject(list),destination=RuntimeHelpers.GetUninitializedObject(token==0x060008DB?system:list);
                F(list,"_data").SetValue(source,q.GetProperty("null_data").GetBoolean()?null:sourceArray);F(list,"_size").SetValue(source,ss);
                if(q.GetProperty("shared_array").GetBoolean())destArray=sourceArray;
                if(token==0x060008DB){F(system,"_items").SetValue(destination,destArray);F(system,"_size").SetValue(destination,ds);F(system,"_version").SetValue(destination,7);}
                else{F(list,"_data").SetValue(destination,destArray);F(list,"_size").SetValue(destination,ds);}
                if(q.GetProperty("alias").GetBoolean())destination=source;
                object receiver=source;if(token==0x060008DB||token==0x060008DC){receiver=RuntimeHelpers.GetUninitializedObject(assoc);F(assoc,"_list").SetValue(receiver,source);}
                var method=receiver.GetType().GetMethods(BF).Single(m=>m.MetadataToken==token);string? error=null;
                try
                {
                    object?[] callArgs=token==0x060008EB?new object?[]{q.GetProperty("argument").GetInt32(),Value(element,99)}:token==0x060008EE?new object?[]{q.GetProperty("argument").GetInt32()}:new object?[]{q.GetProperty("null_destination").GetBoolean()?null:destination};method.Invoke(receiver,callArgs);
                }
                catch(Exception e){error=Root(e).GetType().FullName;}
                Array? sa=(Array?)F(list,"_data").GetValue(source);Type dt=destination.GetType();Array? da=(Array?)F(dt,token==0x060008DB?"_items":"_data").GetValue(destination);
                rows.Add(new{name,token=tokenText,context=element==typeof(string)?"string":element==typeof(int)?"int32":"wide24",error,source_size=(int)F(list,"_size").GetValue(source)!,source_data=sa?.Cast<object?>().Select(Label).ToArray(),source_same=ReferenceEquals(sa,sourceArray),dest_size=(int)F(dt,"_size").GetValue(destination)!,dest_data=da?.Cast<object?>().Select(Label).ToArray(),dest_same=ReferenceEquals(da,destArray),dest_version=token==0x060008DB?(int?)F(dt,"_version").GetValue(destination):null});
            }
        }
        var report=new{scope="DIRECT_UNMODIFIED_ACTUAL_DLL_FIVE_CLOSED_GENERIC_METHODS_FINITE_CASES",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(file))).ToLowerInvariant(),reflection_emit_used=false,cil_rewritten=false,jit,results=rows,unity_execution=false};File.WriteAllText(args[3],JsonSerializer.Serialize(report,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{methods=5,closed_contexts=3,records=rows.Count,jit_records=jit.Count}));alc.Unload();
    }
}
