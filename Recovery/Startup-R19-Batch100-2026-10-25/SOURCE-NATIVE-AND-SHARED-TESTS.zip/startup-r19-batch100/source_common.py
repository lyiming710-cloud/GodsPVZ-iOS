"""Immutable source inspection helpers. Importing executes no validation suites."""
from pathlib import Path
import hashlib, json, struct, sys
Q=Path(__file__).resolve().parent; W=Q.parent; ROOT=W.parents[1]
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile, pefile
from capstone import Cs,CS_ARCH_X86,CS_MODE_64,CS_GRP_RET,CS_GRP_JUMP
from capstone.x86_const import X86_OP_IMM
sha=lambda data:hashlib.sha256(data).hexdigest()
parent=(W/'startup-r18-batch50/candidate1.dll').read_bytes()
assert sha(parent)=='a6aa9f91087db194251c4c989fd80ffd982b3b7a59413b0745592bc43b548abb'
pe=dnfile.dnPE(data=parent)
cil=json.loads((W/'startup-r18-batch50/ALL-CIL.json').read_bytes())
methods={m['token']:m for m in cil['methods']}
I=ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs'
raw=(I/'original-pc/GameAssembly.dll').read_bytes()
assert sha(raw)=='9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d'
pc=pefile.PE(data=raw);base=pc.OPTIONAL_HEADER.ImageBase
field_rows=json.loads((I/'maps/native-fields.json').read_text('utf-8-sig'))
field_map={int(r['token'],16):r for r in field_rows}
dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True
def tok(rid):return f'0x{0x6000000|rid:08X}'
def pointer(token):return int.from_bytes(pc.get_data(0x181b82d60-base+((int(token,16)&0xffffff)-1)*8,8),'little')
def body(token):
    row=pe.net.mdtables.MethodDef.rows[(int(token,16)&0xffffff)-1];at=pe.get_offset_from_rva(row.Rva)
    h=1 if parent[at]&3==2 else (struct.unpack_from('<H',parent,at)[0]>>12)*4
    n=parent[at]>>2 if h==1 else struct.unpack_from('<I',parent,at+4)[0]
    return dict(offset=at,header=h,code_size=n,code=parent[at+h:at+h+n])
def operand_token(token,ins):
    b=body(token)['code'];at=ins['offset']
    prefix=2 if b[at]==0xfe else 1
    return int.from_bytes(b[at+prefix:at+prefix+4],'little')
def native(token=None,entry=None,complete=False):
    entry=entry or pointer(token)
    assert entry
    fn=next(x.struct for x in pc.DIRECTORY_ENTRY_EXCEPTION if x.struct.BeginAddress<=entry-base<x.struct.EndAddress)
    runtime_end=base+fn.EndAddress
    bound=min(pointer(tok(n)) for n in range(1,len(pe.net.mdtables.MethodDef.rows)+1) if pointer(tok(n))>entry) if complete else runtime_end
    end=bound; pending=[entry]; ins={};outside=[];indirect=[];crossings=set()
    while pending:
        at=pending.pop()
        while at not in ins:
            if not entry<=at<end:
                outside.append(dict(target=hex(at),kind='OUTSIDE_DECLARED_RUNTIME_FUNCTION'));break
            if at>=runtime_end:crossings.add(at)
            i=next(dis.disasm(pc.get_data(at-base,15),at));ins[at]=i
            assert len(ins)<2000
            if i.group(CS_GRP_RET) or i.mnemonic in ['int3','ud2']:break
            if i.group(CS_GRP_JUMP):
                if i.operands[0].type==X86_OP_IMM:
                    target=i.operands[0].imm
                    if entry<=target<end:pending.append(target)
                    else:outside.append(dict(source=hex(at),target=hex(target),kind='EXTERNAL_TAIL_OR_SEPARATE_FUNCLET_REVIEW'))
                else:indirect.append(dict(source=hex(at),operand=i.op_str))
                if i.mnemonic=='jmp':break
            at+=i.size
    return dict(token=token,entry=hex(entry),runtime_begin=hex(base+fn.BeginAddress),runtime_end=hex(runtime_end),next_distinct_method_pointer=hex(bound) if complete else None,
        scope='METHOD_POINTER_BOUNDED_CFG_WITH_EXPLICIT_PDATA_CROSSINGS_AND_EXTERNAL_TAILS' if complete else 'DECLARED_RUNTIME_FUNCTION_CFG_EXPLICIT_UNFOLLOWED_BOUNDARIES',
        instructions=[dict(va=hex(i.address),op=i.mnemonic,operands=i.op_str,bytes=i.bytes.hex()) for i in sorted(ins.values(),key=lambda i:i.address)],
        outside_boundaries=outside,indirect_jumps=indirect,pdata_crossing_instruction_count=len(crossings))
def save_native(token,complete=False):
    d=Q/('native-source-complete' if complete else 'native-source');d.mkdir(exist_ok=True);cfg=native(token,complete=complete)
    (d/(token+'.json')).write_bytes((json.dumps(cfg,indent=2)+'\n').encode())
    (d/(token+'.txt')).write_text('\n'.join(f"{x['va']} {x['op']} {x['operands']}" for x in cfg['instructions'])+'\n')
    (Q/(token+'.parent-cil.json')).write_bytes((json.dumps(methods[token],indent=2)+'\n').encode())
    return cfg
