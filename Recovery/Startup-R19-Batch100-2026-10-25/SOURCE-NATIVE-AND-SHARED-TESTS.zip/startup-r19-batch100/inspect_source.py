"""Compact source reading only; never executes a candidate or a verifier."""
import sys, json
import source_common as s
for a in sys.argv[1:]:
    token = s.tok(int(a,16))
    m=s.methods[token]
    print('\n###',token,m['name'],'args=',m['args'],'locals=',m['locals'])
    if m['handlers']: print('EH',m['handlers'])
    for i in m['instructions']:
        v=i['operand']
        if isinstance(v,dict):
            if 'identity' in v: v=v['identity']
            elif 'owner' in v: v=v['owner']+'::'+v.get('name','')+'('+','.join(v.get('args',[]))+')->'+v.get('ret','')
        print(f"{i['offset']:04x} {i['opcode']} {v if v is not None else ''}")
