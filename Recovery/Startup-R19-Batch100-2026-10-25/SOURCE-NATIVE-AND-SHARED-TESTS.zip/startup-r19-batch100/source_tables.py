"""Decode original embedded dispatch tables and literal slots; source only."""
import struct,json
import source_common as s
TABLES={0x144:(0x18031ba90,9),0x18f:(0x180312cf4,11),0x3c2:(0x1803763bc,9),0x445:(0x180360884,20),0x56d:(0x18038a9ec,8),0x609:(0x180394acc,26),0x4d0:(0x180376114,7),0x453:(0x180361fc8,6),0x728:(0x1803b676c,14)}
metadata=(s.I/'original-pc/global-metadata.dat').read_bytes()
def literal(slot):
    encoded=int.from_bytes(s.pc.get_data(slot-s.base,4),'little');assert encoded>>29==5,(hex(slot),hex(encoded))
    index=(encoded&0x1fffffff)>>1
    table,size,data,n=struct.unpack_from('<4I',metadata,8);assert index<size//8
    length,off=struct.unpack_from('<II',metadata,table+index*8)
    value=metadata[data+off:data+off+length].decode('utf-8')
    return dict(slot=hex(slot),encoded=hex(encoded),index=index,value=value)
def rip_value(i):
    return i.address+i.size+i.operands[-1].mem.disp
def main():
    report={}
    for rid,(va,n) in TABLES.items():
        token=s.tok(rid);start=s.pointer(token);stop=min(s.pointer(s.tok(k)) for k in range(1,2318) if s.pointer(s.tok(k))>start)
        raw=s.pc.get_data(va-s.base,n*4);targets=[s.base+v for v in struct.unpack('<'+'I'*n,raw)]
        assert all(start<=v<stop for v in targets)
        pending=[start,*targets];seen={};outside=[];indirect=[]
        while pending:
            at=pending.pop()
            while at not in seen and start<=at<stop:
                i=next(s.dis.disasm(s.pc.get_data(at-s.base,15),at));seen[at]=dict(va=hex(at),op=i.mnemonic,operands=i.op_str,bytes=i.bytes.hex())
                if i.mnemonic in ['ret','int3','ud2']:break
                if i.group(s.CS_GRP_JUMP):
                    if i.operands[0].type==s.X86_OP_IMM:
                        target=i.operands[0].imm
                        if start<=target<stop:pending.append(target)
                        else:outside.append(dict(source=hex(at),target=hex(target)))
                    else:indirect.append(dict(source=hex(at),operand=i.op_str,table_targets_seeded=True))
                    if i.mnemonic=='jmp':break
                at+=i.size
        details=dict(table_va=hex(va),count=n,table_bytes=raw.hex(),targets=[hex(v) for v in targets])
        if rid==0x144:
            details['literals']=[]
            for address in [*targets,0x18031ba82]:
                i=next(s.dis.disasm(s.pc.get_data(address-s.base,15),address));assert i.mnemonic=='mov' and i.op_str.startswith('rax, qword ptr [rip')
                details['literals'].append(literal(rip_value(i)))
        if rid==0x18f:
            details['values']=[int(next(s.dis.disasm(s.pc.get_data(at-s.base,15),at)).operands[1].imm) if at!=0x180312cee else 0 for at in targets]
        report[token]=details
        evidence=dict(token=token,entry=hex(start),bound=hex(stop),scope='ORIGINAL_SOURCE_CFG_WITH_EXPLICIT_EMBEDDED_SWITCH_TABLE_TARGETS',tables=[details],instructions=[seen[k] for k in sorted(seen)],outside_boundaries=outside,indirect_jumps=indirect)
        d=s.Q/'native-source-complete';(d/(token+'.json')).write_text(json.dumps(evidence,indent=2)+'\n',encoding='utf-8');(d/(token+'.txt')).write_text('\n'.join(f"{v['va']} {v['op']} {v['operands']}" for k,v in sorted(seen.items()))+'\n')
    (s.Q/'ORIGINAL-SWITCH-TABLES.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=1,ensure_ascii=False))
if __name__=='__main__':main()
