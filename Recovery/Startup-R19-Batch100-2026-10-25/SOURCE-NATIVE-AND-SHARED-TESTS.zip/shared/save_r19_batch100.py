"""Publish an honest hundred-method construction and partial shared-test checkpoint."""
from pathlib import Path
import collections,json
from archive_support import sha,js,pack,variants,manifest
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';Q=W/'startup-r19-batch100';D=R/'Recovery/Startup-R19-Batch100-2026-10-25'
candidate=(Q/'candidate5.dll').read_bytes();digest=sha(candidate)
assert digest=='a6ccfb7ceed40099e7bc9c1bb06f927dff763911632464c9318705c06594a863' and candidate==(Q/'candidate6.dll').read_bytes()
construction=json.loads((Q/'candidate5.json').read_bytes());assert construction['new_unique_methods']==100 and len({x['token'] for x in construction['changes']})==100
first=json.loads((Q/'SHARED-TEST-START.json').read_bytes());assert first['constructed_methods']==100 and not first['tests_run_before_this_marker']
P=Q/'shared-candidate5';iso=json.loads((P/'ISOLATION.json').read_bytes());assert iso['pass_'] and iso['unchanged_methoddefs']==2217
generic=json.loads((P/'GENERIC-COMPARISON.json').read_bytes());ctors=json.loads((P/'NATIVE-CONSTRUCTORS.json').read_bytes());leaves=json.loads((P/'NATIVE-LEAVES.json').read_bytes());assert not generic['expected_state_mismatches'] and not generic['native_vs_candidate_mismatches'] and not ctors['mismatches'] and not leaves['differences']
frozen=json.loads((P/'FROZEN-WITH-INTERFACE-FACTS.json').read_bytes());targets={x['token'] for x in construction['changes']};selected=[r for r in frozen['results'] if r['token'] in targets]
jit=json.loads((P/'jit/RESULT.json').read_bytes());assert jit['counts']=={'JIT_PREPARED_NO_EXECUTION':95,'UNSUPPORTED':5}
access=json.loads((P/'MEMBER-ACCESS-ALL.json').read_bytes());assert not [m for m in access['members'] if not m['allowed']]
assert json.loads((P/'MEMBER-EXIT.json').read_bytes())['exit_code']==0
index=[]
for r in construction['changes']:
    f=Q/'native-source-complete'/(r['token']+'.json');e=json.loads(f.read_bytes());index.append(dict(token=r['token'],name=r['name'],group=r['group'],evidence=f.relative_to(Q).as_posix(),sha256=sha(f.read_bytes()),entry=e.get('entry'),generic_variants=[v['binding'] for v in e.get('variants',[])],has_original_source=True))
js(Q/'CURRENT-SOURCE-BINDING-INDEX.json',dict(scope='ALL_CURRENT_HUNDRED_ORIGINAL_NATIVE_EVIDENCE_FILES_NOT_BEHAVIORAL_ACCEPTANCE',candidate_sha256=digest,methods=100,rows=index))
compared={r['token'] for r in ctors['results'] if r['token'] not in {b['token'] for b in ctors['blockers']}}|set(leaves['per_method'])|{'0x060008DB','0x060008DC','0x060008EB','0x060008EE','0x060008F0'}
assert len(compared)==35
progress=dict(status='HUNDRED_CONSTRUCTED_PARTIAL_SHARED_RUNTIME_EVIDENCE_COMPILER_PENDING_NO_PROMOTION',candidate_sha256=digest,parent_sha256=construction['parent_sha256'],bytes=len(candidate),new_unique_methods=100,first_test_after_hundred=True,repeat_identical=True,non_target_methoddefs_unchanged=2217,old_metadata_prefixes_preserved=True,target_relocations=len(iso['relocated_methods']),new_memberrefs=4,new_local_signatures=13,new_methodspecs=1,changed_frozen_counts=dict(collections.Counter(r['status'] for r in selected)),whole_frozen_counts=frozen['counts'],raw_frozen_report_preserved=True,member_access_actual_exit=0,member_access_rejected=0,exact_jit_counts=jit['counts'],closed_generic_jit_preparations=15,actual_closed_generic_runtime_records=1026,original_generic_reference_normal_records=241,generic_native_unwind='UNSUPPORTED',generic_physical_old_body_controls=5,generic_controls_runtime_different=5,original_constructor_records=50,actual_constructor_comparable_records=46,actual_constructor_comparable_methods=25,actual_constructor_blocked_records=4,original_scalar_reward_records=4101,finite_original_native_vs_actual_dll_compared_methods=35,other_method_runtime_profiles='PENDING',qualified_methods=0,full_batch_semantic_acceptance=False,unity='NOT_RUN',xcode='NOT_RUN',ipa=None,ipad_acceptance=False,groups=dict(collections.Counter(r['group'] for r in construction['changes'])))
js(Q/'PROGRESS.json',progress)
assert not D.exists();D.mkdir(parents=True)
(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text whitespace=cr-at-eol\n*.md -text\n*.zip -text\n*.yml -text\n')
for name in ['ACTIVE-INPUT.json','SHARED-TEST-START.json','REPEAT-CANDIDATE5.json','CURRENT-SOURCE-BINDING-INDEX.json','PROGRESS.json','METHODS.json']:(D/name).write_bytes((Q/name).read_bytes())
(D/'CONSTRUCTION.json').write_bytes((Q/'candidate5.json').read_bytes())
for name in ['ISOLATION.json','GENERIC-COMPARISON.json','GENERIC-REVERT-CONTROLS.json','FROZEN-WITH-INTERFACE-FACTS.json','MEMBER-EXIT.json']:(D/name).write_bytes((P/name).read_bytes())
pack(D/'STARTUP-R19-BATCH100-CANDIDATE.zip',[('STARTUP-R19-BATCH100.dll',candidate)])
pack(D/'FIRST-FAILED-CANDIDATES.zip',[(n,(Q/n).read_bytes()) for n in ['candidate1.dll','candidate1.json','candidate3.dll','candidate3.json']])
js(Q/'GENERIC-REVERT-BYTE-DELTAS.json',variants(P/'generic-reverts',candidate))
items=[]
for f in sorted(Q.rglob('*')):
    if not f.is_file():continue
    rel=f.relative_to(Q)
    if any(p in ['__pycache__','obj'] for p in rel.parts) or f.suffix=='.pyc':continue
    if f.suffix=='.dll' and 'bin' not in rel.parts:continue
    if f.name in ['GENERIC-REVERT-BYTE-DELTAS.json'] or f.suffix in ['.py','.cs','.csproj','.json','.txt','.log','.runtimeconfig','.deps','.pdb','.exe']:
        items.append(('startup-r19-batch100/'+rel.as_posix(),f.read_bytes()))
extra=[W/'startup-r5/runtime-common/Rehost.cs',W/'startup-r5/native_runtime_common.py',W/'startup-r2/construct.py',W/'startup-r13/construct.py',W/'archive_support.py',Path(__file__)]
items += [('shared/'+p.relative_to(W).as_posix(),p.read_bytes()) for p in extra]
base=W.parents[1]
for f in [base/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py',base/'audit/native111-publication-2026-10-20/repository/scripts/actions/static_gates.py',base/'audit/bulk400-generic-repair-2026-10-24/runtime/Mono.Cecil.dll']:
    items.append(('shared-input-tools/'+f.relative_to(base).as_posix(),f.read_bytes()))
pack(D/'SOURCE-NATIVE-AND-SHARED-TESTS.zip',items)
text=f'''# R19: 100 actual source changes, shared qualification in progress

Candidate `{digest}` ({len(candidate):,} bytes) is directly based on R18 `{construction['parent_sha256']}`. Exactly 100 distinct methods were constructed before shared testing was enabled. This is a durable source and partial verification checkpoint. It is **not** accepted as a complete 100-method semantic restoration or an iPad fix. Formal qualified count stays zero while batch gates are open.

## Source and repeatability

The batch restores 29 constructors, seven lost switch bodies, seven Int32 width defects, float state transitions, collection public access, typed projectile initialization, selection callbacks, UI/frame counters, five generic collection methods and other complete missing bodies. CURRENT-SOURCE-BINDING-INDEX.json binds each actual target to original PC native evidence. Generic entries are bound through original metadata/code registrations rather than ordinary non-generic method pointers. Original input hashes are PC `9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d`, metadata `ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9`.

Seventeen already-correct iterator Reset throw bodies were excluded from the count. Replacing a decompiler warning without a real body defect does not count as recovery. The initial repeat guard detected unordered set iteration before tests; deterministic ordering was corrected. First shared tests on candidate3 detected a bad Vector2 array token from an FE opcode decoder and two missing float type flows. Failed DLLs and raw reports remain archived. Candidate5 and candidate6 now match byte for byte. The first-test marker remains bound to candidate3; it was not rewritten to claim candidate5 was the first test.

## Isolation and static boundaries

Independent byte audit covers all 2,317 MethodDefs. Exactly 100 change; 2,217 others remain intact. All old metadata rows/heaps and method flags/section permissions stay intact. Twenty target bodies relocate while preserving their old slots. Appended metadata consists of four MemberRefs, thirteen StandAloneSig rows and one closed MethodSpec. Three physical out-of-scope body/metadata/permission controls are rejected.

Frozen verifier remains SHA `2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14`. Raw whole census is preserved; a separate direct InterfaceImpl metadata supplement yields {frozen['counts']}. Target census is {progress['changed_frozen_counts']}. Unsupported generic/indirect operations remain explicit; they were not forced green. Authentic whole-assembly member audit exits zero with no rejected or unresolved access. Exact-DLL preparation passes 95 non-generic targets; five open generic methods are unsupported by that probe and are separately closed/prepared in three real contexts, fifteen preparations total. JIT preparation is not behavior execution.

## Actual runtime observations already made

Five generic methods execute **unmodified actual DLL** code for String, Int32 and a 24-byte value type: 1,026 records. All match finite state expectations. A first ref-only test model incorrectly expected CoreCLR List<T>.Clear to zero value-type storage; those mismatches were retained and the expectation was corrected to account for the real dependency's element-kind behavior. Candidate code was not changed to accommodate the test. A separate original-reference-native comparison matches 241 normal cases. Each of five physical old-body reversions produces real observable differences, including the negative-index/null-data exception order. Native exceptions/SEH and native value-type ABI remain untested.

Twenty-nine original native constructors execute for fifty input records. Actual DLL snapshots are comparable for 25 methods /46 records and match every declared field in the stated snapshot scope. DeviceManager/ZombieManager Unity base calls and Skill/Card.PlantData static initialization block four records on ordinary CLR; their real errors remain in DIRECT-CONSTRUCTORS.json. Field snapshots do not prove allocation order, GC or memory-exhaustion behavior. Map comparison covers caller-written cameraSize and object presence, with a controlled Map leaf. Native MonoBehaviour hook is not a Unity proof.

Five additional scalar/reward methods match 4,101 original-native/actual-DLL records: painter names, device price, talent count, board-entry loot and PlantLevelUpSupplies constructor. Cases include table defaults, null/empty talent names, signed bounds, wraparound, float32 reward formulas and CVTT overflow sentinel. Pow/Exp leaves use host libm; original math library implementation is not qualified by that controlled contract.

These observations cover **35 distinct methods** with finite native/actual-DLL comparisons. Remaining 65 runtime profiles, full-batch negative controls, Unity import/player/export/link and iPad behavior remain pending. No universal semantic equivalence is claimed for the 35 either.

## Reproduction and next action

Extract SOURCE-NATIVE-AND-SHARED-TESTS.zip, preserve the work layout and pinned R18/original inputs plus authentic support. construct.py outputs a named new candidate; two independent outputs must match. prepare_shared_tests.py enforces the hundred threshold. For the current candidate, run_static.py candidate5 frozen/member, supplement_interface_facts.py, verify_isolation.py candidate5 and run_exact_jit.py candidate5 retain separate raw reports. Build direct-generics, direct-constructors and direct-leaves .NET10 fixture projects; invoke each on the exact DLL with authentic support and corresponding case/construction JSON. generic_native_oracle.py, compare_generics.py, generic_revert_controls.py, constructor_native_oracle.py and leaf_native_oracle.py execute isolated Windows x64 native/CLR evidence profiles. Read each script's arguments and limitations; this is not a full SDK/input distribution. Native code maps at the original base, never enters DllMain, and checks caller bytes after all hooks.

Compiler-only diagnostics are allowed after the hundred threshold and do not promote a partially tested candidate. Keep all failed compiler results and all generated units. The user's iPad M5/iPadOS27 black-screen/flicker remains unresolved until an updated player is actually tested.
'''
(D/'README.md').write_bytes(text.encode())
p=R/'README.md';lines=p.read_text('utf-8').splitlines();hits=[i for i,x in enumerate(lines) if x.startswith('Recovery now includes compiler repair,')];assert len(hits)==1
lines[hits[0]]='Recovery now includes compiler repair, original-native execution, real Editor diagnosis and shader restoration. Latest [R19 Batch100](Recovery/Startup-R19-Batch100-2026-10-25/README.md) has 100 actual native-backed method changes before shared tests. Exactly 2,217 other MethodDefs and all old metadata remain intact. Member-access audit now has zero rejections. Finite original-native/actual-DLL comparisons currently cover 35 methods; 65 profiles and full-batch qualification remain pending, with real Unity/static-initializer blocks retained. R19 compiler diagnostics are being prepared; R18 compiler results remain separately bound. No updated IPA or iPad black-screen/flicker acceptance is claimed.'
p.write_bytes(('\n'.join(lines)+'\n').encode())
p=R/'Recovery/STATUS.md';old=p.read_text('utf-8');marker='## Latest checkpoint — 2026-10-25\n';assert marker in old
note='\n[R19 Batch100](Startup-R19-Batch100-2026-10-25/README.md) completes 100 actual source changes before shared tests. Candidate5/6 SHA '+digest+' repeats identically. Whole byte audit preserves 2,217 other MethodDefs and all old metadata prefixes, adding four MemberRefs/thirteen locals/one MethodSpec and relocating twenty targets. Actual member audit exits zero with no rejections. Frozen census with direct interface metadata facts retains seventy FAIL_OR_UNSUPPORTED; six targets remain checker-unsupported. Exact JIT prepares 95 plus fifteen closed-context preparations for the remaining five generic methods. Finite original-native/direct actual-DLL comparisons currently cover 35 distinct methods: 241 reference generic normal cases (with 1,026 three-context CLR records), 46 constructor field snapshots and 4,101 scalar/reward records. Four constructor records remain blocked by authentic Unity bases/Skill initialization. First failed candidates, the test-model correction and five detected old generic-body controls are preserved. Remaining 65 runtime profiles and full-batch negative controls are pending. Compiler-only diagnostics do not promote this candidate; no R19 Unity/IPA/iPad acceptance.\n'
p.write_bytes(old.replace(marker,marker+note,1).encode())
manifest(D)
print(json.dumps(dict(checkpoint=str(D),candidate_sha256=digest,source_archive_members=len(items),source_zip_bytes=(D/'SOURCE-NATIVE-AND-SHARED-TESTS.zip').stat().st_size,progress=progress),indent=2))
