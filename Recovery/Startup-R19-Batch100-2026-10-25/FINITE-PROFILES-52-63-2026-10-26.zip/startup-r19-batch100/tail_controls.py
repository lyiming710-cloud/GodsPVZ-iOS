"""Six physical behavior faults; process failures never count as detections."""
from pathlib import Path
import hashlib,json,struct,subprocess,sys
Q=Path(__file__).resolve().parent;ROOT=Q.parents[2];P=Q/'shared-candidate9';O=P/'tail-controls';O.mkdir(exist_ok=True);sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
base=(Q/'candidate9.dll').read_bytes();pe=dnfile.dnPE(data=base);original=json.loads((P/'NATIVE-TAILS.json').read_bytes());assert original['candidate_sha256']==hashlib.sha256(base).hexdigest() and not original['differences'];expected={r['name']:r for r in original['results']};cil=json.loads((P/'ALL-CIL.json').read_bytes());methods={int(m['token'],16)&0xffffff:m for m in cil['methods']};rows=[]
for rid,label in [(0x38,'omit-device-load'),(0x5f,'omit-path-load'),(0x377,'heal-wrong-receiver'),(0x6f0,'omit-page-setinfo'),(0x56d,'settext-wrong-force'),(0x762,'omit-material-cache')]:
 data=bytearray(base);at=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[rid-1].Rva);h=1 if data[at]&3==2 else (struct.unpack_from('<H',data,at)[0]>>12)*4;m=methods[rid]
 if rid in [0x38,0x5f,0x6f0]:
  i=next(i for i in m['instructions'] if i['opcode']=='call' and i['operand']['name'] in ['LoadData','SetInfo']);p=at+h+i['offset'];assert data[p]==0x28;data[p:p+5]=bytes.fromhex('2600000000')
 elif rid==0x377:p=at+h;assert data[p]==4;data[p]=2
 elif rid==0x56d:
  i=[i for i in m['instructions'] if i['opcode']=='ldc.i4' and i['operand']==1][-1];p=at+h+i['offset'];assert data[p]==0x20;struct.pack_into('<i',data,p+1,0)
 else:
  i=[i for i in m['instructions'] if i['opcode']=='stfld'][-1];p=at+h+i['offset'];assert data[p]==0x7d;data[p:p+5]=bytes.fromhex('2626000000')
 file=O/(label+'.dll');file.write_bytes(data);out=O/(label+'.runtime.json');args=[str(ROOT/'.local/dotnet10/dotnet.exe'),str(Q/'runtime-tails/bin/Release/net10.0/Fixture.dll'),str(file),str(ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'),str(Q/'TAIL-CASES.json'),str(out),str(Q.parent/'startup-r5/runtime-common/Rehost.cs')];run=subprocess.run(args,capture_output=True,timeout=45);(O/(label+'.stdout.log')).write_bytes(run.stdout);(O/(label+'.stderr.log')).write_bytes(run.stderr);assert run.returncode==0,(label,'Process failure is not semantic detection',run.returncode)
 actual=json.loads(out.read_bytes());assert actual['candidate_sha256']==hashlib.sha256(data).hexdigest();different=[dict(original=expected[r['name']],actual=r) for r in actual['results'] if r['name'] in expected and expected[r['name']]!=r];assert different,(label,'Undetected physical fault');assert all(x['original']['token']==f'0x{0x6000000|rid:08X}' for x in different),'Cross-method contamination'
 rows.append(dict(token=f'0x{0x6000000|rid:08X}',fault=label,physical_sha256=actual['candidate_sha256'],status='RUNTIME_DIFFERENCE_DETECTED',different_records=len(different),differences=different))
report=dict(scope='SIX_PHYSICAL_TAIL_DISPATCH_SHADER_BEHAVIOR_FAULTS',candidate_sha256=hashlib.sha256(base).hexdigest(),variants=6,runtime_detected=6,process_failures=0,results=rows,formal_or_product_acceptance=False);(P/'TAIL-CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k!='results'}))
