"""Separate all current target states; never relabel unsupported items PASS."""
from pathlib import Path
import collections,hashlib,json,sys
Q=Path(__file__).resolve().parent;stem=sys.argv[1] if len(sys.argv)>1 else 'candidate9';P=Q/('shared-'+stem);report=json.loads((Q/(stem+'.json')).read_bytes());digest=hashlib.sha256((Q/(stem+'.dll')).read_bytes()).hexdigest();assert digest==report['candidate_sha256']
frozen={r['token']:r for r in json.loads((P/'FROZEN-WITH-INTERFACE-FACTS.json').read_bytes())['results']};ops={r['token']:r for r in json.loads((P/'OPERATION-BOUNDARIES.json').read_bytes())['rows']};profiles={}
def add(token,scope,records,limitations):assert token not in profiles;profiles[token]=dict(scope=scope,native_comparison_records=records,limitations=limitations,universal_behavior_proof=False)
c=json.loads((P/'NATIVE-CONSTRUCTORS.json').read_bytes());blocked={r['token'] for r in c['blockers']}
for token,count in collections.Counter(r['token'] for r in c['results']).items():add(token,'COMPLETE_CIL_CONTROLLED_CTOR_FIELDS_REAL_DLL_BLOCK_RETAINED' if token in blocked else 'DIRECT_ACTUAL_DLL_DECLARED_CTOR_FIELDS',count,['Final declared fields do not observe overwritten writes or allocation order','GC and native exception/SEH unmodeled']+(['Unity base/game cctor not qualified'] if token in blocked else []))
for token,count in collections.Counter(r['token'] for r in json.loads((P/'NATIVE-GENERICS.json').read_bytes())['results']).items():add(token,'DIRECT_ACTUAL_DLL_CLOSED_GENERIC_REFERENCE_NATIVE_NORMAL_PATH',count,['Three CLR contexts tested separately','Native value ABI/exception/SEH unmodeled','Controlled array/GC leaves'])
for token,count in json.loads((P/'NATIVE-LEAVES.json').read_bytes())['per_method'].items():add(token,'DIRECT_ACTUAL_DLL_SCALAR_AND_REWARD_FINITE_NATIVE_PROFILE',count,['String/allocator/GC contracts','Host libm Pow/Exp for supply ctor'])
for token,count in collections.Counter(r['token'] for r in json.loads((P/'NATIVE-STATE.json').read_bytes())['results']).items():add(token,'COMPLETE_CANDIDATE_CIL_FINITE_NATIVE_STATE_TRACE_REAL_MATH_HELPERS',count,['Controlled engine/game leaves and callback profiles','Native exceptions/SEH unmodeled','No NaN payload equivalence'])
phone=json.loads((P/'NATIVE-PHONE.json').read_bytes());add('0x06000728','COMPLETE_CANDIDATE_CIL_FINITE_NATIVE_PHONE_TRACE',phone['normal_records'],['Controlled Debug and strings','Two managed null-input records not native unwind proof'])
extra=P/'NATIVE-FOREACH.json'
if extra.exists():
    each=json.loads(extra.read_bytes());assert not each['differences'];add('0x0600006D','COMPLETE_CANDIDATE_CIL_FOREACH_NORMAL_PROFILE_REAL_FINALLY_GRAPH',each['normal_comparison_records'],['Controlled enumerator/manager/Debug leaves','Native exception/SEH unsupported','Empty Dispose has no runtime observable effect; EH graph preserved independently'])
expected_methods=51 if extra.exists() else 50;expected_records=11108 if extra.exists() else 11096
for filename,nmethods,nrecords,scope,limitations in [
 ('NATIVE-TAILS.json',6,174,'COMPLETE_CANDIDATE_CIL_TAIL_DISPATCH_SHADER_FINITE_NATIVE_PROFILE',['Controlled tail/lookup/Healed/string/text/renderer leaves','Six managed-only null exceptions do not prove native unwind','No material rendering/lifetime or universal equivalence proof']),
 ('NATIVE-FRAMES.json',2,1920,'COMPLETE_CANDIDATE_CIL_FRAME_DISPLAY_FINITE_NATIVE_PROFILE',['Controlled Time/anchor/Concat/TMP leaves','Real original SSE arithmetic and original color branch order','No text layout/rendering, native SEH or NaN payload proof']),
 ('NATIVE-UI-INIT.json',2,227,'COMPLETE_CANDIDATE_CIL_RESOLUTION_LEVEL_INIT_FINITE_NATIVE_PROFILE',['Controlled resolution properties/display calls and sprite/text/refresh leaves','Four managed-only exceptions are not native unwind proof','No real screen switch or scene rendering proof']),
 ('NATIVE-DAMAGE-CLICK.json',2,2976,'COMPLETE_CANDIDATE_CIL_DAMAGE_BYREF_PICKUP_FINITE_NATIVE_PROFILE',['Controlled ATK/MS/Collect/bank/audio leaves','Shared managed reference field is passed as Damage& for callback alias tests','No real buff, inventory, audio or native exception proof'])
]:
 path=P/filename
 if not path.exists():continue
 observed=json.loads(path.read_bytes());assert observed['candidate_sha256']==digest and not observed['differences'] and not observed['callback_errors']
 counts=collections.Counter(r['token'] for r in observed['results']);assert len(counts)==nmethods and sum(counts.values())==observed['normal_records']==nrecords and dict(counts)==observed['per_method']
 assert len(observed['results'])==len({r['name'] for r in observed['results']}) and all(r['error'] is None for r in observed['results'])
 for token,count in counts.items():add(token,scope,count,limitations)
 expected_methods+=nmethods;expected_records+=nrecords
assert len(profiles)==expected_methods and sum(r['native_comparison_records'] for r in profiles.values())==expected_records
rows=[]
for c in report['changes']:
 token=c['token'];rows.append(dict(token=token,name=c['name'],group=c['group'],constructed=True,frozen=frozen[token],actual_member_audit='NO_REJECTIONS_OR_UNRESOLVED_ACCESS',runtime_profile=profiles.get(token),operation_boundary_audit=ops.get(token),full_runtime_profile_pending=token not in profiles,formal_promoted=False))
pending=[r for r in rows if r['full_runtime_profile_pending']];assert len(pending)==100-expected_methods
priority=lambda r:0 if r['token']=='0x0600006D' else 1 if r['group'] in ['lost-tail','lost-tail-and-dispatch','lost-properties','public-contract','frame-display','selection-state'] else 2 if r['operation_boundary_audit'] else 3
pending.sort(key=lambda r:(priority(r),r['token']))
registry=dict(scope='CURRENT_HUNDRED_METHOD_CONSTRUCTION_AND_SCOPED_TEST_STATE_LEDGER',candidate_sha256=digest,targets=100,finite_native_profiles=len(profiles),native_comparison_records=expected_records,pending_runtime_profiles=len(pending),operation_boundary_only_methods=22,formal_promoted=0,rows=rows)
(P/'METHOD-TEST-REGISTRY.json').write_text(json.dumps(registry,indent=2)+'\n',encoding='utf-8')
(P/'PENDING-RUNTIME-PROFILES.json').write_text(json.dumps(dict(candidate_sha256=digest,methods=len(pending),not_a_count_of_confirmed_remaining_game_bugs=True,rows=pending),indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in registry.items() if k!='rows'},indent=2));print('pending groups',dict(collections.Counter(r['group'] for r in pending)))
