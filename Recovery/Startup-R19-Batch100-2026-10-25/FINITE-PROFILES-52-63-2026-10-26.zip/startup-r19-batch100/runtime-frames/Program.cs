using System.Reflection;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public class Frame
{
 public int AnchorPosition,last_AnchorPosition,m_Frames;public float UpdateInterval,m_LastInterval;public string htmlColorTag="initial";public Text m_TextMeshPro=null!;
 public void Set_FrameCounter_Position(int anchor){Program.Trace.Add("Anchor:"+anchor);if(Program.Mode=="anchor-fields"){AnchorPosition=7;m_Frames=30;}}
}
public class Text
{
 public string Tag="";public string? Last,Fps,Millis;
 public void SetText(string value,float fps,float ms){Last=value;Fps=Program.Bits(fps);Millis=Program.Bits(ms);Program.Trace.Add("SetText:"+Tag+":"+value+":"+Fps+":"+Millis);if(Program.Mode=="text-fields"){Program.Frame.m_LastInterval=77;Program.Frame.m_Frames=333;}}
}
public static class Program
{
 public static JsonElement Case;public static Frame Frame=null!;public static Text Text=null!,Other=null!;public static List<string> Trace=[];
 public static string Mode=>Case.GetProperty("mode").GetString()!;
 public static string Bits(float f)=>float.IsNaN(f)?"NaN":BitConverter.SingleToUInt32Bits(f).ToString("X8");
 public static float F(string k)=>BitConverter.UInt32BitsToSingle(Convert.ToUInt32(Case.GetProperty(k).GetString(),16));
 public static float Time(){float v=F("now");Trace.Add("Time:"+Bits(v));if(Mode=="time-fields"){Frame.m_LastInterval=-1;Frame.UpdateInterval=0;Frame.m_Frames=90;Frame.AnchorPosition=9;}return v;}
 public static string Concat(string a,string b){Trace.Add("Concat:"+a+"|"+b);if(Mode=="concat-fields"){Frame.htmlColorTag="replaced";Frame.m_TextMeshPro=Other;Frame.m_LastInterval=55;Frame.m_Frames=666;}return string.Concat(a,b);}
 static Type Map(MC.TypeReference t)
 {
  if(t.FullName.EndsWith("/FpsCounterAnchorPositions"))return typeof(int);
  return t.FullName switch{"System.Void"=>typeof(void),"System.Boolean"=>typeof(bool),"System.Int32"=>typeof(int),"System.Single"=>typeof(float),"System.String"=>typeof(string),"TMPro.Examples.TMP_FrameRateCounter" or "TMPro.Examples.TMP_UiFrameRateCounter"=>typeof(Frame),"TMPro.TextMeshPro" or "TMPro.TextMeshProUGUI" or "TMPro.TMP_Text"=>typeof(Text),_=>throw new NotSupportedException(t.FullName)};
 }
 static FieldInfo Field(MC.FieldReference f)=>Map(f.DeclaringType).GetField(f.Name)!;
 static MethodBase Method(MC.MethodReference m)=>m.DeclaringType.FullName switch{"UnityEngine.Time"=>typeof(Program).GetMethod("Time")!,"System.String"=>typeof(Program).GetMethod("Concat")!,_=>Map(m.DeclaringType).GetMethod(m.Name,BindingFlags.Public|BindingFlags.Static|BindingFlags.Instance,null,m.Parameters.Select(p=>Map(p.ParameterType)).ToArray(),null)!};
 public static void Main(string[] args)
 {
  var resolver=new MC.DefaultAssemblyResolver();resolver.AddSearchDirectory(args[1]);using var asm=MC.AssemblyDefinition.ReadAssembly(args[0],new MC.ReaderParameters{AssemblyResolver=resolver});int[] ids={0x7b4,0x7d2};var code=ids.ToDictionary(r=>r,r=>ActualCil.Emit((MC.MethodDefinition)asm.MainModule.LookupToken(0x6000000|r),Map,Field,Method));using var cases=JsonDocument.Parse(File.ReadAllText(args[2]));var rows=new List<object>();
  foreach(var q in cases.RootElement.EnumerateArray())
  {
   Case=q;Trace.Clear();Text=new(){Tag="text"};Other=new(){Tag="other"};Frame=new(){AnchorPosition=q.GetProperty("anchor").GetInt32(),last_AnchorPosition=q.GetProperty("last_anchor").GetInt32(),m_Frames=q.GetProperty("frames").GetInt32(),m_LastInterval=F("last"),UpdateInterval=F("interval"),m_TextMeshPro=Text};string? error=null;
   try{code[Convert.ToInt32(q.GetProperty("token").GetString(),16)&0xffffff].Invoke(null,[Frame]);}catch(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;error=e.GetType().FullName;}
   rows.Add(new{name=q.GetProperty("name").GetString(),token=q.GetProperty("token").GetString(),error,trace=Trace.ToArray(),state=new{anchor=Frame.AnchorPosition,last_anchor=Frame.last_AnchorPosition,frames=Frame.m_Frames,last=Bits(Frame.m_LastInterval),interval=Bits(Frame.UpdateInterval),color=Frame.htmlColorTag,selected=Frame.m_TextMeshPro.Tag,text=Text.Last,fps=Text.Fps,millis=Text.Millis,other_text=Other.Last,other_fps=Other.Fps,other_millis=Other.Millis}});
  }
  File.WriteAllText(args[3],JsonSerializer.Serialize(new{scope="TWO_COMPLETE_CANDIDATE_FRAME_DISPLAY_BODIES_CONTROLLED_TIME_ANCHOR_TEXT",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),results=rows,methods=2,eh_removed=false,private_access_bypass=false,unity_or_product_acceptance=false},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{records=rows.Count,methods=2}));
 }
}
