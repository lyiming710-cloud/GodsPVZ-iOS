"""Unchanged native frame callers; real SSE arithmetic, modeled engine leaves."""
from pathlib import Path
import collections,ctypes as C,functools,hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
im=NativeImage();state={};ids=[0x7b4,0x7d2];cfgs={rid:json.loads((Q/'native-source-complete'/f'0x{0x6000000|rid:08X}.json').read_bytes()) for rid in ids};fields=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_bytes())
@functools.lru_cache(None)
def off(owner,name):
 rs=[r for r in fields if r['namespace']=='TMPro.Examples' and r['type']==owner and r['name']==name];assert len(rs)==1,(owner,name,rs);return rs[0]['offset']
def at(name):return state['self']+off(state['owner'],name)
def string(s):
 b=s.encode('utf-16-le');p=im.alloc(24+len(b));put32(p+0x10,len(b)//2);C.memmove(p+0x14,b,len(b));return p
def text(p):return None if not p else C.string_at(p+0x14,get32(p+0x10)*2).decode('utf-16-le')
def f(s):return struct.unpack('>f',bytes.fromhex(s))[0]
def mode():return state['q']['mode']
def anchor(p,n,method):
 assert p==state['self'] and not method;state['trace'].append('Anchor:'+str(n))
 if mode()=='anchor-fields':put32(at('AnchorPosition'),7);put32(at('m_Frames'),30)
def time(method):
 assert not method;v=f(state['q']['now']);state['trace'].append('Time:'+bits(v))
 if mode()=='time-fields':putf(at('m_LastInterval'),-1);putf(at('UpdateInterval'),0);put32(at('m_Frames'),90);put32(at('AnchorPosition'),9)
 return v
def concat(a,b,method):
 assert not method;a,b=text(a),text(b);state['trace'].append('Concat:'+a+'|'+b)
 if mode()=='concat-fields':put64(at('htmlColorTag'),string('replaced'));put64(at('m_TextMeshPro'),state['other']);putf(at('m_LastInterval'),55);put32(at('m_Frames'),666)
 return string(a+b)
def settext(p,s,fps,ms,method):
 assert not method and p in [state['text'],state['other']];label='text' if p==state['text'] else 'other';s=text(s);fb,mb=bits(fps),bits(ms);state['rendered'][label]=(s,fb,mb);state['trace'].append('SetText:'+label+':'+s+':'+fb+':'+mb)
 if mode()=='text-fields':putf(at('m_LastInterval'),77);put32(at('m_Frames'),333)
def snapshot():
 s=state['rendered'];return dict(anchor=get32(at('AnchorPosition')),last_anchor=get32(at('last_AnchorPosition')),frames=get32(at('m_Frames')),last=bits(getf(at('m_LastInterval'))),interval=bits(getf(at('UpdateInterval'))),color=text(get64(at('htmlColorTag'))),selected='text' if get64(at('m_TextMeshPro'))==state['text'] else 'other',text=s['text'][0],fps=s['text'][1],millis=s['text'][2],other_text=s['other'][0],other_fps=s['other'][1],other_millis=s['other'][2])
try:
 meta=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/global-metadata.dat').read_bytes();assert hashlib.sha256(meta).hexdigest()=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9';so,sn,do,dn=struct.unpack_from('<4I',meta,8);dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True;slots=set()
 for cfg in cfgs.values():
  for row in cfg['instructions']:
   i=next(dis.disasm(bytes.fromhex(row['bytes']),int(row['va'],16)))
   if i.mnemonic not in ['mov','lea']:continue
   for op in i.operands:
    if op.type!=X86_OP_MEM or op.mem.base!=X86_REG_RIP:continue
    a=i.address+i.size+op.mem.disp;raw=im.pe.get_data(a-im.base,8)
    if len(raw)!=8:continue
    code=int.from_bytes(raw,'little')
    if code>0xffffffff or code>>29 not in range(1,8) or a in slots:continue
    slots.add(a);kind,index=code>>29,(code&0x1fffffff)>>1
    if kind==5:n,pos=struct.unpack_from('<II',meta,so+index*8);put64(a,string(meta[do+pos:do+pos+n].decode('utf-8')))
    else:im.class_slot(a)
 def init(a):assert a in slots,hex(a)
 def barrier(a,p):assert get64(a)==(p or 0)
 im.hook(0x18024fef0,None,[P],init);im.hook(0x18024f360,None,[P,P],barrier);im.hook(0x1803b5dd0,None,[P,I,P],anchor);im.hook(0x1803badc0,None,[P,I,P],anchor);im.hook(0x18132c3b0,F,[P],time);im.hook(0x180b74270,P,[P,P,P],concat);im.hook(0x1811aed30,None,[P,P,F,F,P],settext)
 for rid,cfg in cfgs.items():im.verify_caller(rid,int(cfg['entry'],16),cfg)
 rows=[];cases=json.loads((Q/'FRAME-CASES.json').read_bytes())
 for q in cases:
  state.clear();state.update(q=q,trace=[],self=im.alloc(256),text=im.alloc(64),other=im.alloc(64),rendered={'text':(None,None,None),'other':(None,None,None)});rid=int(q['token'],16)&0xffffff;state['owner']='TMP_FrameRateCounter' if rid==0x7b4 else 'TMP_UiFrameRateCounter'
  for name,key in [('AnchorPosition','anchor'),('last_AnchorPosition','last_anchor'),('m_Frames','frames')]:put32(at(name),q[key])
  putf(at('m_LastInterval'),f(q['last']));putf(at('UpdateInterval'),f(q['interval']));put64(at('htmlColorTag'),string('initial'));put64(at('m_TextMeshPro'),state['text']);C.CFUNCTYPE(None,P,P)(int(cfgs[rid]['entry'],16))(state['self'],None);assert not im.errors,(q,im.errors);rows.append(dict(name=q['name'],token=q['token'],error=None,trace=list(state['trace']),state=snapshot()))
 actual=json.loads(Path(sys.argv[1]).read_bytes());assert actual['candidate_sha256']==hashlib.sha256((Q/'candidate9.dll').read_bytes()).hexdigest();byname={r['name']:r for r in actual['results']};assert len(byname)==len(cases) and set(byname)=={q['name'] for q in cases};diff=[dict(original=r,actual=byname[r['name']]) for r in rows if r!=byname[r['name']]]
 report=dict(scope='TWO_UNCHANGED_NATIVE_FRAME_DISPLAY_CALLERS_VS_COMPLETE_CANDIDATE_CIL',candidate_sha256=actual['candidate_sha256'],original_pc_sha256=hashlib.sha256(im.raw).hexdigest(),caller_bytes_verified=2,normal_records=len(rows),per_method=dict(collections.Counter(r['token'] for r in rows)),differences=diff,results=rows,callback_errors=im.errors,arithmetic='ORIGINAL_SSE_FLOAT32_DIVISION_MAX_AND_COLOR_COMPARISONS',controlled_leaves=['Time.realtimeSinceStartup','Set_FrameCounter_Position','String.Concat','TMP.SetText(string,float,float)','Metadata/GC barrier'],limitations=['No native exceptions or SEH','No Unity text layout/rendering/anchor implementation proof','No NaN payload proof or universal behavior equivalence'],formal_or_product_acceptance=False);Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k not in ['results','differences']}));print('differences',len(diff));assert not diff
finally:im.close()
