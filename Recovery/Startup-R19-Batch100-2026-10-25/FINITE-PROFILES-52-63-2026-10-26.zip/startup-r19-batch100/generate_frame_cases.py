"""Frame gates, signed overflow, float edge cases, and callback reload order."""
from pathlib import Path
import itertools,json,struct
Q=Path(__file__).resolve().parent;rows=[]
def f(v):return struct.pack('>f',v).hex().upper()
times=[(f(0),f(.5),f(1)),(f(0),f(.5),f(.5)),(f(0),f(.5),'7FC00001'),(f(0),f(-1),f(0)),('7F800000',f(0),'7F800000'),(f(0),f(0),'7F800000'),(f(0),f(0),'00000001'),(f(-1),f(0),f(0))]
for rid,anchor,frames,t,mode in itertools.product([0x7b4,0x7d2],[(0,0),(1,0),(-1,4)],[-2,-1,0,8,28,29,59,2147483647],times,['none','anchor-fields','time-fields','concat-fields','text-fields']):
 rows.append(dict(name='f'+str(len(rows)).zfill(5),token=f'0x{0x6000000|rid:08X}',anchor=anchor[0],last_anchor=anchor[1],frames=frames,last=t[0],interval=t[1],now=t[2],mode=mode,native_supported=True))
(Q/'FRAME-CASES.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print('frame records',len(rows))
