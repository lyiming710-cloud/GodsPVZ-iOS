using System.Reflection;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public struct RefreshRate{public uint N,D;}
public struct Resolution
{
 public int W,H;public RefreshRate Rate;
 public int width{get{int n=W;Program.Trace.Add("Width:"+n);if(Program.Mode=="width-fields"){H=999;Rate=new(){N=120000,D=1001};}return n;}}
 public int height{get{int n=H;Program.Trace.Add("Height:"+n);if(Program.Mode=="height-fields")Rate=new(){N=240000,D=1001};return n;}}
 public RefreshRate refreshRateRatio{get{Program.Trace.Add("Rate:"+Rate.N+"/"+Rate.D);return Rate;}}
}
public class Test{}
public static class Screen
{
 public static Resolution currentResolution{get{Program.Trace.Add("Resolution");return Program.Res;}}
 public static void SetResolution(int w,int h,int mode,RefreshRate rate){Program.Trace.Add("Set4:"+w+":"+h+":"+mode+":"+rate.N+"/"+rate.D);if(Program.Mode=="set-fields")Program.Res=new(){W=-2,H=-3,Rate=new(){N=1,D=2}};}
 public static void SetResolution(int w,int h,int mode)=>Program.Trace.Add("Set3:"+w+":"+h+":"+mode);
}
public class Manager{}
public class LawnApp{public Manager? savesManager;}
public static class Global{public static LawnApp? gLawnApp;}
public class Sprite{public string Tag="";}
public class Image
{
 public string Tag="";public string? Last;
 public Sprite? sprite{set{Last=value?.Tag;Program.Trace.Add("Sprite:"+Tag+":"+(Last??"null"));if(Program.Mode=="sprite-fields"){Program.Level.text_Name=Program.OtherText;Program.Level.level=889;}}}
}
public class Text
{
 public string Tag="";public string? Last;public bool Force;
 public void SetText(string? value,bool force){Last=value;Force=force;Program.Trace.Add("Text:"+Tag+":"+(value??"null")+":"+(force?1:0));if(Program.Mode=="text-fields"){Program.Level.image_inside=Program.OtherImage;Program.Level.level=890;}}
}
public class SpriteList
{
 public string Tag="";
 public Sprite? this[int index]{get{Program.Trace.Add("Item:"+Tag+":"+index);if(index<0||index>=3)throw new ArgumentOutOfRangeException(nameof(index));if(Program.Mode=="item-fields"){Program.Level.image_inside=Program.OtherImage;Program.Level.text_Name=Program.OtherText;Program.Level.level=888;}return Program.N("null_sprite")==1?null:new(){Tag=Tag+index};}}
}
public static class Resource{public static SpriteList levelSprites_A=new(){Tag="A"},levelSprites_R=new(){Tag="R"},levelSprites_BA=new(){Tag="BA"};}
public class Level
{
 public int level;public Image image_inside=null!;public Text text_Name=null!;
 public void SetState(){Program.Trace.Add("Refresh:"+level);if(Program.Mode=="refresh-fields")level=891;}
}
public static class Program
{
 public static JsonElement Case;public static List<string> Trace=[];public static Resolution Res;public static Level Level=null!;public static Image Image=null!,OtherImage=null!;public static Text Text=null!,OtherText=null!;
 public static string Mode=>Case.GetProperty("mode").GetString()!;
 public static int N(string k,int d=0)=>Case.TryGetProperty(k,out var v)?v.GetInt32():d;
 public static uint U(string k,uint d=0)=>Case.TryGetProperty(k,out var v)?v.GetUInt32():d;
 static Type Map(MC.TypeReference t)
 {
  if(t is MC.GenericInstanceType g&&g.ElementType.FullName=="System.Collections.Generic.List`1"&&g.GenericArguments.Single().FullName=="UnityEngine.Sprite")return typeof(SpriteList);
  return t.FullName switch{"System.Void"=>typeof(void),"System.Boolean"=>typeof(bool),"System.Int32" or "ChallengeType" or "UnityEngine.FullScreenMode"=>typeof(int),"System.IntPtr"=>typeof(IntPtr),"System.String"=>typeof(string),"System.NullReferenceException"=>typeof(NullReferenceException),"UnityEngine.Resolution"=>typeof(Resolution),"UnityEngine.RefreshRate"=>typeof(RefreshRate),"UnityEngine.Screen"=>typeof(Screen),"Test"=>typeof(Test),"LevelItem"=>typeof(Level),"GlobalStaticVars"=>typeof(Global),"GlobalStaticVars/LawnApp"=>typeof(LawnApp),"SavesManager"=>typeof(Manager),"ResourceManager"=>typeof(Resource),"UnityEngine.Sprite"=>typeof(Sprite),"UnityEngine.UI.Image"=>typeof(Image),"TMPro.TextMeshProUGUI" or "TMPro.TMP_Text"=>typeof(Text),_=>throw new NotSupportedException(t.FullName)};
 }
 static FieldInfo Field(MC.FieldReference f)=>Map(f.DeclaringType).GetField(f.Name)!;
 static MethodBase Method(MC.MethodReference m){var pars=m.Parameters.Select(p=>Map(p.ParameterType)).ToArray();return m.Name==".ctor"?Map(m.DeclaringType).GetConstructor(pars)!:Map(m.DeclaringType).GetMethod(m.Name,BindingFlags.Public|BindingFlags.Instance|BindingFlags.Static,null,pars,null)!;}
 public static void Main(string[] args)
 {
  var resolver=new MC.DefaultAssemblyResolver();resolver.AddSearchDirectory(args[1]);using var asm=MC.AssemblyDefinition.ReadAssembly(args[0],new MC.ReaderParameters{AssemblyResolver=resolver});int[] ids={0x62b,0x713};var code=ids.ToDictionary(r=>r,r=>ActualCil.Emit((MC.MethodDefinition)asm.MainModule.LookupToken(0x6000000|r),Map,Field,Method));using var cases=JsonDocument.Parse(File.ReadAllText(args[2]));var rows=new List<object>();
  foreach(var q in cases.RootElement.EnumerateArray())
  {
   Case=q;Trace.Clear();Res=new(){W=N("width",1920),H=N("height",1080),Rate=new(){N=U("numerator",60000),D=U("denominator",1001)}};Global.gLawnApp=N("app",1)==0?null:new(){savesManager=N("manager",1)==0?null:new()};Image=new(){Tag="image"};OtherImage=new(){Tag="other-image"};Text=new(){Tag="text"};OtherText=new(){Tag="other-text"};Level=new(){level=-7,image_inside=Image,text_Name=Text};int rid=Convert.ToInt32(q.GetProperty("token").GetString(),16)&0xffffff;string? error=null;
   try{code[rid].Invoke(null,rid==0x713?[new Test()]:[Level,N("level"),N("challenge"),q.GetProperty("text").ValueKind==JsonValueKind.Null?null:q.GetProperty("text").GetString()]);}catch(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;error=e.GetType().FullName;}
   object state=rid==0x713?new{width=Res.W,height=Res.H,numerator=Res.Rate.N,denominator=Res.Rate.D}:new{level=Level.level,image=Level.image_inside.Tag,text_owner=Level.text_Name.Tag,sprite=Image.Last,other_sprite=OtherImage.Last,text=Text.Last,force=Text.Force,other_text=OtherText.Last,other_force=OtherText.Force};rows.Add(new{name=q.GetProperty("name").GetString(),token=q.GetProperty("token").GetString(),error,trace=Trace.ToArray(),state});
  }
  File.WriteAllText(args[3],JsonSerializer.Serialize(new{scope="TWO_COMPLETE_CANDIDATE_RESOLUTION_AND_LEVEL_INIT_BODIES_CONTROLLED_ENGINE_CALLEES",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),results=rows,methods=2,eh_removed=false,private_access_bypass=false,unity_or_product_acceptance=false},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{records=rows.Count,methods=2}));
 }
}
