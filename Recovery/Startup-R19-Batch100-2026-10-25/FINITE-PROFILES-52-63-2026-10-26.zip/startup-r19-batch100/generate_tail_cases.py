"""Finite cases for four restored tails, painter dispatch and shader cache order."""
from pathlib import Path
import collections,itertools,json
Q=Path(__file__).resolve().parent;rows=[]
def add(rid,**values):
 q=dict(name='t'+str(len(rows)).zfill(4),token=f'0x{0x6000000|rid:08X}',mode='none',native_supported=True);q.update(values);rows.append(q)
for rid in [0x38,0x5f]:
 for arg,mode in itertools.product([0,1],['none','tail-replaces']):add(rid,input=arg,mode=mode)
for healer,target,amount in itertools.product([0,1,2],[1,2],['00000000','80000000','3F000000','BF800000','7F7FFFFF','7F800000','FF800000','7FC00001']):add(0x377,healer=healer,target=target,amount=amount)
for healer in [0,1,2]:add(0x377,healer=healer,target=0,amount='3F800000',native_supported=False)
for ident,result,mode in itertools.product([-2147483648,-1,0,1,49,2147483647],[0,1,2],['none','lookup-replaces','tail-replaces']):add(0x6f0,id=ident,lookup_result=result,mode=mode)
for mode in ['none','tail-replaces']:add(0x6f0,input=0,lookup_result=1,mode=mode)
for ident,mode in itertools.product([-2147483648,-1,*range(10),48,49,50,2147483647],['none','concat-replaces','text-replaces']):add(0x56d,id=ident,mode=mode)
for mode in ['none','text-replaces']:add(0x56d,input=0,mode=mode)
for inp in [0,1]:add(0x56d,input=inp,painter=0,id=1,native_supported=False)
for renderer,material,mode in itertools.product([1,2],[0,1],['none','component-replaces','material-replaces']):add(0x762,renderer=renderer,material=material,mode=mode)
add(0x762,renderer=0,material=1,native_supported=False)
(Q/'TAIL-CASES.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(records=len(rows),native=sum(r['native_supported'] for r in rows),per_method=dict(collections.Counter(r['token'] for r in rows)))))
