"""Original SSE damage dispatch and ordered pickup click callers."""
from pathlib import Path
import collections,ctypes as C,functools,hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
im=NativeImage();state={};ids=[0x445,0x3c2];cfgs={rid:json.loads((Q/'native-source-complete'/f'0x{0x6000000|rid:08X}.json').read_bytes()) for rid in ids};fields=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_bytes())
@functools.lru_cache(None)
def off(owner,name):
 rs=[r for r in fields if r['type']==owner and r['namespace']=='' and r['name']==name];assert len(rs)==1,(owner,name,rs);return rs[0]['offset']
def mode():return state['q']['mode']
def f(k,d=0):return struct.unpack('>f',bytes.fromhex(state['q'][k]))[0] if k in state['q'] else d
def tag(p):return 'null' if not p else state['tags'][p]
def make(label):
 p=im.alloc(1024);state['tags'][p]=label;return p
def atk(p,method):
 assert p==state['zombie'] and not method;v=f('atk',1);state['trace'].append('ATK:'+bits(v))
 if mode()=='atk-fields':put32(p+off('Zombie','ID'),22);put64(state['slot'],state['other'])
 return v
def ms(p,method):
 assert p==state['zombie'] and not method;v=f('ms',1);state['trace'].append('MS:'+bits(v))
 if mode()=='ms-fields':put32(p+off('Zombie','ID'),3);put64(state['slot'],state['other'])
 return v
def collect(p,method):
 assert p==state['project'] and not method;state['trace'].append('Collect')
 if mode()=='collect-fields':put64(p+off('Project','board'),state['board-b']);put64(p+off('Project','projectManager'),state['audio-b']);put32(p+off('Project','projectType'),8)
def bank(p,kind,method):
 assert not method and tag(p) in ['bank-a','bank-b'];state['trace'].append('Bank:'+tag(p)+':'+str(kind))
 if mode()=='bank-fields':put64(state['project']+off('Project','projectManager'),state['audio-b']);put32(state['project']+off('Project','projectType'),5)
def audio(p,project,method):
 assert not method and project==state['project'] and tag(p) in ['audio-a','audio-b'];state['trace'].append('Audio:'+tag(p))
 if mode()=='audio-fields':put32(project+off('Project','projectType'),6)
def snapshot(rid):
 if rid==0x445:return dict(id=get32(state['zombie']+off('Zombie','ID')),root=tag(get64(state['slot'])),damage=bits(getf(state['damage']+off('Damage','damagePoint'))),other=bits(getf(state['other']+off('Damage','damagePoint'))))
 p=state['project'];return dict(kind=get32(p+off('Project','projectType')),board='other' if get64(p+off('Project','board'))==state['board-b'] else 'initial',manager=tag(get64(p+off('Project','projectManager'))))
try:
 im.hook(0x180360280,F,[P,P],atk);im.hook(0x180361380,F,[P,P],ms);im.hook(0x1803767e0,None,[P,P],collect);im.hook(0x180322c80,None,[P,I,P],bank);im.hook(0x180323840,None,[P,P,P],audio)
 for rid,cfg in cfgs.items():im.verify_caller(rid,int(cfg['entry'],16),cfg)
 rows=[];cases=json.loads((Q/'DAMAGE-CLICK-CASES.json').read_bytes())
 for q in cases:
  if not q['native_supported']:continue
  state.clear();state.update(q=q,tags={},trace=[])
  for label in ['zombie','damage','other','project','board-a','board-b','bank-a','bank-b','audio-a','audio-b']:state[label]=make(label)
  state['slot']=im.alloc(8);put64(state['slot'],state['damage']);putf(state['damage']+off('Damage','damagePoint'),-7);putf(state['other']+off('Damage','damagePoint'),-9);put32(state['zombie']+off('Zombie','ID'),q.get('id',0));p=state['project'];put32(p+off('Project','projectType'),q.get('kind',0));put64(p+off('Project','board'),state['board-a']);put64(p+off('Project','projectManager'),state['audio-a']);put64(state['board-a']+off('Board','projectManager'),state['bank-a']);put64(state['board-b']+off('Board','projectManager'),state['bank-b']);rid=int(q['token'],16)&0xffffff;entry=int(cfgs[rid]['entry'],16)
  if rid==0x445:C.CFUNCTYPE(None,P,P,I,I,P)(entry)(state['zombie'],state['slot'],q.get('target',0),q.get('impact',0),None)
  else:C.CFUNCTYPE(None,P,P,P)(entry)(p,None,None)
  assert not im.errors,(q,im.errors);rows.append(dict(name=q['name'],token=q['token'],error=None,trace=list(state['trace']),state=snapshot(rid)))
 actual=json.loads(Path(sys.argv[1]).read_bytes());assert actual['candidate_sha256']==hashlib.sha256((Q/'candidate9.dll').read_bytes()).hexdigest();byname={r['name']:r for r in actual['results']};assert len(byname)==len(cases) and set(byname)=={q['name'] for q in cases};diff=[dict(original=r,actual=byname[r['name']]) for r in rows if r!=byname[r['name']]]
 report=dict(scope='TWO_UNCHANGED_NATIVE_DAMAGE_AND_PROJECT_CLICK_CALLERS_VS_COMPLETE_CANDIDATE_CIL',candidate_sha256=actual['candidate_sha256'],original_pc_sha256=hashlib.sha256(im.raw).hexdigest(),caller_bytes_verified=2,normal_records=len(rows),per_method=dict(collections.Counter(r['token'] for r in rows)),differences=diff,results=rows,callback_errors=im.errors,managed_only_exception_records=[r for r in actual['results'] if not next(q for q in cases if q['name']==r['name'])['native_supported']],controlled_leaves=['Zombie.GetATK/GetMS with byref root and ID callback mutation','Project.Collect/ProjectManager bank/audio','Original SSE constants and dispatch instructions execute unchanged'],limitations=['No actual ATK/MS buff pipeline, inventory effects or audio playback','No native exceptions/SEH or NaN payload proof','Finite caller profiles do not establish universal equivalence'],formal_or_product_acceptance=False);Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k not in ['results','differences','managed_only_exception_records']}));print('differences',len(diff));assert not diff
finally:im.close()
