"""Counter and final-write physical faults for each complete frame body."""
from pathlib import Path
import hashlib,json,struct,subprocess,sys
Q=Path(__file__).resolve().parent;ROOT=Q.parents[2];P=Q/'shared-candidate9';O=P/'frame-controls';O.mkdir(exist_ok=True);sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
base=(Q/'candidate9.dll').read_bytes();pe=dnfile.dnPE(data=base);n=json.loads((P/'NATIVE-FRAMES.json').read_bytes());assert not n['differences'];expected={r['name']:r for r in n['results']};methods={m['token']:m for m in json.loads((P/'ALL-CIL.json').read_bytes())['methods']};rows=[]
for rid in [0x7b4,0x7d2]:
 for fault in ['wrong-frame-increment','omit-final-interval-store']:
  data=bytearray(base);at=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[rid-1].Rva);h=(struct.unpack_from('<H',data,at)[0]>>12)*4;m=methods[f'0x{0x6000000|rid:08X}']
  if fault=='wrong-frame-increment':i=next(i for i in m['instructions'] if i['opcode']=='ldc.i4' and i['operand']==1);p=at+h+i['offset'];assert data[p]==0x20;struct.pack_into('<i',data,p+1,2)
  else:i=next(i for i in m['instructions'] if i['opcode']=='stfld' and i['operand']['identity'].endswith('::m_LastInterval'));p=at+h+i['offset'];assert data[p]==0x7d;data[p:p+5]=bytes.fromhex('2626000000')
  label=f'{rid:03x}-'+fault;file=O/(label+'.dll');file.write_bytes(data);out=O/(label+'.runtime.json');run=subprocess.run([str(ROOT/'.local/dotnet10/dotnet.exe'),str(Q/'runtime-frames/bin/Release/net10.0/Fixture.dll'),str(file),str(ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'),str(Q/'FRAME-CASES.json'),str(out)],capture_output=True,timeout=45);(O/(label+'.stdout.log')).write_bytes(run.stdout);(O/(label+'.stderr.log')).write_bytes(run.stderr);assert run.returncode==0,(label,'Process failure is not detection',run.returncode);actual=json.loads(out.read_bytes());assert actual['candidate_sha256']==hashlib.sha256(data).hexdigest();different=[dict(original=expected[r['name']],actual=r) for r in actual['results'] if expected[r['name']]!=r];assert different and all(d['original']['token']==f'0x{0x6000000|rid:08X}' for d in different)
  rows.append(dict(token=f'0x{0x6000000|rid:08X}',fault=fault,physical_sha256=actual['candidate_sha256'],different_records=len(different),differences=different,status='RUNTIME_DIFFERENCE_DETECTED'))
report=dict(scope='FOUR_PHYSICAL_FRAME_CALLER_BEHAVIOR_FAULTS',candidate_sha256=hashlib.sha256(base).hexdigest(),variants=4,runtime_detected=4,process_failures=0,results=rows,formal_or_product_acceptance=False);(P/'FRAME-CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k!='results'}))
