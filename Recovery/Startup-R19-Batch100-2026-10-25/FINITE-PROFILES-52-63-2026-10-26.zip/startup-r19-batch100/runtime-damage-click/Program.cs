using System.Reflection;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public class Damage{public string Tag="";public float damagePoint;}
public class Zombie
{
 public int ID;
 public float GetATK(){float f=Program.F("atk",1);Program.Trace.Add("ATK:"+Program.Bits(f));if(Program.Mode=="atk-fields"){ID=22;Program.RootDamage=Program.OtherDamage;}return f;}
 public float GetMS(){float f=Program.F("ms",1);Program.Trace.Add("MS:"+Program.Bits(f));if(Program.Mode=="ms-fields"){ID=3;Program.RootDamage=Program.OtherDamage;}return f;}
}
public class Mouse{}
public class Manager
{
 public string Tag="";
 public void Awake_MoneyBank(int kind){Program.Trace.Add("Bank:"+Tag+":"+kind);if(Program.Mode=="bank-fields"){Program.Project.projectManager=Program.OtherManager;Program.Project.projectType=5;}}
 public void PlayAudio_Click(Project p){if(p!=Program.Project)throw new Exception("Project identity");Program.Trace.Add("Audio:"+Tag);if(Program.Mode=="audio-fields")p.projectType=6;}
}
public class Board{public Manager projectManager=null!;}
public class Project
{
 public int projectType;public Board board=null!;public Manager projectManager=null!;
 public void Collect(){Program.Trace.Add("Collect");if(Program.Mode=="collect-fields"){board=Program.OtherBoard;projectManager=Program.OtherManager;projectType=8;}}
}
public delegate void DamageCall(Zombie z,ref Damage? d,int target,int impact);
public static class Program
{
 public static JsonElement Case;public static List<string> Trace=[];public static Damage Damage=null!,OtherDamage=null!;public static Damage? RootDamage;public static Zombie Zombie=null!;public static Project Project=null!;public static Board OtherBoard=null!;public static Manager OtherManager=null!;
 public static string Mode=>Case.GetProperty("mode").GetString()!;
 public static int N(string k,int d=0)=>Case.TryGetProperty(k,out var v)?v.GetInt32():d;
 public static float F(string k,float d=0)=>Case.TryGetProperty(k,out var v)?BitConverter.UInt32BitsToSingle(Convert.ToUInt32(v.GetString(),16)):d;
 public static string Bits(float f)=>float.IsNaN(f)?"NaN":BitConverter.SingleToUInt32Bits(f).ToString("X8");
 static Type Map(MC.TypeReference t)
 {
  if(t is MC.ByReferenceType b)return Map(b.ElementType).MakeByRefType();
  return t.FullName switch{"System.Void"=>typeof(void),"System.Single"=>typeof(float),"System.Int32" or "ProjectType"=>typeof(int),"Zombie"=>typeof(Zombie),"Damage"=>typeof(Damage),"Project"=>typeof(Project),"Board"=>typeof(Board),"ProjectManager"=>typeof(Manager),"MouseManager"=>typeof(Mouse),_=>throw new NotSupportedException(t.FullName)};
 }
 static FieldInfo Field(MC.FieldReference f)=>Map(f.DeclaringType).GetField(f.Name)!;
 static MethodBase Method(MC.MethodReference m)=>Map(m.DeclaringType).GetMethod(m.Name,BindingFlags.Public|BindingFlags.Static|BindingFlags.Instance,null,m.Parameters.Select(p=>Map(p.ParameterType)).ToArray(),null)!;
 public static void Main(string[] args)
 {
  var resolver=new MC.DefaultAssemblyResolver();resolver.AddSearchDirectory(args[1]);using var asm=MC.AssemblyDefinition.ReadAssembly(args[0],new MC.ReaderParameters{AssemblyResolver=resolver});var click=ActualCil.Emit((MC.MethodDefinition)asm.MainModule.LookupToken(0x60003c2),Map,Field,Method);var damage=(DamageCall)ActualCil.Emit((MC.MethodDefinition)asm.MainModule.LookupToken(0x6000445),Map,Field,Method).CreateDelegate(typeof(DamageCall));using var cases=JsonDocument.Parse(File.ReadAllText(args[2]));var rows=new List<object>();
  foreach(var q in cases.RootElement.EnumerateArray())
  {
   Case=q;Trace.Clear();Damage=new(){Tag="damage",damagePoint=-7};OtherDamage=new(){Tag="other",damagePoint=-9};RootDamage=N("damage",1)==0?null:Damage;Zombie=new(){ID=N("id")};OtherManager=new(){Tag="audio-b"};OtherBoard=new(){projectManager=new(){Tag="bank-b"}};Project=new(){projectType=N("kind"),board=new(){projectManager=new(){Tag="bank-a"}},projectManager=new(){Tag="audio-a"}};int rid=Convert.ToInt32(q.GetProperty("token").GetString(),16)&0xffffff;string? error=null;
   try{if(rid==0x445)damage(Zombie,ref RootDamage,N("target"),N("impact"));else click.Invoke(null,[Project,new Mouse()]);}catch(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;error=e.GetType().FullName;}
   object state=rid==0x445?new{id=Zombie.ID,root=RootDamage?.Tag??"null",damage=Bits(Damage.damagePoint),other=Bits(OtherDamage.damagePoint)}:new{kind=Project.projectType,board=Project.board==OtherBoard?"other":"initial",manager=Project.projectManager.Tag};rows.Add(new{name=q.GetProperty("name").GetString(),token=q.GetProperty("token").GetString(),error,trace=Trace.ToArray(),state});
  }
  File.WriteAllText(args[3],JsonSerializer.Serialize(new{scope="TWO_COMPLETE_CANDIDATE_DAMAGE_BYREF_AND_PROJECT_CLICK_BODIES_CONTROLLED_CALLEES",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),results=rows,methods=2,eh_removed=false,private_access_bypass=false,unity_or_product_acceptance=false},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{records=rows.Count,methods=2}));
 }
}
