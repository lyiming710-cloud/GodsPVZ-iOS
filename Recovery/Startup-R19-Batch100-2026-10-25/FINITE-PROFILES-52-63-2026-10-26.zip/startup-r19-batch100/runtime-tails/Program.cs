using System.Reflection;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public class Item{public string Tag="";}
public class PreDevice:Item{}
public class EnemyPath:Item{}
public class Supplies:Item{public int ID;}
public class SuppliesInfo:Item{}
public class DeviceEditor{public PreDevice? preDevice;public void LoadData(){Program.Trace.Add("DeviceLoad:"+Program.Tag(preDevice));if(Program.Mode=="tail-replaces")preDevice=Program.OtherDevice;}}
public class PathEditor{public EnemyPath? enemyPath;public void LoadData(){Program.Trace.Add("PathLoad:"+Program.Tag(enemyPath));if(Program.Mode=="tail-replaces")enemyPath=Program.OtherPath;}}
public class Warehouse
{
 public Supplies? supplies;public SuppliesInfo? suppliesInfo;
 public void SetInfo(){Program.Trace.Add("SetInfo:"+Program.Tag(supplies)+":"+Program.Tag(suppliesInfo));if(Program.Mode=="tail-replaces"){supplies=Program.OtherSupply;suppliesInfo=Program.OtherInfo;}}
}
public static class Resource
{
 public static SuppliesInfo? GetSuppliesInfo(int id){Program.Trace.Add("Lookup:"+id);if(Program.Mode=="lookup-replaces"){Program.Page.supplies=Program.OtherSupply;Program.Page.suppliesInfo=Program.OtherInfo;Program.Supply.ID=-999;}return Program.N("lookup_result")==0?null:Program.N("lookup_result")==1?Program.Info:Program.OtherInfo;}
}
public class Plant:Item
{
 public int Hits;public string? Last;
 public void Healed(float amount,Plant? healer){Last=Program.Tag(this)+":"+Program.Bits(amount)+":"+Program.Tag(healer);Program.Trace.Add("Healed:"+Last);Hits++;}
}
public class PlantSave{public int ID;}
public class Text:Item
{
 public string? Last;public bool Force;
 public void SetText(string value,bool force){Last=value;Force=force;Program.Trace.Add("SetText:"+Tag+":"+value+":"+(force?1:0));if(Program.Mode=="text-replaces")Program.Almanac.painter=Program.OtherText;}
}
public class Almanac{public Text? painter;}
public static class Strings
{
 public static string Concat(string a,string b){Program.Trace.Add("Concat:"+a+"|"+b);if(Program.Mode=="concat-replaces"){Program.Almanac.painter=Program.OtherText;Program.Save.ID=49;}return string.Concat(a,b);}
}
public class Material:Item{}
public class Renderer:Item
{
 public Material? Value;
 public Material? material{get{Program.Trace.Add("Material:"+Tag);if(Program.Mode=="material-replaces")Program.Shader.m_Renderer=Program.OtherRenderer;return Value;}}
}
public class Shader
{
 public Renderer? m_Renderer;public Material? m_Material;
 public T? GetComponent<T>() where T:class{Program.Trace.Add("GetComponent:Renderer");if(Program.Mode=="component-replaces")m_Renderer=Program.OtherRenderer;return Program.N("renderer")==0?null:(T)(object)(Program.N("renderer")==1?Program.Renderer:Program.OtherRenderer);}
}
public static class Program
{
 public static JsonElement Case;public static List<string> Trace=[];public static DeviceEditor Device=null!;public static PathEditor Path=null!;public static Warehouse Page=null!;public static PreDevice OtherDevice=null!;public static EnemyPath OtherPath=null!;public static Supplies Supply=null!,OtherSupply=null!;public static SuppliesInfo Info=null!,OtherInfo=null!;public static Plant A=null!,B=null!;public static PlantSave Save=null!;public static Almanac Almanac=null!;public static Text Text=null!,OtherText=null!;public static Shader Shader=null!;public static Renderer Renderer=null!,OtherRenderer=null!;
 public static string Mode=>Case.GetProperty("mode").GetString()!;
 public static int N(string k,int d=0)=>Case.TryGetProperty(k,out var v)?v.GetInt32():d;
 public static string Tag(Item? item)=>item?.Tag??"null";
 public static string Bits(float f)=>float.IsNaN(f)?"NaN":BitConverter.SingleToUInt32Bits(f).ToString("X8");
 static Type Map(MC.TypeReference t)
 {
  if(t is MC.ByReferenceType b)return Map(b.ElementType).MakeByRefType();
  return t.FullName switch{"System.Void"=>typeof(void),"System.Boolean"=>typeof(bool),"System.Int32"=>typeof(int),"System.Single"=>typeof(float),"System.Object"=>typeof(object),"System.String"=>typeof(string),"PreDevice"=>typeof(PreDevice),"Device_boardEditor"=>typeof(DeviceEditor),"EnemyPath"=>typeof(EnemyPath),"Path_enemyEditor"=>typeof(PathEditor),"Supplies"=>typeof(Supplies),"SuppliesInfo"=>typeof(SuppliesInfo),"Warehouse_SuppliesInfoPage"=>typeof(Warehouse),"ResourceManager"=>typeof(Resource),"Plant"=>typeof(Plant),"PlantSave"=>typeof(PlantSave),"Almanac_OtherPlantInfo"=>typeof(Almanac),"TMPro.TextMeshProUGUI" or "TMPro.TMP_Text"=>typeof(Text),"TMPro.Examples.ShaderPropAnimator"=>typeof(Shader),"UnityEngine.Renderer"=>typeof(Renderer),"UnityEngine.Material"=>typeof(Material),_=>throw new NotSupportedException(t.FullName)};
 }
 static FieldInfo Field(MC.FieldReference f)=>Map(f.DeclaringType).GetField(f.Name)!;
 static MethodBase Method(MC.MethodReference m)
 {
  if(m.Name=="GetComponent"&&m is MC.GenericInstanceMethod g)return typeof(Shader).GetMethod("GetComponent")!.MakeGenericMethod(g.GenericArguments.Select(Map).ToArray());
  if(m.DeclaringType.FullName=="System.String"&&m.Name=="Concat")return typeof(Strings).GetMethod("Concat")!;
  return Map(m.DeclaringType).GetMethod(m.Name,BindingFlags.Public|BindingFlags.Instance|BindingFlags.Static,null,m.Parameters.Select(p=>Map(p.ParameterType)).ToArray(),null)!;
 }
 static object Snapshot(int rid)=>rid switch
 {
  0x38=>new{item=Tag(Device.preDevice)},0x5f=>new{item=Tag(Path.enemyPath)},0x6f0=>new{item=Tag(Page.supplies),info=Tag(Page.suppliesInfo),input_id=Supply.ID},0x377=>new{a_hits=A.Hits,a_last=A.Last,b_hits=B.Hits,b_last=B.Last},0x56d=>new{painter=Tag(Almanac.painter),text=Text.Last,force=Text.Force,other_text=OtherText.Last,other_force=OtherText.Force,save_id=Save.ID},0x762=>new{renderer=Tag(Shader.m_Renderer),material=Tag(Shader.m_Material)},_=>throw new Exception()
 };
 public static void Main(string[] args)
 {
  var resolver=new MC.DefaultAssemblyResolver();resolver.AddSearchDirectory(args[1]);using var asm=MC.AssemblyDefinition.ReadAssembly(args[0],new MC.ReaderParameters{AssemblyResolver=resolver});int[] ids={0x38,0x5f,0x377,0x6f0,0x56d,0x762};var code=ids.ToDictionary(r=>r,r=>ActualCil.Emit((MC.MethodDefinition)asm.MainModule.LookupToken(0x6000000|r),Map,Field,Method));using var cases=JsonDocument.Parse(File.ReadAllText(args[2]));var rows=new List<object>();
  foreach(var q in cases.RootElement.EnumerateArray())
  {
   Case=q;Trace.Clear();OtherDevice=new(){Tag="other"};OtherPath=new(){Tag="other"};Device=new(){preDevice=new(){Tag="stale"}};Path=new(){enemyPath=new(){Tag="stale"}};Supply=new(){Tag="input",ID=N("id")};OtherSupply=new(){Tag="other",ID=999};Info=new(){Tag="info"};OtherInfo=new(){Tag="other-info"};Page=new(){supplies=OtherSupply,suppliesInfo=OtherInfo};A=new(){Tag="a"};B=new(){Tag="b"};Save=new(){ID=N("id")};Text=new(){Tag="text"};OtherText=new(){Tag="other-text"};Almanac=new(){painter=N("painter",1)==0?null:Text};Renderer=new(){Tag="renderer",Value=N("material",1)==0?null:new(){Tag="material"}};OtherRenderer=new(){Tag="other-renderer",Value=new(){Tag="other-material"}};Shader=new(){m_Renderer=OtherRenderer,m_Material=new(){Tag="stale-material"}};
   int rid=Convert.ToInt32(q.GetProperty("token").GetString(),16)&0xffffff;Plant? healer=N("healer",1)==0?null:N("healer",1)==1?A:B;Plant? target=N("target",2)==0?null:N("target",2)==1?A:B;float amount=q.TryGetProperty("amount",out var v)?BitConverter.UInt32BitsToSingle(Convert.ToUInt32(v.GetString(),16)):0;
   object?[] call=rid switch{0x38=>[Device,N("input",1)==0?null:new PreDevice{Tag="input"}],0x5f=>[Path,N("input",1)==0?null:new EnemyPath{Tag="input"}],0x377=>[healer,amount,target],0x6f0=>[Page,N("input",1)==0?null:Supply],0x56d=>[Almanac,N("input",1)==0?null:Save],0x762=>[Shader],_=>throw new Exception()};string? error=null;
   try{code[rid].Invoke(null,call);}catch(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;error=e.GetType().FullName;}
   rows.Add(new{name=q.GetProperty("name").GetString(),token=q.GetProperty("token").GetString(),error,trace=Trace.ToArray(),state=Snapshot(rid)});
  }
  File.WriteAllText(args[3],JsonSerializer.Serialize(new{scope="SIX_COMPLETE_CANDIDATE_TAIL_DISPATCH_AND_SHADER_BODIES_CONTROLLED_CALLEES",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),methods=6,rehost_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[4]))).ToLowerInvariant(),results=rows,eh_removed=false,private_access_bypass=false,unity_or_product_acceptance=false},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{records=rows.Count,methods=6}));
 }
}
