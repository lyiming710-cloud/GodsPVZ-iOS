"""Run six unchanged PC callers; model only declared external leaf contracts.

This is a finite normal-path profile. Native exceptions, Unity rendering,
real material lifetime, GC and universal equivalence are not established.
"""
from pathlib import Path
import collections,ctypes as C,functools,hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
ids=[0x38,0x5f,0x377,0x6f0,0x56d,0x762];im=NativeImage();state={}
cfgs={rid:json.loads((Q/'native-source-complete'/f'0x{0x6000000|rid:08X}.json').read_bytes()) for rid in ids}
fields=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_bytes())
@functools.lru_cache(None)
def off(owner,name):
 rows=[r for r in fields if ((r['namespace']+'.' if r['namespace'] else '')+r['type'])==owner and r['name']==name];assert len(rows)==1,(owner,name,rows);return rows[0]['offset']
def string(s):
 if s is None:return 0
 b=s.encode('utf-16-le');p=im.alloc(24+len(b));put32(p+0x10,len(b)//2);C.memmove(p+0x14,b,len(b));return p
def text(p):return None if not p else C.string_at(p+0x14,get32(p+0x10)*2).decode('utf-16-le')
def mode():return state['q']['mode']
def tag(p):return 'null' if not p else state['tags'][p]
def field(owner,name):return state['self']+off(owner,name)
def make(label):
 p=im.alloc(256);state['tags'][p]=label;return p
def device(p,method):
 assert p==state['self'] and not method;at=field('Device_boardEditor','preDevice');state['trace'].append('DeviceLoad:'+tag(get64(at)))
 if mode()=='tail-replaces':put64(at,state['other'])
def path(p,method):
 assert p==state['self'] and not method;at=field('Path_enemyEditor','enemyPath');state['trace'].append('PathLoad:'+tag(get64(at)))
 if mode()=='tail-replaces':put64(at,state['other'])
def lookup(ident,method):
 assert not method;state['trace'].append('Lookup:'+str(ident))
 if mode()=='lookup-replaces':put64(field('Warehouse_SuppliesInfoPage','supplies'),state['other']);put64(field('Warehouse_SuppliesInfoPage','suppliesInfo'),state['other-info']);put32(state['input']+off('Supplies','ID'),-999)
 n=state['q'].get('lookup_result',0);return 0 if n==0 else state['info'] if n==1 else state['other-info']
def setinfo(p,method):
 assert p==state['self'] and not method;sa=field('Warehouse_SuppliesInfoPage','supplies');ia=field('Warehouse_SuppliesInfoPage','suppliesInfo');state['trace'].append('SetInfo:'+tag(get64(sa))+':'+tag(get64(ia)))
 if mode()=='tail-replaces':put64(sa,state['other']);put64(ia,state['other-info'])
def healed(target,amount,healer,method):
 assert not method and tag(target) in ['a','b'];last=tag(target)+':'+bits(amount)+':'+tag(healer);state['trace'].append('Healed:'+last);k=tag(target);state[k+'_hits']+=1;state[k+'_last']=last
def concat(a,b,method):
 assert not method;a,b=text(a),text(b);state['trace'].append('Concat:'+a+'|'+b)
 if mode()=='concat-replaces':put64(field('Almanac_OtherPlantInfo','painter'),state['other-text']);put32(state['input']+off('PlantSave','ID'),49)
 return string(a+b)
def settext(p,s,force,method):
 assert not method and tag(p) in ['text','other-text'];value=text(s);key='text' if p==state['text'] else 'other_text';state['text_value' if key=='text' else key]=value;state[key+'_force']=bool(force);state['trace'].append('SetText:'+tag(p)+':'+value+':'+str(int(force)))
 if mode()=='text-replaces':put64(field('Almanac_OtherPlantInfo','painter'),state['other-text'])
def component(p,method):
 assert p==state['self'] and method in state['metadata_handles'];state['trace'].append('GetComponent:Renderer')
 if mode()=='component-replaces':put64(field('TMPro.Examples.ShaderPropAnimator','m_Renderer'),state['other-renderer'])
 n=state['q'].get('renderer',1);return 0 if n==0 else state['renderer'] if n==1 else state['other-renderer']
def material(p,method):
 assert not method and tag(p) in ['renderer','other-renderer'];state['trace'].append('Material:'+tag(p))
 if mode()=='material-replaces':put64(field('TMPro.Examples.ShaderPropAnimator','m_Renderer'),state['other-renderer'])
 return state['renderer_materials'][p]
def snapshot(rid):
 if rid==0x38:return dict(item=tag(get64(field('Device_boardEditor','preDevice'))))
 if rid==0x5f:return dict(item=tag(get64(field('Path_enemyEditor','enemyPath'))))
 if rid==0x6f0:return dict(item=tag(get64(field('Warehouse_SuppliesInfoPage','supplies'))),info=tag(get64(field('Warehouse_SuppliesInfoPage','suppliesInfo'))),input_id=get32(state['input']+off('Supplies','ID')))
 if rid==0x377:return {k:state[k] for k in ['a_hits','a_last','b_hits','b_last']}
 if rid==0x56d:return dict(painter=tag(get64(field('Almanac_OtherPlantInfo','painter'))),text=state['text_value'],force=state['text_force'],other_text=state['other_text'],other_force=state['other_text_force'],save_id=get32(state['input']+off('PlantSave','ID')))
 if rid==0x762:return dict(renderer=tag(get64(field('TMPro.Examples.ShaderPropAnimator','m_Renderer'))),material=tag(get64(field('TMPro.Examples.ShaderPropAnimator','m_Material'))))
 raise AssertionError(rid)
try:
 meta=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/global-metadata.dat').read_bytes();assert hashlib.sha256(meta).hexdigest()=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9'
 so,sn,do,dn=struct.unpack_from('<4I',meta,8);dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True;slots=set();handles=set()
 for cfg in cfgs.values():
  for row in cfg['instructions']:
   i=next(dis.disasm(bytes.fromhex(row['bytes']),int(row['va'],16)))
   if i.mnemonic not in ['mov','lea']:continue
   for op in i.operands:
    if op.type!=X86_OP_MEM or op.mem.base!=X86_REG_RIP:continue
    at=i.address+i.size+op.mem.disp;raw=im.pe.get_data(at-im.base,8)
    if len(raw)!=8:continue
    code=int.from_bytes(raw,'little')
    if code>0xffffffff or code>>29 not in range(1,8):continue
    if at in slots:continue
    slots.add(at);kind,index=code>>29,(code&0x1fffffff)>>1
    if kind==5:n,pos=struct.unpack_from('<II',meta,so+8*index);put64(at,string(meta[do+pos:do+pos+n].decode('utf-8')))
    else:cls=im.class_slot(at);handles.add(cls);put64(get64(cls+0xb8),string(''))
 def init(at):assert at in slots,hex(at)
 im.hook(0x18024fef0,None,[P],init);im.hook(0x1802501e0,None,[P],lambda p:None);im.hook(0x18024f360,None,[P,P],lambda at,p:assert_barrier(at,p))
 def assert_barrier(at,p):assert get64(at)==(p or 0)
 im.hook(0x180303880,None,[P,P],device);im.hook(0x180306260,None,[P,P],path);im.hook(0x18032fd30,P,[I,P],lookup);im.hook(0x1803ae670,None,[P,P],setinfo);im.hook(0x180351680,None,[P,F,P,P],healed);im.hook(0x180b74270,P,[P,P,P],concat);im.hook(0x1811af070,None,[P,P,C.c_bool,P],settext);im.hook(0x18042e9f0,P,[P,P],component);im.hook(0x1812fae70,P,[P,P],material)
 for rid,cfg in cfgs.items():im.verify_caller(rid,int(cfg['entry'],16),cfg)
 cases=json.loads((Q/'TAIL-CASES.json').read_bytes());rows=[]
 for q in cases:
  if not q['native_supported']:continue
  state.clear();state.update(q=q,tags={},trace=[],metadata_handles=handles,a_hits=0,a_last=None,b_hits=0,b_last=None,text_value=None,text_force=False,other_text=None,other_text_force=False)
  for label in ['self','input','other','stale','info','other-info','a','b','text','other-text','renderer','other-renderer','material','other-material','stale-material']:state[label]=make(label)
  state['renderer_materials']={state['renderer']:state['material'] if q.get('material',1) else 0,state['other-renderer']:state['other-material']}
  rid=int(q['token'],16)&0xffffff;entry=int(cfgs[rid]['entry'],16);arg=state['input'] if q.get('input',1) else 0
  if rid==0x38:put64(field('Device_boardEditor','preDevice'),state['stale'])
  elif rid==0x5f:put64(field('Path_enemyEditor','enemyPath'),state['stale'])
  elif rid==0x6f0:put32(state['input']+off('Supplies','ID'),q.get('id',0));put64(field('Warehouse_SuppliesInfoPage','supplies'),state['other']);put64(field('Warehouse_SuppliesInfoPage','suppliesInfo'),state['other-info'])
  elif rid==0x56d:put32(state['input']+off('PlantSave','ID'),q.get('id',0));put64(field('Almanac_OtherPlantInfo','painter'),state['text'])
  elif rid==0x762:put64(field('TMPro.Examples.ShaderPropAnimator','m_Renderer'),state['other-renderer']);put64(field('TMPro.Examples.ShaderPropAnimator','m_Material'),state['stale-material'])
  if rid==0x377:
   hp=q.get('healer',1);tp=q.get('target',2);amount=struct.unpack('>f',bytes.fromhex(q['amount']))[0];healer=0 if hp==0 else state['a'] if hp==1 else state['b'];target=state['a'] if tp==1 else state['b'];C.CFUNCTYPE(None,P,F,P,P)(entry)(healer,amount,target,None)
  elif rid==0x762:C.CFUNCTYPE(None,P,P)(entry)(state['self'],None)
  else:C.CFUNCTYPE(None,P,P,P)(entry)(state['self'],arg,None)
  assert not im.errors,(q,im.errors)
  # The text object pointer remains available independently of its text value.
  if 'text' in state and not isinstance(state['text'],int):raise AssertionError('Pointer label overwritten')
  rows.append(dict(name=q['name'],token=q['token'],error=None,trace=list(state['trace']),state=snapshot(rid)))
 actual=json.loads(Path(sys.argv[1]).read_bytes());expected_sha=hashlib.sha256((Q/'candidate9.dll').read_bytes()).hexdigest();assert actual['candidate_sha256']==expected_sha;byname={r['name']:r for r in actual['results']};assert len(byname)==len(cases) and set(byname)=={q['name'] for q in cases};diff=[dict(original=r,actual=byname[r['name']]) for r in rows if r!=byname[r['name']]]
 report=dict(scope='SIX_UNCHANGED_ORIGINAL_PC_CALLERS_VS_COMPLETE_CANDIDATE_CIL_FINITE_NORMAL_PROFILES',candidate_sha256=actual['candidate_sha256'],original_pc_sha256=hashlib.sha256(im.raw).hexdigest(),caller_bytes_verified=6,normal_records=len(rows),per_method=dict(collections.Counter(r['token'] for r in rows)),managed_only_exception_records=[r for r in actual['results'] if not next(q for q in cases if q['name']==r['name'])['native_supported']],results=rows,differences=diff,callback_errors=im.errors,controlled_leaves=['Device/Path LoadData','ResourceManager lookup and page SetInfo','Plant.Healed','String.Concat and TMP.SetText','GetComponent<Renderer> and Renderer.material','Metadata and GC barrier'],limitations=['No native exceptions or SEH unwind','Controlled renderer is nonpersistent; no Unity material rendering/lifetime proof','Controlled callbacks do not establish callee internals or universal equivalence'],formal_or_product_acceptance=False)
 Path(sys.argv[2]).write_text(json.dumps(report,indent=2,ensure_ascii=True)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k not in ['results','differences','managed_only_exception_records']}));print('differences',len(diff));assert not diff
finally:im.close()
