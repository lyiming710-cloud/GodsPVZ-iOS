"""Resolution by-reference reads and level challenge/receiver capture profiles."""
from pathlib import Path
import collections,itertools,json
Q=Path(__file__).resolve().parent;rows=[]
def add(rid,**v):
 q=dict(name='u'+str(len(rows)).zfill(4),token=f'0x{0x6000000|rid:08X}',mode='none',native_supported=True);q.update(v);rows.append(q)
for wh,rate,mode in itertools.product([(1920,1080),(1280,720),(0,0),(-1,2147483647)],[(60,1),(60000,1001),(0,0),(4294967295,4294967295)],['none','width-fields','height-fields','set-fields']):add(0x713,width=wh[0],height=wh[1],numerator=rate[0],denominator=rate[1],mode=mode)
for challenge,level,text,mode in itertools.product([-2147483648,-1,0,1,2,3,4,2147483647],[0,2],[None,'Level'],['none','item-fields','sprite-fields','text-fields','refresh-fields']):add(0x62b,challenge=challenge,level=level,text=text,mode=mode)
for challenge in [0,1,3]:add(0x62b,challenge=challenge,level=1,text='null-sprite',null_sprite=1)
for app,manager in [(0,1),(1,0)]:add(0x62b,challenge=0,level=0,text='blocked',app=app,manager=manager,native_supported=False)
for level in [-1,3]:add(0x62b,challenge=0,level=level,text='bad-index',native_supported=False)
(Q/'UI-INIT-CASES.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(records=len(rows),native=sum(q['native_supported'] for q in rows),per_method=dict(collections.Counter(q['token'] for q in rows)))))
