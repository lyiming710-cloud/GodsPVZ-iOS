"""Original resolution/level callers with explicit by-reference/leaf contracts."""
from pathlib import Path
import collections,ctypes as C,functools,hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
im=NativeImage();state={};ids=[0x62b,0x713];cfgs={rid:json.loads((Q/'native-source-complete'/f'0x{0x6000000|rid:08X}.json').read_bytes()) for rid in ids};fields=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_bytes())
@functools.lru_cache(None)
def off(owner,name):
 rs=[r for r in fields if r['namespace']=='' and r['type']==owner and r['name']==name];assert len(rs)==1,(owner,name,rs);return rs[0]['offset']
def at(name):return state['self']+off('LevelItem',name)
def string(s):
 if s is None:return 0
 b=s.encode('utf-16-le');p=im.alloc(24+len(b));put32(p+0x10,len(b)//2);C.memmove(p+0x14,b,len(b));return p
def text(p):return None if not p else C.string_at(p+0x14,get32(p+0x10)*2).decode('utf-16-le')
def tag(p):return 'null' if not p else state['tags'][p]
def mode():return state['q']['mode']
def make(label):
 p=im.alloc(256);state['tags'][p]=label;return p
def current(p,method):
 assert not method;state['trace'].append('Resolution');C.memmove(p,struct.pack('<iiII',*state['resolution']),16);return p
def width(p,method):
 assert not method;n=get32(p);state['trace'].append('Width:'+str(n))
 if mode()=='width-fields':put32(p+4,999);C.memmove(p+8,struct.pack('<II',120000,1001),8)
 return n
def height(p,method):
 assert not method;n=get32(p+4);state['trace'].append('Height:'+str(n))
 if mode()=='height-fields':C.memmove(p+8,struct.pack('<II',240000,1001),8)
 return n
def rate(p,method):
 assert not method;n,d=struct.unpack('<II',C.string_at(p+8,8));state['trace'].append('Rate:'+str(n)+'/'+str(d));return n|(d<<32)
def set4(w,h,m,ratevalue,method):
 assert not method;n,d=ratevalue&0xffffffff,ratevalue>>32;state['trace'].append(f'Set4:{w}:{h}:{m}:{n}/{d}')
 if mode()=='set-fields':state['resolution']=(-2,-3,1,2)
def set3(w,h,m,method):assert not method;state['trace'].append(f'Set3:{w}:{h}:{m}')
def item(p,index,method):
 assert method in handles and tag(p) in ['A','R','BA'] and 0<=index<3;state['trace'].append('Item:'+tag(p)+':'+str(index))
 if mode()=='item-fields':put64(at('image_inside'),state['other-image']);put64(at('text_Name'),state['other-text']);put32(at('level'),888)
 return 0 if state['q'].get('null_sprite',0) else state[tag(p)+str(index)]
def sprite(p,value,method):
 assert not method and tag(p) in ['image','other-image'];state['images'][tag(p)]=None if not value else tag(value);state['trace'].append('Sprite:'+tag(p)+':'+tag(value))
 if mode()=='sprite-fields':put64(at('text_Name'),state['other-text']);put32(at('level'),889)
def settext(p,value,force,method):
 assert not method and tag(p) in ['text','other-text'];s=text(value);state['texts'][tag(p)]=(s,bool(force));state['trace'].append('Text:'+tag(p)+':'+('null' if s is None else s)+':'+str(int(force)))
 if mode()=='text-fields':put64(at('image_inside'),state['other-image']);put32(at('level'),890)
def refresh(p,method):
 assert p==state['self'] and not method;state['trace'].append('Refresh:'+str(get32(at('level'))))
 if mode()=='refresh-fields':put32(at('level'),891)
def snapshot(rid):
 if rid==0x713:
  w,h,n,d=state['resolution'];return dict(width=w,height=h,numerator=n,denominator=d)
 t=state['texts'];return dict(level=get32(at('level')),image=tag(get64(at('image_inside'))),text_owner=tag(get64(at('text_Name'))),sprite=state['images']['image'],other_sprite=state['images']['other-image'],text=t['text'][0],force=t['text'][1],other_text=t['other-text'][0],other_force=t['other-text'][1])
try:
 meta=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/global-metadata.dat').read_bytes();assert hashlib.sha256(meta).hexdigest()=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9';so,sn,do,dn=struct.unpack_from('<4I',meta,8);dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True;slots=set();handles=set()
 for cfg in cfgs.values():
  for row in cfg['instructions']:
   i=next(dis.disasm(bytes.fromhex(row['bytes']),int(row['va'],16)))
   if i.mnemonic not in ['mov','lea']:continue
   for op in i.operands:
    if op.type!=X86_OP_MEM or op.mem.base!=X86_REG_RIP:continue
    a=i.address+i.size+op.mem.disp;raw=im.pe.get_data(a-im.base,8)
    if len(raw)!=8:continue
    code=int.from_bytes(raw,'little')
    if code>0xffffffff or code>>29 not in range(1,8) or a in slots:continue
    slots.add(a);kind,index=code>>29,(code&0x1fffffff)>>1
    if kind==5:n,pos=struct.unpack_from('<II',meta,so+8*index);put64(a,string(meta[do+pos:do+pos+n].decode('utf-8')))
    else:cls=im.class_slot(a);put64(cls+0xb8,im.alloc(512));handles.add(cls)
 def rip(va):
  i=next(dis.disasm(im.pe.get_data(va-im.base,15),va));return next(i.address+i.size+o.mem.disp for o in i.operands if o.type==X86_OP_MEM and o.mem.base==X86_REG_RIP)
 global_static=get64(get64(rip(0x18039eca3))+0xb8);resource_static=get64(get64(rip(0x18039ed0a))+0xb8)
 def init(a):assert a in slots,hex(a)
 im.hook(0x18024fef0,None,[P],init);im.hook(0x1802501e0,None,[P],lambda p:None);im.hook(0x1812fb890,P,[P,P],current);im.hook(0x1812f64f0,I,[P,P],width);im.hook(0x1809d26f0,I,[P,P],height);im.hook(0x180d0e340,C.c_uint64,[P,P],rate);im.hook(0x1812fb780,None,[I,I,I,C.c_uint64,P],set4);im.hook(0x1812fb7e0,None,[I,I,I,P],set3);im.hook(0x180825710,P,[P,I,P],item);im.hook(0x1813d7ab0,None,[P,P,P],sprite);im.hook(0x1811af070,None,[P,P,C.c_bool,P],settext);im.hook(0x18039ee10,None,[P,P],refresh)
 for rid,cfg in cfgs.items():im.verify_caller(rid,int(cfg['entry'],16),cfg)
 rows=[];cases=json.loads((Q/'UI-INIT-CASES.json').read_bytes())
 for q in cases:
  if not q['native_supported']:continue
  state.clear();state.update(q=q,tags={},trace=[],resolution=(q.get('width',1920),q.get('height',1080),q.get('numerator',60000),q.get('denominator',1001)),images={'image':None,'other-image':None},texts={'text':(None,False),'other-text':(None,False)})
  for label in ['self','app','manager','image','other-image','text','other-text','A','R','BA',*[s+str(i) for s in ['A','R','BA'] for i in range(3)]]:state[label]=make(label)
  put64(global_static,state['app']);put64(state['app']+off('LawnApp','savesManager'),state['manager'])
  for offset,label in [(0x98,'A'),(0xa0,'R'),(0xc0,'BA')]:put64(resource_static+offset,state[label])
  put32(at('level'),-7);put64(at('image_inside'),state['image']);put64(at('text_Name'),state['text']);rid=int(q['token'],16)&0xffffff;entry=int(cfgs[rid]['entry'],16)
  if rid==0x713:C.CFUNCTYPE(None,P,P)(entry)(state['self'],None)
  else:C.CFUNCTYPE(None,P,I,I,P,P)(entry)(state['self'],q.get('level',0),q.get('challenge',0),string(q['text']),None)
  assert not im.errors,(q,im.errors);rows.append(dict(name=q['name'],token=q['token'],error=None,trace=list(state['trace']),state=snapshot(rid)))
 actual=json.loads(Path(sys.argv[1]).read_bytes());assert actual['candidate_sha256']==hashlib.sha256((Q/'candidate9.dll').read_bytes()).hexdigest();byname={r['name']:r for r in actual['results']};assert len(byname)==len(cases) and set(byname)=={q['name'] for q in cases};diff=[dict(original=r,actual=byname[r['name']]) for r in rows if r!=byname[r['name']]]
 report=dict(scope='TWO_ORIGINAL_RESOLUTION_AND_LEVEL_INIT_CALLERS_VS_COMPLETE_CANDIDATE_CIL',candidate_sha256=actual['candidate_sha256'],original_pc_sha256=hashlib.sha256(im.raw).hexdigest(),caller_bytes_verified=2,normal_records=len(rows),per_method=dict(collections.Counter(r['token'] for r in rows)),differences=diff,results=rows,callback_errors=im.errors,managed_only_exception_records=[r for r in actual['results'] if not next(q for q in cases if q['name']==r['name'])['native_supported']],controlled_leaves=['Resolution 16-byte result and by-reference width/height/rate reads','Screen.SetResolution overloads and exact 8-byte rate value','Sprite-list item/Image.sprite/TMP.SetText/Level.SetState','Static manager/metadata'],limitations=['No native exceptions/SEH','No actual display switch, texture, text rendering or scene refresh','Controlled leaf contracts do not prove their internals or universal equivalence'],formal_or_product_acceptance=False);Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k not in ['results','differences','managed_only_exception_records']}));print('differences',len(diff));assert not diff
finally:im.close()
