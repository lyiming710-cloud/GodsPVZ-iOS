"""Dispatch coverage and reference-root changes during ATK/MS callbacks."""
from pathlib import Path
import collections,itertools,json
Q=Path(__file__).resolve().parent;rows=[]
def add(rid,**v):
 q=dict(name='d'+str(len(rows)).zfill(5),token=f'0x{0x6000000|rid:08X}',mode='none',native_supported=True);q.update(v);rows.append(q)
vals=['00000000','80000000','3F000000','BF800000','7F7FFFFF','7F800000','FF800000','7FC00001']
for ident,atk,target,impact in itertools.product([-2147483648,-1,*range(25),2147483647],vals,[-1,0,1],[-1,0,1,2]):add(0x445,id=ident,atk=atk,ms='3F000000',target=target,impact=impact)
table=json.loads((Q/'ORIGINAL-SWITCH-TABLES.json').read_bytes())['0x06000445']['targets'];ms_ids=[3+i for i,v in enumerate(table) if v=='0x1803607fe'];assert ms_ids
for ident,atk,ms in itertools.product(ms_ids,vals,vals):add(0x445,id=ident,atk=atk,ms=ms,target=1,impact=0)
for ident,mode,target,impact in itertools.product([-1,*range(3,23)],['atk-fields','ms-fields'],[-1,1],[0,1]):add(0x445,id=ident,mode=mode,atk='3FC00000',ms='3F400000',target=target,impact=impact)
add(0x445,id=3,atk='3F800000',ms='3F800000',damage=0,native_supported=False)
for kind,mode in itertools.product([-2147483648,-1,*range(11),2147483647],['none','collect-fields','bank-fields','audio-fields']):add(0x3c2,kind=kind,mode=mode)
(Q/'DAMAGE-CLICK-CASES.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(records=len(rows),native=sum(q['native_supported'] for q in rows),ms_dispatch_ids=ms_ids,per_method=dict(collections.Counter(q['token'] for q in rows)))))
