using System.Reflection;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public class UObj{public string Tag="";public bool Live=true;}
public class Element{public float burstTime,point;}
public class ElementManager{public Element? GetElement(int kind){if(kind!=0)throw new Exception();Program.Trace.Add("Element:0");if(Program.Mode=="element-fields")Program.Mouse.propOnHand=Program.OtherProp;return Program.N("element",1)==0?null:Program.Element;}}
public class Plant:UObj{public ElementManager? elementManager=new();public void PlantDie_Shovel(int level,int special){Program.Trace.Add("Shovel:"+level+":"+special);if(Program.Mode=="shovel-fields")Program.Mouse.propOnHand=Program.OtherProp;}}
public class Prop:UObj{public int level,specialType;public void DropDown()=>Program.Trace.Add("Drop:"+Tag);}
public class Mouse:UObj
{
 public Prop? propOnHand;
 public Plant? GetPlantUnderMouse(){Program.Trace.Add("Pick:"+Program.Tag(Program.Plant));if(Program.Mode=="pick-fields")propOnHand=Program.OtherProp;return Program.Plant;}
 public void ResetMouseState(){Program.Trace.Add("Reset");if(Program.Mode=="reset-fields")propOnHand=null;}
 public void AudioPlay(int id){Program.Trace.Add("Audio:"+Tag+":"+id);if(Program.Mode=="audio-fields"){Program.Card.seedChooserScreen=Program.OtherChooser;Program.Card.isChosen=!Program.Card.isChosen;Program.Card.plantID=779;}}
}
public class GameObject:UObj{public bool Value;public bool activeSelf{get{Program.Trace.Add("Active:"+Tag+":"+(Value?1:0));if(Program.Mode=="active-fields"){Program.Card.seedChooserScreen=Program.OtherChooser;Program.Card.isChosen=!Program.Card.isChosen;Program.Card.plantID=778;}return Value;}}}
public class Component:UObj{public GameObject? Value;public GameObject? gameObject{get{Program.Trace.Add("GameObject:"+Tag);if(Program.Mode=="gameobject-fields"){Program.Card.seedChooserScreen=Program.OtherChooser;Program.Card.plantID=777;}return Value;}}}
public class Prepare:UObj{public void SeedChoose(int id)=>Program.Trace.Add("Seed:"+Tag+":"+id);}
public class Chooser:Component{public Mouse mouseManager=null!;public Prepare prepareUIController=null!;}
public class Almanac:UObj{public void OpenPlant(int id)=>Program.Trace.Add("Open:"+Tag+":"+id);}
public class Card
{
 public Chooser? seedChooserScreen;public Almanac? almanacUIController;public int plantID;public bool isChosen;
 public void Choose_Reset(){Program.Trace.Add("ChooseReset");isChosen=false;}
 public void Choose_Being(){Program.Trace.Add("ChooseBeing");isChosen=true;}
}
public static class Program
{
 public static JsonElement Case;public static List<string> Trace=[];public static Mouse Mouse=null!;public static Plant? Plant;public static Element Element=null!;public static Prop OtherProp=null!;public static Card Card=null!;public static Chooser OtherChooser=null!;public static Almanac OtherAlmanac=null!;public static int AliveCalls;
 public static string Mode=>Case.GetProperty("mode").GetString()!;public static int N(string k,int d=0)=>Case.TryGetProperty(k,out var v)?v.GetInt32():d;public static string Tag(UObj? p)=>p?.Tag??"null";public static float F(string k)=>BitConverter.UInt32BitsToSingle(Convert.ToUInt32(Case.GetProperty(k).GetString(),16));
 public static bool Alive(UObj? p){bool value=p!=null&&p.Live;Trace.Add("Alive:"+Tag(p)+":"+(value?1:0));AliveCalls++;if(Mode=="alive-fields"&&p is Prop)Mouse.propOnHand=OtherProp;if(Mode=="alive-chooser"&&AliveCalls==1)Card.seedChooserScreen=OtherChooser;if(Mode=="alive-almanac"&&AliveCalls==2)Card.almanacUIController=OtherAlmanac;return value;}
 public static bool Equal(UObj? p,UObj? b){if(b!=null)throw new Exception("Only null comparison is in this caller");bool value=p==null||!p.Live;Trace.Add("Equal:"+Tag(p)+":"+(value?1:0));return value;}
 static Type Map(MC.TypeReference t)=>t.FullName switch{"System.Void"=>typeof(void),"System.Boolean"=>typeof(bool),"System.Int32" or "ElementType"=>typeof(int),"System.Single"=>typeof(float),"UnityEngine.Object"=>typeof(UObj),"MouseManager"=>typeof(Mouse),"Plant"=>typeof(Plant),"Prop"=>typeof(Prop),"Element"=>typeof(Element),"ElementManager"=>typeof(ElementManager),"Card_Choose"=>typeof(Card),"SeedChooserScreen"=>typeof(Chooser),"PrepareUIController"=>typeof(Prepare),"AlmanacUIController"=>typeof(Almanac),"UnityEngine.Component"=>typeof(Component),"UnityEngine.GameObject"=>typeof(GameObject),_=>throw new NotSupportedException(t.FullName)};
 static FieldInfo Field(MC.FieldReference f)=>Map(f.DeclaringType).GetField(f.Name)!;
 static MethodBase Method(MC.MethodReference m)=>m.DeclaringType.FullName=="UnityEngine.Object"?typeof(Program).GetMethod(m.Name=="op_Equality"?"Equal":"Alive")!:Map(m.DeclaringType).GetMethod(m.Name,BindingFlags.Public|BindingFlags.Static|BindingFlags.Instance,null,m.Parameters.Select(p=>Map(p.ParameterType)).ToArray(),null)!;
 public static void Main(string[] args)
 {
  var resolver=new MC.DefaultAssemblyResolver();resolver.AddSearchDirectory(args[1]);using var asm=MC.AssemblyDefinition.ReadAssembly(args[0],new MC.ReaderParameters{AssemblyResolver=resolver});int[] ids={0x1da,0x2f3};var code=ids.ToDictionary(r=>r,r=>ActualCil.Emit((MC.MethodDefinition)asm.MainModule.LookupToken(0x6000000|r),Map,Field,Method));using var cases=JsonDocument.Parse(File.ReadAllText(args[2]));var rows=new List<object>();
  foreach(var q in cases.RootElement.EnumerateArray())
  {
   Case=q;Trace.Clear();AliveCalls=0;OtherProp=new(){Tag="other-prop",level=-5,specialType=99};Mouse=new(){Tag="mouse",propOnHand=N("prop",1)==0?null:new(){Tag="prop",level=3,specialType=7,Live=N("prop",1)==1}};Plant=N("plant",1)==0?null:new(){Tag="plant",Live=N("plant",1)==1,elementManager=N("element_manager",1)==0?null:new()};Element=new(){burstTime=q.TryGetProperty("burst",out _)?F("burst"):0,point=q.TryGetProperty("point",out _)?F("point"):0};OtherChooser=new(){Tag="other-chooser",Value=new(){Tag="other-object",Value=N("active")==1},mouseManager=new(){Tag="mouse-b"},prepareUIController=new(){Tag="prepare-b"}};OtherAlmanac=new(){Tag="other-almanac"};Card=new(){plantID=N("id"),isChosen=N("chosen")==1,seedChooserScreen=N("chooser",1)==0?null:new(){Tag="chooser",Live=N("chooser",1)==1,Value=new(){Tag="object",Value=N("active")==1},mouseManager=new(){Tag="mouse-a"},prepareUIController=new(){Tag="prepare-a"}},almanacUIController=N("almanac",1)==0?null:new(){Tag="almanac",Live=N("almanac",1)==1}};int rid=Convert.ToInt32(q.GetProperty("token").GetString(),16)&0xffffff;string? error=null;
   try{code[rid].Invoke(null,[rid==0x1da?(object)Mouse:Card]);}catch(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;error=e.GetType().FullName;}
   object state=rid==0x1da?new{prop=Tag(Mouse.propOnHand)}:new{chooser=Tag(Card.seedChooserScreen),almanac=Tag(Card.almanacUIController),id=Card.plantID,chosen=Card.isChosen};rows.Add(new{name=q.GetProperty("name").GetString(),token=q.GetProperty("token").GetString(),error,trace=Trace.ToArray(),state});
  }
  File.WriteAllText(args[3],JsonSerializer.Serialize(new{scope="TWO_COMPLETE_CANDIDATE_SELECTION_BODIES_CONTROLLED_OBJECT_AND_GAME_LEAVES",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),methods=2,results=rows,eh_removed=false,private_access_bypass=false,unity_or_product_acceptance=false},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{records=rows.Count,methods=2}));
 }
}
