"""Selection routes, pseudo-null Unity objects and callback capture order."""
from pathlib import Path
import collections,itertools,json,struct
Q=Path(__file__).resolve().parent;rows=[]
def add(rid,**v):
 q=dict(name='s'+str(len(rows)).zfill(5),token=f'0x{0x6000000|rid:08X}',mode='none',native_supported=True);q.update(v);rows.append(q)
pairs=[('00000000','3F800000'),('80000000','3F800000'),('BF800000','3F800000'),('3F800000','00000000'),('3F800000','3F800000'),('7FC00001','3F800000'),('3F800000','7FC00001'),('7F800000','3F800000')]
for plant,prop,pair,element,mode in itertools.product([0,1,2],[0,1,2],pairs,[0,1],['none','pick-fields','element-fields','shovel-fields','alive-fields','reset-fields']):
 burst,point=[struct.unpack('>f',bytes.fromhex(s))[0] for s in pair];blocked=element and burst>0 and point>0;safe=plant!=1 or prop!=0 or blocked or mode in ['pick-fields','element-fields'];add(0x1da,plant=plant,prop=prop,burst=pair[0],point=pair[1],element=element,mode=mode,native_supported=bool(safe))
add(0x1da,plant=1,prop=1,burst='00000000',point='00000000',element_manager=0,native_supported=False)
for chooser,almanac,active,chosen,ident,mode in itertools.product([0,1,2],[0,1,2],[0,1],[0,1],[-1,0,49,2147483647],['none','gameobject-fields','active-fields','audio-fields','alive-chooser','alive-almanac']):add(0x2f3,chooser=chooser,almanac=almanac,active=active,chosen=chosen,id=ident,mode=mode)
(Q/'SELECTION-CASES.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(records=len(rows),native=sum(q['native_supported'] for q in rows),per_method=dict(collections.Counter(q['token'] for q in rows)))))
