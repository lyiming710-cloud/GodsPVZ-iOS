"""Original shovel/card callers under explicit Unity pseudo-null contracts."""
from pathlib import Path
import collections,ctypes as C,functools,hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
im=NativeImage();state={};ids=[0x1da,0x2f3];cfgs={rid:json.loads((Q/'native-source-complete'/f'0x{0x6000000|rid:08X}.json').read_bytes()) for rid in ids};fields=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_bytes())
@functools.lru_cache(None)
def off(owner,name):
 rs=[r for r in fields if r['type']==owner and r['namespace']=='' and r['name']==name];assert len(rs)==1,(owner,name,rs);return rs[0]['offset']
def at(owner,name):return state['mouse' if owner=='MouseManager' else 'card']+off(owner,name)
def mode():return state['q']['mode']
def tag(p):return 'null' if not p else state['tags'][p]
def make(label,live=True):
 p=im.alloc(1024);state['tags'][p]=label;state['live'][p]=bool(live);return p
def f(k):return struct.unpack('>f',bytes.fromhex(state['q'][k]))[0]
def getplant(p,method):
 assert p==state['mouse'] and not method;state['trace'].append('Pick:'+tag(state['plant_arg']))
 if mode()=='pick-fields':put64(at('MouseManager','propOnHand'),state['other-prop'])
 return state['plant_arg']
def equal(p,b,method):
 assert not b and not method;v=not p or not state['live'][p];state['trace'].append('Equal:'+tag(p)+':'+str(int(v)));return v
def alive(p,method):
 assert not method;v=bool(p and state['live'][p]);state['trace'].append('Alive:'+tag(p)+':'+str(int(v)));state['alive_calls']+=1
 if mode()=='alive-fields' and tag(p) in ['prop','other-prop']:put64(at('MouseManager','propOnHand'),state['other-prop'])
 if mode()=='alive-chooser' and state['alive_calls']==1:put64(at('Card_Choose','seedChooserScreen'),state['other-chooser'])
 if mode()=='alive-almanac' and state['alive_calls']==2:put64(at('Card_Choose','almanacUIController'),state['other-almanac'])
 return v
def inequality(p,b,method):assert not b;return alive(p,method)
def element(p,kind,method):
 assert p==state['element-manager'] and kind==0 and not method;state['trace'].append('Element:0')
 if mode()=='element-fields':put64(at('MouseManager','propOnHand'),state['other-prop'])
 return state['element'] if state['q'].get('element',1) else 0
def shovel(p,level,special,method):
 assert p==state['plant'] and not method;state['trace'].append(f'Shovel:{level}:{special}')
 if mode()=='shovel-fields':put64(at('MouseManager','propOnHand'),state['other-prop'])
def drop(p,method):assert not method and tag(p) in ['prop','other-prop'];state['trace'].append('Drop:'+tag(p))
def reset(p,method):
 assert not method and p==state['mouse'];state['trace'].append('Reset')
 if mode()=='reset-fields':put64(at('MouseManager','propOnHand'),0)
def audio(p,index,method):
 assert not method and tag(p) in ['mouse','mouse-a','mouse-b'];state['trace'].append('Audio:'+tag(p)+':'+str(index))
 if mode()=='audio-fields':put64(at('Card_Choose','seedChooserScreen'),state['other-chooser']);C.c_ubyte.from_address(at('Card_Choose','isChosen')).value=not C.c_ubyte.from_address(at('Card_Choose','isChosen')).value;put32(at('Card_Choose','plantID'),779)
def gameobject(p,method):
 assert not method and tag(p) in ['chooser','other-chooser'];state['trace'].append('GameObject:'+tag(p))
 if mode()=='gameobject-fields':put64(at('Card_Choose','seedChooserScreen'),state['other-chooser']);put32(at('Card_Choose','plantID'),777)
 return state['object' if tag(p)=='chooser' else 'other-object']
def active(p,method):
 assert not method and tag(p) in ['object','other-object'];v=bool(state['q'].get('active',0));state['trace'].append('Active:'+tag(p)+':'+str(int(v)))
 if mode()=='active-fields':put64(at('Card_Choose','seedChooserScreen'),state['other-chooser']);C.c_ubyte.from_address(at('Card_Choose','isChosen')).value=not C.c_ubyte.from_address(at('Card_Choose','isChosen')).value;put32(at('Card_Choose','plantID'),778)
 return v
def seed(p,index,method):assert not method and tag(p) in ['prepare-a','prepare-b'];state['trace'].append('Seed:'+tag(p)+':'+str(index))
def openplant(p,index,method):assert not method and tag(p) in ['almanac','other-almanac'];state['trace'].append('Open:'+tag(p)+':'+str(index))
def choose(p,method,chosen):assert not method and p==state['card'];state['trace'].append('ChooseBeing' if chosen else 'ChooseReset');C.c_ubyte.from_address(at('Card_Choose','isChosen')).value=chosen
def snapshot(rid):
 if rid==0x1da:return dict(prop=tag(get64(at('MouseManager','propOnHand'))))
 return dict(chooser=tag(get64(at('Card_Choose','seedChooserScreen'))),almanac=tag(get64(at('Card_Choose','almanacUIController'))),id=get32(at('Card_Choose','plantID')),chosen=bool(C.c_ubyte.from_address(at('Card_Choose','isChosen')).value))
try:
 dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True;slots=set()
 for cfg in cfgs.values():
  for row in cfg['instructions']:
   i=next(dis.disasm(bytes.fromhex(row['bytes']),int(row['va'],16)))
   if i.mnemonic not in ['mov','lea']:continue
   for o in i.operands:
    if o.type!=X86_OP_MEM or o.mem.base!=X86_REG_RIP:continue
    a=i.address+i.size+o.mem.disp;raw=im.pe.get_data(a-im.base,8)
    if len(raw)!=8:continue
    code=int.from_bytes(raw,'little')
    if code>0xffffffff or code>>29 not in range(1,8) or a in slots:continue
    assert code>>29==1,'Only class slots belong to these callers';slots.add(a);im.class_slot(a)
 def init(a):assert a in slots,hex(a)
 im.hook(0x18024fef0,None,[P],init);im.hook(0x1802501e0,None,[P],lambda p:None);im.hook(0x18031ea60,P,[P,P],getplant);im.hook(0x18131f760,C.c_bool,[P,P,P],equal);im.hook(0x18131f870,C.c_bool,[P,P],alive);im.hook(0x18131f900,C.c_bool,[P,P,P],inequality);im.hook(0x180315250,P,[P,I,P],element);im.hook(0x180355f50,None,[P,I,I,P],shovel);im.hook(0x18037e320,None,[P,P],drop);im.hook(0x180320fe0,None,[P,P],reset);im.hook(0x18031d390,None,[P,I,P],audio);im.hook(0x1813044d0,P,[P,P],gameobject);im.hook(0x18131bf10,C.c_bool,[P,P],active);im.hook(0x1803a74e0,None,[P,I,P],seed);im.hook(0x180388b00,None,[P,I,P],openplant);im.hook(0x180343640,None,[P,P],lambda p,m:choose(p,m,True));im.hook(0x1803438a0,None,[P,P],lambda p,m:choose(p,m,False))
 for rid,cfg in cfgs.items():im.verify_caller(rid,int(cfg['entry'],16),cfg)
 rows=[];cases=json.loads((Q/'SELECTION-CASES.json').read_bytes())
 for q in cases:
  if not q['native_supported']:continue
  state.clear();state.update(q=q,tags={},live={},trace=[],alive_calls=0)
  for label in ['mouse','plant','prop','other-prop','element','element-manager','card','chooser','other-chooser','almanac','other-almanac','object','other-object','mouse-a','mouse-b','prepare-a','prepare-b']:state[label]=make(label)
  state['live'][state['plant']]=q.get('plant',1)==1;state['live'][state['prop']]=q.get('prop',1)==1;state['live'][state['chooser']]=q.get('chooser',1)==1;state['live'][state['almanac']]=q.get('almanac',1)==1;state['plant_arg']=state['plant'] if q.get('plant',1) else 0;put64(at('MouseManager','propOnHand'),state['prop'] if q.get('prop',1) else 0);put64(state['plant']+off('Plant','elementManager'),state['element-manager']);putf(state['element']+off('Element','burstTime'),f('burst') if 'burst' in q else 0);putf(state['element']+off('Element','point'),f('point') if 'point' in q else 0)
  for prop,level,special in [('prop',3,7),('other-prop',-5,99)]:put32(state[prop]+off('Prop','level'),level);put32(state[prop]+off('Prop','specialType'),special)
  put64(at('Card_Choose','seedChooserScreen'),state['chooser'] if q.get('chooser',1) else 0);put64(at('Card_Choose','almanacUIController'),state['almanac'] if q.get('almanac',1) else 0);put32(at('Card_Choose','plantID'),q.get('id',0));C.c_ubyte.from_address(at('Card_Choose','isChosen')).value=q.get('chosen',0)
  for chooser,mouse,prepare in [('chooser','mouse-a','prepare-a'),('other-chooser','mouse-b','prepare-b')]:put64(state[chooser]+off('SeedChooserScreen','mouseManager'),state[mouse]);put64(state[chooser]+off('SeedChooserScreen','prepareUIController'),state[prepare])
  rid=int(q['token'],16)&0xffffff;C.CFUNCTYPE(None,P,P)(int(cfgs[rid]['entry'],16))(state['mouse' if rid==0x1da else 'card'],None);assert not im.errors,(q,im.errors);rows.append(dict(name=q['name'],token=q['token'],error=None,trace=list(state['trace']),state=snapshot(rid)))
 actual=json.loads(Path(sys.argv[1]).read_bytes());assert actual['candidate_sha256']==hashlib.sha256((Q/'candidate9.dll').read_bytes()).hexdigest();byname={r['name']:r for r in actual['results']};assert len(byname)==len(cases) and set(byname)=={q['name'] for q in cases};diff=[dict(original=r,actual=byname[r['name']]) for r in rows if r!=byname[r['name']]]
 report=dict(scope='TWO_ORIGINAL_SHOVEL_CARD_SELECTION_CALLERS_VS_COMPLETE_CANDIDATE_CIL',candidate_sha256=actual['candidate_sha256'],original_pc_sha256=hashlib.sha256(im.raw).hexdigest(),caller_bytes_verified=2,normal_records=len(rows),per_method=dict(collections.Counter(r['token'] for r in rows)),results=rows,differences=diff,callback_errors=im.errors,managed_only_exception_records=[r for r in actual['results'] if not next(q for q in cases if q['name']==r['name'])['native_supported']],controlled_leaves=['Unity Object null/pseudo-null predicates','GetPlant/GetElement/Shovel/DropDown/Reset/Audio','Component.gameObject/GameObject.activeSelf','SeedChoose/OpenPlant/Choose_Reset/Choose_Being'],limitations=['No actual Unity Object destruction semantics or engine lifecycle proof','Native inequality-null and CIL implicit leaves share only the explicit live/null contract tested here','No callee internals, native exception/SEH, actual shovel effects or UI rendering proof'],formal_or_product_acceptance=False);Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k not in ['results','differences','managed_only_exception_records']}));print('differences',len(diff));assert not diff
finally:im.close()
