"""Compare preserved R18 and exact current returned game registration coverage."""
from pathlib import Path
import hashlib,json,re,sys,tarfile
W=Path(__file__).resolve().parent;Q=W/'startup-r19-batch100';D=W.parents[1]/'audit/repo-native113/Recovery/Startup-R19-Batch100-2026-10-25';run=int(sys.argv[1]);archive=Path(sys.argv[2]).resolve();stem=sys.argv[3] if len(sys.argv)>3 else 'candidate9'
def read(file):
 files={}
 with tarfile.open(file,'r|gz') as z:
  for m in z:
   if m.isfile() and m.name.startswith('il2cppOutput/cpp/GodsPVZRuntime1'):files[Path(m.name).name]=z.extractfile(m).read().decode('utf-8-sig')
 reg=files['GodsPVZRuntime1_CodeGen.c'];m=re.search(r's_methodPointers\[(\d+)\]\s*=\s*\{(.*?)\};',reg,re.S);assert m
 entries=[s.strip().rstrip(',') for s in m[2].splitlines() if s.strip()];assert len(entries)==int(m[1])==2317
 defs={};pat=re.compile(r'^IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR[^\n]*?\b([A-Za-z0-9_]+_m[0-9A-Fa-f]{40}(?:_gshared)?)\s*\([^\n]*\)\s*\n\{',re.M)
 for name,text in files.items():
  if name.endswith('.cpp'):
   for d in pat.finditer(text):assert d[1] not in defs;defs[d[1]]=name
 return entries,defs
old,od=read(W/'r18-compiler-run-40172961231/startup-r18-generated.tar.gz');new,nd=read(archive);assert old==new and set(od)==set(nd)
construction=json.loads((Q/(stem+'.json')).read_bytes());targets=[];generic=[]
for r in construction['changes']:
 symbol=new[(int(r['token'],16)&0xffffff)-1]
 if symbol=='NULL':assert r['group']=='generic-source';generic.append(dict(token=r['token'],scope='NO_ORDINARY_POINTER_OPEN_GENERIC_INSTANTIATION_CHECKS_SEPARATE'));continue
 assert symbol in nd;targets.append(dict(token=r['token'],symbol=symbol,cpp_file=nd[symbol]))
assert len(targets)==95 and len(generic)==5
actual=json.loads((D/f'ACTUAL-COMPILER-{run}.json').read_bytes());assert actual['candidate_sha256']==construction['candidate_sha256'] and actual['raw_generated_sources_rehashed']==1029
out=dict(scope='EXACT_R19_GAME_POINTER_AND_GENERATED_ORDINARY_DEFINITION_COVERAGE_NOT_SEMANTIC_ACCEPTANCE',run_id=run,candidate_sha256=construction['candidate_sha256'],registered_method_rows=2317,all_pointer_entries_identical_to_r18=True,ordinary_game_definition_sets_identical_to_r18=True,ordinary_generated_game_definitions=len(nd),ninety_five_nongeneric_targets_registered_and_defined=True,targets=targets,five_generic_targets_separate=generic,all_source_hashes_rechecked=1029,game_semantics_or_ipa=False)
(D/f'GENERATED-COVERAGE-{run}.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k not in ['targets','five_generic_targets_separate']},indent=2))
