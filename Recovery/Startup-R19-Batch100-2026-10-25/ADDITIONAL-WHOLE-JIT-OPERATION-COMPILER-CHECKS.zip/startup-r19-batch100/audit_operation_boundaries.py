"""Independent old/new instruction and raw-byte boundary audit for 22 callers.

Checks complete branch/switch/EH entry boundaries, including conditional edges.
This verifies changed operations/unchanged remainder; no whole-caller runtime
or universal equivalence is inferred from a correct public getter/width alone.
"""
from pathlib import Path
import collections,hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];stem=sys.argv[1] if len(sys.argv)>1 else 'candidate9';P=Q/('shared-'+stem);sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
old=(W/'startup-r18-batch50/candidate1.dll').read_bytes();new=(Q/(stem+'.dll')).read_bytes();op,cp=dnfile.dnPE(data=old),dnfile.dnPE(data=new);a={m['token']:m for m in json.loads((W/'startup-r18-batch50/ALL-CIL.json').read_bytes())['methods']};b={m['token']:m for m in json.loads((P/'ALL-CIL.json').read_bytes())['methods']};construction=json.loads((Q/(stem+'.json')).read_bytes())

def code(raw,pe,rid):
 at=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[rid-1].Rva);h=1 if raw[at]&3==2 else (struct.unpack_from('<H',raw,at)[0]>>12)*4;n=raw[at]>>2 if h==1 else struct.unpack_from('<I',raw,at+4)[0];return raw[at+h:at+h+n]

def field_name(i):return i['operand']['identity'].rsplit('::',1)[-1]
def local_index(i):
 if i['opcode'] in ['ldloc','ldloc.s']:return i['operand']['index']
 if i['opcode'] in ['ldloc.0','ldloc.1','ldloc.2','ldloc.3']:return int(i['opcode'][-1])
 raise AssertionError(i)
def edges(i):
 o=i.get('operand');return [o['target']] if isinstance(o,dict) and 'target' in o else o.get('targets',[]) if isinstance(o,dict) else []

rows=[]
for r in construction['changes']:
 group=r['group'];token=r['token'];rid=int(token,16)&0xffffff
 if group not in ['native-numeric-and-legal-access','native-int32-width','float32-operands'] or rid==0x3a8:continue
 before,after=code(old,op,rid),code(new,cp,rid);assert len(before)==len(after);oi,ni=a[token]['instructions'],b[token]['instructions'];bynew={i['offset']:i for i in ni};allowed=set();sites=[];ranges=[]
 for k,i in enumerate(oi):
  if i['opcode']!='ldfld' or field_name(i)!='_version':continue
  first=oi[k-1];assert first['opcode']=='ldloc';start=first['offset'];receiver=first['operand']['index'];clear=next(j for j in range(k,len(oi)) if oi[j]['opcode']=='call' and oi[j]['operand']['owner']=='System.Array' and oi[j]['operand']['name']=='Clear');ending=next(j for j in range(clear+1,len(oi)) if oi[j]['opcode']=='br');end=oi[ending]['offset']+5;exit_=oi[ending]['operand']['target']
  n0=bynew[start];assert local_index(n0)==receiver,(token,first,n0)
  call=next(x for x in ni if x['offset']>start);assert call['opcode']=='callvirt' and call['operand']['name']=='Clear' and call['operand']['owner']==i['operand']['owner'] and call['operand']['args']==[] and call['operand']['ret']=='System.Void'
  jump=next(x for x in ni if x['offset']>call['offset']);assert jump['opcode']=='br' and jump['operand']['target']==exit_
  assert all(x['opcode']=='nop' for x in ni if jump['offset']+5<=x['offset']<end)
  for external in oi:
   if start<=external['offset']<end:continue
   assert all(not start<t<end for t in edges(external)),(token,external,start,end)
  # Exported exception metadata must remain identical; never prune a clause.
  for key in ['exception_handlers','exceptionHandlers','handlers']:
   if key in a[token] or key in b[token]:
    assert a[token].get(key)==b[token].get(key)
    for clause in a[token].get(key,[]):
     for boundary in ['tryStart','tryEnd','handlerStart','handlerEnd','filterStart']:
      value=clause.get(boundary)
      if isinstance(value,int):assert not start<value<end,(token,'EH boundary enters removed inline Clear',clause)
  allowed.update(range(start,end));ranges.append((start,end));sites.append(dict(kind='PUBLIC_CLEAR_WITH_CAPTURED_RECEIVER_AND_EXACT_EXIT',offset=start,end=end,owner=i['operand']['owner'],receiver_local=receiver,exit=exit_))
 for i in oi:
  at=i['offset']
  if any(start<=at<end for start,end in ranges):continue
  j=bynew.get(at)
  if before[at:at+1]==after[at:at+1] and (i['opcode'] not in ['ldfld','ldflda','ldsfld','call','callvirt'] or before[at:at+5]==after[at:at+5]):continue
  assert j is not None,(token,i)
  kind=None;width=5
  if i['opcode']=='ldc.i8':
   assert before[at:at+9]==bytes.fromhex('21ffffffff00000000') and after[at:at+9]==bytes.fromhex('20ffffffff00000000');kind='INT32_MINUS_ONE_REPLACES_POSITIVE_INT64';width=9
  elif i['opcode']=='ldc.i4':assert before[at:at+5]==bytes.fromhex('2000000000') and after[at:at+5]==bytes.fromhex('2200000000');kind='FLOAT32_ZERO_REPLACES_INT32_ZERO'
  elif i['opcode'] in ['ldfld','ldflda'] and i['operand']['owner']=='Zombie':assert field_name(i)=='previousPosition' and j['opcode']=='callvirt' and j['operand']['owner']=='Zombie' and j['operand']['name']=='PreviousPosition' and j['operand']['ret']=='UnityEngine.Vector3';kind='PUBLIC_ZOMBIE_PREVIOUS_POSITION'
  elif i['opcode']=='ldsfld':assert i['operand']['owner']=='UnityEngine.Quaternion' and field_name(i)=='identityQuaternion' and j['opcode']=='call' and j['operand']['name']=='get_identity';kind='PUBLIC_QUATERNION_IDENTITY'
  elif i['opcode']=='ldfld':assert i['operand']['owner']=='UnityEngine.UI.Image' and field_name(i)=='m_FillAmount' and j['opcode']=='callvirt' and j['operand']['name']=='get_fillAmount';kind='PUBLIC_IMAGE_FILL_AMOUNT'
  elif i['opcode'] in ['call','callvirt']:assert i['operand']['owner']=='UnityEngine.Transform' and i['operand']['name']=='set_parentInternal' and j['operand']['name']=='set_parent' and i['operand']['args']==j['operand']['args'];kind='PUBLIC_TRANSFORM_PARENT'
  assert kind,(token,i,j);allowed.update(range(at,at+width));sites.append(dict(kind=kind,offset=at,old_opcode=i['opcode'],new_opcode=j['opcode']))
 assert all(x==y or k in allowed for k,(x,y) in enumerate(zip(before,after))),(token,'Unclassified change')
 assert sites;rows.append(dict(token=token,name=r['name'],code_bytes=len(after),classified_operation_sites=sites,all_other_code_bytes_identical=True,all_external_branch_switch_entries_checked=True,full_caller_runtime_acceptance=False))
assert len(rows)==22
result=dict(scope='TWENTY_TWO_CALLER_EXACT_OPERATION_AND_BRANCH_BOUNDARY_AUDIT_NOT_FULL_BODY_BEHAVIOR',candidate_sha256=hashlib.sha256(new).hexdigest(),methods=len(rows),operation_kinds=dict(collections.Counter(s['kind'] for r in rows for s in r['classified_operation_sites'])),rows=rows,member_legality_evidence='Separate exact actual all-assembly member audit; this audit does not bypass visibility',native_semantics_or_product_acceptance=False)
(P/'OPERATION-BOUNDARIES.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))
