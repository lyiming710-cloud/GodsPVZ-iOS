"""Execute all original PC callers, both jump tables and real rounding/CRT code.

No host replacement of Round/modf/ceil/floor/max. Unity time/truth/Animator,
string equality and Buff.GetIncrement remain explicitly controlled callees.
No native null throw, SEH, real engine state or CRT errno claim is made.
"""
from pathlib import Path
import ctypes as C,hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
im=NativeImage();state={};cases=json.loads(Path(sys.argv[1]).read_bytes());rows=[];dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True
def value(bits_):return struct.unpack('<f',bytes.fromhex(bits_)[::-1])[0]
def string(s):
    if s is None:return 0
    b=s.encode('utf-16-le');p=im.alloc(24+len(b)+2);put32(p+0x10,len(b)//2);C.memmove(p+0x14,b,len(b));return p
def read(p):return C.string_at(p+0x14,get32(p+0x10)*2).decode('utf-16-le') if p else None
def text(s):return '<null>' if s is None else s
def actor(id_):p=im.alloc(64);state['actors'][p]=id_;return p
def asset(id_,live,rate):
    p=im.alloc(64);state['assets'][p]=dict(id=id_,live=bool(live));putf(p+0x28,rate);return p
try:
    cfgs={}
    for rid in [0xf8,0x18e,0x44e,0x602,0x607,0x835,0x863,0x887]:
        cfg=json.loads((Q/f'{rid:04X}.expanded-native.json' if rid in [0x18e,0x607] else Q/f'{rid:04X}.native.json').read_bytes())
        if rid==0x602:
            cfg=dict(cfg,instructions=[i for i in cfg['instructions'] if 0x18039bdd0<=int(i['va'],16)<0x18039beab],indirect_jumps=[],scope='EXACT_DAMAGE_CALLER_NORMAL_CFG_TAIL_TO_CONTROLLED_ANIMATOR_EXCLUDED')
            (Q/'0602.caller-only-native.json').write_bytes((json.dumps(cfg,indent=2)+'\n').encode())
        cfgs[rid]=cfg;im.verify_caller(rid,int(cfg['entry'],16),cfg)
    helpers=[json.loads((Q/f'{name}-HELPER-CFG.json').read_bytes()) for name in ['ROUND','MODF','CEILF']]
    for cfg in helpers:
        for i in cfg['instructions']:assert C.string_at(int(i['va'],16),len(bytes.fromhex(i['bytes'])))==bytes.fromhex(i['bytes'])
    metadata=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/global-metadata.dat').read_bytes();assert hashlib.sha256(metadata).hexdigest()=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9';literals,literal_size,literal_data=struct.unpack_from('<III',metadata,8)
    globals_={};constant_data={}
    for cfg in list(cfgs.values())+helpers:
        for row in cfg['instructions']:
            ins=next(dis.disasm(bytes.fromhex(row['bytes']),int(row['va'],16)))
            for operand in ins.operands:
                if operand.type!=X86_OP_MEM or operand.mem.base!=X86_REG_RIP:continue
                at=ins.address+ins.size+operand.mem.disp
                if ins.mnemonic in ('lea','mov'):
                    encoded=int.from_bytes(im.pe.get_data(at-im.base,8),'little');kind=encoded>>29
                    if encoded>0xffffffff or kind not in range(1,8):continue
                    entry=dict(slot=hex(at),encoded=hex(encoded),kind=kind,index=(encoded&0x1fffffff)>>1)
                    if kind==5:
                        assert entry['index']*8<literal_size;n,start=struct.unpack_from('<II',metadata,literals+entry['index']*8);entry['string']=metadata[literal_data+start:literal_data+start+n].decode()
                    globals_[at]=entry
                elif ins.mnemonic in ('movss','movsd','comiss','ucomiss','comisd','ucomisd','addss','subss','mulss','divss'):
                    n=operand.size;assert n in (4,8);b=im.pe.get_data(at-im.base,n);constant_data[(at,n)]=b
    def init(at):
        assert at in globals_,hex(at);r=globals_[at]
        if r['kind']==5:
            if at not in im.classes:im.classes[at]=string(r['string'])
            put64(at,im.classes[at])
        else:im.class_slot(at)
    for at,r in globals_.items():assert get64(at)==int(r['encoded'],16);init(at)
    damage_ins=next(r for r in cfgs[0x602]['instructions'] if r['va']=='0x18039bde7');i=next(dis.disasm(bytes.fromhex(damage_ins['bytes']),int(damage_ins['va'],16)));damage_slot=i.address+i.size+i.operands[1].mem.disp;assert damage_slot in globals_;damage_static=get64(im.classes[damage_slot]+0xb8)
    def equal(left,right,method):
        assert not method;a,b=read(left),read(right);answer=a==b;state['trace'].append('Equal:'+text(a)+':'+text(b)+':'+str(int(answer)));mode=state['case']['mode'];owner=state['owner']
        if mode=='equality-mutates-value':putf(owner+0x60,17)
        if mode=='equality-mutates-multi':C.c_ubyte.from_address(owner+0x64).value^=1
        if mode=='equality-replaces-name':put64(owner+0x58,string('changed'))
        return answer
    def truth(p,method):
        assert not method;info=state['assets'].get(p);answer=bool(info and info['live']);state['trace'].append('Truth:'+(info['id'] if info else 'null')+':'+str(int(answer)));mode=state['case']['mode']
        if mode=='replace-clip-on-truth':put64(state['owner']+0x88,asset('clip-new',True,77))
        if mode=='replace-destroyed-clip-on-truth':put64(state['owner']+0x88,asset('clip-new',False,77))
        if mode=='mutate-rate-on-truth' and p:putf(p+0x28,-19)
        return answer
    def time(method):
        assert not method;state['times']+=1;n=state['times'];c=state['case'];v=value(c['time1'] if n==1 else c['time2']);state['trace'].append(f'Time:{n}:'+bits(v))
        if (n==1 and c['mode']=='time1-replaces-animator') or (n==2 and c['mode']=='time2-replaces-animator'):put64(state['owner']+0x28,actor('animator-new'))
        if n==2 and c['mode']=='time2-mutates-hash':put32(damage_static,C.c_int32(get32(damage_static)+99).value)
        return v
    def set_float(p,id_,v,method):assert not method;state['trace'].append(f"SetFloat:{state['actors'][p]}:{id_}:"+bits(v))
    def increment(p,base,name,method):
        assert not method and read(name)=='Tou';state['trace'].append('Increment:'+state['buffs'][p]+':'+bits(base)+':'+read(name));mode=state['case']['mode']
        if mode=='buff-mutates-armor':putf(state['owner']+0x90,17);putf(state['owner']+0xa8,-19)
        if mode=='buff-replaces-manager':
            new=im.alloc(64);state['buffs'][new]='buff-new';put64(state['owner']+0x228,new)
        return value(state['case']['increment'])
    def reject(*unused):raise AssertionError('Native throw outside this normal-object oracle')
    im.hook(0x18024fef0,None,[P],init);im.hook(0x1802501e0,None,[P],lambda _:None)
    im.hook(0x180b76170,C.c_bool,[P,P,P],equal);im.hook(0x18131f870,C.c_bool,[P,P],truth);im.hook(0x18132c440,F,[P],time);im.hook(0x1812dba60,None,[P,I,F,P],set_float);im.hook(0x180310420,F,[P,F,P,P],increment);im.hook(0x180250150,None,[P],reject)
    # Original caller, table, literals and every rounding/math helper byte must
    # still match the authoritative PC image after controlled hook installation.
    for rid,cfg in cfgs.items():im.verify_caller(rid,int(cfg['entry'],16),cfg)
    for cfg in helpers:
        for i in cfg['instructions']:assert C.string_at(int(i['va'],16),len(bytes.fromhex(i['bytes'])))==bytes.fromhex(i['bytes'])
    for (at,n),b in constant_data.items():assert C.string_at(at,n)==b
    for rid in [0x18e,0x607]:
        cfg=cfgs[rid];b=bytes.fromhex(cfg['table_bytes']);assert C.string_at(im.base+int(cfg['table_rva'],16),len(b))==b
        if cfg['selector_bytes']:
            b=bytes.fromhex(cfg['selector_bytes']);assert C.string_at(im.base+int(cfg['selector_rva'],16),len(b))==b
    stats=C.CFUNCTYPE(F,P,F,P,P)(0x180325030);device=C.CFUNCTYPE(F,I,P)(0x180312b80);tou=C.CFUNCTYPE(F,P,I,P)(0x180361950);damage=C.CFUNCTYPE(None,P,P)(0x18039bdd0);board=C.CFUNCTYPE(F,P,P)(0x180395070);clip=C.CFUNCTYPE(F,P,P)(0x1803c89c0);rates={'rate-controller':(C.CFUNCTYPE(None,P,F,P)(0x1803c72c0),0x4c),'rate-manager':(C.CFUNCTYPE(None,P,F,P)(0x1803ca220),0x3c)}
    for c in cases:
        state.clear();state.update(case=c,trace=[],times=0,actors={},assets={},buffs={});owner=im.alloc(1024);state['owner']=owner;result=None;after=None;k=c['kind']
        if k=='device':result=bits(device(c['id'],None))
        elif k=='board':put32(owner+0x10,c['id']);put32(owner+0x14,c['level']);result=bits(board(owner,None))
        elif k in rates:
            f,offset=rates[k];putf(owner+offset,123);f(owner,value(c['value']),None);after=dict(rate=bits(getf(owner+offset)))
        elif k=='stats':
            put64(owner+0x58,string(c['value_name']));putf(owner+0x60,value(c['value']));C.c_ubyte.from_address(owner+0x64).value=c['multi'];result=bits(stats(owner,value(c['other']),string(c['input_name']),None));after=dict(value=bits(getf(owner+0x60)),multi=bool(C.c_ubyte.from_address(owner+0x64).value),value_name=read(get64(owner+0x58)))
        elif k=='clip':
            put64(owner+0x88,0 if c['clip_kind']==0 else asset('clip',c['clip_kind']==1,value(c['value'])));result=bits(clip(owner,None));p=get64(owner+0x88);info=state['assets'].get(p);after=dict(clip_id=info['id'] if info else None,clip_live=info['live'] if info else None,rate=bits(getf(p+0x28)) if p else None)
        elif k=='damage':
            put64(owner+0x28,actor('animator'));put32(damage_static,c['hash']);damage(owner,None);after=dict(animator_id=state['actors'][get64(owner+0x28)],hash=get32(damage_static))
        elif k=='tou':
            putf(owner+0x90,value(c['value']));putf(owner+0xa8,value(c['other']));p=im.alloc(64);state['buffs'][p]='buff';put64(owner+0x228,p);result=bits(tou(owner,c['id'],None));after=dict(armor1=bits(getf(owner+0x90)),armor2=bits(getf(owner+0xa8)),buff_id=state['buffs'][get64(owner+0x228)])
        else:raise AssertionError(k)
        assert not im.errors,im.errors;rows.append(dict(name=c['name'],kind=k,result=result,trace=list(state['trace']),state=after,error=None))
    report=dict(scope='EIGHT_ORIGINAL_PC_CALLERS_AND_REAL_JUMP_TABLE_ROUND_MODF_CEIL_FLOOR_MAX_CODE_CONTROLLED_ENGINE_AND_BUFF_STRING_CALLEES',original_sha256=PC_SHA,original_caller_and_helpers_preserved=True,caller_instruction_counts={f'0x{0x6000000|rid:08X}':len(c['instructions']) for rid,c in cfgs.items()},helper_counts={name:len(c['instructions']) for name,c in zip(['ROUND','MODF','CEILF'],helpers)},global_bindings=list(globals_.values()),literal_data=[dict(va=hex(at),bytes=b.hex()) for (at,n),b in sorted(constant_data.items())],round_crt_callees_replaced=False,callback_errors=im.errors,native_exception_unwind=False,unity_execution=False,nan_payload_equivalence=False,results=rows)
    Path(sys.argv[2]).write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(dict(cases=len(rows),callback_errors=im.errors)))
finally:im.close()
