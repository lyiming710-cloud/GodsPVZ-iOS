using System.Reflection;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public sealed class StatsState{public string? valueName;public float value;public bool multi;}
public sealed class DeviceState{}
public sealed class BoardState{public int boardEntryType,level;}
public sealed class RateState{public float _rateScale;}
public class ObjectState(string id,bool live){public string Id=id;public bool Live=live;}
public sealed class AssetState(string id,bool live,float rate):ObjectState(id,live){public float FrameRate=rate;}
public sealed class ClipState{public AssetState? _clip;}
public sealed class DamageState{public AnimatorState? animator;public static int Ani_SpeedHash;}
public sealed class AnimatorState(string id){public string Id=id;public void SetFloat(int id,float value)=>Program.Trace.Add("SetFloat:"+Id+":"+id+":"+Program.Bits(value));}
public sealed class ZombieState{public float armor1Toughness,armor2Toughness;public BuffState? buffManager;}
public sealed class BuffState(string id)
{
    public string Id=id;
    public float GetIncrement(float value,string name)
    {
        Program.Trace.Add("Increment:"+Id+":"+Program.Bits(value)+":"+name);
        if(Program.Current.mode=="buff-mutates-armor"){Program.Zombie.armor1Toughness=17;Program.Zombie.armor2Toughness=-19;}
        if(Program.Current.mode=="buff-replaces-manager")Program.Zombie.buffManager=new("buff-new");
        return Program.Value(Program.Current.increment);
    }
}
public sealed class Case
{
    public string name{get;set;}="";public string kind{get;set;}="";public string mode{get;set;}="none";
    public int id{get;set;}=0;public int level{get;set;}=1;public int clip_kind{get;set;}=1;public int hash{get;set;}=42;
    public string value{get;set;}="3F800000";public string other{get;set;}="40000000";public string increment{get;set;}="00000000";
    public string time1{get;set;}="3F800000";public string time2{get;set;}="3F800000";
    public string? value_name{get;set;}="A";public string? input_name{get;set;}="A";public bool multi{get;set;}=false;
}
public static class Program
{
    public static Case Current=new();public static List<string> Trace=[];public static StatsState Stats=new();public static ClipState Clip=new();public static ZombieState Zombie=new();public static DamageState Damage=new();public static int Times;
    public static float Value(string s)=>BitConverter.Int32BitsToSingle(unchecked((int)Convert.ToUInt32(s,16)));
    public static string Bits(float f)=>float.IsNaN(f)?"NaN":BitConverter.SingleToInt32Bits(f).ToString("X8");
    static string Text(string? s)=>s??"<null>";
    public static bool StringEqual(string? a,string? b)
    {
        bool equal=string.Equals(a,b,StringComparison.Ordinal);Trace.Add("Equal:"+Text(a)+":"+Text(b)+":"+(equal?"1":"0"));
        if(Current.mode=="equality-mutates-value")Stats.value=17;
        if(Current.mode=="equality-mutates-multi")Stats.multi=!Stats.multi;
        if(Current.mode=="equality-replaces-name")Stats.valueName="changed";
        return equal;
    }
    public static bool Truth(ObjectState? obj)
    {
        bool answer=obj?.Live??false;Trace.Add("Truth:"+(obj?.Id??"null")+":"+(answer?"1":"0"));
        if(Current.mode=="replace-clip-on-truth")Clip._clip=new("clip-new",true,77);
        if(Current.mode=="replace-destroyed-clip-on-truth")Clip._clip=new("clip-new",false,77);
        if(Current.mode=="mutate-rate-on-truth"&&obj is AssetState asset)asset.FrameRate=-19;
        if(Current.mode=="clear-clip-on-truth")Clip._clip=null;
        return answer;
    }
    public static float TimeScale()
    {
        Times++;float value=Value(Times==1?Current.time1:Current.time2);Trace.Add("Time:"+Times+":"+Bits(value));
        if((Times==1&&Current.mode=="time1-replaces-animator")||(Times==2&&Current.mode=="time2-replaces-animator"))Damage.animator=new("animator-new");
        if(Times==2&&Current.mode=="time2-mutates-hash")DamageState.Ani_SpeedHash=unchecked(DamageState.Ani_SpeedHash+99);
        return value;
    }
    static Type Map(MC.TypeReference t)=>t.FullName switch
    {
        "System.Void"=>typeof(void),"System.Boolean"=>typeof(bool),"System.Int32" or "BoardEntryType"=>typeof(int),"System.Int64"=>typeof(long),"System.Single"=>typeof(float),"System.Double"=>typeof(double),"System.String"=>typeof(string),"System.Object"=>typeof(object),"System.IntPtr"=>typeof(IntPtr),
        "StatsIncreased"=>typeof(StatsState),"DeviceManager"=>typeof(DeviceState),"BoardEntry"=>typeof(BoardState),"FTRuntime.SwfClipController" or "FTRuntime.SwfManager"=>typeof(RateState),"FTRuntime.SwfClip"=>typeof(ClipState),"FTRuntime.SwfClipAsset"=>typeof(AssetState),"UnityEngine.Object"=>typeof(ObjectState),"DamageText"=>typeof(DamageState),"UnityEngine.Animator"=>typeof(AnimatorState),"Zombie"=>typeof(ZombieState),"BuffManager"=>typeof(BuffState),_=>throw new NotSupportedException("Unmapped type "+t.FullName)
    };
    static FieldInfo Field(MC.FieldReference f)=>Map(f.DeclaringType).GetField(f.Name,BindingFlags.Public|BindingFlags.Instance|BindingFlags.Static)??throw new NotSupportedException(f.FullName);
    static MethodBase Method(MC.MethodReference m)
    {
        if(m.DeclaringType.FullName=="System.String"&&m.Name=="op_Equality")return typeof(Program).GetMethod(nameof(StringEqual))!;
        if(m.DeclaringType.FullName=="UnityEngine.Object"&&m.Name=="op_Implicit")return typeof(Program).GetMethod(nameof(Truth))!;
        if(m.DeclaringType.FullName=="UnityEngine.Time"&&m.Name=="get_timeScale")return typeof(Program).GetMethod(nameof(TimeScale))!;
        if(m.DeclaringType.FullName=="UnityEngine.Animator"&&m.Name=="SetFloat")return typeof(AnimatorState).GetMethod(nameof(AnimatorState.SetFloat))!;
        if(m.DeclaringType.FullName=="BuffManager"&&m.Name=="GetIncrement")return typeof(BuffState).GetMethod(nameof(BuffState.GetIncrement))!;
        if(m.DeclaringType.FullName=="System.Math")return typeof(Math).GetMethod(m.Name,m.Parameters.Select(p=>Map(p.ParameterType)).ToArray())!;
        if(m.DeclaringType.FullName=="System.MathF")return typeof(MathF).GetMethod(m.Name,m.Parameters.Select(p=>Map(p.ParameterType)).ToArray())!;
        throw new NotSupportedException("Unmapped method "+m.FullName);
    }
    public static void Main(string[] args)
    {
        using var module=MC.ModuleDefinition.ReadModule(args[0]);MethodInfo Emit(int token)=>ActualCil.Emit((MC.MethodDefinition)module.LookupToken(token),Map,Field,Method);
        var stats=Emit(0x060000F8).CreateDelegate<Func<StatsState,float,string?,float>>();var device=Emit(0x0600018E).CreateDelegate<Func<int,float>>();var tou=Emit(0x0600044E).CreateDelegate<Func<ZombieState,int,float>>();var damage=Emit(0x06000602).CreateDelegate<Action<DamageState>>();var board=Emit(0x06000607).CreateDelegate<Func<BoardState,float>>();var clip=Emit(0x06000835).CreateDelegate<Func<ClipState,float>>();var rate1=Emit(0x06000863).CreateDelegate<Action<RateState,float>>();var rate2=Emit(0x06000887).CreateDelegate<Action<RateState,float>>();
        var rows=new List<object>();
        foreach(var c in JsonSerializer.Deserialize<List<Case>>(File.ReadAllText(args[1]))!)
        {
            Current=c;Trace=[];Times=0;string? result=null,error=null;object? state=null;
            try
            {
                switch(c.kind)
                {
                    case "device":result=Bits(device(c.id));break;
                    case "board":result=Bits(board(new(){boardEntryType=c.id,level=c.level}));break;
                    case "rate-controller":case "rate-manager":var r=new RateState(){_rateScale=123};if(c.kind=="rate-controller")rate1(r,Value(c.value));else rate2(r,Value(c.value));state=new{rate=Bits(r._rateScale)};break;
                    case "stats":Stats=new(){valueName=c.value_name,value=Value(c.value),multi=c.multi};result=Bits(stats(Stats,Value(c.other),c.input_name));state=new{value=Bits(Stats.value),multi=Stats.multi,value_name=Stats.valueName};break;
                    case "clip":Clip=new(){_clip=c.clip_kind==0?null:new("clip",c.clip_kind==1,Value(c.value))};result=Bits(clip(Clip));state=new{clip_id=Clip._clip?.Id,clip_live=Clip._clip?.Live,rate=Clip._clip==null?null:Bits(Clip._clip.FrameRate)};break;
                    case "damage":Damage=new(){animator=new("animator")};DamageState.Ani_SpeedHash=c.hash;damage(Damage);state=new{animator_id=Damage.animator?.Id,hash=DamageState.Ani_SpeedHash};break;
                    case "tou":Zombie=new(){armor1Toughness=Value(c.value),armor2Toughness=Value(c.other),buffManager=new("buff")};result=Bits(tou(Zombie,c.id));state=new{armor1=Bits(Zombie.armor1Toughness),armor2=Bits(Zombie.armor2Toughness),buff_id=Zombie.buffManager?.Id};break;
                    default:throw new NotSupportedException(c.kind);
                }
            }catch(Exception e){error=e.GetType().FullName;}
            rows.Add(new{name=c.name,kind=c.kind,result,trace=Trace.ToArray(),state,error});
        }
        // Real managed null controls. Native guards are read but Windows throw
        // and SEH unwinding are intentionally not executed by the native oracle.
        Current=new(){mode="clear-clip-on-truth"};Trace=[];Clip=new(){_clip=new("clip",true,1)};string? e1=null;try{clip(Clip);}catch(Exception e){e1=e.GetType().FullName;}var nullClip=new{error=e1,trace=Trace.ToArray()};
        Current=new(){time1="3F800000",time2="40000000"};Trace=[];Times=0;Damage=new(){animator=null};DamageState.Ani_SpeedHash=42;string? e2=null;try{damage(Damage);}catch(Exception e){e2=e.GetType().FullName;}var nullDamage=new{error=e2,trace=Trace.ToArray()};
        Current=new();Trace=[];Zombie=new(){armor1Toughness=1,buffManager=null};string? e3=null;try{tou(Zombie,1);}catch(Exception e){e3=e.GetType().FullName;}var nullBuff=new{error=e3,trace=Trace.ToArray()};
        var report=new{scope="ALL_EIGHT_COMPLETE_ACTUAL_CANDIDATE_CIL_CALLERS_CONTROLLED_EXTERNAL_CALLEES",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),all_source_instructions_emitted=true,native_exception_execution=false,unity_execution=false,results=rows,managed_null_controls=new{clip=nullClip,damage=nullDamage,buff=nullBuff}};
        File.WriteAllText(args[2],JsonSerializer.Serialize(report,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{cases=rows.Count}));
    }
}
