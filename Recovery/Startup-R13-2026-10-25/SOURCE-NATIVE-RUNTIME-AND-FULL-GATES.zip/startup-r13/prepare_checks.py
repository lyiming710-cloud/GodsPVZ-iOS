"""Bind readonly census/JIT and existing caller fixtures to exact R13."""
from pathlib import Path
import hashlib,json,shutil
Q=Path(__file__).resolve().parent;W=Q.parent;rows=[];sha=lambda b:hashlib.sha256(b).hexdigest();old='28946ce7343a4ca7479fb1a3aeb6b191bcc74aae5292a8b0a18f06c5019e1bd5';new='e6452513ce3c5a3d9449d8c7287aae39a8458cdc8e4eec09d199769aa1794b4b'
for name in ['full_type_census_r12.py','interface_facts_r12.py','census_lexical_tails.py','full_member_access.py']:
    src=W/'startup-r12'/name;b=src.read_bytes();text=b.decode().replace(old,new).replace("Q=W/'startup-r12'","Q=W/'startup-r13'")
    out=Q/name.replace('_r12','_r13');out.write_bytes(text.encode());rows.append(dict(source=str(src.relative_to(W)),source_sha256=sha(b),derived=str(out.relative_to(W)),derived_sha256=sha(out.read_bytes()),changes='Exact child hash/output only'))
shutil.copy2(W/'startup-r12/ALL-METHODS.json',Q/'ALL-METHODS.json')
c=json.loads((Q/'METHOD-CIL.json').read_text('utf-8-sig'));(Q/'METHODS.json').write_bytes((json.dumps(dict(methods=[dict(token=r['token']) for r in c['methods']]),indent=2)+'\n').encode())
src=W/'startup-r11/run_changed_exact_jit.py';b=src.read_bytes();text=b.decode().replace('e101c701802969bffe370841abc92cd01ec75592097d60b2b9e3629c5c107637',new).replace('len(tokens)==47','len(tokens)==8').replace('CHANGED_47_EXACT_CLR_JIT_PRECHECK_NO_GAMEPLAY_EXECUTION','CHANGED_EIGHT_EXACT_CLR_JIT_PRECHECK_NO_GAMEPLAY_EXECUTION')
out=Q/'run_changed_exact_jit.py';out.write_bytes(text.encode());rows.append(dict(source=str(src.relative_to(W)),source_sha256=sha(b),derived=str(out.relative_to(W)),derived_sha256=sha(out.read_bytes()),changes='Exact child and changed-eight token/output scope only'))
for name in ['run_prior_nut.py','run_prior_regressions.py']:
    src=W/'startup-r11'/name;b=src.read_bytes();text=b.decode().replace('e101c701802969bffe370841abc92cd01ec75592097d60b2b9e3629c5c107637',new).replace('startup-r11','startup-r13')
    out=Q/name;out.write_bytes(text.encode());rows.append(dict(source=str(src.relative_to(W)),source_sha256=sha(b),derived=str(out.relative_to(W)),derived_sha256=sha(out.read_bytes()),changes='Exact child and output binding only; prior native/CIL fixture implementations unchanged'))
(Q/'DRIVER-DERIVATION.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode());print('Prepared',len(rows),'input/scope-only driver derivatives')
