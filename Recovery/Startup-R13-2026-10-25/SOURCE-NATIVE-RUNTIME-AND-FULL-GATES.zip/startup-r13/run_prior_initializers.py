from pathlib import Path
import hashlib,json,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];P=W/'startup-r12';O=Q/'initializer-runtime-results';O.mkdir(exist_ok=True)
dll=Q/'candidate1.dll';digest=hashlib.sha256(dll.read_bytes()).hexdigest();assert digest=='e6452513ce3c5a3d9449d8c7287aae39a8458cdc8e4eec09d199769aa1794b4b'
cases=P/'runtime-results/CASES.json';assert len(json.loads(cases.read_bytes()))==90
commands=[('native',[sys.executable,P/'native_oracle.py',cases,O/'NATIVE.json']),('actual-cil',[ROOT/'.local/dotnet10/dotnet.exe',P/'runtime/bin/Release/net10.0/Fixture.dll',dll,cases,O/'ACTUAL-CIL.json'])]
for name,args in commands:
    p=subprocess.run([str(x) for x in args],capture_output=True,timeout=60);(O/(name+'.stdout.log')).write_bytes(p.stdout);(O/(name+'.stderr.log')).write_bytes(p.stderr);assert p.returncode==0,(name,p.returncode,p.stderr[-800:])
a=json.loads((O/'NATIVE.json').read_bytes());b=json.loads((O/'ACTUAL-CIL.json').read_bytes());assert a['results']==b['results'] and b['candidate_sha256']==digest
r=dict(scope='EXACT_R13_REPLAY_OF_THREE_R12_NATIVE_INITIALIZER_CALLERS_CONTROLLED_LOADS',candidate_sha256=digest,methods=3,cases=90,pass_=True,differences=0,actual_loader_behavior=False,native_unwind=False,whole_game=False)
(O/'RESULT.json').write_bytes((json.dumps(r,indent=2)+'\n').encode());print(json.dumps(r))
