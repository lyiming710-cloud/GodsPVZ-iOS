from pathlib import Path
import hashlib,json,sys
Q=Path(__file__).resolve().parent;ROOT=Q.parents[2];sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import pefile
from capstone import *
from capstone.x86_const import X86_OP_IMM
raw=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/GameAssembly.dll').read_bytes();assert hashlib.sha256(raw).hexdigest()=='9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d';p=pefile.PE(data=raw);base=p.OPTIONAL_HEADER.ImageBase;d=Cs(CS_ARCH_X86,CS_MODE_64);d.detail=True
for name,entry in [('MODF',0x1802cb1d8),('CEILF',0x1802cb2b8)]:
    pending=[entry];ins={};indirect=[]
    while pending:
        at=pending.pop()
        while at not in ins:
            i=next(d.disasm(p.get_data(at-base,15),at));ins[at]=i;assert len(ins)<1000
            if i.group(CS_GRP_RET) or i.mnemonic in ['int3','ud2']:break
            if i.group(CS_GRP_JUMP):
                if i.operands[0].type==X86_OP_IMM:pending.append(i.operands[0].imm)
                else:indirect.append(i.op_str)
                if i.mnemonic=='jmp':break
            at+=i.size
    rows=[dict(va=hex(i.address),op=i.mnemonic,operands=i.op_str,bytes=i.bytes.hex()) for i in sorted(ins.values(),key=lambda x:x.address)]
    assert not indirect and not any(x['op']=='call' for x in rows)
    (Q/f'{name}-HELPER-CFG.json').write_bytes((json.dumps(dict(entry=hex(entry),instructions=rows,indirect_jumps=indirect),indent=2)+'\n').encode());print(name,len(rows),'original instructions, no host substitution')
