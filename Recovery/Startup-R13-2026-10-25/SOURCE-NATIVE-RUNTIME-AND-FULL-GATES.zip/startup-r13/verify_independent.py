"""Independent raw all-methods/metadata and CIL semantic shape audit.

The constructor report and its byte-offset plan are never read. The native
table specification is independently checked against actual exported CIL;
real PC execution and physical fault controls remain separate evidence.
"""
from pathlib import Path
import collections,hashlib,importlib.util,json,struct,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
sha=lambda b:hashlib.sha256(b).hexdigest()
def mod(name,path):s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
writer=mod('reader_metadata',W/'startup-r2/construct.py');reader=mod('reader_bodies',ROOT/'audit/native111-publication-2026-10-20/repository/scripts/actions/static_gates.py')
a=(W/'startup-r12/candidate1.dll').read_bytes();b=(Q/'candidate1.dll').read_bytes();assert sha(a)=='28946ce7343a4ca7479fb1a3aeb6b191bcc74aae5292a8b0a18f06c5019e1bd5' and sha(b)=='e6452513ce3c5a3d9449d8c7287aae39a8458cdc8e4eec09d199769aa1794b4b' and b==(Q/'candidate2.dll').read_bytes()
pp=dnfile.dnPE(data=a);cp=dnfile.dnPE(data=b);targets={0xf8,0x18e,0x44e,0x602,0x607,0x835,0x863,0x887};relocated={0x18e,0x44e,0x607}
def meta(data,p):
    at=p.get_offset_from_rva(p.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress);rva,size=struct.unpack_from('<II',data,at+8);loc=p.get_offset_from_rva(rva);_,streams=writer.metadata_root(data[loc:loc+size]);v={n:x for n,_,x in streams};_,rows,_,counts=writer.tables_decode(v['#~']);return v,rows,counts
pv,pr,pc=meta(a,pp);cv,cr,cc=meta(b,cp);assert set(pr)==set(cr) and set(pv)==set(cv)
for t in pr:
    if t==6:
        assert len(pr[t])==len(cr[t])==2317
        for rid,(x,y) in enumerate(zip(pr[t],cr[t]),1):
            if rid in relocated:assert x[0]!=y[0] and x[1:]==y[1:]
            else:assert x==y
    elif t==10:assert cr[t][:-1]==pr[t]
    elif t==17:assert cr[t][:-2]==pr[t]
    else:assert pr[t]==cr[t],t
for n in pv:
    if n in ['#Strings','#Blob']:assert cv[n].startswith(pv[n])
    elif n!='#~':assert pv[n]==cv[n]
mr=cp.net.mdtables.MemberRef.rows[-1];assert str(mr.Name)=='Ceiling' and mr.Signature.value==bytes.fromhex('00010d0d') and str(mr.Class.row.TypeName)=='Math' and str(mr.Class.row.TypeNamespace)=='System'
def loc(data,p,rid):
    row=p.net.mdtables.MethodDef.rows[rid-1];at=p.get_offset_from_rva(row.Rva);h=1 if data[at]&3==2 else (struct.unpack_from('<H',data,at)[0]>>12)*4;size=data[at]>>2 if h==1 else struct.unpack_from('<I',data,at+4)[0];return at,h,size
changed=[]
for rid,(old,new) in enumerate(zip(pp.net.mdtables.MethodDef.rows,cp.net.mdtables.MethodDef.rows),1):
    if not old.Rva:assert not new.Rva;continue
    x=pp.get_offset_from_rva(old.Rva);y=cp.get_offset_from_rva(new.Rva);xs=reader.parse_raw_method_body_span(a,x)[0];ys=reader.parse_raw_method_body_span(b,y)[0]
    if a[x:x+xs]!=b[y:y+ys]:changed.append(rid)
    if rid in relocated:assert a[x:x+xs]==b[x:x+xs]
assert set(changed)==targets and len(changed)==8
old_cil=json.loads((W/'startup-r12/ALL-CIL.json').read_text('utf-8-sig'));old_ms={int(x['token'],16)&0xffffff:x for x in old_cil['methods']};new_cil=json.loads((Q/'METHOD-CIL.json').read_text('utf-8-sig'));ms={int(x['token'],16)&0xffffff:x for x in new_cil['methods']}
allowed=set();shape=[]
for rid,zeroes in [(0xf8,[107]),(0x835,[70]),(0x863,[0,15]),(0x887,[0,15])]:
    old=old_ms[rid];new=ms[rid];x,h,n=loc(a,pp,rid);y,j,m=loc(b,cp,rid);assert x==y and h==j and n==m and old['locals']==new['locals'] and old['maxStack']==new['maxStack'] and old['handlers']==new['handlers']==[]
    expected=bytearray(a[x+h:x+h+n])
    for at in zeroes:assert expected[at:at+5]==bytes.fromhex('2000000000');expected[at:at+5]=bytes.fromhex('2200000000');allowed.update(range(x+h+at,x+h+at+5))
    if rid==0xf8:
        assert expected[85:91]==b'\x02\x7b'+struct.pack('<I',0x04000110);expected[85:91]=bytes.fromhex('110600000000');allowed.update(range(x+h+85,x+h+91))
    assert expected==b[y+j:y+j+m];shape.append(dict(token=new['token'],scope='EXACT_FIXED_WIDTH_FLOAT_ZERO_AND_CAPTURED_VALUE_OPERANDS',pass_=True))
# Independent semantic block interpretation of the actual two restored switches.
spec=json.loads((Q/'TABLE-SPECIFICATION.json').read_bytes())
def bits(value):return struct.pack('<f',value)[::-1].hex().upper()
def instructions(rid):return ms[rid]['instructions']
def expect_constant(ins,index,expected):assert ins[index]['opcode']=='ldc.r4' and bits(ins[index]['operand'])==expected and ins[index+1]['opcode']=='ret'
dev=instructions(0x18e);assert not ms[0x18e]['hasThis'] and ms[0x18e]['args']==['System.Int32'] and [r['opcode'] for r in dev[:4]]==['ldarg.0','ldc.i4','sub','switch'] and dev[1]['operand']==4
index={i['offset']:k for k,i in enumerate(dev)};labels=dev[3]['operand']['targets'];assert len(labels)==11;expect_constant(dev,4,'00000000')
for target,row in zip(labels,spec['device_constants']):expect_constant(dev,index[target],row['constant']['bits'])
board=instructions(0x607);assert ms[0x607]['hasThis'] and [r['opcode'] for r in board[:3]]==['ldarg.0','ldfld','switch'] and board[1]['operand']['identity']=='BoardEntryType BoardEntry::boardEntryType';index={i['offset']:k for k,i in enumerate(board)};labels=board[2]['operand']['targets'];assert len(labels)==36;expect_constant(board,3,'00000000')
aliases={}
for selection,target in zip(spec['board_type_selectors'],labels):
    if selection in aliases:assert aliases[selection]==target
    aliases[selection]=target
for selection,group in enumerate(spec['board_groups']):
    k=index[aliases[selection]];lookup=group['level_constants'];formula=group['formula']
    if formula:
        seq=board[k:k+6];assert [i['opcode'] for i in seq]==['ldarg.0','ldfld','conv.r4','ldc.r4','mul','ret'] and seq[1]['operand']['identity']=='System.Int32 BoardEntry::level' and bits(seq[3]['operand'])==formula['factor']['bits']
    elif not lookup:expect_constant(board,k,'00000000')
    else:
        seq=board[k:k+5];assert [i['opcode'] for i in seq]==['ldarg.0','ldfld','ldc.i4','sub','switch'] and seq[1]['operand']['identity']=='System.Int32 BoardEntry::level' and seq[2]['operand']==1
        sublabels=seq[4]['operand']['targets'];assert len(sublabels)==max(int(n) for n in lookup);expect_constant(board,k+5,'00000000')
        for level,target in enumerate(sublabels,1):expect_constant(board,index[target],lookup.get(str(level),dict(bits='00000000'))['bits'])
shape.extend([dict(token='0x0600018E',scope='COMPLETE_UNSIGNED_ID_SWITCH_AND_EXACT_NATIVE_CONSTANT_BITS',pass_=True),dict(token='0x06000607',scope='COMPLETE_TYPE_LEVEL_SWITCH_AND_FLOAT32_LEVEL_TIMES_TEN',pass_=True)])
# Capture/check ordering comes directly from the native receiver/hash registers.
damage=ms[0x602];d=damage['instructions'];assert [i['opcode'] for i in d]==['call','stloc.s','ldarg.0','ldfld','stloc.s','ldloc.s','ldc.r4','ceq','brfalse','ldsfld','stloc.s','ldc.r4','stloc.s','br','ldsfld','stloc.s','ldc.r4','call','div','stloc.s','ldloc.s','ldloc.s','ldloc.s','callvirt','ret']
assert damage['locals']==old_ms[0x602]['locals']+['UnityEngine.Animator'] and d[4]['operand']['index']==d[20]['operand']['index']==8 and d[3]['operand']['identity']=='UnityEngine.Animator DamageText::animator'
assert [i['operand']['identity'] for i in d if i['opcode'] in ['call','callvirt']]==['System.Single UnityEngine.Time::get_timeScale()','System.Single UnityEngine.Time::get_timeScale()','System.Void UnityEngine.Animator::SetFloat(System.Int32,System.Single)']
assert d[8]['operand']['target']==d[14]['offset'] and d[13]['operand']['target']==d[20]['offset'] and [d[k]['operand'] for k in [6,11,16]]==[0,0,1]
shape.append(dict(token='0x06000602',scope='EXACT_CAPTURED_ANIMATOR_HASH_BEFORE_TIME2_NAN_NONZERO_AND_NULL_THROW_PATHS',pass_=True))
# Verify the custom round skeleton, including guarded Int64 parity conversion.
tou=ms[0x44e];t=tou['instructions'];assert tou['locals']==old_ms[0x44e]['locals']+['System.Double','System.Single'];calls=[i for i in t if i['opcode'] in ['call','callvirt']]
assert [i['operand']['identity'] for i in calls]==['System.Single BuffManager::GetIncrement(System.Single,System.String)','System.Double System.Math::Truncate(System.Double)','System.Double System.Math::Floor(System.Double)','System.Double System.Math::Ceiling(System.Double)','System.Single System.Math::Max(System.Single,System.Single)'] and calls[0]['opcode']=='callvirt'
assert [i['operand'] for i in t if i['opcode']=='ldstr']==['Tou'] and [i['operand'] for i in t if i['opcode']=='ldc.r8']==[0.5,-0.5]
assert sum(i['opcode']=='clt.un' for i in t)==1 and sum(i['opcode']=='conv.i8' for i in t)==2
for k,i in enumerate(t):
    if i['opcode']!='conv.i8':continue
    seq=t[k-1:k+6];assert seq[0]['opcode']=='ldloc.s' and seq[0]['operand']['index']==11 and [x['opcode'] for x in seq[1:]]==['conv.i8','ldc.i8','and','ldc.i8','ceq','brtrue'] and seq[2]['operand']==1 and seq[4]['operand']==0
    # The parity block is reachable solely by equality to fractional +/-0.5.
    entry=seq[0]['offset'];incoming=[(j,x) for j,x in enumerate(t) if isinstance(x['operand'],dict) and x['operand'].get('target')==entry];assert len(incoming)==1
    j,branch=incoming[0];assert branch['opcode']=='brtrue' and t[j-1]['opcode']=='ceq' and t[j-2]['opcode']=='ldc.r8' and abs(t[j-2]['operand'])==0.5
assert t[-3]['opcode']=='ldc.r4' and t[-3]['operand']==0 and t[-2]==calls[-1] and t[-1]['opcode']=='ret'
shape.append(dict(token='0x0600044E',scope='NATIVE_FLOAT32_HALF_ADJUSTMENT_ORDERED_FRACTION_TIES_INT64_PARITY_AND_FINAL_MAX',pass_=True))
# A short rewritten body may leave original bytes as non-executed slot padding.
x,h,n=loc(a,pp,0x602);y,j,m=loc(b,cp,0x602);assert x==y and h==j==12 and m<n;allowed.update(range(y+j,y+j+m));allowed.update(range(y+4,y+12));assert a[x+h+m:x+h+n]==b[x+h+m:x+h+n]
sh=pp.sections[-1].get_file_offset();opt=pp.OPTIONAL_HEADER.get_file_offset();cli=pp.get_offset_from_rva(pp.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress)
allowed.update(p+i for p in [sh+8,sh+16,opt+8,opt+56,opt+64,cli+8,cli+12] for i in range(4))
def boundary(data):
    if len(data)!=len(b) or any(x!=y and i not in allowed for i,(x,y) in enumerate(zip(a,data))):raise ValueError('Non-target bytes changed')
boundary(b);controls=[]
for name,at in [('unrelated-GameStart-body',pp.get_offset_from_rva(pp.net.mdtables.MethodDef.rows[0x526-1].Rva)+12),('old-metadata',pp.get_offset_from_rva(pp.net.struct.MetaDataRva)),('old-relocated-slot',pp.get_offset_from_rva(pp.net.mdtables.MethodDef.rows[0x607-1].Rva)+1)]:
    bad=bytearray(b);bad[at]^=1
    try:boundary(bad)
    except ValueError:controls.append(dict(name=name,rejected=True));continue
    raise AssertionError('Raw isolation false accept')
result=dict(scope='INDEPENDENT_ALL_METHODDEF_METADATA_HEAP_RAW_PREFIX_AND_ACTUAL_CIL_SPECIFICATION',candidate_sha256=sha(b),parent_sha256=sha(a),pass_=True,changed_methods=8,unchanged_methoddefs=2309,relocated_methods=3,new_memberrefs=1,new_private_local_signatures=2,field_type_method_visibility_unchanged=True,old_metadata_rows_heaps_prefixes_preserved=True,old_relocated_code_slots_preserved=True,semantic_shape_rows=shape,negative_isolation_controls=controls,whole_game_acceptance=False)
(Q/'ISOLATION-AND-CIL-SPEC.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result,indent=2))
