"""Derive finite switch partitions from original affine Int32 branch tests.

No observed runtime output is used to implement the restored getters. Each
nonzero constant leaf must have one exact level equality constraint. All other
levels provably reach zero, apart from the explicit float(level)*factor leaf.
"""
from pathlib import Path
import hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;ROOT=Q.parents[2];sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import pefile
from capstone import *
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP,X86_OP_IMM
raw=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/GameAssembly.dll').read_bytes();assert hashlib.sha256(raw).hexdigest()=='9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d';p=pefile.PE(data=raw);base=p.OPTIONAL_HEADER.ImageBase;d=Cs(CS_ARCH_X86,CS_MODE_64);d.detail=True
def signed(n):return (n+0x80000000)%0x100000000-0x80000000
def constant(i):
    op=i.operands[1];assert op.type==X86_OP_MEM and op.mem.base==X86_REG_RIP;at=i.address+i.size+op.mem.disp;b=p.get_data(at-base,4);return dict(va=hex(at),bits=b[::-1].hex().upper(),value=struct.unpack('<f',b)[0])
def paths(start):
    queue=[dict(pc=start,offset=None,eq=None,ne=[],out=dict(kind='constant',bits='00000000'),trace=[])]
    leaves=[]
    while queue:
        state=queue.pop();at=state['pc'];offset=state['offset'];equal=state['eq'];excluded=set(state['ne']);out=state['out'];trace=list(state['trace']);zero=None
        while True:
            i=next(d.disasm(p.get_data(at-base,15),at));trace.append(dict(va=hex(at),op=i.mnemonic,args=i.op_str));assert len(trace)<80
            if i.mnemonic=='ret':leaves.append(dict(equal_level=equal,excluded_levels=sorted(excluded),output=out,instructions=trace));break
            if i.mnemonic=='mov' and i.op_str=='ecx, dword ptr [rcx + 0x14]':offset=0
            elif i.mnemonic=='sub':
                assert i.op_str=='ecx, 1' and offset is not None;offset=signed(offset-1);zero=signed(-offset)
            elif i.mnemonic=='cmp':assert i.op_str=='ecx, 1' and offset is not None;zero=signed(1-offset)
            elif i.mnemonic in ('je','jne'):
                assert zero is not None;target=i.operands[0].imm;nxt=at+i.size
                for take in [False,True]:
                    iseq=(take and i.mnemonic=='je') or (not take and i.mnemonic=='jne');eq=equal;ne=set(excluded)
                    if iseq:
                        if zero in ne or eq is not None and eq!=zero:continue
                        eq=zero
                    else:
                        if eq==zero:continue
                        ne.add(zero)
                    queue.append(dict(pc=target if take else nxt,offset=offset,eq=eq,ne=sorted(ne),out=out,trace=trace))
                break
            elif i.mnemonic=='movss':out=dict(kind='constant',**constant(i))
            elif i.mnemonic=='movd':assert i.op_str=='xmm0, dword ptr [rcx + 0x14]';out=dict(kind='level_bits')
            elif i.mnemonic=='cvtdq2ps':assert out['kind']=='level_bits';out=dict(kind='float32_level')
            elif i.mnemonic=='mulss':assert out['kind']=='float32_level';out=dict(kind='float32_level_times_float32_constant',factor=constant(i))
            else:raise AssertionError((hex(at),i.mnemonic,i.op_str))
            at+=i.size
    return leaves
board=json.loads((Q/'0607.expanded-native.json').read_bytes());groups=[]
for t in board['table_targets']:
    leaves=paths(int(t,16));lookup={};default=None;formula=None
    for l in leaves:
        out=l['output'];eq=l['equal_level']
        if out['kind']=='constant':
            if eq is None:assert out['bits']=='00000000';default=out
            else:assert eq not in lookup;lookup[eq]=out
        else:assert eq is None and out['kind']=='float32_level_times_float32_constant' and len(leaves)==1;formula=out
    if formula is None:assert default is not None
    assert all(1<=k<=5 for k in lookup)
    groups.append(dict(native_entry=t,level_constants={str(k):v for k,v in sorted(lookup.items())},default=default,formula=formula,proof_leaves=leaves))
device=json.loads((Q/'018E.expanded-native.json').read_bytes());dev=[]
for n,target in enumerate(device['table_targets']):
    at=int(target,16);i=next(d.disasm(p.get_data(at-base,15),at));v=dict(bits='00000000',value=0.0)
    if i.mnemonic=='movss':v=constant(i);at+=i.size;i=next(d.disasm(p.get_data(at-base,15),at))
    assert i.mnemonic=='ret';dev.append(dict(id=n+4,target=target,constant=v))
result=dict(scope='CONSTRUCTION_SPEC_DERIVED_FROM_ORIGINAL_BOUNDED_TABLE_AND_AFFINE_BRANCH_BYTES',original_sha256=hashlib.sha256(raw).hexdigest(),board_type_selectors=list(bytes.fromhex(board['selector_bytes'])),board_groups=groups,board_type_field=dict(token='0x040007FA',name='boardEntryType',offset=16),board_level_field=dict(token='0x040007FB',name='level',offset=20),device_id_range=[4,14],device_constants=dev,device_default=dict(bits='00000000',value=0.0),runtime_outputs_used=False)
(Q/'TABLE-SPECIFICATION.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(dict(device_constants=dev,board_groups=[{k:v for k,v in x.items() if k!='proof_leaves'} for x in groups]),indent=2))
# Full rounding helper including the native floor tail. extract_math_helpers.py
# also extracts original modf/ceil code; the oracle executes those originals.
queue=[0x180003010];ins={}
while queue:
    at=queue.pop()
    while at not in ins:
        i=next(d.disasm(p.get_data(at-base,15),at));ins[at]=i;assert len(ins)<500
        if i.group(CS_GRP_RET) or i.mnemonic in ('int3','ud2'):break
        if i.group(CS_GRP_JUMP):
            assert i.operands[0].type==X86_OP_IMM;queue.append(i.operands[0].imm)
            if i.mnemonic=='jmp':break
        at+=i.size
rows=[dict(va=hex(i.address),op=i.mnemonic,operands=i.op_str,bytes=i.bytes.hex()) for i in sorted(ins.values(),key=lambda x:x.address)]
(Q/'ROUND-HELPER-CFG.json').write_bytes((json.dumps(dict(entry='0x180003010',instructions=rows,calls=[r for r in rows if r['op']=='call']),indent=2)+'\n').encode());print('Rounding helper',len(rows),'instructions','callees',[r['operands'] for r in rows if r['op']=='call'])
