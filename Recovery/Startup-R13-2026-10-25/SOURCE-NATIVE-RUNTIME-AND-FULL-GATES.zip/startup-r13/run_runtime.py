from pathlib import Path
import collections,concurrent.futures,hashlib,importlib.util,json,struct,subprocess,sys
Q=Path(__file__).resolve().parent;ROOT=Q.parents[2];O=Q/'runtime-results';O.mkdir(exist_ok=True);sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
sha=lambda b:hashlib.sha256(b).hexdigest();raw=(Q/'candidate1.dll').read_bytes();digest=sha(raw);assert digest=='e6452513ce3c5a3d9449d8c7287aae39a8458cdc8e4eec09d199769aa1794b4b'
dot=ROOT/'.local/dotnet10/dotnet.exe';fixture=Q/'runtime/bin/Release/net10.0/Fixture.dll';export=ROOT/'audit/bulk250-r1-evidence-39702928368/bulk250-r1-run/tools_bin/CilExporter/bin/CilExporter.dll';sup=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'
def run(label,args,allow_invalid=False):
    p=subprocess.run([str(x) for x in args],capture_output=True,timeout=120);(O/(label+'.stdout.log')).write_bytes(p.stdout);(O/(label+'.stderr.log')).write_bytes(p.stderr)
    if p.returncode and not (allow_invalid and b'InvalidProgramException' in p.stderr):raise RuntimeError((label,p.returncode,p.stderr[-1200:]))
    return p
run('generate-cases',[sys.executable,Q/'generate_cases.py'])
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    jobs=[pool.submit(run,'native',[sys.executable,Q/'native_oracle.py',O/'CASES.json',O/'NATIVE.json']),pool.submit(run,'actual-cil',[dot,fixture,Q/'candidate1.dll',O/'CASES.json',O/'ACTUAL-CIL.json'])]
    for job in jobs:job.result()
native=json.loads((O/'NATIVE.json').read_bytes());cil=json.loads((O/'ACTUAL-CIL.json').read_bytes());a=native['results'];b=cil['results'];assert len(a)==len(b)==13167 and cil['candidate_sha256']==digest
diff=[dict(name=x['name'],native=x,cil=y) for x,y in zip(a,b) if x!=y]
baseline=dict(scope='EIGHT_COMPLETE_ACTUAL_CIL_VS_ORIGINAL_PC_CALLERS_WITH_ORIGINAL_MATH_HELPERS_CONTROLLED_CALLEES',candidate_sha256=digest,cases=len(a),counts=dict(collections.Counter(x['kind'] for x in a)),pass_=not diff,differences=diff)
(O/'BASELINE.json').write_bytes((json.dumps(baseline,indent=2)+'\n').encode());assert not diff, diff[:3]
assert cil['managed_null_controls']==dict(clip=dict(error='System.NullReferenceException',trace=['Truth:clip:1']),damage=dict(error='System.NullReferenceException',trace=['Time:1:3F800000','Time:2:40000000']),buff=dict(error='System.NullReferenceException',trace=[]))
pe=dnfile.dnPE(data=raw);method_cil={int(m['token'],16)&0xffffff:m for m in json.loads((Q/'METHOD-CIL.json').read_text('utf-8-sig'))['methods']}
def body(rid):
    at=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[rid-1].Rva);head=1 if raw[at]&3==2 else (struct.unpack_from('<H',raw,at)[0]>>12)*4;size=raw[at]>>2 if head==1 else struct.unpack_from('<I',raw,at+4)[0];return at,head,size
mutants={}
def fixed(name,edits):
    data=bytearray(raw)
    for rid,offset,expected,replacement in edits:
        at,h,n=body(rid);assert len(expected)==len(replacement) and raw[at+h+offset:at+h+offset+len(expected)]==expected;data[at+h+offset:at+h+offset+len(expected)]=replacement
    mutants[name]=bytes(data)
def zero_method(name,rid):
    data=bytearray(raw);at,h,n=body(rid);assert h==12;data[at+h:at+h+6]=bytes.fromhex('22000000002a');struct.pack_into('<I',data,at+4,6);mutants[name]=bytes(data)
zero_method('device-cd-always-zero',0x18e);zero_method('board-value-always-zero',0x607)
at,h,n=body(0x607);code=raw[at+h:at+h+n];needle=b'\x7b'+struct.pack('<I',0x040007fb);offsets=[i for i in range(len(code)-4) if code[i:i+5]==needle];assert len(offsets)==9
fixed('board-level-read-from-type',[(0x607,i,needle,b'\x7b'+struct.pack('<I',0x040007fa)) for i in offsets])
needle=b'\x7b'+struct.pack('<I',0x040007fb)+b'\x6b\x22'+struct.pack('<f',10)+b'\x5a\x2a';pos=code.index(needle)+7;fixed('board-level-factor-nine',[(0x607,pos,struct.pack('<f',10),struct.pack('<f',9))])
fixed('rate-unordered-low-clamp',[(rid,9,bytes.fromhex('fe02'),bytes.fromhex('fe03')) for rid in [0x863,0x887]])
fixed('rate-upper-clamp-one',[(rid,off,b'\x22'+struct.pack('<f',3.4028234663852886e38),b'\x22'+struct.pack('<f',1)) for rid in [0x863,0x887] for off in [42,53]])
fixed('clip-truth-branch-inverted',[(0x835,35,b'\x3a',b'\x39')]);fixed('stats-multiply-replaced-add',[(0xf8,97,b'\x5a',b'\x58')]);fixed('stats-integer-zero-restored',[(0xf8,107,b'\x22',b'\x20')])
def rewrite_damage(name,replacements):
    rid=0x602;at,h,n=body(rid);ins=method_cil[rid]['instructions'];old=raw[at+h:at+h+n];new=bytearray();mapping={};branches=[]
    for k,i in enumerate(ins):
        p=i['offset'];end=ins[k+1]['offset'] if k+1<len(ins) else n;mapping[p]=len(new);chunk=old[p:end]
        if isinstance(i['operand'],dict) and 'target' in i['operand']:assert len(chunk)==5;branches.append((len(new),i['operand']['target']))
        new.extend(replacements.get(p,chunk))
    for p,target in branches:struct.pack_into('<i',new,p+1,mapping[target]-(p+5))
    assert len(new)<=151;data=bytearray(raw);data[at+h:at+h+len(new)]=new;struct.pack_into('<I',data,at+4,len(new));mutants[name]=bytes(data)
ins=method_cil[0x602]['instructions'];load_anim=next(i for i in ins if i['opcode']=='ldfld');anim_token=raw[body(0x602)[0]+body(0x602)[1]+load_anim['offset']+1:body(0x602)[0]+body(0x602)[1]+load_anim['offset']+5]
apply=next(i for i in reversed(ins) if i['opcode']=='ldloc.s' and i['operand']['index']==8);rewrite_damage('animator-reloaded-after-time2',{apply['offset']:b'\x02\x7b'+anim_token})
hashes=[(k,i) for k,i in enumerate(ins) if i['opcode']=='ldsfld'];assert len(hashes)==2;hash_k,late_hash=hashes[1];apply_hash=next(i for i in ins if i['offset']>apply['offset'] and i['opcode']=='ldloc.s' and i['operand']['index']==4)
hash_token=raw[body(0x602)[0]+body(0x602)[1]+late_hash['offset']+1:body(0x602)[0]+body(0x602)[1]+late_hash['offset']+5]
rewrite_damage('hash-reloaded-after-time2',{late_hash['offset']:b'\0'*5,ins[hash_k+1]['offset']:b'\0'*2,apply_hash['offset']:b'\x7e'+hash_token})
ins=method_cil[0x44e]['instructions'];trunc_index=next(k for k,i in enumerate(ins) if i['opcode']=='call' and i['operand']['name']=='Truncate');start=ins[trunc_index-2]['offset'];max_index=next(k for k,i in enumerate(ins) if i['opcode']=='call' and i['operand']['name']=='Max');max_label=ins[max_index-1]['offset'];at,h,n=body(0x44e);code=raw[at+h:at+h+n]
prefix=bytes.fromhex('1107')+b'\x38'+struct.pack('<i',max_label-(start+7))+b'\0';fixed('tou-round-omitted',[(0x44e,start,code[start:start+8],prefix)])
end=ins[trunc_index+4]['offset'];assert end-start==17
ideal=bytes.fromhex('1107')+b'\x28'+struct.pack('<I',0x0a0001f8)+b'\x38'+struct.pack('<i',max_label-(start+12))+b'\0'*5
fixed('tou-ideal-mathf-round-substituted',[(0x44e,start,code[start:end],ideal)])
parity=[i['offset'] for i in ins if i['opcode']=='ldc.i8' and i['operand']==1];assert len(parity)==2
fixed('tou-ties-always-even-integerpart',[(0x44e,p,b'\x21'+struct.pack('<q',1),b'\x21'+struct.pack('<q',0)) for p in parity])
controls=[]
for name,data in mutants.items():
    dll=O/(name+'.dll');dll.write_bytes(data);p=run(name,[dot,fixture,dll,O/'CASES.json',O/(name+'.json')],allow_invalid=name=='stats-integer-zero-restored')
    count=None
    if p.returncode==0:
        rows=json.loads((O/(name+'.json')).read_bytes())['results'];assert len(rows)==len(a);count=sum(x!=y for x,y in zip(a,rows))
    entry=dict(name=name,mutant_sha256=sha(data),runtime_differences=count,runtime_exit=p.returncode)
    if name=='stats-integer-zero-restored':
        f=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py';assert sha(f.read_bytes())=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14';s=importlib.util.spec_from_file_location('unchanged_frozen',f);v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
        run('width-export',[dot,export,dll,O/'WIDTH-MUTANT-CIL.json',sup,'0x060000F8']);c=json.loads((O/'WIDTH-MUTANT-CIL.json').read_text('utf-8-sig'))
        try:bad=v.verify(c['methods'][0],c['types'])
        except Exception as e:bad=dict(status='FAIL',error=str(e))
        assert bad['status']!='PASS' and 'I4' in bad['error'];entry.update(runtime_alone_adequate=False,frozen_width_rejected=True,frozen_result=bad)
    else:assert count and count>0,entry
    controls.append(entry)
result=dict(**{k:v for k,v in baseline.items() if k not in ['pass_','differences']},pass_=True,differences=[],negative_controls=controls,managed_null_controls=cil['managed_null_controls'],original_round_modf_ceil_floor_max_code_executed=True,host_math_replacement_of_original_helpers=False,real_unity_callees=False,real_buff_and_string_callees=False,native_exception_unwind=False,nan_payload_or_fp_status_equivalence=False,full_game_acceptance=False,ipa=None)
(O/'RESULT.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result,indent=2))
