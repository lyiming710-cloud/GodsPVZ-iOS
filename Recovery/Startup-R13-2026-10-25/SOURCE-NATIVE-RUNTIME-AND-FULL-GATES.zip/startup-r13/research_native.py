"""Read-only direct CFG, CIL and field evidence for a floating-point batch."""
from pathlib import Path
import hashlib,json,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import pefile
from capstone import Cs,CS_ARCH_X86,CS_MODE_64,CS_GRP_RET,CS_GRP_JUMP
from capstone.x86_const import X86_OP_IMM
inputs=ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs';raw=(inputs/'original-pc/GameAssembly.dll').read_bytes();assert hashlib.sha256(raw).hexdigest()=='9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d'
p=pefile.PE(data=raw);base=p.OPTIONAL_HEADER.ImageBase;d=Cs(CS_ARCH_X86,CS_MODE_64);d.detail=True
known=json.loads((inputs/'maps/native-method-map.json').read_text('utf-8-sig'));starts={int(m['va'],16) for m in known if m.get('va')}
cil=json.loads((W/'startup-r12/ALL-CIL.json').read_text('utf-8-sig'));methods={m['token']:m for m in cil['methods']};fields=json.loads((inputs/'maps/native-fields.json').read_text('utf-8-sig'));summaries=[]
for rid in [0xF8,0x18E,0x44E,0x602,0x607,0x835,0x863,0x887]:
    token=f'0x{0x6000000|rid:08X}';m=methods[token];(Q/f'{rid:04X}.cil.json').write_bytes((json.dumps(m,indent=2)+'\n').encode());(Q/f'{rid:04X}.cil.txt').write_text('\n'.join(f"{i['offset']:4} {i['opcode']:14} {json.dumps(i['operand'],ensure_ascii=False)}" for i in m['instructions'])+'\n',encoding='utf-8')
    va=int.from_bytes(p.get_data(0x181b82d60-base+(rid-1)*8,8),'little');pending=[va];ins={};edges=[];tails=[];indirect=[]
    while pending:
        at=pending.pop()
        while at not in ins:
            section=p.get_section_by_rva(at-base);assert section and section.Characteristics&0x20000000
            i=next(d.disasm(p.get_data(at-base,15),at,count=1));ins[at]=i;assert len(ins)<8000
            if i.group(CS_GRP_RET) or i.mnemonic in ('int3','ud2'):break
            if i.group(CS_GRP_JUMP):
                if i.operands[0].type==X86_OP_IMM:
                    dest=i.operands[0].imm;edges.append(dict(source=hex(at),target=hex(dest),op=i.mnemonic))
                    if dest in starts and dest!=va:tails.append(dict(source=hex(at),target=hex(dest)))
                    elif dest not in ins:pending.append(dest)
                else:indirect.append(dict(va=hex(at),op=i.mnemonic,operands=i.op_str))
                if i.mnemonic=='jmp':break
            at+=i.size
    rows=[dict(va=hex(i.address),op=i.mnemonic,operands=i.op_str,bytes=i.bytes.hex()) for i in sorted(ins.values(),key=lambda x:x.address)]
    cfg=dict(token=token,entry=hex(va),scope='NORMAL_DIRECT_CFG_ONLY_NO_EXCEPTION_UNWIND',instructions=rows,edges=edges,tail_targets=tails,indirect_jumps=indirect)
    (Q/f'{rid:04X}.native.json').write_bytes((json.dumps(cfg,indent=2)+'\n').encode());(Q/f'{rid:04X}.native.txt').write_text('\n'.join(f"{r['va']} {r['bytes']:22s} {r['op']} {r['operands']}" for r in rows)+'\n')
    refs={i['operand']['identity'] for i in m['instructions'] if i['opcode'] in ('ldfld','stfld','ldsfld','stsfld')};ff=[r for r in fields if any(x.endswith(' '+(r['namespace']+'.' if r['namespace'] else '')+r['type']+'::'+r['name']) for x in refs)]
    summaries.append(dict(token=token,name=m['name'],cil_instructions=len(m['instructions']),native_instructions=len(rows),native_entry=hex(va),tail_targets=tails,indirect_jumps=indirect,fields=ff,calls=[r for r in rows if r['op']=='call']))
(Q/'RESEARCH.json').write_bytes((json.dumps(summaries,indent=2)+'\n').encode());print(json.dumps(summaries,indent=2))
