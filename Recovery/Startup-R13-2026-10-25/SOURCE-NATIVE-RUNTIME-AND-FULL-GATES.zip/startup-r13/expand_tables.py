"""Resolve only the two proven bounded original native jump tables."""
from pathlib import Path
import hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;ROOT=Q.parents[2];sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import pefile
from capstone import *
from capstone.x86_const import X86_OP_IMM
b=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/GameAssembly.dll').read_bytes();assert hashlib.sha256(b).hexdigest()=='9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d';p=pefile.PE(data=b);base=p.OPTIONAL_HEADER.ImageBase;d=Cs(CS_ARCH_X86,CS_MODE_64);d.detail=True
for rid,entry,table,count,selectors in [(0x18e,0x180312b80,0x312bc8,11,None),(0x607,0x180395070,0x395218,0,p.get_data(0x395240,36))]:
    if selectors is not None:count=max(selectors)+1
    offsets=struct.unpack('<'+'I'*count,p.get_data(table,count*4));targets=[base+x for x in offsets]
    pending=[entry]+targets;ins={};edges=[];indirect=[]
    while pending:
        at=pending.pop()
        while at not in ins:
            i=next(d.disasm(p.get_data(at-base,15),at,count=1));ins[at]=i;assert len(ins)<2000
            if i.group(CS_GRP_RET) or i.mnemonic in ('int3','ud2'):break
            if i.group(CS_GRP_JUMP):
                if i.operands[0].type==X86_OP_IMM:target=i.operands[0].imm;edges.append(dict(source=hex(at),target=hex(target)));pending.append(target)
                else:indirect.append(dict(va=hex(at),op=i.mnemonic,operand=i.op_str))
                if i.mnemonic=='jmp':break
            at+=i.size
    rows=[dict(va=hex(i.address),op=i.mnemonic,operands=i.op_str,bytes=i.bytes.hex()) for i in sorted(ins.values(),key=lambda x:x.address)]
    out=dict(token=f'0x{0x6000000|rid:08X}',entry=hex(entry),scope='FULL_BOUNDED_JUMP_TABLE_NORMAL_CFG_ONLY',table_rva=hex(table),table_bytes=p.get_data(table,count*4).hex(),table_targets=[hex(t) for t in targets],selector_bytes=selectors.hex() if selectors is not None else None,selector_rva='0x395240' if selectors is not None else None,instructions=rows,edges=edges,indirect_jumps=indirect)
    (Q/f'{rid:04X}.expanded-native.json').write_bytes((json.dumps(out,indent=2)+'\n').encode());(Q/f'{rid:04X}.expanded-native.txt').write_text('\n'.join(f"{r['va']} {r['bytes']:22s} {r['op']} {r['operands']}" for r in rows)+'\n')
    print(hex(rid),'entries',len(targets),'targets',[hex(t) for t in targets],'selectors',list(selectors) if selectors else None,'instructions',len(rows))
