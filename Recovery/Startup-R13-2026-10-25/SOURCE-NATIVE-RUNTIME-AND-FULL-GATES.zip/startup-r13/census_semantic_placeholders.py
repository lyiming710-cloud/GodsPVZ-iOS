"""Conservative read-only warning/stub census; never auto-repairs a body.

Normal CFG plus every EH/filter entry is considered potentially reachable.
Reachable decompiler markers are investigation leads, not a gameplay bug count.
Valid original constant methods cannot be rejected merely for being constant.
"""
from pathlib import Path
import collections,hashlib,json,re
Q=Path(__file__).resolve().parent;data=(Q/'candidate1.dll').read_bytes();digest=hashlib.sha256(data).hexdigest();assert digest=='e6452513ce3c5a3d9449d8c7287aae39a8458cdc8e4eec09d199769aa1794b4b'
cil=json.loads((Q/'ALL-CIL.json').read_text('utf-8-sig'));typed={r['token']:r['status'] for r in json.loads((Q/'FROZEN-WITH-INTERFACE-FACTS.json').read_bytes())['results']}
pattern=re.compile(r'(?:Invalid instruction:|Not implemented instruction:|Unmanaged memory load|Method not found @|Cpp2IL|NoteDecompilerIssue)',re.I);rows=[];simple=[]
for m in cil['methods']:
    ins=m['instructions'];lookup={r['offset']:r for r in ins};edges={};seeds=[ins[0]['offset']] if ins else [];unmodeled=[]
    for h in m['handlers']:
        for key in ['handlerStart','filterStart']:
            v=h.get(key)
            if v in lookup:seeds.append(v)
    for k,i in enumerate(ins):
        at=i['offset'];op=i['opcode'];stem=op.split('.')[0];next_=ins[k+1:k+2];fall=[r['offset'] for r in next_];operand=i['operand']
        if op in ['ret','throw','rethrow','endfinally','endfilter','jmp']:targets=[]
        elif stem in ['br','leave']:targets=[operand['target']]
        elif stem in ['brtrue','brfalse','beq','bne','bge','bgt','ble','blt']:targets=[operand['target']]+fall
        elif op=='switch':targets=operand['targets']+fall
        else:targets=fall
        if not all(t in lookup for t in targets):unmodeled.append(dict(offset=at,opcode=op,targets=targets))
        edges[at]=[t for t in targets if t in lookup]
    reached=set();queue=seeds[:]
    while queue:
        at=queue.pop()
        if at in reached:continue
        reached.add(at);queue+=edges[at]
    warnings=[dict(offset=i['offset'],text=i['operand'],conservatively_reachable=i['offset'] in reached) for i in ins if i['opcode']=='ldstr' and isinstance(i['operand'],str) and pattern.search(i['operand'])]
    normal=[i for i in ins if i['opcode']!='nop'];candidate=normal
    while len(candidate)>=2 and candidate[0]['opcode']=='ldstr' and candidate[1]['opcode']=='pop' and pattern.search(candidate[0]['operand']):candidate=candidate[2:]
    isconstant=len(candidate)==2 and candidate[-1]['opcode']=='ret' and (candidate[0]['opcode'].startswith('ldc.') or candidate[0]['opcode']=='ldnull')
    if warnings:rows.append(dict(token=m['token'],name=m['name'],frozen_type_status=typed[m['token']],instructions=len(ins),handlers=len(m['handlers']),reachable_markers=sum(w['conservatively_reachable'] for w in warnings),warnings=warnings,graph_unmodeled=unmodeled,scope='CONSERVATIVE_INVESTIGATION_LEAD_NOT_PROVEN_NATIVE_MISMATCH'))
    if isconstant:simple.append(dict(token=m['token'],name=m['name'],ret=m['ret'],frozen_type_status=typed[m['token']],constant_opcode=candidate[0]['opcode'],constant=candidate[0]['operand'],has_decompiler_marker=bool(warnings),native_validation='REQUIRED_UNLESS_ALREADY_IN_A_NATIVE_BACKED_CONSTANT_CHECKPOINT'))
report=dict(scope='READ_ONLY_WHOLE_ASSEMBLY_SEMANTIC_PLACEHOLDER_AND_CONSTANT_BODY_CENSUS_NO_AUTOMATIC_REPAIR',candidate_sha256=digest,methods=2297,methods_with_markers=len(rows),methods_with_conservatively_reachable_markers=sum(r['reachable_markers']>0 for r in rows),reachable_marker_methods_passing_type_gate=sum(r['reachable_markers']>0 and r['frozen_type_status']=='PASS' for r in rows),constant_body_methods=len(simple),constant_bodies_with_markers=sum(r['has_decompiler_marker'] for r in simple),warning_rows=rows,constant_rows=simple,whole_game_acceptance=False)
(Q/'SEMANTIC-PLACEHOLDER-CENSUS.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in report.items() if k not in ['warning_rows','constant_rows']},indent=2));print('CONSTANT BODIES WITH MARKERS',json.dumps([r for r in simple if r['has_decompiler_marker']],indent=2))
