from pathlib import Path
import collections,itertools,json,random
Q=Path(__file__).resolve().parent;O=Q/'runtime-results';O.mkdir(exist_ok=True);cases=[]
def add(kind,**k):
    c=dict(name=f'case-{len(cases)}',kind=kind,mode='none',id=0,level=1,clip_kind=1,hash=42,value='3F800000',other='40000000',increment='00000000',time1='3F800000',time2='3F800000',value_name='A',input_name='A',multi=False);c.update(k);cases.append(c)
rng=random.Random(13025)
for n in list(range(-32,49))+[-2147483648,2147483647,-2147483647,2147483646]+[rng.randrange(-2147483648,2147483648) for _ in range(128)]:add('device',id=n)
levels=list(range(-3,9))+[-2147483648,2147483647,16777215,16777216,16777217,-16777217]
for t,l in itertools.product(list(range(-3,40))+[-2147483648,2147483647],levels):add('board',id=t,level=l)
for _ in range(256):add('board',id=rng.randrange(-5,40),level=rng.randrange(-2147483648,2147483648))
fs=['00000000','80000000','00000001','80000001','00800000','80800000','3EFFFFFF','3F000000','3F000001','3FBFFFFF','3FC00000','3FC00001','401FFFFF','40200000','40200001','BF000000','BFC00000','C0200000','4B7FFFFF','4B800000','4F000000','CF000000','7F7FFFFF','FF7FFFFF','7F800000','FF800000','7FC00001','FFC00001']
for kind,v in itertools.product(['rate-controller','rate-manager'],fs+[f'{rng.getrandbits(32):08X}' for _ in range(64)]):add(kind,value=v)
names=[(None,None),(None,'A'),('A',None),('A','A'),('A','a'),('Å','Å'),('🌱','🌱')]
for v,b,n,m,mode in itertools.product(fs[::2],['00000000','80000000','3FC00000','BF800000','7FC00001','7F800000'],names,[False,True],['none','equality-mutates-value','equality-mutates-multi','equality-replaces-name']):add('stats',value=v,other=b,value_name=n[0],input_name=n[1],multi=m,mode=mode)
for v,k,mode in itertools.product(fs,[0,1,2],['none','replace-clip-on-truth','replace-destroyed-clip-on-truth','mutate-rate-on-truth']):add('clip',value=v,clip_kind=k,mode=mode)
for a,b,mode,h in itertools.product(fs[::2],['00000000','80000000','3F800000','40000000','BF800000','7FC00001','7F800000','FF800000'],['none','time1-replaces-animator','time2-replaces-animator','time2-mutates-hash'],[-1,42,2147483647]):add('damage',time1=a,time2=b,mode=mode,hash=h)
for n,v,inc,mode in itertools.product([-2147483648,-1,0,1,2,3,2147483647],fs,['00000000','80000000','3DCCCCCD','3F000000','3FC00000','BF800000','7FC00001','7F800000','FF800000'],['none','buff-mutates-armor','buff-replaces-manager']):
    idx=fs.index(v);add('tou',id=n,value=v,other=fs[(idx+3)%len(fs)],increment=inc,mode=mode)
for v in fs:add('tou',id=1,value=v,other='00000000',increment='00000000')
assert len(cases)==13167
(O/'CASES.json').write_bytes((json.dumps(cases,indent=2,ensure_ascii=False)+'\n').encode());print(json.dumps(dict(cases=len(cases),counts=dict(collections.Counter(c['kind'] for c in cases)))))
