"""Input-only derivative of the existing license-free full compiler census."""
from pathlib import Path
import ast
from archive_support import sha,js,pack,manifest
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';D=R/'Recovery/Startup-R13-2026-10-25'
parent='e101c701802969bffe370841abc92cd01ec75592097d60b2b9e3629c5c107637';child='e6452513ce3c5a3d9449d8c7287aae39a8458cdc8e4eec09d199769aa1794b4b'
source=R/'scripts/actions/check_startup_r11_compiler.py';before=source.read_bytes();text=before.decode();assert text.count(parent)==1
text=text.replace(parent,child).replace('STARTUP_R11','STARTUP_R13').replace('STARTUP-R11','STARTUP-R13').replace('Startup R11','Startup R13');ast.parse(text)
dest=R/'scripts/actions/check_startup_r13_compiler.py';dest.write_bytes(text.encode())
p=R/'.github/workflows/bulk401-generic-compiler-check.yml';old=p.read_bytes();snapshot=D/'PARENT-R11-COMPILER-WORKFLOW.yml';assert not snapshot.exists();snapshot.write_bytes(old)
yaml=old.decode().replace(parent,child).replace('Startup R11','Startup R13').replace('startup-r11','startup-r13').replace('STARTUP-R11','STARTUP-R13').replace('Startup-R11','Startup-R13').replace('exact R11','exact R13').replace('check_startup_r11_compiler.py','check_startup_r13_compiler.py')
assert parent not in yaml and child in yaml and 'secrets.' not in yaml;p.write_bytes(yaml.encode())
js(D/'COMPILER-DRIVER-DERIVATION.json',dict(scope='INPUT_BINDING_ONLY_TO_UNCHANGED_ALL_GENERATED_C_CPP_COMPILER_CENSUS',candidate_sha256=child,parent_driver_sha256=sha(before),driver_sha256=sha(dest.read_bytes()),parent_workflow_sha256=sha(old),workflow_sha256=sha(p.read_bytes()),controls_and_algorithm_unchanged=True,unity_license_or_ipa=False))
pack(D/'COMPILER-BINDING-SOURCES.zip',[(f.relative_to(R).as_posix(),f.read_bytes()) for f in [dest,source,p,R/'scripts/actions/verify_bulk152_portable.py',R/'scripts/actions/restore_bulk152_checkpoint.py']]+[('prepare_r13_compiler.py',Path(__file__).read_bytes())]);manifest(D);print('Exact R13 compiler-only workflow prepared; no dispatch by this script')
