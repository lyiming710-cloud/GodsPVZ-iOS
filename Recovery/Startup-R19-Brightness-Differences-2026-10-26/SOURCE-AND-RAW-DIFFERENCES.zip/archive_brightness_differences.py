from pathlib import Path
import json
from archive_support import js,pack,manifest
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';Q=W/'r19-brightness-review-2026-10-26';D=R/'Recovery/Startup-R19-Brightness-Differences-2026-10-26';T=R/'Recovery/Startup-R20-Sites104-2026-10-26';H=R/'Recovery/Startup-R19-Batch100-2026-10-25';N=R/'Recovery/Startup-R21-Source-Queue-2026-10-26'
assert not D.exists();D.mkdir();(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text\n*.md -text\n*.zip -text\n')
n=json.loads((Q/'NATIVE-ATTEMPT1.json').read_bytes());a=json.loads((Q/'FULL-CIL-R19.json').read_bytes());b=json.loads((Q/'FULL-CIL-R20.json').read_bytes());assert a['results']==b['results'] and n['records']==2932 and len(n['differences'])==946 and n['differences_by_domain']['FINITE_NORMAL_ENGINE_TIME']==228 and not n['callback_errors'] and n['original_max_leaf_executed_unchanged']
inputs={r['name']:r for r in json.loads((Q/'CASES.json').read_bytes())};examples=[]
for token in ['0x0600030A','0x06000423']:
    d=next(d for d in n['differences'] if d['domain']=='FINITE_NORMAL_ENGINE_TIME' and d['original']['token']==token);examples.append(dict(input=inputs[d['original']['name']],comparison=d))
js(D/'ORDINARY-FINITE-COUNTEREXAMPLES.json',examples)
sites=[]
for rid,field,va,description in [(0x30a,'brightTime','0x18034bf5b','Native qword zero clears brightEffectTime and brightTime; CIL clears only effect time'),(0x423,'brightTime','0x18036b82c','Native qword zero clears body effect time and remaining time'),(0x423,'brightTime_Armor2','0x18036b8ee','Native qword zero clears armor2 effect time and remaining time')]:sites.append(dict(token=f'0x{0x6000000|rid:08X}',native_va=va,kind='MISSING_EXPIRED_REMAINING_TIME_FIELD_ZERO',field=field,description=description,normal_finite_difference_observed=True,constructed=False))
for rid,offset,va in [(0x30a,93,'0x18034bf2c'),(0x423,93,'0x18036b806'),(0x423,338,'0x18036b8c8')]:sites.append(dict(token=f'0x{0x6000000|rid:08X}',native_va=va,kind='FLOAT_UNORDERED_CONTROL_FLOW',cil_offset=offset,proposed='clt -> clt.un in inverted ordered-JAE comparison only',actual_unity_nan_delta_trigger_proven=False,constructed=False))
for rid,field,va in [(0x30a,'brightTime','0x18034bf0f'),(0x423,'brightTime','0x18036b7e4'),(0x423,'brightTime_Armor2','0x18036b8a6')]:sites.append(dict(token=f'0x{0x6000000|rid:08X}',native_va=va,kind='PRE_TIME_GETTER_FLOAT_CAPTURE',field=field,actual_unity_getter_mutation_trigger_proven=False,constructed=False))
assert len(sites)==9;js(D/'NINE-SOURCE-POSITIONS-NOT-APPLIED.json',sites)
js(Q/'R19-AND-R20-BINDING.json',dict(parent_sha256=a['candidate_sha256'],current_sha256=b['candidate_sha256'],all_rows_identical=True,records=2932,new_game_changes=0))
files=[]
for p in sorted(Q.rglob('*')):
    if p.is_file() and not any(x in p.parts for x in ['obj','__pycache__']):files.append(('brightness-review/'+p.relative_to(Q).as_posix(),p.read_bytes()))
for rid in [0x30a,0x423]:
    for suffix in ['.json','.txt']:
        p=W/'startup-r19-batch100/native-source-complete'/f'0x{0x6000000|rid:08X}{suffix}';files.append(('original-source/'+p.name,p.read_bytes()))
files += [('original-source/MAX-HELPER-BOUNDED-LINEAR.json',(W/'startup-r19-batch100/MAX-HELPER-BOUNDED-LINEAR.json').read_bytes()),('frozen-runtime/Rehost.cs',(W/'startup-r5/runtime-common/Rehost.cs').read_bytes()),('frozen-runtime/native_runtime_common.py',(W/'startup-r5/native_runtime_common.py').read_bytes()),(Path(__file__).name,Path(__file__).read_bytes())];pack(D/'SOURCE-AND-RAW-DIFFERENCES.zip',files)
js(D/'PROGRESS.json',dict(status='TWO_EXISTING_R19_METHODS_HAVE_EXPIRY_FIELD_ZERO_MISSING_ORDINARY_FINITE_DIFFERENCES',records=2932,total_differences=946,difference_domains=n['differences_by_domain'],method_difference_counts=n['differences_by_method'],ordinary_finite_differences=228,original_max_executed_unchanged=True,proposed_positions=9,constructed_positions=0,new_game_changes=0,r19_finite_union_unchanged=81,r19_pending_unchanged=19,ipad_black_screen_cause_proven=False,formal_or_product_acceptance=False))
(D/'README.md').write_bytes('''# 两个亮度更新方法：普通到期路径漏清剩余时间

0x0600030A Device.Update_Brightness和0x06000423 Zombie.Update_Brightness的完整既有CIL与完整未改原版调用方共2,932条记录；两个固定R19/R20候选CIL全部结果相同。共946条差异，其中228条为正常有限非负delta、无额外回调副作用的输入；不是只在NaN或人为getter改字段下才出现。

原版到期路径以qword零写同时清brightEffectTime与brightTime，再将相应intensity设为1。当前CIL只清effectTime，留下更新后的负brightTime。Device、Zombie body、Zombie armor2三处均缺该剩余时间清零；普通到期样本字段快照可独立观察。正常样本的SetBrightness数值未据此泛化为全部视觉差异，也没有证明它导致当前iPad主菜单黑屏。

其余558条来自受控Time getter写回字段、144条来自受控亮度回调字段、16条来自扩展NaN/Infinity delta。分别保留标签，未把真实Time getter副作用或NaN delta当成已证事实。原版还在Time getter前捕获三个剩余时间值；三处inverted clt与原版ordered JAE的unordered语义不同。共九个源位置拟恢复，尚未改游戏候选。

原版Math.Max(0x180CA5FC0)整段机器码真实执行且保持原字节，未用Python/C#猜写它。CLR侧执行真实Math.Max；观察范围内未以它的替代掩盖差异。显式模型仅控制Time与最终SetBrightness边界。此前fixture在首轮原生对照前调整观察schema，只保留Device实际字段并将armor字段限定Zombie，初始CIL/source版本也保留。

这两个方法继续留在R19的19个待验收中，不加入已通过的81方法/31,812正常记录。四个已知差异R19方法、另一个百方法外Buff捕获顺序方法以及后续队列分开保存。当前发布的R20测试IPA仍保持原游戏候选d887b370；这些后续提案等待新批次累计超过100位置后集中检测。
'''.encode());manifest(D)
pending=json.loads((H/'CURRENT-PENDING-RUNTIME-PROFILES.json').read_bytes());assert pending['methods']==19
for r in pending['rows']:
    if r['token'] in n['differences_by_method']:r.update(runtime_profile_status='ORDINARY_FINITE_DIFFERENCES_FOUND_NOT_ACCEPTED',difference_review='../'+D.name,native_difference_records=n['differences_by_method'][r['token']],source_fix_pending=True)
js(H/'CURRENT-PENDING-RUNTIME-PROFILES.json',pending);s=json.loads((H/'PROGRESS.json').read_bytes());s.update(brightness_review_methods=2,brightness_normal_finite_differences=228,brightness_all_domain_differences=946,known_pending_methods_with_observed_differences=4);js(H/'PROGRESS.json',s);manifest(H)
queue=json.loads((T/'CURRENT-WORK-QUEUE.json').read_bytes())
for row in queue['rows']:
    if row['token'] in n['differences_by_method']:row.update(current_state='EXISTING_R19_BODY_ORDINARY_EXPIRY_FIELD_STATE_DIFFERENCES',current_required_action='Restore missing remaining-time zero and source-backed float comparison/capture positions in next batch; keep pending',brightness_review='../'+D.name)
js(T/'CURRENT-WORK-QUEUE.json',queue);manifest(T)
q=json.loads((N/'SOURCE-QUEUE.json').read_bytes());assert q['proposed_positions']==7
q['rows'] += [dict(kind=s['kind'],token=s['token'],native_va=s['native_va'],evidence='../'+D.name,spec=s,constructed=False) for s in sites];assert len({(r['token'],r['native_va']) for r in q['rows']})==16;q.update(proposed_positions=16,methoddefs=5,constructed_positions=0);js(N/'SOURCE-QUEUE.json',q)
p=N/'README.md';s=p.read_text('utf-8');s+='\n\n新增亮度更新九个源位置后，当前合计16个提案、5个方法、0个构造位置。三处遗漏清brightTime有228条普通有限输入差异；另六处比较/预捕获的触发范围单独记录。完整证据在Startup-R19-Brightness-Differences-2026-10-26。\n';p.write_bytes(s.encode());manifest(N)
print(json.dumps(dict(archived=D.name,ordinary_finite_differences=228,total_differences=946,proposed_positions_total=16,constructed=0)))
