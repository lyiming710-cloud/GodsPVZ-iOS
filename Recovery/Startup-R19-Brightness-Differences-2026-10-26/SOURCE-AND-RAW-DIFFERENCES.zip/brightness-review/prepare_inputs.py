from pathlib import Path
import itertools,json,struct
Q=Path(__file__).resolve().parent;bits=lambda x:struct.pack('>f',x).hex().upper();rows=[]
for rid,time,effect,intensity,delta,selected,armor,mode in itertools.product([0x30a,0x423],[0,.1,1],[0,.5,1],[0,1,3],[0,.125,1],range(2),[(0,1,2),(.1,.5,2),(1,.5,4)],range(3)):
 rows.append(dict(name=f'l{len(rows):05}',token=f'0x{0x6000000|rid:08X}',time=bits(time),effect=bits(effect),intensity=bits(intensity),delta=bits(delta),selected=selected,armor_time=bits(armor[0]),armor_effect=bits(armor[1]),armor_intensity=bits(armor[2]),mode=mode,domain='FINITE_NORMAL_ENGINE_TIME' if mode==0 else 'CONTROLLED_TIME_GETTER_MUTATION_NO_REAL_TRIGGER_PROOF' if mode==1 else 'CONTROLLED_BRIGHTNESS_CALLBACK_FIELDS'))
for rid,time,armor_time,delta in itertools.product([0x30a,0x423],['7F800000','3F800000'],['7F800000','3F800000'],['7F800000','7FC07654']):rows.append(dict(name=f'l{len(rows):05}',token=f'0x{0x6000000|rid:08X}',time=time,effect=bits(1),intensity=bits(3),delta=delta,selected=0,armor_time=armor_time,armor_effect=bits(1),armor_intensity=bits(2),mode=0,domain='EXPANDED_DELTA_NO_REAL_UNITY_TRIGGER_PROOF'))
(Q/'CASES.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode());print(len(rows))
