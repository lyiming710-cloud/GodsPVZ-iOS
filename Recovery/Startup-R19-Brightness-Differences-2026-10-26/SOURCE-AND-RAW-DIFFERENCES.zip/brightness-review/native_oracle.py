"""Two existing full brightness callers, executing the real original Max leaf."""
from pathlib import Path
import collections,ctypes as C,functools,hashlib,json,struct,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
im=NativeImage();state={};ids=[0x30a,0x423];cfgs={rid:json.loads((W/'startup-r19-batch100/native-source-complete'/f'0x{0x6000000|rid:08X}.json').read_bytes()) for rid in ids};fields=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_bytes())
@functools.lru_cache(None)
def off(owner,name):
    rows=[r for r in fields if r['type']==owner and r['namespace']=='' and r['name']==name];assert len(rows)==1,(owner,name);return rows[0]['offset']
def bits(v):return struct.pack('<f',v)[::-1].hex().upper()
def f(key):return struct.unpack('<f',bytes.fromhex(state['q'][key])[::-1])[0]
def field(name):return state['self']+off(state['owner'],name)
def text(p):return C.string_at(p+0x14,get32(p+0x10)*2).decode('utf-16-le')
def string(s):
    b=s.encode('utf-16-le');p=im.alloc(24+len(b));put32(p+0x10,len(b)//2);C.memmove(p+0x14,b,len(b));return p
def delta(m):
    assert not m;state['trace'].append('Delta:'+state['q']['delta'])
    if state['q']['mode']==1:
        putf(field('brightTime'),3)
        if state['owner']=='Zombie':putf(field('brightTime_Armor2'),4)
    return f('delta')
def setter(p,value,where,m):
    assert p==state['self'] and not m;state['trace'].append('Set:'+where+':'+bits(value))
    if state['q']['mode']==2 and where=='body':
        putf(field('brightTime_Armor2'),3);putf(field('brightEffectTime_Armor2'),2);putf(field('brightIntensity_Armor2'),4);C.c_ubyte.from_address(field('selected_Bright')).value=1
def device(p,value,m):setter(p,value,'device',m)
def zombie(p,value,where,m):setter(p,value,text(where),m)
try:
    meta=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/global-metadata.dat').read_bytes();assert hashlib.sha256(meta).hexdigest()=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9';so,sn,do,dn=struct.unpack_from('<4I',meta,8);dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True;slots=set();literals=[]
    for cfg in cfgs.values():
        for row in cfg['instructions']:
            i=next(dis.disasm(bytes.fromhex(row['bytes']),int(row['va'],16)))
            if i.mnemonic not in ['mov','lea']:continue
            for o in i.operands:
                if o.type!=X86_OP_MEM or o.mem.base!=X86_REG_RIP:continue
                at=i.address+i.size+o.mem.disp;raw=im.pe.get_data(at-im.base,8)
                if len(raw)!=8:continue
                code=int.from_bytes(raw,'little')
                if code>0xffffffff or code>>29 not in range(1,8) or at in slots:continue
                slots.add(at);kind,index=code>>29,(code&0x1fffffff)>>1
                if kind==5:
                    size,pos=struct.unpack_from('<II',meta,so+8*index);lit=meta[do+pos:do+pos+size].decode('utf-8');put64(at,string(lit));literals.append(lit)
                else:im.class_slot(at)
    assert set(literals)=={'body','armor2'}
    def init(p):assert p in slots
    im.hook(0x18024fef0,None,[P],init);im.hook(0x1802501e0,None,[P],lambda p:None);im.hook(0x18132c2f0,F,[P],delta);im.hook(0x18034a0b0,None,[P,F,P],device);im.hook(0x180367040,None,[P,F,P,P],zombie)
    for rid,cfg in cfgs.items():im.verify_caller(rid,int(cfg['entry'],16),cfg)
    pure=json.loads((W/'startup-r19-batch100/MAX-HELPER-BOUNDED-LINEAR.json').read_bytes());assert pure['entry']=='0x180ca5fc0'
    for i in pure['instructions']:assert C.string_at(int(i['va'],16),len(bytes.fromhex(i['bytes'])))==bytes.fromhex(i['bytes'])
    rows=[];cases=json.loads((Q/'CASES.json').read_bytes())
    for q in cases:
        rid=int(q['token'],16)&0xffffff;state.clear();state.update(q=q,owner='Device' if rid==0x30a else 'Zombie',self=im.alloc(1024),trace=[])
        for name,key in [('brightTime','time'),('brightEffectTime','effect'),('brightIntensity','intensity')]+([] if rid==0x30a else [('brightTime_Armor2','armor_time'),('brightEffectTime_Armor2','armor_effect'),('brightIntensity_Armor2','armor_intensity')]):C.c_uint32.from_address(field(name)).value=int(q[key],16)
        C.c_ubyte.from_address(field('selected_Bright')).value=q['selected'];C.CFUNCTYPE(None,P,P)(int(cfgs[rid]['entry'],16))(state['self'],None);assert not im.errors,(q,im.errors)
        snap={key:f'{C.c_uint32.from_address(field(name)).value:08X}' for name,key in [('brightTime','time'),('brightEffectTime','effect'),('brightIntensity','intensity')]+([] if rid==0x30a else [('brightTime_Armor2','armor_time'),('brightEffectTime_Armor2','armor_effect'),('brightIntensity_Armor2','armor_intensity')])};snap['selected']=bool(C.c_ubyte.from_address(field('selected_Bright')).value)
        rows.append(dict(name=q['name'],token=q['token'],error=None,trace=list(state['trace']),state=snap))
    actual=json.loads(Path(sys.argv[1]).read_bytes());digest=hashlib.sha256((W/'startup-r20-sites100/authored3.dll').read_bytes()).hexdigest();assert actual['candidate_sha256']==digest;found={r['name']:r for r in actual['results']};domains={q['name']:q['domain'] for q in cases};assert set(found)==set(domains);diff=[dict(domain=domains[r['name']],original=r,actual=found[r['name']]) for r in rows if r!=found[r['name']]]
    report=dict(scope='TWO_EXISTING_FULL_BRIGHTNESS_CALLER_DIFFERENCE_REVIEW',candidate_sha256=digest,original_pc_sha256=hashlib.sha256(im.raw).hexdigest(),records=len(rows),results=rows,differences=diff,differences_by_domain=dict(collections.Counter(r['domain'] for r in diff)),differences_by_method=dict(collections.Counter(r['original']['token'] for r in diff)),callback_errors=im.errors,original_max_leaf_executed_unchanged=True,original_branches_and_stores_unchanged=True,new_game_changes=0,real_unity_nan_delta_or_time_getter_mutation_trigger_proven=False,formal_or_product_acceptance=False)
    Path(sys.argv[2]).write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in report.items() if k not in ['results','differences']}));print('differences',len(diff));raise SystemExit(2 if diff else 0)
finally:im.close()
