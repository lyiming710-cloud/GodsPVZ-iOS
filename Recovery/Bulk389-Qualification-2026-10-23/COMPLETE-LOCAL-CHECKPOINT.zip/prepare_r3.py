from audit_candidate import *
import shutil
src=Q/'revision-r2-final/source';D=Q/'revision-r3';D.mkdir(exist_ok=False);S=D/'source';S.mkdir()
for p in src.iterdir():
 if p.is_file():shutil.copy2(p,S/p.name)
def replace(file,old,new,count=1):
 p=S/file;t=p.read_text('utf-8');req(t.count(old)==count,(file,old,t.count(old)));p.write_text(t.replace(old,new),'utf-8')
replace('N119.TextEventBodies.cs','.Virtual(0x0A0002EA);','.Virtual(0x0A000403);')
replace('N119.UiBodies.cs','b.Load(2).Load(3).Branch(0x3E,"rangeOk");b.Load(2).Load(3).Call(0x2B000082);b.Label("rangeOk");\n        b.Arg(1).Load(2).Branch(0x3F,"min");b.Arg(1).Load(3).Branch(0x3D,"clamped");b.Arg(1).Store(3).Branch(0x38,"clamped");b.Label("min").Load(2).Store(3);b.Label("clamped");','b.Arg(1).Load(2).Load(3).Call(0x0A000526).Store(3);')
p=S/'N119.SkillBodies.cs';t=p.read_text('utf-8');a=t.index('        b.Load(4).Field(0x0400054C).Store(6);');z=t.index('        b.Float(.9f).Float(1.1f)',a)
t=t[:a]+'        // Original native inlines the exact Collision_Wall path here.\n        b.Load(4).Virtual(0x060003E9);\n'+t[z:]
# Restore the public entry point's own damaged unsigned range comparisons.
body='''
    private static byte[] N121_CollisionWallBody()
    {
        var b=new IL();
        b.Arg(0).Field(0x0400054C).Integer(9).Op(0x59).Integer(2).Branch(0x43,"explode");
        b.Arg(0).Field(0x0400054C).Integer(15).Branch(0x3B,"explode");
        b.Arg(0).Field(0x0400054C).Integer(26).Op(0x59).Integer(6).Branch(0x42,"collision");
        b.Label("explode").Arg(0).Field(0x0400054E).Virtual(0x0600010C).Op(0x26);
        b.Label("collision").Arg(0).Call(0x060003EB);b.Arg(0).Virtual(0x060003EC).Op(0x2A);
        return b.Finish();
    }
'''
req(t.endswith('}\n'),'partial class ending');p.write_text(t[:-2]+body+'}\n','utf-8')
dp=dnfile.dnPE(data=parent);m=dp.net.mdtables.MethodDef.rows[0x3e9-1];at=dp.get_offset_from_rva(m.Rva);span=h.parse_raw_method_body_span(parent,at);code=parent[at+span[1]:at+span[1]+span[2]];local=dp.net.mdtables.StandAloneSig.rows[(span[4]&0xffffff)-1].Signature.value.hex()
pin=f'        new(0x060003E9,"Projectile","Collision_Wall","{m.Signature.value.hex()}",{len(code)},{span[3]},0x{span[4]:08X},"{local}","{sha(code)}"),\n'
replace('Program.cs','    ];\n\n    private static void Require',pin+'    ];\n\n    private static void Require')
replace('Program.cs','(Token:0x060003F9, Code:N120_SetSortingGroup(), Max:4, Locals:0)','(Token:0x060003F9, Code:N120_SetSortingGroup(), Max:4, Locals:0),\n            (Token:0x060003E9, Code:N121_CollisionWallBody(), Max:3, Locals:0)')
for old,new in [('Pins.Length==388','Pins.Length==389'),('plans.Length==388','plans.Length==389'),('Distinct().Count()==388','Distinct().Count()==389'),('Exact 388-method','Exact 389-method'),('appended_memberref_count = 217','appended_memberref_count = 218')]:replace('Program.cs',old,new)
replace('AppendNative119Metadata.cs','TableIndex.MemberRef)==1317','TableIndex.MemberRef)==1318')
member=dict(name='N121_IntClamp',token=0x0a000526,class_code=(37<<3)|1,owner_pin='System.Math',template=189,template_name='Clamp',signature='000308080808',new_name=None)
replace('Native119MetadataData.cs','    private static readonly Native119Local[] N119NewLocals', '    private static readonly Native119Local[] N119NewLocals')
p=S/'Native119MetadataData.cs';t=p.read_text('utf-8');marker='    ];\n    private static readonly Native119Local[]';req(t.count(marker)==1,'member array end');t=t.replace(marker,'        new(0x0A000526,297,"System.Math",189,"Clamp","00030c0c0c0c","000308080808",null),\n'+marker);p.write_text(t,'utf-8')
meta=json.loads((S/'METADATA-ADDITIONS.json').read_text('utf-8'));meta['member_definitions'].append(member);meta['expected_blob_heap_bytes']+=7;meta['constants'].append(dict(name='N121_IntClamp',token=member['token']));(S/'METADATA-ADDITIONS.json').write_text(json.dumps(meta,indent=2)+'\n','utf-8')
plan=json.loads((S/'IMPLEMENTATION-PLAN.json').read_text('utf-8'));plan['targets'].append(dict(token='0x060003E9',name='Projectile::Collision_Wall',signature=m.Signature.value.hex(),old_code_size=len(code),old_code_sha256=sha(code),old_max_stack=span[3],old_local_sig_token=f'0x{span[4]:08X}',old_local_sig_blob=local,new_declared_max_stack=3,local_constant='0',emission_method='N121_CollisionWallBody()',explicit_companion=True,source_batch='native121-public-wrapper-2026-10-23',original_native=dict(start='0x18037b090',end='0x18037b0e4'),reason='Restore original unsigned interval tests; permits legal public wrapper use by SkillManager.Update10 without cross-type private call'))
plan.update(state='R3_UNTESTED_SOURCE_389_WITH_EXPLICIT_COMPANION',method_body_targets=389,unchanged_other_method_bodies=1928,memberref_count_after=1318);plan['target_tokens'].append('0x060003E9');plan['companion_tokens'].append('0x060003E9');(S/'IMPLEMENTATION-PLAN.json').write_text(json.dumps(plan,indent=2,ensure_ascii=False)+'\n','utf-8')
(D/'candidates').mkdir();(D/'logs').mkdir();(D/'CHANGES.json').write_text(json.dumps(dict(scope=389,non_targets=1928,metadata_visibility_changes=0,new_member=member,additional_companion='0x060003E9',original_candidate_sha256=sha((Q/'candidates/candidate1.dll').read_bytes()),r2_candidate_sha256=sha((Q/'revision-r2-final/candidates/candidate1.dll').read_bytes()),native_semantics='UNPROVEN',frozen_validators_modified=False),indent=2)+'\n','utf-8');print('R3_WRITTEN targets=389 blob='+str(meta['expected_blob_heap_bytes']))
