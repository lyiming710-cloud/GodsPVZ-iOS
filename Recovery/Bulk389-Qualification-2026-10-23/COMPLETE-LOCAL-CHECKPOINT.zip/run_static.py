from pathlib import Path
import subprocess,json,hashlib,sys,importlib.util,collections,copy
BASE=Path(__file__).resolve().parent;R=BASE.parents[1];Q=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else BASE;sys.dont_write_bytecode=True
dot=R/'.local/dotnet10/dotnet.exe';V=R/'audit/bulk350-root-verification-2026-10-22';checker=V/'reviewed-tools/verify_types_reviewed.py'
plan=json.loads((Q/'source/IMPLEMENTATION-PLAN.json').read_text('utf-8'));tokens=','.join(x['token'] for x in plan['targets']);candidate=Q/'candidates/candidate1.dll'
def recorded(name,args):
 paths=[Q/'logs'/(name+'.argv.json'),Q/'logs'/(name+'.stdout'),Q/'logs'/(name+'.stderr'),Q/'logs'/(name+'.result.json')]
 if any(p.exists() for p in paths):raise FileExistsError(name)
 argv=list(map(str,args));paths[0].write_text(json.dumps(argv,indent=2)+'\n','utf-8');res=subprocess.run(argv,cwd=R,capture_output=True,timeout=45);paths[1].write_bytes(res.stdout);paths[2].write_bytes(res.stderr);paths[3].write_text(json.dumps(dict(exit=res.returncode,stdout_sha256=hashlib.sha256(res.stdout).hexdigest(),stderr_sha256=hashlib.sha256(res.stderr).hexdigest()))+'\n','utf-8');print(name,'exit',res.returncode);return res
support=V/'authentic-support';exporter=V/'reviewed-tools/exporter-bin/CilExporter.dll'
res=recorded('static-export',[dot,exporter,candidate,Q/'targets-reviewed.json',support,tokens]);res.check_returncode()
d=json.loads((Q/'targets-reviewed.json').read_text('utf-8'));spec=importlib.util.spec_from_file_location('reviewed',checker);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);results=[]
for a in d['methods']:
 try:result=m.verify(a,d['types'])
 except Exception as e:result=dict(token=a['token'],method=a['name'],status='FAIL' if isinstance(e,m.InvalidIL) else 'VERIFIER_ERROR',error=str(e))
 results.append(result)
report=dict(scope='STATIC_FLOW_ONLY_NOT_BEHAVIOR_OR_FULL_ECMA',candidate_sha256=hashlib.sha256(candidate.read_bytes()).hexdigest(),checker_sha256=hashlib.sha256(checker.read_bytes()).hexdigest(),exporter_sha256=hashlib.sha256(exporter.read_bytes()).hexdigest(),counts=dict(collections.Counter(x['status'] for x in results)),results=results)
(Q/'STATIC-TYPES-FIRST.json').write_text(json.dumps(report,indent=2)+'\n','utf-8');print(json.dumps(report['counts']));print(json.dumps([x for x in results if x['status']!='PASS'],ensure_ascii=True))
res=recorded('static-member',[dot,V/'reviewed-tools/member-bin/MemberAccess.dll',candidate,support,Q/'candidates/construction1.json',Q/'MEMBER-ACCESS-FIRST.json']);res.check_returncode()
