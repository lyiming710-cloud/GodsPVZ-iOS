from audit_candidate import *
import pefile
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from dncil.cil.body import CilMethodBody
from dncil.cil.body.reader import CilMethodBodyReaderBytes
out=Q/'helper-evidence';out.mkdir(exist_ok=False)
inputs=R/'audit/offline-test-handoff-2026-10-14/payload/inputs';ga=(inputs/'original-pc/GameAssembly.dll').read_bytes();req(sha(ga)=='9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d','original GA')
native=pefile.PE(data=ga);maps=json.loads((inputs/'maps/native-method-map.json').read_text('utf-8-sig'));byva={int(x['va'],16):x['type']+'::'+x['name'] for x in maps};vas=sorted(set(byva));managed=dnfile.dnPE(data=parent)
for token in [0x060003B9,0x060003E5,0x060003EB]:
 entry=next(x for x in maps if int(x['token'],16)==token and x['image']=='Assembly-CSharp.dll');start=int(entry['va'],16);end=next(x for x in vas if x>start);code=native.get_data(start-native.OPTIONAL_HEADER.ImageBase,end-start)
 text=['# '+entry['type']+'::'+entry['name']+' '+hex(start)+' '+sha(code)]
 for i in Cs(CS_ARCH_X86,CS_MODE_64).disasm(code,start):text.append(f'{i.address:016X} {i.mnemonic:10} {i.op_str} '+(byva.get(int(i.op_str,16),'') if i.mnemonic in ('call','jmp') and i.op_str.startswith('0x') else ''))
 (out/f'{token:08x}-native.asm').write_text('\n'.join(text)+'\n','utf-8')
 row=managed.net.mdtables.MethodDef.rows[(token&0xffffff)-1];body=CilMethodBody(CilMethodBodyReaderBytes(managed.get_data(row.Rva,32768)));(out/f'{token:08x}-managed.txt').write_text('\n'.join(f'{i.offset-body.header_size:04X} {i.opcode} {i.operand}' for i in body.instructions)+'\n','utf-8')
print('READ_ONLY_HELPERS_SAVED 3')
