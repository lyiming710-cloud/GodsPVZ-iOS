from audit_candidate import *
r6=(R/'audit/bulk350-root-verification-2026-10-22/r6-candidate.dll').read_bytes();req(sha(r6)=='ef95567ce714146b2f7aed1a92e98798023090bb47757f6c5b377f9ce6d9c0f4','exact R6 comparison input')
old=dnfile.dnPE(data=r6);b=(Q/'candidates/candidate1.dll').read_bytes();new=dnfile.dnPE(data=b);records=[]
p=json.loads((R/'audit/bulk350-root-verification-2026-10-22/frozen-source/IMPLEMENTATION-PLAN.json').read_text('utf-8'))
for target in p['targets']:
 token=int(target['token'],16);rid=(token&0xffffff)-1;ao=old.get_offset_from_rva(old.net.mdtables.MethodDef.rows[rid].Rva);bo=new.get_offset_from_rva(new.net.mdtables.MethodDef.rows[rid].Rva);al=h.parse_raw_method_body_span(r6,ao)[0];bl=h.parse_raw_method_body_span(b,bo)[0];req(r6[ao:ao+al]==b[bo:bo+bl],'inherited body changed '+hex(token));records.append(dict(token=hex(token),raw_body_sha256=sha(r6[ao:ao+al])))
req(len(records)==350,'350 references');report=dict(scope='EXACT_RAW_BODY_REUSE_ONLY',candidate_sha256=sha(b),r6_sha256=sha(r6),inherited_350_bodies_identical=True,methods=records,old_compile_failures_not_reclassified=True,behavior_proven=False)
(Q/'R6-BODY-COMPARISON.json').write_text(json.dumps(report,indent=2)+'\n','utf-8');print('R6_RAW_BODY_REUSE_PASS 350')
