from pathlib import Path
import json,hashlib,shutil,zipfile,subprocess
Q=Path(__file__).resolve().parent;R=Q.parents[1];repo=R/'audit/repo-native113';D=repo/'Recovery/Bulk389-Qualification-2026-10-23'
D.mkdir(exist_ok=False);final=Q/'revision-r3'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(path,obj):path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n','utf-8')
for p in final.glob('*.json'):shutil.copy2(p,D/p.name)
for name in ['WIDTH-BOUNDARY-RESULT.json','INPUT-AUTHENTICATION.json','EMITTER-LITERAL-CHECK.json']:shutil.copy2(Q/name,D/name)
(D/'source').mkdir()
for p in (final/'source').iterdir():
 if p.is_file():shutil.copy2(p,D/'source'/p.name)
# This package preserves failed attempts, source revisions, exact binaries and full logs.
package=D/'COMPLETE-LOCAL-CHECKPOINT.zip';entries=[]
with zipfile.ZipFile(package,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(Q.rglob('*')):
  if not p.is_file() or any(x in ('obj','__pycache__') for x in p.relative_to(Q).parts):continue
  rel=p.relative_to(Q).as_posix();z.write(p,rel);entries.append(dict(path=rel,bytes=p.stat().st_size,sha256=sha(p)))
dump(D/'CHECKPOINT-CONTENTS.json',dict(archive=package.name,bytes=package.stat().st_size,sha256=sha(package),entries=entries))
with zipfile.ZipFile(D/'BULK389-R3-CANDIDATE.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:z.write(final/'candidates/candidate1.dll','BULK389-R3-CANDIDATE.dll')
dump(D/'CURRENT-RESULT.json',dict(state='SCOPED_STATIC_INTEGRATION_PASS_NOT_FORMAL_GAME_QUALIFICATION',candidate_sha256=sha(final/'candidates/candidate1.dll'),candidate_bytes=(final/'candidates/candidate1.dll').stat().st_size,patcher_sha256=sha(final/'source/bin/Release/net10.0/Bulk388.dll'),target_methods=389,explicit_new_companion='0x060003E9 Projectile::Collision_Wall',unchanged_non_target_methods=1928,preexisting_numeric_columns_preserved=37512,finally_regions=201,blob_heap_bytes=66513,deterministic_twice=True,scoped_static_types_pass=389,member_access_rejected=0,member_access_unresolved=0,inherited_350_raw_bodies_identical_to_r6=True,width_boundary_cases=32,width_input_rejections=7,width_independent_mutants_detected=8,static_model_controls_detected=11,actual_private_access_mutant_detected=True,isolation_mutants_detected=8,construction_rejection_controls=2,controlled_actual_native_vs_actual_cil=dict(method='0x060003E9',normal_path_cases=184,signed_range_mutant_divergences=100,omitted_audio_mutant_divergences=184,null_exception_paths='NOT_EXECUTED',external_callbacks='CONTROLLED_UNPROVEN'),historical_compiler=dict(run_id=39790796339,date='2026-10-22',unique_error_methods=38,diagnostics=1616,failed_game_tus=14,total_game_tus=16,new_candidate_full_cpp_recounted=False),formal_native_qualification='NOT_PROMOTED',unity='NOT_RUN',xcode='NOT_RUN',ipa=None))
# Verify archive bytes before publishing; do not rely on zip integrity alone.
with zipfile.ZipFile(package) as z:
 for e in entries:
  b=z.read(e['path']);assert len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256'],e['path']
(D/'.gitattributes').write_text('** -text -whitespace\n','ascii')
print(json.dumps(dict(directory=str(D),complete_archive_bytes=package.stat().st_size,entries=len(entries),candidate_zip_bytes=(D/'BULK389-R3-CANDIDATE.zip').stat().st_size)))
