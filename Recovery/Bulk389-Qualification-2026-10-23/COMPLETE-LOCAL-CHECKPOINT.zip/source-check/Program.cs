using System.Reflection;
using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Reflection.PortableExecutable;
using System.Security.Cryptography;
using System.Text.Json;
using System.Buffers.Binary;
static string Sha(byte[] b)=>Convert.ToHexString(SHA256.HashData(b)).ToLowerInvariant();
if(args.Length!=5)throw new ArgumentException("patcher plan candidate Native93 fresh-report");
var asm=Assembly.LoadFrom(Path.GetFullPath(args[0]));var program=asm.GetType("Program",true)!;
using var doc=JsonDocument.Parse(File.ReadAllText(args[1]));byte[] bytes=File.ReadAllBytes(args[2]);
using var pe=new PEReader(new MemoryStream(bytes));var md=pe.GetMetadataReader();var rows=new List<object>();
foreach(var target in doc.RootElement.GetProperty("targets").EnumerateArray())
{
 string expr=target.GetProperty("emission_method").GetString()!;int par=expr.IndexOf('(');string content=expr[(par+1)..^1];
 var method=program.GetMethod(expr[..par],BindingFlags.Static|BindingFlags.NonPublic)!;
 object?[] parameters=method.GetParameters().Select(p=>p.HasDefaultValue?p.DefaultValue:null).ToArray();
 if(content.Length!=0){if(parameters.Length!=1)throw new Exception("Unsupported source invocation");parameters[0]=bool.Parse(content);}
 byte[] emitted=(byte[])method.Invoke(null,parameters)!;int token=Convert.ToInt32(target.GetProperty("token").GetString(),16);
 byte[] actual=pe.GetMethodBody(md.GetMethodDefinition(MetadataTokens.MethodDefinitionHandle(token&0xffffff)).RelativeVirtualAddress).GetILBytes()!;
 if(!actual.SequenceEqual(emitted))throw new Exception("Source binding mismatch "+expr);
 rows.Add(new{token=$"0x{token:X8}",emitter=expr,cil_bytes=actual.Length,cil_sha256=Sha(actual)});
}
// Test the unchanged first-stage guard with a large but still short-index input heap.
byte[] oversized=File.ReadAllBytes(args[3]);using(var pp=new PEReader(new MemoryStream(oversized)))
{
 var h=pp.PEHeaders;var original=pp.GetMetadataReader();int at=h.SectionHeaders.Single(s=>h.CorHeader!.MetadataDirectory.RelativeVirtualAddress>=s.VirtualAddress&&h.CorHeader.MetadataDirectory.RelativeVirtualAddress<s.VirtualAddress+s.SizeOfRawData).PointerToRawData;
 var sec=h.SectionHeaders.Single(s=>h.CorHeader!.MetadataDirectory.RelativeVirtualAddress>=s.VirtualAddress&&h.CorHeader.MetadataDirectory.RelativeVirtualAddress<s.VirtualAddress+s.SizeOfRawData);
 at+=h.CorHeader!.MetadataDirectory.RelativeVirtualAddress-sec.VirtualAddress;
 int version=BitConverter.ToInt32(oversized,at+12);int p=(at+16+version+3)&~3;int count=BitConverter.ToUInt16(oversized,p+2);p+=4;
 for(int i=0;i<count;i++)
 {
  int end=Array.IndexOf(oversized,(byte)0,p+8);string name=System.Text.Encoding.ASCII.GetString(oversized,p+8,end-p-8);
  if(name=="#Blob")
  {
   int old=BitConverter.ToInt32(oversized,p+4);if(old!=60617)throw new Exception("Legacy input heap binding");
   BinaryPrimitives.WriteInt32LittleEndian(oversized.AsSpan(p+4),61083);
   BinaryPrimitives.WriteInt32LittleEndian(oversized.AsSpan(h.CorHeaderStartOffset+12),h.CorHeader.MetadataDirectory.Size+61083-old);
  }
  p=(end+4)&~3;
 }
}
bool legacyRejected=false;string reason="";using(var pp=new PEReader(new MemoryStream(oversized)))
{
 if(pp.GetMetadataReader().GetHeapSize(HeapIndex.Blob)!=61083)throw new Exception("Mutated heap was not materialized");
 try{program.GetMethod("AppendMetadata",BindingFlags.Static|BindingFlags.NonPublic)!.Invoke(null,new object?[]{oversized,pp,null});}
 catch(TargetInvocationException ex){reason=ex.InnerException!.Message;legacyRejected=reason=="No heap index widening";}
}
if(!legacyRejected)throw new Exception("Legacy no-widening rejection failed: "+reason);
var result=new{state="PASS_SCOPED_SOURCE_EMITTER_BINDING",candidate_sha256=Sha(bytes),patcher_sha256=Sha(File.ReadAllBytes(args[0])),methods=rows,source_emitter_matches=rows.Count,legacy_no_widening_guard_rejected=true,legacy_reason=reason,game_cil_executed=false,native_behavior_proven=false};
if(File.Exists(args[4]))throw new IOException("Fresh report only");File.WriteAllText(args[4],JsonSerializer.Serialize(result,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine($"SOURCE_BINDING_PASS methods={rows.Count} legacy_guard=True");
