# Projectile::Collision_Destroy 0x18037aff0 ae3278f156fa11cfdca08066969b5ff771055c24d7b4a88e81e67d87508ed4cd
000000018037AFF0 mov        eax, dword ptr [rcx + 0x24] 
000000018037AFF3 cmp        eax, 0x13 
000000018037AFF6 je         0x18037affd 
000000018037AFF8 cmp        eax, 0x17 
000000018037AFFB jne        0x18037b007 
000000018037AFFD cmp        edx, 1 
000000018037B000 jbe        0x18037b007 
000000018037B002 cmp        edx, 3 
000000018037B005 jne        0x18037b00e 
000000018037B007 xor        edx, edx 
000000018037B009 jmp        0x18037b200 Projectile::DestroyProjectile
000000018037B00E ret         
000000018037B00F int3        
