000000018037B090 push       rbx
000000018037B092 sub        rsp, 0x20
000000018037B096 mov        rbx, rcx
000000018037B099 mov        ecx, dword ptr [rcx + 0x24]
000000018037B09C lea        eax, [rcx - 9]
000000018037B09F cmp        eax, 2
000000018037B0A2 jbe        0x18037b0b1
000000018037B0A4 cmp        ecx, 0xf
000000018037B0A7 je         0x18037b0b1
000000018037B0A9 lea        eax, [rcx - 0x1a]
000000018037B0AC cmp        eax, 6
000000018037B0AF ja         0x18037b0c1
000000018037B0B1 mov        rcx, qword ptr [rbx + 0x30]
000000018037B0B5 test       rcx, rcx
000000018037B0B8 je         0x18037b0de
000000018037B0BA xor        edx, edx
000000018037B0BC call       0x180311890
000000018037B0C1 xor        edx, edx
000000018037B0C3 mov        rcx, rbx
000000018037B0C6 call       0x18037a410
000000018037B0CB mov        eax, dword ptr [rbx + 0x24]
000000018037B0CE xor        edx, edx
000000018037B0D0 mov        rcx, rbx
000000018037B0D3 call       0x18037b200
000000018037B0D8 add        rsp, 0x20
000000018037B0DC pop        rbx
000000018037B0DD ret        
000000018037B0DE call       0x180250150
000000018037B0E3 int3       
000000018037B0E4 int3       
000000018037B0E5 int3       
000000018037B0E6 int3       
000000018037B0E7 int3       
000000018037B0E8 int3       
000000018037B0E9 int3       
000000018037B0EA int3       
000000018037B0EB int3       
000000018037B0EC int3       
000000018037B0ED int3       
000000018037B0EE int3       
000000018037B0EF int3       
000000018037B0F0 push       rbx
000000018037B0F2 sub        rsp, 0x20
000000018037B0F6 mov        rbx, rcx
000000018037B0F9 mov        r10, rdx
000000018037B0FC mov        ecx, dword ptr [rcx + 0x24]
000000018037B0FF lea        eax, [rcx - 0xa]
000000018037B102 cmp        eax, 1
000000018037B105 jbe        0x18037b12d
000000018037B107 cmp        ecx, 0xf
000000018037B10A je         0x18037b12d
000000018037B10C lea        eax, [rcx - 0x1a]
000000018037B10F cmp        eax, 6
000000018037B112 jbe        0x18037b12d
000000018037B114 test       rdx, rdx
000000018037B117 je         0x18037b169
000000018037B119 mov        rdx, qword ptr [rbx + 0x30]
000000018037B11D xor        r9d, r9d
000000018037B120 mov        r8, rbx
000000018037B123 mov        rcx, r10
000000018037B126 call       0x18035a7a0
000000018037B12B jmp        0x18037b13d
000000018037B12D mov        rcx, qword ptr [rbx + 0x30]
000000018037B131 test       rcx, rcx
000000018037B134 je         0x18037b169
000000018037B136 xor        edx, edx
000000018037B138 call       0x180311890
000000018037B13D xor        edx, edx
000000018037B13F mov        rcx, rbx
000000018037B142 call       0x18037a410
000000018037B147 mov        eax, dword ptr [rbx + 0x24]
000000018037B14A cmp        eax, 0x13
000000018037B14D je         0x18037b163
000000018037B14F cmp        eax, 0x17
000000018037B152 je         0x18037b163
000000018037B154 xor        edx, edx
000000018037B156 mov        rcx, rbx
000000018037B159 add        rsp, 0x20
000000018037B15D pop        rbx
000000018037B15E jmp        0x18037b200
000000018037B163 add        rsp, 0x20
000000018037B167 pop        rbx
000000018037B168 ret        
000000018037B169 call       0x180250150
000000018037B16E int3       
000000018037B16F int3       
000000018037B170 push       rbx
000000018037B172 sub        rsp, 0x20
000000018037B176 mov        rbx, rcx
000000018037B179 mov        r10, rdx
000000018037B17C mov        ecx, dword ptr [rcx + 0x24]
000000018037B17F cmp        ecx, 0xf
000000018037B182 jle        0x18037b1d0
000000018037B184 lea        eax, [rcx - 0x1a]
000000018037B187 cmp        eax, 2
000000018037B18A jbe        0x18037b194
000000018037B18C lea        eax, [rcx - 0x1f]
000000018037B18F cmp        eax, 1
000000018037B192 ja         0x18037b1dd
000000018037B194 mov        rcx, qword ptr [rbx + 0x30]
000000018037B198 test       rcx, rcx
000000018037B19B je         0x18037b1f6
000000018037B19D xor        edx, edx
000000018037B19F call       0x180311890
000000018037B1A4 xor        edx, edx
000000018037B1A6 mov        rcx, rbx
000000018037B1A9 call       0x18037a410
000000018037B1AE mov        eax, dword ptr [rbx + 0x24]
000000018037B1B1 cmp        eax, 0x13
000000018037B1B4 je         0x18037b1ca
000000018037B1B6 cmp        eax, 0x17
000000018037B1B9 je         0x18037b1ca
000000018037B1BB xor        edx, edx
000000018037B1BD mov        rcx, rbx
000000018037B1C0 add        rsp, 0x20
000000018037B1C4 pop        rbx
000000018037B1C5 jmp        0x18037b200
000000018037B1CA add        rsp, 0x20
000000018037B1CE pop        rbx
000000018037B1CF ret        
000000018037B1D0 lea        eax, [rcx - 0xa]
000000018037B1D3 cmp        eax, 1
000000018037B1D6 jbe        0x18037b194
000000018037B1D8 cmp        ecx, 0xf
000000018037B1DB je         0x18037b194
000000018037B1DD test       r10, r10
000000018037B1E0 je         0x18037b1f6
000000018037B1E2 mov        rdx, qword ptr [rbx + 0x30]
000000018037B1E6 xor        r9d, r9d
000000018037B1E9 mov        r8, rbx
000000018037B1EC mov        rcx, r10
000000018037B1EF call       0x180369aa0
000000018037B1F4 jmp        0x18037b1a4
000000018037B1F6 call       0x180250150
000000018037B1FB int3       
000000018037B1FC int3       
000000018037B1FD int3       
000000018037B1FE int3       
000000018037B1FF int3       
