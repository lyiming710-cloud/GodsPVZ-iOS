# Projectile::Collision_AudioParticle 0x18037a410 b0d635850e034e4296083275f65c07067c27b01619347db9b5c75d33bd472d4b
000000018037A410 mov        qword ptr [rsp + 0x20], rsi 
000000018037A415 push       rdi 
000000018037A416 sub        rsp, 0xe0 
000000018037A41D cmp        byte ptr [rip + 0x196a9aa], 0 
000000018037A424 mov        rdi, rcx 
000000018037A427 jne        0x18037a490 
000000018037A429 lea        rcx, [rip + 0x1829b28] 
000000018037A430 call       0x18024fef0 
000000018037A435 lea        rcx, [rip + 0x182a2fc] 
000000018037A43C call       0x18024fef0 
000000018037A441 lea        rcx, [rip + 0x1827bd0] 
000000018037A448 call       0x18024fef0 
000000018037A44D lea        rcx, [rip + 0x1829e24] 
000000018037A454 call       0x18024fef0 
000000018037A459 lea        rcx, [rip + 0x18360a0] 
000000018037A460 call       0x18024fef0 
000000018037A465 lea        rcx, [rip + 0x183c00c] 
000000018037A46C call       0x18024fef0 
000000018037A471 lea        rcx, [rip + 0x182f288] 
000000018037A478 call       0x18024fef0 
000000018037A47D lea        rcx, [rip + 0x1853cf4] 
000000018037A484 call       0x18024fef0 
000000018037A489 mov        byte ptr [rip + 0x196a93e], 1 
000000018037A490 mov        rax, qword ptr [rip + 0x1827b81] 
000000018037A497 xor        esi, esi 
000000018037A499 cmp        dword ptr [rax + 0xe0], esi 
000000018037A49F jne        0x18037a4b0 
000000018037A4A1 mov        rcx, rax 
000000018037A4A4 call       0x1802501e0 
000000018037A4A9 mov        rax, qword ptr [rip + 0x1827b68] 
000000018037A4B0 mov        rax, qword ptr [rax + 0xb8] 
000000018037A4B7 mov        qword ptr [rsp + 0xf0], rbx 
000000018037A4BF mov        qword ptr [rsp + 0xf8], rbp 
000000018037A4C7 mov        qword ptr [rsp + 0x100], r14 
000000018037A4CF mov        rcx, qword ptr [rax] 
000000018037A4D2 movaps     xmmword ptr [rsp + 0xd0], xmm6 
000000018037A4DA movaps     xmmword ptr [rsp + 0xc0], xmm7 
000000018037A4E2 movaps     xmmword ptr [rsp + 0xb0], xmm8 
000000018037A4EB movaps     xmmword ptr [rsp + 0xa0], xmm9 
000000018037A4F4 movaps     xmmword ptr [rsp + 0x90], xmm10 
000000018037A4FD movaps     xmmword ptr [rsp + 0x80], xmm11 
000000018037A506 movaps     xmmword ptr [rsp + 0x70], xmm12 
000000018037A50C movaps     xmmword ptr [rsp + 0x60], xmm13 
000000018037A512 movaps     xmmword ptr [rsp + 0x50], xmm14 
000000018037A518 movaps     xmmword ptr [rsp + 0x40], xmm15 
000000018037A51E test       rcx, rcx 
000000018037A521 je         0x18037af3e 
000000018037A527 movss      xmm8, dword ptr [rip + 0x122d4e0] 
000000018037A530 lea        r14, [rip - 0x37a537] 
000000018037A537 mov        edx, dword ptr [rdi + 0x24] 
000000018037A53A movaps     xmm13, xmm8 
000000018037A53E movss      xmm7, dword ptr [rcx + 0x18] 
000000018037A543 movaps     xmm14, xmm8 
000000018037A547 movss      xmm9, dword ptr [rip + 0x122d4c4] 
000000018037A550 movaps     xmm15, xmm8 
000000018037A554 movss      xmm0, dword ptr [rip + 0x122d4ac] 
000000018037A55C movss      xmm11, dword ptr [rip + 0x122d6af] 
000000018037A565 movss      xmm12, dword ptr [rip + 0x122d55a] 
000000018037A56E cmp        edx, 1 
000000018037A571 jle        0x18037a76a 
000000018037A577 lea        eax, [rdx - 9] 
000000018037A57A cmp        eax, 6 
000000018037A57D ja         0x18037a634 
000000018037A583 cdqe        
000000018037A585 mov        ecx, dword ptr [r14 + rax*4 + 0x37af44] 
000000018037A58D add        rcx, r14 
000000018037A590 jmp        rcx 
000000018037A592 mov        rcx, qword ptr [rdi + 0xe8] 
000000018037A599 mov        ebx, 2 
000000018037A59E movss      xmm6, dword ptr [rdi + 0x48] 
000000018037A5A3 movaps     xmm13, xmm9 
000000018037A5A7 movss      xmm10, dword ptr [rdi + 0x44] 
000000018037A5AD movaps     xmm14, xmm9 
000000018037A5B1 movaps     xmm15, xmm9 
000000018037A5B5 addss      xmm6, dword ptr [rip + 0x122d6a3] 
000000018037A5BD test       rcx, rcx 
000000018037A5C0 je         0x18037af3e 
000000018037A5C6 movss      xmm2, dword ptr [rip + 0x122d536] 
000000018037A5CE xor        r9d, r9d 
000000018037A5D1 movss      xmm1, dword ptr [rip + 0x122d633] 
000000018037A5D9 call       0x1803276e0 Board::Shake
000000018037A5DE jmp        0x18037a793 
000000018037A5E3 mov        rcx, qword ptr [rdi + 0xe8] 
000000018037A5EA mov        ebx, 2 
000000018037A5EF movss      xmm6, dword ptr [rdi + 0x4c] 
000000018037A5F4 movss      xmm10, dword ptr [rdi + 0x44] 
000000018037A5FA addss      xmm6, dword ptr [rdi + 0x48] 
000000018037A5FF test       rcx, rcx 
000000018037A602 je         0x18037af3e 
000000018037A608 movss      xmm2, dword ptr [rip + 0x122d5d0] 
000000018037A610 xor        r9d, r9d 
000000018037A613 movss      xmm1, dword ptr [rip + 0x122d5ed] 
000000018037A61B call       0x1803276e0 Board::Shake
000000018037A620 jmp        0x18037a793 
000000018037A625 movss      xmm6, dword ptr [rdi + 0x48] 
000000018037A62A mov        ebx, 0x17 
000000018037A62F jmp        0x18037a78d 
000000018037A634 add        edx, -0x13 
000000018037A637 cmp        edx, 0xd 
000000018037A63A ja         0x18037a92f 
000000018037A640 movsxd     rax, edx 
000000018037A643 mov        ecx, dword ptr [r14 + rax*4 + 0x37af60] 
000000018037A64B add        rcx, r14 
000000018037A64E jmp        rcx 
000000018037A650 mov        ebx, 0xc 
000000018037A655 jmp        0x18037a783 
000000018037A65A mov        rcx, qword ptr [rdi + 0xe8] 
000000018037A661 mov        ebx, 0x21 
000000018037A666 movss      xmm6, dword ptr [rdi + 0x4c] 
000000018037A66B movss      xmm10, dword ptr [rdi + 0x44] 
000000018037A671 addss      xmm6, dword ptr [rdi + 0x48] 
000000018037A676 test       rcx, rcx 
000000018037A679 je         0x18037af3e 
000000018037A67F movss      xmm2, dword ptr [rip + 0x122d5cd] 
000000018037A687 xor        r9d, r9d 
000000018037A68A movaps     xmm1, xmm0 
000000018037A68D call       0x1803276e0 Board::Shake
000000018037A692 jmp        0x18037a793 
000000018037A697 movaps     xmm13, xmm11 
000000018037A69B movaps     xmm14, xmm11 
000000018037A69F movaps     xmm15, xmm11 
000000018037A6A3 jmp        0x18037a5e3 
000000018037A6A8 mov        rcx, qword ptr [rdi + 0xe8] 
000000018037A6AF mov        ebx, 0x13 
000000018037A6B4 movss      xmm10, dword ptr [rdi + 0x44] 
000000018037A6BA movss      xmm6, dword ptr [rdi + 0x48] 
000000018037A6BF test       rcx, rcx 
000000018037A6C2 je         0x18037af3e 
000000018037A6C8 movss      xmm2, dword ptr [rip + 0x122d584] 
000000018037A6D0 xor        r9d, r9d 
000000018037A6D3 movss      xmm1, dword ptr [rip + 0x122d531] 
000000018037A6DB call       0x1803276e0 Board::Shake
000000018037A6E0 jmp        0x18037a793 
000000018037A6E5 mov        rcx, qword ptr [rdi + 0xe8] 
000000018037A6EC mov        ebx, 0x21 
000000018037A6F1 movss      xmm6, dword ptr [rdi + 0x4c] 
000000018037A6F6 movss      xmm10, dword ptr [rdi + 0x44] 
000000018037A6FC addss      xmm6, dword ptr [rdi + 0x48] 
000000018037A701 test       rcx, rcx 
000000018037A704 je         0x18037af3e 
000000018037A70A movss      xmm2, dword ptr [rip + 0x122d542] 
000000018037A712 movaps     xmm1, xmm0 
000000018037A715 xor        r9d, r9d 
000000018037A718 call       0x1803276e0 Board::Shake
000000018037A71D jmp        0x18037a793 
000000018037A71F mov        rcx, qword ptr [rdi + 0xe8] 
000000018037A726 mov        ebx, 2 
000000018037A72B movss      xmm6, dword ptr [rdi + 0x4c] 
000000018037A730 movaps     xmm13, xmm12 
000000018037A734 movss      xmm10, dword ptr [rdi + 0x44] 
000000018037A73A movaps     xmm14, xmm12 
000000018037A73E movaps     xmm15, xmm12 
000000018037A742 addss      xmm6, dword ptr [rdi + 0x48] 
000000018037A747 test       rcx, rcx 
000000018037A74A je         0x18037af3e 
000000018037A750 movss      xmm2, dword ptr [rip + 0x122d3ac] 
000000018037A758 xor        r9d, r9d 
000000018037A75B movss      xmm1, dword ptr [rip + 0x122d349] 
000000018037A763 call       0x1803276e0 Board::Shake
000000018037A768 jmp        0x18037a793 
000000018037A76A test       edx, edx 
000000018037A76C jne        0x18037a775 
000000018037A76E mov        ebx, 0x15 
000000018037A773 jmp        0x18037a783 
000000018037A775 cmp        edx, 1 
000000018037A778 jne        0x18037a92f 
000000018037A77E mov        ebx, 0x1f 
000000018037A783 movss      xmm6, dword ptr [rdi + 0x4c] 
000000018037A788 addss      xmm6, dword ptr [rdi + 0x48] 
000000018037A78D movss      xmm10, dword ptr [rdi + 0x44] 
000000018037A793 cmp        byte ptr [rip + 0x196a39a], sil 
000000018037A79A jne        0x18037a7af 
000000018037A79C lea        rcx, [rip + 0x18370ed] 
000000018037A7A3 call       0x18024fef0 
000000018037A7A8 mov        byte ptr [rip + 0x196a385], 1 
000000018037A7AF mov        rax, qword ptr [rip + 0x18370da] 
000000018037A7B6 mov        rcx, qword ptr [rax + 0xb8] 
000000018037A7BD mov        rcx, qword ptr [rcx] 
000000018037A7C0 test       rcx, rcx 
000000018037A7C3 je         0x18037af3e 
000000018037A7C9 xor        r8d, r8d 
000000018037A7CC mov        edx, ebx 
000000018037A7CE call       0x180321f30 ParticlesManager::CreatNewParticle
000000018037A7D3 mov        rcx, qword ptr [rip + 0x1835d26] 
000000018037A7DA mov        rbp, rax 
000000018037A7DD cmp        dword ptr [rcx + 0xe0], esi 
000000018037A7E3 jne        0x18037a7ea 
000000018037A7E5 call       0x1802501e0 
000000018037A7EA xor        r8d, r8d 
000000018037A7ED xor        edx, edx 
000000018037A7EF mov        rcx, rbp 
000000018037A7F2 call       0x18131f900 Object::op_Inequality
000000018037A7F7 test       al, al 
000000018037A7F9 je         0x18037a92f 
000000018037A7FF test       rbp, rbp 
000000018037A802 je         0x18037af3e 
000000018037A808 xor        edx, edx 
000000018037A80A mov        rcx, rbp 
000000018037A80D call       0x180cfb610 GameObject::get_gameObject
000000018037A812 test       rax, rax 
000000018037A815 je         0x18037af3e 
000000018037A81B xor        edx, edx 
000000018037A81D mov        rcx, rax 
000000018037A820 call       0x18131c070 GameObject::get_transform
000000018037A825 xorps      xmm1, xmm1 
000000018037A828 test       rax, rax 
000000018037A82B je         0x18037af3e 
000000018037A831 unpcklps   xmm10, xmm6 
000000018037A835 lea        rdx, [rsp + 0x30] 
000000018037A83A xor        r8d, r8d 
000000018037A83D movsd      qword ptr [rsp + 0x30], xmm10 
000000018037A844 mov        rcx, rax 
000000018037A847 movss      dword ptr [rsp + 0x38], xmm1 
000000018037A84D call       0x18132fbb0 Transform::set_position
000000018037A852 mov        rdx, qword ptr [rip + 0x18296ff] 
000000018037A859 mov        rcx, rbp 
000000018037A85C call       0x18046d280 
000000018037A861 test       rax, rax 
000000018037A864 je         0x18037af3e 
000000018037A86A mov        rdx, qword ptr [rip + 0x182ee8f] 
000000018037A871 xor        r8d, r8d 
000000018037A874 mov        rcx, rax 
000000018037A877 call       0x181348060 SortingGroup::set_sortingLayerName
000000018037A87C xor        edx, edx 
000000018037A87E mov        rcx, rbp 
000000018037A881 call       0x18131c070 GameObject::get_transform
000000018037A886 test       rax, rax 
000000018037A889 je         0x18037af3e 
000000018037A88F xor        r8d, r8d 
000000018037A892 lea        rcx, [rsp + 0x30] 
000000018037A897 mov        rdx, rax 
000000018037A89A call       0x18132f1b0 Transform::get_localScale
000000018037A89F xor        edx, edx 
000000018037A8A1 mov        rcx, rbp 
000000018037A8A4 movsd      xmm6, qword ptr [rax] 
000000018037A8A8 mov        ebx, dword ptr [rax + 8] 
000000018037A8AB call       0x18131c070 GameObject::get_transform
000000018037A8B0 movd       xmm2, ebx 
000000018037A8B4 movaps     xmm1, xmm6 
000000018037A8B7 shufps     xmm1, xmm1, 0x55 
000000018037A8BB movaps     xmm0, xmm6 
000000018037A8BE mulss      xmm1, xmm14 
000000018037A8C3 mulss      xmm0, xmm13 
000000018037A8C8 movsd      qword ptr [rsp + 0x30], xmm6 
000000018037A8CE mulss      xmm2, xmm15 
000000018037A8D3 test       rax, rax 
000000018037A8D6 je         0x18037af3e 
000000018037A8DC unpcklps   xmm0, xmm1 
000000018037A8DF lea        rdx, [rsp + 0x30] 
000000018037A8E4 xor        r8d, r8d 
000000018037A8E7 movsd      qword ptr [rsp + 0x30], xmm0 
000000018037A8ED mov        rcx, rax 
000000018037A8F0 movss      dword ptr [rsp + 0x38], xmm2 
000000018037A8F6 call       0x18132fa50 Transform::set_localScale
000000018037A8FB cmp        dword ptr [rdi + 0x24], 0x1e 
000000018037A8FF jne        0x18037a92f 
000000018037A901 mov        rdx, qword ptr [rip + 0x1829e30] 
000000018037A908 mov        rcx, rbp 
000000018037A90B call       0x18046dc80 
000000018037A910 test       rax, rax 
000000018037A913 je         0x18037af3e 
000000018037A919 mov        r8d, dword ptr [rdi + 0x74] 
000000018037A91D xor        r9d, r9d 
000000018037A920 mov        rdx, qword ptr [rip + 0x1853851] 
000000018037A927 mov        rcx, rax 
000000018037A92A call       0x1812dbb60 
000000018037A92F movsxd     rax, dword ptr [rdi + 0x24] 
000000018037A933 cmp        eax, 0x20 
000000018037A936 ja         0x18037ae30 
000000018037A93C movzx      eax, byte ptr [r14 + rax + 0x37afcc] 
000000018037A945 mov        ecx, dword ptr [r14 + rax*4 + 0x37af98] 
000000018037A94D add        rcx, r14 
000000018037A950 jmp        rcx 
000000018037A952 movss      xmm0, dword ptr [rip + 0x122d16a] 
000000018037A95A xor        r8d, r8d 
000000018037A95D movaps     xmm1, xmm9 
000000018037A961 call       0x18130d350 Random::Range
000000018037A966 mov        rax, qword ptr [rip + 0x183bb0b] 
000000018037A96D movaps     xmm8, xmm0 
000000018037A971 cmp        dword ptr [rax + 0xe0], esi 
000000018037A977 jne        0x18037a988 
000000018037A979 mov        rcx, rax 
000000018037A97C call       0x1802501e0 
000000018037A981 mov        rax, qword ptr [rip + 0x183baf0] 
000000018037A988 mov        rax, qword ptr [rax + 0xb8] 
000000018037A98F xor        r8d, r8d 
000000018037A992 mov        edx, 3 
000000018037A997 xor        ecx, ecx 
000000018037A999 mov        rbx, qword ptr [rax + 0x130] 
000000018037A9A0 call       0x18130d310 Random::RandomRangeInt
000000018037A9A5 test       rbx, rbx 
000000018037A9A8 je         0x18037af3e 
000000018037A9AE lea        edx, [rax + 7] 
000000018037A9B1 mov        rcx, rbx 
000000018037A9B4 mov        r8, qword ptr [rip + 0x18298bd] 
000000018037A9BB call       0x180825710 
000000018037A9C0 mulss      xmm7, dword ptr [rip + 0x122d0f4] 
000000018037A9C8 jmp        0x18037ae2d 
000000018037A9CD movss      xmm0, dword ptr [rip + 0x122d0ef] 
000000018037A9D5 xor        r8d, r8d 
000000018037A9D8 movaps     xmm1, xmm9 
000000018037A9DC call       0x18130d350 Random::Range
000000018037A9E1 mov        rax, qword ptr [rip + 0x183ba90] 
000000018037A9E8 movaps     xmm8, xmm0 
000000018037A9EC cmp        dword ptr [rax + 0xe0], esi 
000000018037A9F2 jne        0x18037aa03 
000000018037A9F4 mov        rcx, rax 
000000018037A9F7 call       0x1802501e0 
000000018037A9FC mov        rax, qword ptr [rip + 0x183ba75] 
000000018037AA03 mov        rax, qword ptr [rax + 0xb8] 
000000018037AA0A mov        rcx, qword ptr [rax + 0x130] 
000000018037AA11 test       rcx, rcx 
000000018037AA14 je         0x18037af3e 
000000018037AA1A mov        edx, 1 
000000018037AA1F jmp        0x18037a9b4 
000000018037AA21 movss      xmm0, dword ptr [rip + 0x122d09b] 
000000018037AA29 xor        r8d, r8d 
000000018037AA2C movaps     xmm1, xmm9 
000000018037AA30 call       0x18130d350 Random::Range
000000018037AA35 mov        rax, qword ptr [rip + 0x183ba3c] 
000000018037AA3C movaps     xmm8, xmm0 
000000018037AA40 cmp        dword ptr [rax + 0xe0], esi 
000000018037AA46 jne        0x18037aa57 
000000018037AA48 mov        rcx, rax 
000000018037AA4B call       0x1802501e0 
000000018037AA50 mov        rax, qword ptr [rip + 0x183ba21] 
000000018037AA57 mov        rax, qword ptr [rax + 0xb8] 
000000018037AA5E mov        rcx, qword ptr [rax + 0x130] 
000000018037AA65 test       rcx, rcx 
000000018037AA68 je         0x18037af3e 
000000018037AA6E mov        r8, qword ptr [rip + 0x1829803] 
000000018037AA75 xor        edx, edx 
000000018037AA77 call       0x180825710 
000000018037AA7C jmp        0x18037ae2d 
000000018037AA81 movss      xmm0, dword ptr [rip + 0x122d03b] 
000000018037AA89 xor        r8d, r8d 
000000018037AA8C movaps     xmm1, xmm9 
000000018037AA90 call       0x18130d350 Random::Range
000000018037AA95 mov        rax, qword ptr [rip + 0x183b9dc] 
000000018037AA9C movaps     xmm8, xmm0 
000000018037AAA0 cmp        dword ptr [rax + 0xe0], esi 
000000018037AAA6 jne        0x18037aab7 
000000018037AAA8 mov        rcx, rax 
000000018037AAAB call       0x1802501e0 
000000018037AAB0 mov        rax, qword ptr [rip + 0x183b9c1] 
000000018037AAB7 mov        rax, qword ptr [rax + 0xb8] 
000000018037AABE mov        rcx, qword ptr [rax + 0x130] 
000000018037AAC5 test       rcx, rcx 
000000018037AAC8 je         0x18037af3e 
000000018037AACE mov        r8, qword ptr [rip + 0x18297a3] 
000000018037AAD5 mov        edx, 0xa 
000000018037AADA call       0x180825710 
000000018037AADF jmp        0x18037ae2d 
000000018037AAE4 movss      xmm0, dword ptr [rip + 0x122cfd8] 
000000018037AAEC xor        r8d, r8d 
000000018037AAEF movaps     xmm1, xmm9 
000000018037AAF3 call       0x18130d350 Random::Range
000000018037AAF8 mov        rax, qword ptr [rip + 0x183b979] 
000000018037AAFF movaps     xmm8, xmm0 
000000018037AB03 cmp        dword ptr [rax + 0xe0], esi 
000000018037AB09 jne        0x18037ab1a 
000000018037AB0B mov        rcx, rax 
000000018037AB0E call       0x1802501e0 
000000018037AB13 mov        rax, qword ptr [rip + 0x183b95e] 
000000018037AB1A mov        rax, qword ptr [rax + 0xb8] 
000000018037AB21 mov        rcx, qword ptr [rax + 0x130] 
000000018037AB28 test       rcx, rcx 
000000018037AB2B je         0x18037af3e 
000000018037AB31 mov        r8, qword ptr [rip + 0x1829740] 
000000018037AB38 mov        edx, 0xb 
000000018037AB3D call       0x180825710 
000000018037AB42 jmp        0x18037ae2d 
000000018037AB47 movss      xmm0, dword ptr [rip + 0x122cf75] 
000000018037AB4F xor        r8d, r8d 
000000018037AB52 movaps     xmm1, xmm9 
000000018037AB56 call       0x18130d350 Random::Range
000000018037AB5B mov        rax, qword ptr [rip + 0x183b916] 
000000018037AB62 movaps     xmm8, xmm0 
000000018037AB66 cmp        dword ptr [rax + 0xe0], esi 
000000018037AB6C jne        0x18037ab7d 
000000018037AB6E mov        rcx, rax 
000000018037AB71 call       0x1802501e0 
000000018037AB76 mov        rax, qword ptr [rip + 0x183b8fb] 
000000018037AB7D mov        rax, qword ptr [rax + 0xb8] 
000000018037AB84 mov        rcx, qword ptr [rax + 0x130] 
000000018037AB8B test       rcx, rcx 
000000018037AB8E je         0x18037af3e 
000000018037AB94 mov        r8, qword ptr [rip + 0x18296dd] 
000000018037AB9B mov        edx, 0x15 
000000018037ABA0 call       0x180825710 
000000018037ABA5 jmp        0x18037ae2d 
000000018037ABAA movss      xmm0, dword ptr [rip + 0x122cf12] 
000000018037ABB2 xor        r8d, r8d 
000000018037ABB5 movaps     xmm1, xmm9 
000000018037ABB9 call       0x18130d350 Random::Range
000000018037ABBE mulss      xmm7, dword ptr [rip + 0x122ce42] 
000000018037ABC6 jmp        0x18037aaf8 
000000018037ABCB movss      xmm0, dword ptr [rip + 0x122cef1] 
000000018037ABD3 xor        r8d, r8d 
000000018037ABD6 movaps     xmm1, xmm9 
000000018037ABDA call       0x18130d350 Random::Range
000000018037ABDF mulss      xmm7, xmm11 
000000018037ABE4 jmp        0x18037aaf8 
000000018037ABE9 movss      xmm0, dword ptr [rip + 0x122ced3] 
000000018037ABF1 xor        r8d, r8d 
000000018037ABF4 movaps     xmm1, xmm9 
000000018037ABF8 call       0x18130d350 Random::Range
000000018037ABFD mov        rax, qword ptr [rip + 0x183b874] 
000000018037AC04 movaps     xmm8, xmm0 
000000018037AC08 cmp        dword ptr [rax + 0xe0], esi 
000000018037AC0E jne        0x18037ac1f 
000000018037AC10 mov        rcx, rax 
000000018037AC13 call       0x1802501e0 
000000018037AC18 mov        rax, qword ptr [rip + 0x183b859] 
000000018037AC1F mov        rax, qword ptr [rax + 0xb8] 
000000018037AC26 mov        rcx, qword ptr [rax + 0x130] 
000000018037AC2D test       rcx, rcx 
000000018037AC30 je         0x18037af3e 
000000018037AC36 mov        r8, qword ptr [rip + 0x182963b] 
000000018037AC3D mov        edx, 1 
000000018037AC42 call       0x180825710 
000000018037AC47 mulss      xmm7, dword ptr [rip + 0x122cf45] 
000000018037AC4F jmp        0x18037ae2d 
000000018037AC54 movss      xmm0, dword ptr [rip + 0x122ce68] 
000000018037AC5C xor        r8d, r8d 
000000018037AC5F movaps     xmm1, xmm9 
000000018037AC63 call       0x18130d350 Random::Range
000000018037AC68 mov        rax, qword ptr [rip + 0x183b809] 
000000018037AC6F movaps     xmm8, xmm0 
000000018037AC73 cmp        dword ptr [rax + 0xe0], esi 
000000018037AC79 jne        0x18037ac8a 
000000018037AC7B mov        rcx, rax 
000000018037AC7E call       0x1802501e0 
000000018037AC83 mov        rax, qword ptr [rip + 0x183b7ee] 
000000018037AC8A mov        rax, qword ptr [rax + 0xb8] 
000000018037AC91 mov        rcx, qword ptr [rax + 0x130] 
000000018037AC98 test       rcx, rcx 
000000018037AC9B je         0x18037af3e 
000000018037ACA1 mov        r8, qword ptr [rip + 0x18295d0] 
000000018037ACA8 mov        edx, 0x16 
000000018037ACAD call       0x180825710 
000000018037ACB2 mov        rsi, rax 
000000018037ACB5 mov        rax, qword ptr [rip + 0x183b7bc] 
000000018037ACBC mov        rcx, qword ptr [rax + 0xb8] 
000000018037ACC3 mov        rcx, qword ptr [rcx + 0x120] 
000000018037ACCA test       rcx, rcx 
000000018037ACCD je         0x18037af3e 
000000018037ACD3 mov        r8, qword ptr [rip + 0x182959e] 
000000018037ACDA mov        edx, 0xa 
000000018037ACDF call       0x180825710 
000000018037ACE4 xor        ecx, ecx 
000000018037ACE6 mov        rdi, rax 
000000018037ACE9 call       0x1812e27c0 Camera::get_main
000000018037ACEE test       rax, rax 
000000018037ACF1 je         0x18037af3e 
000000018037ACF7 xor        edx, edx 
000000018037ACF9 mov        rcx, rax 
000000018037ACFC call       0x181304510 Component::get_transform
000000018037AD01 test       rax, rax 
000000018037AD04 je         0x18037af3e 
000000018037AD0A xor        r8d, r8d 
000000018037AD0D lea        rcx, [rsp + 0x30] 
000000018037AD12 mov        rdx, rax 
000000018037AD15 call       0x18132f3a0 Transform::get_position
000000018037AD1A mov        rcx, qword ptr [rip + 0x18272f7] 
000000018037AD21 movsd      xmm6, qword ptr [rax] 
000000018037AD25 cmp        dword ptr [rcx + 0xe0], 0 
000000018037AD2C mov        ebx, dword ptr [rax + 8] 
000000018037AD2F jne        0x18037ad36 
000000018037AD31 call       0x1802501e0 
000000018037AD36 movaps     xmm3, xmm8 
000000018037AD3A movsd      qword ptr [rsp + 0x30], xmm6 
000000018037AD40 movaps     xmm2, xmm7 
000000018037AD43 mov        dword ptr [rsp + 0x38], ebx 
000000018037AD47 lea        rdx, [rsp + 0x30] 
000000018037AD4C mov        qword ptr [rsp + 0x20], 0 
000000018037AD55 mov        rcx, rdi 
000000018037AD58 call       0x18031b350 GlobalStaticVars::CreateAudioAtPoint
000000018037AD5D jmp        0x18037ae30 
000000018037AD62 movss      xmm0, dword ptr [rip + 0x122cd5a] 
000000018037AD6A xor        r8d, r8d 
000000018037AD6D movaps     xmm1, xmm9 
000000018037AD71 call       0x18130d350 Random::Range
000000018037AD76 mov        rax, qword ptr [rip + 0x183b6fb] 
000000018037AD7D movaps     xmm8, xmm0 
000000018037AD81 mulss      xmm7, dword ptr [rip + 0x122cd43] 
000000018037AD89 cmp        dword ptr [rax + 0xe0], esi 
000000018037AD8F jne        0x18037ada0 
000000018037AD91 mov        rcx, rax 
000000018037AD94 call       0x1802501e0 
000000018037AD99 mov        rax, qword ptr [rip + 0x183b6d8] 
000000018037ADA0 mov        rax, qword ptr [rax + 0xb8] 
000000018037ADA7 mov        rcx, qword ptr [rax + 0x130] 
000000018037ADAE test       rcx, rcx 
000000018037ADB1 je         0x18037af3e 
000000018037ADB7 mov        r8, qword ptr [rip + 0x18294ba] 
000000018037ADBE mov        edx, 0x10 
000000018037ADC3 call       0x180825710 
000000018037ADC8 jmp        0x18037ae2d 
000000018037ADCA movss      xmm0, dword ptr [rip + 0x122ccf2] 
000000018037ADD2 xor        r8d, r8d 
000000018037ADD5 movaps     xmm1, xmm9 
000000018037ADD9 call       0x18130d350 Random::Range
000000018037ADDE mov        rax, qword ptr [rip + 0x183b693] 
000000018037ADE5 movaps     xmm8, xmm0 
000000018037ADE9 cmp        dword ptr [rax + 0xe0], esi 
000000018037ADEF jne        0x18037ae00 
000000018037ADF1 mov        rcx, rax 
000000018037ADF4 call       0x1802501e0 
000000018037ADF9 mov        rax, qword ptr [rip + 0x183b678] 
000000018037AE00 mov        rax, qword ptr [rax + 0xb8] 
000000018037AE07 mov        rcx, qword ptr [rax + 0x130] 
000000018037AE0E test       rcx, rcx 
000000018037AE11 je         0x18037af3e 
000000018037AE17 mov        r8, qword ptr [rip + 0x182945a] 
000000018037AE1E mov        edx, 1 
000000018037AE23 call       0x180825710 
000000018037AE28 mulss      xmm7, xmm12 
000000018037AE2D mov        rsi, rax 
000000018037AE30 mov        rcx, qword ptr [rip + 0x18356c9] 
000000018037AE37 cmp        dword ptr [rcx + 0xe0], 0 
000000018037AE3E jne        0x18037ae45 
000000018037AE40 call       0x1802501e0 
000000018037AE45 xor        edx, edx 
000000018037AE47 mov        rcx, rsi 
000000018037AE4A call       0x18131f870 Object::op_Implicit
000000018037AE4F test       al, al 
000000018037AE51 je         0x18037aec9 
000000018037AE53 xor        ecx, ecx 
000000018037AE55 call       0x1812e27c0 Camera::get_main
000000018037AE5A test       rax, rax 
000000018037AE5D je         0x18037af3e 
000000018037AE63 xor        edx, edx 
000000018037AE65 mov        rcx, rax 
000000018037AE68 call       0x181304510 Component::get_transform
000000018037AE6D test       rax, rax 
000000018037AE70 je         0x18037af3e 
000000018037AE76 xor        r8d, r8d 
000000018037AE79 lea        rcx, [rsp + 0x30] 
000000018037AE7E mov        rdx, rax 
000000018037AE81 call       0x18132f3a0 Transform::get_position
000000018037AE86 mov        rcx, qword ptr [rip + 0x182718b] 
000000018037AE8D movsd      xmm6, qword ptr [rax] 
000000018037AE91 cmp        dword ptr [rcx + 0xe0], 0 
000000018037AE98 mov        ebx, dword ptr [rax + 8] 
000000018037AE9B jne        0x18037aea2 
000000018037AE9D call       0x1802501e0 
000000018037AEA2 movaps     xmm3, xmm8 
000000018037AEA6 movsd      qword ptr [rsp + 0x30], xmm6 
000000018037AEAC movaps     xmm2, xmm7 
000000018037AEAF mov        dword ptr [rsp + 0x38], ebx 
000000018037AEB3 lea        rdx, [rsp + 0x30] 
000000018037AEB8 mov        qword ptr [rsp + 0x20], 0 
000000018037AEC1 mov        rcx, rsi 
000000018037AEC4 call       0x18031b350 GlobalStaticVars::CreateAudioAtPoint
000000018037AEC9 movaps     xmm15, xmmword ptr [rsp + 0x40] 
000000018037AECF movaps     xmm14, xmmword ptr [rsp + 0x50] 
000000018037AED5 movaps     xmm13, xmmword ptr [rsp + 0x60] 
000000018037AEDB movaps     xmm12, xmmword ptr [rsp + 0x70] 
000000018037AEE1 movaps     xmm11, xmmword ptr [rsp + 0x80] 
000000018037AEEA movaps     xmm10, xmmword ptr [rsp + 0x90] 
000000018037AEF3 movaps     xmm9, xmmword ptr [rsp + 0xa0] 
000000018037AEFC movaps     xmm8, xmmword ptr [rsp + 0xb0] 
000000018037AF05 movaps     xmm7, xmmword ptr [rsp + 0xc0] 
000000018037AF0D movaps     xmm6, xmmword ptr [rsp + 0xd0] 
000000018037AF15 mov        r14, qword ptr [rsp + 0x100] 
000000018037AF1D mov        rbp, qword ptr [rsp + 0xf8] 
000000018037AF25 mov        rbx, qword ptr [rsp + 0xf0] 
000000018037AF2D mov        rsi, qword ptr [rsp + 0x108] 
000000018037AF35 add        rsp, 0xe0 
000000018037AF3C pop        rdi 
000000018037AF3D ret         
000000018037AF3E call       0x180250150 
000000018037AF43 int3        
000000018037AF44 xchg       edx, eax 
000000018037AF45 movsd      dword ptr [rdi], dword ptr [rsi] 
