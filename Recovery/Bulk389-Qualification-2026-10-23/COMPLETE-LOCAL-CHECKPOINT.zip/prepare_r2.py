from pathlib import Path
import shutil,json,hashlib
Q=Path(__file__).resolve().parent;D=Q/'revision-r2-final';D.mkdir(exist_ok=False);S=D/'source';S.mkdir();changes=[]
for p in (Q/'source').iterdir():
 if p.is_file():shutil.copy2(p,S/p.name)
def replace(file,old,new,count=1):
 p=S/file;t=p.read_text('utf-8');assert t.count(old)==count,(file,old,t.count(old));p.write_text(t.replace(old,new),encoding='utf-8');changes.append(dict(file=file,old=old,new=new))
replace('N119.RemainingBodies.cs','b.Load(0).Ref(0x8C,0x0100000A).Virtual(0x0A000061)','b.Address(0).Op(0xFE).Ref(0x16,0x0100000A).Virtual(0x0A000061)')
replace('N119.BoxingBodies.cs','Virtual(0x0A000036)','Virtual(0x0A000152)')
replace('N119.UiBodies.cs','.Field(0x040008BA).Call(0x2B000027)','.Field(0x040008BA).Call(0x2B00007D)')
# The two final stores in ShakeB mistakenly used ShakeA's current field.
p=S/'N119.VertexBodies.cs';text=p.read_text('utf-8');a,b=text.split('    private static byte[] N119_ShakeB()',1);assert b.count('Set(0x04000A43)')==2
p.write_text(a+'    private static byte[] N119_ShakeB()'+b.replace('Set(0x04000A43)','Set(0x04000A4D)'),encoding='utf-8');changes.append(dict(file=p.name,old='ShakeB current=0x04000A43',new='ShakeB current=0x04000A4D'))
# Both concrete event classes derive from these exact closed UnityEvent bases.
old='070f0808031283841181e10e080812838c1181e51d03081181950e128394';new='070f080803151281e90203081181e10e0808151281ed030e08081181e51d03081181950e128394'
replace('Native119MetadataData.cs',old,new)
replace('N119.TextEventBodies.cs','Virtual(N119_WordInvoke)','Virtual(0x0A000402)',count=2)
# Existing public getter is precisely ldarg.0; ldfld animationSprites; ret.
replace('N119.SkillBodies.cs','Arg(0).Field(0x040004DF)','Arg(0).Virtual(0x060003B9)',count=2)
meta=json.loads((S/'METADATA-ADDITIONS.json').read_text('utf-8'));assert meta['local_blobs'][318]==old;meta['local_blobs'][318]=new;meta['expected_blob_heap_bytes']+=len(bytes.fromhex(new))-len(bytes.fromhex(old));(S/'METADATA-ADDITIONS.json').write_text(json.dumps(meta,indent=2)+'\n','utf-8')
delta=json.loads((S/'NATIVE119-METADATA-DELTA.json').read_text('utf-8'));assert delta['local_signatures'][25]['blob']==old;delta['local_signatures'][25]['blob']=new;(S/'NATIVE119-METADATA-DELTA.json').write_text(json.dumps(delta,indent=2)+'\n','utf-8')
plan=json.loads((S/'IMPLEMENTATION-PLAN.json').read_text('utf-8'));target=next(t for t in plan['targets'] if int(t['token'],16)==0x06000735);target['local_blob']=new;plan['state']='R2_UNTESTED_CONSTRUCTION_SOURCE';(S/'IMPLEMENTATION-PLAN.json').write_text(json.dumps(plan,indent=2,ensure_ascii=False)+'\n','utf-8')
(D/'CHANGES.json').write_text(json.dumps(dict(changes=changes,unresolved=['Math.ThrowMinMaxException private access in 0x06000582','Projectile.Collision_AudioParticle private access in 0x06000507'],validators_modified=False),indent=2)+'\n','utf-8');(D/'candidates').mkdir();(D/'logs').mkdir();print('R2_SOURCE_WRITTEN',len(changes),'blob bytes',meta['expected_blob_heap_bytes'])
