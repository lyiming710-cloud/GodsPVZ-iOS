from width_fixtures import *
specs=json.loads((B/'expected-v2.json').read_text());results=json.loads((B/'rewrite-results-v2.json').read_text());jobs={x['name']:x for x in json.loads((B/'rewrite-jobs-v2.json').read_text())}
inspection=[];accepted=[];rejected=[];controls=[]
def check(p,expected):
 rows,loc=read(p)
 if rows!= {int(t):v for t,v in expected['rows'].items()}:raise ValueError('Decoded column values changed')
 if p[6]!=expected['flags']:raise ValueError('Incorrect HeapSizes flags')
 return rows,loc
for result in results:
 name=result['name'];s=specs[name];job=jobs[name]
 if s['reject']:
  assert result['status']=='REJECTED',(name,result)
  assert not Path(job['out']).exists(),name
  rejected.append(result);continue
 assert result['status']=='COMPLETED',(name,result)
 p=Path(job['out']).read_bytes();rows,loc=check(p,s);counts={t:len(v) for t,v in rows.items()}
 widths={t:sum(width(c,p[6],counts) for c in SC[t]) for t in rows}
 original=bytes.fromhex(s['original']);oldrows,_=read(original);oldcounts={t:len(v) for t,v in oldrows.items()}
 for t,n in counts.items():
  assert result['widths'][str(t)]==sum(width(c,original[6],oldcounts) for c in SC[t])
 rp=Path(job['out']+'.metadata')
 content=root(p,job['strings'],job['blobs'],job['guids'])
 if rp.exists():assert rp.read_bytes()==content,'Interrupted earlier output changed'
 else:put(rp,content)
 inspection.append(dict(name=name,root=str(rp),tables=list(rows)))
 accepted.append(dict(name=name,sha256=hashlib.sha256(p).hexdigest(),bytes=len(p),expected_widths=widths,counts=counts))
 if name=='blob-65536':
  mutants=[('heap-flag-only',bytes.fromhex(s['original'])[:6]+bytes([4])+bytes.fromhex(s['original'])[7:]),('truncated-wide-tail',p[:-2])]
  for t in (4,6,12,23):
   at,w=next(loc[t,0,i] for i,c in enumerate(SC[t]) if c=='b');assert w==4
   mutants.append(('unwidened-blob-column-'+str(t),p[:at+2]+p[at+4:]))
  at,w=loc[10,0,0];m=bytearray(p);m[at]^=7;mutants.append(('wrong-coded-tag',bytes(m)))
  for label,m in mutants:
   try:check(m,s);detected=False;reason='ACCEPTED'
   except Exception as e:detected=True;reason=str(e)
   controls.append(dict(name=label,detected=detected,reason=reason,sha256=hashlib.sha256(m).hexdigest()))
   assert detected,label
  # Same length but truncated high word must fail numeric comparison, not just length.
 if name=='append-high-blob':
  at,w=loc[17,1,0];m=bytearray(p);m[at+2:at+4]=b'\0\0'
  try:check(m,s);detected=False;reason='ACCEPTED'
  except Exception as e:detected=True;reason=str(e)
  assert detected;controls.append(dict(name='truncated-high-blob-index',detected=detected,reason=reason))
put(B/'inspect-jobs-v2.json',(json.dumps(inspection)+'\n').encode())
summary=dict(scope='SYNTHETIC_TABLE_WIDTH_AND_NUMERIC_PRESERVATION_ONLY',patcher_sha256=hashlib.sha256(PATCH.read_bytes()).hexdigest(),positive_count=len(accepted),writer_rejections=len(rejected),independent_mutants=len(controls),accepted=accepted,rejections=rejected,mutants=controls,official_reopened_widths='PENDING_SECOND_READER',game_behavior_proven=False)
put(B/'numeric-result-v2.json',(json.dumps(summary,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in summary.items() if k not in ('accepted','rejections','mutants')}))
