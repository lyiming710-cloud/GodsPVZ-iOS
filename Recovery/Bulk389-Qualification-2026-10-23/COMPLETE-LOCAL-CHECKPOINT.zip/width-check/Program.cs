using System.Collections.Immutable;
using System.Reflection;
using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Text.Json;
if(args.Length!=3)throw new ArgumentException("patcher.dll jobs.json results.json");
var asm=Assembly.LoadFrom(Path.GetFullPath(args[0]));
var type=asm.GetType("Program+WidthAwareTables",true)!;
var results=new List<object>();
foreach(var job in JsonDocument.Parse(File.ReadAllText(args[1])).RootElement.EnumerateArray())
{
    string name=job.GetProperty("name").GetString()!;
    try
    {
        using var provider=MetadataReaderProvider.FromMetadataImage(ImmutableArray.Create(File.ReadAllBytes(job.GetProperty("root").GetString()!)));
        var md=provider.GetMetadataReader();
        var widths=new Dictionary<int,int>();var counts=new Dictionary<int,int>();
        foreach(var x in job.GetProperty("tables").EnumerateArray())
        {int t=x.GetInt32();widths[t]=md.GetTableRowSize((TableIndex)t);counts[t]=md.GetTableRowCount((TableIndex)t);}
        if(job.TryGetProperty("payload",out var payload))
        {
            object writer=Activator.CreateInstance(type,BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic,null,
                new object[]{File.ReadAllBytes(payload.GetString()!),md},null)!;
            if(job.TryGetProperty("append",out var additions))foreach(var row in additions.EnumerateArray())
                type.GetMethod("Append")!.Invoke(writer,new object[]{row.GetProperty("table").GetInt32(),row.GetProperty("token").GetInt32(),row.GetProperty("values").EnumerateArray().Select(x=>x.GetUInt32()).ToArray()});
            object?[] parameters={job.GetProperty("strings").GetInt32(),job.GetProperty("blobs").GetInt32(),job.GetProperty("guids").GetInt32(),null};
            byte[] output=(byte[])type.GetMethod("Write")!.Invoke(writer,parameters)!;
            using(var f=new FileStream(job.GetProperty("out").GetString()!,FileMode.CreateNew))f.Write(output);
        }
        results.Add(new{name,status="COMPLETED",widths,counts});
    }
    catch(Exception e)
    {
        while(e.InnerException!=null)e=e.InnerException;
        results.Add(new{name,status="REJECTED",exception=e.GetType().FullName,message=e.Message});
    }
}
if(File.Exists(args[2]))throw new IOException("Never overwrite results");
File.WriteAllText(args[2],JsonSerializer.Serialize(results,new JsonSerializerOptions{WriteIndented=true}));
Console.WriteLine($"JOBS_RECORDED {results.Count}");
