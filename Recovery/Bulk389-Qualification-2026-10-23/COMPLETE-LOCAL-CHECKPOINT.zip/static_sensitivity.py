from audit_candidate import *
import subprocess
V=R/'audit/bulk350-root-verification-2026-10-22';checker=V/'reviewed-tools/verify_types_reviewed.py';spec=importlib.util.spec_from_file_location('reviewed',checker);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
d=json.loads((Q/'targets-reviewed.json').read_text('utf-8'));controls=[]
def ins(a,op):return next(i for i in a['instructions'] if i['opcode']==op)
def negative(name,token,change):
 a=copy.deepcopy(next(x for x in d['methods'] if x['token']==token));types=copy.deepcopy(d['types']);change(a,types)
 try:v.verify(a,types);detected=False;reason='FALSE_ACCEPT'
 except v.InvalidIL as e:detected=True;reason=str(e)
 except Exception as e:detected=False;reason='VERIFIER_ERROR '+str(e)
 req(detected,name);controls.append(dict(name=name,detected=detected,reason=reason))
negative('wrong-constrained-type','0x06000088',lambda a,t:ins(a,'constrained.')['operand'].update(type='System.Int32'))
negative('wrong-constrained-return','0x06000088',lambda a,t:next(i for i in a['instructions'] if i['opcode']=='callvirt' and i['operand']['owner']=='System.Enum')['operand'].update(ret='System.Int32'))
negative('prefix-bypass','0x06000088',lambda a,t:a['instructions'][0].update(opcode='br',operand={'target':ins(a,'constrained.')['offset']+6}))
def remove_interfaces(a,t):
 for name in t:
  if name.startswith('TMPro.Examples.TextMeshProFloatingText/<DisplayTextMeshProFloatingText>'):t[name]['interfaces']=[]
negative('missing-coroutine-interfaces','0x06000798',remove_interfaces)
negative('wrong-coroutine-interface','0x06000798',lambda a,t:next(i for i in a['instructions'] if i['opcode']=='callvirt' and i['operand'].get('name')=='StartCoroutine')['operand'].update(args=['System.IFormatProvider']))
negative('non-type-ldtoken','0x06000069',lambda a,t:ins(a,'ldtoken').update(operand={'method':'NotAType'}))
negative('stack-underflow','0x060004A9',lambda a,t:a['instructions'][0].update(opcode='pop',operand=None))
negative('maxstack-zero','0x060004A9',lambda a,t:a.update(maxStack=0))
negative('wrong-instantiate-Device','0x060006B4',lambda a,t:next(i for i in a['instructions'] if i['opcode']=='call' and i['operand'].get('name')=='Instantiate')['operand'].update(args=['Device'],ret='Device'))
negative('wrong-event-local','0x06000735',lambda a,t:a['locals'].__setitem__(3,'TMPro.TMP_TextEventHandler/CharacterSelectionEvent'))
negative('wrong-coroutine-field-owner','0x06000802',lambda a,t:next(i for i in a['instructions'] if i['opcode']=='stfld' and i['operand'].get('identity','').endswith('::<>2__current'))['operand'].update(owner='TMPro.Examples.VertexShakeA/<AnimateVertexColors>d__11'))
report=dict(scope='STATIC_CHECKER_SENSITIVITY_ONLY',candidate_sha256=sha((Q/'candidates/candidate1.dll').read_bytes()),checker_sha256=sha(checker.read_bytes()),controls=controls,all_detected=True,semantic_equivalence=False)
(Q/'STATIC-SENSITIVITY.json').write_text(json.dumps(report,indent=2)+'\n','utf-8')
# An actual-byte private-call mutant remains type-correct but must fail access checks.
b=bytearray((Q/'candidates/candidate1.dll').read_bytes());dn=dnfile.dnPE(data=b);row=dn.net.mdtables.MethodDef.rows[0x507-1];off=dn.get_offset_from_rva(row.Rva);span=h.parse_raw_method_body_span(b,off);start=off+span[1];cil=b[start:start+span[2]];needle=b'\x6f\xe9\x03\x00\x06';req(cil.count(needle)==1,'specific public-wrapper call');at=start+cil.index(needle);b[at+1]=0xeb
mutant=Q/'candidates/rejected-private-access.dll';req(not mutant.exists(),'fresh mutant');mutant.write_bytes(b)
argv=list(map(str,[R/'.local/dotnet10/dotnet.exe',V/'reviewed-tools/member-bin/MemberAccess.dll',mutant,V/'authentic-support',Q/'candidates/construction1.json',Q/'PRIVATE-ACCESS-MUTANT.json']));res=subprocess.run(argv,cwd=R,capture_output=True,timeout=30);(Q/'logs/private-mutant.stdout').write_bytes(res.stdout);(Q/'logs/private-mutant.stderr').write_bytes(res.stderr)
a=json.loads((Q/'PRIVATE-ACCESS-MUTANT.json').read_text('utf-8'));req(res.returncode==2 and a['rejected']==1 and a['unresolved']==0,'actual private-access mutant');(Q/'PRIVATE-ACCESS-CONTROL.json').write_text(json.dumps(dict(argv=argv,exit=res.returncode,candidate_sha256=report['candidate_sha256'],mutant_sha256=sha(b),detected=True,rejected=a['rejected']),indent=2)+'\n','utf-8');print('STATIC_CONTROLS_PASS model=11 actual_private_access=1')
