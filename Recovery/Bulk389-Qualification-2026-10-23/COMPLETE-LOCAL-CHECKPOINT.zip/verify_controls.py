from audit_candidate import *
import subprocess,time
b=(Q/'candidates/candidate1.dll').read_bytes();dc=dnfile.dnPE(data=b);pe=h.parse_pe_and_cli(b);md=h.parse_metadata_root(b,pe['meta_off'],pe['meta_size']);raw,loc,_,_=decode(md['streams']['#~']['bytes']);start=md['streams']['#~']['abs_offset'];controls=[]
def reject(name,mutant):
 start_time=time.monotonic()
 try:audit(mutant);detected=False;why='FALSE_ACCEPT'
 except Exception as e:detected=True;why=type(e).__name__+': '+str(e)
 controls.append(dict(name=name,detected=detected,reason=why,sha256=sha(mutant),elapsed_seconds=time.monotonic()-start_time));req(detected,name)
mutations=[('old-non-target-byte',1200,1),('target-initlocals',dc.get_offset_from_rva(dc.net.mdtables.MethodDef.rows[0x3f9-1].Rva),0x10),('appended-member-owner',start+loc[10,1317,0][0],1),('wide-field-blob-highword',start+loc[4,1,2][0]+2,1),('wide-method-blob-highword',start+loc[6,1,4][0]+2,1),('new-locals-highword',start+loc[17,2095,0][0]+2,1),('new-typeref-scope',start+loc[1,178,0][0],1),('wrong-heap-size-flag',md['streams']['#~']['abs_offset']+6,4)]
for name,at,mask in mutations:
 m=bytearray(b);m[at]^=mask;reject(name,bytes(m))
dot=R/'.local/dotnet10/dotnet.exe';patch=Q/'source/bin/Release/net10.0/Bulk388.dll';parent_path=R/'audit/native93-codex-2026-10-17/verification-2026-10-17/candidates/candidate1.dll';runs=[]
for name,source,out,report in [('wrong-parent',R/'audit/bulk350-root-verification-2026-10-22/r6-candidate.dll',Q/'candidates/rejected-parent.dll',Q/'candidates/rejected-parent.json'),('existing-candidate',parent_path,Q/'candidates/candidate1.dll',Q/'candidates/rejected-existing.json')]:
 before={p:sha(p.read_bytes()) for p in (out,report) if p.exists()};argv=list(map(str,[dot,patch,source,out,report]));res=subprocess.run(argv,cwd=R,capture_output=True,timeout=20)
 (Q/'logs'/f'construction-control-{name}.stdout').write_bytes(res.stdout);(Q/'logs'/f'construction-control-{name}.stderr').write_bytes(res.stderr)
 req(res.returncode==3,'patcher nonzero rejection '+name)
 req(all(p.exists() and sha(p.read_bytes())==s for p,s in before.items()),'existing file modified')
 req(all(not p.exists() for p in (out,report) if p not in before),'rejected candidate created')
 runs.append(dict(name=name,argv=argv,exit=res.returncode,outputs_unchanged=True,stderr=res.stderr.decode(errors='replace')))
report=dict(state='PASS_SCOPED_NEGATIVE_CONTROLS',candidate_sha256=sha(b),isolation_controls=controls,construction_controls=runs,deterministic_second_build=b==(Q/'candidates/candidate2.dll').read_bytes(),game_behavior=False)
req(report['deterministic_second_build'],'determinism');req(not (Q/'NEGATIVE-CONTROLS.json').exists(),'fresh report');(Q/'NEGATIVE-CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n','utf-8');print('CONTROLS_PASS isolation=8 construction=2 deterministic=True')
