using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text.Json;
using Mono.Cecil;
using Mono.Cecil.Cil;
using EOp=System.Reflection.Emit.OpCodes;
using COp=Mono.Cecil.Cil.OpCodes;
static class Program
{
 public sealed class P {public int Id;public D Damage=null!;}
 public sealed class D {public P Parent=null!;public bool Explode(){Trace.Add("explode:"+Parent.Id);if(Mode>=2)Parent.Id=42;return true;}}
 static List<string> Trace=new();static int Mode;static IntPtr Current;
 public static void Audio(P p){Trace.Add("audio:"+p.Id);if((Mode&1)!=0)p.Id=23;}
 public static void Destroy(P p)=>Trace.Add("destroy:"+p.Id);
 [DllImport("kernel32",SetLastError=true)]static extern IntPtr VirtualAlloc(IntPtr address,nuint size,uint allocation,uint protection);
 [DllImport("kernel32",SetLastError=true)]static extern bool VirtualFree(IntPtr address,nuint size,uint type);
 [UnmanagedFunctionPointer(CallingConvention.Winapi)]delegate void NativeVoid(IntPtr instance,IntPtr method);
 [UnmanagedFunctionPointer(CallingConvention.Winapi)]delegate int NativeExplosion(IntPtr instance,IntPtr method);
 static string Sha(byte[] b)=>Convert.ToHexString(SHA256.HashData(b)).ToLowerInvariant();
 static Action<P> Translate(MethodDefinition m,string mutant)
 {
  var dm=new DynamicMethod("actual_CIL_"+mutant,typeof(void),new[]{typeof(P)},typeof(Program).Module,true);var il=dm.GetILGenerator();
  var labels=m.Body.Instructions.ToDictionary(i=>i,i=>il.DefineLabel());
  var ops=typeof(EOp).GetFields(BindingFlags.Static|BindingFlags.Public).Where(f=>f.FieldType==typeof(System.Reflection.Emit.OpCode)).Select(f=>(System.Reflection.Emit.OpCode)f.GetValue(null)!).ToDictionary(o=>o.Value);
  foreach(var v in m.Body.Variables){Type t=v.VariableType.FullName switch{"System.Int32"=>typeof(int),"System.Boolean"=>typeof(bool),"System.Object"=>typeof(object),"Projectile"=>typeof(P),_=>throw new NotSupportedException(v.VariableType.FullName)};il.DeclareLocal(t);}
  foreach(var i in m.Body.Instructions)
  {
   il.MarkLabel(labels[i]);var op=ops[i.OpCode.Value];
   if(mutant=="signed-ranges"&&i.OpCode==COp.Ble_Un)op=EOp.Ble;
   if(mutant=="signed-ranges"&&i.OpCode==COp.Bgt_Un)op=EOp.Bgt;
   if(i.Operand is FieldReference f)
   {string name=f.MetadataToken.ToInt32() switch{0x0400054C=>nameof(P.Id),0x0400054E=>nameof(P.Damage),_=>throw new NotSupportedException(f.FullName)};il.Emit(op,typeof(P).GetField(name)!);}
   else if(i.Operand is MethodReference call)
   {
    MethodInfo mapped=call.MetadataToken.ToInt32() switch{0x0600010C=>typeof(D).GetMethod(nameof(D.Explode))!,0x060003EB=>typeof(Program).GetMethod(nameof(Audio))!,0x060003EC=>typeof(Program).GetMethod(nameof(Destroy))!,_=>throw new NotSupportedException(call.FullName)};
    if(mutant=="omit-audio"&&call.MetadataToken.ToInt32()==0x060003EB)il.Emit(EOp.Pop);
    else il.Emit(mapped.IsStatic?EOp.Call:op,mapped);
   }
   else if(i.Operand is Instruction target)il.Emit(op,labels[target]);
   else if(i.Operand is VariableDefinition local)il.Emit(op,(short)local.Index);
   else if(i.Operand is int n)il.Emit(op,n);
   else if(i.Operand is sbyte tiny)il.Emit(op,tiny);
   else if(i.Operand==null)il.Emit(op);
   else throw new NotSupportedException(i.ToString());
  }
  return dm.CreateDelegate<Action<P>>();
 }
 static void Main(string[] args)
 {
  if(args.Length!=3)throw new ArgumentException("candidate GameAssembly fresh-result");
  if(!OperatingSystem.IsWindows()||RuntimeInformation.ProcessArchitecture!=Architecture.X64)throw new PlatformNotSupportedException("UNSUPPORTED: Windows x64 native oracle");
  byte[] candidate=File.ReadAllBytes(args[0]),ga=File.ReadAllBytes(args[1]);
  if(Sha(candidate)!="9c8cefd7b348a254a7c41ec48d95d9c5a1047eb6e17ad6eb45eb03b7351ce1c1"||Sha(ga)!="9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d")throw new Exception("Input SHA mismatch");
  using var a=AssemblyDefinition.ReadAssembly(new MemoryStream(candidate));var method=(MethodDefinition)a.MainModule.LookupToken(0x060003E9);var actual=Translate(method,"none");var signed=Translate(method,"signed-ranges");var omitted=Translate(method,"omit-audio");
  // PEReader supplies original .text file mapping. Oracle body is copied unmodified.
  using var pe=new System.Reflection.PortableExecutable.PEReader(new MemoryStream(ga));var section=pe.PEHeaders.SectionHeaders.Single(s=>0x37b090>=s.VirtualAddress&&0x37b090<s.VirtualAddress+s.SizeOfRawData);int at=section.PointerToRawData+0x37b090-section.VirtualAddress;byte[] native=ga.AsSpan(at,0x54).ToArray();
  IntPtr mapped=VirtualAlloc(new IntPtr(0x180000000),0x400000,0x3000,0x40);if(mapped!=new IntPtr(0x180000000))throw new Exception("UNSUPPORTED: fixed native oracle mapping errno="+Marshal.GetLastWin32Error());
  IntPtr instance=Marshal.AllocHGlobal(0x100),damage=Marshal.AllocHGlobal(0x100);Current=instance;
  NativeExplosion explode=(p,m)=>{int id=Marshal.ReadInt32(Current,0x24);Trace.Add("explode:"+id);if(Mode>=2)Marshal.WriteInt32(Current,0x24,42);return 1;};
  NativeVoid audio=(p,m)=>{Trace.Add("audio:"+Marshal.ReadInt32(p,0x24));if((Mode&1)!=0)Marshal.WriteInt32(p,0x24,23);};
  NativeVoid destroy=(p,m)=>Trace.Add("destroy:"+Marshal.ReadInt32(p,0x24));
  void Stub(long address,Delegate callback){byte[] stub=new byte[12];stub[0]=0x48;stub[1]=0xb8;BitConverter.GetBytes(Marshal.GetFunctionPointerForDelegate(callback).ToInt64()).CopyTo(stub,2);stub[10]=0xff;stub[11]=0xe0;Marshal.Copy(stub,0,new IntPtr(address),stub.Length);}
  try
  {
   Marshal.Copy(native,0,new IntPtr(0x18037b090),native.Length);Stub(0x180311890,explode);Stub(0x18037a410,audio);Stub(0x18037b200,destroy);
   var oracle=Marshal.GetDelegateForFunctionPointer<NativeVoid>(new IntPtr(0x18037b090));var records=new List<object>();int signedDiff=0,omittedDiff=0;
   int[] ids=new[]{int.MinValue,-26,-10,-1}.Concat(Enumerable.Range(0,41)).Concat(new[]{int.MaxValue}).ToArray();
   foreach(int id in ids)for(Mode=0;Mode<4;Mode++)
   {
    Marshal.Copy(new byte[0x100],0,instance,0x100);Marshal.WriteInt32(instance,0x24,id);Marshal.WriteIntPtr(instance,0x30,damage);Trace.Clear();oracle(instance,IntPtr.Zero);string[] expected=Trace.ToArray();int expectedId=Marshal.ReadInt32(instance,0x24);
    P Build(){var p=new P{Id=id};p.Damage=new D{Parent=p};return p;}
    var p=Build();Trace.Clear();actual(p);string[] observed=Trace.ToArray();if(!expected.SequenceEqual(observed)||p.Id!=expectedId)throw new Exception("Native/CIL divergence id="+id+" mode="+Mode);
    Trace.Clear();var q=Build();signed(q);if(!Trace.SequenceEqual(expected)||q.Id!=expectedId)signedDiff++;
    Trace.Clear();q=Build();omitted(q);if(!Trace.SequenceEqual(expected)||q.Id!=expectedId)omittedDiff++;
    records.Add(new{id,mode=Mode,trace=observed,final_id=p.Id});
   }
   if(signedDiff==0||omittedDiff==0)throw new Exception("Semantic controls failed");
   var result=new{state="PASS_CONTROLLED_ACTUAL_NATIVE_VS_CANDIDATE_CIL_NORMAL_PATHS",candidate_sha256=Sha(candidate),method_token="0x060003E9",original_gameassembly_sha256=Sha(ga),original_native_va="0x18037b090",original_native_bytes=native.Length,original_native_body_sha256=Sha(native),cases=records.Count,actual_candidate_cil_executed=true,actual_original_native_executed=true,semantic_model_mutants=new[]{new{name="signed-ranges",divergent_cases=signedDiff},new{name="omit-audio",divergent_cases=omittedDiff}},null_and_exception_paths="NOT_EXECUTED",particle_audio_destroy_internals="CONTROLLED_CALLBACKS_UNPROVEN",whole_game_qualified=false,records};
   if(File.Exists(args[2]))throw new IOException("Fresh report only");File.WriteAllText(args[2],JsonSerializer.Serialize(result,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine($"NATIVE_CIL_COLLISION_PASS cases={records.Count} signed_diffs={signedDiff} omitted_diffs={omittedDiff}");
   GC.KeepAlive(explode);GC.KeepAlive(audio);GC.KeepAlive(destroy);GC.KeepAlive(oracle);
  }
  finally{Marshal.FreeHGlobal(instance);Marshal.FreeHGlobal(damage);VirtualFree(mapped,0,0x8000);}
 }
}
