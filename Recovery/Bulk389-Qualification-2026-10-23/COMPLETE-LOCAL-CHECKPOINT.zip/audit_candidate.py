"""Independent reopened metadata/body isolation, including heap-column widening.
Never executes game CIL and never treats construction assertions as evidence.
"""
from pathlib import Path
import sys,json,hashlib,struct,importlib.util,copy
sys.dont_write_bytecode=True
BASE=Path(__file__).resolve().parent;R=BASE.parents[1]
Q=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else BASE
sys.path.insert(0,str(R/'audit/stage9-native3/python-deps'));import dnfile
sys.path.insert(0,str(BASE/'width-check'));from width_fixtures import SC,CG,width
spec=importlib.util.spec_from_file_location('historical_parsers',R/'audit/native111-publication-2026-10-20/repository/scripts/actions/static_gates.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
plan=json.loads((Q/'source/IMPLEMENTATION-PLAN.json').read_text('utf-8'));meta=json.loads((Q/'source/METADATA-ADDITIONS.json').read_text('utf-8'))
targets={int(x['token'],16):x for x in plan['targets']};constants={x['name']:x['token'] for x in meta['constants']}
parent=(R/'audit/native93-codex-2026-10-17/verification-2026-10-17/candidates/candidate1.dll').read_bytes()
def req(ok,why):
 if not ok:raise ValueError(why)
def sha(b):return hashlib.sha256(b).hexdigest()
req(sha(parent)==plan['parent_sha256'],'parent hash')
def enc(n):return bytes([n]) if n<128 else bytes([0x80|(n>>8),n&255]) if n<16384 else bytes([0xc0|(n>>24),(n>>16)&255,(n>>8)&255,n&255])
def decode(p):
 flags=p[6];valid=struct.unpack_from('<Q',p,8)[0];at=24;counts={}
 for t in range(64):
  if valid>>t&1:counts[t]=struct.unpack_from('<I',p,at)[0];at+=4
 rows={};locations={};widths={}
 for t,n in counts.items():
  rows[t]=[];widths[t]=sum(width(c,flags,counts) for c in SC[t])
  for rid in range(1,n+1):
   row=[]
   for col,c in enumerate(SC[t]):
    w=width(c,flags,counts);req(at+w<=len(p),'bounded table column');row.append(int.from_bytes(p[at:at+w],'little'));locations[t,rid,col]=(at,w);at+=w
   rows[t].append(row)
 return rows,locations,widths,p[at:]
def audit(candidate,settings=meta):
 req(len(candidate)>len(parent),'truncated candidate')
 pp=h.parse_pe_and_cli(parent);pc=h.parse_pe_and_cli(candidate);allowed=set()
 for off in [pp['sections'][-1]['header_offset']+8,pp['sections'][-1]['header_offset']+16,pp['opt_off']+8,pp['opt_off']+56,pp['opt_off']+64,pp['cli_off']+8,pp['cli_off']+12]:allowed.update(range(off,off+4))
 req(all(a==b or i in allowed for i,(a,b) in enumerate(zip(parent,candidate))),'unauthorized original-prefix modification')
 mp=h.parse_metadata_root(parent,pp['meta_off'],pp['meta_size']);mc=h.parse_metadata_root(candidate,pc['meta_off'],pc['meta_size'])
 req(mp['valid_mask']==mc['valid_mask'] and mp['sorted_mask']==mc['sorted_mask'],'metadata masks')
 req(mc['heap_sizes']==mp['heap_sizes']|4,'exact Blob HeapSizes widening')
 req(mp['streams'].keys()==mc['streams'].keys(),'stream set')
 for name in mp['streams']:
  if name=='#~':continue
  a=mp['streams'][name]['bytes'];b=mc['streams'][name]['bytes'];req(b[:len(a)]==a,'heap prefix '+name)
  if name=='#GUID':req(a==b,'GUID heap unchanged')
 rp,lp,wp,tp=decode(mp['streams']['#~']['bytes']);rc,lc,wc,tc=decode(mc['streams']['#~']['bytes']);req(tp==tc,'table trailing bytes')
 dp=dnfile.dnPE(data=parent);dc=dnfile.dnPE(data=candidate)
 expected_counts={1:plan['typeref_count_after'],10:plan['memberref_count_after'],17:plan['standalone_count_after'],27:plan['typespec_count_after'],43:plan['methodspec_count_after']};numeric=0;relocated=0
 for a,b in zip(dp.net.mdtables.tables_list,dc.net.mdtables.tables_list):
  t=a.number;req(t==b.number and a.row_size==wp[t] and b.row_size==wc[t],'dnfile row-width agreement')
  req(b.num_rows==expected_counts.get(t,a.num_rows),'row count '+a.name)
  for rid,(old,new) in enumerate(zip(rp[t],rc[t]),1):
   if t==6 and (0x06000000|rid) in targets:
    req(old[1:]==new[1:] and old[0]!=new[0],'target identity/RVA');relocated+=1
   else:req(old==new,'old numeric columns '+a.name+':'+str(rid))
   numeric+=len(old)
 for x in settings['member_definitions']:
  rid=x['token']&0xffffff;row=dc.net.mdtables.MemberRef.rows[rid-1]
  sig=next((y['signature'] for y in settings['emitted_field_signatures'] if y['token']==x['token']),x['signature'])
  req(rc[10][rid-1][0]==x['class_code'],'new member owner')
  req(str(row.Name)==(x['new_name'] or x['template_name']) and row.Signature.value.hex()==sig,'new member name/signature')
  tag=x['class_code']&7;owner=x['class_code']>>3
  req(tag in (1,4),'new member owner tag')
  if tag==4:pin=dc.net.mdtables.TypeSpec.rows[owner-1].Signature.value.hex()
  else:
   tr=dc.net.mdtables.TypeRef.rows[owner-1];pin=str(tr.TypeNamespace)+'.'+str(tr.TypeName)
  req(pin==x['owner_pin'],'new member declaring identity')
 for i,x in enumerate(settings['local_blobs'],1766):req(dc.net.mdtables.StandAloneSig.rows[i-1].Signature.value.hex()==x,'new locals')
 for i,x in enumerate(settings['type_blobs'],174):req(dc.net.mdtables.TypeSpec.rows[i-1].Signature.value.hex()==x,'new TypeSpec')
 for x in settings['additional_typerefs']:
  rid=x['token']&0xffffff;req(rc[1][rid-1][0]==(x['resolution_scope_rid']<<2)|2,'TypeRef scope')
  tr=dc.net.mdtables.TypeRef.rows[rid-1];req(str(tr.TypeName)==x['name'] and str(tr.TypeNamespace)==x['namespace'],'TypeRef name')
 ms=dc.net.mdtables.MethodSpec.rows
 for rid,ref,sig in [(186,126,'0a011180dc'),(187,484,'0a01128210')]:
  row=ms[rid-1];req(row.Method.row_index==ref and row.Method.table.name=='MemberRef' and row.Instantiation.value.hex()==sig,'MethodSpec baseline append')
 for i,x in enumerate(settings['added_methodspecs'],188):
  row=ms[i-1];req(row.Method.table.name=='MethodDef' and row.Method.row_index==(x['definition']&0xffffff) and row.Instantiation.value.hex()==x['instantiation'],'MethodSpec game append')
 blobs=[bytes.fromhex(x) for x in settings['local_blobs'][:293]]+[bytes.fromhex(x['signature']) for x in settings['emitted_field_signatures']]+[bytes.fromhex(x) for x in settings['type_blobs'][:5]]+[bytes.fromhex('0a011180dc'),bytes.fromhex('0a01128210')]+[bytes.fromhex(x['instantiation']) for x in settings['added_methodspecs']]
 blobs += [bytes.fromhex(x) for x in settings['type_blobs'][5:]]+[bytes.fromhex(x['signature']) for x in settings['member_definitions'][180:]]+[bytes.fromhex(x) for x in settings['local_blobs'][293:]]
 req(mc['streams']['#Blob']['bytes']==mp['streams']['#Blob']['bytes']+b''.join(enc(len(x))+x for x in blobs),'exact appended Blob payload')
 req(len(mc['streams']['#Blob']['bytes'])==settings['expected_blob_heap_bytes'],'Blob byte extent')
 names=b''.join(x['new_name'].encode()+b'\0' for x in settings['member_definitions'][:180] if x['new_name'])
 for tr in settings['additional_typerefs']:names+=tr['name'].encode()+b'\0'+tr['namespace'].encode()+b'\0'
 names+=b''.join(x['new_name'].encode()+b'\0' for x in settings['member_definitions'][180:] if x['new_name'])
 req(mc['streams']['#Strings']['bytes']==mp['streams']['#Strings']['bytes']+names,'exact appended Strings')
 us=mp['streams']['#US']['bytes']
 for x in settings['user_strings']:
  req(x['token']==0x70000000+len(us),'US offset');text=x['value'];data=text.encode('utf-16-le');flag=int(any(ord(c)>255 or 1<=ord(c)<=8 or 14<=ord(c)<=31 or ord(c) in (0x27,0x2d,0x7f) for c in text));payload=enc(len(data)+1)+data+bytes([flag]);req(payload.hex()==x['encoded_bytes'],'US payload');us+=payload
 req(mc['streams']['#US']['bytes']==us,'exact US heap')
 unchanged=zero=eh=0;records=[]
 for rid,(a,b) in enumerate(zip(dp.net.mdtables.MethodDef.rows,dc.net.mdtables.MethodDef.rows),1):
  token=0x06000000|rid
  if not a.Rva:req(not b.Rva and token not in targets,'zero-RVA method');unchanged+=1;zero+=1;continue
  ao=dp.get_offset_from_rva(a.Rva);bo=dc.get_offset_from_rva(b.Rva);ab=h.parse_raw_method_body_span(parent,ao);bb=h.parse_raw_method_body_span(candidate,bo)
  if token not in targets:req(parent[ao:ao+ab[0]]==candidate[bo:bo+bb[0]],'non-target body/header/EH');unchanged+=1;continue
  t=targets[token];c=t.get('local_constant');expected=constants[c] if c and c!='0' else int(t['new_local_sig_token'],16) if t.get('new_local_sig_token') else ab[4]
  req(bb[4]==expected,'target local token '+hex(token));req(bo>=len(parent) and bo%4==0,'appended/aligned target');req(struct.unpack_from('<H',candidate,bo)[0]&0x10,'InitLocals');req(parent[ao:ao+ab[0]]==candidate[ao:ao+ab[0]],'old target slot')
  code=candidate[bo+bb[1]:bo+bb[1]+bb[2]];req(code!=parent[ao+ab[1]:ao+ab[1]+ab[2]],'target unchanged')
  req(bb[3]==t['new_declared_max_stack'],'target declared MaxStack')
  for clause in bb[8]:
   _,_,flags,ts,tl,hs,hl,ct=clause;req(flags==2 and ct==0 and tl>0 and hl>0 and ts+tl==hs and hs+hl<=len(code) and code[hs+hl-1]==0xdc,'finally extent')
  eh+=bb[7];records.append(dict(token=hex(token),body_sha256=sha(candidate[bo:bo+bb[0]]),finally_regions=bb[7]))
 req(len(records)==relocated==len(targets) and unchanged==2317-len(targets) and eh==plan['expected_finally_regions'],'scope counts')
 return dict(state='PASS_SCOPED_REOPENED_BYTE_AND_METADATA_ISOLATION',candidate_sha256=sha(candidate),target_methods=len(targets),unchanged_non_target_methods=unchanged,unchanged_non_target_bodies=unchanged-zero,zero_rva_methods=zero,preexisting_numeric_columns_checked=numeric,finally_regions=eh,blob_bytes=len(mc['streams']['#Blob']['bytes']),table_widths=[dict(table=t,old=wp[t],new=wc[t]) for t in wp],methods=records,game_cil_executed=False,native_semantics='UNPROVEN')
if __name__=='__main__':
 b=(Q/'candidates/candidate1.dll').read_bytes();result=audit(b)
 out=Q/'ISOLATION-FIRST.json';req(not out.exists(),'fresh result');out.write_text(json.dumps(result,indent=2)+'\n','utf-8');print(json.dumps({k:v for k,v in result.items() if k not in ('table_widths','methods')}))
