int f(void){return deliberately_undefined_identifier;}
