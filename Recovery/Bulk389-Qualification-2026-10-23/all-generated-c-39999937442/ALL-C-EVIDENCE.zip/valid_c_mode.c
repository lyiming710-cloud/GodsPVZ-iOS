#ifdef __cplusplus
#error Must_compile_as_C
#endif
int f(void){return 1;}
