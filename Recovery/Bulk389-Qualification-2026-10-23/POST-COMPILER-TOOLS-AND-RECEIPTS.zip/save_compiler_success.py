from pathlib import Path
import json,shutil,hashlib,zipfile,subprocess,datetime
Q=Path(__file__).resolve().parent;repo=Q.parents[1]/'audit/repo-native113';D=repo/'Recovery/Bulk389-Qualification-2026-10-23';A=Q/'actions-39957635669';out=D/'compiler-39957635669';out.mkdir(exist_ok=False)
for p in (A/'bulk389-linux').rglob('*'):
 if p.is_file():dst=out/p.relative_to(A/'bulk389-linux');dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
shutil.copy2(A/'bulk389-restore-receipt.json',out/'bulk389-restore-receipt.json');shutil.copy2(Q/'COMPILER-READBACK-39957635669.json',out/'INDEPENDENT-READBACK.json');shutil.copy2(Q/'FULL-WORKFLOW-PREFLIGHT.json',D/'FULL-WORKFLOW-PREFLIGHT.json');shutil.copy2(Q/'GIT-STAGED-VERIFICATION.json',D/'FIRST-COMMIT-GIT-BLOB-VERIFICATION.json')
gh=r'C:\Program Files\GitHub CLI\gh.exe';run=json.loads(subprocess.check_output([gh,'run','view','39957635669','-R','lyiming710-cloud/GodsPVZ-iOS','--json','status,conclusion,headSha,url,jobs']));assert run['conclusion']=='success';(out/'GITHUB-RUN.json').write_text(json.dumps(run,indent=2)+'\n','utf-8')
result=json.loads((D/'CURRENT-RESULT.json').read_text('utf-8'));result.update(state='LINUX_GAME_TU_COMPILER_PASS_NOT_FORMAL_GAME_QUALIFICATION',full_cpp_errors_recounted=True,current_linux_compiler=dict(run_id=39957635669,source_commit=run['headSha'],il2cpp_exit=0,generated_game_tus=14,failed_game_tus=0,diagnostics=0,methods_with_compiler_errors=0,mapped_methods=2267,all_generated_system_units_compiled=False,clang_version='18.1.3',syntax_only=True),real_unity_xcode_ipa_workflow='PREPARED_NOT_DISPATCHED_AT_THIS_SNAPSHOT');(D/'CURRENT-RESULT.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n','utf-8')
p=D/'README.md';t=p.read_text('utf-8');t+='''

## 本轮完整 Linux 编译结果已回收

[Actions 39957635669](https://github.com/lyiming710-cloud/GodsPVZ-iOS/actions/runs/39957635669) 在源码提交 1cc0761d6378c8d00e4d9c67e9c322eba6e52614 上成功结束。R4 SHA 一致，IL2CPP exit=0；此次生成 756 个 C++ 文件，游戏部分为 14 个 TU，14/14 均 Clang18 语法检查 exit=0、error=0。映射方法仍是 2,267，与 R6 相同。旧 38 个报错方法在这个 Linux 门下归零；源码分片从 16 降为 14，不是少检查两个现有文件。

独立回读了全部 14 个原始日志，并在生成源码压缩包中逐一核验源文件 SHA 和 global-metadata SHA。只编译了全部游戏 TU，没有宣称其余 742 个系统 C++ 也通过，更没有宣称 Apple 链接、设备执行或全方法行为通过。原始报告、日志、逐方法映射和独立回读保存于 compiler-39957635669/。生成全 C++ 压缩包 152,296,115 字节，超过 Git 单文件限制，单独保存到本轮 Release，不塞入 Git blob。

下一流程为 bulk389-real-ios-ipa.yml：把这个固定候选绑定到同次运行的包，经精确 Unity 2022.3.44f1c1 重新导出，再由 macOS-15 / Xcode16.4 构建 ARM64 未签名应用。保留失败日志、归还 Personal 席位，账号日志仅上传脱敏副本。历史 helper 来自固定 64b86ed 提交并独立放在 ios-support/；不替换仓库原 Assets/Editor 工具。历史 workflow 引用的两个 IPA 脚本不存在，已改用新标准库打包器，检查主程序及 UnityFramework 的物理 iOS ARM64、无代码签名／provision、ZIP CRC，以及 IPA metadata 与本次 Xcode 导出逐字节一致。该流程是否真正完成，以后续运行实际产物为准。
''';p.write_text(t,'utf-8')
p=repo/'Recovery/REMAINING-WORK-2026-10-23.md';p.write_text('''# 当前剩余工作：Bulk389 R4，2026-10-23

**已知游戏 C++ 报错在 Linux 预检查中已归零，真实 Unity / Apple / IPA 门仍需完成。**

| 门 | 当前已观测结果 | 范围 |
| --- | --- | --- |
| 最新 Linux 运行 | 39957635669，成功 | 固定 R4，代码提交 1cc0761… |
| IL2CPP | exit 0 | 756 个生成 C++，其中 14 个游戏 TU |
| 游戏 TU Clang18 语法检查 | 14 / 14 通过，0 条错误，0 个报错方法 | 其余 742 个系统 CPP 未在此门编译 |
| 历史对照 | R6 原 38 个报错方法 / 1,616 条诊断 | 在当前 Linux 门下均归零；不能据此推断 Apple 也通过 |
| 新候选静态集成 | 389 方法类型通过；218 个新增引用的解析及原始泛型参数检查通过 | 1,928 个非目标方法保持原样，201 finally |
| 新入口受控行为 | 184 正常路径 native vs 实际 CIL 通过 | 仅 Collision_Wall；依赖内部及异常仍未证明 |
| 当前另一候选的 50 方法队列 | 14 通过 / 14 待执行 / 22 上下文缺项 | Bulk250-R2，另外 2 getter 独立计数；不与本轮混算 |
| 真实 Unity / Xcode / IPA | 新流程已准备，待真实运行产物 | 无可宣称合格或真机验证的 IPA |

完整证据见 Bulk389-Qualification-2026-10-23/。目前不能再说“Linux 还剩 38 个报错方法”，也不能说“整个项目已经没有问题”。剩余重点是持证导出、真实 Apple 全编译／链接、未签名打包以及引擎和设备／行为验收。
''','utf-8')
evidence=Q/'BULK389-R4-COMPILER-EVIDENCE.zip'
with zipfile.ZipFile(evidence,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in out.rglob('*'):
  if p.is_file():z.write(p,p.relative_to(out).as_posix())
notes=Q/'RELEASE-NOTES.md';notes.write_text('''Bulk389 R4 fixed-candidate diagnostic checkpoint. Candidate SHA-256 ef1992326d1ee494a389bc2c78bdfab131721434c0b08ab5f41dbc3e506c4e48.

IL2CPP conversion passed; all 14 generated game translation units passed Linux Clang18 syntax checks with zero errors in run 39957635669. Previous R6 had 38 error methods. This does not qualify all system C++ units, Apple compilation, Unity runtime, gameplay semantics or device execution. Real Unity/Xcode/IPA pipeline is the next gate.

Core checkpoint plus R4 supplement preserve every candidate/source/log revision and the initial false-accept evidence. 389 scoped static targets; 1,928 unchanged non-targets; 218 appended references checked against actual GenericParam tables. Only Collision_Wall has this round's 184 controlled original-native vs actual-CIL normal-path cases; external internals and exceptions remain unproven. No IPA in this release snapshot.
''','utf-8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifest=json.loads((D/'DELIVERY-MANIFEST.json').read_text('utf-8'));manifest['entries']=[dict(path=p.relative_to(D).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(D.rglob('*')) if p.is_file() and p.name!='DELIVERY-MANIFEST.json'];extra=[repo/'.github/workflows/bulk389-real-ios-ipa.yml']+[repo/'scripts/actions'/x for x in ['bind_bulk389_compiler_package.py','package_bulk389_ipa.py','sanitize_unity_evidence.py']];external={x['path']:repo/x['path'] for x in manifest['external_git_paths']};external.update({p.relative_to(repo).as_posix():p for p in extra})
for p in external.values():
 if p.suffix in ('.md','.py','.yml'):p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
manifest['external_git_paths']=[dict(path=k,bytes=p.stat().st_size,sha256=sha(p)) for k,p in sorted(external.items())];(D/'DELIVERY-MANIFEST.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n','utf-8');print('COMPILER_SUCCESS_ARCHIVED',len(manifest['entries']),'files evidence_zip',evidence.stat().st_size)
