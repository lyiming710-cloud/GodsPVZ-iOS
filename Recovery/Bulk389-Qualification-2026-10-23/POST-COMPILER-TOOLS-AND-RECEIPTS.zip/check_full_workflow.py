from pathlib import Path
import sys,re,ast,json,hashlib
Q=Path(__file__).resolve().parent;repo=Q.parents[1]/'audit/repo-native113';sys.path.insert(0,str(Q/'yaml-deps'));import yaml
path=repo/'.github/workflows/bulk389-real-ios-ipa.yml';d=yaml.load(path.read_text('utf-8'),Loader=yaml.BaseLoader);assert list(d['jobs'])==['conversion_binding','export','build_ipa'];assert d['jobs']['export']['needs']=='conversion_binding';assert d['jobs']['build_ipa']['needs']=='export';assert d['jobs']['build_ipa']['runs-on']=='macos-15'
count=0
for job in d['jobs'].values():
 for step in job['steps']:
  run=step.get('run','')
  for text in re.findall(r"<<'PY'\n(.*?)\nPY(?:\n|$)",run,re.S):ast.parse(text);count+=1
for file in ['bind_bulk389_compiler_package.py','package_bulk389_ipa.py','sanitize_unity_evidence.py']:ast.parse((repo/'scripts/actions'/file).read_text('utf-8'))
export=d['jobs']['export'];assert export['env']['TEST_DLL_SHA256']=='ef1992326d1ee494a389bc2c78bdfab131721434c0b08ab5f41dbc3e506c4e48'
assert any('public-evidence' in s.get('with',{}).get('path','') for s in export['steps'] if s.get('uses','').startswith('actions/upload-artifact'))
result=dict(scope='WORKFLOW_YAML_AND_EMBEDDED_PYTHON_SYNTAX_ONLY',workflow_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),jobs=list(d['jobs']),embedded_python_blocks_parsed=count,external_python_files_parsed=3,unity_xcode_executed=False)
out=Q/'FULL-WORKFLOW-PREFLIGHT.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n','utf-8');print('WORKFLOW_SYNTAX_PASS',result)
