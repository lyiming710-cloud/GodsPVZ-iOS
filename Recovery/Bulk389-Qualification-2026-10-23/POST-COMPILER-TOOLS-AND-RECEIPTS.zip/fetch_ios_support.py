from pathlib import Path
import subprocess,base64,concurrent.futures,hashlib,json
Q=Path(__file__).resolve().parent;root=Q/'ios-support-inputs';root.mkdir(exist_ok=False);gh=r'C:\Program Files\GitHub CLI\gh.exe'
paths=['Assets/Editor/GodsPVZPackageReferenceMigrator.cs','Assets/Editor/GodsPVZIOSBuild.cs','Recovery/package-script-map-editor.json','scripts/package_unsigned_ipa.mjs','scripts/validate_ipa.mjs']
def fetch(path):
 api='repos/lyiming710-cloud/GodsPVZ-iOS/contents/'+path+'?ref=64b86ed725c40e8e00cecd7a917f72bbed37777e';d=json.loads(subprocess.check_output([gh,'api',api]));raw=base64.b64decode(d['content']);p=root/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);return dict(path=path,git_blob=d['sha'],sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
rows=list(concurrent.futures.ThreadPoolExecutor(max_workers=4).map(fetch,paths));(root/'MANIFEST.json').write_text(json.dumps(dict(source_commit='64b86ed725c40e8e00cecd7a917f72bbed37777e',entries=rows),indent=2)+'\n','utf-8');print('IOS_SUPPORT_AUTHENTICATED',len(rows))
