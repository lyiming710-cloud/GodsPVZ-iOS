from pathlib import Path
import json,hashlib,tarfile,re
Q=Path(__file__).resolve().parent;root=Q/'actions-39957635669';p=root/'bulk389-linux';r=p/'results';report=json.loads((p/'BULK389-COMPILER-REPORT.json').read_text());rows=json.loads((r/'GAME-TU-RESULTS.json').read_text());expected='ef1992326d1ee494a389bc2c78bdfab131721434c0b08ab5f41dbc3e506c4e48'
assert report['candidate_sha256']==expected and report['il2cpp']['exit_code']==0
assert len(rows)==report['il2cpp']['game_tu_count']==14
archive=root/'bulk389-generated-cpp.tar.gz';source_hashes={};metadata=[]
with tarfile.open(archive,'r:gz') as t:
 for item in t:
  if item.isfile() and (re.fullmatch(r'GodsPVZRuntime1(?:__\d+)?\.cpp',Path(item.name).name) or item.name.endswith('/Metadata/global-metadata.dat')):
   data=t.extractfile(item).read();s=hashlib.sha256(data).hexdigest()
   if item.name.endswith('/Metadata/global-metadata.dat'):metadata.append(s)
   else:source_hashes[Path(item.name).name]=s
assert set(source_hashes)=={x['file'] for x in rows};assert metadata==[report['il2cpp']['metadata_sha256']]
checks=[]
for row in rows:
 assert row['exit_code']==row['error_count']==row['fatal_count']==0
 assert source_hashes[row['file']]==row['sha256']
 log=r/'clang_logs'/(row['file']+'.log');text=log.read_text('utf-8',errors='replace');assert not re.search(r'(?:^|\n).*?(?:fatal )?error:',text)
 checks.append(dict(file=row['file'],source_sha256=row['sha256'],raw_log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),exit=0))
result=dict(scope='INDEPENDENT_READBACK_ALL_GENERATED_GAME_TUS_LINUX_SYNTAX_ONLY',run_id=39957635669,source_commit='1cc0761d6378c8d00e4d9c67e9c322eba6e52614',candidate_sha256=expected,il2cpp_exit=0,game_tus=14,failed_tus=0,diagnostics=0,methods_with_compiler_errors=0,mapped_method_count_unchanged_from_r6=2267,all_756_generated_system_cpp_units_compiled=False,apple_xcode='NOT_EXECUTED',unity_editor='NOT_EXECUTED',ipa=None,checks=checks,generated_archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
out=Q/'COMPILER-READBACK-39957635669.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n','utf-8');print('COMPILER_READBACK_PASS game_tus=14 errors=0 source_hashes=14 metadata_hash=matched')
