from pathlib import Path
import json,subprocess,hashlib,shutil,zipfile,datetime
Q=Path(__file__).resolve().parent;repo=Q.parents[1]/'audit/repo-native113';D=repo/'Recovery/Bulk389-Qualification-2026-10-23';gh=r'C:\Program Files\GitHub CLI\gh.exe'
run=json.loads(subprocess.check_output([gh,'run','view','39961120509','-R','lyiming710-cloud/GodsPVZ-iOS','--json','status,conclusion,headSha,url,jobs']));assert run['headSha']=='6c33aa4ea57fec1162897026c3ad0e26f00209a6';stamp=datetime.datetime.now(datetime.timezone.utc).isoformat();run['observed_at_utc']=stamp
(D/'REAL-IOS-RUN-OBSERVATION.json').write_text(json.dumps(run,indent=2)+'\n','utf-8');shutil.copy2(Q/'RELEASE-ASSET-VERIFICATION.json',D/'RELEASE-ASSET-VERIFICATION.json');shutil.copy2(Q/'GIT-STAGED-VERIFICATION-FULL-GATE.json',D/'FULL-GATE-GIT-BLOB-VERIFICATION.json')
result=json.loads((D/'CURRENT-RESULT.json').read_text('utf-8'));result['real_unity_xcode_ipa_workflow']=dict(run_id=39961120509,code_commit=run['headSha'],url=run['url'],status_observed=run['status'],conclusion_observed=run['conclusion'],observed_at_utc=stamp);(D/'CURRENT-RESULT.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n','utf-8')
toolzip=D/'POST-COMPILER-TOOLS-AND-RECEIPTS.zip';entries=[]
with zipfile.ZipFile(toolzip,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 paths=list(Q.glob('*.py'))+list(Q.glob('*.json'))+list(Q.glob('historical*.yml'))+list((Q/'yaml-deps').rglob('*'))
 for p in sorted(set(paths)):
  if not p.is_file() or '__pycache__' in p.parts:continue
  rel=p.relative_to(Q).as_posix();b=p.read_bytes();z.write(p,rel);entries.append(dict(path=rel,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
with zipfile.ZipFile(toolzip) as z:
 for e in entries:assert hashlib.sha256(z.read(e['path'])).hexdigest()==e['sha256']
(D/'POST-COMPILER-TOOLS-MANIFEST.json').write_text(json.dumps(dict(archive=toolzip.name,sha256=hashlib.sha256(toolzip.read_bytes()).hexdigest(),entries=entries),indent=2)+'\n','utf-8')
p=D/'README.md';text=p.read_text('utf-8');text+='\n\n实际 iOS 流程已经启动：[39961120509](https://github.com/lyiming710-cloud/GodsPVZ-iOS/actions/runs/39961120509)，固定代码提交 `6c33aa4ea57fec1162897026c3ad0e26f00209a6`。`REAL-IOS-RUN-OBSERVATION.json` 是带时间戳的观测，不能当成未来的最终状态。生成 C++、核心历史归档、R4 补充、候选及编译日志已保存至 [本轮预发布归档](https://github.com/lyiming710-cloud/GodsPVZ-iOS/releases/tag/native121-bulk389-r4-compiler-clean-2026-10-23)，6 个资产共 209,086,594 字节，服务器 SHA-256 digest 均与本地匹配（未重复下载 152 MB 资产）。Release 内清单固定于提交 6c33aa4 的归档时刻；仓库后续清单还包含运行回执。最后的审查／编译归属／workflow 准备工具与回执在 POST-COMPILER-TOOLS-AND-RECEIPTS.zip 内，逐文件再次解压校验。\n';p.write_text(text,'utf-8')
p=repo/'Recovery/REMAINING-WORK-2026-10-23.md';text=p.read_text('utf-8').replace('新流程已准备，待真实运行产物','实际流程 39961120509 已启动，待真实运行产物');p.write_bytes(text.encode('utf-8'))
manifest=json.loads((D/'DELIVERY-MANIFEST.json').read_text('utf-8'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifest['entries']=[dict(path=p.relative_to(D).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(D.rglob('*')) if p.is_file() and p.name!='DELIVERY-MANIFEST.json'];manifest['external_git_paths']=[dict(path=x['path'],bytes=(repo/x['path']).stat().st_size,sha256=sha(repo/x['path'])) for x in manifest['external_git_paths']];(D/'DELIVERY-MANIFEST.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n','utf-8');print('LIVE_RECEIPT_SAVED',run['status'],[(j['name'],j['status'],j['conclusion']) for j in run['jobs']])
