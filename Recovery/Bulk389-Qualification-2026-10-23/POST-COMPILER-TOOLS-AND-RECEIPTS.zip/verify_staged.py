from pathlib import Path
import subprocess,json,hashlib,sys
Q=Path(__file__).resolve().parent;repo=Q.parents[1]/'audit/repo-native113';D=repo/'Recovery/Bulk389-Qualification-2026-10-23';manifest=json.loads((D/'DELIVERY-MANIFEST.json').read_text('utf-8'))
items=[dict(x,path=(D.relative_to(repo)/x['path']).as_posix()) for x in manifest['entries']]+manifest['external_git_paths'];requests=''.join(':'+x['path']+'\n' for x in items).encode()
r=subprocess.run(['git','cat-file','--batch'],cwd=repo,input=requests,capture_output=True,check=True);p=0;checked=[]
for item in items:
 end=r.stdout.index(b'\n',p);header=r.stdout[p:end].split();assert len(header)==3 and header[1]==b'blob',header;size=int(header[2]);data=r.stdout[end+1:end+1+size];p=end+size+2
 assert size==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],item['path'];checked.append(dict(path=item['path'],git_blob=header[0].decode(),sha256=item['sha256']))
assert p==len(r.stdout)
result=dict(state='PASS_STAGED_GIT_BLOB_MANIFEST',files=len(items),checked=checked)
out=Q/(sys.argv[1] if len(sys.argv)>1 else 'GIT-STAGED-VERIFICATION.json');assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n','utf-8');print('STAGED_BLOBS_VERIFIED',len(items))
