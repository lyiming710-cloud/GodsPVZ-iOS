from pathlib import Path
import shutil,json,hashlib
Q=Path(__file__).resolve().parent;R=Q.parents[1];repo=R/'audit/repo-native113';D=repo/'Recovery/Bulk389-Qualification-2026-10-23';support=D/'ios-support';support.mkdir(exist_ok=False)
rows=[]
for name in ['Assets/Editor/GodsPVZPackageReferenceMigrator.cs','Assets/Editor/GodsPVZIOSBuild.cs','Recovery/package-script-map-editor.json']:
 p=Q/'ios-support-inputs'/name;out=support/name;out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,out);b=p.read_bytes();rows.append(dict(path=name,sha256=hashlib.sha256(b).hexdigest(),git_blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()))
(support/'MANIFEST.json').write_text(json.dumps(dict(source_commit='64b86ed725c40e8e00cecd7a917f72bbed37777e',entries=rows),indent=2)+'\n','utf-8')
old=(Q/'historical-native18-real-gate.yml').read_text('utf-8');export=old[old.index('  export:\n'):old.index('\n  build_ipa:')]
export=export.replace('native18','bulk389').replace('NATIVE18','BULK389').replace('Stage9 bulk389','Bulk389 R4')
export=export.replace('needs: qualification','needs: conversion_binding').replace('ubuntu-latest','ubuntu-24.04').replace('f9122641902d0c4a65bf7120c29b64c01cf830506e4b1dd14479ad1fd81226b1','ef1992326d1ee494a389bc2c78bdfab131721434c0b08ab5f41dbc3e506c4e48')
export=export.replace("assert p['status']=='BULK389_DIRECT_CONVERSION_PASS'","assert p['status']=='BULK389_R4_LINUX_COMPILER_PASS'").replace("assert p['bulk389']['exit']==0 and p['bulk389']['methods']==[]","assert p['linux_compiler']['exit']==0 and p['linux_compiler']['failed_game_tus']==0 and p['linux_compiler']['diagnostics']==0")
export=export.replace('$GITHUB_WORKSPACE/Assets/Editor/','$GITHUB_WORKSPACE/Recovery/Bulk389-Qualification-2026-10-23/ios-support/Assets/Editor/').replace('$GITHUB_WORKSPACE/Recovery/package-script-map-editor.json','$GITHUB_WORKSPACE/Recovery/Bulk389-Qualification-2026-10-23/ios-support/Recovery/package-script-map-editor.json')
export=export.replace('          set +e\n          "$CLIENT" --activate-all','          touch "$OUT/seat-acquired.flag"\n          set +e\n          "$CLIENT" --activate-all')
marker='      - name: Upload real Unity gate evidence'
sanitize='''      - name: Prepare sanitized Unity evidence
        if: always()
        shell: bash
        run: |
          python3 scripts/actions/sanitize_unity_evidence.py "$RUNNER_TEMP/stage9-bulk389-ios/evidence" "$RUNNER_TEMP/stage9-bulk389-ios/public-evidence"

'''
export=export.replace(marker,sanitize+marker).replace('path: ${{ runner.temp }}/stage9-bulk389-ios/evidence/','path: ${{ runner.temp }}/stage9-bulk389-ios/public-evidence/')
prefix='''name: Bulk389 R4 REAL Unity Xcode unsigned IPA diagnostic gate

on:
  push:
    branches: [verify/codex-bulk250-r2-takeover-2026-10-23]
    paths: ['.github/workflows/bulk389-real-ios-ipa.yml']
  workflow_dispatch:

permissions:
  contents: read
  actions: read

concurrency:
  group: bulk389-r4-real-ios-ipa
  cancel-in-progress: false

jobs:
  conversion_binding:
    runs-on: ubuntu-24.04
    timeout-minutes: 15
    env:
      GH_TOKEN: ${{ github.token }}
    steps:
      - uses: actions/checkout@v4
      - uses: actions/download-artifact@v4
        with:
          github-token: ${{ github.token }}
          repository: lyiming710-cloud/GodsPVZ-iOS
          run-id: 39957635669
          name: Bulk389-R4-compiler-39957635669-1
          path: ${{ runner.temp }}/prior-compiler
      - name: Bind exact compiler input; no semantic promotion
        run: python3 scripts/actions/bind_bulk389_compiler_package.py --prior "$RUNNER_TEMP/prior-compiler" --output "$RUNNER_TEMP/bulk389-package"
      - uses: actions/upload-artifact@v4
        with:
          name: Stage9-bulk389-conversion-qualified
          path: ${{ runner.temp }}/bulk389-package/
          if-no-files-found: error
          retention-days: 90

'''
mac=old[old.index('  build_ipa:\n'):].replace('native18','bulk389').replace('macos-14','macos-15').replace('Checking bulk389 Zombie fixes','fixed Bulk389 R4 input')
mac=mac.replace('sudo xcode-select -s /Applications/Xcode_15.4.app/Contents/Developer || sudo xcode-select -s /Applications/Xcode.app/Contents/Developer','sudo xcode-select -s /Applications/Xcode_16.4.app/Contents/Developer')
begin=mac.index('      - name: Setup Node.js');end=mac.index('      - name: Upload Unsigned IPA Artifact')
mac=mac[:begin]+'''      - name: Package and verify unsigned physical-iOS ARM64 IPA
        shell: bash
        run: |
          set -euo pipefail
          APP_FOUND="$(find "$RUNNER_TEMP/build/Release-iphoneos" -maxdepth 1 -name '*.app' -type d | head -n1)"
          test -d "$APP_FOUND"
          python3 scripts/actions/package_bulk389_ipa.py --app "$APP_FOUND" --xcode-dir "$RUNNER_TEMP/build/xcode" --output-dir "$RUNNER_TEMP/ipa-output"

      - name: Preserve Apple build logs even on failure
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: Bulk389-R4-APPLE-BUILD-EVIDENCE
          path: |
            ${{ runner.temp }}/build/xcodebuild.log
            ${{ runner.temp }}/ipa-output/IPA-VALIDATION.json
          if-no-files-found: warn
          retention-days: 90

'''+mac[end:]
mac=mac.replace('path: build/output/*.ipa','path: ${{ runner.temp }}/ipa-output/*.ipa\n          retention-days: 90')
workflow=prefix+export+'\n'+mac
assert 'native18' not in workflow and 'p[\'bulk389\']' not in workflow
target=repo/'.github/workflows/bulk389-real-ios-ipa.yml';assert not target.exists();target.write_bytes(workflow.encode())
print('FULL_GATE_PREPARED',len(workflow.splitlines()),'lines, historical helpers scoped, unsigned packaging implemented')
