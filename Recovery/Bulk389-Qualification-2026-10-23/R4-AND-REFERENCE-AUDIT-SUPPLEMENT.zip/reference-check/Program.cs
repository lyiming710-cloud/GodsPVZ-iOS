using Mono.Cecil;
using System.Text.Json;
using System.Security.Cryptography;
using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Reflection.PortableExecutable;
using TypeDefinition=Mono.Cecil.TypeDefinition;
using MethodDefinition=Mono.Cecil.MethodDefinition;
using TypeReference=Mono.Cecil.TypeReference;
using TypeSpecification=Mono.Cecil.TypeSpecification;
using GenericParameter=Mono.Cecil.GenericParameter;
using AssemblyDefinition=Mono.Cecil.AssemblyDefinition;
if(args.Length!=3)throw new Exception("candidate support fresh-report");
var resolver=new DefaultAssemblyResolver();resolver.AddSearchDirectory(args[1]);using var assembly=AssemblyDefinition.ReadAssembly(args[0],new ReaderParameters{AssemblyResolver=resolver});var rows=new List<object>();int failed=0;
foreach(var member in assembly.MainModule.GetMemberReferences().Where(m=>m.MetadataToken.RID>1100))
{
 var errors=new List<string>();bool resolved=false;
 try
 {
  // Cecil may synthesize placeholder GenericParameters while reading a malformed
  // MemberRef, including on a same-module TypeDefinition. Read real table rows.
  int RawArity(IMemberDefinition definition)
  {
   var module=definition is TypeDefinition td?td.Module:((MethodDefinition)definition).Module;
   using var file=File.OpenRead(module.FileName);using var pe=new PEReader(file);var md=pe.GetMetadataReader();int rid=(int)definition.MetadataToken.RID;
   return definition is TypeDefinition?md.GetTypeDefinition(MetadataTokens.TypeDefinitionHandle(rid)).GetGenericParameters().Count:md.GetMethodDefinition(MetadataTokens.MethodDefinitionHandle(rid)).GetGenericParameters().Count;
  }
  var type=member.DeclaringType;int declaredArity=RawArity(type.Resolve());int arity=type is GenericInstanceType git?git.GenericArguments.Count:declaredArity;
  if(type is GenericInstanceType && arity!=declaredArity)errors.Add("Generic instance arity mismatch");
  int methodArity=member is MethodReference mr?RawArity(mr.Resolve()):0;
  void Check(TypeReference t)
  {
   if(t is GenericParameter gp){int limit=gp.Type==GenericParameterType.Type?arity:methodArity;if(gp.Position>=limit)errors.Add("Generic parameter "+gp.FullName+" outside declaring arity "+limit);}
   else if(t is GenericInstanceType g){foreach(var x in g.GenericArguments)Check(x);}
   else if(t is TypeSpecification s)Check(s.ElementType);
  }
  if(member is MethodReference method){resolved=method.Resolve()!=null;Check(method.ReturnType);foreach(var p in method.Parameters)Check(p.ParameterType);}
  else if(member is FieldReference field){resolved=field.Resolve()!=null;Check(field.FieldType);}
  if(!resolved)errors.Add("Unresolved member");
 }
 catch(Exception e){errors.Add(e.GetType().Name+": "+e.Message);}
 if(errors.Count!=0)failed++;rows.Add(new{token=$"0x{member.MetadataToken.ToInt32():X8}",member=member.FullName,resolved,errors});
}
if(File.Exists(args[2]))throw new IOException("Fresh output only");var result=new{scope="ALL_APPENDED_MEMBERREF_RESOLUTION_AND_GENERIC_PARAMETER_ARITY_ONLY",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),appended=rows.Count,failed,rows,full_ecma_verification=false};File.WriteAllText(args[2],JsonSerializer.Serialize(result,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine($"REFERENCE_CHECK appended={rows.Count} failed={failed}");return failed==0?0:2;
