from pathlib import Path
import json,shutil
Q=Path(__file__).resolve().parent;D=Q/'revision-r4';D.mkdir(exist_ok=False);S=D/'source';S.mkdir()
for p in (Q/'revision-r3/source').iterdir():
 if p.is_file():shutil.copy2(p,S/p.name)
old='12838c';new='151281ed030e0808'
p=S/'Native119MetadataData.cs';s=p.read_text('utf-8');assert s.count('new(0x1B0000B5,"'+old+'")')==1;assert s.count('new(0x0A00051B,1452,"'+old+'"')==1;s=s.replace('new(0x1B0000B5,"'+old+'")','new(0x1B0000B5,"'+new+'")').replace('new(0x0A00051B,1452,"'+old+'"','new(0x0A00051B,1452,"'+new+'"');p.write_text(s,'utf-8')
for filename in ['METADATA-ADDITIONS.json','NATIVE119-METADATA-DELTA.json']:
 p=S/filename;d=json.loads(p.read_text('utf-8'))
 for m in d['member_definitions']:
  if m['token']==0x0a00051b:assert m['owner_pin']==old;m['owner_pin']=new
 for t in d['added_typespecs']:
  if t['token']==0x1b0000b5:assert t['blob']==old;t['blob']=new
 if 'type_blobs' in d:assert d['type_blobs'][-1]==old;d['type_blobs'][-1]=new;d['expected_blob_heap_bytes']+=5
 p.write_text(json.dumps(d,indent=2)+'\n','utf-8')
p=S/'IMPLEMENTATION-PLAN.json';d=json.loads(p.read_text('utf-8'));d['state']='R4_METADATA_GENERIC_CONTEXT_FIX_BODY_SCOPE_389';p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n','utf-8');(D/'candidates').mkdir();(D/'logs').mkdir()
(D/'CHANGES.json').write_text(json.dumps(dict(type_spec='0x1B0000B5',member_ref='0x0A00051B',old_declaring_type='WordSelectionEvent (arity=0)',new_declaring_type='UnityEvent<string,int,int> (arity=3)',method_cil_changes=0,expected_blob_bytes=66518,frozen_validators_changed=False,initial_new_reference_checker_false_accept_preserved=True),indent=2)+'\n','utf-8');print('R4_SOURCE_READY metadata-only')
