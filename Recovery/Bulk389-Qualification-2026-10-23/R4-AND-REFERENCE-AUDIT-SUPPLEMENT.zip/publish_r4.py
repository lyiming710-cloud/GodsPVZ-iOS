from pathlib import Path
import json,hashlib,zipfile,shutil,sys
Q=Path(__file__).resolve().parent;R=Q.parents[1];repo=R/'audit/repo-native113';D=repo/'Recovery/Bulk389-Qualification-2026-10-23';F=Q/'revision-r4';sys.path.insert(0,str(Q));import audit_candidate as a
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n','utf-8')
candidate=F/'candidates/candidate1.dll';expected='ef1992326d1ee494a389bc2c78bdfab131721434c0b08ab5f41dbc3e506c4e48';assert sha(candidate)==expected
assert candidate.read_bytes()==(F/'candidates/candidate2.dll').read_bytes()
for p in F.glob('*.json'):shutil.copy2(p,D/p.name)
for p in (F/'source').iterdir():
 if p.is_file():shutil.copy2(p,D/'source'/p.name)
with zipfile.ZipFile(D/'BULK389-R4-CANDIDATE.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:z.write(candidate,'BULK389-R4-CANDIDATE.dll')
cur=json.loads((D/'CURRENT-RESULT.json').read_text('utf-8'));cur.update(candidate_sha256=expected,candidate_bytes=candidate.stat().st_size,patcher_sha256=sha(F/'source/bin/Release/net10.0/Bulk388.dll'),revision='R4',blob_heap_bytes=66518,all_appended_member_references=dict(total=218,failed=0,raw_generic_parameter_arity=True,earlier_r3_false_accept_preserved=True));dump(D/'CURRENT-RESULT.json',cur)
for p in [repo/'.github/workflows/bulk389-root-compiler-check.yml',repo/'scripts/actions/check_bulk389_compiler.py']:
 text=p.read_text('utf-8').replace('9c8cefd7b348a254a7c41ec48d95d9c5a1047eb6e17ad6eb45eb03b7351ce1c1',expected).replace('R3','R4').replace('r3-root','r4-root');p.write_text(text,'utf-8')
# Verify metadata-only R3->R4 binding using raw bodies, not construction reports.
bb=(Q/'revision-r3/candidates/candidate1.dll').read_bytes();nn=candidate.read_bytes();db=a.dnfile.dnPE(data=bb);dn=a.dnfile.dnPE(data=nn);all_methods=0
for x,y in zip(db.net.mdtables.MethodDef.rows,dn.net.mdtables.MethodDef.rows):
 if not x.Rva:assert not y.Rva;continue
 xo=db.get_offset_from_rva(x.Rva);yo=dn.get_offset_from_rva(y.Rva);xl=a.h.parse_raw_method_body_span(bb,xo)[0];yl=a.h.parse_raw_method_body_span(nn,yo)[0];assert bb[xo:xo+xl]==nn[yo:yo+yl];all_methods+=1
dump(F/'R3-R4-METADATA-ONLY-COMPARISON.json',dict(r3_sha256=hashlib.sha256(bb).hexdigest(),r4_sha256=expected,all_nonzero_rva_method_bodies_identical=all_methods,only_new_metadata_changed=True,game_cil_execution_not_inferred_from_this_comparison=True))
shutil.copy2(F/'R3-R4-METADATA-ONLY-COMPARISON.json',D/'R3-R4-METADATA-ONLY-COMPARISON.json')
matrix=json.loads((D/'SOURCE-REVISION-MATRIX.json').read_text('utf-8'));matrix['r4_candidate_sha256']=expected;matrix['r3_r4_all_method_bodies_identical']=True;matrix['r3_unused_memberref_arity_failure']='0x0A00051B';dump(D/'SOURCE-REVISION-MATRIX.json',matrix)
readme=D/'README.md';text=readme.read_text('utf-8').replace('Bulk389 R3','Bulk389 R4').replace('最终 R3','最终 R4').replace('R3 的 389','R4 的 389').replace('BULK389-R3-CANDIDATE.zip','BULK389-R4-CANDIDATE.zip').replace('9c8cefd7b348a254a7c41ec48d95d9c5a1047eb6e17ad6eb45eb03b7351ce1c1',expected).replace('66,513','66,518')
text+='''

## 提交前追加的 R4 元数据审查

R3 方法指令的静态类型与成员访问虽通过，尚未覆盖未引用的新 MemberRef。新增检查器首版也出现了 false accept：Cecil 会为损坏的同模块签名补出 GenericParameter 占位对象，不能据其内存 Count 判断原始声明。改用 System.Reflection.Metadata 直接读取真实 GenericParam 表后，R3 的 `0x0A00051B` 被拒绝：非泛型 WordSelectionEvent 上错误引用了 !0/!1/!2。

R4 将这个新增引用的 TypeSpec `0x1B0000B5` 改为原有基类对应的封闭 UnityEvent<string,int,int>。218 个新增引用全部重新检查，解析与原始泛型参数数量检查 0 失败；R3 的失败输入同时构成已检出的反例。此处修的是本轮新建检查器；冻结历史检查器未改。记录 32 因新检查器当时构建失败，实际上执行了旧二进制，**不采信**其零错误结论；记录 35 才是真正原始表行检查，检出 1 个错误。完整输出与首次漏报代码均保留。

R4 与 R3 的所有 2,297 个有 RVA 方法体逐字节相同；R4 已重新执行构造两次、独立隔离、源绑定、静态类型、成员访问、正负控制及 184 个实际 native/CIL 用例。状态以本目录 CURRENT-RESULT 及各报告中的 R4 SHA 为准，R3 不是正式可晋级候选。

新增与变更的本地证据在 R4-AND-REFERENCE-AUDIT-SUPPLEMENT.zip。先解压 COMPLETE-LOCAL-CHECKPOINT.zip，再覆盖解压该补充包，可恢复最终工具和全部修订；两个清单逐文件记录 SHA 并已实际回读。核心原 ZIP 继续保留 R1–R3 的当时状态。CI 准备脚本是当时生成器，真正执行配置以仓库 workflow 与 check_bulk389_compiler.py 固定的 R4 哈希为准。
''';readme.write_text(text,'utf-8')
p=repo/'Recovery/REMAINING-WORK-2026-10-23.md';text=p.read_text('utf-8').replace('Bulk389 R3','Bulk389 R4').replace('SHA 9c8cefd7…51ce1c1','SHA ef199232…06c4e48').replace('最终 R3 才达到当前静态状态','R3 后又检出 1 个未引用新 MemberRef 的泛型参数错误，R4 修正后 218 个新增引用全部通过；最终 R4 达到当前静态状态');p.write_text(text,'utf-8')
old={e['path']:e['sha256'] for e in json.loads((D/'CHECKPOINT-CONTENTS.json').read_text('utf-8'))['entries']};entries=[];package=D/'R4-AND-REFERENCE-AUDIT-SUPPLEMENT.zip'
with zipfile.ZipFile(package,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(Q.rglob('*')):
  if not p.is_file() or any(x in ('obj','__pycache__') for x in p.relative_to(Q).parts):continue
  rel=p.relative_to(Q).as_posix();s=sha(p)
  if old.get(rel)==s:continue
  z.write(p,rel);entries.append(dict(path=rel,bytes=p.stat().st_size,sha256=s))
with zipfile.ZipFile(package) as z:
 for e in entries:assert hashlib.sha256(z.read(e['path'])).hexdigest()==e['sha256']
dump(D/'SUPPLEMENT-CONTENTS.json',dict(archive=package.name,bytes=package.stat().st_size,sha256=sha(package),entries=entries))
external=[repo/'.github/workflows/bulk389-root-compiler-check.yml',repo/'scripts/actions/check_bulk389_compiler.py',repo/'scripts/actions/verify_bulk152_portable.py',repo/'scripts/actions/restore_bulk152_checkpoint.py',repo/'Recovery/REMAINING-WORK-2026-10-23.md']
entries=[dict(path=p.relative_to(D).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(D.rglob('*')) if p.is_file() and p.name!='DELIVERY-MANIFEST.json']
dump(D/'DELIVERY-MANIFEST.json',dict(schema='bulk389-r4-delivery-v1',entries=entries,external_git_paths=[dict(path=p.relative_to(repo).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in external],core_archive_entries_verified=711))
print('R4_PUBLICATION_READY',len(entries),'files supplement',package.stat().st_size,'method_bodies_identical',all_methods)
