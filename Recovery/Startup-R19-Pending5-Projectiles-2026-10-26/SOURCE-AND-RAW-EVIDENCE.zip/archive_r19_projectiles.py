"""Publish the five existing projectile caller profiles, including failed fixture attempt."""
from pathlib import Path
import json
from archive_support import sha,js,pack,manifest,variants
W=Path(__file__).resolve().parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113';Q=W/'r19-pending-projectiles-2026-10-26';D=R/'Recovery/Startup-R19-Pending5-Projectiles-2026-10-26';H=R/'Recovery/Startup-R19-Batch100-2026-10-25';T=R/'Recovery/Startup-R20-Sites104-2026-10-26'
assert not D.exists();D.mkdir();(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text\n*.md -text\n*.zip -text\n')
n=json.loads((Q/'NATIVE-ATTEMPT1.json').read_bytes());c=json.loads((Q/'controls/RESULT.json').read_bytes());binding=json.loads((Q/'R19-AND-R20-BINDING.json').read_bytes())
assert n['normal_records']==5316 and n['managed_only_records']==28 and n['caller_bytes_verified']==5 and not n['differences'] and not n['callback_errors']
assert c['controls']==c['detected']==5 and c['process_failures']==0 and binding['all_rows_identical']
current=(W/'startup-r20-sites100/authored3.dll').read_bytes();parent=(W/'startup-r19-batch100/candidate9.dll').read_bytes();assert sha(current)==binding['current_sha256'] and sha(parent)==binding['parent_sha256']
assert sha((W/'startup-r5/runtime-common/Rehost.cs').read_bytes())=='59b1e80892d0038ee188f0ef36d1af25ce37ae6df71016ba6617cc221ca51d40'
delta=variants(Q/'controls',current);assert len(delta)==5;js(Q/'PHYSICAL-CONTROL-DELTAS.json',delta)
for p,name in [(Q/'NATIVE-ATTEMPT1.json','NATIVE.json'),(Q/'R19-AND-R20-BINDING.json','R19-AND-R20-BINDING.json'),(Q/'controls/RESULT.json','CONTROLS.json'),(Q/'PHYSICAL-CONTROL-DELTAS.json','PHYSICAL-CONTROL-DELTAS.json')]:(D/name).write_bytes(p.read_bytes())
files=[]
for p in sorted(Q.rglob('*')):
    if not p.is_file() or any(x in p.parts for x in ['obj','__pycache__']):continue
    if p.suffix=='.dll' and 'bin' not in p.parts:continue
    files.append(('projectile-profile/'+p.relative_to(Q).as_posix(),p.read_bytes()))
tokens=list(n['counts'])
cil=json.loads((W/'startup-r20-sites100/shared-authored3/ALL-CIL.json').read_bytes());methods={m['token']:m for m in cil['methods']}
for token in tokens:
    for suffix in ['.txt','.json']:
        p=W/'startup-r19-batch100/native-source-complete'/(token+suffix);files.append(('original-native/'+p.name,p.read_bytes()))
    files.append(('current-cil/'+token+'.json',(json.dumps(methods[token],indent=2)+'\n').encode()))
files += [('frozen-runtime/Rehost.cs',(W/'startup-r5/runtime-common/Rehost.cs').read_bytes()),('frozen-runtime/native_runtime_common.py',(W/'startup-r5/native_runtime_common.py').read_bytes()),(Path(__file__).name,Path(__file__).read_bytes())];pack(D/'SOURCE-AND-RAW-EVIDENCE.zip',files)
pending=json.loads((H/'CURRENT-PENDING-RUNTIME-PROFILES.json').read_bytes());assert pending['methods']==25;remaining=[r for r in pending['rows'] if r['token'] not in tokens];assert len(remaining)==20
pending.update(methods=20,added_supplement='../'+D.name,rows=remaining);js(H/'CURRENT-PENDING-RUNTIME-PROFILES.json',pending)
s=json.loads((H/'PROGRESS.json').read_bytes());assert s['finite_comparison_method_union']==75 and s['total_native_finite_comparison_records']==21456
s.update(status='HUNDRED_CONSTRUCTED_EIGHTY_FINITE_PROFILES_TWENTY_PENDING_INCLUDING_TWO_FLOAT_FAILURES',finite_comparison_method_union=80,other_runtime_profile_count=20,total_native_finite_comparison_records=26772,finite_original_native_vs_complete_cil_additional_methods=45,projectile5_native_normal_records=5316,projectile5_managed_only_records=28,projectile5_physical_controls=5,projectile5_detected_controls=5,total_physical_controls_including_foreach_and_new_profiles=s['total_physical_controls_including_foreach_and_new_profiles']+5,total_runtime_differences_including_supplements=s['total_runtime_differences_including_supplements']+5)
js(H/'PROGRESS.json',s)
js(D/'PROGRESS.json',dict(status='FIVE_FINITE_PROJECTILE_FULL_CALLERS_PASS_PRODUCT_PENDING',parent_candidate_sha256=sha(parent),current_candidate_sha256=sha(current),new_game_code_changes=0,methods=5,native_normal_records=5316,managed_only_records=28,controls_detected=5,r19_finite_union=80,r19_native_comparison_records=26772,r19_pending_profiles=20,initial_fixture_signature_guard_rejection_retained=True,unity=False,ipa=None,ipad_acceptance=False))
(D/'README.md').write_bytes('''# R19 五个投射物初始化调用方：原生 ABI / 完整 CIL 对照

实际发射完整目标 CIL，并运行未改完整原版调用方：0x060000BA PlantAnimationEvent.PC_SW_IcicleCircle、0x0600037E Plant.PC_CBKillZombie、0x060003AE Plant.ST_Snowpeawitch、0x0600049B Zombie.ZC_LadderSaboteursPlaceC4、0x060004A2 Zombie.ZC_PoleCommanderThrowC4。

5,316条正常记录0差异，逐方法1,728/1,152/324/1,920/192条。两个固定候选 R19 candidate9 / R20 authored3 的5,344条完整CLR记录相同；28个空board/manager/skill的CLR异常另列，不宣称Windows原生异常展开已支持。冻结Rehost、游戏DLL及原生调用方比较/分支不变。

覆盖Unity对象伪空、返回投射物伪空/实际空、技能ID分支、正负零/最小非零量/极大有限向量、C4的Int32溢出边界、不同Camp值，并在Create/Initial/GetDamage/Skill.Function回调后替换阵营、动画事件plant接收者与skill，实际比较后续字段重读和调用顺序。原生Vector3隐藏返回缓冲区、generic Initial的三个Vector3/float/int/owner/MethodInfo栈参数均按Windows x64协议执行。原版元数据中的四个字符串字面量被实际物化，未用猜测名替代。

五个物理单站点错误（冰锥X偏移、吞噬爆弹时长、雪豌豆速度、梯子C4时长、撑杆C4方向倍率）都由正常完成进程检测，分别48/64/128/640/64条可定位差异，其他方法0差异，没有把异常或进程崩溃算检测通过。变体按真实DLL增量与SHA重建。首次fixture误将实例Component.get_transform映射为静态shim，被冻结签名检查挡在执行前；原源/日志/二进制保留，随后只修正公开fixture形状，未修改冻结器。

Unity lifetime、transform、动画精灵查询/隐藏、投射物管理器、Initial/GetDamage/SetDamage和Skill子调用为明确受控叶函数；该结果证明有限输入下调用方路径和实参，不证明子方法内部、实际画面/音频、普遍等价或真机行为。R19有限profile联合数80，累计正常原版记录26,772，另20个profile待验收，其中两个浮点差异方法继续保留失败。此前三个运行时故障未检出和一个仅源码EH guard的状态不变。
'''.encode())
p=H/'README.md';v=p.read_text('utf-8');v+='\n## 五个投射物调用方补充\n\n[完整投射物对照](../Startup-R19-Pending5-Projectiles-2026-10-26/README.md) 保存5,316条正常原版对照、28个CLR-only异常、五个检出的物理故障和首次fixture签名拒绝。R19有限联合80 /26,772条记录，20个profile待完成，包含两处浮点差异方法。\n';p.write_bytes(v.encode())
s=json.loads((T/'PROGRESS.json').read_bytes());s.update(r19_runtime_profiles_still_pending=20,r19_additional_finite_profiles_verified_on_current_r20=15);js(T/'PROGRESS.json',s)
q=json.loads((T/'CURRENT-WORK-QUEUE.json').read_bytes())
for r in q['rows']:
    if r['token'] in tokens:r.update(current_state='R19_BODY_FINITE_PROJECTILE_PROFILE_PASS_BOTH_EXACT_CANDIDATES_PRODUCT_PENDING',r19_runtime_pending=False,normal_native_records=n['counts'][r['token']],current_required_action='Actual engine/product integration and callee internals remain pending')
q.update(other_parent_followup_work_items=133,additional_parent_r19_profiles_completed=15);js(T/'CURRENT-WORK-QUEUE.json',q)
p=R/'README.md';v=p.read_text('utf-8');assert 'Seventy-five methods now have 21,456' in v;v=v.replace('Seventy-five methods now have 21,456','Eighty methods now have 26,772').replace('Twenty-five other runtime profiles','Twenty other runtime profiles').replace('82 physical controls: 78 runtime differences','87 physical controls: 83 runtime differences');p.write_bytes(v.encode())
p=R/'Recovery/STATUS.md';v=p.read_text('utf-8');marker='## Latest checkpoint - 2026-10-26\n';v=v.replace(marker,marker+'\n[Five projectile caller profiles](Startup-R19-Pending5-Projectiles-2026-10-26/README.md) match5,316 normal original-PC records with both exact candidates and detect five physical faults. R19 finite union80 /26,772 normal records,20 profiles pending including two known float differences. No new gameplay DLL changes.\n',1);p.write_bytes(v.encode())
for folder in [D,H,T]:manifest(folder)
print(json.dumps(dict(archived=D.name,native_records=5316,r19_union=80,r19_pending=20,new_game_changes=0)))
