using System.Reflection;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public struct Vec{public float x,y,z;public Vec(float x,float y,float z){this.x=x;this.y=y;this.z=z;}public static Vec zero=>new(0,0,0);public static Vec operator*(Vec v,float f)=>new(v.x*f,v.y*f,v.z*f);}
public class Obj{public string Tag="";public bool Live=true;}
public class Transform:Obj{public Vec position{get{Program.Log("Position:"+Tag+":"+Program.V(Program.Position));return Program.Position;}}}
public class GO:Obj{public bool activeSelf{get{Program.Log("Active:"+Tag+":"+Program.N("active"));return Program.N("active")==1;}}}
public class Board:Obj{public ProjectileManager? projectileManager;}
public class ProjectileManager:Obj{public Projectile? CrateNewProjectile(int id){Program.Log("Create:"+Tag+":"+id);Program.Mutate("Create");return Program.Made;}}
public class Damage:Obj{}
public class Plant:Obj{public Board? board;public int camp;public bool supperHit;public Skill? skill;public List<GO> animationSprites=[];public Damage GetDamage(Projectile? p,int id)=>Program.GetDamage(this,p,id,null);public Damage GetDamage(Projectile? p,int id,int extra)=>Program.GetDamage(this,p,id,extra);}
public class Zombie:Obj{public Board? board;public int camp;public bool ashes;public float fX,fY;public Vec rDirection;public int ladderSaboteurs_C4;public List<GO> animationSprites=[];public Damage GetDamage(int id,Projectile? p,int extra)=>Program.GetDamage(this,p,id,extra);}
public class Event:Obj{public Plant? plant;public void PC_SW_IcicleCircle(){throw new NotSupportedException();}}
public class Projectile:Obj
{
 public void Initial<T>(Vec p,Vec s,Vec a,float duration,int track,T owner)=>Program.Initial(this,p,s,a,duration,null,track,(Obj)(object)owner!);
 public void Initial<T>(Vec p,Vec s,Vec a,float duration,float extra,int track,T owner)=>Program.Initial(this,p,s,a,duration,extra,track,(Obj)(object)owner!);
 public void SetDamage(Damage? d,int camp)=>Program.Log("SetDamage:"+Tag+":"+(d?.Tag??"null")+":"+camp);
}
public class Skill:Obj{public int ID;public void Function(Plant p,Projectile? proj,Damage? damage){Program.Log("Function:"+Tag+":"+p.Tag+":"+(proj?.Tag??"null")+":"+(damage?.Tag??"null"));Program.Mutate("Function");}public void End(Plant p,Zombie? z,Projectile? proj,Damage? damage)=>Program.Log("End:"+Tag+":"+p.Tag+":"+(z?.Tag??"null")+":"+(proj?.Tag??"null")+":"+(damage?.Tag??"null"));}
public static class Global
{
 public static Vec GetAnimationSpritePosition(List<GO> items,string name){Program.Log("SpritePosition:"+Program.ListTag(items)+":"+name+":"+Program.V(Program.Position));return Program.Position;}
 public static GO GetAnimationSprite_Name(List<GO> items,string name){Program.Log("SpriteName:"+Program.ListTag(items)+":"+name);return Program.Bomb;}
 public static void HideSprite(List<GO> items,string name)=>Program.Log("Hide:"+Program.ListTag(items)+":"+name);
}
public static class Program
{
 public static JsonElement Case;public static List<string> Trace=[];public static Plant MainPlant=null!,OtherPlant=null!;public static Zombie MainZombie=null!;public static Event Event=null!;public static Projectile? Made;public static Damage Damage=null!;public static Skill Skill2=null!;public static GO Bomb=null!;public static Vec Position;public static int Rid;
 public static int N(string k,int d=0)=>Case.TryGetProperty(k,out var p)?p.GetInt32():d;
 public static string Bits(float f)=>((uint)BitConverter.SingleToInt32Bits(f)).ToString("X8");public static string V(Vec v)=>Bits(v.x)+","+Bits(v.y)+","+Bits(v.z);public static float F(JsonElement p)=>BitConverter.Int32BitsToSingle(unchecked((int)Convert.ToUInt32(p.GetString(),16)));public static Vec Vector(string k){var p=Case.GetProperty(k);return new(F(p[0]),F(p[1]),F(p[2]));}
 public static void Log(string s)=>Trace.Add(s);public static string ListTag(List<GO> items)=>ReferenceEquals(items,MainPlant.animationSprites)?"plantSprites":ReferenceEquals(items,OtherPlant.animationSprites)?"otherSprites":ReferenceEquals(items,MainZombie.animationSprites)?"zombieSprites":throw new Exception("unknown list");
 public static bool Exists(Obj? a){bool value=a!=null&&a.Live;Log("Exists:"+(a?.Tag??"null")+":"+(value?1:0));return value;}public static bool Equal(Obj? a,Obj? b){if(b!=null)throw new Exception();return !Exists(a);}public static bool Unequal(Obj? a,Obj? b){if(b!=null)throw new Exception();return Exists(a);}
 public static Transform GetTransform(Obj obj){Log("Transform:"+obj.Tag);return new(){Tag=obj.Tag+"Transform"};}
 public static void Mutate(string stage)
 {
  if(N("mutation")==1&&stage=="Create"){MainPlant.camp=101;MainZombie.camp=201;}
  if(N("mutation")==2&&stage=="Initial"){MainPlant.camp=102;MainZombie.camp=202;if(Rid==0xba)Event.plant=OtherPlant;}
  if(N("mutation")==3&&stage=="Damage"){MainPlant.camp=103;OtherPlant.camp=303;MainZombie.camp=203;}
  if(N("mutation")==4&&stage=="Function")MainPlant.skill=Skill2;
 }
 public static Damage GetDamage(Obj owner,Projectile? p,int id,int? extra){Log("Damage:"+owner.Tag+":"+(p?.Tag??"null")+":"+id+":"+(extra.HasValue?extra.Value.ToString():"omitted"));Mutate("Damage");return Damage;}
 public static void Initial(Projectile p,Vec position,Vec speed,Vec accel,float duration,float? extra,int track,Obj owner){Log("Initial:"+p.Tag+":"+V(position)+":"+V(speed)+":"+V(accel)+":"+Bits(duration)+":"+(extra.HasValue?Bits(extra.Value):"omitted")+":"+track+":"+owner.Tag);Mutate("Initial");}
 static Type Map(MC.TypeReference t)
 {
  if(t is MC.ArrayType a)return Map(a.ElementType).MakeArrayType();
  return t.FullName switch{"System.Void"=>typeof(void),"System.Object"=>typeof(object),"System.Boolean"=>typeof(bool),"System.Int32"=>typeof(int),"System.IntPtr"=>typeof(IntPtr),"System.Single"=>typeof(float),"System.String"=>typeof(string),"UnityEngine.Object"=>typeof(Obj),"UnityEngine.Component"=>typeof(Obj),"UnityEngine.Transform"=>typeof(Transform),"UnityEngine.Vector3"=>typeof(Vec),"UnityEngine.GameObject"=>typeof(GO),"System.Collections.Generic.List`1<UnityEngine.GameObject>"=>typeof(List<GO>),"Plant"=>typeof(Plant),"Zombie"=>typeof(Zombie),"Projectile"=>typeof(Projectile),"ProjectileManager"=>typeof(ProjectileManager),"Board"=>typeof(Board),"PlantAnimationEvent"=>typeof(Event),"Damage"=>typeof(Damage),"Camp"=>typeof(int),"Skill"=>typeof(Skill),"GlobalStaticVars"=>typeof(Global),_=>throw new NotSupportedException(t.FullName)};
 }
 static FieldInfo Field(MC.FieldReference f)=>Map(f.DeclaringType).GetField(f.Name)!;
 static MethodBase Method(MC.MethodReference m)
 {
  if(m.DeclaringType.FullName=="UnityEngine.Object")return typeof(Program).GetMethod(m.Name=="op_Equality"?"Equal":"Unequal")!;
  if(m.DeclaringType.FullName=="UnityEngine.Component"&&m.Name=="get_transform")return typeof(Program).GetMethod("GetTransform")!;
  if(m is MC.GenericInstanceMethod g)return typeof(Projectile).GetMethods().Single(x=>x.Name=="Initial"&&x.GetParameters().Length==m.Parameters.Count).MakeGenericMethod(g.GenericArguments.Select(Map).ToArray());
  var types=m.Parameters.Select(p=>Map(p.ParameterType)).ToArray();return m.Name==".ctor"?Map(m.DeclaringType).GetConstructor(types)!:Map(m.DeclaringType).GetMethod(m.Name,BindingFlags.Public|BindingFlags.Static|BindingFlags.Instance,null,types,null)!;
 }
 static T? State<T>(T obj,int state)where T:Obj{obj.Live=state==1;return state==0?null:obj;}
 public static void Main(string[] args)
 {
  var resolver=new MC.DefaultAssemblyResolver();resolver.AddSearchDirectory(args[1]);using var asm=MC.AssemblyDefinition.ReadAssembly(args[0],new MC.ReaderParameters{AssemblyResolver=resolver});int[] rids=[0xba,0x37e,0x3ae,0x49b,0x4a2];var bodies=rids.ToDictionary(r=>r,r=>ActualCil.Emit((MC.MethodDefinition)asm.MainModule.LookupToken(0x6000000|r),Map,Field,Method));using var input=JsonDocument.Parse(File.ReadAllText(args[2]));var rows=new List<object>();
  foreach(var q in input.RootElement.EnumerateArray())
  {
   Case=q;Trace.Clear();Rid=Convert.ToInt32(q.GetProperty("token").GetString(),16)&0xffffff;Position=Vector("position");MainPlant=new(){Tag="plant",camp=N("camp"),supperHit=N("supper")==1};OtherPlant=new(){Tag="other",camp=300};MainZombie=new(){Tag="zombie",camp=N("camp"),ashes=N("ashes")==1,fX=Position.x,fY=Position.y,rDirection=Vector("direction"),ladderSaboteurs_C4=N("c4")};Event=new(){Tag="event",plant=State(MainPlant,N("plant",1))};Bomb=new(){Tag="bomb"};Damage=new(){Tag="damage"};Skill2=new(){Tag="skill2",ID=2};MainPlant.skill=q.TryGetProperty("nullSkill",out _)?null:new(){Tag="skill",ID=N("skill",1)};
   var pm=State(new ProjectileManager{Tag="manager"},N("manager",1));var board=State(new Board{Tag="board",projectileManager=pm},N("board",1));MainPlant.board=MainZombie.board=board;Made=State(new Projectile{Tag="projectile"},N("projectile",1));string? error=null;
   try{if(Rid==0xba)bodies[Rid].Invoke(null,[Event]);else if(Rid==0x37e)bodies[Rid].Invoke(null,[MainPlant,State(MainZombie,N("zombie",1))]);else bodies[Rid].Invoke(null,[Rid==0x3ae?(Obj)MainPlant:MainZombie]);}catch(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;error=e.GetType().FullName;}
   rows.Add(new{name=q.GetProperty("name").GetString(),token=q.GetProperty("token").GetString(),error,trace=Trace.ToArray(),state=new{plant_camp=MainPlant.camp,other_camp=OtherPlant.camp,zombie_camp=MainZombie.camp,c4=MainZombie.ladderSaboteurs_C4,supper=MainPlant.supperHit,event_plant=Event.plant?.Tag??"null",plant_skill=MainPlant.skill?.Tag??"null"}});
  }
  File.WriteAllText(args[3],JsonSerializer.Serialize(new{scope="COMPLETE_EXISTING_FIVE_PROJECTILE_CALLERS_CIL_CONTROLLED_ENGINE_AND_CALLEES",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),methods=5,results=rows,no_instruction_pruning=true,eh_removed=false,private_access_bypass=false,unity_or_product_acceptance=false},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{records=rows.Count,methods=5}));
 }
}
