"""Full unmodified original caller paths; generic Initial and Unity leaves are observed stubs."""
from pathlib import Path
import collections,ctypes as C,hashlib,json,struct,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
im=NativeImage();state={};rids=[0xba,0x37e,0x3ae,0x49b,0x4a2]
cfgs={r:json.loads((W/'startup-r19-batch100/native-source-complete'/f'0x{0x6000000|r:08X}.json').read_bytes()) for r in rids}
fields=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_bytes())
def off(owner,name):
    rows=[r for r in fields if r['type']==owner and r['namespace']=='' and r['name']==name];assert len(rows)==1,(owner,name,rows);return rows[0]['offset']
def log(s):state['trace'].append(s)
def tag(p):return 'null' if not p else state['tags'][p]
def text(p):return None if not p else C.string_at(p+0x14,get32(p+0x10)*2).decode('utf-16-le')
def string(s):
    b=s.encode('utf-16-le');p=im.alloc(24+len(b));put32(p+0x10,len(b)//2);C.memmove(p+0x14,b,len(b));return p
def fb(value):return struct.pack('<f',value)[::-1].hex().upper()
def vec(p):return ','.join(f'{C.c_uint32.from_address(p+4*k).value:08X}' for k in range(3))
def write_vec(p,values):C.memmove(p,b''.join(bytes.fromhex(v)[::-1] for v in values),12)
def mutate(stage):
    q=state['q'];m=q['mutation']
    if m==1 and stage=='Create':
        put32(state['plant']+off('Plant','camp'),101);put32(state['zombie']+off('Zombie','camp'),201)
    if m==2 and stage=='Initial':
        put32(state['plant']+off('Plant','camp'),102);put32(state['zombie']+off('Zombie','camp'),202)
        if state['rid']==0xba:put64(state['event']+off('PlantAnimationEvent','plant'),state['other'])
    if m==3 and stage=='Damage':
        put32(state['plant']+off('Plant','camp'),103);put32(state['other']+off('Plant','camp'),303);put32(state['zombie']+off('Zombie','camp'),203)
    if m==4 and stage=='Function':put64(state['plant']+off('Plant','skill'),state['skill2'])
def exists(p,method):
    assert not method;v=bool(p and state['live'][p]);log('Exists:'+tag(p)+':'+str(int(v)));return v
def equal(p,b,m):assert not b;return not exists(p,m)
def unequal(p,b,m):assert not b;return exists(p,m)
def create(p,id,m):assert p==state['manager'] and not m;log(f'Create:{tag(p)}:{id}');mutate('Create');return state['made']
def transform(p,m):assert p==state['event'] and not m;log('Transform:'+tag(p));return state['transform']
def position(out,p,m):assert p==state['transform'] and not m;log('Position:'+tag(p)+':'+','.join(state['q']['position']));write_vec(out,state['q']['position']);return out
def sprite_position(out,items,name,m):assert not m;log('SpritePosition:'+tag(items)+':'+text(name)+':'+','.join(state['q']['position']));write_vec(out,state['q']['position']);return out
def sprite_name(items,name,m):assert not m;log('SpriteName:'+tag(items)+':'+text(name));return state['bomb']
def active(p,m):assert p==state['bomb'] and not m;log('Active:bomb:'+str(state['q']['active']));return bool(state['q']['active'])
def hide(items,name,m):assert not m;log('Hide:'+tag(items)+':'+text(name))
def initial(p,v,s,a,d,e,track,owner,method):
    assert p==state['made'] and method in metadata_values;log('Initial:'+tag(p)+':'+vec(v)+':'+vec(s)+':'+vec(a)+':'+fb(d)+':'+('omitted' if e is None else fb(e))+':'+str(track)+':'+tag(owner));mutate('Initial')
def initial6(p,v,s,a,d,track,owner,m):initial(p,v,s,a,d,None,track,owner,m)
def damage(owner,proj,id,extra,m):
    assert not m;log('Damage:'+tag(owner)+':'+tag(proj)+':'+str(id)+':'+('omitted' if extra is None else str(extra)));mutate('Damage');return state['damage']
def pd2(owner,proj,id,m):return damage(owner,proj,id,None,m)
def pd3(owner,proj,id,extra,m):return damage(owner,proj,id,extra,m)
def zd3(owner,id,proj,extra,m):return damage(owner,proj,id,extra,m)
def set_damage(p,d,camp,m):assert p==state['made'] and not m;log('SetDamage:'+tag(p)+':'+tag(d)+':'+str(camp))
def function(s,p,proj,d,m):assert not m;log('Function:'+tag(s)+':'+tag(p)+':'+tag(proj)+':'+tag(d));mutate('Function')
def end(s,p,z,proj,d,m):assert not m;log('End:'+tag(s)+':'+tag(p)+':'+tag(z)+':'+tag(proj)+':'+tag(d))
try:
    meta=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/global-metadata.dat').read_bytes();assert hashlib.sha256(meta).hexdigest()=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9'
    so,sn,do,dn=struct.unpack_from('<4I',meta,8);dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True;slots=set();literals=[];metadata_values=set()
    for cfg in cfgs.values():
        for row in cfg['instructions']:
            ins=next(dis.disasm(bytes.fromhex(row['bytes']),int(row['va'],16)))
            if ins.mnemonic not in ['mov','lea']:continue
            for o in ins.operands:
                if o.type!=X86_OP_MEM or o.mem.base!=X86_REG_RIP:continue
                at=ins.address+ins.size+o.mem.disp;raw=im.pe.get_data(at-im.base,8)
                if len(raw)!=8:continue
                code=int.from_bytes(raw,'little')
                if code>0xffffffff or code>>29 not in range(1,8) or at in slots:continue
                slots.add(at);kind,index=code>>29,(code&0x1fffffff)>>1
                if kind==5:
                    n,pos=struct.unpack_from('<II',meta,so+8*index);literal=meta[do+pos:do+pos+n].decode('utf-8');put64(at,string(literal));literals.append(dict(slot=hex(at),value=literal))
                else:metadata_values.add(im.class_slot(at))
    assert {r['value'] for r in literals}=={'PeaShooter_mouth','LadderSaboteurs_bomb1','LadderSaboteurs_bomb2','Zombie_polevaulter_body1'}
    def init(p):assert p in slots
    im.hook(0x18024fef0,None,[P],init);im.hook(0x1802501e0,None,[P],lambda p:None)
    im.hook(0x18131f760,C.c_bool,[P,P,P],equal);im.hook(0x18131f900,C.c_bool,[P,P,P],unequal)
    im.hook(0x180324150,P,[P,I,P],create);im.hook(0x181304510,P,[P,P],transform);im.hook(0x18132f3a0,P,[P,P,P],position)
    im.hook(0x18031b680,P,[P,P,P,P],sprite_position);im.hook(0x18031b790,P,[P,P,P],sprite_name);im.hook(0x18131bf10,C.c_bool,[P,P],active);im.hook(0x18031bac0,None,[P,P,P],hide)
    im.hook(0x1804a25f0,None,[P,P,P,P,F,I,P,P],initial6);im.hook(0x1804a24e0,None,[P,P,P,P,F,F,I,P,P],initial)
    im.hook(0x180350e20,P,[P,P,I,P],pd2);im.hook(0x180350e40,P,[P,P,I,I,P],pd3);im.hook(0x180360d00,P,[P,I,P,I,P],zd3);im.hook(0x18037c0f0,None,[P,P,I,P],set_damage)
    im.hook(0x180386570,None,[P,P,P,P,P],function);im.hook(0x180386040,None,[P,P,P,P,P,P],end)
    for rid,cfg in cfgs.items():im.verify_caller(rid,int(cfg['entry'],16),cfg)
    cases=json.loads((Q/'CASES.json').read_bytes());rows=[]
    for q in cases:
        if not q['native_comparable']:continue
        if '--trace-cases' in sys.argv:print(json.dumps(dict(starting_case=q['name'])),flush=True)
        rid=int(q['token'],16)&0xffffff;state.clear();state.update(q=q,rid=rid,tags={},live={},trace=[])
        for name,size in [('plant',1024),('other',1024),('zombie',1024),('event',128),('board',1024),('manager',128),('projectile',1024),('damage',128),('transform',64),('bomb',64),('skill',128),('skill2',128),('plantSprites',64),('otherSprites',64),('zombieSprites',64)]:
            a=im.alloc(size);state[name]=a;state['tags'][a]=('eventTransform' if name=='transform' else name);state['live'][a]=q.get(name,1)==1
        def ref(name):return state[name] if q.get(name,1)!=0 else 0
        for owner,obj in [('Plant','plant'),('Plant','other'),('Zombie','zombie')]:
            put64(state[obj]+off(owner,'board'),ref('board'));put32(state[obj]+off(owner,'camp'),300 if obj=='other' else q['camp']);put64(state[obj]+off(owner,'animationSprites'),state[{'plant':'plantSprites','other':'otherSprites','zombie':'zombieSprites'}[obj]])
        put64(state['event']+off('PlantAnimationEvent','plant'),ref('plant'));put64(state['board']+off('Board','projectileManager'),ref('manager'));state['made']=ref('projectile')
        C.c_ubyte.from_address(state['plant']+off('Plant','supperHit')).value=q.get('supper',0);put64(state['plant']+off('Plant','skill'),state['skill']);put32(state['skill']+off('Skill','ID'),q.get('skill',1));put32(state['skill2']+off('Skill','ID'),2)
        C.c_ubyte.from_address(state['zombie']+off('Zombie','ashes')).value=q.get('ashes',0);write_vec(state['zombie']+off('Zombie','rDirection'),q['direction']);write_vec(state['zombie']+off('Zombie','fX'),q['position']);put32(state['zombie']+off('Zombie','ladderSaboteurs_C4'),q['c4'])
        entry=int(cfgs[rid]['entry'],16)
        if rid==0x37e:C.CFUNCTYPE(None,P,P,P)(entry)(state['plant'],ref('zombie'),None)
        else:C.CFUNCTYPE(None,P,P)(entry)(state['event'] if rid==0xba else state['plant'] if rid==0x3ae else state['zombie'],None)
        assert not im.errors,(q,im.errors)
        snap=dict(plant_camp=get32(state['plant']+off('Plant','camp')),other_camp=get32(state['other']+off('Plant','camp')),zombie_camp=get32(state['zombie']+off('Zombie','camp')),c4=get32(state['zombie']+off('Zombie','ladderSaboteurs_C4')),supper=bool(C.c_ubyte.from_address(state['plant']+off('Plant','supperHit')).value),event_plant=tag(get64(state['event']+off('PlantAnimationEvent','plant'))),plant_skill=tag(get64(state['plant']+off('Plant','skill'))))
        rows.append(dict(name=q['name'],token=q['token'],error=None,trace=list(state['trace']),state=snap))
    actual=json.loads(Path(sys.argv[1]).read_bytes());digest=hashlib.sha256((W/'startup-r20-sites100/authored3.dll').read_bytes()).hexdigest();assert actual['candidate_sha256']==digest
    found={r['name']:r for r in actual['results']};assert set(found)=={q['name'] for q in cases};diff=[dict(original=r,actual=found[r['name']]) for r in rows if r!=found[r['name']]]
    report=dict(scope='FIVE_COMPLETE_EXISTING_ORIGINAL_PROJECTILE_CALLERS',candidate_sha256=digest,original_pc_sha256=hashlib.sha256(im.raw).hexdigest(),caller_bytes_verified=5,normal_records=len(rows),managed_only_records=sum(not q['native_comparable'] for q in cases),counts=dict(collections.Counter(r['token'] for r in rows)),results=rows,differences=diff,callback_errors=im.errors,literals_materialized_from_original_metadata=literals,native_sret_vector3_and_stack_generic_arguments_preserved=True,
        new_game_dll_changes=0,controlled_leaves=['Unity object lifetime, transform position, activeSelf','Projectile manager, generic Initial, damage contracts','Animation lookup/hide, Skill.Function/End'],not_callee_body_or_unity_acceptance=True,formal_or_product_acceptance=False)
    Path(sys.argv[2]).write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in report.items() if k not in ['results','differences']}));print('differences',len(diff));raise SystemExit(2 if diff else 0)
finally:im.close()
