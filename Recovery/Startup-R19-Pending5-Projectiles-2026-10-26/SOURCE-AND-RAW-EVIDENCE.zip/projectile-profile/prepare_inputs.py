from pathlib import Path
import collections,itertools,json,struct
Q=Path(__file__).resolve().parent
bits=lambda x:struct.pack('>f',x).hex().upper()
vectors=[[bits(x) for x in a] for a in [[0.,-0.,2**-149],[1.25,2.5,-3.5],[-100,99,1e30],[3.4e38,-3.4e38,-2**-149]]]
rows=[]
def add(rid,**kw):rows.append(dict(name=f'p{len(rows):05}',token=f'0x{0x6000000|rid:08X}',native_comparable=True,**kw))
for pos,mut,camp in itertools.product(vectors,range(4),[-1,0,1,2147483647]):
 base=dict(position=pos,direction=[bits(x) for x in [1,-.5,.125]],mutation=mut,camp=camp,c4=0,active=1)
 for plant,board,manager in itertools.product(range(3),repeat=3):add(0xba,**base,plant=plant,board=board,manager=manager,projectile=1)
 for zombie,ashes,projectile in itertools.product(range(3),range(2),range(3)):add(0x37e,**base,zombie=zombie,ashes=ashes,projectile=projectile)
 for supper,skill,proj in [(0,1,1),(0,1,2),(1,0,1),(1,1,1),(1,2,1)]:add(0x3ae,**base,supper=supper,skill=skill,projectile=proj)
 for proj,active,c4 in itertools.product(range(3),range(2),[-2147483648,0,1,2,2147483647]):
  b={**base,'active':active,'c4':c4};add(0x49b,**b,projectile=proj)
 for proj in range(3):add(0x4a2,**base,projectile=proj)
for pos in vectors:
 add(0x3ae,position=pos,direction=pos,mutation=4,camp=7,supper=1,skill=1,c4=0,active=1)
 for field in ['board','manager']:
  for rid in [0x3ae,0x49b,0x4a2]:
   add(rid,position=pos,direction=pos,mutation=0,camp=7,c4=1,active=1,**{field:0});rows[-1]['native_comparable']=False
 add(0x3ae,position=pos,direction=pos,mutation=0,camp=7,c4=0,active=1,supper=1,nullSkill=True);rows[-1]['native_comparable']=False
(Q/'CASES.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode());print(json.dumps(dict(records=len(rows),counts=dict(collections.Counter(r['token'] for r in rows)),managed_only=sum(not r['native_comparable'] for r in rows))))
