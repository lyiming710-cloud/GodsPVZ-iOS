from pathlib import Path
import collections,json,struct,subprocess
from archive_support import sha,js,pack,manifest
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';D=R/'Recovery/Startup-R8-2026-10-25';E=W/'r8-editor-run-40115001552';B=W/'r8-shader-programs-40115001552'
shader=json.loads((E/'custom-shader-audit.json').read_bytes());startup=json.loads((E/'startup-play-probe.json').read_bytes());asset=json.loads((E/'startup-asset-audit.json').read_bytes())
assert shader['pass'] and len(shader['compilations'])==76 and len(shader['pixels'])==20 and not shader['errors']
assert collections.Counter(r['platform'] for r in shader['compilations'])=={'Metal':38,'OpenGLCore':38}
assert shader['negative_compile_control'] and all(r['success'] and r['bytes']>0 for r in shader['compilations'])
assert all(r['pass'] and r['max_error']<.003 for r in shader['pixels']) and not shader['metal_device_execution'] and not shader['game_pixel_equivalence']
assert shader['pipeline_asset_guid']=='22c2bf3291e4d8f4db5d66a87a6f8123' and shader['render_pipeline_tag']=='UniversalPipeline' and shader['initialized_original_pipeline_for_headless_render']
assert startup['pass'] and startup['frames']==2113 and startup['active_canvases']==2 and startup['main_ui_components']==1 and not startup['errors'] and startup['active_scene']=='MainMenu'
assert not startup['device_execution'] and not startup['pixel_equivalence']
assert asset['pass'] and asset['original_serialization_markers']==130 and asset['resolved_plugin_scripts']==148 and asset['missing_components']==0 and asset['unresolved_custom_dummy_shaders']==[] and not asset['errors']
assert (E/'test-dll-after-reimport.sha256').read_text().strip()=='6189387c6af11108eba9a9855bfd6d6af567ec000a4999d1ed1b0328ba0e1d08'
assert (E/'license-return-exit.txt').read_text().strip()=='0'
names=set()
for row in shader['compilations']:
    prefix='game' if row['shader']=='Unlit/GameUnitShader' else 'brightness';suffix='_'.join(k[-1] for k in row['keywords'].split());name=f"shader-{prefix}-p{row['pass']}-{row['platform']}-{row['stage']}-{suffix}.bin"
    b=(B/name).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'];names.add(name)
for row in shader['pixels']:
    name='render-'+row['name']+'.png';b=(B/name).read_bytes();assert b[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack_from('>II',b,16)==(32,32);names.add(name)
assert names=={p.name for p in B.iterdir() if p.is_file()} and len(names)==96
p=subprocess.run(['C:/Program Files/GitHub CLI/gh.exe','run','view','40115001552','--repo','lyiming710-cloud/GodsPVZ-iOS','--json','databaseId,status,conclusion,headSha,url,jobs'],capture_output=True);assert p.returncode==0
run=json.loads(p.stdout);assert run['status']=='completed' and run['conclusion']=='success' and run['headSha']=='f3739e6a7d5562fe9c7dd844697b9235b43ddd41' and all(j['conclusion']=='success' for j in run['jobs'])
items=[('evidence/'+p.relative_to(E).as_posix(),p.read_bytes()) for p in sorted(E.rglob('*')) if p.is_file()]+[('shader-output/'+p.name,p.read_bytes()) for p in sorted(B.iterdir()) if p.is_file()]
items+=[('record_r8_editor.py',Path(__file__).read_bytes()),('archive_support.py',(W/'archive_support.py').read_bytes())]
pack(D/'ACTUAL-EDITOR-AND-SHADERS-40115001552.zip',items);js(D/'RUN-40115001552.json',run);js(D/'ACTUAL-EDITOR-READBACK.json',dict(shader=shader,startup=startup,asset=asset))
current=json.loads((D/'CURRENT-RESULT.json').read_bytes());current.update(status='REAL_EDITOR_MAINMENU_AND_SHADER_DIAGNOSTIC_PASS_FULL_PIPELINE_HELD',editor_diagnostic='PASS_SCOPED_ONLY',editor_run=run['url'],editor_source_commit=run['headSha'],
    normal_mainmenu_frames=2113,normal_mainmenu_errors=0,metal_stage_compilations=38,opengl_stage_compilations=38,controlled_pixel_readbacks=20,controlled_pixel_max_error=max(r['max_error'] for r in shader['pixels']),
    raw_program_and_png_files_verified=96,personal_seat_return_exit=0,game_pixel_equivalence=False,metal_device_execution=False,ipa=None)
js(D/'CURRENT-RESULT.json',current)
readme=D/'README.md';text=readme.read_text('utf-8');mark='## Actual Editor result 40115001552'
if mark not in text:readme.write_bytes((text+'''\n## Actual Editor result 40115001552\n\nRun 40115001552 at source f3739e6 completed successfully on exact R8. The actual Editor advances the separate normal MainMenu probe 2,113 frames with two active Canvases, one MainUIController and no errors. Asset audit resolves all 148 plugin scripts, all 130 original serialization markers, zero missing components and no unresolved custom dummy shaders. The original configured URP asset is used. All 76 shader stages compile (38 Metal, 38 OpenGLCore); the deliberately broken shader is rejected; all 20 controlled OpenGL RGBA float readbacks pass. Every one of the 76 raw program buffers is rehashed against its report, and 20 byte-preserved 32x32 PNGs are retained. Personal seat return exits zero.\n\nThis confirms the specified real Editor startup/shader scopes for R8. It does not execute Metal on an iPad, render the full game camera for comparison, play Board, test physical audio, export Xcode or produce an IPA. Full failed/unsupported type and access queues remain held. The live workflow's job named export performs a diagnostic and does not call the iOS exporter.\n''').encode())
manifest(D);print(json.dumps(dict(run=run['url'],candidate=current['candidate_sha256'],frames=2113,shader_stages=76,controlled_pixels=20,raw_files=96,ipa=None)))
