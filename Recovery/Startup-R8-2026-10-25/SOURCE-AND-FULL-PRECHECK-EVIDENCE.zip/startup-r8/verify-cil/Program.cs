using System.Security.Cryptography;using System.Text.Json;using Mono.Cecil;using Mono.Cecil.Cil;
public static class Program
{
    static HashSet<Instruction> Reach(MethodDefinition m)
    {
        var seen=new HashSet<Instruction>();var queue=new Stack<Instruction>();queue.Push(m.Body.Instructions[0]);
        foreach(var eh in m.Body.ExceptionHandlers){queue.Push(eh.HandlerStart);if(eh.FilterStart!=null)queue.Push(eh.FilterStart);}
        while(queue.TryPop(out var i))
        {
            if(!seen.Add(i))continue;if(i.OpCode.Code==Code.Jmp||i.OpCode.FlowControl is FlowControl.Return or FlowControl.Throw)continue;
            if(i.OpCode.FlowControl==FlowControl.Branch){queue.Push((Instruction)i.Operand);continue;}
            if(i.OpCode.FlowControl==FlowControl.Cond_Branch){if(i.Operand is Instruction t)queue.Push(t);else foreach(var target in (Instruction[])i.Operand)queue.Push(target);}
            if(i.Next!=null)queue.Push(i.Next);
        }
        return seen;
    }
    static string Clause(ExceptionHandler e)=>$"{e.HandlerType}:{e.TryStart.Offset}:{e.TryEnd.Offset}:{e.HandlerStart.Offset}:{e.HandlerEnd.Offset}:{e.CatchType?.FullName}:{e.FilterStart?.Offset}";
    public static void Main(string[] args)
    {
        byte[] old=File.ReadAllBytes(args[0]),changed=File.ReadAllBytes(args[1]);string parent=Convert.ToHexString(SHA256.HashData(old)).ToLowerInvariant(),candidate=Convert.ToHexString(SHA256.HashData(changed)).ToLowerInvariant();
        if(parent!="22d6aa537bfb71e40dcfa0fdd8776566278cf8fd9a4d4212a93fb7d49d3a8655"||candidate!="6189387c6af11108eba9a9855bfd6d6af567ec000a4999d1ed1b0328ba0e1d08")throw new InvalidOperationException("Pinned input mismatch");
        using var a=ModuleDefinition.ReadModule(new MemoryStream(old));using var b=ModuleDefinition.ReadModule(new MemoryStream(changed));var rows=new List<object>();
        foreach(int token in new[]{0x06000004,0x06000144,0x0600047A,0x060004D0,0x06000609,0x06000728})
        {
            var s=(MethodDefinition)a.LookupToken(token);var d=(MethodDefinition)b.LookupToken(token);var sr=Reach(s);var dr=Reach(d);
            if(s.RVA!=d.RVA||s.Body.MaxStackSize!=d.Body.MaxStackSize||s.Body.InitLocals!=d.Body.InitLocals||s.Body.LocalVarToken!=d.Body.LocalVarToken||s.ReturnType.FullName!=d.ReturnType.FullName||!s.Body.Variables.Select(v=>v.VariableType.FullName).SequenceEqual(d.Body.Variables.Select(v=>v.VariableType.FullName)))throw new InvalidOperationException("Unrelated header/local change");
            if(!sr.Select(i=>i.Offset).Order().SequenceEqual(dr.Select(i=>i.Offset).Order()))throw new InvalidOperationException("Changed reachable CFG including EH seeds");
            foreach(var i in sr){var j=d.Body.Instructions.Single(x=>x.Offset==i.Offset);if(i.OpCode.Value!=j.OpCode.Value||i.Operand?.ToString()!=j.Operand?.ToString())throw new InvalidOperationException("Changed reachable instruction");}
            if(!s.Body.ExceptionHandlers.Select(Clause).Order().SequenceEqual(d.Body.ExceptionHandlers.Select(Clause).Order()))throw new InvalidOperationException("Changed exception regions or handlers");
            if(token==0x06000004)
            {
                if(sr.Any(i=>i.Offset is 100 or 101 or 102)||s.Body.CodeSize!=d.Body.CodeSize||!s.Body.ExceptionHandlers.Select(Clause).SequenceEqual(d.Body.ExceptionHandlers.Select(Clause)))throw new InvalidOperationException("Try gap was reachable or EH changed");
                var leave=d.Body.Instructions.Single(i=>i.Offset==101);if(leave.OpCode.Code!=Code.Leave_S||((Instruction)leave.Operand).Offset!=113)throw new InvalidOperationException("Wrong dead-edge sealing");
            }
            else if(token==0x0600047A)
            {
                if(s.Body.CodeSize!=d.Body.CodeSize||d.Body.ExceptionHandlers[0].TryStart.Offset!=282||d.Body.ExceptionHandlers[1].TryStart.Offset!=257)throw new InvalidOperationException("Wrong nesting order");
            }
            else
            {
                if(s.Body.ExceptionHandlers.Count!=0||s.Body.Instructions[^2].OpCode.Code!=Code.Ldstr||s.Body.Instructions[^1].OpCode.Code!=Code.Pop||sr.Contains(s.Body.Instructions[^2])||sr.Contains(s.Body.Instructions[^1]))throw new InvalidOperationException("Trimmed executable code");
                if(d.Body.CodeSize!=s.Body.CodeSize-6||d.Body.Instructions.Count!=s.Body.Instructions.Count-2||d.Body.Instructions[^1].OpCode.FlowControl is not (FlowControl.Return or FlowControl.Branch or FlowControl.Throw))throw new InvalidOperationException("Wrong method boundary trim");
            }
            rows.Add(new {token="0x"+token.ToString("X8"),method=s.FullName,parent_code_size=s.Body.CodeSize,code_size=d.Body.CodeSize,reachable_instructions=sr.Count,normal_and_handler_reachability_unchanged=true,exception_regions_and_handlers_unchanged=true});
        }
        File.WriteAllText(args[2],JsonSerializer.Serialize(new {scope="INDEPENDENT_SIX_METHOD_CIL_AND_EH_FORM_DELTA_ONLY",parent_sha256=parent,candidate_sha256=candidate,methods=6,pass=true,behavior_or_native_unwind_equivalence=false,rows},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine("CIL_EH_FORM_PASS methods=6");
    }
}
