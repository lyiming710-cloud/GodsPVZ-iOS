"""Independent raw six-method boundary and unchanged frozen gates."""
from pathlib import Path
import hashlib,importlib.util,json,struct,subprocess,sys,collections
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'));import dnfile
sha=lambda b:hashlib.sha256(b).hexdigest();parent=(W/'startup-r7/candidate1.dll').read_bytes();candidate=Q/'candidate1.dll';data=candidate.read_bytes()
assert sha(parent)=='22d6aa537bfb71e40dcfa0fdd8776566278cf8fd9a4d4212a93fb7d49d3a8655' and sha(data)=='6189387c6af11108eba9a9855bfd6d6af567ec000a4999d1ed1b0328ba0e1d08'
proof=json.loads((Q/'INDEPENDENT-CIL-EH-FORM.json').read_bytes());assert proof['pass'] and proof['candidate_sha256']==sha(data) and proof['methods']==6
pe=dnfile.dnPE(data=parent);expected=bytearray(parent)
def loc(rid):
    at=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[rid-1].Rva);tiny=parent[at]&3==2
    return at,1 if tiny else (struct.unpack_from('<H',parent,at)[0]>>12)*4,parent[at]>>2 if tiny else struct.unpack_from('<I',parent,at+4)[0],tiny
for rid,old,new in [(0x144,65,59),(0x4D0,222,216),(0x609,90,84),(0x728,50,44)]:
    at,head,size,tiny=loc(rid);assert size==old and parent[at+head+new]==0x72 and parent[at+head+old-1]==0x26
    if tiny:expected[at]=(new<<2)|2
    else:struct.pack_into('<I',expected,at+4,new)
at,head,_,tiny=loc(4);assert not tiny and parent[at+head+100:at+head+103]==b'\0'*3
expected[at+head+101:at+head+103]=bytes.fromhex('de0a');dead_gap=at+head+101
at,head,size,tiny=loc(0x47a);eh=(at+head+size+3)&~3;assert not tiny and parent[eh:eh+4]==bytes.fromhex('41340000')
outer=parent[eh+4:eh+28];inner=parent[eh+28:eh+52]
assert struct.unpack('<6I',outer)==(2,257,107,364,8,0) and struct.unpack('<6I',inner)==(2,282,57,339,8,0)
expected[eh+4:eh+52]=inner+outer
def audit(b):
    if b!=expected:raise ValueError('Only the independent four size trims, dead try edge and clause-row permutation are admitted')
audit(data);assert data==(Q/'candidate2.dll').read_bytes();controls=[]
for name,offset in [('reachable-start-code',loc(4)[0]+loc(4)[1]),('try-gap-regression',dead_gap),('finally-region-corruption',eh+8),('metadata-corruption',pe.get_offset_from_rva(pe.net.struct.MetaDataRva))]:
    b=bytearray(data);b[offset]^=1
    try:audit(bytes(b))
    except ValueError:controls.append(dict(name=name,rejected=True));continue
    raise AssertionError('Isolation false acceptance: '+name)
(Q/'ISOLATION.json').write_bytes((json.dumps(dict(scope='INDEPENDENT_SIX_METHOD_WHOLE_FILE_BYTE_BOUNDARY',candidate_sha256=sha(data),parent_sha256=sha(parent),direct_method_targets=6,untouched_methoddefs=2311,
    metadata_rvas_and_other_bytes_identical=True,normal_and_handler_reachable_cil_preserved=True,default_return_values_synthesized=0,finally_handlers_removed=0,pass_=True,negative_controls=controls),indent=2)+'\n').encode())
DOT=ROOT/'.local/dotnet10/dotnet.exe';SUPPORT=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'
EXPORT=ROOT/'audit/bulk250-r1-evidence-39702928368/bulk250-r1-run/tools_bin/CilExporter/bin/CilExporter.dll';CHECKER=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py'
assert sha(CHECKER.read_bytes())=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14'
spec=importlib.util.spec_from_file_location('unchanged_frozen',CHECKER);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
def run(label,args):
    p=subprocess.run([str(x) for x in args],capture_output=True);(Q/(label+'.stdout.log')).write_bytes(p.stdout);(Q/(label+'.stderr.log')).write_bytes(p.stderr);assert p.returncode==0,(label,p.returncode,p.stderr[:600])
prior_tokens={r['token'] for r in json.loads((W/'startup-r7/METHODS.json').read_bytes())['methods']};targets={r['token'] for r in proof['rows']};tokens=sorted(prior_tokens|targets)
(Q/'METHODS.json').write_bytes((json.dumps(dict(methods=[dict(token=t) for t in tokens]),indent=2)+'\n').encode())
run('union-cil-export',[DOT,EXPORT,candidate,Q/'UNION-CIL.json',SUPPORT,','.join(tokens)])
cil=json.loads((Q/'UNION-CIL.json').read_text('utf-8-sig'));results=[]
for m in cil['methods']:
    try:r=v.verify(m,cil['types'])
    except Exception as e:r=dict(token=m['token'],status='FAIL_OR_UNSUPPORTED',error=str(e))
    results.append(r)
prior45={m['token'] for m in json.loads((W/'startup-r6/FORTY-FIVE-CIL.json').read_bytes())['methods']};assert all(r['status']=='PASS' for r in results if r['token'] in prior45)
report=dict(scope='UNCHANGED_FROZEN_STACK_UNION_NOT_WHOLE_RUNTIME_ACCEPTANCE',candidate_sha256=sha(data),total=len(tokens),counts=dict(collections.Counter(r['status'] for r in results)),prior_45_passed=True,results=results)
(Q/'FROZEN-UNION.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
out=Q/'buff-runtime-results';out.mkdir(exist_ok=True);bad=bytearray(data);at,head,_,_=loc(0x5E7)
for offset in [279,819]:assert data[at+head+offset]==0x20;bad[at+head+offset:at+head+offset+9]=b'\x21'+struct.pack('<q',4294967295)
mutant=out/'int64-sentinel-restored.dll';mutant.write_bytes(bad);run('int64-export',[DOT,EXPORT,mutant,Q/'INT64-CONTROL-CIL.json',SUPPORT,'0x060005E7'])
bc=json.loads((Q/'INT64-CONTROL-CIL.json').read_text('utf-8-sig'))
try:failure=v.verify(bc['methods'][0],bc['types'])
except Exception as e:failure=dict(token='0x060005E7',status='FAIL',error=str(e))
assert failure['status']!='PASS'
(Q/'INT64-NEGATIVE-WIDTH.json').write_bytes((json.dumps(dict(scope='UNCHANGED_FROZEN_WIDTH_GATE_ON_PHYSICAL_INT64_MUTANT',baseline_passed=True,mutant_sha256=sha(bad),checker_sha256=sha(CHECKER.read_bytes()),runtime_did_not_distinguish=True,rejected=True,result=failure),indent=2)+'\n').encode())
print(json.dumps(dict(isolation_methods=6,boundary_controls=4,union_methods=len(tokens),frozen_counts=report['counts'],prior45_passed=True,int64_control_rejected=True),indent=2))
