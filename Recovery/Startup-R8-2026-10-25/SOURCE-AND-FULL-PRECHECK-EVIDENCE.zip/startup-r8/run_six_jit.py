from pathlib import Path
import subprocess,json
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];O=Q/'exact-jit-results';O.mkdir(exist_ok=True);rows=[]
for token in ['0x06000004','0x06000144','0x0600047A','0x060004D0','0x06000609','0x06000728']:
    pair=dict(token=token)
    for label,dll in [('parent',W/'startup-r7/candidate1.dll'),('candidate',Q/'candidate1.dll')]:
        output=O/(token+'-'+label+'.json');p=subprocess.run([str(ROOT/'.local/dotnet10/dotnet.exe'),str(W/'startup-r5/jit-probe/bin/Release/net10.0/Probe.dll'),str(dll),str(ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'),token,str(output)],capture_output=True)
        (O/(token+'-'+label+'.stdout.log')).write_bytes(p.stdout);(O/(token+'-'+label+'.stderr.log')).write_bytes(p.stderr);assert p.returncode==0;pair[label]=json.loads(output.read_bytes())
    rows.append(pair)
report=dict(scope='EXACT_SIX_METHOD_CLR_JIT_NO_EXECUTION',parent_sha256='22d6aa537bfb71e40dcfa0fdd8776566278cf8fd9a4d4212a93fb7d49d3a8655',candidate_sha256='6189387c6af11108eba9a9855bfd6d6af567ec000a4999d1ed1b0328ba0e1d08',methods=6,
    parent_rejected=sum(r['parent']['status']=='REJECTED' for r in rows),candidate_prepared=sum(r['candidate']['status']=='JIT_PREPARED_NO_EXECUTION' for r in rows),method_execution=False,rows=rows)
assert report['parent_rejected']==report['candidate_prepared']==6
(O/'RESULT.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print('SIX_BEFORE_AFTER_JIT_PASS')
