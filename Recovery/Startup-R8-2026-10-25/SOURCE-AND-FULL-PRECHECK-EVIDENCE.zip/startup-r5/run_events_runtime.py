from pathlib import Path
import hashlib,json,subprocess,sys,struct,itertools
Q=Path(__file__).resolve().parent;ROOT=Q.parents[2];OUT=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else Q.parent/'startup-r6/events-runtime-results';OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'));import dnfile
sequences=[['E:A'],['D:A'],['E:A','D:A'],['D:A','E:A'],['E:A','E:A','D:A'],['E:A','E:B','D:A'],['E:A','E:B','D:B','D:A'],['E:B','D:A','D:B']]
cases=[dict(name='case-'+str(n),handler=h,steps=s,callback=c) for n,(h,s,c) in enumerate(itertools.product([0,1,2],sequences,['none','replace-handler-on-truth','replace-handler-on-getcomponent','replace-handler-on-add-character','replace-handler-on-remove-character']))]
(OUT/'CASES.json').write_bytes((json.dumps(cases,indent=2)+'\n').encode());dot=ROOT/'.local/dotnet10/dotnet.exe';fixture=Q/'runtime-events/bin/Release/net10.0/Fixture.dll';candidate=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Q.parent/'startup-r6/candidate1.dll';raw=candidate.read_bytes();sha=hashlib.sha256(raw).hexdigest();assert sha in ['c36092b5326687112adfa8c285bb3cf5e8ad46d3b3de8ebcd84daf598041465d','22d6aa537bfb71e40dcfa0fdd8776566278cf8fd9a4d4212a93fb7d49d3a8655','6189387c6af11108eba9a9855bfd6d6af567ec000a4999d1ed1b0328ba0e1d08']
def run(label,args):
    p=subprocess.run(args,capture_output=True);(OUT/(label+'.stdout.log')).write_bytes(p.stdout);(OUT/(label+'.stderr.log')).write_bytes(p.stderr)
    if p.returncode:raise RuntimeError(f'{label} exit={p.returncode}: '+p.stderr.decode('utf-8','replace')[:1200])
run('native',[sys.executable,str(Q/'native_events_oracle.py'),str(OUT/'CASES.json'),str(OUT/'NATIVE.json')])
run('actual-cil',[str(dot),str(fixture),str(candidate),str(OUT/'CASES.json'),str(OUT/'ACTUAL-CIL.json')])
native=json.loads((OUT/'NATIVE.json').read_bytes())['results'];cil=json.loads((OUT/'ACTUAL-CIL.json').read_bytes())['results'];assert len(native)==len(cil)==len(cases)
diff=[dict(name=a['name'],native=a,cil=b) for a,b in zip(native,cil) if a!=b]
pe=dnfile.dnPE(data=raw)
def body(rid):
    p=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[rid-1].Rva);return p+(struct.unpack_from('<H',raw,p)[0]>>12)*4
e,d=body(0x7B7),body(0x7B8);mutants={}
b=bytearray(raw);assert b[e+117]==0x28;b[e+118:e+122]=raw[e+173:e+177];mutants['character-registered-on-sprite-event']=bytes(b)
b=bytearray(raw);assert b[d+96]==0x28;b[d+97:d+101]=raw[e+127:e+131];mutants['disable-adds-instead-of-removes-character']=bytes(b)
b=bytearray(raw);assert b[e+66]==0x7d;b[e+66:e+71]=bytes.fromhex('2626000000');mutants['text-component-write-omitted']=bytes(b)
for label,at in [('enable-early-return',e),('disable-early-return',d)]:
    b=bytearray(raw);b[at:at+5]=b'\x2a\0\0\0\0';mutants[label]=bytes(b)
controls=[]
def control(name,dll,digest):
    run(name,[str(dot),str(fixture),str(dll),str(OUT/'CASES.json'),str(OUT/(name+'.json'))]);r=json.loads((OUT/(name+'.json')).read_bytes())['results'];detected=sum(a!=b for a,b in zip(native,r));controls.append(dict(name=name,mutant_sha256=digest,detected_cases=detected,baseline_pass=not diff,pass_=not diff and detected>0))
for name,data in mutants.items():
    dll=OUT/(name+'.dll');dll.write_bytes(data);control(name,dll,hashlib.sha256(data).hexdigest())
parent=Q/'candidate1.dll';control('parent-unterminated-tails',parent,hashlib.sha256(parent.read_bytes()).hexdigest())
report=dict(scope='TWO_EVENT_CALLERS_ACTUAL_CIL_VS_ORIGINAL_PC_NATIVE_CONTROLLED_EVENT_SYSTEM_ONLY',candidate_sha256=sha,method_tokens=['0x060007B7','0x060007B8'],cases=len(cases),
            pass_=not diff and all(c['pass_'] for c in controls),differences=diff,negative_controls=controls,exceptions_native_unwind_modeled=False,unity_event_implementation_executed=False,original_event_handlers_executed=False,unity_execution=False,whole_six_method_acceptance=False)
(OUT/'RESULT.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({**report,'differences':diff[:2]},indent=2));assert report['pass_']
