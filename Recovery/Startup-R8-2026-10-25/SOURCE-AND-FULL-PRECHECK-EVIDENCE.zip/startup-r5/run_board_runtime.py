from pathlib import Path
import hashlib,json,subprocess,sys,struct,itertools
Q=Path(__file__).resolve().parent;ROOT=Q.parents[2]
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
OUT=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else Q/'board-runtime-results';OUT.mkdir(exist_ok=True)
cases=[]
for end,dt,volume,won in itertools.product(['1','0','-0','-1','NaN','Inf','-Inf','1.40129846e-45','0.05'],['0','0.1','1','2','NaN','Inf','-Inf'],['0','-0','-1','1','NaN','Inf'],[True,False]):
    cases.append(dict(name=f'grid-{len(cases):04}',end=end,dt1=dt,dt2='0.25',volume=volume,bgm='0.8',won=won,callback='none'))
for bgm in ['NaN','Inf','-Inf','0','-1']:
    cases.append(dict(name='bgm-'+bgm,end='0.05',dt1='0.1',dt2='0.25',volume='1',bgm=bgm,won=True,callback='none'))
for callback in ['replace-manager-on-create','replace-config-on-create','replace-lawn-on-create','replace-manager-on-pass']:
    for volume in ['0','1']:
        cases.append(dict(name=callback+'-v'+volume,end='0.05',dt1='0.1',dt2='0.25',volume=volume,bgm='0.8',won=True,callback=callback))
(OUT/'CASES.json').write_bytes((json.dumps(cases,indent=2)+'\n').encode())
def run(label,args):
    p=subprocess.run(args,capture_output=True)
    (OUT/(label+'.stdout.log')).write_bytes(p.stdout);(OUT/(label+'.stderr.log')).write_bytes(p.stderr)
    if p.returncode:raise RuntimeError(f'{label} exit={p.returncode}: '+p.stderr.decode('utf-8','replace')[:700])
dot=ROOT/'.local/dotnet10/dotnet.exe';fixture=Q/'runtime-board/bin/Release/net10.0/Fixture.dll';candidate=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Q/'candidate1.dll'
raw=candidate.read_bytes();sha=hashlib.sha256(raw).hexdigest();assert sha in ['7fa02b81d4d1af579a18eea103f776493f012565e64d5b38fd885cf40718a296','c36092b5326687112adfa8c285bb3cf5e8ad46d3b3de8ebcd84daf598041465d','22d6aa537bfb71e40dcfa0fdd8776566278cf8fd9a4d4212a93fb7d49d3a8655','6189387c6af11108eba9a9855bfd6d6af567ec000a4999d1ed1b0328ba0e1d08']
run('native',[sys.executable,str(Q/'native_board_oracle.py'),str(OUT/'CASES.json'),str(OUT/'NATIVE.json')])
run('actual-cil',[str(dot),str(fixture),str(candidate),str(OUT/'CASES.json'),str(OUT/'ACTUAL-CIL.json')])
native=json.loads((OUT/'NATIVE.json').read_bytes());cil=json.loads((OUT/'ACTUAL-CIL.json').read_bytes())
assert not cil['diagnostic_appended_ret'],'Diagnostic accommodation is not candidate qualification'
assert len(native['results'])==len(cil['results'])==len(cases)
diff=[dict(name=a['name'],native=a,cil=b) for a,b in zip(native['results'],cil['results']) if a!=b]
pe=dnfile.dnPE(data=raw);start=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[0x2AD-1].Rva);header=(struct.unpack_from('<H',raw,start)[0]>>12)*4;body=start+header
mutants={}
b=bytearray(raw);assert b[body+377:body+379]==bytes.fromhex('fe05');b[body+377:body+379]=bytes.fromhex('fe04');mutants['ordered-comparison-NaN-regression']=bytes(b)
b=bytearray(raw);b[body:body+5]=b'\x2a\0\0\0\0';mutants['early-return']=bytes(b)
b=bytearray(raw);assert b[body+241]==0x28;b[body+241:body+246]=bytes.fromhex('2626000000');mutants['volume-write-omitted']=bytes(b)
b=bytearray(raw);assert b[body+197]==0x22;struct.pack_into('<f',b,body+198,1.0);mutants['fade-factor-doubled']=bytes(b)
controls=[]
for name,data in mutants.items():
    dll=OUT/(name+'.dll');dll.write_bytes(data)
    run(name,[str(dot),str(fixture),str(dll),str(OUT/'CASES.json'),str(OUT/(name+'.json'))])
    results=json.loads((OUT/(name+'.json')).read_bytes())['results'];detected=sum(a!=b for a,b in zip(native['results'],results))
    controls.append(dict(name=name,mutant_sha256=hashlib.sha256(data).hexdigest(),detected_cases=detected,baseline_pass=not diff,pass_=not diff and detected>0))
report=dict(scope='BOARD_UPDATE_ISWON_ACTUAL_CIL_VS_ORIGINAL_PC_NATIVE_CONTROLLED_NORMAL_PATHS_ONLY',candidate_sha256=sha,method_token='0x060002AD',cases=len(cases),
            pass_=not diff and all(c['pass_'] for c in controls),differences=diff,negative_controls=controls,exceptions_native_unwind_modeled=False,
            unity_execution=False,whole_six_method_acceptance=False)
(OUT/'RESULT.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({**report,'differences':diff[:8]},indent=2));assert report['pass_']
