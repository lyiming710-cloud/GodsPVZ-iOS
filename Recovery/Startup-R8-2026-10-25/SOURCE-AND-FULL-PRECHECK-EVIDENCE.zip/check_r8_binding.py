from pathlib import Path
import hashlib,importlib.util,json,sys,tempfile,zipfile
W=Path(__file__).resolve().parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113';P=R/'scripts/actions/bind_startup_r8_diagnostic.py'
spec=importlib.util.spec_from_file_location('r8_binding',P);b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
with zipfile.ZipFile(R/'Recovery/Bulk401-Generic-Repair-2026-10-24/BULK401-CANDIDATE.zip') as z:parent=z.read('BULK401-CANDIDATE.dll')
assert hashlib.sha256(parent).hexdigest()==b.PARENT
checks=[]
with tempfile.TemporaryDirectory(prefix='godspvz-r8-bind-') as tmp:
    root=Path(tmp)
    def setup(name,wrong_source=False,wrong_hash=False):
        out=root/name;(out/'candidate').mkdir(parents=True);(out/'evidence').mkdir()
        raw=bytes([parent[0]^1])+parent[1:] if wrong_hash else parent
        (out/'candidate/Assembly-CSharp-bulk401.dll').write_bytes(raw)
        p=dict(source_commit='wrong' if wrong_source else 'local-contract-control',status='BULK401_LINUX_AND_APPLE_CPP_PRECHECK_PASS',outputs={'unlinked':{'sha256':b.PARENT}})
        (out/'evidence/PROVENANCE.json').write_bytes((json.dumps(p)+'\n').encode());return out
    for name,opts in [('wrong-parent-bytes',dict(wrong_hash=True)),('wrong-provenance-source',dict(wrong_source=True))]:
        out=setup(name,**opts);before=(out/'candidate/Assembly-CSharp-bulk401.dll').read_bytes()
        try:b.bind(out,'local-contract-control')
        except ValueError as e:
            assert (out/'candidate/Assembly-CSharp-bulk401.dll').read_bytes()==before and not (out/'evidence/PARENT-BULK401-PROVENANCE.json').exists();checks.append(dict(name=name,rejected=True,reason=str(e)))
        else:raise AssertionError('Binding accepted '+name)
    out=setup('exact-child');receipt=b.bind(out,'local-contract-control')
    assert hashlib.sha256((out/'candidate/Assembly-CSharp-bulk401.dll').read_bytes()).hexdigest()==b.CANDIDATE
    assert receipt['parent_compiler_results_apply_to_child'] is False and receipt['ipa_promotion_allowed'] is False and receipt['failed_whole_assembly_gates_preserved']['all_pass'] is False
    checks.append(dict(name='exact-child-preserves-scope-and-holds',pass_=True))
    try:b.bind(out,'local-contract-control')
    except ValueError as e:checks.append(dict(name='repeat-binding-refused',rejected=True,reason=str(e)))
    else:raise AssertionError('Repeated mutation accepted')
result=dict(scope='LICENSE_FREE_INPUT_BINDING_CONTRACT_ONLY_NOT_COMPILER_OR_UNITY_TEST',candidate_sha256=b.CANDIDATE,binding_source_sha256=hashlib.sha256(P.read_bytes()).hexdigest(),checks=checks,unity_started=False,ipa_created=False)
(W/'startup-r8/BINDING-CONTROLS.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result,indent=2))
