from pathlib import Path
import json
from archive_support import sha,record,js,pack,variants,manifest
W=Path(__file__).resolve().parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113';Q=W/'startup-r8';D=R/'Recovery/Startup-R8-2026-10-25';D.mkdir(exist_ok=True)
data=(Q/'candidate1.dll').read_bytes();digest=sha(data);assert digest=='6189387c6af11108eba9a9855bfd6d6af567ec000a4999d1ed1b0328ba0e1d08'
form=json.loads((Q/'INDEPENDENT-CIL-EH-FORM.json').read_bytes());assert form['pass'] and form['methods']==6
matrix=json.loads((Q/'exact-jit-results/RESULT.json').read_bytes());assert matrix['parent_rejected']==matrix['candidate_prepared']==6
whole=json.loads((Q/'all-exact-jit-results/RESULT.json').read_bytes());assert whole['counts']=={'JIT_PREPARED_NO_EXECUTION':2240,'UNSUPPORTED':50,'REJECTED':7}
runtime=[]
for suite in ['admin','board','system','buff','events']:
    r=json.loads((Q/f'{suite}-runtime-results/RESULT.json').read_bytes());assert r['pass_'] and r['candidate_sha256']==digest;runtime.append(dict(suite=suite,result=r))
js(Q/'RUNTIME-SUMMARY.json',dict(scope='SIX_PRIOR_CONTROLLED_CALLER_SCOPES_REEXECUTED_ON_R8',candidate_sha256=digest,cases=sum(r['result']['cases'] for r in runtime),methods=6,suites=runtime,whole_game_acceptance=False))
assert sum(r['result']['cases'] for r in runtime)==2475
names={m['token']:m['name'] for m in json.loads((Q/'ALL-CIL.json').read_bytes())['methods']}
queue=[dict(token=r['token'],name=names[r['token']],error=r.get('error')) for r in whole['rows'] if r['status']=='REJECTED'];assert len(queue)==7
js(Q/'NEXT-JIT-QUEUE.json',dict(candidate_sha256=digest,scope='ACTUAL_CLR_REJECTIONS_NOT_TOTAL_GAME_BUG_COUNT',rows=queue,open_generics_pending=50))
js(Q/'PHYSICAL-VARIANTS.json',dict(scope='EXACT_RECONSTRUCTABLE_EXECUTED_FAULT_CONTROLS',variants=variants(Q,data)))
(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text whitespace=cr-at-eol\n*.md -text\n*.zip -text\n*.yml -text\n')
for n in ['CONSTRUCTION.json','ISOLATION.json','INDEPENDENT-CIL-EH-FORM.json','FROZEN-UNION.json','INT64-NEGATIVE-WIDTH.json','LEXICAL-TAIL-CENSUS.json','RUNTIME-SUMMARY.json','NEXT-JIT-QUEUE.json','BINDING-CONTROLS.json']:(D/n).write_bytes((Q/n).read_bytes())
(D/'EXACT-JIT-SIX.json').write_bytes((Q/'exact-jit-results/RESULT.json').read_bytes());(D/'EXACT-JIT-ALL-2297.json').write_bytes((Q/'all-exact-jit-results/RESULT.json').read_bytes())
pack(D/'STARTUP-R8-CANDIDATE.zip',[('STARTUP-R8.dll',data)])
items=[]
for p in sorted(Q.rglob('*')):
    if not p.is_file() or any(x in ['obj','__pycache__'] for x in p.relative_to(Q).parts):continue
    if p.suffix=='.dll' and 'bin' not in p.relative_to(Q).parts:continue
    if p.name=='Mono.Cecil.dll' or p.suffix=='.exe':continue
    items.append((p.relative_to(W).as_posix(),p.read_bytes()))
for p in sorted((W/'startup-r5').rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(W/'startup-r5')
    if any(x in ['obj','__pycache__'] or x.endswith('-runtime-results') for x in rel.parts):continue
    if p.suffix=='.dll' and 'bin' not in rel.parts:continue
    if p.name=='Mono.Cecil.dll' or p.suffix=='.exe':continue
    if p.suffix not in ['.py','.cs','.csproj','.dll','.json','.pdb']:continue
    items.append((p.relative_to(W).as_posix(),p.read_bytes()))
for p in [W/'startup-r7/construct_r8_form.py',W/'archive_support.py',Path(__file__)]:items.append((p.relative_to(W).as_posix(),p.read_bytes()))
items.append(('check_r8_binding.py',(W/'check_r8_binding.py').read_bytes()))
for relative in ['.github/workflows/startup-r8-editor-diagnostic.yml','.github/workflows/startup-r2-editor-diagnostic.yml','scripts/actions/bind_startup_r8_diagnostic.py','scripts/actions/prepare_startup_r8_unity.py','scripts/actions/prepare_startup_r8_plugin.py']:
    items.append(('repository/'+relative,(R/relative).read_bytes()))
for p in [ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py']:
    items.append(('required-tools/reviewed/'+p.name,p.read_bytes()))
for folder,name in [(ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/member-bin','MemberAccess'),(ROOT/'audit/bulk250-r1-evidence-39702928368/bulk250-r1-run/tools_bin/CilExporter/bin','CilExporter')]:
    for p in sorted(folder.iterdir()):
        if p.is_file() and p.suffix in ['.dll','.json']:items.append(('required-tools/'+name+'/'+p.name,p.read_bytes()))
for folder in ['remaining-native','administrator-next-native','next-runtime-native']:
    for p in sorted((W/folder).glob('*.normal-cfg.*')):items.append((p.relative_to(W).as_posix(),p.read_bytes()))
for p in [W/'startup-r5/runtime-admin/bin/Release/net10.0/Mono.Cecil.dll',ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support/Unity.VisualScripting.Core.exe']:items.append(('runtime-dependencies/'+p.name,p.read_bytes()))
pack(D/'SOURCE-AND-FULL-PRECHECK-EVIDENCE.zip',items)
js(D/'CURRENT-RESULT.json',dict(status='SIX_ADDITIONAL_FORM_REPAIRS_QUALIFIED_FOR_RESTRICTED_EDITOR_DIAGNOSTIC_ONLY',candidate_sha256=digest,parent_sha256='22d6aa537bfb71e40dcfa0fdd8776566278cf8fd9a4d4212a93fb7d49d3a8655',bytes=len(data),direct_form_targets=6,
    untouched_methoddefs=2311,metadata_and_rvas_unchanged=True,no_default_return_values=True,finally_handlers_preserved=True,independent_form_pass=True,exact_jit_parent_rejected=6,exact_jit_child_prepared=6,
    prior_six_method_controlled_cases=2475,runtime_fault_controls_detected=23,runtime_fault_controls_undetected=1,frozen_width_rejects_remaining_control=True,
    whole_assembly={'methods':2297,'jit':whole['counts'],'raw_frozen':{'pass':2136,'fail_or_unsupported':161},'interface_fact_frozen':{'pass':2164,'fail_or_unsupported':133},'member_rejected_sites':217,'member_rejected_methods':112,'member_unresolved':0,'unterminated_lexical_tails':5,'all_pass':False},
    frozen_union={'methods':180,'pass':168,'fail_or_unsupported':12,'prior45_passed':True},editor_diagnostic='NOT_RUN',registered_diagnostic_entry='.github/workflows/startup-r2-editor-diagnostic.yml',il2cpp='NOT_RUN',apple_cpp='NOT_RUN',ipa=None,ipad_device_acceptance=False))
(D/'README.md').write_bytes('''# Startup R8 — six form repairs, restricted Editor diagnostic candidate

2026-10-25. Candidate `6189387c6af11108eba9a9855bfd6d6af567ec000a4999d1ed1b0328ba0e1d08` (18,863,104 bytes), parent R7 `22d6aa53…3a8655`. This follows R7's 132 batch form repairs; the R7 checkpoint remains separate.

Four methods return string/int/Loot/char and had an unreachable six-byte warning tail. Only their CodeSize fields are shortened by six: GlobalStaticVars.GetPainterName, PlantSave.GetTalentNum_Unlocked, BoardEntry.GetLoot and TMP_PhoneNumberValidator.Validate. Every CIL byte remains intact; the old warning bytes become unused padding. No default value or return instruction is synthesized. No branch or exception entry targets the excluded tail, and the new lexical method end already terminates.

Administrator.Start has an unreachable NOP gap at the end of its try region. Two NOP bytes at IL_0065 are replaced with a short leave to the same existing continuation IL_0071. Reachable code, EH region boundaries, handler code, original reachable leave and other method bytes remain unchanged. This prevents unreachable lexical fallthrough into finally. Zombie.SetUIs has two properly nested finally rows in outer-first order. Only those two raw 24-byte rows are permuted inner-first. All region tuples, handler bodies, Dispose calls, locals and CIL bytes are preserved. This is exception-table form repair, not original native unwind qualification.

An independent actual-Cecil parser recomputes reachability using method entry plus every handler/filter entry, checks the unchanged reachable instructions and unchanged EH region/handler multisets, and validates all six targets. A separate raw reader verifies the exact whole-file changes and rejects four boundary mutants. All 2,311 other MethodDefs, metadata and RVAs remain untouched. The six actual methods are rejected by CLR before correction and prepare afterward; no game method is invoked by that JIT check.

The entire 2,297-body DLL was then freshly JIT checked using the identity-checked DLL/EXE reference resolver: 2,240 prepared, seven rejected, 50 open generic methods unsupported. NEXT-JIT-QUEUE is the precise rejection list. It is not the entire remaining-game-bug count. The lexical unterminated-tail queue is five. Read-only original native CFGs for the next seven targets are archived: four of the five boolean methods have original `xor al,al; ret`, and Plant.CanBear has `mov al,1; ret`. Their bodies have not been changed in R8.

The prior six controlled original-native/CIL caller suites were reexecuted on exact R8: all 2,475 case records remain equal in their documented callee-model scope. Twenty-three of 24 fault controls are detected by execution. The intentionally wrong Int64 sentinel is still undetected by permissive CLR truncation and is rejected by the unchanged frozen width checker instead; the false runtime result remains explicit.

Whole-assembly frozen types remain 2,136 PASS / 161 FAIL_OR_UNSUPPORTED, or 2,164 / 133 after supplementing exact direct interface metadata facts. The 180-method changed/prior union has 168 PASS and 12 retained type failures, including GetPainterName; the prior 45 still pass. Member access retains 217 rejected sites across 112 methods, zero unresolved. Its nonzero exit remains a failure. JIT preparation does not clear width, access or behavioral failures.

The candidate is eligible for a restricted real Editor/MainMenu/shader diagnostic while the broader queues are repaired. It is not qualified for full compiler/game/IPA promotion. Native exception unwind equivalence, complete Board gameplay, physical audio, iPad rendering/touch/save/load and a new unsigned IPA remain pending. No exception suppression or global visibility widening is used.

STARTUP-R8-CANDIDATE.zip and SOURCE-AND-FULL-PRECHECK-EVIDENCE.zip contain hashed members. Source archive includes construction, independent CIL/EH and raw validators, exact before/after and full JIT records, original-native/CIL fixtures with compiled tools, all original results/controls and exact reconstructable fault-variant deltas. Native oracles require Windows x64 and the existing hash-locked PC inputs. Runtime dependencies are separately identified; the original Unity package support folder remains required. Current fixture scripts include R8 input selection only; frozen checkers are unchanged.
'''.encode())
manifest(D);print(json.dumps(dict(checkpoint=str(D),candidate_sha256=digest,archives={p.name:p.stat().st_size for p in D.glob('*.zip')})))
