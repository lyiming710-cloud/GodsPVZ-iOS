"""Six further form repairs, no replacement gameplay implementation."""
from pathlib import Path
import hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];O=W/'startup-r8';O.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'));import dnfile
sha=lambda b:hashlib.sha256(b).hexdigest();parent=(Q/'candidate1.dll').read_bytes();assert sha(parent)=='22d6aa537bfb71e40dcfa0fdd8776566278cf8fd9a4d4212a93fb7d49d3a8655'
pe=dnfile.dnPE(data=parent);cil=json.loads((Q/'ALL-CIL.json').read_bytes());methods={m['token']:m for m in cil['methods']};out=bytearray(parent);changes=[];targets=[]
def loc(rid):
    at=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[rid-1].Rva);tiny=parent[at]&3==2;head=1 if tiny else (struct.unpack_from('<H',parent,at)[0]>>12)*4;size=parent[at]>>2 if tiny else struct.unpack_from('<I',parent,at+4)[0];return at,head,size,tiny
def patch(token,kind,at,replacement,details):
    old=parent[at:at+len(replacement)];out[at:at+len(replacement)]=replacement;changes.append(dict(token=token,kind=kind,file_offset=at,before=old.hex(),after=replacement.hex(),details=details));targets.append(token)
for token in ['0x06000144','0x060004D0','0x06000609','0x06000728']:
    m=methods[token];ins=m['instructions'];assert not m['handlers'] and m['ret']!='System.Void' and ins[-1]['opcode']=='pop' and ins[-2]['opcode']=='ldstr'
    assert ins[-2]['operand'].startswith('Warning: Method ends with non empty stack') and ins[-3]['opcode'] in ['ret','br','br.s','throw','rethrow','jmp']
    index={i['offset']:i for i in ins};offsets=list(index);edges={}
    for n,x in enumerate(offsets):
        i=index[x];op=i['opcode'];following=offsets[n+1:n+2]
        if op in ['ret','throw','rethrow','endfinally','endfilter','jmp']:to=[]
        elif op in ['br','br.s','leave','leave.s']:to=[i['operand']['target']]
        elif op.startswith('br') or op.split('.')[0] in ['beq','bge','bgt','ble','blt','bne']:to=[i['operand']['target']]+following
        elif op=='switch':to=i['operand']['targets']+following
        else:to=following
        edges[x]=to
    reached=set();pending=[0]
    while pending:
        x=pending.pop()
        if x in reached:continue
        reached.add(x);pending+=edges[x]
    assert not {ins[-2]['offset'],ins[-1]['offset']}&reached
    at,head,size,tiny=loc(int(token,16)&0xffffff);new_size=size-6;assert new_size==ins[-2]['offset']
    if tiny:
        assert head==1 and size<64;patch(token,'TRIM_UNREACHABLE_NONVOID_WARNING_CODE_SIZE',at,bytes([(new_size<<2)|2]),dict(old_size=size,new_size=new_size,header_kind='tiny',no_return_value_synthesized=True))
    else:patch(token,'TRIM_UNREACHABLE_NONVOID_WARNING_CODE_SIZE',at+4,struct.pack('<I',new_size),dict(old_size=size,new_size=new_size,header_kind='fat',no_return_value_synthesized=True))
# Existing code/handlers are not removed. Only an unreachable dead block is
# made to terminate inside its own try; the real leave at IL_0062 is unchanged.
at,head,size,tiny=loc(4);assert not tiny and parent[at+head+100:at+head+103]==b'\0'*3
m=methods['0x06000004'];assert m['handlers']==[dict(kind='Finally',tryStart=47,tryEnd=103,handlerStart=103,handlerEnd=113,catchType=None)]
assert next(i for i in m['instructions'] if i['offset']==98)['opcode']=='leave.s'
assert all(i['operand'] is None or not isinstance(i['operand'],dict) or i['operand'].get('target') not in [100,101,102] for i in m['instructions'])
patch('0x06000004','SEAL_UNREACHABLE_TRY_GAP',at+head+101,bytes.fromhex('de0a'),dict(il_offset=101,target=113,original_reachable_leave=98,exception_clause_bytes_unchanged=True,finally_body_unchanged=True))
# Two properly nested finally clauses; reorder rows only. Both region tuples,
# handler code and every CIL byte remain identical to parent.
at,head,size,tiny=loc(0x47a);assert not tiny;eh=(at+head+size+3)&~3;assert parent[eh]==0x41 and int.from_bytes(parent[eh+1:eh+4],'little')==52
outer=parent[eh+4:eh+28];inner=parent[eh+28:eh+52]
assert struct.unpack('<6I',outer)==(2,257,107,364,8,0) and struct.unpack('<6I',inner)==(2,282,57,339,8,0)
patch('0x0600047A','ORDER_NESTED_FINALLY_CLAUSES_INNER_FIRST',eh+4,inner+outer,dict(cil_bytes_unchanged=True,clauses_unchanged_as_multiset=True,inner_dispose_and_outer_dispose_retained=True))
data=bytes(out);allowed={i for c in changes for i in range(c['file_offset'],c['file_offset']+len(bytes.fromhex(c['after'])))}
assert len(data)==len(parent) and all(a==b or i in allowed for i,(a,b) in enumerate(zip(parent,data))) and len(set(targets))==6
for n in [1,2]:(O/f'candidate{n}.dll').write_bytes(data)
report=dict(scope='FOUR_NONVOID_UNREACHABLE_CODE_SIZE_TRIMS_AND_TWO_EH_FORM_REPAIRS_ONLY',parent_sha256=sha(parent),candidate_sha256=sha(data),bytes=len(data),direct_method_targets=6,
            untouched_methoddefs=2311,metadata_and_rvas_unchanged=True,all_other_file_bytes_identical=True,no_default_return_or_exception_suppression=True,changes=changes,gameplay_qualification=False,unity_export=False,ipa=None)
(O/'CONSTRUCTION.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(report,indent=2))
