"""Normal-edge CFG readback; .pdata fragments are not whole-method bounds."""
from pathlib import Path
import hashlib
import json
import sys

W=Path(__file__).resolve().parent
R=W.parents[1]
sys.path.insert(0,str(R/'audit/stage9-native3/python-deps'))
import pefile
from capstone import Cs,CS_ARCH_X86,CS_MODE_64,CS_GRP_JUMP,CS_GRP_RET,CS_GRP_CALL
from capstone.x86_const import X86_OP_IMM

raw=(R/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/GameAssembly.dll').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d'
p=pefile.PE(data=raw);base=p.OPTIONAL_HEADER.ImageBase
dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True
known=json.loads((R/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-method-map.json').read_text('utf-8-sig'))
starts={int(m['va'],16) for m in known if m.get('va')}
out=W/'remaining-native';out.mkdir(exist_ok=True)
results=[]
for rid in [0x89,0x2ad,0x5e7,0x7b7,0x7b8]:
    va=int.from_bytes(p.get_data(0x181B82D60-base+(rid-1)*8,8),'little')
    queue=[va];ins={};edges=[];tails=[];indirect=[]
    while queue:
        at=queue.pop()
        while at not in ins:
            section=p.get_section_by_rva(at-base)
            assert section is not None and section.Characteristics&0x20000000,(hex(at),'non-code target')
            i=next(dis.disasm(p.get_data(at-base,15),at,count=1));ins[at]=i
            assert len(ins)<6000,'Unexpected CFG expansion'
            nxt=at+i.size
            if i.group(CS_GRP_RET) or i.mnemonic in ('int3','ud2'):break
            if i.group(CS_GRP_JUMP):
                if i.operands[0].type==X86_OP_IMM:
                    target=i.operands[0].imm;edges.append({'from':hex(at),'to':hex(target),'op':i.mnemonic})
                    if target in starts and target!=va:tails.append({'from':hex(at),'target':hex(target),'op':i.mnemonic})
                    elif target not in ins:queue.append(target)
                else:indirect.append({'va':hex(at),'op':i.mnemonic,'operand':i.op_str})
                if i.mnemonic=='jmp':break
            at=nxt
    instructions=[{'va':hex(i.address),'op':i.mnemonic,'operands':i.op_str,'bytes':i.bytes.hex()} for i in sorted(ins.values(),key=lambda i:i.address)]
    row={'token':f'0x{0x06000000|rid:08X}','entry':hex(va),'scope':'NORMAL_DIRECT_CFG_ONLY_EH_AND_INDIRECT_DISPATCH_NOT_MODELED','instructions':instructions,'edges':edges,'tail_targets':tails,'indirect_jumps':indirect}
    (out/f'{rid:04X}.normal-cfg.json').write_text(json.dumps(row,indent=2)+'\n')
    (out/f'{rid:04X}.normal-cfg.txt').write_text('\n'.join(f"{x['va']} {x['bytes']:22s} {x['op']} {x['operands']}" for x in instructions)+'\n')
    results.append({k:v for k,v in row.items() if k not in ('instructions','edges')})
    print(hex(rid),'instructions',len(instructions),'tail_targets',len(tails),'indirect',indirect)
    print('FLOATS',[(x['va'],x['op'],x['operands']) for x in instructions if x['op'] in ('comiss','ucomiss','xorps','jp','jnp')])
(out/'CFG-MANIFEST.json').write_text(json.dumps(results,indent=2)+'\n')
first=out/'MANIFEST.json'
if first.exists():
    rows=json.loads(first.read_text())
    for row in rows:
        row['scope']='FIRST_RUNTIME_FUNCTION_FRAGMENT_ONLY_NOT_WHOLE_METHOD';row['first_fragment_bytes']=row.pop('bytes',row.get('first_fragment_bytes'))
    first.write_text(json.dumps(rows,indent=2)+'\n')
