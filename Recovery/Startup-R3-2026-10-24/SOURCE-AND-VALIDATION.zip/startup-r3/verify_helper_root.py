"""Independent whole-file boundary and class-root census for Startup R3."""
from pathlib import Path
import hashlib
import json
import sys

Q=Path(__file__).resolve().parent
R=Q.parents[2]
sys.path.insert(0,str(R/'audit/stage9-native3/python-deps'))
import dnfile

source=(Q.parent/'startup-r2/candidate1.dll').read_bytes()
candidate=(Q/'candidate1.dll').read_bytes()
assert hashlib.sha256(source).hexdigest()=='81815f178e1de70e1e2e5088afd856bb5292801c3ccdc1ffc60b9c24ba223823'

def audit(data):
    p=dnfile.dnPE(data=data);issues=[]
    for rid,row in enumerate(p.net.mdtables.TypeDef.rows,1):
        null=row.struct.Extends_CodedIndex==0
        if null and not (rid==1 or row.struct.Flags&0x20 or str(row.TypeName)=='Object' and str(row.TypeNamespace)=='System'):
            issues.append({'token':hex(0x02000000|rid),'name':str(row.TypeName)})
    assert not issues,issues
    helper=p.net.mdtables.TypeDef.rows[319]
    at=helper.struct.get_field_absolute_offset('Extends_CodedIndex')
    assert helper.Extends.table.name=='TypeRef' and helper.Extends.row_index==26
    expected=bytearray(source);expected[at:at+2]=b'\x69\0'
    assert data==bytes(expected),'Whole file differs beyond the helper root column'
    assert len(p.net.mdtables.CustomAttribute.rows)==130
    # Every original method RVA still points before the appended R2 metadata;
    # the single changed metadata byte cannot overlap any method body.
    assert all(not m.Rva or p.get_offset_from_rva(m.Rva)<17563648 for m in p.net.mdtables.MethodDef.rows)
    return {'scope':'INJECTED_HELPER_ROOT_METADATA_AND_WHOLE_FILE_ISOLATION_ONLY','pass':True,'candidate_sha256':hashlib.sha256(data).hexdigest(),'parent_sha256':hashlib.sha256(source).hexdigest(),'typedefs_scanned':len(p.net.mdtables.TypeDef.rows),'invalid_null_class_roots':issues,'changed_bytes':sum(x!=y for x,y in zip(source,data)),'all_2317_method_definitions_and_bodies_unchanged_from_r2':True,'all_original_319_game_type_rows_unchanged':True,'field_and_attribute_tables_unchanged':True,'serialize_field_markers':130,'deterministic':True,'gameplay_equivalence':False}

result=audit(candidate)
assert candidate==(Q/'candidate2.dll').read_bytes()
controls=[]
for name,data in [('restore_invalid_parent_root',source),('change_an_unrelated_original_byte',bytes([candidate[0]^1])+candidate[1:])]:
    try:audit(data)
    except Exception as e:controls.append({'name':name,'rejected':True,'reason':str(e)[:200]})
    else:raise AssertionError('False accept: '+name)
result['negative_controls']=controls
(Q/'ISOLATION.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
