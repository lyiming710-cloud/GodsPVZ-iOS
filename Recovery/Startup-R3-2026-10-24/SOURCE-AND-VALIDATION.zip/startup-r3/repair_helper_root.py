"""Repair only the non-game Cpp2IL helper's invalid null Extends column."""
from pathlib import Path
import hashlib
import json
import struct
import sys

Q=Path(__file__).resolve().parent
R=Q.parents[2]
sys.path.insert(0,str(R/'audit/stage9-native3/python-deps'))
import dnfile

def repair(source,output,report):
    source=Path(source).resolve();output=Path(output).resolve();report=Path(report).resolve()
    if output.exists() or report.exists() or len({source,output,report})!=3:raise ValueError('Fresh distinct outputs required')
    before=source.read_bytes()
    if hashlib.sha256(before).hexdigest()!='81815f178e1de70e1e2e5088afd856bb5292801c3ccdc1ffc60b9c24ba223823':raise ValueError('Exact Startup R2 parent required')
    pe=dnfile.dnPE(data=before)
    row=pe.net.mdtables.TypeDef.rows[319]
    if len(pe.net.mdtables.TypeDef.rows)!=320 or str(row.TypeName)!='Cpp2ILHelpers' or str(row.TypeNamespace)!='Cpp2ILInjected' or row.struct.Flags!=0x181 or row.struct.Extends_CodedIndex!=0:raise ValueError('Exact injected helper identity/root required')
    target=pe.net.mdtables.TypeRef.rows[25]
    if str(target.TypeNamespace)!='System' or str(target.TypeName)!='Object' or str(target.ResolutionScope.row.Name)!='mscorlib':raise ValueError('Existing canonical System.Object reference required')
    at=row.struct.get_field_absolute_offset('Extends_CodedIndex')
    # TypeDefOrRef tag 1 is TypeRef; 26 is the existing System.Object RID.
    coded=(26<<2)|1
    after=bytearray(before);struct.pack_into('<H',after,at,coded)
    changes=[i for i,(x,y) in enumerate(zip(before,after)) if x!=y]
    if not changes or any(i not in (at,at+1) for i in changes):raise ValueError('Exact single-column byte boundary')
    reopened=dnfile.dnPE(data=bytes(after));fixed=reopened.net.mdtables.TypeDef.rows[319]
    if fixed.Extends.table.name!='TypeRef' or fixed.Extends.row_index!=26:raise ValueError('Reopened helper root differs')
    result={'status':'CONSTRUCTED_HELPER_METADATA_FIX_NOT_GAME_QUALIFIED','parent_sha256':hashlib.sha256(before).hexdigest(),'candidate_sha256':hashlib.sha256(after).hexdigest(),'candidate_bytes':len(after),'type':'Cpp2ILInjected.Cpp2ILHelpers','typedef_token':'0x02000140','column':'Extends','file_offset':at,'before_coded_index':0,'after_coded_index':coded,'extends':'System.Object, mscorlib','changed_byte_offsets':changes,'game_type_rows_changed':0,'method_bodies_changed':0,'field_rows_changed':0,'serialize_field_markers':130,'type_flags_changed':False,'cause':'Actual Unity GetTypes failed for a non-interface injected class with no base type','editor_acceptance':'PENDING','device_execution':False}
    with output.open('xb') as f:f.write(after)
    with report.open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps(result))

if __name__=='__main__':
    if len(sys.argv)!=4:raise ValueError('parent-r2.dll fresh-r3.dll fresh-report.json')
    repair(*sys.argv[1:])
