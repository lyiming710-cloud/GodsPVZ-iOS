using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;

var results = new List<object>();
foreach (string path in args.Take(2))
{
    var context = new AssemblyLoadContext("IsolatedHelper_"+Guid.NewGuid().ToString("N"),isCollectible:true);
    bool loaded=false,invoked=false; string? error=null,baseType=null;
    try {
        var assembly=context.LoadFromAssemblyPath(Path.GetFullPath(path));
        var type=assembly.GetType("Cpp2ILInjected.Cpp2ILHelpers",throwOnError:true)!;
        baseType=type.BaseType?.FullName;loaded=true;
        type.GetMethod("NoteDecompilerIssue",BindingFlags.Public|BindingFlags.Static)!.Invoke(null,["fixture, no game code"]);invoked=true;
    } catch(Exception e){error=e.GetType().FullName+": "+e.Message;}
    finally {context.Unload();}
    results.Add(new {sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant(),loaded,invoked,base_type=baseType,error});
}
var doc=JsonSerializer.SerializeToElement(results);
bool pass=doc[0].GetProperty("loaded").GetBoolean()==false && doc[1].GetProperty("loaded").GetBoolean() && doc[1].GetProperty("invoked").GetBoolean() && doc[1].GetProperty("base_type").GetString()=="System.Object";
var report=new {scope="ACTUAL_CLR_LOAD_OF_INJECTED_HELPER_ONLY_NOT_UNITY_OR_GAME_EXECUTION",pass,results,game_types_loaded=false,unity_started=false,device_execution=false};
File.WriteAllText(args[2],JsonSerializer.Serialize(report,new JsonSerializerOptions{WriteIndented=true}));
Console.WriteLine(JsonSerializer.Serialize(report));
return pass?0:1;
