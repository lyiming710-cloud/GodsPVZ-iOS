"""Execute original PC IsOnBoard/getters in an isolated Windows mapping.

Unity truthiness and metadata/class initialization are controlled callees.
Windows throw/unwind and real Unity engine state are not modeled or promoted.
"""
from pathlib import Path
import ctypes as C
import hashlib
import json
import struct
import sys

Q=Path(__file__).resolve().parent
ROOT=Q.parents[2]
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import pefile

need=lambda ok,message: None if ok else (_ for _ in ()).throw(ValueError(message))
need(sys.platform=='win32','This oracle requires the native Windows x64 ABI')
raw=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/GameAssembly.dll').read_bytes()
sha=lambda b:hashlib.sha256(b).hexdigest()
need(sha(raw)=='9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d','Original PC binary')
pe=pefile.PE(data=raw);base=pe.OPTIONAL_HEADER.ImageBase;size=pe.OPTIONAL_HEADER.SizeOfImage
api=C.WinDLL('kernel32',use_last_error=True)
api.VirtualAlloc.argtypes=[C.c_void_p,C.c_size_t,C.c_uint32,C.c_uint32];api.VirtualAlloc.restype=C.c_void_p
api.VirtualFree.argtypes=[C.c_void_p,C.c_size_t,C.c_uint32];api.VirtualFree.restype=C.c_int
address=api.VirtualAlloc(base,size,0x3000,0x40)
need(address==base,'Fixed address unavailable in isolated child process')
owned=[];callbacks=[];errors=[];state={}
def alloc(n):
    b=C.create_string_buffer(n);owned.append(b);return C.addressof(b)
def w64(at,value):C.c_uint64.from_address(at).value=value or 0
def w32(at,value):C.c_uint32.from_address(at).value=value
def read64(at):return C.c_uint64.from_address(at).value
def hook(va,restype,args,fn):
    def guarded(*values):
        try:return fn(*values)
        except Exception as e:errors.append(repr(e));return None if restype is None else 0
    cb=C.CFUNCTYPE(restype,*args)(guarded);callbacks.append(cb)
    C.memmove(va,b'\xff\x25\0\0\0\0'+struct.pack('<Q',C.cast(cb,C.c_void_p).value),14)
def no_op(*_):return None

try:
    C.memmove(base,raw[:pe.OPTIONAL_HEADER.SizeOfHeaders],pe.OPTIONAL_HEADER.SizeOfHeaders)
    for section in pe.sections:C.memmove(base+section.VirtualAddress,raw[section.PointerToRawData:section.PointerToRawData+section.SizeOfRawData],section.SizeOfRawData)
    mgr_class=alloc(512);obj_class=alloc(512);static=alloc(64)
    w64(mgr_class+0xB8,static);w32(mgr_class+0xE0,1);w32(obj_class+0xE0,1)
    # Both original singleton getter and inlined IsOnBoard reads resolve the
    # same original RIP-relative BoardManager class global.
    w64(0x181BD1A40,mgr_class);w64(0x181BB0500,obj_class)
    hook(0x18024FEF0,None,[C.c_void_p],no_op)
    hook(0x1802501E0,None,[C.c_void_p],no_op)
    def truth(pointer,_method):
        pointer=pointer or 0  # ctypes represents a null c_void_p as None.
        value=state['objects'].get(pointer)
        need(pointer==0 or value is not None,'Unexpected object escaped the controlled graph')
        state['trace'].append('Truth:'+(value[0] if value else 'null'))
        result=bool(value and value[1])
        action=state.pop('replace',None)
        if action is not None:w64(static,action)
        return result
    hook(0x18131F870,C.c_bool,[C.c_void_p,C.c_void_p],truth)
    functions={0x146:0x18031BB70,0x169:0x1803100F0,0x16F:0x18030F590}
    for rid,va in functions.items():need(int.from_bytes(pe.get_data(0x181B82D60-base+(rid-1)*8,8),'little')==va,'Original method pointer binding')
    invoke=C.CFUNCTYPE(C.c_bool)(functions[0x146]);get_instance=C.CFUNCTYPE(C.c_void_p)(functions[0x169]);get_board=C.CFUNCTYPE(C.c_void_p,C.c_void_p)(functions[0x16F])
    def manager(alive,kind,suffix=''):
        board=alloc(128) if kind>=0 else 0;mgr=alloc(128)
        if board:state['objects'][board]=('board'+suffix,kind>0)
        state['objects'][mgr]=('manager'+suffix,alive);w64(mgr+0x48,board)
        return mgr,board
    fixture=json.loads((Q/'ACTUAL-CIL-STARTUP-FIXTURE.json').read_text('utf-8-sig'))
    results=[]
    for row in fixture['cases']:
        state={'objects':{},'trace':[]}
        if row['kind']=='null_manager':w64(static,0)
        elif row['kind']=='normal':
            mgr,board=manager(row['manager_alive'],row['board_kind']);w64(static,mgr)
            need(get_instance()==mgr and (get_board(mgr) or 0)==board,'Actual getter identity, not a simulated getter result')
        elif row['kind']=='replace_after_first_truth':
            mgr,_=manager(True,1);replacement,_=manager(True,row['board_kind'],'2');w64(static,mgr);state['replace']=replacement
        else:raise ValueError('Unknown candidate case')
        value=bool(invoke());trace=state['trace'][:]
        if errors or value!=row['result'] or trace!=row['trace']:
            (Q/'NATIVE-ORACLE-DIVERGENCE.json').write_text(json.dumps({'case':row,'native_result':value,'native_trace':trace,'adapter_errors':errors},indent=2)+'\n',encoding='utf-8')
            raise ValueError('Original-vs-candidate result/trace divergence')
        results.append({'input':row,'original_native_result':value,'original_native_trace':trace,'match':True})
    report={'scope':'ORIGINAL_PC_NATIVE_VS_REHOSTED_CANDIDATE_CIL_WITH_CONTROLLED_UNITY_CALLEES','status':'PASS_SCOPED_NORMAL_AND_CALLBACK_PATHS','original_gameassembly_sha256':sha(raw),'candidate_sha256':fixture['candidate_sha256'],'cases':len(results),'differences':0,'actual_original_method_tokens':['0x06000146','0x06000169','0x0600016F'],'controlled_callees':['0x18024FEF0 metadata initializer','0x1802501E0 class initializer','0x18131F870 UnityEngine.Object truthiness'],'native_throw_unwind':'UNSUPPORTED_NOT_EXECUTED','unity_engine_behavior':'CONTROLLED_NOT_PROVEN','device_execution':False,'results':results}
    (Q/'ACTUAL-NATIVE-STARTUP-ORACLE.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='results'}))
finally:
    api.VirtualFree(base,0,0x8000)
