"""Read back actual R3 startup evidence; do not promote game/IPA acceptance."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

W=Path(__file__).resolve().parent
R=W.parent/'repo-native113'
D=R/'Recovery/Startup-R3-2026-10-24'
E=W/'asset-audit-40081048209'
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(path,value,eol='\n'):path.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').replace('\n',eol).encode('utf-8'))
a=json.loads((E/'startup-asset-audit.json').read_text('utf-8-sig'))
p=json.loads((E/'startup-play-probe.json').read_text('utf-8-sig'))
run=json.loads(subprocess.check_output([r'C:\Program Files\GitHub CLI\gh.exe','run','view','40081048209','--repo','lyiming710-cloud/GodsPVZ-iOS','--json','databaseId,headSha,status,conclusion,url,jobs']))
assert run['status']=='completed' and run['conclusion']=='success' and run['headSha']=='f940d893ae66da9ea366226bf6c73a498c844528'
assert a['pass'] and p['pass'] and not a['errors'] and not p['errors']
assert a['original_serialization_markers']==130 and p['frames']==1884
assert all(x['assigned'] for x in p['restored_runtime_fields'])
proof=json.loads((E/'PROVENANCE.json').read_text('utf-8-sig'))
assert proof['candidate_sha256']=='752939d1ae69877ef457945f6e0dfe61c749e8d4657e720075adcbcc76cc2e7f'
save(D/'RUN-40081048209.json',run)
summary={'state':'REAL_EDITOR_MAINMENU_STARTUP_PASS_DEVICE_AND_GAMEPLAY_PENDING','run_id':40081048209,'source_commit':run['headSha'],'candidate_sha256':proof['candidate_sha256'],'asset_audit':{k:a[k] for k in ['pass','original_serialization_markers','plugin_scripts','resolved_plugin_scripts','validated_game_script_references','prefab_assets','missing_components','splash_unity_logo_canonical','splash_game_logo_preserved','unresolved_custom_dummy_shaders']},'official_shader_bindings':len(a['official_shader_bindings']),'fonts_checked':len(a['fonts']),'play_probe':p,'previous_observed_startup_exception_traces_absent_in_this_probe':['Administrator.Start NullReferenceException','TextLink.Update NullReferenceException','GlobalStaticVars.IsOnBoard FieldAccessException'],'scope_limits':{'board_scene_played':False,'gameplay_equivalence':False,'pixel_equivalence':False,'physical_audio_tested':False,'new_unity_ios_export':False,'new_cpp_or_xcode_compile':False,'new_ipa':None,'ipad_test':False},'known_pending':{'own_assembly_private_field_census':77,'separate_overlapping_40_target_member_access_rejections':43,'methods_in_that_rejected_scope':9,'quarantined_type_flow_methods':5,'custom_dummy_shaders':a['unresolved_custom_dummy_shaders']}}
save(D/'REAL-EDITOR-STARTUP-READBACK.json',summary)
save(D/'CURRENT-RESULT.json',summary)
files={}
for name in ['startup-asset-audit.json','startup-asset-audit.log','startup-asset-audit-exit.txt','startup-play-probe.json','startup-play-probe.log','startup-play-probe-exit.txt','PROVENANCE.json','PARENT-BULK401-PROVENANCE.json','workcopy-transition.json','startup-plugin-transition.json','HELPER-COMPILATION.json','test-dll-after-reimport.sha256','official-tmp-shader-sources.json']:
    if (E/name).exists():files[name]=(E/name).read_bytes()
manifest=[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())]
files['ARCHIVE-MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(D/'REAL-EDITOR-STARTUP-40081048209.zip','w',zipfile.ZIP_DEFLATED) as z:
    for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(D/'REAL-EDITOR-STARTUP-40081048209.zip') as z:
    assert z.testzip() is None
    for row in manifest:assert sha(z.read(row['path']))==row['sha256']
with zipfile.ZipFile(D/'NEXT-METHOD-NORMAL-CFG-EVIDENCE.zip','w',zipfile.ZIP_DEFLATED) as z:
    z.write(W/'extract_remaining_cfg.py','extract_remaining_cfg.py')
    for path in sorted((W/'remaining-native').iterdir()):
        if path.is_file():z.write(path,'remaining-native/'+path.name)
    z.writestr('SCOPE.txt','Normal direct control-flow evidence only. First .pdata fragments are explicitly labeled as fragments. EH/unwind and indirect dispatch are not modeled. No new method repairs in this archive are accepted.\n')
source_archive=D/'SOURCE-AND-VALIDATION.zip'
with zipfile.ZipFile(source_archive) as z:
    sources={n:z.read(n) for n in z.namelist() if n!='ARCHIVE-MANIFEST.json'}
sources['tools/record_completed_r3.py']=Path(__file__).read_bytes()
source_manifest=[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(sources.items())]
sources['ARCHIVE-MANIFEST.json']=(json.dumps(source_manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(source_archive,'w',zipfile.ZIP_DEFLATED) as z:
    for name,data in sorted(sources.items()):z.writestr(name,data)
readme=D/'README.md'
base_text=readme.read_text('utf-8')
addition='''\n\n**Actual completed run 40081048209:** exact source f940d893ae66da9ea366226bf6c73a498c844528, candidate 752939d1... passes the real Editor asset audit and normal MainMenu Play Mode. All 130 original markers were read; 148 scripts and 263 references resolved; 186 prefabs had zero missing components; 40 official shader mappings and 21 fonts passed. One MainUIController and two active Canvases were created and 1,884 frames advanced with no captured errors. Administrator.mainSystem and systems (four entries), and TextLink.TMP_Text are actually assigned. The prior three startup exception traces were absent in this probe.\n\nThis is no iPad, pixel, physical-audio, Board/gameplay, fresh IL2CPP/Apple or IPA acceptance. The two custom shaders remain dummy, and the overlapping access/type-flow queues remain open. See REAL-EDITOR-STARTUP-READBACK.json and the exact scoped raw evidence ZIP. The next-method CFG archive preserves additional native evidence without claiming those methods repaired.\n'''
text=base_text if '**Actual completed run 40081048209:**' in base_text else base_text.rstrip()+addition
readme.write_bytes(text.encode('utf-8'))
B=R/'Recovery/Bulk401-Generic-Repair-2026-10-24'
current=json.loads((B/'CURRENT-RESULT.json').read_text('utf-8-sig'))
current['device_runtime'].update(startup_repair='REAL_EDITOR_MAINMENU_STARTUP_PASS_DEVICE_PENDING',latest_run=40081048209,latest_run_conclusion='success',latest_source=run['headSha'],new_candidate_sha256=proof['candidate_sha256'],fixed_ipa=None,editor_play_frames=1884,editor_startup_errors=0,readback='../Startup-R3-2026-10-24/REAL-EDITOR-STARTUP-READBACK.json')
save(B/'CURRENT-RESULT.json',current,'\r\n')
for directory,eol in [(D,'\n'),(B,'\r\n')]:
    manifest=[]
    for path in sorted(directory.rglob('*')):
        if path.is_file() and path.name!='MANIFEST.json':
            data=path.read_bytes();manifest.append({'path':path.relative_to(directory).as_posix(),'bytes':len(data),'sha256':sha(data)})
    save(directory/'MANIFEST.json',manifest,eol)
print(json.dumps({'state':summary['state'],'run':run['databaseId'],'frames':p['frames'],'errors':p['errors'],'new_ipa':None}))
