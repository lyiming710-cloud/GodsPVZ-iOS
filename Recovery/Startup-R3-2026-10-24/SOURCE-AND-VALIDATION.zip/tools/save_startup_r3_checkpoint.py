from pathlib import Path
import hashlib
import json
import zipfile

W=Path(__file__).resolve().parent
R=W.parent/'repo-native113'
Q=W/'startup-r3'
D=R/'Recovery/Startup-R3-2026-10-24'
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(path,value):path.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
for name in ['ISOLATION.json','FROZEN-STACK-FLOW.json','ACTUAL-CLR-HELPER-LOAD.json','ACTUAL-CIL-STARTUP-FIXTURE.json','ACTUAL-NATIVE-STARTUP-ORACLE.json']:
    (D/name).write_bytes((Q/name).read_bytes())
files={}
for path in sorted(Q.rglob('*')):
    if path.is_file() and not any(x in ('bin','obj') for x in path.relative_to(Q).parts) and path.suffix in ('.py','.json','.log','.cs','.csproj'):
        files['startup-r3/'+path.relative_to(Q).as_posix()]=path.read_bytes()
for name in ['author_startup_r3_gate.py','save_startup_r3_checkpoint.py','extract_shader_states.py']:
    files['tools/'+name]=(W/name).read_bytes()
files['shader-evidence/ORIGINAL-PROPERTIES-AND-STATES.json']=(W/'custom-shader-evidence/ORIGINAL-PROPERTIES-AND-STATES.json').read_bytes()
for name in ['bind_startup_r3_diagnostic.py','prepare_startup_r3_plugin.py','prepare_startup_r3_unity.py']:
    files['scripts/actions/'+name]=(R/'scripts/actions'/name).read_bytes()
for name in ['startup-r2-editor-diagnostic.yml','startup-r2-editor-preflight.yml']:
    files['workflows/'+name]=(R/'.github/workflows'/name).read_bytes()
for path in sorted((D/'ios-support/Assets/Editor').glob('*.cs')):files['ios-support/Assets/Editor/'+path.name]=path.read_bytes()
manifest=[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())]
files['ARCHIVE-MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(D/'SOURCE-AND-VALIDATION.zip','w',zipfile.ZIP_DEFLATED) as z:
    for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(D/'SOURCE-AND-VALIDATION.zip') as z:
    assert z.testzip() is None
    for row in manifest:assert sha(z.read(row['path']))==row['sha256']
(D/'.gitattributes').write_bytes(b'*.json -text whitespace=trailing-space,space-before-tab,cr-at-eol\n*.md -text whitespace=trailing-space,space-before-tab,cr-at-eol\n*.zip -text\n*.cs -text whitespace=trailing-space,space-before-tab,cr-at-eol\n')
if not (D/'README.md').exists():
    (D/'README.md').write_bytes('''# Startup R3 - valid injected helper metadata

This is a diagnostic successor to R2, not a qualified game or IPA. Candidate SHA-256: `752939d1ae69877ef457945f6e0dfe61c749e8d4657e720075adcbcc76cc2e7f`, 17,996,800 bytes. Direct parent R2: `81815f178e1de70e1e2e5088afd856bb5292801c3ccdc1ffc60b9c24ba223823`.

Actual Unity diagnostic 40078830715 read all 130 original SerializeField markers, then failed to enumerate types because the tool-injected Cpp2ILInjected.Cpp2ILHelpers static class had a null base type. The 319 original game type rows were intact; the extra injected type is TypeDef 0x02000140. R3 binds only its Extends column to the existing System.Object TypeRef 0x0100001A (coded index 0x69). Actual changed bytes: one. Type flags, fields, all 2,317 method definitions/bodies and all restored attributes are unchanged from R2.

Independent full-file isolation, all 320 class-root checks and two negative controls pass. Local CLR loading of the actual parent reproduces the type failure; the actual R3 helper loads with System.Object and its unchanged NoteDecompilerIssue method executes. This is helper-only execution, not game startup. The unchanged frozen stack checker passes the same 40 targets on the new exact candidate. The three IsOnBoard/accessor CIL bodies were rehosted and executed with 17 assertions and three negative controls; ten controlled result/trace cases matched actual original PC machine code. Real Unity behavior and native throw/unwind remain unproven.

R2's larger context still applies: 111 original SerializeField attributes restored, 66 field reads replaced in 40 methods, cumulative body construction roster 441. Five earlier type-flow failures were quarantined, not counted passed. Remaining known access findings include 77 own-assembly private-field sites and a separate 40-target MemberAccess rejection of 43 references in nine methods; these overlapping scopes are not an additive defect total. Two custom shaders and broader runtime/game/device behavior remain unqualified. Original PC/Android pass-state data has now been extracted without the generic shader exporter's omitted blend state; no custom shader replacement is applied here.

The registered `startup-r2-editor-diagnostic.yml` entrypoint now displays Startup R3 and binds this exact child separately from the compiler-qualified Bulk401 input. It remains manual-only and contains no Xcode export, Apple build or IPA packaging. Its helper verifies all 130 markers, full type enumeration, all scene/prefab bindings and normal MainMenu Play Mode. Read the actual run outcome before accepting any startup fix. No new IPA exists.

Reproduction sources and exact validation logs are in SOURCE-AND-VALIDATION.zip. R2's first tool/runner failures and the earlier failed candidate remain preserved in the R2 checkpoint. Test-tool limitations were fixed independently rather than weakening controls.
'''.encode())
if not (D/'CURRENT-RESULT.json').exists():save(D/'CURRENT-RESULT.json',{'state':'HELPER_ROOT_FIXED_EDITOR_DIAGNOSTIC_PENDING','candidate_sha256':'752939d1ae69877ef457945f6e0dfe61c749e8d4657e720075adcbcc76cc2e7f','parent_sha256':'81815f178e1de70e1e2e5088afd856bb5292801c3ccdc1ffc60b9c24ba223823','direct_changed_bytes':1,'direct_game_method_changes':0,'original_field_markers':130,'gameplay_qualified':False,'new_ipa':None,'device_execution':False})
manifest=[]
for path in sorted(D.rglob('*')):
    if path.is_file() and path.name!='MANIFEST.json':
        data=path.read_bytes();manifest.append({'path':path.relative_to(D).as_posix(),'bytes':len(data),'sha256':sha(data)})
save(D/'MANIFEST.json',manifest)
print(json.dumps({'checkpoint':str(D),'files':len(manifest),'source_bytes':(D/'SOURCE-AND-VALIDATION.zip').stat().st_size}))
