"""Advance the registered Editor-only entrypoint to the one-byte helper fix."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

W=Path(__file__).resolve().parent
R=W.parent/'repo-native113'
Q=W/'startup-r3'
D=R/'Recovery/Startup-R3-2026-10-24'
D.mkdir(exist_ok=False)
R2='81815f178e1de70e1e2e5088afd856bb5292801c3ccdc1ffc60b9c24ba223823'
R3='752939d1ae69877ef457945f6e0dfe61c749e8d4657e720075adcbcc76cc2e7f'
for name in ['EMPTY-DYNAMIC-FONT-ATLAS-EVIDENCE.json','ORIGINAL-ATTRIBUTE-ROSTERS.json']:
    shutil.copyfile(R/'Recovery/Startup-R2-2026-10-24'/name,D/name)
shutil.copytree(R/'Recovery/Startup-R2-2026-10-24/ios-support',D/'ios-support')
for name in ['ISOLATION.json','FROZEN-STACK-FLOW.json','ACTUAL-CLR-HELPER-LOAD.json','ACTUAL-CIL-STARTUP-FIXTURE.json','ACTUAL-NATIVE-STARTUP-ORACLE.json','construction1.json']:
    shutil.copyfile(Q/name,D/name)
data=(Q/'candidate1.dll').read_bytes();assert hashlib.sha256(data).hexdigest()==R3
with zipfile.ZipFile(D/'STARTUP-R3-CANDIDATE.zip','w',zipfile.ZIP_DEFLATED) as z:z.writestr('STARTUP-R3.dll',data)
for old,new in [('prepare_startup_r2_unity.py','prepare_startup_r3_unity.py'),('prepare_startup_r2_plugin.py','prepare_startup_r3_plugin.py')]:
    text=(R/'scripts/actions'/old).read_text('utf-8');assert text.count(R2)==1
    (R/'scripts/actions'/new).write_bytes(text.replace(R2,R3).encode())
text=(R/'scripts/actions/bind_startup_r2_diagnostic.py').read_text('utf-8')
text=text.replace(R2,R3).replace('Startup-R2-2026-10-24','Startup-R3-2026-10-24').replace('STARTUP-R2','STARTUP-R3').replace('STARTUP_R2','STARTUP_R3')
text=text.replace("if isolation['status']!='PASS_SCOPED_ISOLATION_ONLY' or isolation['restored_marker_rows']!=111:","if isolation['pass'] is not True or isolation['changed_bytes']!=1 or isolation['field_and_attribute_tables_unchanged'] is not True:")
text=text.replace("'restored_original_markers':111,","'restored_original_markers':111,\n        'helper_parent_sha256':'"+R2+"',\n        'helper_metadata_changed_bytes':1,\n        'body_changes_against_helper_parent':0,")
text=text.replace("'diagnostic_scope':'Original schema and actual MainMenu Editor startup only',","'diagnostic_scope':'Injected helper type loading, original schema and actual MainMenu Editor startup only',")
anchor="    if flow['passed']!=40 or flow['total']!=40:"
assert anchor in text
text=text.replace(anchor,"    previous=json.loads((repo/'Recovery/Startup-R2-2026-10-24/ISOLATION.json').read_text('utf-8'))\n    if previous['candidate_sha256']!='"+R2+"' or previous['status']!='PASS_SCOPED_ISOLATION_ONLY':\n        raise ValueError('Prior field/schema delta isolation missing')\n"+anchor)
(R/'scripts/actions/bind_startup_r3_diagnostic.py').write_bytes(text.encode())
wf=R/'.github/workflows/startup-r2-editor-diagnostic.yml'
text=wf.read_text('utf-8').replace('Startup R2 original serialization and actual Editor startup diagnostic','Startup R3 helper type root and actual Editor startup diagnostic')
text=text.replace(R2,R3).replace('Recovery/Startup-R2-2026-10-24/','Recovery/Startup-R3-2026-10-24/').replace('prepare_startup_r2_','prepare_startup_r3_').replace('bind_startup_r2_diagnostic.py','bind_startup_r3_diagnostic.py').replace('STARTUP-R2-EDITOR-DIAGNOSTIC-EVIDENCE','STARTUP-R3-EDITOR-DIAGNOSTIC-EVIDENCE')
assert '  push:' not in text and 'build_ipa:' not in text and 'ExportIOS' not in text
wf.write_bytes(text.encode())
wf=R/'.github/workflows/startup-r2-editor-preflight.yml'
text=wf.read_text('utf-8').replace('Startup R2 exact Editor helper compilation only','Startup R3 exact Editor helper compilation only').replace('Recovery/Startup-R2-2026-10-24/','Recovery/Startup-R3-2026-10-24/').replace('STARTUP-R2-EXACT','STARTUP-R3-EXACT')
wf.write_bytes(text.encode())
print(json.dumps({'candidate_sha256':R3,'changed_bytes_against_r2':1,'registered_entrypoint':'.github/workflows/startup-r2-editor-diagnostic.yml','export_or_ipa_enabled':False}))
