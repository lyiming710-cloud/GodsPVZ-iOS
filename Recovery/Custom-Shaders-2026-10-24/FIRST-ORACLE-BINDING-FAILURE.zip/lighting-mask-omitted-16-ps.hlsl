#define USE_SHAPE_LIGHT_TYPE_0 0
#define USE_SHAPE_LIGHT_TYPE_1 0
#define USE_SHAPE_LIGHT_TYPE_2 0
#define USE_SHAPE_LIGHT_TYPE_3 0
#ifndef GODSPVZ_RECOVERED_BRIGHTNESS_INCLUDED
#define GODSPVZ_RECOVERED_BRIGHTNESS_INCLUDED

// PC path ID 871: PS programs 37..52, 56, 60. Android: 16..31, 33, 35.
// Keep the graph's float product before the half output; no UV scale/offset.
float4 RecoveredBrightnessColor(half4 texel, float4 color, float brightness, float transparent)
{
    return texel * float4(brightness, brightness, brightness, transparent) * color;
}

half3 RecoveredBrightnessLight(half3 light, half4 filter, half4 inverted)
{
    // The graph's mask is constant (1,1,1,1). Zero filter disables masking.
    if (dot(filter, filter) != 0.0)
        light *= 1.0;
    return light;
}

half4 RecoveredBrightnessLit(float4 color, half3 modulate, half3 additive, half hdrScale, half useLighting)
{
    if (color.a == 0.0)
        discard;
    #if USE_SHAPE_LIGHT_TYPE_0 || USE_SHAPE_LIGHT_TYPE_1 || USE_SHAPE_LIGHT_TYPE_2 || USE_SHAPE_LIGHT_TYPE_3
        half3 lit = hdrScale * (color.rgb * modulate + additive);
        half4 output = half4(lerp(color.rgb, lit, useLighting), color.a);
        return max(output, 0.0);
    #else
        return max(color, 0.0);
    #endif
}

half4 RecoveredBrightnessNormal(half4 texel, float3 viewNormal, float transparent)
{
    // Neither vertex alpha nor _RendererColor affects the original normals pass.
    half3 encodedNormal = (half3(viewNormal) + 1.0) * 0.5;
    return half4(encodedNormal, texel.a * transparent);
}
#endif

cbuffer Globals : register(b0) { float4 globals[160]; };
cbuffer Material : register(b1) { float4 material[4]; };
Texture2D mainTex : register(t0); SamplerState mainSampler : register(s0);
struct A { float4 position : POSITION; float3 normal : NORMAL; float4 tangent : TANGENT; float4 uv : TEXCOORD0; float4 color : COLOR; };
struct V { float4 position : SV_POSITION; float4 uv : INTERP0; float4 color : INTERP1; float4 screen : INTERP2; float3 world : INTERP3; };
V VS(A input) {
  V output;
  float3 world=material[0].xyz*input.position.x+material[1].xyz*input.position.y+material[2].xyz*input.position.z+material[3].xyz;
  output.position=globals[76]*world.x+globals[77]*world.y+globals[78]*world.z+globals[79];
  output.uv=input.uv; output.color=input.color*globals[129]; output.world=world;
  float4 p=output.position;
  output.screen=float4((float2(p.x,p.y*globals[21].x)+p.w)*0.5,p.zw);
  return output;
}

struct N { float4 position : SV_POSITION; float4 tangent : INTERP0; float4 uv : INTERP1; float3 viewNormal : INTERP2; };
N NVS(A input) {
  N output;
  float3 world=material[0].xyz*input.position.x+material[1].xyz*input.position.y+material[2].xyz*input.position.z+material[3].xyz;
  output.position=globals[76]*world.x+globals[77]*world.y+globals[78]*world.z+globals[79];
  float3 tangent=material[0].xyz*input.tangent.x+material[1].xyz*input.tangent.y+material[2].xyz*input.tangent.z;
  output.tangent=float4(tangent*rsqrt(max(dot(tangent,tangent),1.17549435e-38)),input.tangent.w);
  output.uv=input.uv; output.viewNormal=float3(globals[64].z,globals[65].z,globals[66].z);
  return output;
}
float4 PS(N input) : SV_Target {
  return RecoveredBrightnessNormal(mainTex.SampleBias(mainSampler,input.uv.xy,globals[5].x),input.viewNormal,material[1].y);
}
