#ifndef GODSPVZ_RECOVERED_GAME_UNIT_INCLUDED
#define GODSPVZ_RECOVERED_GAME_UNIT_INCLUDED

// Bound to PC DXBC programs 1/3 and Android GLES program 1 (path ID 886).
// Angles are radians. The original vertex program ignores input Z and W.
float2 RecoveredGameUnitXY(float2 position, float angleX, float angleY, float scaleX, float scaleY)
{
    float2 scaled = position * float2(scaleX, scaleY);
    float skewX = scaled.y * sin(angleX - angleY) + scaled.x;
    float skewY = cos(angleX - angleY) * scaled.y;
    float sinY = sin(-angleY);
    float cosY = cos(-angleY);
    return float2(skewX * cosY - skewY * sinY, skewX * sinY + skewY * cosY);
}

float4 RecoveredGameUnitColor(half4 texel, float4 color, float exposure, float alpha, float isVisible)
{
    // The hidden branch returns sampled RGB with alpha 0; it does not discard.
    if (isVisible == -1.0)
        return float4(0.0, 0.0, 0.0, 0.0);
    return texel * color * float4(exposure, exposure, exposure, alpha);
}
#endif

cbuffer Material : register(b0) { float4 material[6]; };
cbuffer Object : register(b1) { float4 object[4]; };
cbuffer Camera : register(b2) { float4 camera[21]; };
Texture2D mainTex : register(t0); SamplerState mainSampler : register(s0);
struct A { float4 position : POSITION; float2 uv : TEXCOORD0; float4 color : COLOR; };
struct V { float2 uv : TEXCOORD0; float4 position : SV_POSITION; float4 color : COLOR; };
V VS(A input) {
  V output;
  float2 xy=RecoveredGameUnitXY(input.position.xy,material[3].x,material[3].y,material[3].z,material[3].w);
  float4 world=object[0]*xy.x+object[1]*xy.y+object[3];
  output.position=camera[17]*world.x+camera[18]*world.y+camera[19]*world.z+camera[20]*world.w;
  output.uv=input.uv*material[2].xy+material[2].zw;
  output.color=input.color*material[5];
  return output;
}
float4 PS(V input) : SV_Target {
  return RecoveredGameUnitColor(mainTex.Sample(mainSampler,input.uv),input.color,material[4].w,material[4].y,material[4].z);
}
