from pathlib import Path
import collections,hashlib,json,struct,subprocess,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';D=R/'Recovery/Custom-Shaders-2026-10-24'
E=W/'shader-run-40094204567';B=W/'shader-programs-40094204567'
shader=json.loads((E/'custom-shader-audit.json').read_bytes());startup=json.loads((E/'startup-play-probe.json').read_bytes());asset=json.loads((E/'startup-asset-audit.json').read_bytes())
assert shader['pass'] and len(shader['compilations'])==76 and len(shader['pixels'])==20 and not shader['errors']
assert collections.Counter(r['platform'] for r in shader['compilations'])=={'Metal':38,'OpenGLCore':38}
assert shader['negative_compile_control'] and all(r['success'] and r['bytes']>0 for r in shader['compilations'])
assert all(r['pass'] and r['max_error']<.003 for r in shader['pixels'])
assert not shader['metal_device_execution'] and not shader['game_pixel_equivalence']
assert shader['pipeline_asset_guid']=='22c2bf3291e4d8f4db5d66a87a6f8123' and shader['render_pipeline_tag']=='UniversalPipeline'
assert shader['initialized_original_pipeline_for_headless_render'] and shader['pipeline_instance_before']=='null'
assert startup['pass'] and startup['frames']==2100 and not startup['errors'] and startup['active_scene']=='MainMenu'
assert not startup['device_execution'] and not startup['pixel_equivalence']
assert asset['pass'] and asset['original_serialization_markers']==130 and asset['resolved_plugin_scripts']==148 and asset['missing_components']==0
assert asset['unresolved_custom_dummy_shaders']==[] and not asset['errors']
assert (E/'test-dll-after-reimport.sha256').read_text().strip()=='752939d1ae69877ef457945f6e0dfe61c749e8d4657e720075adcbcc76cc2e7f'
names=set()
for row in shader['compilations']:
    prefix='game' if row['shader']=='Unlit/GameUnitShader' else 'brightness'
    suffix='_'.join(k[-1] for k in row['keywords'].split())
    name=f"shader-{prefix}-p{row['pass']}-{row['platform']}-{row['stage']}-{suffix}.bin"
    raw=(B/name).read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
    names.add(name)
for row in shader['pixels']:
    name='render-'+row['name']+'.png';raw=(B/name).read_bytes()
    assert raw[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack_from('>II',raw,16)==(32,32)
    names.add(name)
assert names=={p.name for p in B.iterdir() if p.is_file()} and len(names)==96
gh='C:/Program Files/GitHub CLI/gh.exe'
proc=subprocess.run([gh,'run','view','40094204567','--json','databaseId,status,conclusion,headSha,url,jobs'],cwd=R,capture_output=True)
assert proc.returncode==0
run=json.loads(proc.stdout);assert run['status']=='completed' and run['conclusion']=='success' and run['headSha'].startswith('8495e0d')
assert all(job['conclusion']=='success' for job in run['jobs'])

def info(n,b):return dict(file=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def js(path,data):path.write_bytes((json.dumps(data,indent=2)+'\n').encode())
items=[('evidence/'+p.relative_to(E).as_posix(),p.read_bytes()) for p in E.rglob('*') if p.is_file()]
items += [('shader-output/'+p.name,p.read_bytes()) for p in B.iterdir() if p.is_file()]
items += [('source/'+p.relative_to(D).as_posix(),p.read_bytes()) for p in (D/'Shaders').iterdir() if p.is_file()]
items += [('source/GodsPVZCustomShaderAudit.cs',(D/'ios-support/Assets/Editor/GodsPVZCustomShaderAudit.cs').read_bytes()),('record_shader_success.py',Path(__file__).read_bytes())]
archive=D/'ACTUAL-UNITY-SHADER-AND-STARTUP-40094204567.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for n,b in items:z.writestr(n,b)
    z.writestr('MANIFEST.json',json.dumps([info(n,b) for n,b in items],indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    manifest=json.loads(z.read('MANIFEST.json'));assert {r['file'] for r in manifest}==set(z.namelist())-{'MANIFEST.json'}
    for row in manifest:assert row==info(row['file'],z.read(row['file']))
js(D/'RUN-40094204567.json',run)
js(D/'ACTUAL-UNITY-READBACK.json',dict(shader=shader,startup=startup,asset=asset))
current=json.loads((D/'CURRENT-RESULT.json').read_bytes())
current.update(status='ACTUAL_METAL_SOURCE_COMPILE_AND_UNITY_CONTROLLED_RENDER_PASS_IPA_NOT_EXPORTED',unity_run=run['url'],unity_source_commit=run['headSha'],unity_run_status='COMPLETED_SUCCESS',
               unity_import='PASS',metal_compile='PASS_38_STAGES',opengl_compile='PASS_38_STAGES',unity_render='PASS_20_CONTROLLED_READBACKS',unity_pixel_max_error=max(r['max_error'] for r in shader['pixels']),
               normal_mainmenu_startup='PASS_2100_FRAMES_NO_ERRORS',unresolved_custom_dummy_shaders=0,metal_device='NOT_RUN',game_pixel_equivalence='NOT_PROVEN',ipa=None,
               headless_observation=dict(configured_pipeline_guid=shader['pipeline_asset_guid'],pipeline_before=shader['pipeline_instance_before'],pipeline_after=shader['pipeline_instance_type'],initialized_same_asset=True,forced_shader_tag=False))
js(D/'CURRENT-RESULT.json',current)
readme=D/'README.md'
readme.write_bytes(readme.read_bytes()+'''\n## Accepted scoped Unity result: 40094204567

Source 8495e0d: actual run SUCCESS. All 76 stage/variant compilations pass (38 Metal, 38 OpenGLCore), the broken-fragment compiler control fails as expected, and 20 real Unity RGBA float readbacks pass with maximum component error 5.960464477539063e-08. The same original configured URP asset is initialized through Unity's own render-loop initializer for this headless controlled test; its instance becomes UniversalRenderPipeline and it supplies the UniversalPipeline tag. No replacement asset or forced tag is used. The independent subsequent normal MainMenu probe advances 2100 frames with two active Canvases, one MainUIController and no exceptions. Asset audit again resolves all 148 game scripts, all 130 original markers, no missing components and no unresolved custom dummy shaders.

The archive preserves the 76 program byte arrays (each rehashed against the compilation report), all 20 byte-preserved 32x32 PNGs, sanitized logs, full reports and exact source. This result qualifies these shader compilation/math/binding scopes. Actual Metal execution, whole-game camera rendering, Board/gameplay/audio behavior and iPad acceptance are not proven. No new IPA was exported by this diagnostic. Earlier failures remain preserved as failures.
'''.encode())
js(D/'MANIFEST.json',[info(p.relative_to(D).as_posix(),p.read_bytes()) for p in sorted(D.rglob('*')) if p.is_file() and p!=D/'MANIFEST.json'])
print(json.dumps(dict(run=run['url'],shader_stage_compilations=76,pixel_readbacks=20,raw_outputs=96,mainmenu_frames=2100,ipa=None)))
