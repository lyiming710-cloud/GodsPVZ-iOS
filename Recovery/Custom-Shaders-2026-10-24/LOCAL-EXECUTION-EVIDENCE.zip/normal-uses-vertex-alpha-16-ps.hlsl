#define USE_SHAPE_LIGHT_TYPE_0 0
#define USE_SHAPE_LIGHT_TYPE_1 0
#define USE_SHAPE_LIGHT_TYPE_2 0
#define USE_SHAPE_LIGHT_TYPE_3 0

cbuffer Globals : register(b0) { float4 globals[160]; };
cbuffer Material : register(b1) { float4 material[4]; };
#define CBUFFER_START(name)
#define CBUFFER_END
#define TEXTURE2D(name) Texture2D name
#define SAMPLER(name) SamplerState name
#define SAMPLE_TEXTURE2D(tex, samp, uv) tex.SampleBias(samp, uv, globals[5].x)
#define SHAPE_LIGHT(index)
#define _Brightness material[1].x
#define _Transparent material[1].y
#define _ProjectionParams globals[21]
#define unity_ObjectToWorld transpose(float4x4(material[0],material[1],material[2],material[3]))
#define UNITY_MATRIX_V transpose(float4x4(globals[64],globals[65],globals[66],globals[67]))
float4 TransformObjectToHClip(float3 p) {
  float3 world=mul(unity_ObjectToWorld,float4(p,1)).xyz;
  return globals[76]*world.x+globals[77]*world.y+globals[78]*world.z+globals[79];
}
#define _RendererColor globals[129]
#define _HDREmulationScale globals[128].x
#define _UseSceneLighting globals[128].y

        #ifndef GODSPVZ_RECOVERED_BRIGHTNESS_INCLUDED
#define GODSPVZ_RECOVERED_BRIGHTNESS_INCLUDED

// PC path ID 871: PS programs 37..52, 56, 60. Android: 16..31, 33, 35.
// Keep the graph's float product before the half output; no UV scale/offset.
float4 RecoveredBrightnessColor(half4 texel, float4 color, float brightness, float transparent)
{
    return texel * float4(brightness, brightness, brightness, transparent) * color;
}

half3 RecoveredBrightnessLight(half3 light, half4 filter, half4 inverted)
{
    // The graph's mask is constant (1,1,1,1). Zero filter disables masking.
    if (dot(filter, filter) != 0.0)
        light *= dot(1.0 - inverted, filter);
    return light;
}

half4 RecoveredBrightnessLit(float4 color, half3 modulate, half3 additive, half hdrScale, half useLighting)
{
    if (color.a == 0.0)
        discard;
    #if USE_SHAPE_LIGHT_TYPE_0 || USE_SHAPE_LIGHT_TYPE_1 || USE_SHAPE_LIGHT_TYPE_2 || USE_SHAPE_LIGHT_TYPE_3
        half3 lit = hdrScale * (color.rgb * modulate + additive);
        half4 output = half4(lerp(color.rgb, lit, useLighting), color.a);
        return max(output, 0.0);
    #else
        return max(color, 0.0);
    #endif
}

half4 RecoveredBrightnessNormal(half4 texel, float3 viewNormal, float transparent)
{
    // Neither vertex alpha nor _RendererColor affects the original normals pass.
    half3 encodedNormal = (half3(viewNormal) + 1.0) * 0.5;
    return half4(encodedNormal, texel.a * transparent * 0.125);
}
#endif

        Texture2D _MainTex : register(t0);
        SamplerState sampler_MainTex : register(s0);
        CBUFFER_START(UnityPerMaterial)
            
            
            
        CBUFFER_END
        
        struct Attributes
        {
            float3 positionOS : POSITION;
            float4 tangentOS : TANGENT;
            float4 uv : TEXCOORD0;
            float4 color : COLOR;
        };
        struct Varyings
        {
            float4 positionCS : SV_POSITION;
            float4 uv : TEXCOORD0;
            float4 color : COLOR;
            float4 screenPosition : TEXCOORD1;
        };
        Varyings SpriteVertex(Attributes input)
        {
            Varyings output;
            output.positionCS = TransformObjectToHClip(input.positionOS);
            output.uv = input.uv;
            output.color = input.color * _RendererColor;
            float4 clip = output.positionCS;
            output.screenPosition = float4((float2(clip.x, clip.y * _ProjectionParams.x) + clip.w) * 0.5, clip.zw);
            return output;
        }
        half4 SampleMain(float2 uv)
        {
            return SAMPLE_TEXTURE2D(_MainTex, sampler_MainTex, uv);
        }



            struct NormalVaryings { float4 positionCS : SV_POSITION; float4 tangentWS : TEXCOORD0; float4 uv : TEXCOORD1; float3 viewNormal : TEXCOORD2; };
            NormalVaryings NormalVertex(Attributes input)
            {
                NormalVaryings output;
                output.positionCS = TransformObjectToHClip(input.positionOS);
                float3 tangent = mul((float3x3)unity_ObjectToWorld, input.tangentOS.xyz);
                tangent *= rsqrt(max(dot(tangent, tangent), 1.17549435e-38));
                output.tangentWS = float4(tangent, input.tangentOS.w);
                output.uv = input.uv;
                output.viewNormal = UNITY_MATRIX_V[2].xyz;
                return output;
            }
            half4 NormalFragment(NormalVaryings input) : SV_Target
            {
                return RecoveredBrightnessNormal(SampleMain(input.uv.xy), input.viewNormal, _Transparent);
            }
            