
cbuffer Material : register(b0) { float4 material[6]; };
cbuffer Object : register(b1) { column_major float4x4 unity_ObjectToWorld; };
cbuffer Camera : register(b2) { float4 cameraPadding[17]; column_major float4x4 recoveredVP; };
#define UNITY_MATRIX_VP recoveredVP
#define _MainTex_ST material[2]
#define _AngleX material[3].x
#define _AngleY material[3].y
#define _ScaleX material[3].z
#define _ScaleY material[3].w
#define _Alpha material[4].y
#define _IsVisible material[4].z
#define _Exposure material[4].w
#define _Color material[5]
Texture2D _MainTex : register(t0); SamplerState sampler_MainTex : register(s0);
#define tex2D(textureName, uv) textureName.Sample(sampler_MainTex, uv)



            
            #ifndef GODSPVZ_RECOVERED_GAME_UNIT_INCLUDED
#define GODSPVZ_RECOVERED_GAME_UNIT_INCLUDED

// Bound to PC DXBC programs 1/3 and Android GLES program 1 (path ID 886).
// Angles are radians. The original vertex program ignores input Z and W.
float2 RecoveredGameUnitXY(float2 position, float angleX, float angleY, float scaleX, float scaleY)
{
    float2 scaled = position * float2(scaleX, scaleY);
    float skewX = scaled.y * sin(angleX - angleY) + scaled.x;
    float skewY = cos(angleX - angleY) * scaled.y;
    float sinY = sin(angleY);
    float cosY = cos(angleY);
    return float2(skewX * cosY - skewY * sinY, skewX * sinY + skewY * cosY);
}

float4 RecoveredGameUnitColor(half4 texel, float4 color, float exposure, float alpha, float isVisible)
{
    // The hidden branch returns sampled RGB with alpha 0; it does not discard.
    if (isVisible == -1.0)
        return float4(texel.rgb, 0.0);
    return texel * color * float4(exposure, exposure, exposure, alpha);
}
#endif

            
            
            
            
            
            struct Attributes { float4 position : POSITION; float2 uv : TEXCOORD0; float4 color : COLOR; };
            struct Varyings { float2 uv : TEXCOORD0; float4 position : SV_POSITION; float4 color : COLOR; };
            Varyings vert(Attributes input)
            {
                Varyings output;
                float2 xy = RecoveredGameUnitXY(input.position.xy, _AngleX, _AngleY, _ScaleX, _ScaleY);
                float4 world = mul(unity_ObjectToWorld, float4(xy, 0.0, 1.0));
                output.position = mul(UNITY_MATRIX_VP, world);
                output.uv = input.uv * _MainTex_ST.xy + _MainTex_ST.zw;
                output.color = input.color * _Color;
                return output;
            }
            half4 frag(Varyings input) : SV_Target
            {
                half4 texel = tex2D(_MainTex, input.uv);
                return RecoveredGameUnitColor(texel, input.color, _Exposure, _Alpha, _IsVisible);
            }
            