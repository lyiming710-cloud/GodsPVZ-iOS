import itertools,json
from pathlib import Path
q=Path(__file__).resolve().parent;rows=[]
for occupy,y,depth,group in itertools.product(range(5),[-2.75,0,3.25],[.125,1.25],['null','live','destroyed']):rows.append(dict(name=f'layer-{occupy}-{y}-{depth}-{group}',token='0x060003A2',mode='normal',group=group,occupy=occupy,y=y,depth=depth))
for mode in ['normal','dead-ui','parent-swap']:rows.append(dict(name='layer-'+mode,token='0x060003A2',mode=mode,group='live',occupy=3,y=1.125,depth=.25))
for mode,group,count in itertools.product(['normal','second-renderer','hash-callback','dead-ui','no-range'],['null','live','destroyed'],[0,1,2]):rows.append(dict(name=f'preview-{mode}-{group}-{count}',token='0x060003A6',mode=mode,group=group,sprites=count))
rows.append(dict(name='preview-component-throws-original-finally-kept',token='0x060003A6',mode='throw-component',group='null',sprites=1,native_unwind='UNSUPPORTED_WINDOWS_SEH_NOT_MODELED'))
for mode,root,shadow,desired in itertools.product(['normal','shadow-swap'],[[10,20,30],[-7.25,0,9.125]],[[11,22,33],[.1,.2,.3]],[[100,200,300],[0,0,0],[-.5,19.25,-7]]):rows.append(dict(name='position-'+str(len(rows)),token='0x060003A3',mode=mode,group='null',root=root,shadow=shadow,desired=desired))
(q/'CASES.json').write_text(json.dumps(rows,indent=2)+'\n','utf-8');print(json.dumps(dict(cases=len(rows),by_token={t:sum(x['token']==t for x in rows)for t in sorted({x['token']for x in rows})})))
