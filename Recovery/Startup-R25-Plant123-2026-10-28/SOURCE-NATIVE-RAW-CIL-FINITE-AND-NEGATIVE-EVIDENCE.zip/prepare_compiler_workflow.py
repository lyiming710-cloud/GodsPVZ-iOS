from pathlib import Path
import hashlib,json,sys
Q=Path(__file__).resolve().parent;W=Q.parent;R=W.parents[1]/'audit/repo-native113';sys.path.insert(0,str(W));from archive_support import pack,manifest
old='4b5349946ee57d368002cdc1c358334efd43d4b9764657556e057148934927f3';new='9490c1845298fa5afda04fc8dfba915ce2a939eaebe96be83e3311b39557bc4c';files=[]
def derive(a,b,replacements):
 p=R/a;out=R/b;data=p.read_bytes();t=data.decode()
 for x,y in replacements:t=t.replace(x,y)
 assert t!=data.decode() and old not in t.replace("PARENT='"+old+"'",''),(a,'Required child binding was not replaced')
 assert not out.exists();out.write_bytes(t.encode());files.append(out)
repl=[(old,new),('R24','R25'),('r24','r25'),('Actor130','Plant123'),('ACTOR130','PLANT123')]
derive('scripts/actions/check_startup_r24_compiler.py','scripts/actions/check_startup_r25_compiler.py',repl)
repl=[(old,new),("PARENT='1d244776ee85083c2ed298c4f749f96b6c5ae820a78d50b0ce47480691775122'","PARENT='"+old+"'"),("{'0x06000228','0x06000229','0x0600022B','0x06000234','0x060003A4'}","{'0x060003A2','0x060003A3','0x060003A6'}"),('R24','R25'),('Actor130','Plant123'),('ACTOR130','PLANT123'),('==130','==123'),('==5','==3'),('==2312','==2314'),("'JIT_PREPARED_NO_EXECUTION':5","'JIT_PREPARED_NO_EXECUTION':3"),("'ZERO_DIFFERENCE':138,'UNSUPPORTED_ORIGINAL_WINDOWS_SEH_EXCEPTION_UNWIND':2","'ZERO_DIFFERENCE':162,'UNSUPPORTED_ORIGINAL_WINDOWS_SEH_EXCEPTION_UNWIND':1"),('==140','==163'),('positions=130,normal_native_cases=138,unmodeled_native_unwind=2','positions=123,normal_native_cases=162,unmodeled_native_unwind=1')]
derive('scripts/actions/validate_startup_r24_checkpoint.py','scripts/actions/validate_startup_r25_checkpoint.py',repl)
p=R/'.github/workflows/bulk401-generic-compiler-check.yml';data=p.read_bytes();(Q/'PREVIOUS-REGISTERED-COMPILER-WORKFLOW.yml').write_bytes(data);t=data.decode().replace(old,new).replace('R24','R25').replace('r24','r25').replace('Actor130','Plant123').replace('ACTOR130','PLANT123');p.write_bytes(t.encode());files.append(p);p=R/'.github/workflows/startup-r25-compiler-check.yml';assert not p.exists();p.write_bytes(t.encode());files.append(p)
C=R/'Recovery/Startup-R25-Plant123-2026-10-28';pack(C/'COMPILER-ADMISSION-AND-WORKFLOW-SOURCES.zip',[(p.relative_to(R).as_posix(),p.read_bytes())for p in files]);manifest(C);print('PREPARED_R25_COMPILER_ONLY_NO_EDITOR_OR_IPA')
