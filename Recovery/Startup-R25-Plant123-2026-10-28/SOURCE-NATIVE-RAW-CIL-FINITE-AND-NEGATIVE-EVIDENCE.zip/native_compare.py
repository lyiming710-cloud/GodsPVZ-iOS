"""Run three untouched original Plant callers against exact child raw CIL.

Engine/collection leaves are explicit finite controlled contracts. Windows
exception unwind, real Unity and iPad behavior remain separate gates.
"""
from pathlib import Path
import collections,ctypes as C,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
spec=json.loads((W/'startup-r24-actor-initialization/ORIGINAL-OPERAND-RESOLUTION.json').read_bytes());cases=json.loads((Q/'CASES.json').read_bytes());actual=json.loads(Path(sys.argv[1]).read_bytes());by={x['name']:x for x in actual['results']};state={};rows=[]
def f32(v):return struct.unpack('<f',struct.pack('<f',v))[0]
def vec(v):return ','.join(bits(x)for x in v)
def tag(p):return 'null'if not p else state['objects'][p]['tag']
def log(*v):state['trace'].append(':'.join('1'if x is True else'0'if x is False else'null'if x is None else str(x)for x in v))
def obj(label,kind='UObj',alive=True,size=1024):p=im.alloc(size);state['objects'][p]=dict(tag=label,kind=kind,alive=alive);return p
def go(label):
 p=obj(label,'GameObject');tr=obj(label+'-tr','Transform');r=obj(label+'-renderer','SpriteRenderer');other=obj(label+'-other-renderer','SpriteRenderer');state['objects'][p].update(transform=tr,renderer=r,other=other,reads=0,active=True);state['objects'][tr].update(position=(0.,0.,0.),parent=0,worldStay=False);state['objects'][r]['color']=tuple(f32(v)for v in[.1,.3,.7,.8]);state['objects'][other]['color']=tuple(f32(v)for v in[.9,.5,.4,.2]);state['go_order'].append(p);return p
def seq(items):p=im.alloc(64);state['lists'][p]=items;return p
def string(v):p=im.alloc(32);state['strings'][p]=v;return p
def live(p):return bool(p and state['objects'][p]['alive'])
def presence(kind):
 def cb(a,b=None,m=None):
  if kind=='implicit':v=live(a);log(kind,tag(a),v)
  else:
   v=(not live(a)and not live(b))or a==b
   if kind=='ne':v=not v
   log(kind,tag(a),tag(b),v)
  return v
 return cb
def component_transform(p,m):log('componentTransform',tag(p));return state['objects'][p]['transform']
def go_transform(p,m):
 log('goTransform',tag(p))
 if state['mode']=='parent-swap'and tag(p)=='hp':put64(get64(state['plant']+0x1e8)+0x70,state['other-ui'])
 return state['objects'][p]['transform']
def parent(p,other,stay,m=None):log('parent',tag(p),tag(other),bool(stay));state['objects'][p].update(parent=other,worldStay=bool(stay))
def getpos(out,p,m):v=state['objects'][p]['position'];log('position',tag(p));C.memmove(out,struct.pack('<3f',*v),12);return out
def setpos(p,value,m):
 v=struct.unpack('<3f',C.string_at(value,12));log('setPosition',tag(p),vec(v));old=state['objects'][p]['position'];delta=tuple(f32(a-b)for a,b in zip(v,old));state['objects'][p]['position']=v
 if tag(p)=='plant-tr':
  shadow=get64(state['plant']+0x178);tr=state['objects'][shadow]['transform'];state['objects'][tr]['position']=tuple(f32(a+b)for a,b in zip(state['objects'][tr]['position'],delta))
  if state['mode']=='shadow-swap':put64(state['plant']+0x178,state['other-shadow'])
def getenum(out,p,m):put64(out,p);put32(out+8,0);put64(out+16,0);return out
def move(p,m):
 source=get64(p);index=get32(p+8);items=state['lists'][source]
 if index>=len(items):return False
 put64(p+16,items[index]);put32(p+8,index+1);return True
def getcomponent(p,m):
 log('getComponent',tag(p),'SpriteRenderer');o=state['objects'][p];o['reads']+=1;return o['other']if state['mode']=='second-renderer'and o['reads']%2==0 else o['renderer']
def getcolor(out,p,m):v=state['objects'][p]['color'];log('color',tag(p),vec(v));C.memmove(out,struct.pack('<4f',*v),16);return out
def setcolor(p,value,m):v=struct.unpack('<4f',C.string_at(value,16));log('setColor',tag(p),vec(v));state['objects'][p]['color']=v
def newgroup(p,m):log('addComponent',tag(p),'SortingGroup');r=obj('created-group','SortingGroup');state['objects'][r].update(layer='',order=-999);return r
def layer(p,value,m):v=state['strings'][value];log('layer',tag(p),v);state['objects'][p]['layer']=v
def order(p,value,m):log('order',tag(p),value);state['objects'][p]['order']=value
def active(p,value,m):log('active',tag(p),bool(value));state['objects'][p]['active']=bool(value)
def expand(p,n,v,m):log('expand',tag(p),n,bool(v));state['objects'][p]['expanded']=True
def getstate(out,p,n,m):log('state',tag(p),n);C.memmove(out,struct.pack('<9i',state['objects'][p]['hash'],*([0]*8)),36);return out
def gethash(p,m):
 v=get32(p);log('hash',v)
 if state['mode']=='hash-callback':put64(state['plant']+0x168,state['other-animator'])
 return v
def play(p,h,n,v,m):log('play',tag(p),h,n,bits(v));state['objects'][p].update(played=h,playLayer=n,normal=v)
def speed(p,v,m):log('speed',tag(p),bits(v));state['objects'][p]['speed']=v

def setup(q):
 state.clear();state.update(mode=q['mode'],objects={},strings={},lists={},trace=[],go_order=[])
 state['other-ui']=go('other-ui');state['other-shadow']=go('other-shadow');state['objects'][state['objects'][state['other-shadow']]['transform']]['position']=(501.,502.,503.);otheranim=obj('other-animator','Animator');state['other-animator']=otheranim
 board=obj('board','Board');plantui=go('plant-ui');put64(board+0x70,plantui);plant=obj('plant','Plant');root=obj('plant-tr','Transform');state['plant']=plant;state['root']=root;state['objects'][plant]['transform']=root;state['objects'][root].update(position=tuple(q.get('root',[10.,20.,30.])),parent=0,worldStay=False)
 putf(plant+0x30,-1);putf(plant+0x34,q.get('y',2.75));putf(plant+0x44,q.get('depth',1.25));put32(plant+0x118,q.get('occupy',0));manager=im.alloc(128);put32(manager+0x38,q.get('base',7));put64(plant+0x1e0,manager);put64(plant+0x1e8,board);C.c_ubyte.from_address(plant+0xb0).value=True
 for name,off in [('animation-part',0x158),('shadow',0x178),('hp',0x1a0),('elements',0x1b0),('buff',0x1c0)]:
  p=go(name);put64(plant+off,p)
  if name=='shadow':state['objects'][state['objects'][p]['transform']]['position']=tuple(f32(v)for v in q.get('shadow',[11.,22.,33.]))
  if state['mode']=='dead-ui'and name in['hp','buff']:state['objects'][p]['alive']=False
 ar=obj('attack-range','AttackRangeUIController');state['objects'][ar]['expanded']=False;put64(plant+0x70,0 if q['mode']=='no-range'else ar)
 anim=obj('animator','Animator');state['animator']=anim;put64(plant+0x168,anim)
 for p,hash_ in[(anim,1234),(otheranim,9876)]:state['objects'][p].update(hash=hash_,speed=7.,played=-1,playLayer=-1,normal=-1.)
 group=0
 if q['group']!='null':group=obj('group','SortingGroup',alive=q['group']!='destroyed');state['objects'][group].update(layer='',order=-999)
 put64(plant+0x170,group);mouse=obj('mouse','MouseManager');mt=obj('mouse-tr','Transform');state['mouse']=mouse;state['objects'][mouse]['transform']=mt;state['objects'][mt].update(position=(0.,0.,0.),parent=0,worldStay=False);mb=obj('mouse-board','Board');put64(mb+0x70,go('mouse-plant-ui'));put64(mouse+0x28,mb)
 put64(plant+0x148,seq([go('sprite-'+str(i))for i in range(q.get('sprites',2))]));uis=[]
 for i in range(q.get('ui',2)):
  p=go('characteristic-'+str(i));state['objects'][p]['alive']=i!=1;uis.append(p)
 if q.get('ui',2)>1:uis.append(0)
 put64(plant+0x1c8,seq(uis));state['desired']=im.alloc(12);C.memmove(state['desired'],struct.pack('<3f',*q.get('desired',[100.,200.,300.])),12)
 for at,text in literal_slots.items():put64(at,string(text))

def snapshot():
 p=state['plant'];g=get64(p+0x170);group=state['objects'][g]if g else{};tr=state['objects'][state['root']];ar=get64(p+0x70);gos=[]
 for ptr in state['go_order']:
  go_=state['objects'][ptr];t=state['objects'][go_['transform']];gos.append(dict(tag=tag(ptr),active=go_['active'],parent=tag(t['parent']),worldStay=t['worldStay'],position=vec(t['position']),color=vec(state['objects'][go_['renderer']]['color']),otherColor=vec(state['objects'][go_['other']]['color'])))
 animators=[]
 for a in[state['animator'],state['other-animator']]:
  o=state['objects'][a];animators.append(dict(tag=tag(a),speed=bits(o['speed']),hash=o['played'],layer=o['playLayer'],normal=bits(o['normal'])))
 return dict(board=tag(get64(p+0x1e8)),fX=bits(getf(p+0x30)),fY=bits(getf(p+0x34)),onField=bool(C.c_ubyte.from_address(p+0xb0).value),group=tag(g),layer=group.get('layer'),order=group.get('order'),root=vec(tr['position']),parent=tag(tr['parent']),worldStay=tr['worldStay'],shadow=tag(get64(p+0x178)),animator=tag(get64(p+0x168)),animators=animators,expanded=state['objects'][ar]['expanded']if ar else None,objects=gos)

for rid in[0x3a2,0x3a3,0x3a6]:
 im=NativeImage();literal_slots={};classes={};cfg=json.loads((Q/'native-source-complete'/f'0x{0x6000000|rid:08X}.json').read_bytes())
 for d in spec:
  for r in d['rows']:
   v=r['resolved']
   if isinstance(v,dict)and'class'in v:
    if v['class']not in classes:
     p=im.alloc(512);put32(p+0xe0,1);classes[v['class']]=p
    put64(int(v['slot_va'],16),classes[v['class']])
   if isinstance(v,dict)and'string'in v:literal_slots[int(v['slot_va'],16)]=v['string']
 im.hook(0x18024fef0,None,[P],lambda p:None);im.hook(0x1802501e0,None,[P],lambda p:None);im.hook(0x18024f360,None,[P,P],lambda a,b:None)
 im.hook(0x18131f760,C.c_bool,[P,P,P],presence('eq'));im.hook(0x18131f900,C.c_bool,[P,P,P],presence('ne'));im.hook(0x18131f870,C.c_bool,[P,P],presence('implicit'))
 im.hook(0x181304510,P,[P,P],component_transform);im.hook(0x18131c070,P,[P,P],go_transform);im.hook(0x18132e8b0,None,[P,P,P],lambda p,o,m:parent(p,o,True,m));im.hook(0x18132e900,None,[P,P,C.c_bool,P],parent)
 im.hook(0x18132f3a0,P,[P,P,P],getpos);im.hook(0x18132fbb0,None,[P,P,P],setpos);im.hook(0x1808197f0,P,[P,P,P],getenum);im.hook(0x180669280,C.c_bool,[P,P],move);im.hook(0x180302170,None,[P,P],lambda p,m:None)
 im.hook(0x18046dc80,P,[P,P],getcomponent);im.hook(0x181328fc0,P,[P,P,P],getcolor);im.hook(0x1813290a0,None,[P,P,P],setcolor);im.hook(0x18046d280,P,[P,P],newgroup)
 im.hook(0x181348060,None,[P,P,P],layer);im.hook(0x1813480b0,None,[P,I,P],order);im.hook(0x18131bad0,None,[P,C.c_bool,P],active);im.hook(0x180394450,None,[P,I,C.c_bool,P],expand)
 im.hook(0x1812db780,P,[P,P,I,P],getstate);im.hook(0x1808e3a80,I,[P,P],gethash);im.hook(0x1812db860,None,[P,I,I,F,P],play);im.hook(0x1812dbcd0,None,[P,F,P],speed)
 im.verify_caller(rid,int(cfg['entry'],16),cfg)
 for q in cases:
  if q['token']!=f'0x{0x6000000|rid:08X}':continue
  expected=by[q['name']]
  if'native_unwind'in q:rows.append(dict(name=q['name'],token=q['token'],status='UNSUPPORTED_ORIGINAL_WINDOWS_SEH_EXCEPTION_UNWIND',cil_error=expected['error'],candidate_finally_preserved=True));continue
  setup(q)
  if rid==0x3a2:C.CFUNCTYPE(None,P,P)(int(cfg['entry'],16))(state['plant'],None)
  else:C.CFUNCTYPE(None,P,P,P)(int(cfg['entry'],16))(state['plant'],state['mouse']if rid==0x3a6 else state['desired'],None)
  assert not im.errors,im.errors;got=dict(state=snapshot(),trace=state['trace']);diff={k:dict(native=got[k],cil=expected[k])for k in['state','trace']if got[k]!=expected[k]}
  if expected['error']:diff['cil_error']=expected['error']
  rows.append(dict(name=q['name'],token=q['token'],status='ZERO_DIFFERENCE'if not diff else'DIFFERENCE',native=got,cil=expected,differences=diff))
 im.close()
result=dict(scope='THREE_UNMODIFIED_PC_PLANT_CALLERS_VS_EXACT_RAW_CHILD_CIL_FINITE_CONTRACTS_NOT_UNITY',candidate_sha256=actual['candidate_sha256'],original_pc_sha256=PC_SHA,counts=dict(collections.Counter(x['status']for x in rows)),rows=rows,whole_game_behavior_proven=False,ipa=None)
(Q/'NATIVE-COMPARE.json').write_text(json.dumps(result,indent=2)+'\n','utf-8');print(json.dumps({k:v for k,v in result.items()if k!='rows'},indent=2));print(json.dumps([x for x in rows if x['status']=='DIFFERENCE'][:1],indent=2));assert not any(x['status']=='DIFFERENCE'for x in rows)
