from pathlib import Path
import hashlib,json,sys
Q=Path(__file__).resolve().parent;W=Q.parent;R=W.parents[1]/'audit/repo-native113';sys.path.insert(0,str(W));from archive_support import js,pack,manifest,variants
data=(Q/'authored1.dll').read_bytes();r=json.loads((Q/'authored1.json').read_bytes());assert hashlib.sha256(data).hexdigest()==r['candidate_sha256']=='9490c1845298fa5afda04fc8dfba915ce2a939eaebe96be83e3311b39557bc4c'
C=R/'Recovery/Startup-R25-Plant123-2026-10-28';assert not C.exists();C.mkdir();(C/'.gitattributes').write_bytes(b'* -text\n');pack(C/'STARTUP-R25-PLANT123-CANDIDATE.zip',[('STARTUP-R25-PLANT123.dll',data)])
for src,name in [('authored1.json','CONSTRUCTION.json'),('shared-authored1/ISOLATION.json','ISOLATION.json'),('shared-authored1/FROZEN-RAW.json','FROZEN-RAW.json'),('shared-authored1/MEMBER-EXIT.json','MEMBER-EXIT.json'),('shared-authored1/jit/RESULT.json','EXACT-JIT.json'),('NATIVE-COMPARE.json','NATIVE-COMPARE.json'),('PHYSICAL-CONTROLS.json','PHYSICAL-CONTROLS.json'),('REPEATED-CONSTRUCTION.json','REPEATED-CONSTRUCTION.json'),('ORIGINAL-DIRECT-API-IDENTITIES.json','ORIGINAL-DIRECT-API-IDENTITIES.json')]:
 (C/name).write_bytes((Q/src).read_bytes())
items=[]
for p in sorted(Q.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(Q)
 if any(x in['bin','obj','__pycache__']for x in rel.parts)or p.suffix.lower()=='.dll':continue
 items.append((rel.as_posix(),p.read_bytes()))
pack(C/'SOURCE-NATIVE-RAW-CIL-FINITE-AND-NEGATIVE-EVIDENCE.zip',items)
js(C/'PHYSICAL-VARIANT-BYTE-DELTAS.json',variants(Q/'physical-controls',data))
js(C/'PROGRESS.json',dict(status='THREE_PLANT_CALLERS_123_POSITIONS_FINITE_GATES_PASS_FRESH_COMPILER_PENDING',candidate_sha256=r['candidate_sha256'],parent_sha256=r['parent_sha256'],positions=123,methods=3,qualified_methods=0,whole_game_accepted=False,ipad_acceptance=False,ipa=None,unity_run=None,normal_native_comparisons=162,unsupported_windows_unwind=1,physical_semantic_controls=6,known_next_blockers=['Two actual loaded ComponentHolderProtocol SDK methods still return defaults','Real Editor complex level and actual plant damage remain unobserved for this exact child']))
(C/'README.md').write_text('''# R25 original Plant visual lifecycle and position recovery

Parent R24 `4b534994…27f3`; child `9490c1845298fa5afda04fc8dfba915ce2a939eaebe96be83e3311b39557bc4c`. Three complete original callers, 123 distinct original native operation positions. This follows the separately completed R24 130-position cohort; the total 253 positions is not a count of independent bugs or formally qualified methods.

- Plant.SetLayer (0x060003A2): original Unity group presence, Entity layer, single-precision depth/occupy-state sorting and total-plant offset; original HP/element/buff and characteristic UI reparenting, preserving one-argument SetParent semantics and finally.
- Plant.SetPrefabState_previewOnField (0x060003A6): original mouse.board assignment, two separate SpriteRenderer lookups and copied RGBA with alpha * 0.2f, Unity-null group creation, UI/9000, two-argument SetParent(false), range view, UI hiding, both finally regions, captured animator state hash / Play(hash,0,1f/60f) and speed zero. On-hand and preview intentionally use different original parenting overloads.
- Plant.SetTransformPosition (0x060003A3): calculate desired-minus-shadow offset and add it to the plant root, then re-read actual shadow separately for logical fX/fY. The former reconstructed body directly set the root to the requested shadow position.

Append-only relocation preserves the other 2,314 MethodDefs and all old code slots, metadata rows/heaps, visibility and section permissions. Three local signatures are appended; no new MemberRef or MethodSpec. All three targets pass the unchanged frozen checker; whole assembly remains 2,200 PASS / 97 FAIL_OR_UNSUPPORTED. The all-2,297-method member access census passes and three real-image JIT preparations succeed, without gameplay invocation.

Actual raw CIL executed 163 finite controlled cases. Three original byte-rechecked PC callers match all 162 normal cases, including fake-null groups, depth states, different sprite renderer per lookup, callback-induced animator replacement, UI-parent replacement and root/shadow offset cases. One injected Windows exception-unwind case remains UNSUPPORTED. Six physically changed, type-valid candidates each create observable final-state differences. Controlled callees are not proof of original nested Unity/game behavior.

No Editor or iPad gameplay acceptance, Xcode link or IPA is claimed. The actual VisualScripting default-return defect is still recorded; do not ignore it in a new real complex-level attempt. R24's fresh Linux run 40643198045 passes 755 C++ + 274 C sources with raw read-back and does not qualify this different R25 child.
''','utf-8')
manifest(C);print(json.dumps(dict(checkpoint=str(C),candidate_sha256=r['candidate_sha256'],positions=123,methods=3)))
