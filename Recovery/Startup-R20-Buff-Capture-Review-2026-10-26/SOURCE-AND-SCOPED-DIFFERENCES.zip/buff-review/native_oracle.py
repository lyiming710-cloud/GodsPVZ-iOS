"""Find capture-order differences, explicitly separating controlled side effects from game triggers."""
from pathlib import Path
import collections,ctypes as C,functools,hashlib,json,struct,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
im=NativeImage();state={};cfg=json.loads((W/'r21-marker-source-review-2026-10-26/0x060005E7.native.json').read_bytes());fields=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_bytes())
@functools.lru_cache(None)
def off(owner,name):
    rows=[r for r in fields if r['type']==owner and r['namespace']=='' and r['name']==name];assert len(rows)==1,(owner,name);return rows[0]['offset']
def log(s):state['trace'].append(s)
def bits(v):return struct.pack('<f',v)[::-1].hex().upper()
def f(k):return struct.unpack('<f',bytes.fromhex(state['q'][k])[::-1])[0]
def tag(p):return 'null' if not p else state['tags'][p]
def text(p):return C.string_at(p+0x14,get32(p+0x10)*2).decode('utf-16-le')
def string(s):
    b=s.encode('utf-16-le');p=im.alloc(24+len(b));put32(p+0x10,len(b)//2);C.memmove(p+0x14,b,len(b));return p
def equal(p,b,m):assert not b and not m;v=bool(p and state['live'][p]);log('Exists:'+tag(p)+':'+str(int(v)));return not v
def atk(p,m):assert not m;v=f('adjusted')+(1 if tag(p)=='other' else 0);log('ATK:'+tag(p)+':'+bits(v));return v
def inc(p,value,key,m):
    assert not m;k=text(key);result=f('ms' if k=='Ms' else 'increment');log('Increment:'+tag(p)+':'+bits(value)+':'+k+':'+bits(result))
    if k=='Def':
        state['defcalls']+=1;n=state['q']['mode'];owner=state['owners'][p];name='defense' if state['defcalls']==1 else 'armor1Defense' if state['defcalls']==2 and get32(owner+off('Zombie','armor1Type')) else 'armor2Defense'
        if n in [1,3]:putf(owner+off('Zombie',name),getf(owner+off('Zombie',name))+10)
        if n in [2,3] and state['defcalls']==1:put64(state['ui']+off('BuffUIController_Zombie','zombie'),state['other'])
    return result
def stats_float(p,key,value,m):assert p==state['ui'] and not m;log('Float:'+str(key)+':'+bits(value))
def stats_int(p,key,level,direction,m):assert p==state['ui'] and not m;log(f'Ints:{key}:{level}:{direction}')
try:
    meta=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/global-metadata.dat').read_bytes();assert hashlib.sha256(meta).hexdigest()=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9';so,sn,do,dn=struct.unpack_from('<4I',meta,8);dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True;slots=set();literals=[]
    for row in cfg['instructions']:
        i=next(dis.disasm(bytes.fromhex(row['bytes']),int(row['va'],16)))
        if i.mnemonic not in ['mov','lea']:continue
        for o in i.operands:
            if o.type!=X86_OP_MEM or o.mem.base!=X86_REG_RIP:continue
            at=i.address+i.size+o.mem.disp;raw=im.pe.get_data(at-im.base,8)
            if len(raw)!=8:continue
            code=int.from_bytes(raw,'little')
            if code>0xffffffff or code>>29 not in range(1,8) or at in slots:continue
            slots.add(at);kind,index=code>>29,(code&0x1fffffff)>>1
            if kind==5:
                size,pos=struct.unpack_from('<II',meta,so+8*index);literal=meta[do+pos:do+pos+size].decode('utf-8');put64(at,string(literal));literals.append(literal)
            else:im.class_slot(at)
    assert set(literals)=={'Ms','Def'}
    def init(p):assert p in slots
    im.hook(0x18024fef0,None,[P],init);im.hook(0x1802501e0,None,[P],lambda p:None);im.hook(0x18131f760,C.c_bool,[P,P,P],equal);im.hook(0x180310420,F,[P,F,P,P],inc);im.hook(0x180360280,F,[P,P],atk);im.hook(0x18039aa60,None,[P,I,F,P],stats_float);im.hook(0x18039a7d0,None,[P,I,I,I,P],stats_int)
    im.verify_caller(0x5e7,int(cfg['entry'],16),cfg);rows=[];cases=json.loads((Q/'CASES.json').read_bytes())
    for q in cases:
        state.clear();state.update(q=q,trace=[],tags={},live={},owners={},defcalls=0)
        def make(label,size):p=im.alloc(size);state['tags'][p]=label;return p
        state['ui']=make('ui',128)
        for label,delta in [('first',0),('other',13)]:
            p=make(label,1024);state[label]=p;state['live'][p]=q.get('zombie',1)==1;board=make(label+'Board',128);state['live'][board]=q.get('board',1)==1;buff=make(label+'Buff',128);state['owners'][buff]=p;put64(p+off('Zombie','board'),board if q.get('board',1) else 0);put64(p+off('Zombie','buffManager'),buff);putf(p+off('Zombie','attackPoint'),f('attack'))
            for name,value in [('defense',f('defense')+delta),('armor1Defense',f('defense')+3+delta),('armor2Defense',f('defense')*2+delta)]:putf(p+off('Zombie',name),value)
            put32(p+off('Zombie','armor1Type'),q['armor']&1);put32(p+off('Zombie','armor2Type'),(q['armor']>>1)&1)
        put64(state['ui']+off('BuffUIController_Zombie','zombie'),state['first'] if q.get('zombie',1) else 0);C.CFUNCTYPE(None,P,P)(int(cfg['entry'],16))(state['ui'],None);assert not im.errors,(q,im.errors)
        snap=dict(root=tag(get64(state['ui']+off('BuffUIController_Zombie','zombie'))),first=[bits(getf(state['first']+off('Zombie',n))) for n in ['defense','armor1Defense','armor2Defense']],other=[bits(getf(state['other']+off('Zombie',n))) for n in ['defense','armor1Defense','armor2Defense']]);rows.append(dict(name=q['name'],token='0x060005E7',error=None,trace=list(state['trace']),state=snap))
    actual=json.loads(Path(sys.argv[1]).read_bytes());digest=hashlib.sha256((W/'startup-r20-sites100/authored3.dll').read_bytes()).hexdigest();assert actual['candidate_sha256']==digest;found={r['name']:r for r in actual['results']};domains={q['name']:q['domain'] for q in cases};assert set(found)==set(domains)
    diff=[dict(domain=domains[r['name']],original=r,actual=found[r['name']]) for r in rows if r!=found[r['name']]]
    report=dict(scope='COMPLETE_EXISTING_BUFF_CALLER_CAPTURE_ORDER_DIFFERENCE_REVIEW',candidate_sha256=digest,original_pc_sha256=hashlib.sha256(im.raw).hexdigest(),records=len(rows),results=rows,differences=diff,differences_by_domain=dict(collections.Counter(r['domain'] for r in diff)),callback_errors=im.errors,native_caller_bytes_verified=True,original_comparisons_and_branches_unchanged=True,actual_buff_callee_side_effect_trigger_proven=False,child_stats_float_known_nan_failure_not_tested_by_this_caller_profile=True,new_game_changes=0,formal_or_product_acceptance=False)
    Path(sys.argv[2]).write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in report.items() if k not in ['results','differences']}));print('differences',len(diff));raise SystemExit(2 if diff else 0)
finally:im.close()
