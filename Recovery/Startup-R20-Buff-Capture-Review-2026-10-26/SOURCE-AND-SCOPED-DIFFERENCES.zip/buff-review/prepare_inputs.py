from pathlib import Path
import itertools,json,struct
Q=Path(__file__).resolve().parent;bits=lambda x:struct.pack('>f',x).hex().upper();rows=[]
for attack,adjusted,armor,defense,ms,mode in itertools.product(['00000000','80000000','3F800000','BF800000','7FC07654','7F800000'],[0,2],range(4),[0,1,-2],[-1,0,1],range(4)):
 rows.append(dict(name=f'b{len(rows):05}',token='0x060005E7',attack=attack,adjusted=bits(adjusted),armor=armor,defense=bits(defense),ms=bits(ms),increment=bits(.5),mode=mode,domain='PURE_CONTROLLED_RETURNS' if mode==0 else 'CONTROLLED_ROOT_REPLACEMENT' if mode==2 else 'CONTROLLED_FIELD_MUTATION_NO_REAL_CALLEE_TRIGGER_PROOF'))
for z,b in [(0,1),(2,1),(1,0),(1,2)]:rows.append(dict(rows[0],name=f'b{len(rows):05}',zombie=z,board=b))
(Q/'CASES.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode());print(len(rows))
