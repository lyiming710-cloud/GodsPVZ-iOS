from pathlib import Path
import json
from archive_support import sha,js,pack,manifest
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';Q=W/'r21-buff-capture-review-2026-10-26';D=R/'Recovery/Startup-R20-Buff-Capture-Review-2026-10-26';T=R/'Recovery/Startup-R20-Sites104-2026-10-26';F=R/'Recovery/Startup-R20-IPA-Build-2026-10-26';A=R/'Recovery/Startup-R20-Asset-Case-2026-10-26'
assert not D.exists();D.mkdir();(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text\n*.md -text\n*.zip -text\n')
n=json.loads((Q/'NATIVE-ATTEMPT1.json').read_bytes());a=json.loads((Q/'FULL-CIL-R19.json').read_bytes());b=json.loads((Q/'FULL-CIL-R20.json').read_bytes());assert n['records']==1732 and len(n['differences'])==864 and n['differences_by_domain']=={'CONTROLLED_FIELD_MUTATION_NO_REAL_CALLEE_TRIGGER_PROOF':864} and not n['callback_errors'] and a['results']==b['results']
assert all(r['error'] is None for r in a['results']) and not n['actual_buff_callee_side_effect_trigger_proven'];cases={q['name']:q for q in json.loads((Q/'CASES.json').read_bytes())}
js(D/'COUNTEREXAMPLES.json',[dict(input=cases[d['original']['name']],comparison=d) for armor in range(4) for d in [next(r for r in n['differences'] if cases[r['original']['name']]['armor']==armor and cases[r['original']['name']]['mode']==1)]])
js(Q/'R19-AND-R20-BINDING.json',dict(parent_sha256=a['candidate_sha256'],current_sha256=b['candidate_sha256'],all_rows_identical=True,records=1732,new_game_changes=0))
cil=json.loads((W/'startup-r20-sites100/shared-authored3/ALL-CIL.json').read_bytes());method=next(m for m in cil['methods'] if m['token']=='0x060005E7');getter=next(m for m in cil['methods'] if m['name']=='System.Single Zombie::AttackPoint()');assert not any(i['opcode'].startswith('call') for i in getter['instructions']) and {i['operand']['identity'] for i in getter['instructions'] if i['opcode']=='ldfld'}=={'System.Single Zombie::attackPoint'}
spec=[]
cfg=json.loads((W/'r21-marker-source-review-2026-10-26/0x060005E7.native.json').read_bytes());native={i['va']:i for i in cfg['instructions']}
for field,va,cil_after in [('defense','0x18039a64f',435),('armor1Defense','0x18039a69a',549),('armor2Defense','0x18039a70b',726)]:
    ins=next(i for i in method['instructions'] if i['offset']==cil_after);assert ins['opcode']=='ldfld' and ins['operand']['identity']=='System.Single Zombie::'+field
    spec.append(dict(token='0x060005E7',field=field,native_pre_call_capture=native[va],current_cil_post_call_re_read=ins,proposed='Capture the float operand in a new local before GetIncrement and reuse it after the call; preserve separate fresh receiver/base-defense reads',source_semantic_position_count=1,candidate_modified=False,actual_buff_callee_trigger_proven=False))
js(D/'THREE-CAPTURE-POSITIONS-PROPOSED-NOT-APPLIED.json',spec)
files=[]
for p in sorted(Q.rglob('*')):
    if p.is_file() and not any(x in p.parts for x in ['obj','__pycache__']):files.append(('buff-review/'+p.relative_to(Q).as_posix(),p.read_bytes()))
for suffix in ['.native.json','.cil.json']:
    p=W/'r21-marker-source-review-2026-10-26'/('0x060005E7'+suffix);files.append(('source/'+p.name,p.read_bytes()))
files += [('current-cil/AttackPoint.json',(json.dumps(getter,indent=2)+'\n').encode()),('frozen-runtime/Rehost.cs',(W/'startup-r5/runtime-common/Rehost.cs').read_bytes()),('frozen-runtime/native_runtime_common.py',(W/'startup-r5/native_runtime_common.py').read_bytes()),(Path(__file__).name,Path(__file__).read_bytes())];pack(D/'SOURCE-AND-SCOPED-DIFFERENCES.zip',files)
js(D/'PROGRESS.json',dict(status='THREE_CAPTURE_ORDER_DIFFERENCES_OBSERVED_UNDER_CONTROLLED_FIELD_MUTATION_NOT_REAL_GAME_TRIGGER_PROOF',method='0x060005E7',records=1732,matching_records=868,controlled_field_mutation_differences=864,actual_buff_callee_trigger_proven=False,scope='Existing parent caller validation, child Stats(float) known failure remains separate',proposed_source_positions=3,new_game_changes=0,existing_r19_finite_union_unchanged=81,existing_r19_pending_unchanged=19,formal_or_product_acceptance=False))
(D/'README.md').write_bytes('''# BuffUI.FixedUpdate：三个字段捕获顺序差异，保留触发范围

0x060005E7既有完整CIL与未改原版调用方，在两个固定R19/R20候选共执行1,732条输入。868条无字段写回的受控返回/接收者替换/早退出记录一致；864条受控GetIncrement回写接收者字段的记录不同。没有异常、进程崩溃或原生回调错误。两候选CIL结果完全相同，游戏DLL不变。

原版在GetIncrement之前保存defense、armor1Defense、armor2Defense作为稍后累加的基值；当前CIL在调用后又从捕获对象读取这些字段。三个原生加载位置、当前CIL重读位置和拟用float local捕获的方案在JSON中。输入控制让GetIncrement回写字段，能观测调用方顺序差异；尚未证明真实BuffManager.GetIncrement会这样回写，因此不宣称实际游戏必定发生864个bug、也不据此解释iPad黑屏。

实际CIL中的AttackPoint是无子调用的纯字段getter，fixture公开getter仅复现该边界；原版该getter已内联为字段读取。GetATK、GetIncrement和SetStats两种重载为声明的受控叶函数。本报告没有执行有已知NaN问题的SetStats(float)真实子body，也不覆盖它的内部正确性。不能把父方法的无写回样本当作子方法修复通过。

三个拟恢复位置尚未写入任何新候选。与先前四个浮点提案合计七个待构造语义位置；不会为凑超过100的位置数修改正确代码，后续新代码仍按批次阈值集中检测。该方法不在R19百方法内，R19已归档81有限profile/19待验收不变。
'''.encode());manifest(D)
queue=json.loads((T/'CURRENT-WORK-QUEUE.json').read_bytes());row=next(r for r in queue['rows'] if r['token']=='0x060005E7');row.update(current_state='EXISTING_CALLER_CAPTURE_ORDER_DIFFERENCES_UNDER_CONTROLLED_FIELD_MUTATIONS',current_required_action='Three pre-call float captures proposed, real BuffManager mutation trigger still unproven; keep universal qualification pending',capture_review='../'+D.name);js(T/'CURRENT-WORK-QUEUE.json',queue);manifest(T)
# The freshly dispatched full build still binds c22560e; no pending build is re-targeted.
for folder in [F,A]:
    s=json.loads((folder/'PROGRESS.json').read_bytes());s.update(current_real_build_run=40263428409,current_real_build_source='c22560ed9e025f04d4e58bc38ba0f23df8b9feb4',current_real_build_status='RUNNING',current_real_build_url='https://github.com/lyiming710-cloud/GodsPVZ-iOS/actions/runs/40263428409');js(folder/'PROGRESS.json',s);manifest(folder)
print(json.dumps(dict(archived=D.name,proposed_positions=3,controlled_differences=864,new_game_changes=0)))
