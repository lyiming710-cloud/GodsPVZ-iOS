# native4 真实门失败核对

Run `36228617935` 第 23 步 Export 失败；24 Audit、27 Xcode upload 跳过。证据工件 `10902486495`，ZIP SHA256 `9df977c1c1df8863da53fff6ccea4cfaa6c35b93a047275ab92c672fe4fdccc6`，893961 字节。已下载并核验。

候选在重导入后的 SHA 为 `11c1a9648ea67cb0ac66b84ddde50cb4ef46d24152f67515a99afb526a2d4b4e`，与本地/云端静态门相同。

## 实际错误与本地对应

| 方法 | IL2CPP 报错 | 本地可见损伤 |
|---|---|---|
| `060006E3 TextLink.ResetLink(int)` | `Cannot get stack type for Color`，日志 16269–16270 行 | `IL_01BA cgt` 比较 I4 与整个 Color；`IL_01D9 cgt` 比较整个 Color 与 float；多组重复；原 local 检查已标出此方法的 21 个存储类型疑点 |
| `06000498 Zombie.ZC_LadderPlaceEnd()` | `Cannot get stack type for Vector3`，日志 16285–16286 行 | `IL_0017 ldfld Vector3 Zombie::rDirection`，经过占位字符串/pop/零指针后，在 `IL_0024 xor` 对整个 Vector3 和 native int 做位运算 |

两者 baseline18e44 与 native4 的 locals、逐条指令、EH 等正文文本比较完全一致；不是六方法改动引入。已有六方法未被本次错误报告点名，但完整真实门没有通过。

初版全量本地扫描已经把 TextLink 列入类型异常清单；Zombie 只标出了占位迹象，未定位运算类型问题。现已补上基本块内操作数类型跟踪，两处均可在本地复现，且扫描覆盖全部 2297 个方法体。保持 77 个正常编译方法体的零错误对照和六个修复方法的零错误检查。新的 245 方法预检清单属于待逐项审计的候选，不能当作已确认的 245 个 IL2CPP 失败或批量改写依据。

## 同时保留的资产异常

日志 6405 行还记录 `TMP_FontAsset.m_AtlasTextures` 的 MissingReferenceException。native3 日志 6308 行已有相同异常，说明不是本轮新增。构建在此异常后继续走到 IL2CPP 并失败；它仍是未解决的独立资产风险，不能因修复 managed IL 就当作消失。

## 当前动作与后续门槛

已保存完整日志、两方法 baseline/candidate IL、一致性结果，并改进全程序集本地扫描。没有生成 native5，没有重跑完整 Unity，没有启动 macOS。

接下来先按本地全量清单审计结构体参与原始比较/位运算的同类损伤，并完成原版 native-backed 规格；不能只消掉日志点名的两个方法后直接再次提交完整导出。修复还需要逐方法字段/参数/调用链及浮点语义证据，不能自动把所有结构体改成标量。
