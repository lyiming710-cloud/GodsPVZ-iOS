# 本地全程序集预检

之前 native3/native4 的类型化 CFG gate 只覆盖当轮重建方法，元数据与非目标差异检查虽然覆盖整程序集，但不验证未修改方法的内部 CIL 合法性。因而“静态 gate 通过”不能理解为全程序集通过；这是此前逐个依赖完整 Unity 门暴露 blocker 的流程缺口。

本轮新增只读工具 `AssemblyPreflight.cs`，实际扫描 baseline18e44 和 native4 两个 DLL：2317 个 MethodDef 中有 2297 个方法体。扫描所有方法体的可达 CFG 栈深、分支合流、下溢、返回栈、MaxStack、相邻生产者与 local 存储的明显类型错配，并另外收集反编译占位和疑似未初始化的枚举器。

本地已重现历史云端两个卡点：

- Plant.SetAnimationState_Planting / 0600039F：IL_0082 栈深 1 与 0 合流，同时 void ret 残留一个值。
- SunManager.SetMaxSunFallTime / 06000267：Map 引用存入 Enumerator 值 local；Enumerator 地址存入 Enumerator 值 local；其他局部数值类型错配。

native4 重建的六个方法均不再触发这些检查。以正常 C# 编译产生的 77 方法体 harness 作对照，未产生错误标记。验证断言见 `verify_scan.py` / `scan-validation.json`。

初版 native4 有 235 个方法被 local 类型规则标记。收到第二次真实门失败后，新增基本块内已知操作数跟踪，捕获整个 Color 参与 `cgt` 与整个 Vector3 参与 `xor`。更新后的清单标记 **245 个方法**，见 `native4-findings.tsv`。这是一份需要逐项核对的预检清单，**不是 245 个已证明的 IL2CPP 失败，也不是 245 个可自动修改的方法**。含占位/枚举器迹象的方法数为 648，与前一数字有重叠，不能相加。不存在上述模式也不代表通过完整 CIL 类型验证或满足原版语义。

此工具没有完整的跨指令类型数据流、接口/泛型约束验证，也没有 Unity stripping 后的程序集或 IL2CPP 内部行为，因此不能取代正式 verifier、native 取证和最终 Unity 导出。它用于把明显的损伤清单前置，避免每次等完整云端导出才发现同类问题。不能据此批量替换 local、删除指令或 ret→throw。

## 本机可用性核对

- Windows .NET Framework C# 编译器与 Mono.Cecil 可用，已运行上述扫描和六方法 CLR 行为测试。
- `unity.exe` 是 Unity 管理 CLI 1.0.0-beta.6；`unity editors --installed --verbose --json` 返回空列表，未发现已安装 Editor。
- `wsl --list --quiet` 返回 exit 1，提示 Linux 的 Windows 子系统未安装。
- PATH 中未发现 dotnet、mono、docker、ilverify、peverify。已缓存的精确 Unity China 2022.3.44f1c1 归档是 Linux 版，不能作为 Windows 可执行程序直接运行。

所以当前环境能立即做程序集级结构扫描、精确引用解析、native/CIL 比较和隔离 CLR 行为验证；完整同版本 IL2CPP 转换还缺可执行的对应工具链。Windows 版精确 Editor 或可用 Linux 环境都需要额外配置，不能把现有本地检查宣称为真实 iOS 导出。

后续先用全程序集清单定位相同损伤模式，再按 native 证据逐组恢复及验证；最后使用对应版本 IL2CPP/Unity 做集成门，不再把完整 Unity Actions 当作查找基本栈错误的唯一手段。
