# Chrome / Codespace 连接诊断

## 重装后复测

随后用户重启桌面应用后再次复测：新的工具临时目录表明运行会话已重建；浏览器枚举识别 Chrome provider 3，但 getState 仍报 nodeRepl.fetch request failed，listTabs 报 Unable to load browser request-header policy。重启未解决页面访问。已准备 check-codespace.sh，只读检查工具、项目版本、Git 状态、资源和 ManagedStripped/il2cppOutput 缓存，不读取凭据或许可证内容。远程环境仍未验证。

用户报告修复后，已成功从 Chrome 读取当前用户标签页列表，精确找到 glowing train 的既有 Codespace 页面。Chrome provider 从 3 变为 2，扩展实例也已更换。浏览器枚举和 openTabs 成功，但 claimTab、getTab 及随后的 tabs.list 在约 30 秒后超时或返回 nodeRepl.fetch request failed；本轮同时出现 Unable to load browser request-header policy。因此只能确认浏览器发现功能恢复，尚未确认页面控制恢复，仍未读取远程终端或修改远程文件。下一步应让桌面应用重新初始化连接与请求策略，而不是重复声称整个连接已经修好。

目标：glowing-train-p7j9gp74q6jwc76v6.github.dev，用户指定 Chrome，一鸣配置文件。

已验证：
- 浏览器 inventory 能识别 Chrome / Edge / IAB；Chrome 和 Edge 读取标签页均报 nodeRepl.fetch request failed，IAB 为空。
- Chrome 正在运行；官方 check-extension-installed.js 确认 Default 配置文件的 hehggadaopoacecdllhhajmbjkdcmajg 已安装并启用，版本 1.26.901.11451_0，无 disableReasons。
- 官方 check-native-host-manifest.js 确认注册表路径、manifest 名称和 allowed origins 全部正确。
- 本机 127.0.0.1:10808 代理端口可连接；这不证明浏览器工具的上游请求正常。
- 重建 cua_repl 会话没有恢复；按官方脚本打开 Default 配置文件新窗口后重试仍然失败。新窗口为 about:blank，未修改已有标签页。
- 现有仓库 Git 凭据访问目标 Codespace REST API 返回 403 Must have admin rights to Repository；没有更改凭据或权限。

结论：故障在浏览器工具通信/初始化链路，尚未读取 Codespace 页面，不足以断定扩展、网络、账户或 Codespace 本身的具体根因。官方排障流程的下一步是由用户在桌面应用插件 UI 重新安装 Browser 插件，再验证 Chrome 连接。未声称修复成功。

限制：未绕过身份或请求策略，未修改 native host，未运行旧 fix-browser.js，未终止 Chrome/Codex，未触碰 Codespace 文件、终端或工作流。

并行项目进度：精确 Unity 2022.3.44f1c1 Linux 归档提取完成。以官方 .NET 6.0.18 Windows runtime 托管原版 managed IL2CPP，--help 已成功；尚未执行完整 C++ 转换。原程序集预检加入精确 Unity resolver 后，待审计标记方法从 245 降为 242；六个已修复方法仍无标记，云端 Color/Vector3 错误仍可定位。native split unwind 提取正在补全，当前在 060003C4 的部分区段遇到不完整线性反汇编并主动中止，未生成新 candidate 或发起新的完整 Unity 门。
