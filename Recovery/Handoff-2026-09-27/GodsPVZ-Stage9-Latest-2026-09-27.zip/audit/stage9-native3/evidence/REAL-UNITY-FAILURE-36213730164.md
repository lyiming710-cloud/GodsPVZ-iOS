# Run 36213730164 失败核对

终态 `failure`；2026-09-26 03:05:41–03:26:26 UTC（北京时间 11:05:41–11:26:26），总计约 20 分 45 秒。

步骤 1–22 全部成功；第 23 步 Export 在 IL2CPP CodeGen 失败；24 Audit 和 27 Xcode 上传跳过；25 归还 Personal seat、26 上传证据成功。没有合格 Xcode 工件，不能进入 macOS IPA。

来源工件 `10896937888` / `Stage9.1-native3-REAL-UNITY-IOS-EVIDENCE`；ZIP SHA256 `f897d0e23ce6a6d40a3bcda37c2493a9c91c8706c7b30b276cc194748cd17ae9`，889146 字节。原始日志见 `real-unity/ios-export.log`。

## 两个实际 IL2CPP blocker

1. `0x0600039F System.Void Plant::SetAnimationState_Planting()`
   - 日志 16242–16255 行：`Invalid global variables count (Parameter 'globalVariables')`。
   - 栈轨迹位于 `WriteAssignGlobalVariables` / `WriteUnconditionalJumpTo`。
   - baseline 与 candidate 的 locals、逐指令、分支、EH、MaxStack 等正文文本比较完全一致。
   - 可直接定位的原有 IL 损伤：`IL_0051 ldarg.0` 预压入接收者；`IL_005B brtrue IL_007A` 的 true 路径保留它；`IL_007B ldarg.0` 再压一个接收者，`IL_007D stfld` 只消费后一个，因此到 `IL_0082 ret` 仍残留一个对象。另一条路径在 `IL_0070 stfld` 后栈空，两条路径栈深不一致。
   - 这解释了分支合流异常的方向；尚未以原版 native 完成修复规格，不能只凭这一点宣称单指令补丁保真。

2. `0x06000267 System.Void SunManager::SetMaxSunFallTime(BoardConfig,Map)`
   - 日志 16256–16271 行：`Cannot get stack type for Enumerator`。
   - baseline 与 candidate 正文文本比较完全一致。
   - 原有 `V22/V23/V24` 均为 `Enumerator<object>`。`IL_002F` 把 Map 存入 V22，`IL_00CA` 把整数算术结果存入 V22，`IL_0182 ldloca V24 → IL_0186 stloc V22` 又把 managed pointer 存入枚举器值 local。
   - foreach 相关调用仍有 `Method not found @1808197F0` / `@180302170` 占位；EH=0；尾部保留非空栈警告字符串。不能将它视为只换 Enumerator 泛型即可修复。

以上两个错误在后续日志重复输出一次，不是四个不同方法。末尾 Unity 汇总 errors=8 包含构建包装层错误，不能等同于八个已定位的受损方法。

## 可以得出的结论

- 云端注入和重导入后的 SHA 均为 `72fe4526fecab9e0e6781cf84d7a5aa3ca32f57973a4be3617708ba4c01343bc`，输入没有漂移。
- Unity、iOS 模块、许可、67/67 包迁移、B001 与软件图形步骤通过，`GL_MAX_TEXTURE_SIZE=16384`。本次失败直接报告在 managed IL 的 CodeGen 阶段。
- 本轮修复的四个目标没有出现在本次 IL2CPP 错误报告中。但完整导出失败，不能宣称四方法已获得完整真实导出/运行时验收，也不能宣称全程序集其余方法都无问题。
- 新报错的两个方法属于本轮四方法范围之外，损伤已经存在于 18e44，未被本轮写入改动。

## 当前边界与续接

已保存新 blocker 的 baseline/candidate IL、逐方法一致性结果和原 PC 方法指针。没有生成新 candidate，没有修改或重跑真实 Unity workflow，没有启动 macOS，没有推进 production。

下一轮若继续修复，应先完成这两个方法的原 PC native CFG、字段/调用映射与 MethodBody 规格，再明确扩展写入范围，并重跑对应静态门；不能靠循环完整 Unity 导出寻找补丁。
