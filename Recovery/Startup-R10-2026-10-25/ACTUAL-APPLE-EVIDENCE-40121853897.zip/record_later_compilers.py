from pathlib import Path,PurePosixPath
import json,tarfile
from archive_support import sha,js,pack,manifest
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';D10=R/'Recovery/Startup-R10-2026-10-25';D11=R/'Recovery/Startup-R11-2026-10-25';A10=W/'r10-compiler-run-40120380134';A11=W/'r11-compiler-run-40121851208';Apple=W/'r10-apple-run-40121853897'
report=json.loads((A11/'startup-r11/STARTUP-R11-COMPILER-REPORT.json').read_bytes());expected='e101c701802969bffe370841abc92cd01ec75592097d60b2b9e3629c5c107637';assert report['candidate_sha256']==expected and report['pass'] and report['conversion']['exit_code']==0
rows=json.loads((A11/'startup-r11/ALL-CPP-RESULTS.json').read_bytes())+json.loads((A11/'startup-r11/ALL-C-RESULTS.json').read_bytes());files={r['file']:r for r in rows};assert len(files)==1030 and all(r['exit_code']==r['error_count']==0 for r in rows)
def tree(path):
    rows={}
    with tarfile.open(path,'r|gz') as t:
        for m in t:
            p=PurePosixPath(m.name);assert '..' not in p.parts and not p.is_absolute()
            if not m.isfile() or not m.name.startswith('il2cppOutput/cpp/'):continue
            b=t.extractfile(m).read();assert m.name not in rows;rows[m.name]=dict(bytes=len(b),sha256=sha(b))
    return rows
old=tree(A10/'startup-r10-generated.tar.gz');new=tree(A11/'startup-r11-generated.tar.gz')
for name,r in files.items():assert new['il2cppOutput/cpp/'+name]==dict(bytes=r['bytes'],sha256=r['sha256'])
different=[n for n in sorted(set(old)|set(new)) if old.get(n)!=new.get(n)];headers=[n for n in new if PurePosixPath(n).suffix not in ('.cpp','.c')]
staged=[];items=[]
with tarfile.open(A11/'startup-r11-evidence.tar.gz','r|gz') as t:
    for m in t:
        if not m.isfile():continue
        assert '..' not in PurePosixPath(m.name).parts and not PurePosixPath(m.name).is_absolute();b=t.extractfile(m).read()
        if m.name.endswith('COHERENT-PLAYER-INPUT-ASSEMBLIES.json'):
            value=json.loads(b);r=next(r for r in value['files'] if r['name']=='GodsPVZRuntime1.dll');staged.append(dict(path=m.name,sha256=r['sha256'],bytes=r['bytes']))
        if m.name.endswith(('.json','.log','.stdout.txt','.stderr.txt')) or '/il2cpp_conversion/' in m.name:items.append((m.name.lstrip('./'),b))
assert any(r['sha256']==expected and r['bytes']==19731968 and '/candidate/' in r['path'] for r in staged)
for p in sorted((A11/'startup-r11').glob('*.json')):items.append(('top-level/'+p.name,p.read_bytes()))
items.append(('record_later_compilers.py',Path(__file__).read_bytes()));pack(D11/'ACTUAL-COMPILER-EVIDENCE-40121851208.zip',items)
result=dict(scope='ACTUAL_EXACT_R11_LINUX_FRESH_IL2CPP_ALL_C_CPP_WITH_FULL_GENERATED_TREE_HASH_READBACK',run_id=40121851208,url='https://github.com/lyiming710-cloud/GodsPVZ-iOS/actions/runs/40121851208',source_commit='2740a9916d7140d3478b1fb0958d6781f886c815',candidate_sha256=expected,pass_=True,cpp=report['cpp'],c=report['c'],conversion=report['conversion'],staged_inputs=staged,sources_rehashed=1030,generated_cpp_tree_files=len(new),generated_non_source_files=len(headers),differences_from_r10=different,full_generated_cpp_tree_byte_identical=not different,apple_new_job=False,unity_or_ipa=False)
js(D11/'ACTUAL-COMPILER-40121851208.json',result)
apple=json.loads((Apple/'APPLE-REPORT.json').read_bytes());arows=json.loads((Apple/'ALL-APPLE-RESULTS.json').read_bytes());base=json.loads((D10/'ACTUAL-COMPILER-40120380134.json').read_bytes());basefiles={PurePosixPath(r['file']).name:r for r in base['source_rows']}
assert apple['candidate_sha256']==base['candidate_sha256'] and apple['source_conversion_run']==40120380134 and apple['attempted']==len(arows)==1030 and apple['failed']==apple['diagnostics']==apple['unparsed_error_lines']==0
assert {r['file'] for r in arows}==set(basefiles)
for r in arows:
    source=basefiles[r['file']];assert r['exit_code']==r['error_count']==0 and r['bytes']==source['bytes'] and r['sha256']==source['sha256'] and not r['unparsed_errors']
flags=json.loads((Apple/'APPLE-CPP-FLAGS.json').read_bytes());assert flags[flags.index('-arch')+1]=='arm64' and flags[flags.index('-isysroot')+1].endswith('/iPhoneOS18.5.sdk') and 'Xcode_16.4.app' in flags[0] and '-fsyntax-only' in flags
damage=json.loads((Apple/'DAMAGED-R4-CONTROL.json').read_bytes());assert damage['error_count']==34 and damage['exit_code']!=0
for file in ['COMPILER-CONTROLS.json','C-COMPILER-CONTROLS.json']:assert all(r['expectation_met'] for r in json.loads((Apple/file).read_bytes()))
pack(D10/'ACTUAL-APPLE-EVIDENCE-40121853897.zip',[(p.relative_to(Apple).as_posix(),p.read_bytes()) for p in sorted(Apple.rglob('*')) if p.is_file()]+[('record_later_compilers.py',Path(__file__).read_bytes())])
av=dict(scope='ACTUAL_R10_ALL_FRESH_GENERATED_CODE_APPLE_ARM64_SYNTAX_ONLY_NOT_LINKED_PLAYER',run_id=40121853897,url='https://github.com/lyiming710-cloud/GodsPVZ-iOS/actions/runs/40121853897',pass_=True,actual=apple,source_records_rechecked=1030,compiler='Xcode 16.4 Apple Clang',sdk='iPhoneOS18.5',architecture='arm64',damaged_control_errors=34,warning_count=sum(r['warning_count'] for r in arows),linked=False,new_unity_export=False,ipa=None)
js(D10/'ACTUAL-APPLE-40121853897.json',av)
equality=dict(scope='FULL_FRESH_CPP_INCLUDE_TREE_COMPARISON_FOR_REUSING_EXACT_COMPILER_SOURCE_EVIDENCE_NOT_A_NEW_APPLE_JOB',r10_candidate_sha256=base['candidate_sha256'],r11_candidate_sha256=expected,r10_linux_run=40120380134,r11_linux_run=40121851208,r10_actual_apple_run=40121853897,files=len(new),non_source_files=len(headers),different_files=different,identical=not different,tree=new,can_reuse_apple_syntax_evidence_for_same_source_input=not different,new_r11_apple_job=False,new_r11_unity_export=False,ipa=None)
js(D11/'APPLE-SOURCE-TREE-COMPARISON.json',equality)
status=json.loads((D10/'CURRENT-RESULT.json').read_bytes());status['r10_apple_cpp']='PASS_ALL_1030_SYNTAX_ONLY_RUN_40121853897';status['r10_apple_linked']=False;js(D10/'CURRENT-RESULT.json',status)
status=json.loads((D11/'CURRENT-RESULT.json').read_bytes());status['r11_il2cpp']='PASS_FRESH_RUN_40121851208';status['r11_linux_all_sources']=dict(cpp=756,c=274,failed=0,rehashed=1030);status['r11_apple_cpp']='SOURCE_IDENTICAL_TO_VERIFIED_R10_APPLE_SCOPE_NO_NEW_JOB' if not different else 'NOT_RUN_R10_TREE_DIFFERS';status['r11_apple_linked']=False;js(D11/'CURRENT-RESULT.json',status)
for d,marker,note in [(D10,'## Actual Apple compiler readback: run 40121853897','All 756 C++/274 C source files passed physical arm64 Apple syntax checks with Xcode16.4/iPhoneOS18.5 and preserved historical runtime headers. All 1,030 actual source sizes/SHA values match the independently verified R10 input. Zero errors and zero unparsed error lines; warnings remain in raw results. Six compiler controls behave correctly and the historical damaged Apple R4 unit still reports 34 errors. No new Unity export, linking, IPA or device acceptance occurred.'),(D11,'## Actual compiler readback: run 40121851208',f'Fresh exact R11 IL2CPP conversion and all 756 C++/274 C Linux checks pass. Every generated source size/SHA and staged R11 DLL identity is independently verified from raw evidence. The entire generated cpp include tree contains {len(new)} files, including {len(headers)} non-source files; {len(different)} files differ from the separately Apple-tested R10 tree. See APPLE-SOURCE-TREE-COMPARISON.json for the exact evidence-reuse boundary. No new R11 Apple job, Unity export, player link, IPA or device acceptance is claimed.')]:
    p=d/'README.md';text=p.read_text('utf-8');assert marker not in text;p.write_bytes((text+'\n'+marker+'\n\n'+note+'\n').encode());manifest(d)
print(json.dumps(dict(r11_cpp=756,r11_c=274,all_sources_rehashed=1030,generated_tree_files=len(new),non_source_files=len(headers),r10_r11_different_files=different,r10_apple_pass=True,r10_apple_warnings=av['warning_count'],ipa=None)))
