"""Read actual GHA evidence and stream-rehash every generated source file."""
from pathlib import Path,PurePosixPath
import hashlib,json,tarfile
from archive_support import sha,js,pack,manifest
W=Path(__file__).resolve().parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113';D=R/'Recovery/Startup-R10-2026-10-25';A=W/'r10-compiler-run-40120380134';Q=A/'startup-r10'
report=json.loads((Q/'STARTUP-R10-COMPILER-REPORT.json').read_bytes());expected='9f030dc1c48e6d77e854979091a223fb636c93b1b528b8c6b9fbb2397a34d72e'
assert report['candidate_sha256']==expected and report['pass'] and report['conversion']['exit_code']==0 and report['cpp']['passed']==report['cpp']['attempted']==756 and report['c']['attempted']==274 and report['cpp']['failed']==report['c']['failed']==0
rows=json.loads((Q/'ALL-CPP-RESULTS.json').read_bytes())+json.loads((Q/'ALL-C-RESULTS.json').read_bytes());files={r['file']:r for r in rows};assert len(files)==1030
found={};nut=None
with tarfile.open(A/'startup-r10-generated.tar.gz','r|gz') as t:
    for m in t:
        assert '..' not in PurePosixPath(m.name).parts and not PurePosixPath(m.name).is_absolute()
        if not m.isfile() or PurePosixPath(m.name).name not in files:continue
        name=PurePosixPath(m.name).name;assert name not in found;b=t.extractfile(m).read();r=files[name];assert len(b)==r['bytes'] and sha(b)==r['sha256'];assert r['exit_code']==0 and r['error_count']==0
        found[name]=dict(file=m.name,bytes=len(b),sha256=sha(b))
        if 'GodsPVZRuntime1' in name and b'Plant_PC_Nutknight_' in b and b'2147483648' in b:nut=dict(file=m.name,sha256=sha(b),contains_native_bound_range_constant=True)
assert set(found)==set(files) and nut is not None
records=[];items=[]
with tarfile.open(A/'startup-r10-evidence.tar.gz','r|gz') as t:
    for m in t:
        if not m.isfile():continue
        assert '..' not in PurePosixPath(m.name).parts and not PurePosixPath(m.name).is_absolute()
        b=t.extractfile(m).read()
        if m.name.endswith('COHERENT-PLAYER-INPUT-ASSEMBLIES.json'):
            value=json.loads(b);row=next(r for r in value['files'] if r['name']=='GodsPVZRuntime1.dll');records.append(dict(path=m.name,sha256=row['sha256'],bytes=row['bytes'],assemblies=value['count']))
        if m.name.endswith(('.json','.log','.stdout.txt','.stderr.txt')) or '/il2cpp_conversion/' in m.name:items.append((m.name.lstrip('./'),b))
assert any(r['sha256']==expected and r['bytes']==19298816 and '/candidate/' in r['path'] for r in records)
assert any(r['sha256']=='ef1992326d1ee494a389bc2c78bdfab131721434c0b08ab5f41dbc3e506c4e48' for r in records)
control=report['damaged_r4_control'];assert sum(r['error_count'] for r in control['units'])==37 and all(r['exit_code']!=0 for r in control['units'])
for p in sorted(Q.glob('*.json')):items.append(('top-level/'+p.name,p.read_bytes()))
items.append(('startup-r10-restore-receipt.json',(A/'startup-r10-restore-receipt.json').read_bytes()));items.append(('record_r10_compiler.py',Path(__file__).read_bytes()))
pack(D/'ACTUAL-COMPILER-EVIDENCE-40120380134.zip',items)
result=dict(scope='ACTUAL_EXACT_R10_LINUX_FRESH_IL2CPP_AND_ALL_GENERATED_C_CPP_ONLY',run_id=40120380134,url='https://github.com/lyiming710-cloud/GodsPVZ-iOS/actions/runs/40120380134',source_commit='de263eb0c2099e3fef8ec9b4c0e26b83641c6092',candidate_sha256=expected,pass_=True,conversion=report['conversion'],cpp=report['cpp'],c=report['c'],damaged_r4_errors=37,compiler_controls=report['compiler_controls'],staged_input_readbacks=records,raw_generated_sources_rehashed=1030,nutknight_range_guard_source=nut,
    downloaded_archives=[dict(file=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in A.glob('*.tar.gz')],source_rows=[found[k] for k in sorted(found)],unity_editor=False,apple_compiler=False,full_game_acceptance=False,ipa=None)
js(D/'ACTUAL-COMPILER-40120380134.json',result)
status=json.loads((D/'CURRENT-RESULT.json').read_bytes());status['r10_il2cpp']='PASS_FRESH_COMPILER_ONLY_RUN_40120380134';status['r10_linux_all_sources']=dict(cpp=756,c=274,failed=0,rehashed=1030);status['r10_apple_cpp']='NOT_RUN';status['status']='NATIVE_CALLER_AND_LINUX_COMPILER_SCOPES_PASS_WIDER_GAME_GATES_HELD';js(D/'CURRENT-RESULT.json',status)
p=D/'README.md';text=p.read_text('utf-8');text=text.replace('No R10 Unity/iOS export, IL2CPP/Apple compilation, new IPA or device acceptance is claimed by this checkpoint.','At initial publication no R10 Unity/iOS export, IL2CPP/Apple compilation, new IPA or device acceptance had run. The subsequent Linux conversion/compiler result is recorded separately below.')
marker='## Actual compiler readback: run 40120380134'
assert marker not in text
text+='\n'+marker+'\n\nExact source commit `de263eb0c2099e3fef8ec9b4c0e26b83641c6092` and exact R10 input completed the license-free Linux diagnostic. Fresh IL2CPP conversion exited zero in 25.63 seconds. All 756 C++ translation units and 274 C files compiled with zero errors, including 172 Generics and 38 GenericMethods units. Downloaded generated tar content was independently streamed and every one of the 1,030 source file sizes and SHA-256 values matched its actual compiler record. The staged GodsPVZRuntime1 input was independently read from raw conversion evidence and matches the R10 candidate. The Nutknight generated source contains the native-bound conversion range constant. The historical R4 negative was converted freshly and still produced 37 errors across two generic units; six C/C++ mode/type controls also behaved as expected. Raw reports/logs and source archive identities are archived. This is Clang18/Linux compiler evidence, with no Unity Editor, Apple/Xcode build, IPA or device acceptance. The wider type/access queues remain held.\n'
p.write_bytes(text.encode());manifest(D);print(json.dumps({k:v for k,v in result.items() if k not in ['source_rows','compiler_controls','downloaded_archives','conversion']}))
