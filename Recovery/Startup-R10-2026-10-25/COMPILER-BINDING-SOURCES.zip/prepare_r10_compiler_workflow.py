"""Bind the existing license-free all-generated compiler census to R10.

No Unity login/import/export or Apple build. The damaged R4 conversion and C/C++
controls remain unchanged. The registered workflow entry is reused explicitly.
"""
from pathlib import Path
import ast,hashlib,json
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';D=R/'Recovery/Startup-R10-2026-10-25';D.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();oldhash='6de4db6c94b80a43876aea060b573ed60c1fa7170cff485103d2c808b94762ae';newhash='9f030dc1c48e6d77e854979091a223fb636c93b1b528b8c6b9fbb2397a34d72e'
src=R/'scripts/actions/check_bulk401_generics.py';original=src.read_bytes();text=original.decode();assert text.count(oldhash)==1
text=text.replace(oldhash,newhash).replace('BULK401_FRESH_LINUX_ALL_GENERATED_SOURCE_COMPILER_ONLY','STARTUP_R10_FRESH_LINUX_ALL_GENERATED_SOURCE_COMPILER_ONLY').replace('BULK401-COMPILER-REPORT.json','STARTUP-R10-COMPILER-REPORT.json').replace('Fixed Bulk401 input','Fixed Startup R10 input')
out=R/'scripts/actions/check_startup_r10_compiler.py';ast.parse(text);out.write_bytes(text.encode())
workflow=R/'.github/workflows/bulk401-generic-compiler-check.yml';old=workflow.read_bytes();archive=D/'PARENT-BULK401-COMPILER-WORKFLOW.yml'
assert not archive.exists(),'Never overwrite the parent workflow snapshot';archive.write_bytes(old)
yaml=old.decode().replace('Bulk401 fresh generic repairs - all generated compiler census','Startup R10 fresh IL2CPP and all generated C C++ compiler census')
yaml=yaml.replace('bulk401-generic-compiler','startup-r10-generic-compiler').replace('Recovery/Bulk401-Generic-Repair-2026-10-24/BULK401-CANDIDATE.zip','Recovery/Startup-R10-2026-10-25/STARTUP-R10-CANDIDATE.zip').replace('BULK401-CANDIDATE.dll','STARTUP-R10.dll').replace(oldhash,newhash)
yaml=yaml.replace('scripts/actions/check_bulk401_generics.py','scripts/actions/check_startup_r10_compiler.py').replace('Fresh R4 negative control and Bulk401 all-source census','Fresh R4 negative control and exact R10 all-source census').replace('.validation/bulk401','.validation/startup-r10').replace('Bulk401-compiler-','Startup-R10-compiler-')
assert newhash in yaml and oldhash not in yaml and 'UNITY_EMAIL' not in yaml and 'secrets.' not in yaml
workflow.write_bytes(yaml.encode())
(D/'COMPILER-DRIVER-DERIVATION.json').write_bytes((json.dumps(dict(scope='INPUT_BINDING_ONLY_TO_EXISTING_LICENSE_FREE_ALL_C_CPP_CENSUS',candidate_sha256=newhash,parent_driver=str(src.relative_to(R)),parent_driver_sha256=sha(original),new_driver=str(out.relative_to(R)),new_driver_sha256=sha(out.read_bytes()),parent_workflow_sha256=sha(old),registered_workflow=str(workflow.relative_to(R)),workflow_sha256=sha(workflow.read_bytes()),algorithm_changed=False,controls_changed=False,unity_license_or_export=False),indent=2)+'\n').encode())
print('R10 compiler-only input binding prepared; no workflow dispatched by this script')
