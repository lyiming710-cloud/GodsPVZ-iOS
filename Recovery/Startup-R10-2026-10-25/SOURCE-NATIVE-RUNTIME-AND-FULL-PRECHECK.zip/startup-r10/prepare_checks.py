"""Bind existing readonly whole-assembly checks to the exact R10 child.

The frozen checker and direct-JIT implementation remain unchanged. These
derived drivers change only the candidate/output binding, recorded below.
"""
from pathlib import Path
import hashlib,json,shutil
Q=Path(__file__).resolve().parent;W=Q.parent;sha=lambda b:hashlib.sha256(b).hexdigest()
old='738ebc37ebdea606011294728ffeaa6a2128d19417905856729efe5947f5577e';new='9f030dc1c48e6d77e854979091a223fb636c93b1b528b8c6b9fbb2397a34d72e';rows=[]
for name in ['run_all_exact_jit.py','full_type_census_r9.py','interface_facts_r9.py','census_lexical_tails.py']:
    p=W/'startup-r9'/name;b=p.read_bytes();text=b.decode();assert old in text
    text=text.replace(old,new).replace("Q=W/'startup-r9'","Q=W/'startup-r10'").replace("Q/'candidate1.dll'","Q/'candidate3.dll'")
    out=Q/name.replace('_r9','_r10');out.write_text(text,encoding='utf-8');rows.append(dict(source=str(p.relative_to(W)),source_sha256=sha(b),output=str(out.relative_to(W)),output_sha256=sha(out.read_bytes()),changes='Only exact candidate hash/path and output directory binding'))
shutil.copy2(W/'startup-r9/ALL-METHODS.json',Q/'ALL-METHODS.json')
(Q/'READONLY-DRIVER-DERIVATION.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
