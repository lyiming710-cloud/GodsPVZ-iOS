from pathlib import Path
import collections,hashlib,itertools,json,random,struct,subprocess,sys
Q=Path(__file__).resolve().parent;ROOT=Q.parents[2];O=Q/'runtime-results';O.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'));import dnfile
digest=lambda b:hashlib.sha256(b).hexdigest();raw=(Q/'candidate1.dll').read_bytes();assert digest(raw)=='3c807e965b7d22afd4ac34ec3e5da93cc8cd8a46075844dfb53d04a9ba1f0b7c'
hp=['00000000','80000000','3EFFFFFF','3F000000','3F7FFFFF','3F800000','3FFFFFFF','40000000','403FFFFF','40400000','40400001','BF800000','C0400000','7F800000','FF800000','7FC00001','FFC00001','00000001','80000001','7F7FFFFF','FF7FFFFF','4EFFFFFF','4F000000','4F000001','CEFFFFFF','CF000000','CF000001']
max_=['40400000','00000000','80000000','3F800000','40C00000','BF800000','7F800000','FF800000','7FC00001','00800000','00000001','7F7FFFFF']
cases=[dict(name='grid-'+str(k),hp=h,max=m,previous=p,mode='none') for k,(h,m,p) in enumerate(itertools.product(hp,max_,[-1,0,1,2,99]))]
modes=['false-result','alternating-result','get-replaces-parameters','get-mutates-health','set-replaces-animation','sprite-get-replaces-animation','change-replaces-animation','change-replaces-sprites']
for h,p,mode in itertools.product(['00000000','3F800000','40000000','40400000'],[-1,0,1,2],modes):cases.append(dict(name='callback-'+str(len(cases)),hp=h,max='40400000',previous=p,mode=mode))
rng=random.Random(10183)
for k in range(256):cases.append(dict(name='random-'+str(k),hp=f'{rng.getrandbits(32):08X}',max=f'{rng.getrandbits(32):08X}',previous=[-1,0,1,2,99][k%5],mode='none'))
(O/'CASES.json').write_bytes((json.dumps(cases,indent=2)+'\n').encode());dot=ROOT/'.local/dotnet10/dotnet.exe';fixture=Q/'runtime/bin/Release/net10.0/Fixture.dll'
def run(label,args):
    p=subprocess.run([str(x) for x in args],capture_output=True,timeout=150);(O/(label+'.stdout.log')).write_bytes(p.stdout);(O/(label+'.stderr.log')).write_bytes(p.stderr)
    if p.returncode:raise RuntimeError(f'{label} exit={p.returncode}: '+p.stderr.decode('utf-8','replace')[:1200])
run('native',[sys.executable,Q/'native_oracle.py',O/'CASES.json',O/'NATIVE.json'])
run('actual-cil',[dot,fixture,Q/'candidate1.dll',O/'CASES.json',O/'ACTUAL-CIL.json'])
a=json.loads((O/'NATIVE.json').read_bytes())['results'];b=json.loads((O/'ACTUAL-CIL.json').read_bytes())['results'];assert len(a)==len(b)==len(cases)
differences=[dict(name=x['name'],native=x,cil=y) for x,y in zip(a,b) if x!=y]
baseline=dict(scope='ACTUAL_PC_CALLER_AND_FLOOR_VS_COMPLETE_CANDIDATE_CIL_CONTROLLED_LIST_SPRITE_CONTRACTS',candidate_sha256=digest(raw),cases=len(cases),pass_=not differences,differences=differences,mode_counts=dict(collections.Counter(c['mode'] for c in cases)),frame_counts=dict(collections.Counter(r['previous'] for r in a)),change_count_distribution=dict(collections.Counter(r['changes'] for r in a)),native_exception_unwind=False,actual_unity_rendering=False)
(O/'BASELINE.json').write_bytes((json.dumps(baseline,indent=2)+'\n').encode());print(json.dumps({**baseline,'differences':differences[:3]},indent=2),flush=True)
if differences:raise SystemExit(2)
pe=dnfile.dnPE(data=raw);start=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[0x383-1].Rva)+12
cil=json.loads((Q/'METHOD-CIL.json').read_text('utf-8-sig'));ins=cil['methods'][0]['instructions'];old=json.loads((Q/'PARENT-METHOD.json').read_bytes())['instructions']
# Derive original/child correspondence by excluding the semantic conversion guard.
floor=next(k for k,i in enumerate(ins) if i['opcode']=='call' and i['operand']['identity']=='System.Double System.Math::Floor(System.Double)');g=floor+2;guard=ins[g:g+14];normal=ins[:g]+ins[g+14:];mapping={x['offset']:y['offset'] for x,y in zip(old,normal)}
mutants={}
def replace(name,offset,expected,value):
    assert raw[start+offset:start+offset+len(expected)]==expected and len(expected)==len(value);v=bytearray(raw);v[start+offset:start+offset+len(value)]=value;mutants[name]=bytes(v)
replace('invalid-conversion-positive-sentinel',guard[12]['offset'],b'\x20'+struct.pack('<i',-2147483648),b'\x20'+struct.pack('<i',2147483647))
replace('integer-clamp-upper-bound-one',mapping[14],b'\x20'+struct.pack('<i',2),b'\x20'+struct.pack('<i',1))
replace('conversion-lower-guard-reversed',guard[3]['offset'],b'\x3a',b'\x39')
set_=next(i for i in ins if i['opcode']=='call' and i['operand']['name']=='set_Item');at=set_['offset'];replace('parameter-write-omitted',at,raw[start+at:start+at+5],bytes.fromhex('2626260000'))
change=next(i for i in ins if i['opcode']=='call' and i['operand']['name']=='ChangeSprite');at=change['offset'];replace('one-sprite-change-omitted',at,raw[start+at:start+at+5],bytes.fromhex('2626261600'))
strings=[i for i in ins if i['opcode']=='ldstr'];body=next(i for i in strings if i['operand']=='KnightWallnut_body');shield=next(i for i in strings if i['operand']=='KnightWallnut_cedun')
replace('body-string-replaced-by-shield',body['offset'],raw[start+body['offset']:start+body['offset']+5],raw[start+shield['offset']:start+shield['offset']+5])
replace('early-return',0,raw[start:start+5],bytes.fromhex('2a00000000'))
# Windows/x64 JIT currently matches CVTTSD2SI even without the portable guard.
# Preserve that non-detection and require the separate guard specification gate.
guard_at=guard[0]['offset'];guard_end=ins[g+14]['offset'];n=guard_end-guard_at
direct=bytes.fromhex('fe0c020069fe0e5600')+b'\0'*(n-9)
replace('portable-guard-omitted',guard_at,raw[start+guard_at:start+guard_end],direct)
controls=[]
for name,data in mutants.items():
    dll=O/(name+'.dll');dll.write_bytes(data);run(name,[dot,fixture,dll,O/'CASES.json',O/(name+'.json')]);rows=json.loads((O/(name+'.json')).read_bytes())['results'];assert len(rows)==len(a)
    detected=sum(x!=y for x,y in zip(a,rows));entry=dict(name=name,mutant_sha256=digest(data),detected_runtime_cases=detected)
    if name=='portable-guard-omitted':
        entry.update(runtime_status='NOT_DETECTED_ON_THIS_X64_JIT',required_independent_gate='EXACT_NATIVE_BOUND_PORTABLE_CONVERSION_GUARD_SPEC',guard_spec_rejected=data[start+guard_at:start+guard_end]!=raw[start+guard_at:start+guard_end]);assert entry['guard_spec_rejected']
    else:assert detected>0,entry
    controls.append(entry)
result=dict(**{k:v for k,v in baseline.items() if k not in ['pass_']},pass_=True,negative_controls=controls,runtime_alone_adequate_for_portability=False,pc_caller_and_floor_executed=True,candidate_has_guarded_only_in_range_conv_i4=True,whole_assembly_pass=False,unity_or_ipa=False)
(O/'RESULT.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({**result,'differences':differences[:3]},indent=2))
