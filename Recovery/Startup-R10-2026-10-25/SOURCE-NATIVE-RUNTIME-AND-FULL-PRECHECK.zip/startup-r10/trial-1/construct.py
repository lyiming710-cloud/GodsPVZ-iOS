"""Recover PC_Nutknight's missing CVTTSD2SI and integer-only clamp dataflow.

The PC instruction returns Int32.MinValue for NaN/Infinity/out-of-range values.
Guard the sole conv.i4 so the ARM64 result does not depend on unspecified CIL
overflow conversion behavior. Preserve every sprite call and all other methods.
"""
from pathlib import Path
import hashlib,importlib.util,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1]
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
spec=importlib.util.spec_from_file_location('writer',W/'startup-r2/construct.py');writer=importlib.util.module_from_spec(spec);spec.loader.exec_module(writer)
sha=lambda b:hashlib.sha256(b).hexdigest()
PARENT='738ebc37ebdea606011294728ffeaa6a2128d19417905856729efe5947f5577e'

def need(ok,message):
    if not ok:raise ValueError(message)

def compressed(n):
    if n<128:return bytes([n])
    if n<16384:return (0x8000|n).to_bytes(2,'big')
    need(n<0x20000000,'Compressed unsigned range');return (0xc0000000|n).to_bytes(4,'big')

def readc(data,p):
    f=data[p]
    if f<128:return f,p+1
    if f<192:return ((f&63)<<8)|data[p+1],p+2
    need(f<224,'Compressed unsigned prefix');return ((f&31)<<24)|int.from_bytes(data[p+1:p+4],'big'),p+4

def type_end(b,p):
    tag=b[p];p+=1
    if tag in (2,3,4,5,6,7,8,9,10,11,12,13,14,24,25,28):return p
    if tag in (0x11,0x12,0x13,0x1e):return readc(b,p)[1]
    if tag in (0x0f,0x10,0x1d,0x45):return type_end(b,p)
    if tag==0x15:
        need(b[p] in (0x11,0x12),'Generic instance owner');_,p=readc(b,p+1);n,p=readc(b,p)
        for _ in range(n):p=type_end(b,p)
        return p
    raise ValueError('Unreviewed local signature type '+hex(tag))

def build(output,report):
    output=Path(output);report=Path(report);need(not output.exists() and not report.exists(),'Fresh outputs')
    before=(W/'startup-r9/candidate1.dll').read_bytes();need(sha(before)==PARENT,'Pinned R9 parent')
    pe=dnfile.dnPE(data=before);row=pe.net.mdtables.MethodDef.rows[0x383-1]
    need(str(row.Name)=='PC_Nutknight','Exact target')
    need(sum(r.Rva==row.Rva for r in pe.net.mdtables.MethodDef.rows)==1,'No body alias')
    old_at=pe.get_offset_from_rva(row.Rva);header=before[old_at:old_at+12];flags,maxstack,size,old_sig=struct.unpack('<HHII',header)
    need(flags>>12==3 and not flags&8,'Fat header without EH sections')
    old=before[old_at+12:old_at+12+size]
    cil=json.loads((Q/'PARENT-METHOD.json').read_bytes());need(cil['token']=='0x06000383' and not cil['handlers'] and len(cil['locals'])==86,'Exact parent CIL')
    signature=pe.net.mdtables.StandAloneSig.rows[(old_sig&0xffffff)-1].Signature.value
    n,p=readc(signature,1);need(signature[0]==7 and n==86,'86 local variables')
    locals_=[]
    for _ in range(n):start=p;p=type_end(signature,p);locals_.append(signature[start:p])
    need(p==len(signature),'Complete local signature')
    for k in [5,6,9]:need(locals_[k]==b'\x0d','Original double placeholder');locals_[k]=b'\x08'
    new_signature=b'\x07'+compressed(n+1)+b''.join(locals_)+b'\x08'
    outcode=bytearray();old_to_new={};branches=[];changed=[];guard_labels={};guard_branches=[]
    def emit(b):outcode.extend(b)
    def ldloc(i):return b'\xfe\x0c'+struct.pack('<H',i)
    def stloc(i):return b'\xfe\x0e'+struct.pack('<H',i)
    def branch(op,label):
        at=len(outcode);emit(bytes([op])+b'\0'*4);guard_branches.append((at,label))
    instructions=cil['instructions']
    for index,i in enumerate(instructions):
        at=i['offset'];end=instructions[index+1]['offset'] if index+1<len(instructions) else size
        old_to_new[at]=len(outcode);raw=old[at:end]
        if isinstance(i['operand'],dict) and 'target' in i['operand']:
            need(i['opcode'] in ('br','brtrue','brfalse') and len(raw)==5,'Only original long scalar branches')
            branches.append((len(outcode),i['operand']['target']))
        if at in (10,48,1899):
            need(raw==ldloc(2),'Original raw floor use');raw=ldloc(86);changed.append(dict(offset=at,operation='ldloc V2 double -> ldloc V86 int32'))
        if at in (387,393,1986,1991):
            need(raw==b'\x6c','Original erroneous conv.r8');raw=b'\x00';changed.append(dict(offset=at,operation='Remove double promotion from integer frame arithmetic'))
        emit(raw)
        if at==1890:
            need(raw==stloc(2),'Floor result store')
            guard_labels['guard']=len(outcode)
            emit(ldloc(2)+b'\x23'+struct.pack('<d',-2147483648.0)+b'\xfe\x05');branch(0x3a,'invalid')
            emit(ldloc(2)+b'\x23'+struct.pack('<d',2147483648.0)+b'\xfe\x04');branch(0x39,'invalid')
            emit(ldloc(2)+b'\x69'+stloc(86));branch(0x38,'done')
            guard_labels['invalid']=len(outcode);emit(b'\x20'+struct.pack('<i',-2147483648)+stloc(86))
            guard_labels['done']=len(outcode)
    old_to_new[size]=len(outcode)
    for at,target in branches:need(target in old_to_new,'Original branch target');struct.pack_into('<i',outcode,at+1,old_to_new[target]-(at+5))
    for at,label in guard_branches:struct.pack_into('<i',outcode,at+1,guard_labels[label]-(at+5))
    need(len(changed)==7 and guard_labels['done']==old_to_new[1894],'Complete numeric dataflow rewrite')
    after=bytearray(before);last=pe.sections[-1]
    need(last.Name.rstrip(b'\0')==b'.n29meta' and last.Characteristics==0x40000040 and last.PointerToRawData+last.SizeOfRawData==len(before),'Append-only readable section without overlay')
    body_at=writer.align(len(after),4);body_rva=last.VirtualAddress+body_at-last.PointerToRawData
    cli=pe.get_offset_from_rva(pe.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress)
    meta_rva,meta_size=struct.unpack_from('<II',before,cli+8);meta_at=pe.get_offset_from_rva(meta_rva)
    root,streams=writer.metadata_root(before[meta_at:meta_at+meta_size]);values={name:b for name,_,b in streams}
    th,rows,tail,counts=writer.tables_decode(values['#~']);need(rows[6][0x383-1][0]==row.Rva,'Raw RVA identity')
    blob=values['#Blob'];blob_index=len(blob);values['#Blob']=blob+compressed(len(new_signature))+new_signature
    rows[17].append([blob_index]);new_sig=0x11000000|len(rows[17]);rows[6][0x383-1][0]=body_rva
    values['#~']=writer.tables_encode(th,rows,tail,counts)
    metadata=bytearray(root)
    for name,h,_ in streams:
        start=writer.align(len(metadata),4);metadata.extend(b'\0'*(start-len(metadata)));struct.pack_into('<II',metadata,h,start,len(values[name]));metadata.extend(values[name])
    new_header=bytearray(header);struct.pack_into('<I',new_header,4,len(outcode));struct.pack_into('<I',new_header,8,new_sig)
    after.extend(b'\0'*(body_at-len(after)));after.extend(new_header);after.extend(outcode)
    new_meta_at=writer.align(len(after),4);after.extend(b'\0'*(new_meta_at-len(after)));after.extend(metadata)
    end=len(after);raw_size=writer.align(end-last.PointerToRawData,pe.OPTIONAL_HEADER.FileAlignment);after.extend(b'\0'*(last.PointerToRawData+raw_size-len(after)))
    sh=last.get_file_offset();opt=pe.OPTIONAL_HEADER.get_file_offset()
    updates={sh+8:end-last.PointerToRawData,sh+16:raw_size,opt+8:pe.OPTIONAL_HEADER.SizeOfInitializedData+raw_size-last.SizeOfRawData,opt+56:writer.align(last.VirtualAddress+end-last.PointerToRawData,pe.OPTIONAL_HEADER.SectionAlignment),opt+64:0,cli+8:last.VirtualAddress+new_meta_at-last.PointerToRawData,cli+12:len(metadata)}
    for p,v in updates.items():struct.pack_into('<I',after,p,v)
    allowed={p+i for p in updates for i in range(4)}
    need(all(a==b or i in allowed for i,(a,b) in enumerate(zip(before,after))),'All old code and metadata bytes retained')
    need(after[old_at:old_at+12+size]==before[old_at:old_at+12+size],'Original code slot preserved')
    output.write_bytes(after)
    result=dict(scope='CONSTRUCTION_ONLY_NATIVE_CVTTSD2SI_I4_CLAMP_RECOVERY_NOT_YET_QUALIFIED',method_token='0x06000383',parent_sha256=sha(before),candidate_sha256=sha(after),bytes=len(after),old_method_rva=hex(row.Rva),new_method_rva=hex(body_rva),old_code_size=size,new_code_size=len(outcode),max_stack=maxstack,
        old_local_token=f'0x{old_sig:08X}',new_local_token=f'0x{new_sig:08X}',old_signature_hex=signature.hex(),new_signature_hex=new_signature.hex(),changed_local_types=[5,6,9],appended_local='V86 System.Int32',numeric_changes=changed,
        old_to_new_offsets={str(k):v for k,v in old_to_new.items()},guard_offsets=guard_labels,code_file_offset=body_at+12,guard='NaN or floor < -2147483648 or floor >= 2147483648 -> Int32.MinValue; otherwise conv.i4',
        old_code_slot_preserved=True,other_methoddefs_unchanged=2316,new_standalonesig_rows=1,new_memberrefs=0,header_updates={str(p):v for p,v in updates.items()},appended_body_offset=body_at,appended_metadata_offset=new_meta_at,appended_metadata_bytes=len(metadata),runtime_equivalence='PENDING',unity_or_ipa='NOT_RUN')
    report.write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in result.items() if k not in ('old_to_new_offsets','numeric_changes','header_updates','old_signature_hex','new_signature_hex')},indent=2))

if __name__=='__main__':
    need(len(sys.argv)==3,'fresh output DLL and construction report');build(*sys.argv[1:])
