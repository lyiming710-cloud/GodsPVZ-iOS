"""Re-execute the previous 12 scoped caller methods on the exact R10 DLL.

Prior fixture/native implementations are not edited. Derived runners only bind
the new candidate/output and retain all physical fault and frozen-width checks.
"""
from pathlib import Path
import concurrent.futures,hashlib,importlib.util,json,struct,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'));import dnfile
candidate=Q/'candidate3.dll';data=candidate.read_bytes();digest=hashlib.sha256(data).hexdigest();assert digest=='9f030dc1c48e6d77e854979091a223fb636c93b1b528b8c6b9fbb2397a34d72e'
dot=ROOT/'.local/dotnet10/dotnet.exe';export=ROOT/'audit/bulk250-r1-evidence-39702928368/bulk250-r1-run/tools_bin/CilExporter/bin/CilExporter.dll';support=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'
def run(label,args):
    p=subprocess.run([str(x) for x in args],capture_output=True,timeout=150);(Q/(label+'.stdout.log')).write_bytes(p.stdout);(Q/(label+'.stderr.log')).write_bytes(p.stderr)
    assert p.returncode==0,(label,p.returncode,p.stderr.decode('utf-8','replace')[-1200:])
# Same immutable width checker and physical I8 sentinel control, bound to R10.
f=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py';assert hashlib.sha256(f.read_bytes()).hexdigest()=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14'
s=importlib.util.spec_from_file_location('unchanged_frozen',f);checker=importlib.util.module_from_spec(s);s.loader.exec_module(checker)
pe=dnfile.dnPE(data=data);bad=bytearray(data);at=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[0x5e7-1].Rva);head=(struct.unpack_from('<H',data,at)[0]>>12)*4
for offset in [279,819]:assert data[at+head+offset]==0x20;bad[at+head+offset:at+head+offset+9]=b'\x21'+struct.pack('<q',4294967295)
o=Q/'buff-runtime-results';o.mkdir(exist_ok=True);mutant=o/'int64-sentinel-restored.dll';mutant.write_bytes(bad)
run('int64-export',[dot,export,mutant,Q/'INT64-CONTROL-CIL.json',support,'0x060005E7']);c=json.loads((Q/'INT64-CONTROL-CIL.json').read_text('utf-8-sig'))
try:failure=checker.verify(c['methods'][0],c['types'])
except Exception as e:failure=dict(status='FAIL',error=str(e))
assert failure['status']!='PASS'
(Q/'INT64-NEGATIVE-WIDTH.json').write_text(json.dumps(dict(scope='UNCHANGED_FROZEN_WIDTH_GATE_ON_PHYSICAL_INT64_MUTANT',baseline_passed=True,mutant_sha256=hashlib.sha256(bad).hexdigest(),checker_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),runtime_did_not_distinguish=True,rejected=True,result=failure),indent=2)+'\n')
derivations=[];commands=[]
for name in ['admin','board','system','buff','events']:
    src=W/'startup-r5'/f'run_{name}_runtime.py';original=src.read_bytes();text=original.decode();assert text.count('Q=Path(__file__).resolve().parent')==1
    text=text.replace('Q=Path(__file__).resolve().parent',"Q=Path(__file__).resolve().parent.parent/'startup-r5'",1)
    old="'738ebc37ebdea606011294728ffeaa6a2128d19417905856729efe5947f5577e'";assert old in text;text=text.replace(old,old+",'"+digest+"'")
    out=Q/f'run_prior_{name}.py';out.write_text(text,encoding='utf-8');derivations.append(dict(source=str(src.relative_to(W)),source_sha256=hashlib.sha256(original).hexdigest(),derived=str(out.relative_to(W)),derived_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),changes='Only source-asset location and exact child input allowlist'))
    commands.append((name,[sys.executable,out,candidate,Q/f'{name}-runtime-results']))
src=W/'startup-r9/run_runtime.py';original=src.read_bytes();text=original.decode()
text=text.replace("Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];O=Q/'runtime-results'","Q=Path(__file__).resolve().parent.parent/'startup-r9';W=Q.parent;ROOT=W.parents[1];O=W/'startup-r10/r9-runtime-results'")
text=text.replace("raw=(Q/'candidate1.dll').read_bytes()","raw=(W/'startup-r10/candidate3.dll').read_bytes()")
text=text.replace('738ebc37ebdea606011294728ffeaa6a2128d19417905856729efe5947f5577e',digest)
text=text.replace("fixture,Q/'candidate1.dll'","fixture,W/'startup-r10/candidate3.dll'")
out=Q/'run_prior_r9.py';out.write_text(text,encoding='utf-8');derivations.append(dict(source=str(src.relative_to(W)),source_sha256=hashlib.sha256(original).hexdigest(),derived=str(out.relative_to(W)),derived_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),changes='Only exact candidate and output binding'))
commands.append(('r9',[sys.executable,out]));(Q/'REGRESSION-DRIVER-DERIVATION.json').write_text(json.dumps(derivations,indent=2)+'\n')
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(lambda item:run('prior-'+item[0],item[1]),commands))
rows=[]
for name in ['admin','board','system','buff','events']:
    r=json.loads((Q/f'{name}-runtime-results/RESULT.json').read_bytes());assert r['pass_'] and r['candidate_sha256']==digest;rows.append(dict(suite=name,cases=r['cases'],result=r))
r9=json.loads((Q/'r9-runtime-results/RESULT.json').read_bytes());assert r9['pass_'] and r9['candidate_sha256']==digest;rows.append(dict(suite='r9',cases=r9['constant_cases']+r9['simple_cases'],result=r9))
assert sum(r['cases'] for r in rows)==3467
new=json.loads((Q/'runtime-results/RESULT.json').read_bytes());assert new['pass_'] and new['candidate_sha256']==digest
report=dict(scope='THIRTEEN_METHODS_IN_SEPARATE_CONTROLLED_CALLER_SCOPES_NOT_FULL_GAME',candidate_sha256=digest,methods=13,prior_cases=3467,new_cases=new['cases'],total_cases=3467+new['cases'],prior_suites=rows,new_suite=new,whole_game_acceptance=False)
(Q/'RUNTIME-SUMMARY.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in report.items() if k not in ['prior_suites','new_suite']},indent=2))
