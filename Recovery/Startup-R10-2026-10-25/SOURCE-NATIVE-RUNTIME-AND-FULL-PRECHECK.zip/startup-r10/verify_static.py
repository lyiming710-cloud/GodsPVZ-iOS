"""Independent raw-file isolation, exported CIL contracts, and frozen type gate.

Does not read the constructor report or its offset map. Fault controls physically
alter unrelated code, old metadata, an integer comparison and the guard bound.
"""
from pathlib import Path
import collections,copy,hashlib,importlib.util,json,struct,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'));import dnfile
sha=lambda b:hashlib.sha256(b).hexdigest()
def module(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
writer=module('metadata_reader',W/'startup-r2/construct.py')
reader=module('raw_body_reader',ROOT/'audit/native111-publication-2026-10-20/repository/scripts/actions/static_gates.py')
checker_path=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py'
assert sha(checker_path.read_bytes())=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14'
checker=module('unchanged_frozen',checker_path)
parent=(W/'startup-r9/candidate1.dll').read_bytes();data=(Q/'candidate3.dll').read_bytes()
assert sha(parent)=='738ebc37ebdea606011294728ffeaa6a2128d19417905856729efe5947f5577e'
assert data==(Q/'candidate4.dll').read_bytes()
pp=dnfile.dnPE(data=parent);cp=dnfile.dnPE(data=data)

def tables(b,p):
    cli=p.get_offset_from_rva(p.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress);rva,size=struct.unpack_from('<II',b,cli+8)
    root,streams=writer.metadata_root(b[p.get_offset_from_rva(rva):p.get_offset_from_rva(rva)+size]);v={n:x for n,_,x in streams}
    _,rows,_,counts=writer.tables_decode(v['#~']);return v,rows,counts

pv,pr,pc=tables(parent,pp);cv,cr,cc=tables(data,cp)
assert set(pr)==set(cr) and set(pv)==set(cv)
for table,rows in pr.items():
    if table==6:
        assert len(rows)==len(cr[6])==2317
        for k,(a,b) in enumerate(zip(rows,cr[6]),1):
            if k==0x383:assert a[1:]==b[1:] and a[0]!=b[0]
            else:assert a==b
    elif table==17:assert cr[table][:-1]==rows and len(cr[table])==len(rows)+1
    else:assert rows==cr[table],table
for name,b in pv.items():
    if name=='#Blob':assert cv[name].startswith(b)
    elif name!='#~':assert cv[name]==b,name

def body(b,p,r):
    if not r.Rva:return b''
    at=p.get_offset_from_rva(r.Rva);size=reader.parse_raw_method_body_span(b,at)[0];return b[at:at+size]
changed=[]
for rid,(a,b) in enumerate(zip(pp.net.mdtables.MethodDef.rows,cp.net.mdtables.MethodDef.rows),1):
    if body(parent,pp,a)!=body(data,cp,b):changed.append(rid)
assert changed==[0x383]
new_at=cp.get_offset_from_rva(cp.net.mdtables.MethodDef.rows[0x383-1].Rva)
assert new_at==len(parent) and cp.sections[-1].Characteristics==pp.sections[-1].Characteristics==0x40000040
assert len(cp.sections)==len(pp.sections)
sh=pp.sections[-1].get_file_offset();opt=pp.OPTIONAL_HEADER.get_file_offset();cli=pp.get_offset_from_rva(pp.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress)
allowed={p+i for p in [sh+8,sh+16,opt+8,opt+56,opt+64,cli+8,cli+12] for i in range(4)}
def boundary(b):
    if len(b)!=len(data) or any(a!=v and i not in allowed for i,(a,v) in enumerate(zip(parent,b))):raise ValueError('Old code/metadata outside bounded PE/CLI header append updates')
boundary(data)
controls=[]
for label,at in [('unrelated-method',pp.get_offset_from_rva(pp.net.mdtables.MethodDef.rows[0x526-1].Rva)+12),('old-target-slot',pp.get_offset_from_rva(pp.net.mdtables.MethodDef.rows[0x383-1].Rva)+12),('old-metadata',pp.get_offset_from_rva(pp.net.struct.MetaDataRva))]:
    m=bytearray(data);m[at]^=1
    try:boundary(m)
    except ValueError:controls.append(dict(name=label,rejected=True));continue
    raise AssertionError('False isolation accept')

old=json.loads((Q/'PARENT-METHOD.json').read_bytes());cil=json.loads((Q/'METHOD-CIL.json').read_text('utf-8-sig'));new=cil['methods'][0]
assert new['token']==old['token']=='0x06000383' and new['maxStack']==old['maxStack']==3 and new['handlers']==old['handlers']==[]
expected_locals=list(old['locals'])
for k in [5,6,9]:assert expected_locals[k]=='System.Double';expected_locals[k]='System.Int32'
assert new['locals']==expected_locals+['System.Int32']
a=old['instructions'];b=new['instructions'];floor=next(k for k,i in enumerate(b) if i['opcode']=='call' and i['operand']['identity']=='System.Double System.Math::Floor(System.Double)')
assert b[floor+1]['opcode']=='stloc' and b[floor+1]['operand']['index']==2
start=floor+2;guard=b[start:start+14]
assert [i['opcode'] for i in guard]==['ldloc','ldc.r8','clt.un','brtrue','ldloc','ldc.r8','clt','brfalse','ldloc','conv.i4','stloc','br','ldc.i4','stloc']
assert [guard[k]['operand']['index'] for k in [0,4,8]]==[2,2,2]
assert guard[1]['operand']==-2147483648.0 and guard[5]['operand']==2147483648.0
assert guard[3]['operand']['target']==guard[7]['operand']['target']==guard[12]['offset']
assert guard[11]['operand']['target']==b[start+14]['offset']
assert guard[12]['operand']==-2147483648 and guard[10]['operand']['index']==guard[13]['operand']['index']==86
without_guard=b[:start]+b[start+14:];without_caches=[];aliases={};captures=0;k=0
animation='System.Collections.Generic.List`1<UnityEngine.GameObject> Plant::animationSprites'
resources='System.Collections.Generic.List`1<UnityEngine.Sprite> ResourceManager::plantSprites'
while k<len(without_guard):
    seq=without_guard[k:k+4]
    if len(seq)==4 and [i['opcode'] for i in seq]==['ldarg.0','ldfld','stloc','ldsfld'] and seq[1]['operand']['identity']==animation:
        assert seq[2]['operand']['index']==13 and seq[3]['operand']['identity']==resources
        aliases[seq[0]['offset']]=seq[3]['offset'];captures+=1;k+=3
    without_caches.append(without_guard[k]);k+=1
assert captures==21
normal=[];late_reads=0;dispatch=0;k=0
while k<len(without_caches):
    seq=without_caches[k:k+6];i=without_caches[k]
    if len(seq)==6 and seq[0]['opcode']=='ldloc' and seq[0]['operand']['index']==13 and all(x['opcode']=='nop' for x in seq[1:]):
        normal.extend([dict(offset=seq[0]['offset'],opcode='ldarg.0',operand=None),dict(offset=seq[1]['offset'],opcode='ldfld',operand=dict(owner='Plant',type='System.Collections.Generic.List`1<UnityEngine.GameObject>',identity=animation))]);late_reads+=1;k+=6;continue
    if k+2<len(without_caches) and i['opcode']=='ldloc' and i['operand']['index']==9 and [x['opcode'] for x in without_caches[k+1:k+3]]==['ldc.i4.0','ceq']:
        normal.append(dict(offset=i['offset'],opcode='ldloc',operand=dict(index=35)));dispatch+=1;k+=3;continue
    normal.append(i);k+=1
assert len(normal)==len(a) and late_reads==21 and dispatch==1
old_ord={i['offset']:k for k,i in enumerate(a)};new_ord={i['offset']:k for k,i in enumerate(normal)}
for at,to in aliases.items():new_ord[at]=new_ord[to]
changed_loads=0;changed_promotions=0
for x,y in zip(a,normal):
    op=x['opcode'];operand=x['operand']
    if op=='ldloc' and operand['index']==2:assert y['opcode']=='ldloc' and y['operand']['index']==86;changed_loads+=1
    elif op=='conv.r8':assert y['opcode']=='nop' and y['operand'] is None;changed_promotions+=1
    elif isinstance(operand,dict) and 'target' in operand:assert y['opcode']==op and old_ord[operand['target']]==new_ord[y['operand']['target']]
    else:assert y['opcode']==op and y['operand']==operand,(x,y)
assert changed_loads==3 and changed_promotions==4
r=checker.verify(new,cil['types']);assert r['status']=='PASS',r
local_sig=struct.unpack_from('<I',data,new_at+8)[0];assert local_sig==0x11000000|len(cr[17])
assert cp.net.mdtables.StandAloneSig.rows[-1].Signature.value[0]==7
result=dict(scope='INDEPENDENT_RAW_ALL_METHODS_AND_CIL_CONTRACTS_PLUS_UNCHANGED_FROZEN_GATE',candidate_sha256=sha(data),parent_sha256=sha(parent),pass_=True,changed_methoddefs=1,unchanged_methoddefs=2316,
    old_code_and_metadata_prefix_preserved=True,appended_standalonesig=1,changed_local_types=[5,6,9],new_int32_local=86,existing_call_and_branch_order_preserved_except_native_frame_dispatch=True,animation_capture_moved_before_sprite_callee=21,guard_instructions=14,
    comparisons_and_conversions_verified=True,computed_type_result=r,negative_isolation_controls=controls,all_assembly_pass=False,runtime_equivalence='PENDING')
(Q/'ISOLATION-AND-CIL.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in result.items() if k!='computed_type_result'},indent=2))
