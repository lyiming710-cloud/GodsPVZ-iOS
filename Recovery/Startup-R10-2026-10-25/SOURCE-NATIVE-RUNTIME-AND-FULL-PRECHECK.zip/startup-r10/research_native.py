from pathlib import Path
import collections,hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import pefile
from capstone import *
from capstone.x86_const import X86_OP_IMM,X86_OP_MEM,X86_REG_RIP
b=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/GameAssembly.dll').read_bytes();assert hashlib.sha256(b).hexdigest()=='9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d'
p=pefile.PE(data=b);base=p.OPTIONAL_HEADER.ImageBase;d=Cs(CS_ARCH_X86,CS_MODE_64);d.detail=True
cfg=json.loads((W/'next-runtime-native/0383.normal-cfg.json').read_bytes());globs={}
metadata=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/global-metadata.dat').read_bytes();assert hashlib.sha256(metadata).hexdigest()=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9'
literals,_,data=struct.unpack_from('<3I',metadata,8)
for i in cfg['instructions']:
    ins=next(d.disasm(bytes.fromhex(i['bytes']),int(i['va'],16)))
    for op in ins.operands:
        if op.type==X86_OP_MEM and op.mem.base==X86_REG_RIP and ins.mnemonic in ('lea','mov'):
            at=ins.address+ins.size+op.mem.disp;encoded=int.from_bytes(p.get_data(at-base,8),'little');kind=encoded>>29;index=(encoded&0x1fffffff)>>1
            if kind in range(1,8) and encoded<=0xffffffff:
                row=dict(slot=hex(at),encoded=hex(encoded),kind=kind,index=index)
                if kind==5:
                    length,start=struct.unpack_from('<II',metadata,literals+index*8);row['string']=metadata[data+start:data+start+length].decode()
                globs[at]=row
floor=[];queue=[0x1802cc8d0];seen=set()
while queue:
    at=queue.pop()
    while at not in seen:
        seen.add(at);assert len(seen)<500
        i=next(d.disasm(p.get_data(at-base,15),at));floor.append(dict(va=hex(i.address),op=i.mnemonic,operands=i.op_str,bytes=i.bytes.hex()))
        if i.group(CS_GRP_RET) or i.mnemonic in ('int3','ud2'):break
        if i.group(CS_GRP_JUMP):
            assert i.operands[0].type==X86_OP_IMM,'Indirect floor branch needs explicit analysis';queue.append(i.operands[0].imm)
            if i.mnemonic=='jmp':break
        at+=i.size
floor.sort(key=lambda x:int(x['va'],16));(Q/'NATIVE-FLOOR-CFG.json').write_text(json.dumps(dict(entry='0x1802cc8d0',instructions=floor),indent=2)+'\n')
(Q/'NATIVE-GLOBALS.json').write_text(json.dumps(list(globs.values()),indent=2)+'\n')
print(json.dumps(dict(globals=list(globs.values()),floor_instructions=len(floor),floor_calls=[x for x in floor if x['op']=='call'],floor_first=floor[:8]),indent=2))
