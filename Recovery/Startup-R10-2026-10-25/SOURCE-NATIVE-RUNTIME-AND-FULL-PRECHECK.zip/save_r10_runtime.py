from pathlib import Path
import collections,json,re
from archive_support import sha,js,pack,variants,manifest
W=Path(__file__).resolve().parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113';Q=W/'startup-r10';D=R/'Recovery/Startup-R10-2026-10-25';D.mkdir(exist_ok=True)
data=(Q/'candidate3.dll').read_bytes();digest=sha(data);assert digest=='9f030dc1c48e6d77e854979091a223fb636c93b1b528b8c6b9fbb2397a34d72e' and data==(Q/'candidate4.dll').read_bytes()
iso=json.loads((Q/'ISOLATION-AND-CIL.json').read_bytes());runtime=json.loads((Q/'RUNTIME-SUMMARY.json').read_bytes());jit=json.loads((Q/'all-exact-jit-results/RESULT.json').read_bytes())
assert iso['pass_'] and iso['unchanged_methoddefs']==2316 and runtime['total_cases']==5583 and jit['counts']==dict(JIT_PREPARED_NO_EXECUTION=2247,UNSUPPORTED=50)
types=json.loads((Q/'FROZEN-WITH-INTERFACE-FACTS.json').read_bytes());members=json.loads((Q/'MEMBER-ACCESS-ALL-2297.json').read_bytes());bad_members=[r for r in members['members'] if not r['allowed']];bad_types=[r for r in types['results'] if r['status']!='PASS']
categories=collections.Counter()
for row in bad_types:
    e=row['error'];row['triage']='CHECKER_UNSUPPORTED_OPERATION_REQUIRES_SEPARATE_EVIDENCE' if 'unsupported' in e else 'TYPE_OR_METADATA_CONFLICT_REQUIRES_NATIVE_SPECIFICATION';categories[row['triage']]+=1
js(Q/'REMAINING-QUEUES.json',dict(scope='OVERLAPPING_GATE_QUEUES_NOT_TOTAL_GAME_BUG_COUNT',candidate_sha256=digest,frozen_fail_or_unsupported=len(bad_types),categories=dict(categories),member_rejected_sites=len(bad_members),member_rejected_methods=len({r['token'] for r in bad_members}),unique_rejected_members=len({r['member'] for r in bad_members}),type_and_access_methods_union=len({r['token'] for r in bad_types+bad_members}),open_generic_jit_unsupported=50,
    type_rows=bad_types,access_rows=bad_members,unsupported_does_not_imply_correct_body=True,all_assembly_pass=False))
js(Q/'PHYSICAL-VARIANTS.json',dict(scope='EXACT_RECONSTRUCTION_OF_EXECUTED_CURRENT_FAULT_VARIANTS',variants=variants(Q,data)))
(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text whitespace=cr-at-eol\n*.md -text\n*.zip -text\n*.yml -text\n')
for name in ['CONSTRUCTION-3.json','CONSTRUCTION-4.json','ISOLATION-AND-CIL.json','RUNTIME-SUMMARY.json','REMAINING-QUEUES.json','INT64-NEGATIVE-WIDTH.json','LEXICAL-TAIL-CENSUS.json']:(D/name).write_bytes((Q/name).read_bytes())
(D/'EXACT-JIT-ALL-2297.json').write_bytes((Q/'all-exact-jit-results/RESULT.json').read_bytes())
pack(D/'STARTUP-R10-CANDIDATE.zip',[('STARTUP-R10.dll',data)])
trial=(Q/'candidate1.dll').read_bytes();assert sha(trial)=='3c807e965b7d22afd4ac34ec3e5da93cc8cd8a46075844dfb53d04a9ba1f0b7c'
pack(D/'REJECTED-TRIAL-1-CANDIDATE.zip',[('UNQUALIFIED-TRIAL-1.dll',trial),('STATUS.json',json.dumps(dict(status='REJECTED_BEHAVIORAL_DIFFERENCES',differences=65,candidate_sha256=sha(trial),not_a_parent_or_promoted_candidate=True)).encode())])
items=[]
def addtree(folder,select=None):
    for p in sorted(folder.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(folder)
        if any(x in ['obj','__pycache__'] for x in rel.parts):continue
        if p.suffix=='.dll' and 'bin' not in rel.parts:continue
        if p.suffix=='.exe' or p.name=='Mono.Cecil.dll':continue
        if select and not select(p,rel):continue
        items.append((p.relative_to(W).as_posix(),p.read_bytes()))
addtree(Q)
addtree(W/'startup-r5',lambda p,rel:not any(x.endswith('-runtime-results') for x in rel.parts) and p.suffix in ['.py','.cs','.csproj','.dll','.json','.pdb'])
addtree(W/'startup-r9/runtime')
items.append(('startup-r9/native_oracle.py',(W/'startup-r9/native_oracle.py').read_bytes()))
for folder in ['remaining-native','administrator-next-native','next-runtime-native']:
    for p in sorted((W/folder).glob('*')):
        if p.is_file() and ('.normal-cfg.' in p.name or p.name=='FMOD-HELPER-CFG.json'):items.append((p.relative_to(W).as_posix(),p.read_bytes()))
for p in [W/'archive_support.py',W/'startup-r2/construct.py',Path(__file__),W/'startup-r5/runtime-admin/bin/Release/net10.0/Mono.Cecil.dll']:items.append((p.relative_to(W).as_posix(),p.read_bytes()))
for p in [ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py',ROOT/'audit/bulk388-qualification-2026-10-23/width-check/width_fixtures.py',ROOT/'audit/native111-publication-2026-10-20/repository/scripts/actions/static_gates.py']:items.append(('required-tools/'+p.name,p.read_bytes()))
pack(D/'SOURCE-NATIVE-RUNTIME-AND-FULL-PRECHECK.zip',items)
status=dict(status='ONE_NATIVE_BACKED_METHOD_RECOVERED_FULL_PIPELINE_HELD',candidate_sha256=digest,parent_sha256='738ebc37ebdea606011294728ffeaa6a2128d19417905856729efe5947f5577e',bytes=len(data),direct_method_targets=1,untouched_methoddefs=2316,method='0x06000383 Plant.PC_Nutknight',new_runtime_cases=2116,prior_runtime_cases=3467,total_scoped_runtime_cases=5583,scoped_caller_methods=13,
    whole_assembly=dict(methods=2297,jit=jit['counts'],jit_rejected=0,raw_frozen=dict(pass_=2138,fail_or_unsupported=159),interface_fact_frozen=dict(pass_=2166,fail_or_unsupported=131),member_rejected_sites=216,member_rejected_methods=111,member_unresolved=0,unterminated_lexical_tails=0,all_pass=False),
    historical_failed_trial=dict(candidate_sha256=sha(trial),differences=65,preserved=True),r10_il2cpp='NOT_RUN',r10_unity='NOT_RUN',r10_apple_cpp='NOT_RUN',ipa=None,ipad_device_acceptance=False,separate_parent_editor_result='R8 run 40115001552 scoped PASS; does not qualify R10')
js(D/'CURRENT-RESULT.json',status)
(D/'README.md').write_bytes('''# Startup R10: PC_Nutknight integer conversion, state dispatch and sprite receiver order

Exact candidate `9f030dc1c48e6d77e854979091a223fb636c93b1b528b8c6b9fbb2397a34d72e` (19,298,816 bytes), derived directly from R9 `738ebc37…f5577e`. Only `0x06000383 Plant.PC_Nutknight()` changes. Independent raw checks compare all 2,317 MethodDefs: the other 2,316 body/header/RVA identities remain unchanged. Original target code slot and every old code/metadata byte remain intact; bounded PE/CLI headers point to an appended readable method body and metadata root. One private StandAloneSig is appended, V5/V6/V9 become Int32, V86 is a new Int32; all other local encodings and old metadata rows/heaps are preserved except this target's new RVA. No field visibility or new MemberRef changes.

## Original source and behavior

The original PC caller at `0x180352B10` contains 592 normal-CFG instructions, including the original 49-instruction Math.Floor helper at `0x1802CC8D0`. It computes health / (maxHealth / 3), floors the float ratio as double, converts with CVTTSD2SI, clamps the resulting signed integer to 0..2, derives frame 2-clamped, compares/writes parameter_ints[0], then changes eight named body/shield/cape/helmet sprites. Invalid PC conversion returns Int32.MinValue. The CIL now checks ordered range [-2147483648,2147483648) before conv.i4 and explicitly supplies the PC invalid result for NaN/Infinity/out-of-range values. This avoids relying on unspecified invalid conversion behavior on ARM64.

Actual execution exposed two additional defects beyond the type error. A stale clamp boolean suppressed all middle-state sprite calls. The method also loaded animationSprites after the sprite getter, where native captures it before the callee. The final candidate restores frameMinusOne == 0 dispatch and captures animationSprites in existing V13 before each of 21 direct sprite reads; the remaining shared getter already had the correct capture. Original method/field/string operands, sprite indices and existing control-flow order remain, except those specified corrections and inserted conversion guard.

## Failures retained and actual tests

The initial numeric-only candidate `3c807e96…a1f0b7c` passed type/JIT checks but failed 65 of 2,004 actual native/CIL comparisons. That unqualified candidate, its source, complete differences and reports are retained. It was not used as the final parent. A first negative changed only the >2 comparison to >1 and produced no differences: this is behavior preserving because integer 2 still yields clamp 2. The ineffective control and explanation are retained; the corrected negative changes the saturation value itself. No aggregate pass was issued from the incomplete control run.

Final actual-CIL execution and original PC caller/helper execution match all 2,116 cases: all three states, same-state early exit, signed zero, subnormals, finite extremes, boundary neighbors, NaN/Infinity, 256 seeded bit-pattern pairs and controlled callbacks that replace parameters, animation lists or sprite lists at each of eight sprite-read positions. Lists, allocations, metadata initialization and ChangeSprite are explicit controlled contracts. Native exception unwind, actual List/ChangeSprite implementations, Unity rendering, NaN payload identity, audio and full gameplay remain outside scope. Original caller and Floor bytes are checked again after hook installation.

Nine physical fault variants are detected by execution: wrong invalid sentinel (1,015), wrong clamp saturation (149), reversed lower guard (324), stale middle-state dispatch (77), omitted parameter write (1,681), omitted sprite call (1,431), wrong body-name string (1,681), early return (2,116), and omitted portable conversion guard (392). The last is also rejected by a separate instruction-level guard specification. These numbers are differing test cases, not game bug counts. Actual ARM64 execution remains untested.

The previous 12 method scopes are rerun on exact R10: all 3,467 records still match. Total separate controlled caller evidence is 5,583 cases across 13 methods. The prior Int64 width control remains undetectable to permissive CLR execution and is rejected by the unchanged frozen width gate; its original non-detection is retained.

## Full gates and next work

A fresh actual-DLL CLR JIT precheck of all 2,297 bodies reports 2,247 prepared, zero rejected and 50 unsupported open generics. This check executes no game method. The frozen whole-assembly type checker still reports 159 raw failures or unsupported cases, reduced to 131 after exact nongeneric InterfaceImpl facts. The separate unchanged access auditor exits 2 and rejects 216 sites across 111 methods, with zero unresolved members. Unterminated lexical tails: zero. These overlapping queues prevent whole-game acceptance. Read REMAINING-QUEUES.json for exact records rather than adding counts as independent bugs.

No R10 Unity/iOS export, IL2CPP/Apple compilation, new IPA or device acceptance is claimed by this checkpoint. Parent R8's successful real Editor/MainMenu/shader run 40115001552 remains separately bound to R8. The next license-free compiler census may diagnose exact R10 conversion and every generated C/C++ unit before another licensed export.

## Reproduction and archive requirements

The source/evidence archive includes actual CIL exports, complete per-method JIT/type/access reports, original caller/helper bytes and metadata bindings, construction/static/runtime drivers, prior concrete fixture/native sources and binaries, failed trials and reconstructable fault deltas. Native oracles require Windows x64 and the original PC inputs (GameAssembly SHA `9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d`, metadata SHA `ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9`). Existing authentic support assemblies, .NET 10, dnfile/pefile/Capstone, the pinned Cecil exporter/access checker and Mono.Cecil paths remain required; this archive does not bundle a full SDK or Unity. Respect the recorded relative paths when restoring. Every ZIP member and top-level file has its own size/SHA manifest.
'''.encode())
manifest(D);print(json.dumps(dict(checkpoint=str(D),candidate_sha256=digest,scoped_cases=5583,archives={p.name:p.stat().st_size for p in D.glob('*.zip')})))
