"""Read original definitions and native bodies without constructing a candidate."""
from pathlib import Path
import hashlib,json,sys,zipfile
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1]
sys.path.insert(0,str(W/'startup-r28-plant-attack-chain'))
import source_common as pc
candidate=W/'startup-r28-plant-attack-chain/authored2.dll';assert pc.sha(candidate.read_bytes())=='9081408a2226a79e23991355108540a0260a3966a500cecf4524f3cba9dfb364'
current=json.loads((W/'startup-r28-plant-attack-chain/shared-authored2/ALL-CIL.json').read_bytes());methods={m['token']:m for m in current['methods']}
selected=[0x357,0x37f,0x380,0x381,0x394,0x3af,0x3b0,0x3b1,0x3b7,0x3b8,0x48b,0x48c,0x497,0x49f,0x4a0,0x4a1,0x4a4,0x4a5,0x4a6,0x4ad,0x500,0x503,0x50a,0x50d]
out=Q/'sources';out.mkdir(exist_ok=True);rows=[]
for rid in selected:
 token=pc.tok(rid);method=methods[token];native=pc.native(token)
 (out/(token+'-native.json')).write_bytes((json.dumps(native,indent=2)+'\n').encode())
 (out/(token+'-native.txt')).write_bytes(('\n'.join(i['va']+' '+i['op']+' '+i['operands']for i in native['instructions'])+'\n').encode())
 (out/(token+'-cil.json')).write_bytes((json.dumps(method,indent=2)+'\n').encode())
 text=[method['name'],'locals='+json.dumps(method['locals'])]
 for i in method['instructions']:
  op=i['operand'];value=op.get('identity',json.dumps(op))if isinstance(op,dict)else str(op)
  text.append(f"IL_{i['offset']:04X} {i['opcode']} {value}")
 (out/(token+'-cil.txt')).write_bytes(('\n'.join(text)+'\n').encode())
 rows.append(dict(token=token,name=method['name'],cil_instructions=len(method['instructions']),native_instructions=len(native['instructions']),native_entry=native['entry'],indirect_jumps=native['indirect_jumps'],external_boundaries=native['outside_boundaries'],test_status='NOT_EXECUTED'))
zip_path=ROOT/'GodsPVZ_1.0.2.zip';assert pc.sha(zip_path.read_bytes())=='2f08b4e2243e2bd296f3db694b4a2c9656252d76202c80167bdf3340b9f65b48'
definitions=Q/'original-definitions';definitions.mkdir(exist_ok=True);config=[]
with zipfile.ZipFile(zip_path)as z:
 for ending,expected in [('GameAssembly.dll','9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d'),('global-metadata.dat','ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9')]:
  matches=[n for n in z.namelist()if n.endswith('/'+ending)];assert len(matches)==1 and pc.sha(z.read(matches[0]))==expected
 for name in z.namelist():
  if not name.endswith('.json')or'/StreamingAssets/jsons/'not in name:continue
  if not any(x in name for x in ['PlantsInitialValue.json','ZombiesInitialValue.json','/PlantData/Skills/','/ZombieData/']):continue
  rel=name.split('/StreamingAssets/jsons/',1)[1];data=z.read(name);p=definitions/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
  config.append(dict(path=rel,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
inventory=[dict(token=m['token'],name=m['name'],cil_instructions=len(m['instructions']),test_status='NOT_EXECUTED')for m in current['methods']if(m['owner']=='Plant'and any(x in m['name']for x in ['::PC_','::ST_','::Skill','::TryUseSkills','::Trigger_Skill']))or(m['owner']=='Zombie'and'::ZC_'in m['name'])or m['owner']=='SkillManager']
result=dict(scope='ORIGINAL_CONFIG_AND_NATIVE_SOURCE_INVENTORY_NOT_TEST_PASS',candidate_sha256=pc.sha(candidate.read_bytes()),original_pc_zip_sha256=pc.sha(zip_path.read_bytes()),input_identity_note='Prior 6e7241 is a tool_archive_sha256 in WORKFLOW-CONTEXT-VALIDATION, not the PC ZIP. PC native and metadata members independently rehashed.',selected_native_sources=rows,all_special_methods=inventory,configuration_files=config)
(Q/'SOURCE-INVENTORY.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(dict(selected=rows,all_special_methods=len(inventory),configuration_files=len(config)),ensure_ascii=True))

# Separate construction/setup signatures for a real-Editor controlled fixture.
setup=[m for m in current['methods']if(m['owner']=='Plant'and any(x in m['name']for x in ['::SettParameter','::Initial','::TryPlanting','::Planted']))or(m['owner']in ['PlantSave','ZombieManager','Zombie']and any(x in m['name']for x in ['::PlaceNewZombie','::CreateNewZombie','::.ctor(System.Int32)','::Place(','::Initial']))]
(Q/'SETUP-METHODS.json').write_bytes((json.dumps(setup,indent=2)+'\n').encode())
print(json.dumps([dict(token=m['token'],name=m['name'],instructions=len(m['instructions']))for m in setup],ensure_ascii=True))
