"""Actual byte mutations, no changes to candidate or frozen type checker."""
from pathlib import Path
import hashlib,importlib.util,json,struct,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1]
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'));import dnfile
data=(W/'startup-r28-plant-attack-chain/authored2.dll').read_bytes()
assert hashlib.sha256(data).hexdigest()=='9081408a2226a79e23991355108540a0260a3966a500cecf4524f3cba9dfb364'
pe=dnfile.dnPE(data=data);cases=json.loads((Q/'CASES.json').read_bytes());good={x['name']:x for x in json.loads((Q/'ACTUAL-CIL.json').read_bytes())['results']}
out=Q/'physical-controls';out.mkdir(exist_ok=True);rows=[]
checker=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py'
assert hashlib.sha256(checker.read_bytes()).hexdigest()=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14'
spec=importlib.util.spec_from_file_location('frozen_types',checker);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
dotnet=ROOT/'.local/dotnet10/dotnet.exe';exporter=ROOT/'audit/bulk250-r1-evidence-39702928368/bulk250-r1-run/tools_bin/CilExporter/bin/CilExporter.dll';support=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'

def mutate(name,rid,opcode,after,operand=None,index=0):
 token=f'0x{0x6000000|rid:08X}';m=json.loads((Q/'sources'/f'{token}-cil.json').read_bytes());selected=[i for i in m['instructions']if i['opcode']==opcode and(operand is None or i['operand']==operand)];i=selected[index]
 mr=pe.net.mdtables.MethodDef.rows[rid-1];start=pe.get_offset_from_rva(mr.Rva);head=data[start];header=1 if head&3==2 else (struct.unpack_from('<H',data,start)[0]>>12)*4
 offset=start+header+i['offset']
 # Operand-only float changes keep the original opcode in place.
 if opcode=='ldc.r4':offset+=1;after=struct.pack('<f',after)
 before=data[offset:offset+len(after)]
 variant=bytearray(data);variant[offset:offset+len(after)]=after
 assert len(variant)==len(data) and before!=after
 path=out/(name+'.dll');path.write_bytes(variant)
 subset=[c for c in cases if c['token']==token]
 # Keep all finite synthetic states plus a bounded original-default sample.
 subset=[c for c in subset if isinstance(c['origin'],str)]+[c for c in subset if isinstance(c['origin'],dict)][:12]
 casepath=out/(name+'.cases.json');casepath.write_text(json.dumps(subset)+'\n',encoding='utf-8');result=out/(name+'.result.json')
 p=subprocess.run([str(dotnet),str(Q/'runtime/bin/Release/net10.0/Fixture.dll'),str(path),str(casepath),str(result)],capture_output=True,timeout=35)
 (out/(name+'.stdout.log')).write_bytes(p.stdout);(out/(name+'.stderr.log')).write_bytes(p.stderr);assert p.returncode==0,(name,p.stderr[-1000:])
 observed=json.loads(result.read_bytes());assert observed['candidate_sha256']==hashlib.sha256(variant).hexdigest()
 changed=[];errors=[]
 for row in observed['results']:
  before_row=good[row['name']]
  if row['error'] or before_row['error']:errors.append(row['name']);continue
  if row['state']!=before_row['state'] or row['returned']!=before_row['returned']:changed.append(row['name'])
 assert changed and not errors,(name,changed,errors)
 export=out/(name+'.cil.json');p=subprocess.run([str(dotnet),str(exporter),str(path),str(export),str(support),token],capture_output=True,timeout=35)
 (out/(name+'.exporter.log')).write_bytes(p.stdout+p.stderr);assert p.returncode==0,(name,p.stderr[-1000:])
 c=json.loads(export.read_bytes());check=v.verify(next(m for m in c['methods']if m['token']==token),c['types']);assert check['status']=='PASS',(name,check)
 rows.append(dict(name=name,token=token,il_offset=i['offset'],file_offset=offset,before=before.hex(),after=after.hex(),variant_sha256=hashlib.sha256(variant).hexdigest(),cases_executed=len(subset),normal_observable_differences=len(changed),exception_cases=errors,frozen_type_status=check['status'],detected=True))

mutate('devour-wrong-coefficient',0x380,'ldc.r4',.8,operand=.4)
mutate('barrels-subtract-instead-of-accumulate',0x381,'add',b'\x59')
mutate('charge-subtract-instead-of-add',0x3af,'add',b'\x59')
mutate('layer-decrement-instead-of-increment',0x3b0,'add',b'\x59')
mutate('duration-grows-instead-of-elapses',0x3b1,'sub',b'\x58')
mutate('manual-seek-gate-reversed',0x3b7,'brtrue',b'\x39')
mutate('sunflower-half-heal',0x394,'ldc.r4',.6,operand=1.2)
mutate('element-armor-gate-reversed',0x48b,'brtrue',b'\x39')
mutate('ladder-flag-off',0x497,'ldc.i4',b'\x20\x00\x00\x00\x00',operand=1)
mutate('pole-jump-flag-off',0x4a0,'ldc.i4',b'\x20\x00\x00\x00\x00',operand=1)
mutate('pole-jump-end-retains-pole',0x4a1,'ldc.i4.0',b'\x17')
mutate('pole-test-gate-reversed',0x4a4,'brfalse',b'\x3a')
mutate('snowbeast-wrong-recovery-cap',0x4a5,'ldc.r4',5,operand=10,index=1)
mutate('snowbeast-wrong-consumption',0x4a6,'ldc.r4',.5,operand=.75)
mutate('snowbeast-retains-target-device',0x4ad,'stfld',b'\x26\x26\x00\x00\x00')
mutate('skill1-adds-instead-of-multiplies',0x500,'mul',b'\x58')
mutate('skill4-wrong-denominator',0x503,'ldc.r4',1,operand=2)
mutate('skill13-adds-instead-of-multiplies',0x50d,'mul',b'\x58')
report=dict(scope='PHYSICAL_TYPE_VALID_WRONG_BEHAVIOR_SPECIAL_CONTROLS',candidate_sha256=hashlib.sha256(data).hexdigest(),controls=len(rows),all_detected=all(r['detected']for r in rows),results=rows,unchanged_frozen_type_checker_sha256=hashlib.sha256(checker.read_bytes()).hexdigest(),unity_executed=False)
(Q/'PHYSICAL-CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:x for k,x in report.items()if k!='results'}))
