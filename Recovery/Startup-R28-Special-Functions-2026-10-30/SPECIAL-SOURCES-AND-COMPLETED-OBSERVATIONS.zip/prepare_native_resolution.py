"""Reuse read-only metadata decoders for this selected source scope."""
from pathlib import Path
import hashlib,json,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;previous=W/'startup-r28-plant-attack-chain'
rids=sorted({int(x['token'],16)&0xffffff for x in json.loads((Q/'CASES.json').read_bytes())})
prefix="from pathlib import Path\nimport sys\nsys.path.insert(0,"+repr(str(previous))+ ")\n"
records=[]
for name,output in [('resolve_native_apis.py','resolve_selected_apis.py'),('inspect_native_operands.py','resolve_selected_operands.py')]:
 s=(previous/name).read_text(encoding='utf-8');assert'[0x34e,0x3a8,0x3ab]'in s
 s=s.replace('[0x34e,0x3a8,0x3ab]',repr(rids))
 s=s.replace('import source_common as s','import source_common as s\ns.Q=Path(__file__).resolve().parent')
 s=s.replace('cfg=s.save_native(rid)','cfg=s.native(s.tok(rid))')
 data=(prefix+s).encode('utf-8');(Q/output).write_bytes(data)
 records.append(dict(original_decoder=name,sha256=hashlib.sha256((previous/name).read_bytes()).hexdigest(),scope_selected_rids=rids,derived=output,derived_sha256=hashlib.sha256(data).hexdigest()))
 p=subprocess.run([sys.executable,str(Q/output)],capture_output=True)
 (Q/(output+'.log')).write_bytes(p.stdout+p.stderr)
 if p.returncode:raise RuntimeError((p.stdout+p.stderr).decode(errors='replace'))
(Q/'METADATA-DECODER-SOURCES.json').write_bytes((json.dumps(records,indent=2)+'\n').encode())
print('Selected original module APIs and RIP operands resolved for '+str(len(rids))+' callers')
