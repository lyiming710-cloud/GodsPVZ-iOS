"""Prepare one scoped Unity run using the existing R28 setup, not full CI gates."""
from pathlib import Path
import copy,json,sys,textwrap
Q=Path(__file__).resolve().parent;W=Q.parent;R=W.parent/'repo-native113'
sys.path.insert(0,str(W/'tool-deps'));import yaml
checkpoint=R/'Recovery/Startup-R28-Special-Functions-2026-10-30';checkpoint.mkdir(exist_ok=True)
plants=json.loads((Q/'original-definitions/PlantData/PlantsInitialValue.json').read_bytes())['plantsInitialValue']
sniper=next(p for p in plants if p['name'] and p['ID']==0)
plan=dict(scope='CONTROLLED_ORIGINAL_PREFAB_SPECIAL_FIXTURE',sniper_skill_json=json.dumps(sniper['skill1'],ensure_ascii=False),sunflower_skill_value=json.loads((Q/'original-definitions/PlantData/Skills/4.json').read_bytes())['floats'][0],original_definition_sources=['PlantData/PlantsInitialValue.json','PlantData/Skills/4.json'],fields_assigned_for_testing=True,save_unlocks_edited=False)
(checkpoint/'UNITY-SPECIAL-PLAN.json').write_text(json.dumps(plan,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
old=yaml.safe_load((R/'.github/workflows/startup-r28-diagnostic-ipa.yml').read_bytes());job=copy.deepcopy(old['jobs']['export']);job.pop('needs');job['timeout-minutes']=80
keep=[0,1,2,3,6,7,8,9,10,11,12,13,14,15,16,17,19,20,21,22,23]
steps=[copy.deepcopy(job['steps'][i])for i in keep]
stage=next(s for s in steps if s.get('name')=='Bind diagnostic child separately from parent compiler results')
stage['name']='Stage existing R28 candidate for scoped special-function execution'
stage['run']=textwrap.dedent('''\
set -euo pipefail
python3 - "$RUNNER_TEMP/stage9-startup-r2" <<'PY'
from pathlib import Path
import hashlib,json,sys,zipfile
out=Path(sys.argv[1]);(out/'candidate').mkdir(exist_ok=True)
with zipfile.ZipFile('Recovery/Startup-R28-Attack115-2026-10-29/STARTUP-R28-ATTACK115-CANDIDATE.zip')as z:
    data=z.read('STARTUP-R28-ATTACK115.dll')
sha=hashlib.sha256(data).hexdigest()
assert sha=='9081408a2226a79e23991355108540a0260a3966a500cecf4524f3cba9dfb364'
(out/'candidate/Assembly-CSharp-bulk401.dll').write_bytes(data)
(out/'evidence/SPECIAL-INPUT.json').write_text(json.dumps(dict(candidate_sha256=sha,scope='EXISTING_CANDIDATE_SPECIAL_TEST_ONLY',full_gates_repeated=False))+'\\n')
PY
''')
align=steps[-1]
align['run']='\n'.join(line for line in align['run'].splitlines()if not any(x in line for x in ['GodsPVZSdkHolderAuditR28.cs','GodsPVZAttackTraceR28.cs','GodsPVZCustomShaderAudit.cs']))+'\n'
align['run']+='cp "$GITHUB_WORKSPACE/scripts/actions/GodsPVZSpecialAuditR28.cs" "$PROJECT/Assets/Editor/"\n'
steps.append(dict(name='Run one real Unity special-functions batch on original prefab clones',shell='bash',env={'GODSPVZ_SPECIAL_EVIDENCE':'${{ runner.temp }}/stage9-startup-r2/evidence','GODSPVZ_SPECIAL_PLAN':'${{ github.workspace }}/Recovery/Startup-R28-Special-Functions-2026-10-30/UNITY-SPECIAL-PLAN.json','LIBGL_ALWAYS_SOFTWARE':'1'},run=textwrap.dedent('''\
set -euo pipefail
OUT="$RUNNER_TEMP/stage9-startup-r2"
UNITY="$(cat "$OUT/unity-path.txt")"
PROJECT="$(cat "$OUT/project-path.txt")"
set +e
timeout --signal=TERM 600s xvfb-run -a -s '-screen 0 1280x720x24' "$UNITY" -batchmode -force-glcore -projectPath "$PROJECT" -executeMethod GodsPVZSpecialAuditR28.Begin -logFile "$OUT/evidence/special-functions.log"
RC=$?
set -e
echo "$RC" > "$OUT/evidence/special-functions-exit.txt"
[ "$RC" -eq 0 ]
python3 - "$OUT/evidence/R28-ACTUAL-SPECIAL-FUNCTIONS.json" <<'PY'
import json,sys
r=json.load(open(sys.argv[1]))
assert r['candidate_sha256']=='9081408a2226a79e23991355108540a0260a3966a500cecf4524f3cba9dfb364'
assert r['sdk_sha256']=='51f72bcd146c5571f642f3c4149f0545eb704fd325d83eb0f7c4ca2deec14c2b'
assert r['pass'] and len(r['cases'])==18 and not r['errors']
print('ACTUAL_CONTROLLED_SPECIAL_CASES',len(r['cases']))
PY
''')))
steps += [copy.deepcopy(job['steps'][i])for i in [32,34,35]]
steps[-1]['with']['name']='STARTUP-R28-SPECIAL-FUNCTIONS-EVIDENCE'
job['steps']=steps
workflow=dict(name='Startup R28 plant and zombie special functions - scoped real Unity',on={'workflow_dispatch':{}},permissions=old['permissions'],concurrency=old['concurrency'],jobs=dict(special_functions=job))
for name in ['bulk401-startup-runtime-gate.yml','startup-r28-special-functions.yml']:(R/'.github/workflows'/name).write_text(yaml.safe_dump(workflow,sort_keys=False,width=120,allow_unicode=True),encoding='utf-8')
print(json.dumps(dict(scope='ONE_SCOPED_UNITY_BATCH_NO_FULL_COMPILER_OR_IPA_GATES',steps=len(steps),cases=18,checkpoint=str(checkpoint))))
