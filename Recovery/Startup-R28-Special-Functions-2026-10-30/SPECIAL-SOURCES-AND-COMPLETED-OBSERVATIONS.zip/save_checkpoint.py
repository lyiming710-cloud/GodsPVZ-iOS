"""Save completed observations without rerunning any test or historical gate."""
from pathlib import Path
import collections,hashlib,json,shutil,zipfile
Q=Path(__file__).resolve().parent;W=Q.parent;R=W.parent/'repo-native113';out=R/'Recovery/Startup-R28-Special-Functions-2026-10-30';out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
native=json.loads((Q/'NATIVE-COMPARE.json').read_bytes());controls=json.loads((Q/'PHYSICAL-CONTROLS.json').read_bytes());cases=json.loads((Q/'CASES.json').read_bytes())
origins=collections.Counter('SYNTHETIC_BOUNDARY'if isinstance(c['origin'],str)else 'ORIGINAL_SKILL_LEVEL'if c['origin']['kind']=='ORIGINAL_PC_SKILL_LEVEL_DATA'else 'NAMED_PLANT_DEFAULT'if c['origin']['skill_name']else 'UNNAMED_SERIALIZED_ENTRY_BOUNDARY_ONLY'for c in cases)
summary=dict(scope='20_SPECIAL_FUNCTION_CALLERS_WITH_CONTROLLED_CALLEE_CONTRACTS',candidate_sha256=native['candidate_sha256'],original_pc_sha256=native['original_pc_sha256'],actual_raw_cil_and_native_cases=len(cases),native_comparison_counts=native['counts'],case_origins=dict(origins),methods=20,physical_wrong_behavior_controls=controls['controls'],physical_controls_detected=controls['all_detected'],type_valid_controls=18,real_unity_status='AUTHORED_NOT_YET_EXECUTED',real_unity_planned_cases=18,whole_game_special_features_accepted=False,normal_level_play_proven=False,game_method_bodies_changed_this_turn=0,ipa=None)
(out/'CONTROLLED-RESULTS.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
for name in ['SOURCE-INVENTORY.json','PHYSICAL-CONTROLS.json','SPECIAL-HELPER-COMPILATION.log']:shutil.copyfile(Q/name,out/name)
# Preserve exact test sources, observations, selected native/CIL bodies and data.
# Physical wrong DLLs are reproducible from the byte deltas and fixed input;
# their large duplicate images are left in the local work directory.
with zipfile.ZipFile(out/'SPECIAL-SOURCES-AND-COMPLETED-OBSERVATIONS.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in sorted(Q.rglob('*')):
  if not p.is_file():continue
  relative=p.relative_to(Q)
  if any(k in relative.parts for k in ['obj','__pycache__']):continue
  if relative.parts[0]=='physical-controls'and p.suffix=='.dll':continue
  z.write(p,relative.as_posix())
 z.write(W/'startup-r23-battle-loop/board-runtime/RehostExact.cs','source-dependencies/RehostExact.cs')
 z.write(R/'scripts/actions/GodsPVZSpecialAuditR28.cs','unity/GodsPVZSpecialAuditR28.cs')
failure=W/'r28-export-run-40800918671';run=json.loads((failure/'RUN.json').read_bytes())
receipt=dict(scope='ACTUAL_PREVIOUS_UNITY_EDITOR_PROCESS_FAILURE_NOT_GAMEPLAY_FAILURE',run_id=40800918671,url=run['url'],source_commit=run['headSha'],conclusion=run['conclusion'],startup_process_exit=134,probe_report_written=False,actual_ipa_exported=False,apple_build_started=False,observed_native_stack=['pal_utilities.h:160 ToFileDescriptor fd assertion','SystemNative_FcntlSetCloseOnExec','NamedPipeServerStream.HandleAcceptedSocket'],root_cause_proven=False,new_retry_or_editor_patch_added=False)
(out/'PREVIOUS-EXPORT-40800918671.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
with zipfile.ZipFile(out/'PREVIOUS-EXPORT-40800918671-EVIDENCE.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(failure.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(failure).as_posix())
print(json.dumps(summary));print(json.dumps([dict(file=p.name,bytes=p.stat().st_size)for p in sorted(out.glob('*.zip'))]))
