"""Finite normal/boundary states, not unlocked saves or a normal-play claim."""
from pathlib import Path
import copy,itertools,json
Q=Path(__file__).resolve().parent;rows=[]
base=dict(mode='normal',plant={},zombie={},skill={},damage={},hp='alive',buff=True,grid='none',argument=0,dt=.1,atk=50,**{'as':1.5},canJump=True,origin='SYNTHETIC_FINITE_BOUNDARY_STATE')
def add(rid,**values):
 row=copy.deepcopy(base);row.update(values);row.update(token=f'0x{0x6000000|rid:08X}',name=f'{rid:03X}-{len(rows):04d}');rows.append(row)
for ongoing,prevent,layers,charge,amount in itertools.product([False,True],[False,True],[0,2,3],[0,11.5,12,25],[0,1,12,35]):
 add(0x3af,plant=dict(skillOngoing=ongoing),skill=dict(isPreventCharge=prevent,chargedLayer=layers,chargeTicking=charge),argument=amount)
for charge,layers in itertools.product([0,11,12,24,36],[0,2,3]):add(0x3b0,skill=dict(chargeTicking=charge,chargedLayer=layers))
add(0x3b0,mode='ui-swap',skill=dict(chargeTicking=24,chargedLayer=0))
add(0x3af,mode='ui-swap',argument=24)
for ID,kind,perpetual,remain in itertools.product([0,49],[1,2],[False,True],[0,.05,1]):
 add(0x3b1,plant=dict(ID=ID,skillRemainTime=remain),skill=dict(type=kind,isPerpetual=perpetual))
for mode in ['update-perpetual','end-swap']:add(0x3b1,mode=mode,plant=dict(ID=49,skillRemainTime=0))
add(0x3b1,plant=dict(ID=49,skillRemainTime=0),buff=False)
for ID,manual in itertools.product([0,4],[False,True]):add(0x3b7,plant=dict(ID=ID),skill=dict(needManualSeek=manual))
add(0x3b7,plant=dict(ID=0),skill=dict(needManualSeek=True),mode='crosshair-switch')
for order,hp in itertools.product([0,1],[.01,400,5000]):add(0x380,plant=dict(order=order,pT_chomperviking_devourPoint=100),zombie=dict(healthPoint=hp))
for order,points in itertools.product([0,1],[0,100,1300,3000]):add(0x381,plant=dict(order=order,pT_chomperviking_devourPoint=points,pT_chomperviking_barrelsPoint=900))
for xy,grid,atk in itertools.product([0,2],['none','full','bottom-only','destroyed-alternate'],[0,50]):add(0x394,plant=dict(GridX=xy,GridY=xy),grid=grid,atk=atk)
add(0x394,grid='full',mode='atk-counter')
for element,armor,point in itertools.product([0,1,7],[0,4],[0,100,-1]):add(0x48b,argument=element,zombie=dict(armor1Type=armor,armor1Point=point))
for rid in [0x497,0x4a0]:
 for value in [False,True]:add(rid,zombie=dict(ladderZombie_place=value,poleZombie_jump=value))
for ID,buff in itertools.product([0,3],[False,True]):add(0x4a1,zombie=dict(ID=ID),buff=buff)
for jump in [False,True]:add(0x4a4,canJump=jump)
for rest,stance,time,dt in itertools.product([False,True],[False,True],[0,9.95,10,11],[0,.1]):add(0x4a5,zombie=dict(snowbeast_isRest=rest,isStant=stance,snowbeast_restTime=time),dt=dt)
for action,time,hp in itertools.product([0,1,2,3,4],[.1,1,10],['null','alive','destroyed']):add(0x4a6,argument=action,zombie=dict(snowbeast_restTime=time),hp=hp)
add(0x4ad)
for rid,value,damage in itertools.product([0x500,0x503,0x50d],[0,1.4,2,2.4,4,10],[0,100,1000]):add(rid,skill=dict(value_float=[value]),damage=dict(damagePoint=damage))
for rid in [0x37f,0x50a]:add(rid)

# Preserve the serialized PC defaults as a separate, attributable input set.
# These are direct caller tests; normal save unlocks and Skill initialization
# through the complete game scene are not claimed by this fixture.
definitions=Q/'original-definitions/PlantData'
plants=json.loads((definitions/'PlantsInitialValue.json').read_bytes())['plantsInitialValue']
allowed={'needManualSeek','isPreventCharge','isPerpetual','chargedLayer','maxChargedLayer','chargeTicking','maxChargeTicking','value_float','type'}
for plant in plants:
 for slot in ['skill1','skill2','skill3']:
  source=plant[slot]
  if source['maxChargeTicking']<=0 or source['maxChargedLayer']<=0:continue
  skill={k:v for k,v in source.items()if k in allowed}
  origin=dict(kind='ORIGINAL_PC_SERIALIZED_SKILL_DEFAULTS',path='PlantData/PlantsInitialValue.json',plant_id=plant['ID'],slot=slot,skill_name=source['name'])
  for amount in [0,1,source['maxChargeTicking'],source['maxChargeTicking']*3]:
   add(0x3af,plant=dict(ID=plant['ID']),skill=skill,argument=amount,origin=origin)
  for layers in [0,source['maxChargedLayer']-1,source['maxChargedLayer']]:
   configured=copy.deepcopy(skill);configured.update(chargedLayer=layers,chargeTicking=source['maxChargeTicking']*2)
   add(0x3b0,plant=dict(ID=plant['ID']),skill=configured,origin=origin)
  add(0x3b1,plant=dict(ID=plant['ID'],skillRemainTime=source['duration']),skill=skill,origin=origin)
for rid,skill_id in [(0x500,1),(0x503,4),(0x50d,13)]:
 source=json.loads((definitions/'Skills'/f'{skill_id}.json').read_bytes())
 for level in range(9):
  add(rid,skill=dict(value_float=[source['floats'][level]]),damage=dict(damagePoint=100),origin=dict(kind='ORIGINAL_PC_SKILL_LEVEL_DATA',path=f'PlantData/Skills/{skill_id}.json',level_index=level))
(Q/'CASES.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode())
from collections import Counter
print(json.dumps(dict(cases=len(rows),methods=len({r['token']for r in rows}),by_token=dict(Counter(r['token']for r in rows)),scope='CONTROLLED_CALLER_CASES_NO_UNITY_OR_NORMAL_PLAY')))
