"""Execute original PC callers; callee hooks are explicit finite contracts."""
from pathlib import Path
import collections,ctypes as C,hashlib,importlib.util,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent
sys.path[:0]=[str(W/'startup-r5'),str(W/'startup-r28-plant-attack-chain')]
from native_runtime_common import NativeImage,P,I,F,put64,get64,put32,get32,putf,getf,bits,PC_SHA
import source_common as original
actual=json.loads((Q/'ACTUAL-CIL.json').read_bytes());assert actual['candidate_sha256']=='9081408a2226a79e23991355108540a0260a3966a500cecf4524f3cba9dfb364'
cases=json.loads((Q/'CASES.json').read_bytes());expected={r['name']:r for r in actual['results']};rids={int(q['token'],16)&0xffffff for q in cases}
apis=json.loads((Q/'ORIGINAL-DIRECT-API-IDENTITIES.json').read_bytes())['resolved']
def api(owner,name):
 found={int(va,16)for va,rows in apis.items()if any(r['owner']==owner and r['name']==name for r in rows)}
 assert len(found)==1,(owner,name,found)
 return found.pop()
fieldrows=original.field_rows
def off(owner,name):
 rows=[r for r in fieldrows if r['type']==owner and not r['namespace']and r['name']==name]
 assert len(rows)==1,(owner,name,rows)
 return rows[0]['offset']
def fget(obj,owner,name):return getf(obj+off(owner,name))
def fset(obj,owner,name,value):putf(obj+off(owner,name),value)
def iget(obj,owner,name):return get32(obj+off(owner,name))
def bget(obj,owner,name):return bool(C.c_ubyte.from_address(obj+off(owner,name)).value)
def bset(obj,owner,name,value):C.c_ubyte.from_address(obj+off(owner,name)).value=bool(value)
def ptr(obj,owner,name):return get64(obj+off(owner,name))
def setptr(obj,owner,name,value):put64(obj+off(owner,name),value)
def f32(x):return struct.unpack('<f',struct.pack('<f',x))[0]

# Independently bind the selected pointer index to original metadata names.
source=original.ROOT/'audit/actions-cleanup-2026-10-02/repository/Tools/MethodIndexDump/native_map.py'
spec=importlib.util.spec_from_file_location('original_names',source);nm=importlib.util.module_from_spec(spec);spec.loader.exec_module(nm)
meta=(original.I/'original-pc/global-metadata.dat').read_bytes();names={rid:(token,owner,name,argc)for rid,token,owner,name,argc in nm.metadata_methods(meta,'Assembly-CSharp.dll')}
methods={m['token']:m for m in json.loads((W/'startup-r28-plant-attack-chain/shared-authored2/ALL-CIL.json').read_bytes())['methods']}
for rid in rids:
 m=methods[original.tok(rid)];token,owner,name,argc=names[rid]
 assert m['owner']==owner and m['name'].split('::')[1].split('(')[0]==name and len(m['args'])==argc,(rid,m['name'],names[rid])

im=NativeImage();state={};rows=[];strings={};configs={};hooks=[]
lo,ln,ld,ldn=struct.unpack_from('<4I',meta,8)
def string(value):
 data=value.encode('utf-16-le');a=im.alloc(22+len(data));put32(a+16,len(data)//2);C.memmove(a+20,data,len(data));strings[a]=value;return a
def text(a):
 assert a in strings,('Unknown string pointer',hex(a or 0))
 return strings[a]
def metadata_slot(slot):
 value=struct.unpack('<Q',original.pc.get_data(slot-original.base,8))[0];kind=value>>29;index=(value&0x1fffffff)>>1
 if kind==5:
  size,start=struct.unpack_from('<II',meta,lo+8*index);assert start+size<=ldn
  put64(slot,string(meta[ld+start:ld+start+size].decode('utf-8')))
 else:im.class_slot(slot)
im.hook(0x18024fef0,None,[P],metadata_slot);im.hook(0x1802501e0,None,[P],lambda _:None);im.hook(0x18024f360,None,[P,P],lambda a,b:None)
def hook(owner,name,result,args,fn):
 va=api(owner,name);assert va not in {original.pointer(original.tok(r))for r in rids},('Cannot replace caller',owner,name)
 im.hook(va,result,args,fn);hooks.append(dict(va=hex(va),owner=owner,name=name,scope='CONTROLLED_CALLEE_CONTRACT_NOT_ORIGINAL_CALLEE_EXECUTION'))
def log(*args):state['trace'].append(':'.join('1'if x is True else'0'if x is False else str(x)for x in args))
def obj(tag,alive=True):
 a=im.alloc(4096);state['objects'][a]=dict(tag=tag,alive=alive,flags={},triggers=[],records=0);return a
def fields(a,owner,values):
 floats={'chargeTicking','maxChargeTicking','skillRemainTime','updateRate','attackIntervalCountdown','pT_chomperviking_devourPoint','pT_chomperviking_barrelsPoint','maxHealthPoint','healthPoint','armor1Point','snowbeast_restTime','damagePoint'}
 for key,value in values.items():
  if isinstance(value,bool):bset(a,owner,key,value)
  elif key=='value_float':
   array=im.alloc(32+4*len(value));put64(array+24,len(value))
   for i,v in enumerate(value):putf(array+32+i*4,v)
   setptr(a,owner,key,array)
  elif key in floats:fset(a,owner,key,value)
  else:put32(a+off(owner,key),value)
def setup(q):
 state.clear();state.update(q=q,trace=[],objects={},neighbors=[],grids={},atkReads=0)
 p=obj('plant');z=obj('zombie');s=obj('main');other=obj('other');d=obj('damage');state.update(p=p,z=z,s=s,other=other,d=d)
 for sk,val in [(s,1.4),(other,2)]:fields(sk,'Skill',dict(maxChargedLayer=3,maxChargeTicking=12,chargeTicking=0,value_float=[val]))
 fields(p,'Plant',dict(updateRate=1,GridX=2,GridY=2,maxHealthPoint=1000,healthPoint=500));setptr(p,'Plant','skill',s)
 fields(z,'Zombie',dict(healthPoint=1000,armor1Point=100,poleZombie_pole=True,poleZombie_jump=True,passablePoint=0))
 for a,owner in [(p,'Plant'),(z,'Zombie')]:
  anim=obj('animator');setptr(a,owner,'animator',anim)
  bm=obj('buff');setptr(a,owner,'buffManager',bm);stat=obj('known');fset(stat,'StatsIncreased','value',7);state['objects'][bm].update(present=q['buff'],known=stat)
  state[('p'if owner=='Plant'else'z')+'Anim']=anim;state[('p'if owner=='Plant'else'z')+'Buff']=bm
 setptr(z,'Zombie','path',obj('path'));setptr(z,'Zombie','targetDevice',obj('device'))
 hp=0 if q['hp']=='null'else obj('hp',q['hp']!='destroyed');setptr(z,'Zombie','hpUIController',hp);state['hp']=hp
 board=obj('board');mouse=obj('mouse');setptr(p,'Plant','board',board);setptr(board,'Board','mouseManager',mouse);setptr(p,'Plant','attackRangeUIController',obj('range'))
 fields(d,'Damage',dict(damagePoint=100));fields(p,'Plant',q['plant']);fields(z,'Zombie',q['zombie']);fields(s,'Skill',q['skill']);fields(d,'Damage',q['damage'])
 if q['grid']!='none':
  for x in range(5):
   for y in range(5):
    grid=obj('grid');state['grids'][(x,y)]=grid
    for layer,key in enumerate(['plant_bottom','plant_common','plant_sheath','plant_top']):
     if q['grid']=='bottom-only'and layer:continue
     n=obj(f'n{x}.{y}.{layer}',q['grid']!='destroyed-alternate'or(x+y+layer)%2==0);fields(n,'Plant',dict(healthPoint=100,maxHealthPoint=1000));state['neighbors'].append(n);setptr(grid,'Grid',key,n)

def skill_ui(a,value,_):
 log('skillUI',value)
 if state['q']['mode']=='ui-swap':setptr(a,'Plant','skill',state['other'])
def update(sk,p,_):
 log('updateSkill')
 if state['q']['mode']=='update-perpetual':bset(sk,'Skill','isPerpetual',True)
def end(sk,p,z,pr,d,_):
 log('endSkill')
 if state['q']['mode']=='end-swap':setptr(p,'Plant','skill',state['other'])
def crosshair(m,p,_):
 log('crosshair')
 if state['q']['mode']=='crosshair-switch':put32(p+off('Plant','ID'),4)
def animator_bool(a,k,v,_):log('animBool',text(k),bool(v));state['objects'][a]['flags'][text(k)]=bool(v)
def animator_trigger(a,k,_):log('animTrigger',text(k));state['objects'][a]['triggers'].append(text(k))
def find(bm,key,_,kind):log(kind,text(key));return state['objects'][bm]['known']if state['objects'][bm]['present']else 0
def remove(bm,b,_):log('removeBuff','known');state['objects'][bm]['present']=False
def atk(a,_):
 log('getATK');value=state['q']['atk']
 if state['q']['mode']=='atk-counter':value=f32(value+f32(state['atkReads']*.5));state['atkReads']+=1
 return value
def heal(a,v,source,_):log('healed',state['objects'][a]['tag'],bits(v),state['objects'][source]['tag']);fset(a,'Plant','healthPoint',min(fget(a,'Plant','maxHealthPoint'),f32(fget(a,'Plant','healthPoint')+v)))
def destroy(a,_):log('destroyZombie');state['objects'][a]['alive']=False
def record(a,_):log('recordHP');state['objects'][a]['records']+=1
def stance(a,value,_):log('stance',bits(value));bset(a,'Zombie','isStant',True)
def grid(a,x,y,_):log('grid',x,y);return state['grids'].get((x,y),0)

hook('UnityEngine.Object','op_Implicit',C.c_bool,[P,P],lambda a,_:bool(a and state['objects'][a]['alive']))
hook('UnityEngine.Time','get_deltaTime',F,[P],lambda _:(log('delta',bits(state['q']['dt']))or state['q']['dt']))
hook('UnityEngine.Animator','SetBool',None,[P,P,C.c_bool,P],animator_bool);hook('UnityEngine.Animator','SetTrigger',None,[P,P,P],animator_trigger)
hook('Plant','SkillUIUpdate',None,[P,I,P],skill_ui);hook('Plant','Trigger_Skill',None,[P,P],lambda a,_:log('triggerSkill'))
hook('Plant','GetAS',F,[P,P],lambda a,_:(log('getAS')or state['q']['as']));hook('Plant','GetATK',F,[P,P],atk)
hook('Plant','Healed',None,[P,F,P,P],heal);hook('Plant','PC_ChompervikingUpdateBarrels',None,[P,P],lambda a,_:log('updateBarrels'));hook('Plant','PC_SSI_TrySummon',None,[P,P],lambda a,_:log('trySummon'))
hook('Skill','Updata',None,[P,P,P],update);hook('Skill','End',None,[P,P,P,P,P,P],end)
hook('MouseManager','GetSkillCrosshairsFromPlant',None,[P,P,P],crosshair);hook('Board','HideButtons',None,[P,P],lambda a,_:log('hideButtons'));hook('Board','GetGrid',P,[P,I,I,P],grid)
hook('AttackRangeUIController','ExpandView',None,[P,I,C.c_bool,P],lambda a,x,b,_:log('expand',x,bool(b)))
hook('BuffManager','FindBuff',P,[P,P,P],lambda b,k,m:find(b,k,m,'findBuff'));hook('BuffManager','FindStatsIncreased',P,[P,P,P],lambda b,k,m:find(b,k,m,'findStats'));hook('BuffManager','RemoveBuff',None,[P,P,P],remove)
hook('Zombie','DestroyZombie',None,[P,P],destroy);hook('Zombie','Path_Finding',C.c_bool,[P,P],lambda a,_:(log('pathFinding')or True));hook('Zombie','ZC_PoleTestJump',C.c_bool,[P,P],lambda a,_:(log('testJump')or state['q']['canJump']))
hook('Zombie','TranToStant',None,[P,F,P],stance);hook('HPUIController_Zombie','RecordingHP',None,[P,P],record)
im.hook(0x18030e0e0,F,[F,F,F,P],lambda x,low,high,_:min(max(x,low),high));hooks.append(dict(va='0x18030e0e0',scope='FINITE_ORDERED_CLAMP_CALLEE_CONTRACT_NOT_ORIGINAL_CLAMP_BODY'))
for rid in rids:
 cfg=json.loads((Q/'sources'/f'0x{0x6000000|rid:08X}-native.json').read_bytes());im.verify_caller(rid,int(cfg['entry'],16),cfg);configs[rid]=cfg
def skillstate(a):return dict(charge=bits(fget(a,'Skill','chargeTicking')),maxCharge=bits(fget(a,'Skill','maxChargeTicking')),layers=iget(a,'Skill','chargedLayer'),maxLayers=iget(a,'Skill','maxChargedLayer'),perpetual=bget(a,'Skill','isPerpetual'))
def snapshot():
 p,z=state['p'],state['z'];pa,za=state['objects'][state['pAnim']],state['objects'][state['zAnim']];hp=state['hp'];pb=state['objects'][state['pBuff']]
 return dict(skillReference='main'if ptr(p,'Plant','skill')==state['s']else'other',mainSkill=skillstate(state['s']),otherSkill=skillstate(state['other']),plantID=iget(p,'Plant','ID'),remaining=bits(fget(p,'Plant','skillRemainTime')),cooldown=bits(fget(p,'Plant','attackIntervalCountdown')),devour=bget(p,'Plant','pC_chomperviking_devour'),devourPoint=bits(fget(p,'Plant','pT_chomperviking_devourPoint')),barrels=bits(fget(p,'Plant','pT_chomperviking_barrelsPoint')),plantFlags=pa['flags'],plantTriggers=pa['triggers'],zombieAlive=state['objects'][z]['alive'],rest=bget(z,'Zombie','snowbeast_isRest'),restTime=bits(fget(z,'Zombie','snowbeast_restTime')),stance=bget(z,'Zombie','isStant'),pole=bget(z,'Zombie','poleZombie_pole'),jump=bget(z,'Zombie','poleZombie_jump'),ladder=bget(z,'Zombie','ladderZombie_place'),passable=iget(z,'Zombie','passablePoint'),zombieFlags=za['flags'],zombieTriggers=za['triggers'],hpRecords=state['objects'][hp]['records']if hp else 0,pathNull=not ptr(z,'Zombie','path'),targetDeviceNull=not ptr(z,'Zombie','targetDevice'),buffPresent=state['objects'][state['zBuff']]['present'],plantBuffValue=bits(fget(pb['known'],'StatsIncreased','value')),heals=[dict(tag=state['objects'][n]['tag'],health=bits(fget(n,'Plant','healthPoint')))for n in state['neighbors']if fget(n,'Plant','healthPoint')!=100],damage=bits(fget(state['d'],'Damage','damagePoint')))

progress=Q/'NATIVE-PROGRESS.jsonl'
progress.write_text('',encoding='utf-8')
for case_index,q in enumerate(cases):
 with progress.open('a',encoding='utf-8')as pf:pf.write(json.dumps(dict(index=case_index,name=q['name'],token=q['token']))+'\n')
 setup(q);rid=int(q['token'],16)&0xffffff;entry=int(configs[rid]['entry'],16);returned=None
 if rid in [0x500,0x503,0x50a,0x50d]:C.CFUNCTYPE(None,P,P,P,P,P)(entry)(state['p'],state['z'],0,state['d'],None)
 elif rid==0x380:C.CFUNCTYPE(None,P,P,P)(entry)(state['p'],state['z'],None)
 elif rid==0x3af:C.CFUNCTYPE(None,P,F,P)(entry)(state['p'],q['argument'],None)
 elif rid==0x48b:returned=bool(C.CFUNCTYPE(C.c_bool,P,I,I,P)(entry)(state['z'],q['argument'],0,None))
 elif rid==0x4a6:C.CFUNCTYPE(None,P,I,P)(entry)(state['z'],q['argument'],None)
 elif rid==0x3b7:returned=bool(C.CFUNCTYPE(C.c_bool,P,P)(entry)(state['p'],None))
 else:C.CFUNCTYPE(None,P,P)(entry)(state['p']if rid<0x400 else state['z'],None)
 assert not im.errors,im.errors
 result=dict(returned=returned,state=snapshot(),trace=state['trace']);want=expected[q['name']]
 differences={k:dict(native=v,cil=want[k])for k,v in result.items()if v!=want[k]}
 if want['error']:differences['cil_error']=want['error']
 rows.append(dict(name=q['name'],token=q['token'],status='DIFFERENCE'if differences else'ZERO_DIFFERENCE',native=result,cil=want,differences=differences))
im.close()
report=dict(scope='TWENTY_ORIGINAL_PC_CALLERS_VS_EXACT_RAW_CIL_FINITE_CONTRACTS_NOT_UNITY',candidate_sha256=actual['candidate_sha256'],original_pc_sha256=PC_SHA,counts=dict(collections.Counter(r['status']for r in rows)),original_caller_metadata_names_checked=20,controlled_callees=hooks,rows=rows,whole_game_proven=False,ipa=None)
(Q/'NATIVE-COMPARE.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
print(json.dumps({k:v for k,v in report.items()if k not in ['rows','controlled_callees']}));print(json.dumps([dict(name=r['name'],token=r['token'],differences=r['differences'])for r in rows if r['differences']][:2],ensure_ascii=True))
if any(r['differences']for r in rows):raise SystemExit(1)
