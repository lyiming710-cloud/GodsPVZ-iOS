"""Isolated Windows x64 original-PC caller harness; never enters DllMain.

Only callers whose original bytes are rechecked are evidence. Patched callees
are explicit controlled contracts, not evidence of Unity or callee correctness.
"""
from pathlib import Path
import ctypes as C
import hashlib,json,struct,sys

ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import pefile
PC_SHA='9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d'
P=C.c_void_p;I=C.c_int32;F=C.c_float
def put64(at,v):C.c_uint64.from_address(at).value=v or 0
def get64(at):return C.c_uint64.from_address(at).value
def put32(at,v):C.c_int32.from_address(at).value=v
def get32(at):return C.c_int32.from_address(at).value
def putf(at,v):C.c_float.from_address(at).value=v
def getf(at):return C.c_float.from_address(at).value
def number(s):return float(s.replace('Inf','inf'))
def bits(v):
    return 'NaN' if v!=v else struct.pack('<f',v)[::-1].hex().upper()

class NativeImage:
    def __init__(self):
        assert sys.platform=='win32' and C.sizeof(P)==8
        self.raw=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/GameAssembly.dll').read_bytes()
        assert hashlib.sha256(self.raw).hexdigest()==PC_SHA
        self.pe=pefile.PE(data=self.raw);self.base=self.pe.OPTIONAL_HEADER.ImageBase
        self.api=C.WinDLL('kernel32',use_last_error=True)
        self.api.VirtualAlloc.argtypes=[P,C.c_size_t,C.c_uint32,C.c_uint32];self.api.VirtualAlloc.restype=P
        self.api.VirtualFree.argtypes=[P,C.c_size_t,C.c_uint32];self.api.VirtualFree.restype=C.c_int
        self.mapped=self.api.VirtualAlloc(self.base,self.pe.OPTIONAL_HEADER.SizeOfImage,0x3000,0x40)
        assert self.mapped==self.base,'Original base unavailable in isolated child'
        C.memmove(self.base,self.raw[:self.pe.OPTIONAL_HEADER.SizeOfHeaders],self.pe.OPTIONAL_HEADER.SizeOfHeaders)
        for s in self.pe.sections:
            C.memmove(self.base+s.VirtualAddress,self.raw[s.PointerToRawData:s.PointerToRawData+s.SizeOfRawData],s.SizeOfRawData)
        self.owned=[];self.callbacks=[];self.errors=[];self.classes={}
    def alloc(self,size):
        value=C.create_string_buffer(size);self.owned.append(value);return C.addressof(value)
    def class_slot(self,at):
        if at not in self.classes:
            cls=self.alloc(512);static=self.alloc(128);put64(cls+0xb8,static);put32(cls+0xe0,1);self.classes[at]=cls
        put64(at,self.classes[at]);return self.classes[at]
    def hook(self,va,result,args,fn):
        def guard(*values):
            try:return fn(*values)
            except Exception as e:
                self.errors.append(dict(va=hex(va),error=repr(e)))
                return None if result is None else 0
        callback=C.CFUNCTYPE(result,*args)(guard);self.callbacks.append(callback)
        C.memmove(va,b'\xff\x25\0\0\0\0'+struct.pack('<Q',C.cast(callback,P).value),14)
    def install_metadata(self):
        self.hook(0x18024fef0,None,[P],lambda slot:self.class_slot(slot) and None)
        self.hook(0x1802501e0,None,[P],lambda _:None)
    def verify_caller(self,rid,entry,cfg):
        assert int.from_bytes(self.pe.get_data(0x181B82D60-self.base+(rid-1)*8,8),'little')==entry
        for i in cfg['instructions']:
            expected=bytes.fromhex(i['bytes'])
            assert C.string_at(int(i['va'],16),len(expected))==expected,'Original caller bytes changed'
    def close(self):
        if self.mapped:self.api.VirtualFree(self.base,0,0x8000);self.mapped=None
