"""Original PC System2 caller; TMP text getter is native-inlined field read.
Int32 parsing is an explicit controlled invariant-culture ASCII contract.
"""
from pathlib import Path
import ctypes as C,json,sys,re,base64
from native_runtime_common import *
Q=Path(__file__).resolve().parent;cases=json.loads(Path(sys.argv[1]).read_bytes());out=Path(sys.argv[2]);im=NativeImage();state={};results=[]
def text(value):
    if value is None:return 0
    data=value.encode('utf-16-le');p=im.alloc(24+len(data)+2);put32(p+0x10,len(data)//2);C.memmove(p+0x14,data,len(data));return p
def read(p):return None if not p else C.string_at(p+0x14,get32(p+0x10)*2).decode('utf-16-le')
def config():
    p=im.alloc(128);m=im.alloc(64);rows=im.alloc(64);put64(p+0x30,m);put64(m+0x10,rows)
    state['row_lists'][rows]=[im.alloc(64) for _ in range(3)]
    for row in state['row_lists'][rows]:put32(row+0x20,-99)
    return p
def snapshot(p):return [get32(r+0x20) for r in state['row_lists'][get64(get64(p+0x30)+0x10)]]
try:
    im.install_metadata()
    def name(p,method):
        assert p==state['input'];state['trace'].append('Name');mode=state['case']['callback']
        if mode=='replace-config-on-name':put64(state['owner']+0x20,config())
        if mode=='mutate-text-on-name':put64(p+0x220,text('17'))
        return text(state['case']['input_name'])
    def parse(p,out_value,method):
        value=read(p);s=value.strip(' \t\r\n\v\f') if value is not None else ''
        okay=bool(re.fullmatch('[+-]?[0-9]+',s));n=int(s) if okay else 0
        okay=okay and -2147483648<=n<=2147483647;n=n if okay else 0;put32(out_value,n)
        state['trace'].append('Parse:'+('<null>' if value is None else base64.b64encode(value.encode()).decode())+':'+('1' if okay else '0')+':'+str(n));return okay
    def item(rows,index,method):return state['row_lists'][rows][index]
    im.hook(0x18131F6F0,P,[P,P],name);im.hook(0x180CA3C50,C.c_bool,[P,P,P],parse)
    im.hook(0x1812E68F0,None,[P,P],lambda *_:state['trace'].append('Log'))
    im.hook(0x180825710,P,[P,I,P],item)
    cfg=json.loads((Q.parent/'remaining-native/0089.normal-cfg.json').read_bytes());im.verify_caller(0x89,0x18030AFF0,cfg)
    invoke=C.CFUNCTYPE(None,P,P,P)(0x18030AFF0)
    for case in cases:
        state.clear();state.update(case=case,trace=[],row_lists={});owner=im.alloc(64);p=im.alloc(1024);state.update(owner=owner,input=p)
        initial=config();put64(owner+0x20,initial);put64(p+0x220,text(case['text']));invoke(owner,p,None)
        results.append(dict(name=case['name'],trace=list(state['trace']),current=snapshot(get64(owner+0x20)),initial=snapshot(initial),error=None))
    assert not im.errors,im.errors
    report=dict(scope='ACTUAL_ORIGINAL_PC_SYSTEM2_CALLER_CONTROLLED_CALLEES',original_sha256=PC_SHA,method_token='0x06000089',original_caller_instruction_count=len(cfg['instructions']),
                original_caller_bytes_preserved=True,callback_errors=im.errors,log_text_equivalence=False,unity_execution=False,results=results)
    out.write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(dict(cases=len(results),callback_errors=im.errors)))
finally:im.close()
