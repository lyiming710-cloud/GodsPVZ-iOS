using System.Reflection;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public class UnityState {public bool Alive=true;public string Id="";}
public sealed class TextState {public string Id="text";}
public interface IEvent {public string Id {get;}public void Fire();public string[] Snapshot();}
public sealed class Event2<T1,T2>(string id):IEvent
{
    public string Id=>id;readonly List<Action<T1,T2>> listeners=[];
    public void AddListener(Action<T1,T2> a){Program.Registration("Add",Id,a);listeners.Add(a);Program.Callback("Add",Id);}
    public void RemoveListener(Action<T1,T2> a){Program.Registration("Remove",Id,a);listeners.RemoveAll(x=>x==a);Program.Callback("Remove",Id);}
    public void Fire(){foreach(var a in listeners.ToArray())a((T1)(object)'q',(T2)(object)7);}
    public string[] Snapshot()=>listeners.Select(Program.Listener).ToArray();
}
public sealed class Event3<T1,T2,T3>(string id):IEvent
{
    public string Id=>id;readonly List<Action<T1,T2,T3>> listeners=[];
    public void AddListener(Action<T1,T2,T3> a){Program.Registration("Add",Id,a);listeners.Add(a);Program.Callback("Add",Id);}
    public void RemoveListener(Action<T1,T2,T3> a){Program.Registration("Remove",Id,a);listeners.RemoveAll(x=>x==a);Program.Callback("Remove",Id);}
    public void Fire(){foreach(var a in listeners.ToArray()){if(typeof(T2)==typeof(string))a((T1)(object)"ID",(T2)(object)"label",(T3)(object)9);else a((T1)(object)"word",(T2)(object)3,(T3)(object)4);}}
    public string[] Snapshot()=>listeners.Select(Program.Listener).ToArray();
}
public sealed class HandlerState:UnityState
{
    private Event2<char,int> m_OnCharacterSelection,m_OnSpriteSelection;
    private Event3<string,int,int> m_OnWordSelection,m_OnLineSelection;
    private Event3<string,string,int> m_OnLinkSelection;
    public HandlerState(string id){Id=id;m_OnCharacterSelection=new(id+"/Character");m_OnSpriteSelection=new(id+"/Sprite");m_OnWordSelection=new(id+"/Word");m_OnLineSelection=new(id+"/Line");m_OnLinkSelection=new(id+"/Link");}
    public Event2<char,int> onCharacterSelection=>m_OnCharacterSelection;public Event2<char,int> onSpriteSelection=>m_OnSpriteSelection;
    public Event3<string,int,int> onWordSelection=>m_OnWordSelection;public Event3<string,int,int> onLineSelection=>m_OnLineSelection;
    public Event3<string,string,int> onLinkSelection=>m_OnLinkSelection;
    public IEvent[] Events=>[m_OnCharacterSelection,m_OnSpriteSelection,m_OnWordSelection,m_OnLineSelection,m_OnLinkSelection];
    public TextState GetComponent(){Program.Trace.Add("GetComponent:"+Id);Program.Callback("GetComponent",Id);return new() {Id="text:"+Id};}
}
public sealed class CheckState(string id)
{
    public string Id=id;public HandlerState? TextEventHandler;public TextState? m_TextComponent;
    public void OnCharacterSelection(char c,int i)=>Program.Trace.Add($"Invoke:{Id}:OnCharacterSelection:{(int)c}:{i}");
    public void OnSpriteSelection(char c,int i)=>Program.Trace.Add($"Invoke:{Id}:OnSpriteSelection:{(int)c}:{i}");
    public void OnWordSelection(string s,int i,int n)=>Program.Trace.Add($"Invoke:{Id}:OnWordSelection:{s}:{i}:{n}");
    public void OnLineSelection(string s,int i,int n)=>Program.Trace.Add($"Invoke:{Id}:OnLineSelection:{s}:{i}:{n}");
    public void OnLinkSelection(string id,string label,int i)=>Program.Trace.Add($"Invoke:{Id}:OnLinkSelection:{id}:{label}:{i}");
}
public sealed class Case {public string name {get;set;}="";public int handler {get;set;}=1;public string[] steps {get;set;}=["E:A"];public string callback {get;set;}="none";}
public static class Program
{
    public static Case Current=new();public static List<string> Trace=[];public static List<HandlerState> Handlers=[];public static CheckState Active=new("A");static bool changed;
    public static string Listener(Delegate a)=>((CheckState)a.Target!).Id+":"+a.Method.Name;
    public static void Registration(string op,string id,Delegate a)=>Trace.Add(op+":"+id+":"+Listener(a));
    public static void Callback(string op,string id)
    {
        if(changed)return;
        if(Current.callback=="replace-handler-on-truth"&&op=="Truth"||Current.callback=="replace-handler-on-getcomponent"&&op=="GetComponent"||Current.callback=="replace-handler-on-add-character"&&op=="Add"&&id.EndsWith("/Character")||Current.callback=="replace-handler-on-remove-character"&&op=="Remove"&&id.EndsWith("/Character"))
        {changed=true;var h=new HandlerState("handler-new");Handlers.Add(h);Active.TextEventHandler=h;}
    }
    public static bool NotEqual(UnityState? a,UnityState? b){if(b!=null)throw new NotSupportedException();Trace.Add("Eq:"+(a?.Id??"null"));var answer=a!=null&&a.Alive;Callback("Truth",a?.Id??"null");return answer;}
    static Type Map(MC.TypeReference t)
    {
        if(t is MC.GenericInstanceType g)
        {
            var args=g.GenericArguments.Select(Map).ToArray();string n=g.ElementType.FullName;
            if(n=="UnityEngine.Events.UnityAction`2")return typeof(Action<,>).MakeGenericType(args);
            if(n=="UnityEngine.Events.UnityAction`3")return typeof(Action<,,>).MakeGenericType(args);
            if(n=="UnityEngine.Events.UnityEvent`2")return typeof(Event2<,>).MakeGenericType(args);
            if(n=="UnityEngine.Events.UnityEvent`3")return typeof(Event3<,,>).MakeGenericType(args);
        }
        return t.FullName switch {"System.Void"=>typeof(void),"System.Boolean"=>typeof(bool),"System.Int32"=>typeof(int),"System.Char"=>typeof(char),"System.String"=>typeof(string),"System.Object"=>typeof(object),"System.IntPtr"=>typeof(nint),"UnityEngine.Object"=>typeof(UnityState),
            "TMPro.Examples.TMP_TextEventCheck"=>typeof(CheckState),"TMPro.TMP_TextEventHandler"=>typeof(HandlerState),"TMPro.TMP_Text"=>typeof(TextState),
            "TMPro.TMP_TextEventHandler/CharacterSelectionEvent"=>typeof(Event2<char,int>),"TMPro.TMP_TextEventHandler/SpriteSelectionEvent"=>typeof(Event2<char,int>),
            "TMPro.TMP_TextEventHandler/WordSelectionEvent"=>typeof(Event3<string,int,int>),"TMPro.TMP_TextEventHandler/LineSelectionEvent"=>typeof(Event3<string,int,int>),"TMPro.TMP_TextEventHandler/LinkSelectionEvent"=>typeof(Event3<string,string,int>),_=>throw new NotSupportedException(t.FullName)};
    }
    static FieldInfo Field(MC.FieldReference f)=>Map(f.DeclaringType).GetField(f.Name,BindingFlags.Instance|BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic)??throw new NotSupportedException(f.FullName);
    static MethodBase Method(MC.MethodReference m)
    {
        if(m.DeclaringType.FullName=="UnityEngine.Object")return typeof(Program).GetMethod(nameof(NotEqual))!;
        if(m.DeclaringType.FullName=="UnityEngine.Component")return typeof(HandlerState).GetMethod(nameof(HandlerState.GetComponent))!;
        var owner=Map(m.DeclaringType);
        if(m.Name==".ctor")return owner.GetConstructor([typeof(object),typeof(nint)])!;
        if(m.Name.StartsWith("get_"))return owner.GetProperty(m.Name[4..])!.GetMethod!;
        return owner.GetMethod(m.Name)??throw new NotSupportedException(m.FullName);
    }
    public static void Main(string[] args)
    {
        using var module=MC.ModuleDefinition.ReadModule(args[0]);var enable=(MC.MethodDefinition)module.LookupToken(0x060007B7);var disable=(MC.MethodDefinition)module.LookupToken(0x060007B8);
        var e=(Action<CheckState>)ActualCil.Emit(enable,Map,Field,Method).CreateDelegate(typeof(Action<CheckState>));var d=(Action<CheckState>)ActualCil.Emit(disable,Map,Field,Method).CreateDelegate(typeof(Action<CheckState>));var results=new List<object>();
        foreach(var c in JsonSerializer.Deserialize<List<Case>>(File.ReadAllText(args[1]))!)
        {
            Current=c;Trace=[];Handlers=[];changed=false;HandlerState? h=c.handler==0?null:new("handler"){Alive=c.handler==1};if(h!=null)Handlers.Add(h);
            var a=new CheckState("A"){TextEventHandler=h};var b=new CheckState("B"){TextEventHandler=h};string? error=null;
            try {foreach(var step in c.steps){Active=step.EndsWith("A")?a:b;(step.StartsWith("E")?e:d)(Active);foreach(var evt in Handlers.SelectMany(x=>x.Events).ToArray())evt.Fire();}}
            catch(Exception ex){error=ex.GetType().FullName+": "+ex.Message;}
            results.Add(new {name=c.name,trace=Trace.ToArray(),text_a=a.m_TextComponent?.Id,text_b=b.m_TextComponent?.Id,events=Handlers.SelectMany(x=>x.Events).ToDictionary(x=>x.Id,x=>x.Snapshot()),error});
        }
        File.WriteAllText(args[2],JsonSerializer.Serialize(new {scope="ACTUAL_EVENT_CIL_REAL_CLR_DELEGATES_CONTROLLED_EVENT_CONTRACT",input_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),method_tokens=new[]{"0x060007B7","0x060007B8"},source_instructions=enable.Body.Instructions.Count+disable.Body.Instructions.Count,all_source_instructions_emitted=true,unity_event_implementation_executed=false,unity_execution=false,results},new JsonSerializerOptions {WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new {cases=results.Count}));
    }
}
