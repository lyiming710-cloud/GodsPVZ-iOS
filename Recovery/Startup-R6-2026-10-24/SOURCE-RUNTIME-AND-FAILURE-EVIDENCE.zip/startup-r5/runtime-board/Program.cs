using System.Reflection;
using System.Reflection.Emit;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Serialization;
using MC=Mono.Cecil;using CIL=Mono.Cecil.Cil;

public sealed class BoardState { public float endTime;public bool isWon;public ConfigState boardConfig=new("config");public AudioState[] audioSource=[new()]; }
public sealed class ConfigState(string name) { public string Name=name; }
public sealed class SettlementState { public string Name="settlement"; }
public sealed class ManagerState
{
    private static ManagerState instance=new("manager");
    public string Id;public ManagerState(string id) { Id=id; }
    public static ManagerState GetInstance()=>instance;
    public static void Install(ManagerState value)=>instance=value;
    public SettlementState CreatSettlementScreen(ConfigState config)
    {
        Program.Trace.Add("Create:"+Id+":"+config.Name);
        if (Program.Current.callback=="replace-manager-on-create") Install(new("manager-new"));
        if (Program.Current.callback=="replace-config-on-create") Program.Board.boardConfig=new("config-new");
        if (Program.Current.callback=="replace-lawn-on-create") GlobalsState.gLawnApp=new("lawn-new");
        return new();
    }
    public void QuitBoard(BoardState board)=>Program.Trace.Add("Quit:"+Id);
}
public sealed class AudioState
{
    public float value;
    public float Volume { get { Program.Trace.Add("VolGet:"+Program.Bits(value));return value; }
        set { Program.Trace.Add("VolSet:"+Program.Bits(value));this.value=value; } }
}
public sealed class LawnState(string id)
{
    public string Id=id;
    public void Pass(SettlementState settlement,ConfigState config)
    {
        Program.Trace.Add("Pass:"+Id+":"+settlement.Name+":"+config.Name);
        if (Program.Current.callback=="replace-manager-on-pass") ManagerState.Install(new("manager-after-pass"));
    }
}
public static class GlobalsState { public static LawnState gLawnApp=new("lawn"); }
public sealed class Case
{
    public string name {get;set;}="";
    public string end {get;set;}="1";
    public string dt1 {get;set;}="0.1";
    public string dt2 {get;set;}="0.1";
    public string volume {get;set;}="1";
    public string bgm {get;set;}="0.8";
    public bool won {get;set;}=true;
    public string callback {get;set;}="none";
}
public static class Program
{
    public static Case Current=new();public static BoardState Board=new();public static List<string> Trace=[];static int times;
    public static float Number(string s)=>s switch { "NaN"=>float.NaN,"Inf"=>float.PositiveInfinity,"-Inf"=>float.NegativeInfinity,_=>float.Parse(s,System.Globalization.CultureInfo.InvariantCulture) };
    public static string Bits(float f)=>float.IsNaN(f)?"NaN":BitConverter.SingleToInt32Bits(f).ToString("X8");
    public static float Delta() { var value=Number(times++==0?Current.dt1:Current.dt2);Trace.Add("Time:"+Bits(value));return value; }
    public static float Bgm() { var value=Number(Current.bgm);Trace.Add("BGM:"+Bits(value));return value; }
    static readonly Dictionary<short,OpCode> Ops=typeof(OpCodes).GetFields(BindingFlags.Public|BindingFlags.Static).Where(f=>f.FieldType==typeof(OpCode)).Select(f=>(OpCode)f.GetValue(null)!).ToDictionary(o=>o.Value);
    static Type Map(MC.TypeReference t)
    {
        if (t is MC.ArrayType array) return Map(array.ElementType).MakeArrayType();
        return t.FullName switch { "System.Void"=>typeof(void),"System.Boolean"=>typeof(bool),"System.Single"=>typeof(float),"System.Int32"=>typeof(int),"System.IntPtr"=>typeof(nint),
            "Board"=>typeof(BoardState),"BoardConfig"=>typeof(ConfigState),"BoardManager"=>typeof(ManagerState),"SettlementUIController"=>typeof(SettlementState),
            "UnityEngine.AudioSource"=>typeof(AudioState),"GlobalStaticVars/LawnApp"=>typeof(LawnState),_=>throw new NotSupportedException(t.FullName) };
    }
    static FieldInfo Field(MC.FieldReference f)
    {
        Type owner=f.DeclaringType.FullName=="GlobalStaticVars"?typeof(GlobalsState):Map(f.DeclaringType);
        string name=f.Name=="<Instance>k__BackingField"?"instance":f.Name;
        return owner.GetField(name,BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance|BindingFlags.Static)??throw new NotSupportedException(f.FullName);
    }
    static MethodInfo Method(MC.MethodReference m)=> (m.DeclaringType.FullName+"::"+m.Name) switch
    {
        "UnityEngine.Time::get_deltaTime"=>typeof(Program).GetMethod(nameof(Delta))!,
        "GlobalStaticVars::BGMVolume"=>typeof(Program).GetMethod(nameof(Bgm))!,
        "UnityEngine.AudioSource::get_volume"=>typeof(AudioState).GetProperty(nameof(AudioState.Volume))!.GetMethod!,
        "UnityEngine.AudioSource::set_volume"=>typeof(AudioState).GetProperty(nameof(AudioState.Volume))!.SetMethod!,
        "BoardManager::get_Instance"=>typeof(ManagerState).GetMethod(nameof(ManagerState.GetInstance))!,
        "BoardManager::CreatSettlementScreen"=>typeof(ManagerState).GetMethod(nameof(ManagerState.CreatSettlementScreen))!,
        "BoardManager::QuitBoard"=>typeof(ManagerState).GetMethod(nameof(ManagerState.QuitBoard))!,
        "GlobalStaticVars/LawnApp::Pass"=>typeof(LawnState).GetMethod(nameof(LawnState.Pass))!,_=>throw new NotSupportedException(m.FullName)
    };
    static Action<BoardState> Bind(MC.MethodDefinition source)
    {
        if (source.Body.ExceptionHandlers.Count!=0) throw new NotSupportedException("EH omitted");
        var a=AssemblyBuilder.DefineDynamicAssembly(new AssemblyName("ActualBoardCIL_"+Guid.NewGuid().ToString("N")),AssemblyBuilderAccess.Run);
        var t=a.DefineDynamicModule("ActualBoardCIL").DefineType("Rehosted.ActualBoardCaller",TypeAttributes.Public|TypeAttributes.Abstract|TypeAttributes.Sealed);
        var m=t.DefineMethod("Execute",MethodAttributes.Public|MethodAttributes.Static,typeof(void),[typeof(BoardState)]);m.InitLocals=source.Body.InitLocals;
        var il=m.GetILGenerator();var locals=source.Body.Variables.Select(v=>il.DeclareLocal(Map(v.VariableType))).ToArray();var labels=source.Body.Instructions.ToDictionary(i=>i,_=>il.DefineLabel());
        foreach (var i in source.Body.Instructions)
        {
            il.MarkLabel(labels[i]);var op=Ops[i.OpCode.Value];
            switch (i.Operand)
            {
                case null:il.Emit(op);break;
                case int value:il.Emit(op,value);break;
                case float value:il.Emit(op,value);break;
                case string value:il.Emit(op,value);break;
                case CIL.Instruction target:il.Emit(op,labels[target]);break;
                case CIL.VariableDefinition local:il.Emit(op,locals[local.Index]);break;
                case MC.TypeReference type:il.Emit(op,Map(type));break;
                case MC.FieldReference field:il.Emit(op,Field(field));break;
                case MC.MethodReference method:il.Emit(op,Method(method));break;
                default:throw new NotSupportedException(i.ToString());
            }
        }
        // Forensic switch only: never used in qualification. Tests whether an
        // unreachable unterminated warning tail alone causes CLR rejection.
        if (Environment.GetEnvironmentVariable("CIL_DIAGNOSTIC_APPEND_RET")=="1") il.Emit(OpCodes.Ret);
        return (Action<BoardState>)t.CreateType()!.GetMethod("Execute")!.CreateDelegate(typeof(Action<BoardState>));
    }
    public static void Main(string[] args)
    {
        using var module=MC.ModuleDefinition.ReadModule(args[0]);var source=(MC.MethodDefinition)module.LookupToken(0x060002AD);var call=Bind(source);
        var cases=JsonSerializer.Deserialize<List<Case>>(File.ReadAllText(args[1]))!;var results=new List<object>();
        foreach (var c in cases)
        {
            Current=c;Trace=[];times=0;Board=new() { endTime=Number(c.end),isWon=c.won,audioSource=[new AudioState { value=Number(c.volume) }] };
            ManagerState.Install(new("manager"));GlobalsState.gLawnApp=new("lawn");string? error=null;
            try { call(Board); } catch (Exception e) { error=e.GetType().FullName+": "+e.Message; }
            results.Add(new { name=c.name,trace=Trace.ToArray(),end_time=Bits(Board.endTime),volume=Bits(Board.audioSource[0].value),manager_id=ManagerState.GetInstance().Id,error });
        }
        var report=new { scope="ACTUAL_CANDIDATE_BOARD_CIL_CONCRETE_CLR_EMISSION_CONTROLLED_CALLEES",input_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),
            method_token="0x060002AD",source_instructions=source.Body.Instructions.Count,diagnostic_appended_ret=Environment.GetEnvironmentVariable("CIL_DIAGNOSTIC_APPEND_RET")=="1",exceptions_native_unwind_modeled=false,unity_execution=false,results };
        File.WriteAllText(args[2],JsonSerializer.Serialize(report,new JsonSerializerOptions { WriteIndented=true }));Console.WriteLine(JsonSerializer.Serialize(new { cases=results.Count,report.input_sha256 }));
    }
}
