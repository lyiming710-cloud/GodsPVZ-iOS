from pathlib import Path
import hashlib,json,subprocess,sys,struct,itertools
Q=Path(__file__).resolve().parent;ROOT=Q.parents[2];OUT=Q.parent/'startup-r6/buff-runtime-results';OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'));import dnfile
cases=[]
def case(name,**kw):return dict(dict(name=name,zombie=1,board=1,attack='1',atk='1',defense='1',armor1=0,armor2=0,d1='2',d2='3',increments=['0','0','0','0']),**kw)
for attack,atk,flags,defense,incs in itertools.product(['0','-0','1','-1','NaN','Inf'],['0','1','-1','NaN','Inf'],[(0,0),(1,0),(0,1),(1,1)],['0','1','-1','NaN','Inf','-5'],[['0','0','0','0'],['0.25','1','-2','0.5']]):
    c=case('grid-'+str(len(cases)));c.update(attack=attack,atk=atk,armor1=flags[0],armor2=flags[1],defense=defense,increments=incs);cases.append(c)
for z,b in [(0,1),(2,1),(1,0),(1,2)]:
    c=case(f'object-{z}-{b}');c.update(zombie=z,board=b);cases.append(c)
for field in ['d1','d2']:
    for value in ['0','NaN','Inf','-Inf']:
        c=case(field+'-'+value);c.update(armor1=1,armor2=1);c[field]=value;cases.append(c)
(OUT/'CASES.json').write_bytes((json.dumps(cases,indent=2)+'\n').encode());dot=ROOT/'.local/dotnet10/dotnet.exe';fixture=Q/'runtime-buff/bin/Release/net10.0/Fixture.dll';candidate=Q.parent/'startup-r6/candidate1.dll';raw=candidate.read_bytes();sha=hashlib.sha256(raw).hexdigest();assert sha=='c36092b5326687112adfa8c285bb3cf5e8ad46d3b3de8ebcd84daf598041465d'
def run(label,args):
    p=subprocess.run(args,capture_output=True);(OUT/(label+'.stdout.log')).write_bytes(p.stdout);(OUT/(label+'.stderr.log')).write_bytes(p.stderr)
    if p.returncode:raise RuntimeError(f'{label} exit={p.returncode}: '+p.stderr.decode('utf-8','replace')[:900])
run('native',[sys.executable,str(Q/'native_buff_oracle.py'),str(OUT/'CASES.json'),str(OUT/'NATIVE.json')])
run('actual-cil',[str(dot),str(fixture),str(candidate),str(OUT/'CASES.json'),str(OUT/'ACTUAL-CIL.json')])
native=json.loads((OUT/'NATIVE.json').read_bytes())['results'];cil=json.loads((OUT/'ACTUAL-CIL.json').read_bytes())['results'];assert len(native)==len(cil)==len(cases)
diff=[dict(name=a['name'],native=a,cil=b) for a,b in zip(native,cil) if a!=b]
pe=dnfile.dnPE(data=raw);start=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[0x5E7-1].Rva);body=start+(struct.unpack_from('<H',raw,start)[0]>>12)*4;mutants={}
b=bytearray(raw);assert b[body+344]==0x5b;b[body+344]=0x5a;mutants['attack-ratio-multiplied']=bytes(b)
b=bytearray(raw);assert b[body+212]==0x22;b[body+212]=0x20;mutants['integer-zero-restored']=bytes(b)
b=bytearray(raw)
for at in [279,819]:b[body+at:body+at+9]=b'\x21'+struct.pack('<q',4294967295)
mutants['int64-sentinel-restored']=bytes(b)
b=bytearray(raw);b[body:body+5]=b'\x2a\0\0\0\0';mutants['early-return']=bytes(b)
controls=[]
def control(name,dll,digest):
    run(name,[str(dot),str(fixture),str(dll),str(OUT/'CASES.json'),str(OUT/(name+'.json'))]);r=json.loads((OUT/(name+'.json')).read_bytes())['results'];detected=sum(a!=b for a,b in zip(native,r));controls.append(dict(name=name,mutant_sha256=digest,detected_cases=detected,baseline_pass=not diff,pass_=not diff and detected>0))
for name,data in mutants.items():
    dll=OUT/(name+'.dll');dll.write_bytes(data);control(name,dll,hashlib.sha256(data).hexdigest())
parent=Q/'candidate1.dll';control('parent-unterminated-tail',parent,hashlib.sha256(parent.read_bytes()).hexdigest())
width=json.loads((OUT.parent/'INT64-NEGATIVE-WIDTH.json').read_bytes())
sentinel=next(c for c in controls if c['name']=='int64-sentinel-restored')
assert width['mutant_sha256']==sentinel['mutant_sha256'] and width['baseline_passed'] and width['rejected']
sentinel['runtime_status']='NOT_DETECTED_BY_CLR_PERMISSIVE_TRUNCATION'
sentinel['required_independent_gate']='UNCHANGED_FROZEN_WIDTH_GATE'
semantic_controls=[c for c in controls if c['name']!='int64-sentinel-restored']
report=dict(scope='BUFF_COMBINED_RUNTIME_AND_UNCHANGED_FROZEN_WIDTH_GATE_CONTROLLED_CALLEES_ONLY',candidate_sha256=sha,method_token='0x060005E7',cases=len(cases),
            pass_=not diff and all(c['pass_'] for c in semantic_controls) and width['rejected'],runtime_equivalence_pass=not diff,
            runtime_alone_adequate=False,width_negative_control=width,differences=diff,negative_controls=controls,exceptions_native_unwind_modeled=False,unity_execution=False,whole_six_method_acceptance=False)
(OUT/'RESULT.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({**report,'differences':diff[:3]},indent=2));assert report['pass_']
