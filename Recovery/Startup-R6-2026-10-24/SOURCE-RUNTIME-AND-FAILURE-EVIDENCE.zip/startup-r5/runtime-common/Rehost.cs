using System.Reflection;using System.Reflection.Emit;using MC=Mono.Cecil;using CIL=Mono.Cecil.Cil;
// Executes the complete candidate instruction stream. No dead-code pruning,
// appended ret, changed branches, private-access bypass, or exception skipping.
public static class ActualCil
{
    static readonly Dictionary<short,OpCode> Ops=typeof(OpCodes).GetFields(BindingFlags.Public|BindingFlags.Static).Where(f=>f.FieldType==typeof(OpCode)).Select(f=>(OpCode)f.GetValue(null)!).ToDictionary(o=>o.Value);
    static MC.TypeReference Close(MC.TypeReference t,MC.MethodReference owner)
    {
        if(t is MC.GenericParameter gp)
        {
            if(gp.Type==MC.GenericParameterType.Method&&owner is MC.GenericInstanceMethod gm)return gm.GenericArguments[gp.Position];
            if(gp.Type==MC.GenericParameterType.Type&&owner.DeclaringType is MC.GenericInstanceType gt)return gt.GenericArguments[gp.Position];
            throw new NotSupportedException("Unclosed callee parameter: "+t.FullName);
        }
        if(t is MC.ByReferenceType b)return new MC.ByReferenceType(Close(b.ElementType,owner));
        if(t is MC.ArrayType ar)return new MC.ArrayType(Close(ar.ElementType,owner),ar.Rank);
        if(t is MC.GenericInstanceType g){var c=new MC.GenericInstanceType(g.ElementType);foreach(var a in g.GenericArguments)c.GenericArguments.Add(Close(a,owner));return c;}
        return t;
    }
    public static MethodInfo Emit(MC.MethodDefinition source,Func<MC.TypeReference,Type> map,Func<MC.FieldReference,FieldInfo> field,Func<MC.MethodReference,MethodBase> method)
    {
        if(source.Body.ExceptionHandlers.Count!=0)throw new NotSupportedException("Unmodeled EH is prohibited");
        var a=AssemblyBuilder.DefineDynamicAssembly(new AssemblyName("ActualCIL_"+Guid.NewGuid().ToString("N")),AssemblyBuilderAccess.Run);
        var t=a.DefineDynamicModule("ActualCIL").DefineType("Rehosted.Caller",TypeAttributes.Public|TypeAttributes.Abstract|TypeAttributes.Sealed);
        var args=(source.HasThis?new[]{map(source.DeclaringType)}:Array.Empty<Type>()).Concat(source.Parameters.Select(p=>map(p.ParameterType))).ToArray();
        var m=t.DefineMethod("Execute",MethodAttributes.Public|MethodAttributes.Static,map(source.ReturnType),args);m.InitLocals=source.Body.InitLocals;
        var il=m.GetILGenerator();var locals=source.Body.Variables.Select(v=>il.DeclareLocal(map(v.VariableType))).ToArray();var labels=source.Body.Instructions.ToDictionary(i=>i,_=>il.DefineLabel());
        foreach(var i in source.Body.Instructions)
        {
            il.MarkLabel(labels[i]);var op=Ops[i.OpCode.Value];
            switch(i.Operand)
            {
                case null:il.Emit(op);break;case sbyte v:il.Emit(op,v);break;case byte v:il.Emit(op,v);break;
                case int v:il.Emit(op,v);break;case long v:il.Emit(op,v);break;case float v:il.Emit(op,v);break;case double v:il.Emit(op,v);break;case string v:il.Emit(op,v);break;
                case CIL.Instruction v:il.Emit(op,labels[v]);break;case CIL.Instruction[] v:il.Emit(op,v.Select(x=>labels[x]).ToArray());break;
                case CIL.VariableDefinition v:il.Emit(op,locals[v.Index]);break;
                case MC.ParameterDefinition v:il.Emit(op,(short)(v.Index+(source.HasThis?1:0)));break;
                case MC.TypeReference v:il.Emit(op,map(v));break;
                case MC.FieldReference v:
                    var f=field(v);if(f.FieldType!=map(v.FieldType))throw new InvalidOperationException("Changed field contract: "+v.FullName);il.Emit(op,f);break;
                case MC.MethodReference v:
                    var callee=method(v);var parameters=v.Parameters.Select(p=>map(Close(p.ParameterType,v))).ToArray();
                    if(!parameters.SequenceEqual(callee.GetParameters().Select(p=>p.ParameterType))||v.HasThis==callee.IsStatic)throw new InvalidOperationException("Changed callee signature: "+v.FullName);
                    if(callee is ConstructorInfo ctor)il.Emit(op,ctor);
                    else { var mi=(MethodInfo)callee;if(mi.ReturnType!=map(Close(v.ReturnType,v)))throw new InvalidOperationException("Changed callee return: "+v.FullName);il.Emit(op,mi); }
                    break;
                default:throw new NotSupportedException(i.ToString());
            }
        }
        return t.CreateType()!.GetMethod("Execute")!;
    }
}
