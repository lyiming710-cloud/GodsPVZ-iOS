using System.Reflection;
using System.Reflection.Emit;
using System.Security.Cryptography;
using System.Text.Json;
using MC=Mono.Cecil;
using CIL=Mono.Cecil.Cil;

// Top-level types keep actual private-member visibility boundaries in the CLR.
public class UnityState { public bool Alive=true; public string Id=""; }
public sealed class BoardState : UnityState { public int challengeType=2,level=3; }
public sealed class ManagerState : UnityState
{
    private static ManagerState? instance;
    public int challengeType=5,level=6;
    public static ManagerState? GetInstance()=>instance;
    public static void Install(ManagerState? value)=>instance=value;
}
public sealed class SystemState { public int challengeType=-99,level=-99; public ConfigState? boardConfig; }
public sealed class SaveState { public int adventureLevel=10; }
public sealed class SavesState { public SaveState playerSave=new(); }
public sealed class LawnState { public SavesState savesManager=new(); }
public static class GlobalsState { public static LawnState gLawnApp=new(); }
public sealed class AdminState { public SystemState system2=new(); }
public sealed class ConfigState
{
    public string Kind="json";public int Width,Height;
    public ConfigState() { }
    public ConfigState(int x,int y)
    {
        Kind="default";Width=x;Height=y;Program.Trace.Add($"Ctor:{x}:{y}");
        if (Program.Current.callback=="new-system2-at-constructor") Program.Owner.system2=new();
    }
}
public sealed class Case
{
    public string name {get;set;}="";
    public int board {get;set;}
    public int manager {get;set;}
    public string json {get;set;}="value";
    public string callback {get;set;}="none";
}
public static class Program
{
    public static List<string> Trace=[];
    public static Case Current=new();public static AdminState Owner=new();
    public static BoardState? Board;public static ManagerState? Manager;
    public static bool Equal(UnityState? a,UnityState? b)
    {
        Trace.Add("Eq:"+(a?.Id??"null"));
        if (b!=null) throw new NotSupportedException("Only null comparison is in this source CIL");
        return a==null || !a.Alive;
    }
    public static bool Truth(UnityState? value)
    {
        Trace.Add("Truth:"+(value?.Id??"null"));bool result=value?.Alive??false;
        if (Current.callback=="replace-manager-on-truth") ManagerState.Install(new ManagerState { Id="manager-new",challengeType=13,level=14 });
        return result;
    }
    public static string PathFor(int challenge,int level)
    {
        Trace.Add($"Path:{challenge}:{level}");
        if (Current.callback=="mutate-selected")
        {
            if (Current.board==1) { Board!.challengeType=7;Board.level=11; }
            else { Manager!.challengeType=9;Manager.level=12; }
        }
        if (Current.callback=="new-system2-at-path") Owner.system2=new();
        if (Current.callback=="advance-save-at-path") GlobalsState.gLawnApp.savesManager.playerSave.adventureLevel=17;
        if (Current.callback=="new-save-at-path") GlobalsState.gLawnApp.savesManager.playerSave=new SaveState { adventureLevel=19 };
        return $"path:{challenge}:{level}";
    }
    public static string? Read(string path)
    {
        Trace.Add("Read:"+path);
        return Current.json switch { "null"=>null,"empty"=>"",_=>"{controlled-json}" };
    }
    public static ConfigState Parse(string input)
    {
        if (input!="{controlled-json}") throw new InvalidOperationException("Unexpected JSON outside controlled contract");
        Trace.Add("Parse");return new ConfigState();
    }
    public static void Log(object value)=>Trace.Add("Log"); // Text equivalence is explicitly outside this oracle.
    static readonly Dictionary<string,OpCode> Ops=typeof(OpCodes).GetFields(BindingFlags.Public|BindingFlags.Static)
        .Where(f=>f.FieldType==typeof(OpCode)).Select(f=>(OpCode)f.GetValue(null)!).ToDictionary(o=>o.Name!);
    static Type Map(MC.TypeReference type)=>type.FullName switch
    {
        "System.Void"=>typeof(void),"System.Boolean"=>typeof(bool),"System.Int32"=>typeof(int),"ChallengeType"=>typeof(int),
        "System.String"=>typeof(string),"System.Object"=>typeof(object),"System.IntPtr"=>typeof(nint),
        "Board"=>typeof(BoardState),"BoardManager"=>typeof(ManagerState),"Administrator"=>typeof(AdminState),
        "System2"=>typeof(SystemState),"SavesManager"=>typeof(SavesState),"Save"=>typeof(SaveState),
        "GlobalStaticVars/LawnApp"=>typeof(LawnState),"BoardConfig"=>typeof(ConfigState),"UnityEngine.Object"=>typeof(UnityState),
        _=>throw new NotSupportedException("Type: "+type.FullName)
    };
    static FieldInfo Field(MC.FieldReference field)
    {
        Type owner=field.DeclaringType.FullName=="GlobalStaticVars"?typeof(GlobalsState):Map(field.DeclaringType);
        string name=field.Name=="<Instance>k__BackingField"?"instance":field.Name;
        return owner.GetField(name,BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Static|BindingFlags.Instance)??throw new NotSupportedException(field.FullName);
    }
    static MethodBase Method(MC.MethodReference method)
    {
        string key=method.DeclaringType.FullName+"::"+method.Name;
        return key switch
        {
            "UnityEngine.Object::op_Equality"=>typeof(Program).GetMethod(nameof(Equal))!,
            "UnityEngine.Object::op_Implicit"=>typeof(Program).GetMethod(nameof(Truth))!,
            "ResourceManager::GetBoardConfigPath"=>typeof(Program).GetMethod(nameof(PathFor))!,
            "InternalResourceLoader::ReadJson_StreamingAssets"=>typeof(Program).GetMethod(nameof(Read))!,
            "UnityEngine.JsonUtility::FromJson"=>typeof(Program).GetMethod(nameof(Parse))!,
            "UnityEngine.Debug::Log"=>typeof(Program).GetMethod(nameof(Log))!,
            "System.String::IsNullOrEmpty"=>typeof(string).GetMethod(nameof(string.IsNullOrEmpty),[typeof(string)])!,
            "BoardManager::get_Instance"=>typeof(ManagerState).GetMethod(nameof(ManagerState.GetInstance))!,
            "BoardConfig::.ctor"=>typeof(ConfigState).GetConstructor([typeof(int),typeof(int)])!,
            _=>throw new NotSupportedException("Method: "+method.FullName)
        };
    }
    static Action<AdminState,BoardState?> Bind(MC.MethodDefinition source)
    {
        if (source.Body.ExceptionHandlers.Count!=0) throw new NotSupportedException("No EH may be omitted");
        var assembly=AssemblyBuilder.DefineDynamicAssembly(new AssemblyName("ActualAdminCIL_"+Guid.NewGuid().ToString("N")),AssemblyBuilderAccess.Run);
        var type=assembly.DefineDynamicModule("ActualAdminCIL").DefineType("Rehosted.ActualAdminCaller",TypeAttributes.Public|TypeAttributes.Abstract|TypeAttributes.Sealed);
        // Static entry arguments retain source ldarg.0=this and ldarg.1=Board.
        var entry=type.DefineMethod("Execute",MethodAttributes.Public|MethodAttributes.Static,typeof(void),[typeof(AdminState),typeof(BoardState)]);
        entry.InitLocals=source.Body.InitLocals;var il=entry.GetILGenerator();
        var locals=source.Body.Variables.Select(v=>il.DeclareLocal(Map(v.VariableType))).ToArray();
        var labels=source.Body.Instructions.ToDictionary(i=>i,_=>il.DefineLabel());
        foreach (var instruction in source.Body.Instructions)
        {
            il.MarkLabel(labels[instruction]);OpCode op=Ops[instruction.OpCode.Name];
            switch (instruction.Operand)
            {
                case null:il.Emit(op);break;
                case int value:il.Emit(op,value);break;
                case long value:il.Emit(op,value);break;
                case string value:il.Emit(op,value);break;
                case CIL.Instruction target:il.Emit(op,labels[target]);break;
                case CIL.VariableDefinition variable:il.Emit(op,locals[variable.Index]);break;
                case MC.ParameterDefinition parameter:il.Emit(op,(short)(parameter.Index+(source.HasThis?1:0)));break;
                case MC.FieldReference field:il.Emit(op,Field(field));break;
                case MC.MethodReference method:
                    if (Method(method) is ConstructorInfo constructor) il.Emit(op,constructor);
                    else il.Emit(op,(MethodInfo)Method(method));
                    break;
                default:throw new NotSupportedException(instruction.ToString());
            }
        }
        var created=type.CreateType()!;
        return (Action<AdminState,BoardState?>)created.GetMethod("Execute")!.CreateDelegate(typeof(Action<AdminState,BoardState?>));
    }
    static object Snapshot(SystemState value)=>new { challenge=value.challengeType,level=value.level,config=value.boardConfig?.Kind,
        width=value.boardConfig?.Width??0,height=value.boardConfig?.Height??0 };
    public static void Main(string[] args)
    {
        if (args.Length!=3) throw new ArgumentException("DLL cases.json report.json");
        using var module=MC.ModuleDefinition.ReadModule(args[0]);
        var method=(MC.MethodDefinition)module.LookupToken(0x06000009);
        var call=Bind(method);var cases=JsonSerializer.Deserialize<List<Case>>(File.ReadAllText(args[1]))!;var results=new List<object>();
        foreach (var c in cases)
        {
            Current=c;Trace=[];Owner=new();SystemState initial=Owner.system2;
            Board=c.board==0?null:new BoardState { Alive=c.board==1,Id="board" };
            Manager=c.manager==0?null:new ManagerState { Alive=c.manager==1,Id="manager" };
            ManagerState.Install(Manager);GlobalsState.gLawnApp=new();string? error=null;
            try { call(Owner,Board); }
            catch (Exception e) { error=e.GetType().FullName+": "+e.Message; }
            var currentManager=ManagerState.GetInstance();
            results.Add(new { name=c.name,trace=Trace.ToArray(),current=Snapshot(Owner.system2),initial=Snapshot(initial),
                save_level=GlobalsState.gLawnApp.savesManager.playerSave.adventureLevel,
                manager_challenge=currentManager?.challengeType,manager_level=currentManager?.level,error });
        }
        var report=new { scope="ACTUAL_CANDIDATE_CIL_CONCRETE_CLR_EMISSION_CONTROLLED_CALLEES",input_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),
            method_token="0x06000009",source_instructions=method.Body.Instructions.Count,source_locals=method.Body.Variables.Select(v=>v.VariableType.FullName),
            exceptions_native_unwind_modeled=false,log_text_equivalence=false,unity_execution=false,results };
        File.WriteAllText(args[2],JsonSerializer.Serialize(report,new JsonSerializerOptions { WriteIndented=true }));
        Console.WriteLine(JsonSerializer.Serialize(new { report.input_sha256,cases=results.Count,report.source_instructions }));
    }
}
