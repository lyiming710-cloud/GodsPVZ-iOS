"""Four already-authorized target methods only; remove unreachable bad tails.

Physical same-length patches. No metadata/header/RVA/target/other byte changes.
The R5 Board CLR rejection and diagnostic-only appended-ret comparison remain
archived separately and are not counted as a passing R5 candidate.
"""
from pathlib import Path
import hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;ROOT=Q.parents[2];O=Q.parent/'startup-r6';O.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
sha=lambda b:hashlib.sha256(b).hexdigest()
raw=(Q/'candidate1.dll').read_bytes();assert sha(raw)=='7fa02b81d4d1af579a18eea103f776493f012565e64d5b38fd885cf40718a296'
cil=json.loads((Q/'SIX-CIL.json').read_bytes());pe=dnfile.dnPE(data=raw);out=bytearray(raw);changes=[]
for token in ['0x060002AD','0x060005E7','0x060007B7','0x060007B8']:
    method=next(m for m in cil['methods'] if m['token']==token);ins=method['instructions'];assert not method['handlers']
    by_offset={i['offset']:i for i in ins};ordered=list(by_offset);successors={}
    for n,at in enumerate(ordered):
        i=by_offset[at];op=i['opcode'];following=ordered[n+1:n+2]
        if op in ['ret','throw','rethrow','endfinally','endfilter','jmp']:to=[]
        elif op in ['br','br.s','leave','leave.s']:to=[i['operand']['target']]
        elif op.startswith('br') or op.split('.')[0] in ['beq','bge','bgt','ble','blt','bne']:to=[i['operand']['target']]+following
        elif op=='switch':raise AssertionError('Switch requires separately audited handling')
        else:to=following
        assert all(x in by_offset for x in to);successors[at]=to
    reached=set();pending=[0]
    while pending:
        at=pending.pop()
        if at in reached:continue
        reached.add(at);pending+=successors[at]
    first,last=ins[-2:];assert first['opcode']=='ldstr' and last['opcode']=='pop' and last['offset']==first['offset']+5
    assert first['operand'].startswith('Warning: Method ends with non empty stack')
    assert not {first['offset'],last['offset']}&reached
    assert all(successors[x] or by_offset[x]['opcode'] in ['ret','throw','rethrow','endfinally','endfilter','jmp'] for x in reached)
    rid=int(token,16)&0xffffff;start=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[rid-1].Rva)
    header=(struct.unpack_from('<H',raw,start)[0]>>12)*4;size=struct.unpack_from('<I',raw,start+4)[0]
    at=start+header+first['offset'];assert size==last['offset']+1 and raw[at]==0x72 and raw[at+5]==0x26
    replacement=b'\0'*5+b'\x2a';out[at:at+6]=replacement
    changes.append(dict(token=token,file_offset=at,il_offset=first['offset'],before=raw[at:at+6].hex(),after=replacement.hex(),
                        reached_instruction_count=len(reached),unreachable_tail_proven=True,exception_handlers=0,code_size=size,header_bytes=header))
result=bytes(out);allowed={i for c in changes for i in range(c['file_offset'],c['file_offset']+6)}
assert len(result)==len(raw) and all(a==b or i in allowed for i,(a,b) in enumerate(zip(raw,result)))
for n in [1,2]:(O/f'candidate{n}.dll').write_bytes(result)
report=dict(scope='FOUR_PREVIOUSLY_AUTHORIZED_METHODS_UNREACHABLE_TAIL_TERMINATION_ONLY',parent_sha256=sha(raw),candidate_sha256=sha(result),bytes=len(result),
            methods_changed=4,unchanged_methoddefs=2313,metadata_headers_rvas_unchanged=True,all_other_file_bytes_identical=True,changes=changes,
            runtime_qualification='PENDING_R6',unity_or_il2cpp='NOT_RUN',ipa=None)
(O/'CONSTRUCTION.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(report,indent=2))
