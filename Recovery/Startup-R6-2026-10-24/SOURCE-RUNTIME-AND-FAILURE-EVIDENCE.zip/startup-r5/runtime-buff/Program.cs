using System.Reflection;using System.Security.Cryptography;using System.Text.Json;using System.Globalization;using MC=Mono.Cecil;
public class UnityState {public bool Alive=true;public string Id="";}
public sealed class BoardState:UnityState {}
public sealed class ZombieState:UnityState
{
    public BoardState? board;public BuffState buffManager=new();private float attackPoint;
    public float defense,armor1Defense,armor2Defense;public int armor1Type,armor2Type;
    public void InstallAttack(float value)=>attackPoint=value;
    public float AttackPoint()=>attackPoint;
    public float GetATK(){float v=Program.Number(Program.Current.atk);Program.Trace.Add("ATK:"+Program.Bits(v));return v;}
}
public sealed class BuffState
{
    public float GetIncrement(float value,string key)
    {
        var result=Program.Number(Program.Current.increments[Program.Index++]);Program.Trace.Add("Inc:"+key+":"+Program.Bits(value)+":"+Program.Bits(result));return result;
    }
}
public sealed class UIState
{
    public ZombieState? zombie;
    public void SetStatsImageSet(int index,float value)=>Program.Trace.Add("Float:"+index+":"+Program.Bits(value));
    public void SetStatsImageSet(int a,int b,int c)=>Program.Trace.Add($"Int:{a}:{b}:{c}");
}
public sealed class Case
{
    public string name {get;set;}="";public int zombie {get;set;}=1;public int board {get;set;}=1;
    public string attack {get;set;}="1";public string atk {get;set;}="1";public string defense {get;set;}="1";
    public int armor1 {get;set;}public int armor2 {get;set;}public string d1 {get;set;}="2";public string d2 {get;set;}="3";
    public string[] increments {get;set;}=["0","0","0","0"];
}
public static class Program
{
    public static Case Current=new();public static List<string> Trace=[];public static int Index;
    public static float Number(string s)=>s switch {"NaN"=>float.NaN,"Inf"=>float.PositiveInfinity,"-Inf"=>float.NegativeInfinity,_=>float.Parse(s,CultureInfo.InvariantCulture)};
    public static string Bits(float v)=>float.IsNaN(v)?"NaN":BitConverter.SingleToInt32Bits(v).ToString("X8");
    public static bool NotEqual(UnityState? a,UnityState? b) {if(b!=null)throw new NotSupportedException();Trace.Add("Eq:"+(a?.Id??"null"));return a!=null&&a.Alive;}
    static Type Map(MC.TypeReference t)=>t.FullName switch {"System.Void"=>typeof(void),"System.Boolean"=>typeof(bool),"System.Int32"=>typeof(int),"Armor1Type"=>typeof(int),"Armor2Type"=>typeof(int),"System.Single"=>typeof(float),"System.String"=>typeof(string),
        "UnityEngine.Object"=>typeof(UnityState),"Board"=>typeof(BoardState),"Zombie"=>typeof(ZombieState),"BuffManager"=>typeof(BuffState),"BuffUIController_Zombie"=>typeof(UIState),_=>throw new NotSupportedException(t.FullName)};
    static FieldInfo Field(MC.FieldReference f)=>Map(f.DeclaringType).GetField(f.Name,BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance|BindingFlags.Static)??throw new NotSupportedException(f.FullName);
    static MethodBase Method(MC.MethodReference m)
    {
        if(m.DeclaringType.FullName=="UnityEngine.Object")return typeof(Program).GetMethod(nameof(NotEqual))!;
        Type owner=Map(m.DeclaringType);return owner.GetMethod(m.Name,m.Parameters.Select(p=>Map(p.ParameterType)).ToArray())??throw new NotSupportedException(m.FullName);
    }
    public static void Main(string[] args)
    {
        using var module=MC.ModuleDefinition.ReadModule(args[0]);var source=(MC.MethodDefinition)module.LookupToken(0x060005E7);var call=(Action<UIState>)ActualCil.Emit(source,Map,Field,Method).CreateDelegate(typeof(Action<UIState>));var results=new List<object>();
        foreach(var c in JsonSerializer.Deserialize<List<Case>>(File.ReadAllText(args[1]))!)
        {
            Current=c;Trace=[];Index=0;var z=c.zombie==0?null:new ZombieState {Alive=c.zombie==1,Id="zombie",board=c.board==0?null:new BoardState {Alive=c.board==1,Id="board"},defense=Number(c.defense),armor1Type=c.armor1,armor2Type=c.armor2,armor1Defense=Number(c.d1),armor2Defense=Number(c.d2)};
            z?.InstallAttack(Number(c.attack));var ui=new UIState {zombie=z};string? error=null;try {call(ui);}catch(Exception e){error=e.GetType().FullName+": "+e.Message;}
            results.Add(new {name=c.name,trace=Trace.ToArray(),error});
        }
        File.WriteAllText(args[2],JsonSerializer.Serialize(new {scope="ACTUAL_BUFF_CIL_NONMUTATING_CONTROLLED_CALLEES",input_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),method_token="0x060005E7",source_instructions=source.Body.Instructions.Count,all_source_instructions_emitted=true,unity_execution=false,results},new JsonSerializerOptions {WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new {cases=results.Count}));
    }
}
