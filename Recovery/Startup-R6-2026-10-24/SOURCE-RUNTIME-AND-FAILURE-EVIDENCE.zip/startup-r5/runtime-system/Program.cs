using System.Reflection;using System.Security.Cryptography;using System.Text.Json;using System.Globalization;using MC=Mono.Cecil;
public sealed class RowState { public int EnemyType=-99; }
public sealed class MapState { public List<RowState> rows=[new(),new(),new()]; }
public sealed class ConfigState { public MapState map=new();public MapState Map()=>map; }
public sealed class SystemState { public ConfigState boardConfig=new(); }
public sealed class InputState
{
    private string? m_Text;public string? Name;
    public void Install(string? value)=>m_Text=value;
    public string? Text=>m_Text;
    public string? GetName()
    {
        Program.Trace.Add("Name");
        if(Program.Current.callback=="replace-config-on-name")Program.Owner.boardConfig=new();
        if(Program.Current.callback=="mutate-text-on-name")Install("17");
        return Name;
    }
}
public sealed class Case { public string name {get;set;}="";public string? input_name {get;set;}public string? text {get;set;}public string callback {get;set;}="none"; }
public static class Program
{
    public static Case Current=new();public static SystemState Owner=new();public static List<string> Trace=[];
    public static bool Parse(string? value,out int answer) { var ok=int.TryParse(value,out answer);Trace.Add("Parse:"+(value==null?"<null>":Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(value)))+":"+(ok?"1":"0")+":"+answer);return ok; }
    public static void Log(object value)=>Trace.Add("Log");
    static Type Map(MC.TypeReference t)
    {
        if(t is MC.ByReferenceType b)return Map(b.ElementType).MakeByRefType();
        if(t is MC.GenericParameter)return typeof(RowState);
        if(t is MC.GenericInstanceType g&&g.ElementType.FullName=="System.Collections.Generic.List`1")return typeof(List<RowState>);
        return t.FullName switch {"System.Void"=>typeof(void),"System.Boolean"=>typeof(bool),"System.Int32"=>typeof(int),"System.String"=>typeof(string),"System.Object"=>typeof(object),
            "System2"=>typeof(SystemState),"TMPro.TMP_InputField"=>typeof(InputState),"BoardConfig"=>typeof(ConfigState),"Map"=>typeof(MapState),"Row"=>typeof(RowState),_=>throw new NotSupportedException(t.FullName)};
    }
    static FieldInfo Field(MC.FieldReference f)=>Map(f.DeclaringType).GetField(f.Name,BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance|BindingFlags.Static)??throw new NotSupportedException(f.FullName);
    static MethodBase Method(MC.MethodReference m)=>(m.DeclaringType.FullName+"::"+m.Name) switch
    {
        "UnityEngine.Object::get_name"=>typeof(InputState).GetMethod(nameof(InputState.GetName))!,
        "TMPro.TMP_InputField::get_text"=>typeof(InputState).GetProperty(nameof(InputState.Text))!.GetMethod!,
        "System.Int32::TryParse"=>typeof(Program).GetMethod(nameof(Parse))!,"UnityEngine.Debug::Log"=>typeof(Program).GetMethod(nameof(Log))!,
        "BoardConfig::Map"=>typeof(ConfigState).GetMethod(nameof(ConfigState.Map))!,
        "System.Collections.Generic.List`1<Row>::get_Item"=>typeof(List<RowState>).GetProperty("Item")!.GetMethod!,_=>throw new NotSupportedException(m.FullName)
    };
    public static void Main(string[] args)
    {
        CultureInfo.CurrentCulture=CultureInfo.InvariantCulture;
        using var module=MC.ModuleDefinition.ReadModule(args[0]);var source=(MC.MethodDefinition)module.LookupToken(0x06000089);
        var call=(Action<SystemState,InputState>)ActualCil.Emit(source,Map,Field,Method).CreateDelegate(typeof(Action<SystemState,InputState>));var results=new List<object>();
        foreach(var c in JsonSerializer.Deserialize<List<Case>>(File.ReadAllText(args[1]))!)
        {
            Current=c;Trace=[];Owner=new();var original=Owner.boardConfig;var input=new InputState { Name=c.input_name };input.Install(c.text);string? error=null;
            try { call(Owner,input); }catch(Exception e){error=e.GetType().FullName+": "+e.Message;}
            results.Add(new {name=c.name,trace=Trace.ToArray(),current=Owner.boardConfig.map.rows.Select(r=>r.EnemyType).ToArray(),initial=original.map.rows.Select(r=>r.EnemyType).ToArray(),error});
        }
        File.WriteAllText(args[2],JsonSerializer.Serialize(new {scope="ACTUAL_SYSTEM2_CIL_CONTROLLED_CALLEES",input_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),method_token="0x06000089",source_instructions=source.Body.Instructions.Count,
            all_source_instructions_emitted=true,log_text_equivalence=false,unity_execution=false,results},new JsonSerializerOptions {WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new {cases=results.Count}));
    }
}
