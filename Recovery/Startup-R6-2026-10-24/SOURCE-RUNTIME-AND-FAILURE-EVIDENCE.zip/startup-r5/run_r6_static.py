from pathlib import Path
import hashlib,importlib.util,json,struct,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];O=W/'startup-r6';sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'));import dnfile
DOT=ROOT/'.local/dotnet10/dotnet.exe';SUPPORT=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'
EXPORT=ROOT/'audit/bulk250-r1-evidence-39702928368/bulk250-r1-run/tools_bin/CilExporter/bin/CilExporter.dll'
CHECKER=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py';MEMBER=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/member-bin/MemberAccess.dll'
candidate=O/'candidate1.dll';data=candidate.read_bytes();parent=(Q/'candidate1.dll').read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(data)=='c36092b5326687112adfa8c285bb3cf5e8ad46d3b3de8ebcd84daf598041465d' and sha(parent)=='7fa02b81d4d1af579a18eea103f776493f012565e64d5b38fd885cf40718a296'
# Independent of constructor plan: derive four raw spans from original headers.
pe=dnfile.dnPE(data=parent);expected=bytearray(parent);ranges=[]
for rid,tail in [(0x2AD,429),(0x5E7,963),(0x7B7,362),(0x7B8,332)]:
    at=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[rid-1].Rva);head=(struct.unpack_from('<H',parent,at)[0]>>12)*4
    size=struct.unpack_from('<I',parent,at+4)[0];assert size==tail+6 and parent[at+head+tail]==0x72 and parent[at+head+tail+5]==0x26
    pos=at+head+tail;expected[pos:pos+6]=b'\0'*5+b'\x2a';ranges.append((rid,pos))
def isolate(b):
    if b!=expected:raise ValueError('Only independently specified six-byte four-tail replacements allowed')
isolate(data);assert data==(O/'candidate2.dll').read_bytes()
controls=[]
for label,offset in [('unrelated-byte',pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[0x526-1].Rva)+12),('metadata-byte',pe.net.struct.MetaDataRva),('target-tail-not-terminated',ranges[0][1]+5),('method-header',ranges[0][1]-429-12)]:
    if label=='metadata-byte':offset=pe.get_offset_from_rva(offset)
    b=bytearray(data);b[offset]^=1
    try:isolate(bytes(b))
    except ValueError:controls.append(dict(name=label,rejected=True));continue
    raise AssertionError('Isolation false accept')
(O/'ISOLATION.json').write_bytes((json.dumps(dict(scope='INDEPENDENT_WHOLE_FILE_BYTE_BOUNDARY_ONLY',candidate_sha256=sha(data),parent_sha256=sha(parent),changed_body_targets=4,untouched_methoddefs=2313,
    all_other_file_bytes_identical=True,metadata_headers_rvas_unchanged=True,negative_controls=controls),indent=2)+'\n').encode())
def run(label,args):
    p=subprocess.run([str(x) for x in args],capture_output=True);(O/(label+'.stdout.log')).write_bytes(p.stdout);(O/(label+'.stderr.log')).write_bytes(p.stderr);assert p.returncode==0,(label,p.returncode,p.stderr[:600])
assert sha(CHECKER.read_bytes())=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14'
spec=importlib.util.spec_from_file_location('frozen_unchanged',CHECKER);checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
tokens=[m['token'] for m in json.loads((Q/'FORTY-FIVE-CIL.json').read_bytes())['methods']];assert len(tokens)==45
run('cil-export',[DOT,EXPORT,candidate,O/'FORTY-FIVE-CIL.json',SUPPORT,','.join(tokens)])
cil=json.loads((O/'FORTY-FIVE-CIL.json').read_text('utf-8-sig'));results=[checker.verify(m,cil['types']) for m in cil['methods']]
report=dict(scope='UNCHANGED_FROZEN_STACK_FLOW_ONLY',candidate_sha256=sha(data),checker_sha256=sha(CHECKER.read_bytes()),total=len(results),passed=sum(r.get('status')=='PASS' for r in results),results=results)
(O/'FROZEN-STACK-FLOW-45.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());assert report['total']==report['passed']==45
(O/'METHODS.json').write_bytes((Q/'METHODS.json').read_bytes());run('member-access',[DOT,MEMBER,candidate,SUPPORT,O/'METHODS.json',O/'MEMBER-ACCESS.json'])
mutant=O/'buff-runtime-results/int64-sentinel-restored.dll';assert mutant.exists()
run('int64-control-export',[DOT,EXPORT,mutant,O/'INT64-CONTROL-CIL.json',SUPPORT,'0x060005E7'])
bad=json.loads((O/'INT64-CONTROL-CIL.json').read_text('utf-8-sig'))
try:failure=checker.verify(bad['methods'][0],bad['types'])
except Exception as e:failure=dict(token='0x060005E7',status='FAIL',error=str(e))
assert failure.get('status')!='PASS',failure
negative=dict(scope='UNCHANGED_FROZEN_WIDTH_GATE_ON_PHYSICAL_INT64_MUTANT',baseline_passed=True,mutant_sha256=sha(mutant.read_bytes()),checker_sha256=sha(CHECKER.read_bytes()),
              runtime_did_not_distinguish=True,rejected=True,result=failure)
(O/'INT64-NEGATIVE-WIDTH.json').write_bytes((json.dumps(negative,indent=2)+'\n').encode());print(json.dumps(dict(frozen_passed=45,member_access_methods=6,isolation_controls=len(controls),width_negative=negative),indent=2))
