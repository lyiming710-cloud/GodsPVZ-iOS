"""Original PC Buff caller, nonmutating controlled ATK/increment/UI callees."""
from pathlib import Path
import ctypes as C,json,sys,struct
from native_runtime_common import *
Q=Path(__file__).resolve().parent;cases=json.loads(Path(sys.argv[1]).read_bytes());out=Path(sys.argv[2]);im=NativeImage();state={};results=[]
metadata=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/global-metadata.dat').read_bytes()
assert hashlib.sha256(metadata).hexdigest()=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9'
literal_table,literal_size,literal_data=struct.unpack_from('<3I',metadata,8)
string_slots={0x181B9FF10:'Ms',0x181BBC430:'Def'};string_bindings=[]
def text(s):
    d=s.encode('utf-16-le');p=im.alloc(24+len(d)+2);put32(p+0x10,len(s));C.memmove(p+0x14,d,len(d));return p
def read(p):return C.string_at(p+0x14,get32(p+0x10)*2).decode('utf-16-le')
try:
    for slot,expected in string_slots.items():
        encoded=int.from_bytes(im.pe.get_data(slot-im.base,8),'little');assert encoded>>29==5;index=(encoded&0x1fffffff)>>1;assert index*8<literal_size
        size,at=struct.unpack_from('<2I',metadata,literal_table+index*8);actual=metadata[literal_data+at:literal_data+at+size].decode();assert actual==expected
        string_bindings.append(dict(slot=hex(slot),encoded=hex(encoded),literal_index=index,value=actual))
    def init(slot):
        if slot in string_slots:put64(slot,text(string_slots[slot]))
        else:im.class_slot(slot)
    im.hook(0x18024fef0,None,[P],init);im.hook(0x1802501e0,None,[P],lambda _:None)
    def equal(a,b,method):
        assert not b;state['trace'].append('Eq:'+(state['objects'][a][0] if a else 'null'));return not a or not state['objects'][a][1]
    def increment(manager,value,key,method):
        assert manager==state['buff'];v=F(number(state['case']['increments'][state['index']])).value;state['index']+=1
        state['trace'].append('Inc:'+read(key)+':'+bits(value)+':'+bits(v));return v
    def atk(zombie,method):
        assert zombie==state['zombie'];v=F(number(state['case']['atk'])).value;state['trace'].append('ATK:'+bits(v));return v
    def stats_float(ui,index,value,method):
        assert ui==state['ui'];state['trace'].append('Float:'+str(index)+':'+bits(value))
    def stats_int(ui,a,b,c,method):
        assert ui==state['ui'];state['trace'].append(f'Int:{a}:{b}:{c}')
    im.hook(0x18131F760,C.c_bool,[P,P,P],equal)
    im.hook(0x180310420,F,[P,F,P,P],increment)
    im.hook(0x180360280,F,[P,P],atk)
    im.hook(0x18039AA60,None,[P,I,F,P],stats_float)
    im.hook(0x18039A7D0,None,[P,I,I,I,P],stats_int)
    cfg=json.loads((Q.parent/'remaining-native/05E7.normal-cfg.json').read_bytes());im.verify_caller(0x5E7,0x18039A4B0,cfg)
    invoke=C.CFUNCTYPE(None,P,P)(0x18039A4B0)
    for case in cases:
        state.clear();state.update(case=case,trace=[],objects={},index=0);ui=im.alloc(64);z=im.alloc(1024) if case['zombie'] else 0;b=im.alloc(64) if case['board'] else 0;buff=im.alloc(64)
        if z:state['objects'][z]=('zombie',case['zombie']==1)
        if b:state['objects'][b]=('board',case['board']==1)
        state.update(ui=ui,zombie=z,buff=buff);put64(ui+0x20,z)
        if z:
            put64(z+0x20,b);put64(z+0x228,buff);putf(z+0x6c,number(case['attack']));putf(z+0x78,number(case['defense']))
            put32(z+0x84,case['armor1']);put32(z+0x9c,case['armor2']);putf(z+0x94,number(case['d1']));putf(z+0xac,number(case['d2']))
        invoke(ui,None);results.append(dict(name=case['name'],trace=list(state['trace']),error=None))
    assert not im.errors,im.errors
    report=dict(scope='ACTUAL_ORIGINAL_PC_BUFF_CALLER_NONMUTATING_CONTROLLED_CALLEES',original_sha256=PC_SHA,method_token='0x060005E7',original_caller_instruction_count=len(cfg['instructions']),
                original_caller_bytes_preserved=True,string_literal_bindings=string_bindings,callback_errors=im.errors,unity_execution=False,results=results)
    out.write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(dict(cases=len(results),callback_errors=im.errors)))
finally:im.close()
