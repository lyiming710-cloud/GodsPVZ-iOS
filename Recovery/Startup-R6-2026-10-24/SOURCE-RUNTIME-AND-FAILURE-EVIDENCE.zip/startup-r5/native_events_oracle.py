"""Original PC Enable/Disable caller bytes; controlled delegates/events.

MethodInfo bindings are decoded from original encoded usages and metadata,
not assigned from candidate instructions. Original handlers are not executed.
"""
from pathlib import Path
import ctypes as C,json,sys,struct
from native_runtime_common import *
Q=Path(__file__).resolve().parent;cases=json.loads(Path(sys.argv[1]).read_bytes());out=Path(sys.argv[2]);im=NativeImage();state={};results=[]
metadata=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/global-metadata.dat').read_bytes()
assert hashlib.sha256(metadata).hexdigest()=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9'
method_table,method_size=struct.unpack_from('<2I',metadata,48);string_table=struct.unpack_from('<I',metadata,24)[0]
bindings=[];methods={};slot_methods={};names=['Character','Sprite','Word','Line','Link']
def callback(op,id):
    if state['changed']:return
    mode=state['case']['callback']
    if mode=='replace-handler-on-truth' and op=='Truth' or mode=='replace-handler-on-getcomponent' and op=='GetComponent' or mode=='replace-handler-on-add-character' and op=='Add' and id.endswith('/Character') or mode=='replace-handler-on-remove-character' and op=='Remove' and id.endswith('/Character'):
        state['changed']=True;put64(state['active']+0x20,handler('handler-new',True))
def handler(id,alive):
    p=im.alloc(128);state['objects'][p]=(id,alive);state['handlers'].append(p)
    for i,n in enumerate(names):
        event=im.alloc(64);state['events'][event]=dict(id=id+'/'+n,listeners=[]);put64(p+0x20+i*8,event)
    return p
def label(p):return state['objects'][p][0] if p else 'null'
def listener(pair):return state['owners'][pair[0]]+':'+pair[1]
def fire():
    for h in state['handlers'][:]:
        for i,n in enumerate(names):
            event=state['events'][get64(h+0x20+i*8)]
            for target,method in event['listeners'][:]:
                args='113:7' if method in ['OnCharacterSelection','OnSpriteSelection'] else 'ID:label:9' if method=='OnLinkSelection' else 'word:3:4'
                state['trace'].append('Invoke:'+state['owners'][target]+':'+method+':'+args)
try:
    for slot,expected in [(0x181BCD560,'OnCharacterSelection'),(0x181BCD660,'OnSpriteSelection'),(0x181BCD6B0,'OnWordSelection'),(0x181BCD5B8,'OnLineSelection'),(0x181BCD608,'OnLinkSelection')]:
        encoded=int.from_bytes(im.pe.get_data(slot-im.base,8),'little');assert encoded>>29==3;index=(encoded&0x1fffffff)>>1;assert index*36<method_size
        at=method_table+index*36;name_at=string_table+struct.unpack_from('<I',metadata,at)[0];name=metadata[name_at:].split(b'\0',1)[0].decode();assert name==expected
        token=struct.unpack_from('<I',metadata,at+24)[0];rid=token&0xffffff;assert token>>24==6
        pointer=int.from_bytes(im.pe.get_data(0x181B82D60-im.base+(rid-1)*8,8),'little');assert 0x180000000<=pointer<0x182000000
        info=im.alloc(128);put64(info,pointer);methods[pointer]=name;slot_methods[slot]=info
        bindings.append(dict(slot=hex(slot),encoded=hex(encoded),metadata_index=index,token=hex(token),name=name,method_pointer=hex(pointer)))
    def init(slot):
        if slot in slot_methods:put64(slot,slot_methods[slot])
        else:im.class_slot(slot)
    im.hook(0x18024FEF0,None,[P],init);im.hook(0x1802501E0,None,[P],lambda _:None)
    im.hook(0x18024F360,None,[P,P],lambda *_:None)
    im.hook(0x180250100,P,[P],lambda _:im.alloc(256))
    def neq(p,b,method):
        assert not b;state['trace'].append('Eq:'+label(p));answer=bool(p and state['objects'][p][1]);callback('Truth',label(p));return answer
    def component(p,method):
        state['trace'].append('GetComponent:'+label(p));callback('GetComponent',label(p));t=im.alloc(64);state['texts'][t]='text:'+label(p);return t
    def ctor(group):
        def f(p,target,info,unused):
            name=methods[get64(info)];assert target in state['owners']
            assert name in (['OnCharacterSelection','OnSpriteSelection'] if group==2 else ['OnWordSelection','OnLineSelection'] if group==3 else ['OnLinkSelection'])
            state['delegates'][p]=(target,name);state['constructors']+=1
        return f
    def registration(op):
        def f(p,delegate,method):
            event=state['events'][p];pair=state['delegates'][delegate];state['trace'].append(op+':'+event['id']+':'+listener(pair))
            if op=='Add':event['listeners'].append(pair)
            else:event['listeners'][:]=[x for x in event['listeners'] if x!=pair]
            callback(op,event['id'])
        return f
    im.hook(0x18131F900,C.c_bool,[P,P,P],neq);im.hook(0x18042E9F0,P,[P,P],component)
    for va,group in [(0x180A62420,2),(0x1805213C0,3),(0x180A624D0,4)]:im.hook(va,None,[P,P,P,P],ctor(group))
    for va in [0x180A64A50,0x180A657F0]:im.hook(va,None,[P,P,P],registration('Add'))
    im.hook(0x180A649D0,None,[P,P,P],registration('Remove'))
    cfgs=[json.loads((Q.parent/f'remaining-native/{rid:04X}.normal-cfg.json').read_bytes()) for rid in [0x7B7,0x7B8]]
    for rid,entry,cfg in zip([0x7B7,0x7B8],[0x1803B6BB0,0x1803B6930],cfgs):im.verify_caller(rid,entry,cfg)
    enable=C.CFUNCTYPE(None,P,P)(0x1803B6BB0);disable=C.CFUNCTYPE(None,P,P)(0x1803B6930);constructors=0
    for case in cases:
        state.clear();state.update(case=case,objects={},handlers=[],events={},owners={},texts={},delegates={},trace=[],changed=False,constructors=0)
        h=handler('handler',case['handler']==1) if case['handler'] else 0;a=im.alloc(64);b=im.alloc(64);state['owners'].update({a:'A',b:'B'});put64(a+0x20,h);put64(b+0x20,h)
        for step in case['steps']:
            p=a if step.endswith('A') else b;state['active']=p;(enable if step.startswith('E') else disable)(p,None);fire()
        constructors+=state['constructors'];results.append(dict(name=case['name'],trace=list(state['trace']),text_a=state['texts'].get(get64(a+0x28)),text_b=state['texts'].get(get64(b+0x28)),
            events={event['id']:[listener(x) for x in event['listeners']] for event in state['events'].values()},error=None))
    assert not im.errors,im.errors
    report=dict(scope='ACTUAL_PC_EVENT_CALLERS_CONTROLLED_DELEGATE_AND_EVENT_CALLEES',original_sha256=PC_SHA,method_tokens=['0x060007B7','0x060007B8'],original_caller_bytes_preserved=True,
                caller_instruction_counts=[len(c['instructions']) for c in cfgs],methodinfo_bindings=bindings,delegate_constructors=constructors,callback_errors=im.errors,
                original_event_handlers_executed=False,unity_event_implementation_executed=False,unity_execution=False,results=results)
    out.write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(dict(cases=len(results),delegate_constructors=constructors,callback_errors=im.errors)))
finally:im.close()
