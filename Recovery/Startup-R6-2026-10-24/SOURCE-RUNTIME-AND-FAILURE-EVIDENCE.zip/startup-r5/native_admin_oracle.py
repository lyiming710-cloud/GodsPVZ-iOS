"""Execute original PC Administrator config method in an isolated Windows process.

Actual original caller bytes, controlled Unity/path/JSON/allocation callees.
Normal-path traces and field writes only. Windows throw/unwind and original log
string text are explicitly not modeled. No DllMain/game executable is entered.
"""
from pathlib import Path
import ctypes as C
import hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;ROOT=Q.parents[2]
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import pefile
assert sys.platform=='win32' and len(sys.argv)==3
cases=json.loads(Path(sys.argv[1]).read_bytes());report_path=Path(sys.argv[2])
raw=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/GameAssembly.dll').read_bytes()
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(raw)=='9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d'
pe=pefile.PE(data=raw);base=pe.OPTIONAL_HEADER.ImageBase
api=C.WinDLL('kernel32',use_last_error=True)
api.VirtualAlloc.argtypes=[C.c_void_p,C.c_size_t,C.c_uint32,C.c_uint32];api.VirtualAlloc.restype=C.c_void_p
api.VirtualFree.argtypes=[C.c_void_p,C.c_size_t,C.c_uint32];api.VirtualFree.restype=C.c_int
address=api.VirtualAlloc(base,pe.OPTIONAL_HEADER.SizeOfImage,0x3000,0x40)
assert address==base,'Original base unavailable in this child process'
owned=[];callbacks=[];errors=[];state={};classes={};results=[]
def alloc(size):
    value=C.create_string_buffer(size);owned.append(value);return C.addressof(value)
def put64(at,value):C.c_uint64.from_address(at).value=value or 0
def get64(at):return C.c_uint64.from_address(at).value
def put32(at,value):C.c_int32.from_address(at).value=value
def get32(at):return C.c_int32.from_address(at).value
def text(value):
    encoded=value.encode('utf-16-le');pointer=alloc(0x18+len(encoded)+2)
    put32(pointer+0x10,len(encoded)//2);C.memmove(pointer+0x14,encoded,len(encoded));return pointer
def read_text(pointer):
    assert pointer
    count=get32(pointer+0x10);assert 0<=count<1000
    return C.string_at(pointer+0x14,count*2).decode('utf-16-le')
def fake_class():
    value=alloc(512);static=alloc(128);put64(value+0xb8,static);put32(value+0xe0,1);return value
def class_slot(at):
    if at not in classes:classes[at]=fake_class()
    put64(at,classes[at]);return classes[at]
def hook(va,result,args,fn):
    def guard(*values):
        try:return fn(*values)
        except Exception as error:errors.append(repr(error));return None if result is None else 0
    callback=C.CFUNCTYPE(result,*args)(guard);callbacks.append(callback)
    C.memmove(va,b'\xff\x25\0\0\0\0'+struct.pack('<Q',C.cast(callback,C.c_void_p).value),14)
def source_label(pointer):
    if not pointer:return 'null'
    assert pointer in state['objects'],'Unknown object escaped controlled graph'
    return state['objects'][pointer][0]
def new_system():
    pointer=alloc(128);put32(pointer+0x28,-99);put32(pointer+0x2c,-99);return pointer
def new_manager(challenge=5,level=6,alive=True,label='manager'):
    pointer=alloc(128);put32(pointer+0x20,challenge);put32(pointer+0x24,level)
    state['objects'][pointer]=(label,alive);return pointer

try:
    C.memmove(base,raw[:pe.OPTIONAL_HEADER.SizeOfHeaders],pe.OPTIONAL_HEADER.SizeOfHeaders)
    for section in pe.sections:
        C.memmove(base+section.VirtualAddress,raw[section.PointerToRawData:section.PointerToRawData+section.SizeOfRawData],section.SizeOfRawData)
    assert int.from_bytes(pe.get_data(0x181B82D60-base+8*8,8),'little')==0x1802fd6e0
    manager_class=class_slot(0x181BD1A40);manager_static=get64(manager_class+0xb8)
    lawn_class=class_slot(0x181BA2018);lawn_static=get64(lawn_class+0xb8)
    class_slot(0x181BB0500)
    hook(0x18024fef0,None,[C.c_void_p],lambda slot:class_slot(slot) and None)
    hook(0x1802501e0,None,[C.c_void_p],lambda _:None)
    def equal(a,b,method):
        assert not b
        state['trace'].append('Eq:'+source_label(a))
        return not a or not state['objects'][a][1]
    def truth(a,method):
        state['trace'].append('Truth:'+source_label(a));answer=bool(a and state['objects'][a][1])
        if state['case']['callback']=='replace-manager-on-truth':
            put64(manager_static,new_manager(13,14,True,'manager-new'))
        return answer
    def path(challenge,level,method):
        state['trace'].append(f'Path:{challenge}:{level}');mode=state['case']['callback']
        if mode=='mutate-selected':
            if state['case']['board']==1:obj=state['board'];ch,lv=7,11
            else:obj=state['manager'];ch,lv=9,12
            put32(obj+0x20,ch);put32(obj+0x24,lv)
        if mode=='new-system2-at-path':put64(state['admin']+0x40,new_system())
        if mode=='advance-save-at-path':put32(get64(state['saves']+0x10)+0x20,17)
        if mode=='new-save-at-path':
            save=alloc(64);put32(save+0x20,19);put64(state['saves']+0x10,save)
        return text(f'path:{challenge}:{level}')
    def read(pointer,method):
        state['trace'].append('Read:'+read_text(pointer));mode=state['case']['json']
        return 0 if mode=='null' else text('' if mode=='empty' else '{controlled-json}')
    def empty(pointer,method):return not pointer or get32(pointer+0x10)==0
    def log(pointer,method):state['trace'].append('Log')
    def allocate(klass):return alloc(256)
    def constructor(pointer,width,height,method):
        state['trace'].append(f'Ctor:{width}:{height}');state['configs'][pointer]=('default',width,height)
        if state['case']['callback']=='new-system2-at-constructor':put64(state['admin']+0x40,new_system())
    def parse(pointer,method):
        assert read_text(pointer)=='{controlled-json}'
        state['trace'].append('Parse');config=alloc(256);state['configs'][config]=('json',0,0);return config
    P=C.c_void_p;I=C.c_int32
    hook(0x18131f760,C.c_bool,[P,P,P],equal)
    hook(0x18131f870,C.c_bool,[P,P],truth)
    hook(0x18032f3c0,P,[I,I,P],path)
    hook(0x18031ce70,P,[P,P],read)
    hook(0x180b78590,C.c_bool,[P,P],empty)
    hook(0x1812e68f0,None,[P,P],log)
    hook(0x180250100,P,[P],allocate)
    hook(0x18030f020,None,[P,I,I,P],constructor)
    hook(0x18047c030,P,[P,P],parse)
    hook(0x18024f360,None,[P,P],lambda *_:None)
    cfg=json.loads((Q.parent/'administrator-next-native/0009.normal-cfg.json').read_bytes())
    for instruction in cfg['instructions']:
        expected=bytes.fromhex(instruction['bytes']);assert C.string_at(int(instruction['va'],16),len(expected))==expected,'Original caller code modified'
    invoke=C.CFUNCTYPE(None,P,P,P)(0x1802fd6e0)
    def snapshot(system):
        config=get64(system+0x20);kind,width,height=state['configs'][config] if config else (None,0,0)
        return dict(challenge=get32(system+0x28),level=get32(system+0x2c),config=kind,width=width,height=height)
    for case in cases:
        state.clear();state.update(case=case,trace=[],objects={},configs={})
        admin=alloc(128);initial=new_system();put64(admin+0x40,initial)
        board=0
        if case['board']:
            board=alloc(128);put32(board+0x20,2);put32(board+0x24,3);state['objects'][board]=('board',case['board']==1)
        manager=new_manager(alive=case['manager']==1) if case['manager'] else 0;put64(manager_static,manager)
        lawn=alloc(64);saves=alloc(64);save=alloc(64);put32(save+0x20,10)
        put64(lawn+0x28,saves);put64(saves+0x10,save);put64(lawn_static,lawn)
        state.update(admin=admin,board=board,manager=manager,saves=saves)
        invoke(admin,board,None)
        current_manager=get64(manager_static)
        results.append(dict(name=case['name'],trace=list(state['trace']),current=snapshot(get64(admin+0x40)),initial=snapshot(initial),
                            save_level=get32(get64(saves+0x10)+0x20),manager_challenge=get32(current_manager+0x20) if current_manager else None,
                            manager_level=get32(current_manager+0x24) if current_manager else None,error=None))
    assert not errors,errors
    report=dict(scope='ACTUAL_ORIGINAL_PC_NATIVE_CALLER_NORMAL_PATHS_CONTROLLED_CALLEES',original_sha256=sha(raw),method_token='0x06000009',entry='0x1802fd6e0',
                original_caller_instruction_count=len(cfg['instructions']),original_caller_bytes_preserved=True,callback_errors=errors,
                exceptions_native_unwind_modeled=False,log_text_equivalence=False,unity_execution=False,results=results)
    report_path.write_bytes((json.dumps(report,indent=2)+'\n').encode())
    print(json.dumps(dict(cases=len(results),original_caller_bytes_preserved=True,callback_errors=errors)))
finally:
    api.VirtualFree(base,0,0x8000)
