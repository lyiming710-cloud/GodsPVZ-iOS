"""Original PC Board.Update_isWon, with controlled nonthrowing callees."""
from pathlib import Path
import ctypes as C,json,sys
from native_runtime_common import *
Q=Path(__file__).resolve().parent
cases=json.loads(Path(sys.argv[1]).read_bytes());out=Path(sys.argv[2])
im=NativeImage();state={};results=[]
try:
    manager_static=get64(im.class_slot(0x181BD1A40)+0xb8)
    lawn_static=get64(im.class_slot(0x181BA2018)+0xb8)
    im.install_metadata()
    def object_(name):
        p=im.alloc(512);state['objects'][p]=name;return p
    def label(p):return state['objects'][p]
    def delta(method):
        n=state['times'];state['times']+=1
        v=F(number(state['case']['dt1' if n==0 else 'dt2'])).value
        state['trace'].append('Time:'+bits(v));return v
    def get_volume(audio,method):
        v=getf(audio+0x20);state['trace'].append('VolGet:'+bits(v));return v
    def set_volume(audio,v,method):
        state['trace'].append('VolSet:'+bits(v));putf(audio+0x20,v)
    def bgm(method):
        v=F(number(state['case']['bgm'])).value;state['trace'].append('BGM:'+bits(v));return v
    def create(manager,config,method):
        state['trace'].append('Create:'+label(manager)+':'+label(config));mode=state['case']['callback']
        if mode=='replace-manager-on-create':put64(manager_static,object_('manager-new'))
        if mode=='replace-config-on-create':put64(state['board']+0x28,object_('config-new'))
        if mode=='replace-lawn-on-create':put64(lawn_static,object_('lawn-new'))
        return object_('settlement')
    def passed(lawn,settlement,config,method):
        state['trace'].append('Pass:'+label(lawn)+':'+label(settlement)+':'+label(config))
        if state['case']['callback']=='replace-manager-on-pass':put64(manager_static,object_('manager-after-pass'))
    def quit_(manager,board,method):
        assert board==state['board'];state['trace'].append('Quit:'+label(manager))
    im.hook(0x18132C2F0,F,[P],delta)
    im.hook(0x1812DC3D0,F,[P,P],get_volume)
    im.hook(0x1812DC4B0,None,[P,F,P],set_volume)
    im.hook(0x18031AFC0,F,[P],bgm)
    im.hook(0x18030F5A0,P,[P,P,P],create)
    im.hook(0x18031CF20,None,[P,P,P,P],passed)
    im.hook(0x18030FF50,None,[P,P,P],quit_)
    cfg=json.loads((Q.parent/'remaining-native/02AD.normal-cfg.json').read_bytes())
    im.verify_caller(0x2AD,0x180328F30,cfg)
    invoke=C.CFUNCTYPE(None,P,P)(0x180328F30)
    for case in cases:
        state.clear();state.update(case=case,objects={},trace=[],times=0)
        board=object_('board');state['board']=board;audio=object_('audio');array=im.alloc(48)
        put64(array+0x18,1);put64(array+0x20,audio);put64(board+0x140,array)
        putf(board+0x3c,number(case['end']));C.c_ubyte.from_address(board+0x39).value=case['won']
        putf(audio+0x20,number(case['volume']));put64(board+0x28,object_('config'))
        put64(manager_static,object_('manager'));put64(lawn_static,object_('lawn'))
        invoke(board,None)
        results.append(dict(name=case['name'],trace=list(state['trace']),end_time=bits(getf(board+0x3c)),
                            volume=bits(getf(audio+0x20)),manager_id=label(get64(manager_static)),error=None))
    assert not im.errors,im.errors
    report=dict(scope='ACTUAL_ORIGINAL_PC_BOARD_CALLER_NORMAL_PATHS_CONTROLLED_CALLEES',original_sha256=PC_SHA,
                method_token='0x060002AD',entry='0x180328f30',original_caller_instruction_count=len(cfg['instructions']),
                original_caller_bytes_preserved=True,callback_errors=im.errors,exceptions_native_unwind_modeled=False,unity_execution=False,results=results)
    out.write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(dict(cases=len(results),callback_errors=im.errors)))
finally:im.close()
