from pathlib import Path
import hashlib,json,zipfile
W=Path(__file__).resolve().parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113';Q=W/'startup-r5';O=W/'startup-r6';D=R/'Recovery/Startup-R6-2026-10-24';D.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
def record(n,b):return dict(file=n,bytes=len(b),sha256=sha(b))
def js(p,d):p.write_bytes((json.dumps(d,indent=2,ensure_ascii=False)+'\n').encode())
def pack(path,items):
    assert len(items)==len({n for n,b in items})
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        for n,b in items:z.writestr(n,b)
        z.writestr('MANIFEST.json',json.dumps([record(n,b) for n,b in items],indent=2))
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        manifest=json.loads(z.read('MANIFEST.json'));assert set(z.namelist())=={'MANIFEST.json'}|{r['file'] for r in manifest}
        for r in manifest:assert record(r['file'],z.read(r['file']))==r
base=(O/'candidate1.dll').read_bytes();digest=sha(base);assert digest=='c36092b5326687112adfa8c285bb3cf5e8ad46d3b3de8ebcd84daf598041465d'
suites=[]
for name in ['admin','board','system','buff','events']:
    result=json.loads((O/f'{name}-runtime-results/RESULT.json').read_bytes());assert result['candidate_sha256']==digest and result['pass_']
    suites.append(dict(suite=name,cases=result['cases'],tokens=result.get('method_tokens',[result.get('method_token')]),scope=result['scope'],runtime_equivalence_pass=True,negative_controls=result['negative_controls']))
assert sum(s['cases'] for s in suites)==2475
controls=[c for s in suites for c in s['negative_controls']];assert len(controls)==24 and sum(c['detected_cases']>0 for c in controls)==23
width=json.loads((O/'INT64-NEGATIVE-WIDTH.json').read_bytes());assert width['rejected'] and width['runtime_did_not_distinguish']
# Store exact reconstructable physical-mutant bytes as changed byte runs. This
# avoids checking in twenty copies of the same 18 MB DLL while preserving hashes.
mutants=[]
for parent in [Q,O]:
    original=(parent/'candidate1.dll').read_bytes()
    for p in sorted(parent.glob('*-runtime-results/*.dll')):
        changed=p.read_bytes();assert len(changed)==len(original);runs=[]
        for page in range(0,len(original),4096):
            before=original[page:page+4096];after=changed[page:page+4096]
            if before==after:continue
            at=0
            while at<len(before):
                if before[at]==after[at]:at+=1;continue
                end=at+1
                while end<len(before) and before[end]!=after[end]:end+=1
                runs.append(dict(file_offset=page+at,before=before[at:end].hex(),after=after[at:end].hex()));at=end
        rebuilt=bytearray(original)
        for run in runs:
            at=run['file_offset'];b=bytes.fromhex(run['before']);a=bytes.fromhex(run['after']);assert rebuilt[at:at+len(b)]==b;rebuilt[at:at+len(a)]=a
        assert rebuilt==changed
        mutants.append(dict(file=p.relative_to(W).as_posix(),parent_sha256=sha(original),mutant_sha256=sha(changed),bytes=len(changed),runs=runs))
js(O/'PHYSICAL-MUTANTS.json',dict(scope='EXACT_BYTE_RECONSTRUCTION_OF_ACTUALLY_EXECUTED_MUTANTS',mutants=mutants))
(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text whitespace=cr-at-eol\n*.md -text\n*.zip -text\n')
for n in ['CONSTRUCTION.json','ISOLATION.json','FROZEN-STACK-FLOW-45.json','MEMBER-ACCESS.json','INT64-NEGATIVE-WIDTH.json','LEXICAL-TAIL-CENSUS.json']:(D/n).write_bytes((O/n).read_bytes())
js(D/'RUNTIME-SUMMARY.json',dict(scope='SIX_TARGETS_CONTROLLED_CALLER_SEMANTICS_PLUS_FROZEN_WIDTH_ONLY',candidate_sha256=digest,methods=6,total_cases=2475,runtime_detected_controls=23,
    runtime_undetected_controls=1,independent_frozen_width_rejects_remaining_control=True,suites=suites,unity_execution=False,whole_game_acceptance=False))
pack(D/'STARTUP-R6-CANDIDATE.zip',[('STARTUP-R6.dll',base)])
items=[]
for parent in [Q,O]:
    for p in sorted(parent.rglob('*')):
        if not p.is_file() or any(x in ['__pycache__','obj'] for x in p.relative_to(parent).parts):continue
        rel=p.relative_to(parent)
        if 'bin' in rel.parts:
            if p.suffix not in ['.json','.dll','.pdb']:continue
            if p.name=='Mono.Cecil.dll':continue
        elif p.suffix=='.dll':continue
        if p.name in ['candidate1.dll','candidate2.dll']:continue
        items.append((p.relative_to(W).as_posix(),p.read_bytes()))
for p in [W/'remaining-native'/f'{rid}.normal-cfg.{ext}' for rid in ['0089','02AD','05E7','07B7','07B8'] for ext in ['json','txt']]:items.append((p.relative_to(W).as_posix(),p.read_bytes()))
for p in [W/'administrator-next-native'/f'0009.normal-cfg.{ext}' for ext in ['json','txt']]:items.append((p.relative_to(W).as_posix(),p.read_bytes()))
items.append(('runtime-dependencies/Mono.Cecil.dll',(Q/'runtime-admin/bin/Release/net10.0/Mono.Cecil.dll').read_bytes()))
items.append(('save_r6_runtime.py',Path(__file__).read_bytes()))
pack(D/'SOURCE-RUNTIME-AND-FAILURE-EVIDENCE.zip',items)
tail=json.loads((O/'LEXICAL-TAIL-CENSUS.json').read_bytes());types=json.loads((O/'FROZEN-WITH-INTERFACE-FACTS.json').read_bytes())
js(D/'CURRENT-RESULT.json',dict(status='SIX_SCOPED_CALLER_SUITES_PASS_FULL_PIPELINE_PENDING',parent_sha256=sha((Q/'candidate1.dll').read_bytes()),candidate_sha256=digest,
    bytes=len(base),changed_bodies_against_r5=4,untouched_methoddefs_against_r5=2313,metadata_and_headers_unchanged=True,method_targets=6,controlled_runtime_cases=2475,
    runtime_controls_detected=23,runtime_controls_undetected=1,additional_width_gate_rejected_remaining_control=True,frozen_stack_passed=45,member_access_target_methods_passed=6,
    original_pc_caller_bytes_preserved=True,whole_assembly={'body_methods':2297,'raw_type_passed':2136,'raw_fail_or_unsupported':161,'interface_fact_passed':2164,'interface_fact_fail_or_unsupported':133,
    'member_rejected_sites':217,'member_rejected_methods':112,'member_unresolved':0,'unterminated_lexical_tails':tail['unterminated_lexical_tails'],'tail_categories':tail['counts'],'all_pass':False},
    unity_editor_r6='NOT_RUN',il2cpp_r6='NOT_RUN',apple_cpp_r6='NOT_RUN',board_gameplay='PENDING',ipad_device='PENDING',new_ipa=None,previous_shader_result='SEPARATE_R3_RUN_40094204567',
    formal_whole_six_method_behavior_equivalence=False,scope_limits=['Controlled nonthrowing external callees','Original Unity implementations not executed by these fixtures','No native exception unwind equivalence','No original log text equivalence','No Android mobile behavior acceptance','No whole-assembly compiler or game acceptance']))
(D/'README.md').write_bytes('''# Startup R6: six scoped caller execution suites, broader queues held

This checkpoint follows R5 `7fa02b81…18a296`. R6 is `c36092b5326687112adfa8c285bb3cf5e8ad46d3b3de8ebcd84daf598041465d` (18,863,104 bytes). It is not an IPA or a whole-game acceptance.

Actual CLR execution rejected R5 Board.Update_isWon with InvalidProgramException. An unreachable Cpp2IL warning string/pop fell off the method end. A diagnostic-only appended ret isolated the cause: 769 cases then matched original PC native execution, but that accommodated fixture was never treated as R5 qualification. R6 physically replaces the same six-byte unreachable tail with five NOPs and ret in Board.Update_isWon, BuffUIController_Zombie.FixedUpdate and TMP_TextEventCheck.OnEnable/OnDisable. Whole-file independent isolation admits only those four spans; all 2,313 other MethodDefs, every header, RVA and metadata byte are identical to R5. The constructor proves the tails unreachable with zero EH, without pruning any reachable candidate instruction.

## Actual execution evidence

The five suites cover six targets: Administrator config loading (22 cases), System2.ChangeEnemyType (112), Board.Update_isWon (769), BuffUIController_Zombie.FixedUpdate (1,452), and the two TMP event callers together (120 lifecycle cases). All 2,475 case records compare equal in the stated controlled scope. Concrete CLR methods emit every candidate opcode/local/branch; no appended ret, dead-code pruning or private-access bypass is used for qualification. External object graphs and callees are explicit models. Source-owned private state is represented by accessible fixture storage; this is not a CLR member-access acceptance, which is checked separately by the unchanged source-DLL member checker. The separate source DLL's declared MaxStack is checked by the frozen verifier.

Original PC GameAssembly.dll is hash-locked, mapped at its original address in isolated Windows x64 Python children, and never entered through DllMain. All original caller instruction bytes are verified after installing controlled callee hooks. Real original call/branch/arithmetic instructions execute. Native Buff string literals and five event MethodInfo references are decoded from original usages/metadata; delegate target names are not assigned from candidate code. CLR event delegates are really constructed, subscribed, removed and invoked against a controlled event contract. Original UnityEvent implementation and original selection handler bodies are not executed. Buff external getters/increments are nonmutating contracts. Null/destroyed/live Unity objects, finite/NaN/infinite/signed-zero floats, armor combinations, parsing failures, singleton/config/save mutation order, and two distinct delegate owners are covered as appropriate to each suite. These are caller tests, not full Unity or Android behavior.

There are 24 fault controls. Runtime traces detect 23. CLR permissively truncates the intentionally restored Int64 sentinel to Int32 and does not detect that width defect: the original false-control failure is preserved. The unchanged frozen width checker independently rejects exactly that physical mutant (`I8 is not assignable to System.Int32`). Buff's combined scoped result requires both runtime and frozen width gates. Its undetected runtime control remains explicitly false; it is not relabeled as runtime PASS. Four independent whole-file boundary mutants are also rejected. Frozen stack passes the 45-method union and member-access passes the six targets.

The initial emitter opcode-name alias failure (`ldelem.any` versus Reflection.Emit's name), and a JSON-plus-sign escaping mismatch in the test trace are preserved as harness failures. They were fixed in adapters, without changing candidate logic. The actual R5 unterminated-tail rejection is separate candidate counterevidence.

## Whole-assembly blockers, checked before another full player build

All 2,297 bodies were rescanned on the exact R6 DLL. The frozen checker reports 2,136 PASS / 161 FAIL_OR_UNSUPPORTED; adding only exact direct nongeneric InterfaceImpl input facts yields 2,164 / 133 with the same checker. The access checker rejects 217 sites across 112 methods, zero unresolved. These are gate queues, not counts of proven game bugs. Its nonzero exit is preserved as failure.

A new read-only lexical-tail census identifies 141 remaining unterminated tails: 132 unreachable void warning tails eligible for the same form-only repair, and nine reachable or nonvoid tails requiring separate specifications. No global rewrite is hidden in this checkpoint. Runtime equivalence, native unwind, compiler/Unity promotion, Board gameplay, physical audio, iPad pixels/touch/save/load and an updated unsigned IPA remain pending. The separate R3 shader gate (run 40094204567) proved actual Metal compilation and controlled Editor pixel readback; it does not apply compiler/game acceptance to R6.

## Reproduction and archives

STARTUP-R6-CANDIDATE.zip contains the exact DLL and an internal member manifest. SOURCE-RUNTIME-AND-FAILURE-EVIDENCE.zip contains source, compiled fixture DLLs, manifests, actual CIL exports, native CFGs, complete results/logs and exact physical-mutant byte deltas. The deltas reconstruct every tested mutant from its identified R5/R6 parent and verify SHA-256, without storing dozens of duplicate assemblies. R5 and R4 parent archives remain in their original checkpoint folders.

These native harnesses require Windows x64; they use ctypes Windows ABI, VirtualAlloc, and original PE caller bytes. They do not run unchanged in Linux or on iPad. This run used workspace .NET SDK 10.0.402 / runtime 10.0.13, Python 3.12, Mono.Cecil and the existing authentic support assemblies. Archived csproj relative references match the original workspace; use the included runtime-dependencies/Mono.Cecil.dll to recreate that reference path. Frozen checker SHA-256 remains `2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14`.

From the original workspace, run `startup-r5/run_r6_static.py`, then the five `run_*_runtime.py` scripts. Admin and Board runners require R6 candidate and R6 output directory arguments; the other three explicitly pin R6. The static script requires the existing physical Int64 mutant after first construction. Never set `CIL_DIAGNOSTIC_APPEND_RET` during qualification. Read every per-suite scope and the preserved negative results before interpreting a summary.
'''.encode())
# Preserve old construction archives and append new counterevidence to live state.
old=R/'Recovery/Startup-R5-Pending-2026-10-24';state=json.loads((old/'CURRENT-RESULT.json').read_bytes())
if 'construction_checkpoint_status' not in state:state['construction_checkpoint_status']=state['status']
state.update(status='SUPERSEDED_WITH_RUNTIME_COUNTEREVIDENCE_SEE_R6',runtime_review={'admin_22_controlled_cases':'PASS_R5','board_769_cases':'CLR_INVALID_PROGRAM_UNTERMINATED_UNREACHABLE_TAIL','diagnostic_only_appended_ret':'769_equal_not_candidate_qualification','replacement_checkpoint':'../Startup-R6-2026-10-24/'})
js(old/'CURRENT-RESULT.json',state)
note='\n\n## Actual execution follow-up\n\nR5 has now been executed: its Administrator method passes 22 controlled native/CIL cases, but its Board method is rejected by CLR because of an unterminated unreachable warning tail. Diagnostic accommodation is not candidate qualification. Read [Startup R6](../Startup-R6-2026-10-24/README.md) for the physical four-tail correction, preserved failure records and scoped six-target runtime evidence. Original R5 construction archives remain unchanged.\n'
text=(old/'README.md').read_text('utf-8')
if '## Actual execution follow-up' not in text:(old/'README.md').write_bytes((text+note).encode())
for directory in [D,old]:js(directory/'MANIFEST.json',[record(p.relative_to(directory).as_posix(),p.read_bytes()) for p in sorted(directory.rglob('*')) if p.is_file() and p!=directory/'MANIFEST.json'])
print(json.dumps(dict(checkpoint=str(D),candidate_sha256=digest,cases=2475,archived_mutants=len(mutants),archive_bytes={p.name:p.stat().st_size for p in D.glob('*.zip')})))
