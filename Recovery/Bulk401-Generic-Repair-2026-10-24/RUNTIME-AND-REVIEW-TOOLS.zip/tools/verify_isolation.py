"""Independent reopened audit; does not import the patcher or construction report."""
from pathlib import Path
import sys,json,hashlib,struct,importlib.util
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;R=Q.parents[1]
sys.path.insert(0,str(R/'audit/stage9-native3/python-deps'))
import dnfile
sys.path.insert(0,str(R/'audit/bulk388-qualification-2026-10-23/width-check'))
from width_fixtures import SC,width
s=importlib.util.spec_from_file_location('raw_parsers',R/'audit/native111-publication-2026-10-20/repository/scripts/actions/static_gates.py')
h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(x,msg):
    if not x:raise ValueError(msg)
def decode(b):
    flags=b[6];valid=struct.unpack_from('<Q',b,8)[0];at=24;counts={}
    for t in range(64):
        if valid>>t&1:counts[t]=struct.unpack_from('<I',b,at)[0];at+=4
    rows={}
    for t,n in counts.items():
        rows[t]=[]
        for i in range(n):
            row=[]
            for col in SC[t]:
                w=width(col,flags,counts);row.append(int.from_bytes(b[at:at+w],'little'));at+=w
            rows[t].append(row)
    return rows,b[at:]
def enc(n):return bytes([n]) if n<128 else bytes([0x80|(n>>8),n&255])
old=(R/'audit/bulk388-qualification-2026-10-23/revision-r4/candidates/candidate1.dll').read_bytes()
parent=(R/'audit/native93-codex-2026-10-17/verification-2026-10-17/candidates/candidate1.dll').read_bytes()
need(sha(old)=='ef1992326d1ee494a389bc2c78bdfab131721434c0b08ab5f41dbc3e506c4e48','R4 identity')
need(sha(parent)=='b074224112d46a959de074d3090ab6d0614b036959c66c63b4f49954472e2162','Native93 identity')
plan=json.loads((Q/'source/IMPLEMENTATION-PLAN.json').read_text())
targets={int(x['token'],16) for x in plan['targets']}
extra={int(x['token'],16) for x in json.loads((Q/'GENERIC-TARGETS.json').read_text())}
need(len(extra)==12 and len(targets)==401 and extra<=targets,'Explicit cumulative scope')
need(extra=={0x0600028f,0x060008d4,0x060008d5,0x060008d6,0x060008d7,0x060008d8,0x060008e5,0x060008e6,0x060008e7,0x060008ea,0x060008ed,0x060008f8},'Exact new scope')
def inspect(b):
    pe=h.parse_pe_and_cli(b);md=h.parse_metadata_root(b,pe['meta_off'],pe['meta_size'])
    return pe,md,dnfile.dnPE(data=b)
pp,pm,pd=inspect(parent);op,om,od=inspect(old)
def body(data,p,r):
    at=p.get_offset_from_rva(r.Rva); span=h.parse_raw_method_body_span(data,at)
    return data[at:at+span[0]],at,span
def audit(b):
    cp,cm,cd=inspect(b)
    allowed=set()
    for at in [pp['sections'][-1]['header_offset']+8,pp['sections'][-1]['header_offset']+16,pp['opt_off']+8,pp['opt_off']+56,pp['opt_off']+64,pp['cli_off']+8,pp['cli_off']+12]:allowed.update(range(at,at+4))
    need(all(x==y or i in allowed for i,(x,y) in enumerate(zip(parent,b))),'Native93 original prefix')
    need(cm['heap_sizes']==om['heap_sizes'] and cm['valid_mask']==om['valid_mask'] and cm['sorted_mask']==om['sorted_mask'],'unchanged metadata flags')
    need(cm['streams'].keys()==om['streams'].keys(),'stream set')
    for name in ['#GUID','#US']:need(cm['streams'][name]['bytes']==om['streams'][name]['bytes'],'unchanged '+name)
    need(cm['streams']['#Strings']['bytes']==om['streams']['#Strings']['bytes']+b'ContainsKey\0','exact new name')
    memberblobs=['2001130008','200113011300','2001021300','20020113001301','200008','2001011300']
    localblobs=['0700','07030813001300','07031d13000808','07011e00','0701151284d8011300']
    blobs=[bytes.fromhex(x) for x in memberblobs+localblobs+['0a011e00']]
    need(cm['streams']['#Blob']['bytes']==om['streams']['#Blob']['bytes']+b''.join(enc(len(x))+x for x in blobs),'exact appended signatures')
    ro,to=decode(om['streams']['#~']['bytes']);rc,tc=decode(cm['streams']['#~']['bytes']);need(to==tc,'table trailing bytes')
    changes={10:6,17:5,43:1};numeric=0
    for t,rows in ro.items():
        need(len(rc[t])==len(rows)+changes.get(t,0),'table count '+str(t))
        for rid,(a,c) in enumerate(zip(rows,rc[t]),1):
            if t==6 and (0x06000000|rid) in targets:need(a[1:]==c[1:] and a[0]!=c[0],'target identity/RVA')
            else:need(a==c,'old table row '+str((t,rid)))
            numeric+=len(a)
    names=['get_Item','get_Item','ContainsKey','Add','get_Count','Push'];owners=[0x9b,0x9f,0x9f,0x9f,0x9b,0x9b]
    for i,(name,owner,sig) in enumerate(zip(names,owners,memberblobs),1318):
        r=cd.net.mdtables.MemberRef.rows[i]
        need(str(r.Name)==name and r.Signature.value.hex()==sig and r.Class.table.name=='TypeSpec' and r.Class.row_index==owner,'new member identity')
    for i,sig in enumerate(localblobs,2095):need(cd.net.mdtables.StandAloneSig.rows[i].Signature.value.hex()==sig,'new local signature')
    ms=cd.net.mdtables.MethodSpec.rows[-1];need(ms.Method.table.name=='MethodDef' and ms.Method.row_index==0x290 and ms.Instantiation.value.hex()=='0a011e00','generic Map binding')
    unchanged=zero=inherited=eh=0
    for rid,(pr,orr,cr) in enumerate(zip(pd.net.mdtables.MethodDef.rows,od.net.mdtables.MethodDef.rows,cd.net.mdtables.MethodDef.rows),1):
        tok=0x06000000|rid
        if not pr.Rva:need(not cr.Rva,'zero RVA');unchanged+=1;zero+=1;continue
        pb,pa,ps=body(parent,pd,pr);ob,oa,os=body(old,od,orr);cb,ca,cs=body(b,cd,cr)
        if tok not in targets:need(pb==cb,'non-target body '+hex(tok));unchanged+=1
        elif tok not in extra:need(ob==cb,'inherited R4 body '+hex(tok));inherited+=1
        else:
            need(pb!=cb and b[pa:pa+len(pb)]==pb,'new target and old slot '+hex(tok))
            need(cs[7]==0,'unexpected new EH')
        eh+=cs[7]
    need(unchanged==1916 and inherited==389,'scope counters')
    return dict(state='PASS_REOPENED_SCOPED_ISOLATION',candidate_sha256=sha(b),target_methods=401,new_targets=12,
        unchanged_non_target_methods=unchanged,zero_rva_methods=zero,inherited_389_raw_bodies_identical=True,
        preexisting_R4_numeric_columns=numeric,all_assembly_eh_clauses=eh,blob_bytes=len(cm['streams']['#Blob']['bytes']),
        actual_game_behavior='NOT_PROVEN')
if __name__=='__main__':
    b=(Q/'candidates/candidate1.dll').read_bytes();result=audit(b)
    need(b==(Q/'candidates/candidate2.dll').read_bytes(),'determinism')
    controls=[]
    cp,cm,cd=inspect(b)
    def reject(name,mut):
        try:audit(mut);raise RuntimeError('FALSE_ACCEPT '+name)
        except ValueError as e:controls.append(dict(name=name,rejected=True,reason=str(e)))
    c=bytearray(b);c[100]^=1;reject('original_prefix_byte',bytes(c))
    c=bytearray(b);r=pd.net.mdtables.MethodDef.rows[0x290-1];at=pd.get_offset_from_rva(r.Rva);c[at+12]^=1;reject('non_target_Map_overload',bytes(c))
    c=bytearray(b);r=cd.net.mdtables.MethodDef.rows[0x3e9-1];at=cd.get_offset_from_rva(r.Rva);c[at+12]^=1;reject('inherited_collision_body',bytes(c))
    result.update(deterministic_twice=True,negative_controls=controls)
    (Q/'ISOLATION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
