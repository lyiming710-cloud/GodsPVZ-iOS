"""Specialize generic evidence for concrete contexts; frozen checker unchanged.

This is finite-context static evidence, not universal generic verification.
For a reference-typed closed parameter, box !!0 is the identity (ECMA-335
III.4.1); preserve stack/offsets with nop in the model only, never the DLL.
"""
from pathlib import Path
import importlib.util,json,hashlib,copy,re,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;R=Q.parents[1]
f=R/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py'
assert hashlib.sha256(f.read_bytes()).hexdigest()=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14'
s=importlib.util.spec_from_file_location('frozen',f);v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
j=json.loads((Q/'all-targets.json').read_text('utf-8-sig'))
extra={x['token'] for x in json.loads((Q/'GENERIC-TARGETS.json').read_text())}
results=[];models=[]
def run(d,t,ctx):
    try:r=v.verify(d,t)
    except Exception as e:r=dict(token=d['token'],status='FAIL',error=str(e))
    results.append(dict(r,context=ctx))
for m in j['methods']:
    if m['token'] not in extra:run(m,j['types'],'INHERITED_UNCHANGED');continue
    values=['System.String','System.Int32'] if m['token']!='0x060008F8' else ['UnityEngine.Transform']
    for value in values:
        # The exporter represents the single generic parameter as T. Bind it
        # only for this explicitly enumerated declaring type/method context.
        def text(s):return re.sub(r'(?<![\w.])T(?!\w)',value,s)
        def bind(x):
            if isinstance(x,str):return text(x)
            if isinstance(x,list):return [bind(y) for y in x]
            if isinstance(x,dict):return {text(k):bind(y) for k,y in x.items()}
            return x
        d=bind(copy.deepcopy(m));types=bind(copy.deepcopy(j['types']))
        if m['owner'].endswith(('SwfList`1','SwfAssocList`1')):
            d['owner']=m['owner']+'<'+value+'>'
        # Bind primitive/class facts from the original full-assembly export,
        # never from the unbound generic parameter placeholder.
        for key in list(types):
            if key in j['types']:types[key]=copy.deepcopy(j['types'][key])
        if d['owner'] not in types:
            base=copy.deepcopy(j['types'][m['owner']]);base.pop('unbound',None);base.pop('unresolved',None)
            types[d['owner']]=base
        if value=='System.String' or value=='UnityEngine.Transform':
            for ins in d['instructions']:
                if ins['opcode']=='box' and ins['operand']['type']==value:
                    ins['opcode']='nop';ins['operand']=None
        run(d,types,value);models.append((d,types,value))
controls=[]
def reject(name,token,value,change):
    d,t,_=copy.deepcopy(next(x for x in models if x[0]['token']==token and x[2]==value));change(d,t)
    try:v.verify(d,t);ok=False;why='FALSE_ACCEPT'
    except v.InvalidIL as e:ok=True;why=str(e)
    controls.append(dict(name=name,rejected=ok,reason=why))
reject('wrong_closed_receiver','0x060008D4','System.String',lambda d,t:d.update(owner='FTRuntime.Internal.SwfAssocList`1<System.Int32>'))
reject('wrong_array_element','0x060008E5','System.String',lambda d,t:next(i for i in d['instructions'] if i['opcode']=='newarr')['operand'].update(type='System.Int32'))
reject('wrong_dictionary_generic_owner','0x060008D8','System.String',lambda d,t:next(i for i in d['instructions'] if i['opcode']=='callvirt' and i['operand']['name']=='Add')['operand'].update(owner='System.Collections.Generic.Dictionary`2<System.Object,System.Int32>'))
reject('wrong_capacity_return','0x060008ED','System.Int32',lambda d,t:d['instructions'][-2].update(opcode='ldnull',operand=None))
reject('wrong_wrapper_argument','0x0600028F','System.Int32',lambda d,t:next(i for i in d['instructions'] if i['opcode']=='call' and len(i['operand']['args'])==4)['operand']['args'].__setitem__(1,'System.String'))
report=dict(scope='FROZEN_CHECKER_FINITE_CLOSED_GENERIC_CONTEXTS_PLUS_UNCHANGED_389',candidate_sha256=hashlib.sha256((Q/'candidates/candidate1.dll').read_bytes()).hexdigest(),
    checker_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),checker_modified=False,
    passed=sum(x['status']=='PASS' for x in results),total=len(results),negative_controls=controls,results=results,
    universal_generic_proof=False,actual_CLR_results='ACTUAL-CLR-FIRST.json')
(Q/'CLOSED-STATIC.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:x for k,x in report.items() if k!='results'},indent=2));print([x for x in results if x['status']!='PASS'])
sys.exit(report['passed']!=report['total'] or not all(x['rejected'] for x in controls))
