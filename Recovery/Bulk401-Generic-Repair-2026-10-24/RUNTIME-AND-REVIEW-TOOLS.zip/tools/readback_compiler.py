from pathlib import Path,PurePosixPath
import tarfile,json,hashlib,re
Q=Path(__file__).resolve().parent;D=Q/'compiler-40012442171';S=D/'bulk401'
sha=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((S/'BULK401-COMPILER-REPORT.json').read_text())
assert r['pass'] and r['candidate_sha256']==sha((Q/'candidates/candidate1.dll').read_bytes())
assert r['conversion']['exit_code']==0
assert len(r['compiler_controls'])==6 and all((x['exit_code']!=0)==x['expected_nonzero'] for x in r['compiler_controls'])
cpp=json.loads((S/'ALL-CPP-RESULTS.json').read_text());c=json.loads((S/'ALL-C-RESULTS.json').read_text());results=cpp+c
assert len(cpp)==756 and len(c)==274 and len({x['file'] for x in results})==1030
assert all(x['exit_code']==x['error_count']==0 for x in results)
expected={x['file']:x for x in results};seen=set()
with tarfile.open(D/'bulk401-generated.tar.gz','r:gz') as tf:
    for m in tf:
        path=PurePosixPath(m.name);assert not path.is_absolute() and '..' not in path.parts
        assert m.isfile() or m.isdir()
        if not m.isfile() or path.name not in expected:continue
        b=tf.extractfile(m).read();x=expected[path.name]
        assert m.size==x['bytes'] and sha(b)==x['sha256'],m.name
        assert path.name not in seen;seen.add(path.name)
assert seen==set(expected)
logs=set();manifest=None
with tarfile.open(D/'bulk401-evidence.tar.gz','r:gz') as tf:
    for m in tf:
        path=PurePosixPath(m.name);assert not path.is_absolute() and '..' not in path.parts
        assert m.isfile() or m.isdir()
        if not m.isfile():continue
        if '/candidate/results/clang_logs/' in m.name and path.name.endswith('.log'):
            name=path.name[:-4]
            if name not in expected:continue
            text=tf.extractfile(m).read().decode('utf8','replace')
            assert not re.search(r': (?:fatal )?error:',text),m.name
            assert name not in logs;logs.add(name)
        if m.name.endswith('/candidate/results/il2cpp_conversion/COHERENT-PLAYER-INPUT-ASSEMBLIES.json'):
            manifest=json.load(tf.extractfile(m))
assert logs==set(expected)
assert manifest and next(x for x in manifest['files'] if x['name']=='GodsPVZRuntime1.dll')['sha256']==r['candidate_sha256']
control=r['damaged_r4_control'];assert control['conversion']['exit_code']==0
assert sum(x['error_count'] for x in control['units'])==37 and all(x['exit_code']!=0 for x in control['units'])
out=dict(state='PASS_INDEPENDENT_READBACK_ALL_1030_GENERATED_SOURCES_AND_LOGS',run_id=40012442171,
    source_commit='7e135883bd2781d056e7dd0d3050420831243b85',candidate_sha256=r['candidate_sha256'],
    cpp=len(cpp),c=len(c),failed=0,error_diagnostics=0,compiler_controls=6,damaged_R4_selected_diagnostics=37,
    compiler_profile='LINUX_PORTABLE_UNSTRIPPED_PROFILE_NOT_REAL_UNITY_EXPORT_PROFILE',
    archives=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in D.glob('*.tar.gz')],
    unity=False,apple_compiler=False,linked=False,ipa=None)
(Q/'COMPILER-READBACK.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
