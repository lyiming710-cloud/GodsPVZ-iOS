"""Execute original PC method bytes under Windows x64, with explicit callees.

Normal paths only. Original PE input is read-only. A private fixed-address
image is mapped in this disposable process; only dependency entry points are
hooked. The twelve method bodies under comparison are never changed.
"""
from pathlib import Path
import ctypes as C,struct,json,sys,hashlib
Q=Path(__file__).resolve().parent;R=Q.parents[1];sys.dont_write_bytecode=True
sys.path.insert(0,str(R/'audit/stage9-native3/python-deps'))
import pefile
raw=(R/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/GameAssembly.dll').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d'
pe=pefile.PE(data=raw);base=pe.OPTIONAL_HEADER.ImageBase;size=pe.OPTIONAL_HEADER.SizeOfImage
k=C.WinDLL('kernel32',use_last_error=True)
k.VirtualAlloc.argtypes=[C.c_void_p,C.c_size_t,C.c_uint32,C.c_uint32];k.VirtualAlloc.restype=C.c_void_p
k.VirtualFree.argtypes=[C.c_void_p,C.c_size_t,C.c_uint32];k.VirtualFree.restype=C.c_int
address=k.VirtualAlloc(base,size,0x3000,0x40)
assert address==base,('fixed image unavailable',address,C.get_last_error())
C.memmove(base,raw[:pe.OPTIONAL_HEADER.SizeOfHeaders],pe.OPTIONAL_HEADER.SizeOfHeaders)
for s in pe.sections:C.memmove(base+s.VirtualAddress,raw[s.PointerToRawData:s.PointerToRawData+s.SizeOfRawData],s.SizeOfRawData)
owned=[];callbacks=[];hooked={};state={};dicts={};byname={};byid={0:None};errors=[]
def alloc(n):
    b=C.create_string_buffer(n);owned.append(b);return C.addressof(b)
def w64(p,v):C.c_uint64.from_address(p).value=v or 0
def r64(p):return C.c_uint64.from_address(p).value
def w32(p,v):C.c_int32.from_address(p).value=v
def r32(p):return C.c_int32.from_address(p).value
def ident(value):
    if value is None:return 0
    if value not in byname:
        ptr=alloc(32);byname[value]=ptr;byid[ptr]=value
    return byname[value]
def hook(va,restype,argtypes,fn):
    def guarded(*args):
        try:return fn(*args)
        except Exception as e:errors.append(str(e));return None if restype in (None,C.c_void_p) else 0
    cb=C.CFUNCTYPE(restype,*argtypes)(guarded);callbacks.append(cb)
    pointer=C.cast(cb,C.c_void_p).value
    code=b'\xff\x25\0\0\0\0'+struct.pack('<Q',pointer)
    C.memmove(va,code,len(code));hooked[hex(va)]='CONTROLLED '+fn.__name__
    return pointer
ptr=C.c_void_p;i32=C.c_int32;u64=C.c_uint64
typeclass=alloc(512);w32(typeclass+0xe0,1);C.c_ubyte.from_address(typeclass+0x135).value=1
arrayclass=alloc(512);w32(arrayclass+0x104,8)
ctx=alloc(512);klass=alloc(512);method=alloc(128);w64(klass+0xc0,ctx);w64(method+0x20,klass);w64(method+0x38,ctx)
for at in [0x18,0x20]:w64(ctx+at,typeclass)
for at in [0x58,0x68,0x78,0x80,0x88]:w64(ctx+at,method)
def array(data):
    p=alloc(32+8*len(data));w64(p,arrayclass);w64(p+0x18,len(data))
    for i,value in enumerate(data):w64(p+32+8*i,ident(value))
    return p
def listobj(data,n):
    p=alloc(32);w64(p+0x10,array(data));w32(p+0x18,n);return p
def snapshot(p):
    data=r64(p+0x10);n=r64(data+0x18)
    assert n<=32
    return dict(size=r32(p+0x18),data=[byid[r64(data+32+8*i)] for i in range(n)])
def no_barrier(*_):return None
def new_array(_cls,n):
    assert 0<=n<=32
    return array([None]*n)
def array_copy(src,dst,n,_method):
    assert 0<=n<=min(r64(src+0x18),r64(dst+0x18));C.memmove(dst+32,src+32,n*8)
def contains(d,key,_method):return byid[key] in dicts[d]
def dict_item(d,key,_method):return dicts[d][byid[key]]
def dict_add(d,key,value,_method):
    key=byid[key];assert key not in dicts[d];dicts[d][key]=value
hook(0x18024f360,None,[ptr,ptr],no_barrier)
hook(0x18024f3e0,ptr,[ptr,u64],new_array)
hook(0x180cb8c90,None,[ptr,ptr,i32,ptr],array_copy)
hook(0x1805d8190,C.c_bool,[ptr,ptr,ptr],contains)
hook(0x1805ea6b0,i32,[ptr,ptr,ptr],dict_item)
hook(0x1805d80b0,None,[ptr,ptr,i32,ptr],dict_add)
# Original RGCTX index 11 identifies SwfList<T>.get_Item. Its shared ABI thunk
# is replaced by a direct jump to the original reference implementation.
C.memmove(0x1800b4980,b'\xff\x25\0\0\0\0'+struct.pack('<Q',0x1809d5990),14)
hooked['0x1800b4980']='CONTROLLED_ABI_THUNK_TO_ORIGINAL_0x1809d5990'
def copy(dest,src,n):
    assert n in (8,24);C.memmove(dest,src,n)
def get_x(_this,_method):state['trace'].append('GetMapX');return state['x']
def invoke(_code,_method,_this,args,result):
    state['trace'].append('Bounded');ap=C.cast(args,C.POINTER(ptr))
    value=byid[ap[1]] if not state['value_type'] else dict(zip(['A','B','C'],struct.unpack('<qqq',C.string_at(ap[1],24))))
    state['call']=dict(num=r32(ap[0]),min=r32(ap[2]),max=r32(ap[3]),value=value,trace=state['trace'])
    w64(result,state['result'])
hook(0x1802f64f0,None,[ptr,ptr,u64],copy)
C.memmove(0x1802c5380,b'\xc3',1);hooked['0x1802c5380']='CONTROLLED_STACK_PROBE_NO_EXCEPTION'
hook(0x18032c3b0,i32,[ptr,ptr],get_x)
# Store the callback pointer directly, without altering an unrelated code slot.
cb=C.CFUNCTYPE(None,ptr,ptr,ptr,ptr,ptr)(invoke);callbacks.append(cb);invoker=C.cast(cb,ptr).value
mapctx=alloc(32);bounded=alloc(128);w64(bounded+0x10,invoker);w64(bounded,0xcafebabe);w64(mapctx,typeclass);w64(mapctx+8,bounded)
mapmethod=alloc(128);w64(mapmethod+0x38,mapctx)
def component_get(_go,_method):state['trace'].append('Get');return state['existing']
def component_add(_go,_method):state['trace'].append('Add');return state['added']
def truth(value,_method):state['trace'].append('Truth');return bool(value and state['alive'])
hook(0x18046dc80,ptr,[ptr,ptr],component_get)
hook(0x18046d280,ptr,[ptr,ptr],component_add)
hook(0x18131f870,C.c_bool,[ptr,ptr],truth)
w64(0x181bb0500,typeclass)
componentctx=alloc(32);w64(componentctx,method);w64(componentctx+0x10,method)
componentmethod=alloc(128);w64(componentmethod+0x38,componentctx)
vmap={0x060008e5:0x1809d5020,0x060008e6:0x1809d4d50,0x060008e7:0x1809d4cc0,0x060008ea:0x1809d5990,0x060008ed:0x18065baa0,
      0x060008d4:0x1809d46e0,0x060008d5:0x1809d44f0,0x060008d6:0x18065baa0,0x060008d7:0x1809d3730,0x060008d8:0x1809d3110,
      0x0600028f:0x180490a10,0x060008f8:0x1804b2f00}
# Check that all actual target bytes still equal the original input image.
bindings=json.loads((Q/'evidence/original-generic-bindings.json').read_text())['methods']
method_spans=[]
for tok,va in vmap.items():
    assert any(int(x['token'],16)==tok and int(x['va'],16)==va for x in bindings)
    import re
    asm=(Q/'evidence'/f'native-{va:X}.asm').read_text()
    end=int(re.search(r' END ([0-9A-F]+)',asm).group(1),16)
    original=pe.get_data(va-base,end-va);assert C.string_at(va,len(original))==original
    method_spans.append(dict(token=hex(tok),va=hex(va),bytes=len(original),full_bytes_sha256=hashlib.sha256(original).hexdigest()))
rows=json.loads((Q/'ACTUAL-CLR-NATIVE-ROWS.json').read_text())['native_comparison_rows'];results=[]
print('MAPPED_ORIGINAL_IMAGE',hex(base),'cases',len(rows),flush=True)
for index,row in enumerate(rows):
    token=int(row['token'],16);entry=vmap[token];data=row['input'];kind=row['kind'];value=None
    if kind in ('list','assoc'):
        lst=listobj(data['data'],data['size']);this=lst
        if kind=='assoc':
            this=alloc(40);w64(this+0x10,lst);d=alloc(32);dicts[d]={'v0':0,'v1':1};w64(this+0x18,d)
        if token==0x060008e5:C.CFUNCTYPE(None,ptr,ptr,ptr)(entry)(this,ident(data['arg']),method)
        elif token in (0x060008d4,0x060008ea):value=byid[C.CFUNCTYPE(ptr,ptr,i32,ptr)(entry)(this,data['arg'],method)]
        elif token in (0x060008e6,0x060008e7):value=byid[C.CFUNCTYPE(ptr,ptr,ptr)(entry)(this,method)]
        elif token in (0x060008ed,0x060008d6):value=C.CFUNCTYPE(i32,ptr,ptr)(entry)(this,method)
        elif token==0x060008d5:value=C.CFUNCTYPE(i32,ptr,ptr,ptr)(entry)(this,ident(data['arg']),method)
        elif token==0x060008d7:value=C.CFUNCTYPE(C.c_bool,ptr,ptr,ptr)(entry)(this,ident(data['arg']),method)
        elif token==0x060008d8:C.CFUNCTYPE(None,ptr,ptr,ptr)(entry)(this,ident(data['arg']),method)
        actual=dict(value=value,**snapshot(lst))
        if kind=='assoc':actual['dict']=dicts[d]
    elif kind=='map':
        value_type=isinstance(data['value'],dict);w32(typeclass+0xfc,24 if value_type else 8)
        C.c_uint32.from_address(typeclass+0x28).value=0x80000000 if value_type else 0
        arg=ident(data['value']) if not value_type else alloc(24)
        if value_type:C.memmove(arg,struct.pack('<qqq',*[data['value'][x] for x in ['A','B','C']]),24)
        state.update(x=data['x'],trace=[],value_type=value_type,result=ident('map-result'))
        ret=C.CFUNCTYPE(ptr,ptr,i32,ptr,ptr)(entry)(alloc(32),data['num'],arg,mapmethod)
        assert ret==state['result'];actual=state['call']
    else:
        state.update(trace=[],existing=ident('existing') if data['state'] else 0,added=ident('added'),alive=data['state']==1)
        ret=C.CFUNCTYPE(ptr,ptr,C.c_bool,ptr)(entry)(alloc(32),data['add'],componentmethod)
        actual=dict(value=byid[ret or 0],trace=state['trace'])
    assert not errors,errors
    ok=actual==row['output'];results.append(dict(index=index,token=row['token'],kind=kind,input=data,actual_original_native=actual,actual_candidate_CIL=row['output'],equal=ok))
    if not ok:print('DIFF',results[-1],flush=True)
    if (index+1)%20==0:print('NATIVE_PROGRESS',index+1,flush=True)
report=dict(scope='ORIGINAL_PC_WINDOWS_X64_VS_ACTUAL_CANDIDATE_CIL_CONTROLLED_NORMAL_PATHS',
    candidate_sha256=hashlib.sha256((Q/'candidates/candidate1.dll').read_bytes()).hexdigest(),original_sha256=hashlib.sha256(raw).hexdigest(),
    CIL_rows_sha256=hashlib.sha256((Q/'ACTUAL-CLR-NATIVE-ROWS.json').read_bytes()).hexdigest(),
    cases=len(results),methods=len({x['token'] for x in results}),differences=sum(not x['equal'] for x in results),
    external_callees='CONTROLLED_UNPROVEN',exception_paths='NOT_EXECUTED_NATIVELY',universal_semantics=False,
    hooks=hooked,method_entry_identities=method_spans,results=results)
(Q/'ORIGINAL-NATIVE-VS-CIL.json').write_text(json.dumps(report,indent=2)+'\n')
assert k.VirtualFree(base,0,0x8000)
print(json.dumps({x:report[x] for x in ['cases','methods','differences','scope']}),flush=True)
sys.exit(report['differences']!=0)
