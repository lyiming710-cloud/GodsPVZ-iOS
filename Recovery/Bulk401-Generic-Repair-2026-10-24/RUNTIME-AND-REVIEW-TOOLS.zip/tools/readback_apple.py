from pathlib import Path
import json,hashlib,re,zipfile,shutil
Q=Path(__file__).resolve().parent;R=Q.parents[1];A=Q/'apple-40014022885'
r=json.loads((A/'APPLE-REPORT.json').read_text());rows=json.loads((A/'ALL-APPLE-RESULTS.json').read_text())
linux=json.loads((Q/'compiler-40012442171/bulk401/ALL-CPP-RESULTS.json').read_text())+json.loads((Q/'compiler-40012442171/bulk401/ALL-C-RESULTS.json').read_text())
assert r['failed']==r['diagnostics']==r['unparsed_error_lines']==0 and r['attempted']==len(rows)==len(linux)==1030
pins={x['file']:x for x in linux}
for x in rows:
    assert x['sha256']==pins[x['file']]['sha256'] and x['bytes']==pins[x['file']]['bytes'] and x['exit_code']==x['error_count']==0
    log=(A/'logs'/(x['file']+'.log')).read_text(errors='replace')
    assert not re.search(r': (?:fatal )?error:',log)
controls=json.loads((A/'COMPILER-CONTROLS.json').read_text())+json.loads((A/'C-COMPILER-CONTROLS.json').read_text())
assert len(controls)==6 and all(x['expectation_met'] for x in controls)
old=json.loads((A/'DAMAGED-R4-CONTROL.json').read_text());assert old['exit_code']==1 and old['error_count']==34
result=dict(state='PASS_INDEPENDENT_APPLE_ALL_1030_LOGS_AND_SOURCE_IDENTITIES',run_id=40014022885,
    source_commit='e2c3f98215718951358de8963a7e7d64bde1f2c6',candidate_sha256=r['candidate_sha256'],logs_checked=1030,
    failed=0,diagnostics=0,compiler_controls=6,damaged_R4_expected_diagnostics=34,
    profile='FRESH_PORTABLE_GENERATED_CODE_WITH_REAL_IOS_APPLE_FLAGS_AND_RUNTIME_HEADERS',new_unity_export=False,linked=False,ipa=None)
(Q/'APPLE-READBACK.json').write_text(json.dumps(result,indent=2)+'\n')
out=R/'audit/repo-native113/Recovery/Bulk401-Generic-Repair-2026-10-24';d=out/'apple-40014022885';d.mkdir(exist_ok=False)
for p in A.glob('*.json'):shutil.copyfile(p,d/p.name)
with zipfile.ZipFile(d/'ALL-APPLE-RAW-LOGS.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted((A/'logs').iterdir()):z.write(p,'logs/'+p.name)
shutil.copyfile(Q/'APPLE-READBACK.json',out/'APPLE-READBACK.json')
print(json.dumps(result))
