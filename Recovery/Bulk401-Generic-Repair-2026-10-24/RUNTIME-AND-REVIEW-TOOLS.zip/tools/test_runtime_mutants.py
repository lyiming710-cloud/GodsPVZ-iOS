"""Mutate real candidate bytes, then execute the same actual-CLR fixture."""
from pathlib import Path
import sys,json,subprocess,struct,hashlib
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;R=Q.parents[1]
sys.path.insert(0,str(R/'audit/stage9-native3/python-deps'))
import dnfile
from dncil.cil.body import CilMethodBody
from dncil.cil.body.reader import CilMethodBodyReaderBytes
b=(Q/'candidates/candidate1.dll').read_bytes();p=dnfile.dnPE(data=b)
assert hashlib.sha256(b).hexdigest()=='6de4db6c94b80a43876aea060b573ed60c1fa7170cff485103d2c808b94762ae'
out=Q/(sys.argv[1] if len(sys.argv)>1 else 'runtime-controls');out.mkdir(exist_ok=False)
def method(t):
    r=p.net.mdtables.MethodDef.rows[(t&0xffffff)-1];at=p.get_offset_from_rva(r.Rva)
    return at,CilMethodBody(CilMethodBodyReaderBytes(b[at:at+32768]))
mutants=[]
def add(name,t,change,want):
    raw=bytearray(b);at,body=method(t);change(raw,at,body)
    file=out/(name+'.dll');file.write_bytes(raw);mutants.append((name,file,want))
def flip_pop(raw,at,body):
    ins=body.instructions[-2];assert ins.opcode.name=='ldloc.1';raw[at+ins.offset]=0x08
add('pop_returns_default',0x060008e6,flip_pop,'ASSERT Pop returns previous last')
def flip_bound(raw,at,body):
    ins=next(i for i in body.instructions if i.opcode.name=='blt.un');raw[at+ins.offset]=0x3f
add('index_uses_signed_bounds',0x060008ea,flip_bound,'ASSERT unsigned index rejects negative before data null')
def flip_key(raw,at,body):
    struct.pack_into('<I',raw,at+4,2);raw[at+body.header_size:at+body.header_size+2]=b'\x16\x2a'
add('dictionary_getter_returns_zero',0x060008d5,flip_key,'ASSERT Assoc key query delegates to dictionary')
def stale_list(raw,at,body):
    ins=body.instructions
    pos=next(i for i,x in enumerate(ins) if x.opcode.name=='callvirt' and x.operand.value==0x0a00052c)
    a,f=ins[pos-3:pos-1];assert a.opcode.name=='ldarg.0' and f.opcode.name=='ldfld'
    raw[at+a.offset]=0x06;raw[at+f.offset:at+f.offset+5]=b'\0'*5
add('assoc_caches_list_before_callback',0x060008d8,stale_list,'ASSERT Assoc reload list after Add callback')
def drop_copy(raw,at,body):
    ins=next(i for i in body.instructions if i.opcode.name=='call' and i.operand.value==0x0a0003d5)
    raw[at+ins.offset:at+ins.offset+5]=b'\x26\x26\x26\0\0'
add('push_omits_existing_array_copy',0x060008e5,drop_copy,'ASSERT Push copies original items and appends')
def wrong_min(raw,at,body):
    ins=next(i for i in body.instructions if i.opcode.name=='ldc.i4.0');raw[at+ins.offset]=0x17
add('map_wrong_minimum',0x0600028f,wrong_min,'ASSERT Map forwards value and inclusive bounds')
def wrong_truth(raw,at,body):
    ins=next(i for i in body.instructions if i.opcode.name=='brtrue');raw[at+ins.offset]=0x39
add('component_inverts_unity_truthiness',0x060008f8,wrong_truth,'ASSERT GetComponent return identity with fake-null')
mutants.insert(0,('positive_candidate',Q/'candidates/candidate1.dll',None))
mutants.append(('damaged_r4',R/'audit/bulk388-qualification-2026-10-23/revision-r4/candidates/candidate1.dll','ASSERT Pop returns previous last'))
results=[]
for name,file,want in mutants:
    report=out/(name+'.json')
    argv=[str(R/'.local/dotnet10/dotnet.exe'),str(Q/'runtime/bin/Release/net10.0/Runtime.dll'),str(file),str(report)]
    run=subprocess.run(argv,capture_output=True,text=True,timeout=45)
    (out/(name+'.stdout.log')).write_text(run.stdout)
    (out/(name+'.stderr.log')).write_text(run.stderr)
    obs=json.loads(report.read_text())
    ok=(run.returncode==0 and obs['pass']) if want is None else (run.returncode==1 and obs['pass'] is False and want in obs.get('error',''))
    record=dict(name=name,sha256=hashlib.sha256(file.read_bytes()).hexdigest(),exit=run.returncode,
        expected_failure=want,matched_expected=ok,assertions=obs['assertions_executed'],error=obs.get('error'))
    results.append(record);print(name,ok,record['assertions'])
    # Preserve all observations even if a control exposes an issue.
(Q/('ACTUAL-CLR-CONTROLS-FINAL.json' if len(sys.argv)>1 else 'ACTUAL-CLR-CONTROLS.json')).write_text(json.dumps(dict(controls=results,all_matched=all(x['matched_expected'] for x in results)),indent=2)+'\n')
sys.exit(not all(x['matched_expected'] for x in results))
