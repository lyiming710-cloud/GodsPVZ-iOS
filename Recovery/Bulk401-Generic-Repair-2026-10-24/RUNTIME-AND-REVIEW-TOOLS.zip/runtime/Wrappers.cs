using System.Reflection;
using System.Reflection.Emit;
using MC=Mono.Cecil;
using CIL=Mono.Cecil.Cil;

internal static partial class Program
{
    public sealed class GridStub;
    public sealed class MapStub(int x)
    {
        public int X=x,Calls;public object? Value;public int Num,Min,Max;
        public readonly List<string> Trace=[];public readonly List<GridStub> Result=[];
        public int GetMapX(){Trace.Add("GetMapX");return X;}
        public List<GridStub> Bounded<T>(int num,T value,int min,int max)
        {Trace.Add("Bounded");Calls++;Value=value;Num=num;Min=min;Max=max;return Result;}
    }
    public class ObjectStub{public bool Alive=true;}
    public class ComponentStub:ObjectStub;
    public sealed class TestComponent:ComponentStub;
    public sealed class GameObjectStub
    {
        public ComponentStub? Existing,Added;public readonly List<string> Trace=[];
        public T? GetComponent<T>()where T:ComponentStub{Trace.Add("Get");return (T?)Existing;}
        public T? AddComponent<T>()where T:ComponentStub{Trace.Add("Add");return (T?)Added;}
    }
    private static List<string>? TruthTrace;
    public static bool Truth(ObjectStub? value){TruthTrace!.Add("Truth");return value?.Alive??false;}
    private static readonly Dictionary<string,OpCode> EmitOps=typeof(OpCodes).GetFields(BindingFlags.Public|BindingFlags.Static)
        .Where(f=>f.FieldType==typeof(OpCode)).Select(f=>(OpCode)f.GetValue(null)!).ToDictionary(x=>x.Name!);
    private static DynamicMethod Transcribe(MC.MethodDefinition m,Type arg)
    {
        Type TypeOf(MC.TypeReference t)
        {
            if(t is MC.GenericParameter)return arg;
            return t.FullName switch {
                "System.Int32"=>typeof(int),"System.Boolean"=>typeof(bool),"System.Void"=>typeof(void),
                "Map"=>typeof(MapStub),"UnityEngine.GameObject"=>typeof(GameObjectStub),
                "System.Collections.Generic.List`1<Grid>"=>typeof(List<GridStub>),
                _=>throw new NotSupportedException("Unbound wrapper type "+t.FullName)};
        }
        var args=m.Parameters.Select(x=>TypeOf(x.ParameterType)).ToList();
        if(m.HasThis)args.Insert(0,TypeOf(m.DeclaringType));
        var dm=new DynamicMethod("ActualCIL_"+m.MetadataToken.ToInt32().ToString("X8"),TypeOf(m.ReturnType),args.ToArray(),typeof(Program).Module,true){InitLocals=m.Body.InitLocals};
        var il=dm.GetILGenerator();var locals=m.Body.Variables.Select(v=>il.DeclareLocal(TypeOf(v.VariableType))).ToArray();
        var labels=m.Body.Instructions.ToDictionary(x=>x,_=>il.DefineLabel());
        Need(m.Body.ExceptionHandlers.Count==0,"wrapper has no unmodeled EH");
        foreach(var ins in m.Body.Instructions)
        {
            il.MarkLabel(labels[ins]);var op=EmitOps[ins.OpCode.Name];
            switch(ins.Operand)
            {
                case null:il.Emit(op);break;
                case CIL.Instruction target:il.Emit(op,labels[target]);break;
                case CIL.VariableDefinition v:il.Emit(op,locals[v.Index]);break;
                case MC.ParameterDefinition p:il.Emit(op,(short)(p.Index+(m.HasThis?1:0)));break;
                case int n:il.Emit(op,n);break;
                case MC.TypeReference tr:il.Emit(op,TypeOf(tr));break;
                case MC.MethodReference mr:
                    MethodInfo method;
                    if(mr.DeclaringType.FullName=="Map" && mr.Name=="GetMapX")method=typeof(MapStub).GetMethod("GetMapX")!;
                    else if(mr.DeclaringType.FullName=="Map" && mr.Name=="RandomGet_Grid_TestPlace" && mr.Parameters.Count==4 && mr is MC.GenericInstanceMethod)
                        method=typeof(MapStub).GetMethod("Bounded")!.MakeGenericMethod(arg);
                    else if(mr.DeclaringType.FullName=="UnityEngine.GameObject" && mr is MC.GenericInstanceMethod && mr.Name is "GetComponent" or "AddComponent")
                        method=typeof(GameObjectStub).GetMethod(mr.Name)!.MakeGenericMethod(arg);
                    else if(mr.DeclaringType.FullName=="UnityEngine.Object" && mr.Name=="op_Implicit")method=typeof(Program).GetMethod("Truth")!;
                    else throw new NotSupportedException("Unbound wrapper call "+mr.FullName);
                    il.Emit(op,method);break;
                default:throw new NotSupportedException("Untranscribed CIL operand "+ins);
            }
        }
        return dm;
    }
    private static void RunMapWrapper<T>(MC.MethodDefinition method,T value)
    {
        var fn=(Func<MapStub,int,T,List<GridStub>>)Transcribe(method,typeof(T)).CreateDelegate(typeof(Func<MapStub,int,T,List<GridStub>>));
        foreach(int x in new[]{0,1,8,-1,int.MinValue,int.MaxValue})
        foreach(int num in new[]{-1,0,3,100})
        {
            var map=new MapStub(x);var result=fn(map,num,value);
            Need(ReferenceEquals(result,map.Result) && map.Calls==1,"Map wrapper returns exact callee result");
            Need(map.Num==num && Equals(map.Value,value) && map.Min==0 && map.Max==unchecked(x-1),"Map forwards value and inclusive bounds");
            Need(map.Trace.SequenceEqual(new[]{"GetMapX","Bounded"}),"Map call order");
            NativeRows.Add(new {kind="map",token="0x0600028F",input=new{x,num,value},
                output=new{num=map.Num,min=map.Min,max=map.Max,value=map.Value,trace=map.Trace}});
        }
    }
    private static void RunControlledWrappers(string dll)
    {
        using var module=MC.ModuleDefinition.ReadModule(dll);
        var map=(MC.MethodDefinition)module.LookupToken(0x0600028F);
        RunMapWrapper(map,"reference-identity");RunMapWrapper(map,new BigKey(long.MinValue,17,long.MaxValue));
        var component=(MC.MethodDefinition)module.LookupToken(0x060008F8);
        Need(component.GenericParameters.Count==1 && component.GenericParameters[0].Constraints.Any(c=>c.ConstraintType.FullName=="UnityEngine.Component"),"real Component generic constraint");
        var get=(Func<GameObjectStub,bool,TestComponent?>)Transcribe(component,typeof(TestComponent)).CreateDelegate(typeof(Func<GameObjectStub,bool,TestComponent?>));
        foreach(bool add in new[]{false,true})
        foreach(int state in new[]{0,1,2})
        {
            var existing=state==0?null:new TestComponent{Alive=state==1};var added=new TestComponent();
            var go=new GameObjectStub{Existing=existing,Added=added};TruthTrace=go.Trace;
            var got=get(go,add);bool creates=add && !(existing?.Alive??false);
            Need(ReferenceEquals(got,creates?added:existing),"GetComponent return identity with fake-null");
            Need(go.Trace.SequenceEqual(!add?new[]{"Get"}:creates?new[]{"Get","Truth","Add"}:new[]{"Get","Truth"}),"GetComponent callback order");
            NativeRows.Add(new{kind="component",token="0x060008F8",input=new{add,state},
                output=new{value=ReferenceEquals(got,added)?"added":ReferenceEquals(got,existing)&&got is not null?"existing":null,trace=go.Trace}});
        }
        Throws<NullReferenceException>(()=>get(null!,true),"GetComponent null receiver");
        Observations.Add(new{token="0x0600028F",mode="actual candidate instruction transcription",external_calls="CONTROLLED_UNPROVEN",cases=48});
        Observations.Add(new{token="0x060008F8",mode="actual candidate instruction transcription",external_calls="CONTROLLED_UNPROVEN",cases=7});
    }
}
