using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text.Json;

internal static partial class Program
{
    private static readonly List<object> NativeRows=[];
    private static void RunNativeRows(Assembly asm)
    {
        var lt=asm.GetType("FTRuntime.Internal.SwfList`1",true)!.MakeGenericType(typeof(string));
        foreach(int capacity in new[]{1,2,4,8})
        foreach(int size in Enumerable.Range(1,capacity))
        foreach(int token in new[]{0x060008E5,0x060008E6,0x060008E7,0x060008EA,0x060008ED})
        {
            string?[] data=Enumerable.Range(0,capacity).Select(i=>i<size?"v"+i:null).ToArray();
            var obj=List(lt,Values(typeof(string),data.Cast<object?>().ToArray()),size);
            object? arg=token==0x060008E5?"append":token==0x060008EA?size-1:null;
            object? value=arg is null?Invoke(obj,token):Invoke(obj,token,arg);
            NativeRows.Add(new {kind="list",token=$"0x{token:X8}",input=new{data,size,arg},
                output=new{value,size=Size(obj),data=Data(obj)!.Cast<object?>().ToArray()}});
        }
        var at=asm.GetType("FTRuntime.Internal.SwfAssocList`1",true)!.MakeGenericType(typeof(string));
        foreach(int capacity in new[]{2,4})
        foreach(int token in new[]{0x060008D4,0x060008D5,0x060008D6,0x060008D7,0x060008D8})
        {
            string?[] data=Enumerable.Range(0,capacity).Select(i=>i<2?"v"+i:null).ToArray();
            var list=List(lt,Values(typeof(string),data.Cast<object?>().ToArray()),2);
            var dict=new Dictionary<string,int>{{"v0",0},{"v1",1}};
            object obj=RuntimeHelpers.GetUninitializedObject(at);Field(at,"_list").SetValue(obj,list);Field(at,"_dict").SetValue(obj,dict);
            object? arg=token==0x060008D4?1:token==0x060008D5?"v1":token==0x060008D6?null:token==0x060008D7?"absent":"append";
            object? value=arg is null?Invoke(obj,token):Invoke(obj,token,arg);
            NativeRows.Add(new {kind="assoc",token=$"0x{token:X8}",input=new{data,size=2,arg},
                output=new{value,size=Size(list),data=Data(list)!.Cast<object?>().ToArray(),dict}});
        }
    }
}
