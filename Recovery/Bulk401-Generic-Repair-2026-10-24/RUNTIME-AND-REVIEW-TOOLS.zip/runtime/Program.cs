using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;

internal static partial class Program
{
    private static int Checks;
    private static readonly List<object> Observations=[];
    private static void Need(bool ok,string why)
    {
        Checks++;
        if(!ok)throw new InvalidOperationException("ASSERT "+why);
    }
    private static MethodInfo Method(Type type,int token) => type.GetMethods(BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic)
        .Single(x=>x.MetadataToken==token);
    private static FieldInfo Field(Type type,string name) => type.GetField(name,BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public)!;
    private static object? Invoke(object instance,int token,params object?[] args)
    {
        try{return Method(instance.GetType(),token).Invoke(instance,args);}
        catch(TargetInvocationException ex)when(ex.InnerException is not null)
        {System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(ex.InnerException).Throw();throw;}
    }
    private static object List(Type t,Array? data,int size)
    {
        object x=RuntimeHelpers.GetUninitializedObject(t);
        Field(t,"_data").SetValue(x,data);Field(t,"_size").SetValue(x,size);return x;
    }
    private static int Size(object list)=>(int)Field(list.GetType(),"_size").GetValue(list)!;
    private static Array? Data(object list)=>(Array?)Field(list.GetType(),"_data").GetValue(list);
    private static Array Values(Type t,params object?[] values)
    {var a=Array.CreateInstance(t,values.Length);for(int i=0;i<values.Length;i++)a.SetValue(values[i],i);return a;}
    private static void Throws<T>(Action act,string why) where T:Exception
    {
        Exception? seen=null;try{act();}catch(Exception ex){seen=ex;}
        Need(seen is T,why+" exception="+seen?.GetType().Name);
    }
    private static void RunList(Assembly asm,Type valueType,object a,object b,object c)
    {
        Type t=asm.GetType("FTRuntime.Internal.SwfList`1",true)!.MakeGenericType(valueType);
        object? zero=valueType.IsValueType?Activator.CreateInstance(valueType):null;
        var list=List(t,Values(valueType,a,b,c),3);
        Need(Equals(Invoke(list,0x060008E6),c),"Pop returns previous last");
        Need(Size(list)==2 && Equals(Data(list)!.GetValue(2),zero),"Pop decrements and clears default(T)");
        Need(Equals(Invoke(list,0x060008E7),b) && Size(list)==2,"Peek retains size");
        Need(Equals(Invoke(list,0x060008EA,0),a),"indexer returns index");
        Need((int)Invoke(list,0x060008ED)! ==3,"Capacity returns array length");
        var empty=List(t,Values(valueType),0);
        Throws<InvalidOperationException>(()=>Invoke(empty,0x060008E6),"empty Pop");
        Throws<InvalidOperationException>(()=>Invoke(empty,0x060008E7),"empty Peek");
        Need(Size(empty)==0,"empty operations do not mutate size");
        var n=List(t,null,2);
        Throws<NullReferenceException>(()=>Invoke(n,0x060008E6),"null data Pop");Need(Size(n)==1,"Pop mutation before NRE");
        n=List(t,null,2);Throws<NullReferenceException>(()=>Invoke(n,0x060008E7),"null data Peek");Need(Size(n)==2,"Peek NRE preserves size");
        n=List(t,null,2);Throws<IndexOutOfRangeException>(()=>Invoke(n,0x060008EA,-1),"unsigned index rejects negative before data null");
        Throws<NullReferenceException>(()=>Invoke(n,0x060008EA,0),"valid index null data");
        Throws<NullReferenceException>(()=>Invoke(n,0x060008ED),"Capacity NRE");
        var bad=List(t,Values(valueType,a),4);
        Throws<IndexOutOfRangeException>(()=>Invoke(bad,0x060008E6),"oversize Pop");Need(Size(bad)==3,"Pop mutation before bounds failure");
        var push=List(t,Values(valueType),0);Invoke(push,0x060008E5,a);
        Need(Size(push)==1 && Data(push)!.Length==4 && Equals(Data(push)!.GetValue(0),a),"Push first capacity=4");
        Invoke(push,0x060008E5,b);Invoke(push,0x060008E5,c);Invoke(push,0x060008E5,a);
        Array old=Data(push)!;Invoke(push,0x060008E5,b);
        Need(Size(push)==5 && Data(push)!.Length==8 && !ReferenceEquals(old,Data(push)),"Push doubles capacity");
        Need(Equals(Data(push)!.GetValue(0),a) && Equals(Data(push)!.GetValue(1),b) && Equals(Data(push)!.GetValue(2),c) && Equals(Data(push)!.GetValue(4),b),"Push copies original items and appends");
        old=Data(push)!;Invoke(push,0x060008E5,c);Need(ReferenceEquals(old,Data(push)) && Size(push)==6,"Push spare capacity identity");
        n=List(t,null,2);Throws<NullReferenceException>(()=>Invoke(n,0x060008E5,a),"Push null data");Need(Size(n)==2,"Push null before size mutation");
        bad=List(t,Values(valueType,a),3);Throws<IndexOutOfRangeException>(()=>Invoke(bad,0x060008E5,a),"Push corrupt size bounds");Need(Size(bad)==4,"Push size mutation before store failure");
        foreach(int token in new[]{0x060008E5,0x060008E6,0x060008E7,0x060008EA,0x060008ED})
        {var m=Method(t,token);Observations.Add(new{token=$"0x{token:X8}",closed_type=t.ToString(),actual_clr_cil_sha256=Convert.ToHexString(SHA256.HashData(m.GetMethodBody()!.GetILAsByteArray()!)).ToLowerInvariant()});}
    }
    private static void RunAssoc<T>(Assembly asm,T a,T b,T missing) where T:notnull
    {
        var lt=asm.GetType("FTRuntime.Internal.SwfList`1",true)!.MakeGenericType(typeof(T));
        var at=asm.GetType("FTRuntime.Internal.SwfAssocList`1",true)!.MakeGenericType(typeof(T));
        var list=List(lt,Values(typeof(T),a,b),2);var dict=new Dictionary<T,int>{{a,0},{b,1}};
        object assoc=RuntimeHelpers.GetUninitializedObject(at);Field(at,"_list").SetValue(assoc,list);Field(at,"_dict").SetValue(assoc,dict);
        Need(Equals(Invoke(assoc,0x060008D4,1),b),"Assoc index query delegates to list");
        Need((int)Invoke(assoc,0x060008D5,b)! ==1,"Assoc key query delegates to dictionary");
        Need((int)Invoke(assoc,0x060008D6)! ==2,"Assoc Count");
        Need((bool)Invoke(assoc,0x060008D7,a)! && !(bool)Invoke(assoc,0x060008D7,missing)!,"Assoc Contains both branches");
        Invoke(assoc,0x060008D8,a);Need(Size(list)==2 && dict.Count==2,"Assoc duplicate is no-op");
        Invoke(assoc,0x060008D8,missing);Need(Size(list)==3 && dict[missing]==2 && Equals(Data(list)!.GetValue(2),missing),"Assoc Add dictionary index then repaired Push");
        if(default(T) is null)Throws<ArgumentNullException>(()=>Invoke(assoc,0x060008D5,default(T)),"Assoc null key");
        else Throws<KeyNotFoundException>(()=>Invoke(assoc,0x060008D5,default(T)),"Assoc missing key");
        Field(at,"_dict").SetValue(assoc,null);Throws<NullReferenceException>(()=>Invoke(assoc,0x060008D7,a),"Assoc null dictionary");
        Field(at,"_list").SetValue(assoc,null);Throws<NullReferenceException>(()=>Invoke(assoc,0x060008D6),"Assoc Count null list");
        // Dictionary comparer callbacks can replace the owner's fields. These
        // controls distinguish correct reload order from a cached receiver.
        var comparer=new CallbackComparer<T>();
        dict=new Dictionary<T,int>(comparer){{a,0},{b,1}};comparer.Calls=0;
        list=List(lt,Values(typeof(T),a,b),2);var replacement=List(lt,Values(typeof(T),a,default(T),default(T),default(T)),1);
        Field(at,"_list").SetValue(assoc,list);Field(at,"_dict").SetValue(assoc,dict);
        comparer.OnHash=n=>{if(n==2)Field(at,"_list").SetValue(assoc,replacement);};
        Invoke(assoc,0x060008D8,missing);
        Need(dict[missing]==2 && Size(replacement)==2 && Equals(Data(replacement)!.GetValue(1),missing) && Size(list)==2,"Assoc reload list after Add callback");
        comparer=new CallbackComparer<T>();dict=new Dictionary<T,int>(comparer){{a,0},{b,1}};comparer.Calls=0;
        var replacementDict=new Dictionary<T,int>{{a,0}};
        list=List(lt,Values(typeof(T),a,b,default(T),default(T)),2);
        Field(at,"_list").SetValue(assoc,list);Field(at,"_dict").SetValue(assoc,dict);
        comparer.OnHash=n=>{if(n==1)Field(at,"_dict").SetValue(assoc,replacementDict);};
        Invoke(assoc,0x060008D8,missing);
        Need(replacementDict[missing]==2 && !dict.ContainsKey(missing) && Size(list)==3,"Assoc reload dictionary after Contains callback");
        foreach(int token in new[]{0x060008D4,0x060008D5,0x060008D6,0x060008D7,0x060008D8})
        {var m=Method(at,token);Observations.Add(new{token=$"0x{token:X8}",closed_type=at.ToString(),actual_clr_cil_sha256=Convert.ToHexString(SHA256.HashData(m.GetMethodBody()!.GetILAsByteArray()!)).ToLowerInvariant()});}
    }
    private sealed class CallbackComparer<T>:IEqualityComparer<T> where T:notnull
    {
        public int Calls;public Action<int>? OnHash;
        public bool Equals(T? x,T? y)=>EqualityComparer<T>.Default.Equals(x!,y!);
        public int GetHashCode(T obj){OnHash?.Invoke(++Calls);return EqualityComparer<T>.Default.GetHashCode(obj);}
    }
    public record struct BigKey(long A,long B,long C);
    private static int Main(string[] args)
    {
        string dll=Path.GetFullPath(args[0]);var alc=new AssemblyLoadContext("candidate-"+Guid.NewGuid(),true);
        var report=new Dictionary<string,object?>{["candidate_sha256"]=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(dll))).ToLowerInvariant(),["scope"]="ACTUAL_CANDIDATE_CLR_METHOD_EXECUTION_WITH_CONTROLLED_OBJECT_GRAPHS",
            ["fixture_sha256"]=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(Program).Assembly.Location))).ToLowerInvariant(),
            ["cecil_sha256"]=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(Mono.Cecil.ModuleDefinition).Assembly.Location))).ToLowerInvariant()};
        try
        {
            Assembly asm=alc.LoadFromAssemblyPath(dll);
            RunList(asm,typeof(string),"a","b","c");RunList(asm,typeof(int),10,20,30);
            RunList(asm,typeof(BigKey),new BigKey(1,2,3),new BigKey(4,5,6),new BigKey(7,8,9));
            RunAssoc(asm,"a","b","missing");RunAssoc(asm,10,20,30);RunAssoc(asm,new BigKey(1,2,3),new BigKey(4,5,6),new BigKey(7,8,9));
            RunControlledWrappers(dll);
            RunNativeRows(asm);
            report["pass"]=true;return 0;
        }
        catch(Exception e){report["pass"]=false;report["error"]=e.ToString();return 1;}
        finally
        {
            report["assertions_executed"]=Checks;report["observations"]=Observations;
            report["native_comparison_rows"]=NativeRows;
            File.WriteAllText(args[1],JsonSerializer.Serialize(report,new JsonSerializerOptions{WriteIndented=true}));
            Console.WriteLine(JsonSerializer.Serialize(new{checks=Checks,pass=report["pass"],error=report.GetValueOrDefault("error")}));alc.Unload();
        }
    }
}
