from pathlib import Path
import sys,json,hashlib,shutil
R=Path(__file__).resolve().parents[2];Q=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(R/'audit/stage9-native3/python-deps'))
import dnfile
from dncil.cil.body import CilMethodBody
from dncil.cil.body.reader import CilMethodBodyReaderBytes
sha=lambda b:hashlib.sha256(b).hexdigest()
old=R/'audit/bulk388-qualification-2026-10-23/revision-r4/source'
out=Q/'source';out.mkdir(exist_ok=False)
for p in old.iterdir():
    if p.suffix in ('.cs','.csproj','.json'):shutil.copyfile(p,out/p.name)
for name in ['GenericBodies.cs','GenericMetadata.cs']:shutil.copyfile(Q/name,out/name)
p=dnfile.dnPE(str(R/'audit/native93-codex-2026-10-17/verification-2026-10-17/candidates/candidate1.dll'))
r4=dnfile.dnPE(str(R/'audit/bulk388-qualification-2026-10-23/revision-r4/candidates/candidate1.dll'))
entries=[(0x28f,'GMapWrapperBody()',6,0x830),(0x8d4,'GAssocItemBody(true)',2,0x830),
 (0x8d5,'GAssocItemBody(false)',2,0x830),(0x8d6,'GAssocCountBody()',1,0x830),
 (0x8d7,'GAssocContainsBody()',2,0x830),(0x8d8,'GAssocAddBody()',3,0x834),
 (0x8e5,'GPushBody()',3,0x832),(0x8e6,'GPopBody()',3,0x831),
 (0x8e7,'GPeekBody()',3,0x830),(0x8ea,'GItemBody()',2,0x830),
 (0x8ed,'GCapacityBody()',1,0x830),(0x8f8,'GComponentBody()',2,0x833)]
owners={}
for t in p.net.mdtables.TypeDef.rows:
 for m in t.MethodList:owners[m.row_index]=str(t.TypeName)
plan=json.loads((old/'IMPLEMENTATION-PLAN.json').read_text())
pins=[];plans=[];new=[]
bindings=json.loads((Q/'evidence/original-generic-bindings.json').read_text())['methods']
for rid,fn,maxstack,localrid in entries:
    tk=0x06000000|rid;r=p.net.mdtables.MethodDef.rows[rid-1]
    b=CilMethodBody(CilMethodBodyReaderBytes(p.get_data(r.Rva,32768)))
    rb=r4.net.mdtables.MethodDef.rows[rid-1]
    bb=CilMethodBody(CilMethodBodyReaderBytes(r4.get_data(rb.Rva,32768)))
    assert b.raw_bytes==bb.raw_bytes,'new target differs from Native93'
    assert len(b.exception_handlers)==0
    lt=b.local_var_sig_tok.value
    local=p.net.mdtables.StandAloneSig.rows[(lt&0xffffff)-1].Signature.value.hex()
    pin=f'        new(0x{tk:08X},{json.dumps(owners[rid])},{json.dumps(str(r.Name))},"{r.Signature.value.hex()}",{b.code_size},{b.max_stack},0x{lt:08X},"{local}","{sha(b.raw_bytes[b.header_size:b.header_size+b.code_size])}"),'
    pins.append(pin)
    plans.append(f'            (Token:0x{tk:08X}, Code:{fn}, Max:{maxstack}, Locals:0x1100{localrid:04X}),')
    x=dict(token=f'0x{tk:08X}',name=owners[rid]+'::'+str(r.Name),signature=r.Signature.value.hex(),
        old_code_size=b.code_size,old_code_sha256=sha(b.raw_bytes[b.header_size:b.header_size+b.code_size]),
        old_max_stack=b.max_stack,new_declared_max_stack=maxstack,local_sig_token=f'0x{lt:08X}',local_sig_blob=local,
        new_local_sig_token=f'0x{0x11000000|localrid:08X}',emission_method=fn,
        source_batch='generic-apple-errors-2026-10-24',role='DAMAGED_REQUIRED_DEPENDENCY' if rid==0x8e5 else 'DIRECT_COMPILER_ERROR',
        original_native=[x for x in bindings if int(x['token'],16)==tk])
    new.append(x)
plan['targets'].extend(new)
plan.update(schema='bulk401-generic-reconstruction-v1',date='2026-10-24',state='CONSTRUCTION_PENDING_INDEPENDENT_VALIDATION',
    memberref_count_after=1324,standalone_count_after=2100,methodspec_count_after=194)
plan['generic_new_targets']=new
(out/'IMPLEMENTATION-PLAN.json').write_text(json.dumps(plan,indent=2)+'\n')
(Q/'GENERIC-TARGETS.json').write_text(json.dumps(new,indent=2)+'\n')
s=(out/'Program.cs').read_text()
a=s.index('    ];',s.index('private static readonly Pin[] Pins'))
s=s[:a]+'\n'.join(pins)+'\n'+s[a:]
s=s.replace('after = AppendNative119WidthAware(after, out var widthMetadataEvidence);',
    'after = AppendNative119WidthAware(after, out var widthMetadataEvidence);\n        after = AppendGenericMetadata(after, out var genericMetadataEvidence);')
oldlast='(Token:0x060003E9, Code:N121_CollisionWallBody(), Max:3, Locals:0)'
assert s.count(oldlast)==1
s=s.replace(oldlast,oldlast+',\n'+'\n'.join(plans))
s=s.replace('==389','==401').replace('389-method','401-method')
s=s.replace('appended_memberref_count = 218','appended_memberref_count = 224').replace('appended_local_signature_count = 330','appended_local_signature_count = 335').replace('appended_methodspec_count = 8','appended_methodspec_count = 9')
s=s.replace('width_metadata = widthMetadataEvidence,','width_metadata = widthMetadataEvidence, generic_metadata = genericMetadataEvidence,')
s=s.replace('// Source only: the author has not built, run, or tested this patcher.','// Bulk401 construction; qualification is recorded separately from construction.')
(out/'Program.cs').write_text(s)
proj=(out/'Bulk388.csproj').read_text().replace('<Compile Include="Program.cs"/>','<Compile Include="Program.cs"/><Compile Include="GenericBodies.cs"/><Compile Include="GenericMetadata.cs"/>')
(out/'Bulk388.csproj').write_text(proj)
manifest=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(out.iterdir()) if p.is_file()]
(Q/'SOURCE-MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('SOURCE_PREPARED total_targets=401 direct_generic_targets=11 dependency=1')
