"""Read-only generic definition -> original PC instantiation binding.

The IL2CPP v31 registration layouts are checked against the original bytes.
Reference: Perfare/Il2CppDumper Il2CppClass.cs, retrieved 2026-10-24.
"""
from pathlib import Path
import sys, struct, json, re, hashlib
R = Path(__file__).resolve().parents[2]
Q = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(R/'audit/stage9-native3/python-deps'))
import pefile
from capstone import Cs, CS_ARCH_X86, CS_MODE_64
I = R/'audit/offline-test-handoff-2026-10-14/payload/inputs'
raw = (I/'original-pc/GameAssembly.dll').read_bytes()
meta = (I/'original-pc/global-metadata.dat').read_bytes()
sha = lambda b: hashlib.sha256(b).hexdigest()
assert sha(raw) == '9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d'
assert sha(meta) == 'ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9'
p = pefile.PE(data=raw)
base = p.OPTIONAL_HEADER.ImageBase
u = lambda b,o=0: struct.unpack_from('<I',b,o)[0]
q = lambda b,o=0: struct.unpack_from('<Q',b,o)[0]
def read(va,n):
    assert base <= va < base + p.OPTIONAL_HEADER.SizeOfImage
    b = p.get_data(va-base,n)
    assert len(b) == n
    return b
def nq(va): return q(read(va,8))
so,to,ts,mo,io,isz = [u(meta,x) for x in [24,160,164,48,168,172]]
def string(i): return meta[so+i:meta.index(0,so+i)].decode()
types = json.loads((I/'maps/native-types.json').read_text('utf-8-sig'))
assert len(types) == ts//88
selected = {'Map','SwfList`1','SwfAssocList`1','SwfUtils'}
methods = {}
for t in types:
    for j in range(t['methods']):
        ix = t['methodStart']+j
        at = mo+36*ix
        if t['name'] in selected:
            tok = u(meta,at+24)
            methods[ix] = dict(token=f'0x{tok:08X}',owner=t['name'],namespace=t['namespace'],name=string(u(meta,at)),definition_index=ix)
# Locate metadata registration through its repeated type-definition count.
found=[]
pat=struct.pack('<Q',len(types))
for m in re.finditer(re.escape(pat),raw):
    a=m.start()
    if raw[a+16:a+24] != pat: continue
    vals=struct.unpack_from('<16Q',raw,a-80)
    if vals[10] != len(types) or vals[12] != len(types): continue
    if not (0<vals[4]<200000 and 0<vals[8]<200000): continue
    try:
        specs=[struct.unpack('<iii',read(vals[9]+12*i,12)) for i in range(vals[8])]
        funcs=[struct.unpack('<iiii',read(vals[5]+16*i,16)) for i in range(vals[4])]
        assert all(0<=x[0]<len(specs) and x[1]>=0 for x in funcs)
        found.append((p.get_rva_from_offset(a-80)+base,vals,specs,funcs))
    except (AssertionError,ValueError,struct.error): pass
assert len(found)==1,[(hex(x[0]),x[1]) for x in found]
mr,mv,specs,funcs=found[0]
print('MetadataRegistration',hex(mr),mv)
# Locate code registration by its exact image count and module array.
images=isz//40
found=[]
for m in re.finditer(re.escape(struct.pack('<Q',images)),raw):
    a=m.start()
    try:
        ptr=q(raw,a+8)
        modules=[nq(ptr+8*i) for i in range(images)]
        names=[]
        for mod in modules:
            at=nq(mod)
            data=read(at,200)
            names.append(data[:data.index(0)].decode())
        assert set(names)=={string(u(meta,io+40*i)) for i in range(images)}
        for back in [120,104]:
            cv=struct.unpack_from('<17Q',raw,a-back)
            if not (max(x[1] for x in funcs)<cv[2]<200000):continue
            gp=[nq(cv[3]+8*i) for i in range(cv[2])]
            assert all(v==0 or base<=v<base+p.OPTIONAL_HEADER.SizeOfImage for v in gp)
            found.append((p.get_rva_from_offset(a-back)+base,cv,gp,names))
    except (AssertionError,ValueError,struct.error,UnicodeDecodeError):pass
assert len(found)==1,[(hex(x[0]),x[1]) for x in found]
cr,cv,pointers,names=found[0]
modules=[nq(cv[16]+8*i) for i in range(images)]
print('CodeRegistration',hex(cr),cv)
def type_name(ptr,depth=0):
    assert depth<12
    data,bits=struct.unpack('<QI',read(ptr,12));kind=(bits>>16)&255
    if kind in (0x11,0x12):
        t=types[data];return (t['namespace']+'.' if t['namespace'] else '')+t['name']
    if kind==0x15:
        tp,ci,mi,cached=struct.unpack('<4Q',read(data,32))
        return type_name(tp,depth+1)+'<'+','.join(inst(ci,depth+1))+'>'
    if kind==0x1d:return type_name(data,depth+1)+'[]'
    return {1:'void',2:'bool',8:'int32',0xe:'string',0x1c:'object',0x13:'!'+str(data),0x1e:'!!'+str(data)}.get(kind,f'kind{kind:x}:{data:x}')
def inst(ptr,depth=0):
    if not ptr:return []
    n,ptr=struct.unpack('<QQ',read(ptr,16));assert n<64
    return [type_name(nq(ptr+8*i),depth+1) for i in range(n)]
gi=[nq(mv[3]+8*i) for i in range(mv[2])]
rows=[]
for si,mi,inv,adj in funcs:
    definition,ci,ii=specs[si]
    if definition not in methods:continue
    va=pointers[mi]
    row=dict(methods[definition],method_spec_index=si,class_inst_index=ci,method_inst_index=ii,
             class_args=inst(gi[ci]) if ci>=0 else [],method_args=inst(gi[ii]) if ii>=0 else [],
             generic_pointer_index=mi,va=f'0x{va:X}',invoker_index=inv,adjustor_index=adj)
    rows.append(row)
allmap=json.loads((I/'maps/native-method-map.json').read_text('utf-8-sig'))
byva={int(x['va'],16):x['type']+'::'+x['name'] for x in allmap if x['va']!='0x0'}
for row in rows:byva.setdefault(int(row['va'],16),row['owner']+'::'+row['name'])
pdata={base+x.struct.BeginAddress:base+x.struct.EndAddress for x in p.DIRECTORY_ENTRY_EXCEPTION}
out=Q/'evidence'
starts=sorted(set(byva)|set(pointers)-{0})
for va in sorted(set(int(r['va'],16) for r in rows)):
    if not va:continue
    # A single function can have several .pdata entries (hot/cold regions).
    # Preserve the first unwind extent but also inspect through the next known
    # method pointer, so split continuations are not silently omitted.
    end=min(v for v in starts if v>va)
    assert end-va<65536
    code=read(va,end-va)
    lines=[f'# VA {va:X} END {end:X} bound=next-method-pointer first-pdata-end={pdata.get(va,0):X} SHA256 {sha(code)}']
    for ins in Cs(CS_ARCH_X86,CS_MODE_64).disasm(code,va):
        label=byva.get(int(ins.op_str,16),'') if ins.mnemonic in ('call','jmp') and ins.op_str.startswith('0x') else ''
        lines.append(f'{ins.address:X} {ins.bytes.hex():24} {ins.mnemonic:8} {ins.op_str} {label}')
    (out/f'native-{va:X}.asm').write_text('\n'.join(lines)+'\n')
result=dict(input_sha256=sha(raw),metadata_sha256=sha(meta),metadata_registration=hex(mr),code_registration=hex(cr),
            generic_method_table_count=len(funcs),method_specs_count=len(specs),generic_pointers_count=len(pointers),methods=rows,
            layout_reference='https://github.com/Perfare/Il2CppDumper/blob/master/Il2CppDumper/Il2Cpp/Il2CppClass.cs')
(out/'original-generic-bindings.json').write_text(json.dumps(result,indent=2)+'\n')
for row in rows:print(row['token'],row['owner'],row['name'],row['class_args'],row['method_args'],row['va'])
selected_calls={0x1800B4980,0x1805EA6B0,0x1805D8190,0x1805D80B0,0x18046DC80,0x18046D280}
aliases=[]
for si,mi,inv,adj in funcs:
    if pointers[mi] not in selected_calls:continue
    definition,ci,ii=specs[si];at=mo+36*definition
    owner=types[u(meta,at+4)]
    aliases.append(dict(va=hex(pointers[mi]),owner=owner['namespace']+'.'+owner['name'],name=string(u(meta,at)),
                        token=hex(u(meta,at+24)),definition_index=definition,method_spec_index=si,
                        class_args=inst(gi[ci]) if ci>=0 else [],method_args=inst(gi[ii]) if ii>=0 else []))
(out/'native-call-aliases.json').write_text(json.dumps(aliases,indent=2)+'\n')
fields=json.loads((I/'maps/native-fields.json').read_text('utf-8-sig'))
fieldrows=[]
for f in fields:
    if f['type'] not in selected:continue
    fieldrows.append(dict(f,native_type=type_name(nq(mv[7]+8*f['type_index']))))
(out/'native-field-types.json').write_text(json.dumps(fieldrows,indent=2)+'\n')
# Original Assembly-CSharp RGCTX records bind the wrapper's indirect call.
module=modules[names.index('Assembly-CSharp.dll')]
rv=struct.unpack('<18Q',read(module,144)); nr,rp,nd,dp=rv[8:12]
rg=[]
selected_rgctx={0x0600028f,0x060008f8}|{int(t['token'],16) for t in types if t['name'] in selected}
for i in range(nr):
    tok,start,length=struct.unpack('<Iii',read(rp+12*i,12))
    if tok not in selected_rgctx:continue
    for j in range(start,start+length):
        kind,data=struct.unpack('<QQ',read(dp+j*16,16))
        entry=dict(token=hex(tok),index=j-start,kind=kind,data=hex(data))
        if kind==3:
            si=u(read(data,4));definition,ci,ii=specs[si]
            at=mo+36*definition;t=types[u(meta,at+4)]
            entry.update(method_spec_index=si,definition_token=hex(u(meta,at+24)),owner=t['name'],name=string(u(meta,at)),
                         class_args=inst(gi[ci]) if ci>=0 else [],method_args=inst(gi[ii]) if ii>=0 else [])
        rg.append(entry)
(out/'wrapper-rgctx.json').write_text(json.dumps(rg,indent=2)+'\n')
# A readable export is evidence only, never rewritten input.
cil=json.loads((out/'parent-targets.json').read_text('utf-8-sig'))
for m in cil['methods']:
    text=[m['name'],'locals '+json.dumps(m['locals']), 'handlers '+json.dumps(m['handlers'])]
    text += [f"{i['offset']:04X} {i['opcode']:12} {json.dumps(i['operand'],ensure_ascii=False)}" for i in m['instructions']]
    (out/(m['token']+'-parent.il')).write_text('\n'.join(text)+'\n')
