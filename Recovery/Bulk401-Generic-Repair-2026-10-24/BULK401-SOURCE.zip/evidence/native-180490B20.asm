# VA 180490B20 END 1804910B0 bound=next-method-pointer first-pdata-end=1804910B0 SHA256 521705583dee7d27a0cb5838e0bca5bd4f8558fff3bab157a5f4983408461f46
180490B20 44894c2420               mov      dword ptr [rsp + 0x20], r9d 
180490B25 4c89442418               mov      qword ptr [rsp + 0x18], r8 
180490B2A 89542410                 mov      dword ptr [rsp + 0x10], edx 
180490B2E 48894c2408               mov      qword ptr [rsp + 8], rcx 
180490B33 55                       push     rbp 
180490B34 53                       push     rbx 
180490B35 56                       push     rsi 
180490B36 57                       push     rdi 
180490B37 4154                     push     r12 
180490B39 4155                     push     r13 
180490B3B 4156                     push     r14 
180490B3D 4157                     push     r15 
180490B3F 4881eca8000000           sub      rsp, 0xa8 
180490B46 488d6c2420               lea      rbp, [rsp + 0x20] 
180490B4B 488bf9                   mov      rdi, rcx 
180490B4E 488bb5f8000000           mov      rsi, qword ptr [rbp + 0xf8] 
180490B55 48837e3800               cmp      qword ptr [rsi + 0x38], 0 
180490B5A 0f85ff000000             jne      0x180490c5f 
180490B60 488d0de1a17001           lea      rcx, [rip + 0x170a1e1] 
180490B67 e884f3dbff               call     0x18024fef0 
180490B6C 488d0d95c37001           lea      rcx, [rip + 0x170c395] 
180490B73 e878f3dbff               call     0x18024fef0 
180490B78 488d0df96d7301           lea      rcx, [rip + 0x1736df9] 
180490B7F e86cf3dbff               call     0x18024fef0 
180490B84 488d0d9d427301           lea      rcx, [rip + 0x173429d] 
180490B8B e860f3dbff               call     0x18024fef0 
180490B90 488d0de9427301           lea      rcx, [rip + 0x17342e9] 
180490B97 e854f3dbff               call     0x18024fef0 
180490B9C 488d0d2d6e7301           lea      rcx, [rip + 0x1736e2d] 
180490BA3 e848f3dbff               call     0x18024fef0 
180490BA8 488d0d29437301           lea      rcx, [rip + 0x1734329] 
180490BAF e83cf3dbff               call     0x18024fef0 
180490BB4 488d0d6d6e7301           lea      rcx, [rip + 0x1736e6d] 
180490BBB e830f3dbff               call     0x18024fef0 
180490BC0 488d0d21907001           lea      rcx, [rip + 0x1709021] 
180490BC7 e824f3dbff               call     0x18024fef0 
180490BCC 488d0d1d917001           lea      rcx, [rip + 0x170911d] 
180490BD3 e818f3dbff               call     0x18024fef0 
180490BD8 488d0d018f7001           lea      rcx, [rip + 0x1708f01] 
180490BDF e80cf3dbff               call     0x18024fef0 
180490BE4 488d0d0d927001           lea      rcx, [rip + 0x170920d] 
180490BEB e800f3dbff               call     0x18024fef0 
180490BF0 488d0d99757201           lea      rcx, [rip + 0x1727599] 
180490BF7 e8f4f2dbff               call     0x18024fef0 
180490BFC 488d0d35c07101           lea      rcx, [rip + 0x171c035] 
180490C03 e8e8f2dbff               call     0x18024fef0 
180490C08 488d0dd9747201           lea      rcx, [rip + 0x17274d9] 
180490C0F e8dcf2dbff               call     0x18024fef0 
180490C14 488d0dc5bf7101           lea      rcx, [rip + 0x171bfc5] 
180490C1B e8d0f2dbff               call     0x18024fef0 
180490C20 488d0d19c17101           lea      rcx, [rip + 0x171c119] 
180490C27 e8c4f2dbff               call     0x18024fef0 
180490C2C 488d0d65c17101           lea      rcx, [rip + 0x171c165] 
180490C33 e8b8f2dbff               call     0x18024fef0 
180490C38 488d0dc1d17201           lea      rcx, [rip + 0x172d1c1] 
180490C3F e8acf2dbff               call     0x18024fef0 
180490C44 488d0dcddf7001           lea      rcx, [rip + 0x170dfcd] 
180490C4B e8a0f2dbff               call     0x18024fef0 
180490C50 48837e3800               cmp      qword ptr [rsi + 0x38], 0 
180490C55 7508                     jne      0x180490c5f 
180490C57 488bce                   mov      rcx, rsi 
180490C5A e8a17edcff               call     0x180258b00 
180490C5F 488b4638                 mov      rax, qword ptr [rsi + 0x38] 
180490C63 488b08                   mov      rcx, qword ptr [rax] 
180490C66 8b81fc000000             mov      eax, dword ptr [rcx + 0xfc] 
180490C6C 894518                   mov      dword ptr [rbp + 0x18], eax 
180490C6F 488d480f                 lea      rcx, [rax + 0xf] 
180490C73 483bc8                   cmp      rcx, rax 
180490C76 770a                     ja       0x180490c82 
180490C78 48b9f0ffffffffffff0f     movabs   rcx, 0xffffffffffffff0 
180490C82 4883e1f0                 and      rcx, 0xfffffffffffffff0 
180490C86 488bc1                   mov      rax, rcx 
180490C89 e8f246e3ff               call     0x1802c5380 
180490C8E 482be1                   sub      rsp, rcx 
180490C91 488d442420               lea      rax, [rsp + 0x20] 
180490C96 48894520                 mov      qword ptr [rbp + 0x20], rax 
180490C9A 0f57c0                   xorps    xmm0, xmm0 
180490C9D 33c0                     xor      eax, eax 
180490C9F 0f114530                 movups   xmmword ptr [rbp + 0x30], xmm0 
180490CA3 48894540                 mov      qword ptr [rbp + 0x40], rax 
180490CA7 488b0d52d17201           mov      rcx, qword ptr [rip + 0x172d152] 
180490CAE e84df4dbff               call     0x180250100 
180490CB3 4c8be0                   mov      r12, rax 
180490CB6 488b1523bf7101           mov      rdx, qword ptr [rip + 0x171bf23] 
180490CBD 488bc8                   mov      rcx, rax 
180490CC0 e80b473700               call     0x1808053d0 
180490CC5 4c896528                 mov      qword ptr [rbp + 0x28], r12 
180490CC9 488b0d30d17201           mov      rcx, qword ptr [rip + 0x172d130] 
180490CD0 e82bf4dbff               call     0x180250100 
180490CD5 4c8bf8                   mov      r15, rax 
180490CD8 488b1501bf7101           mov      rdx, qword ptr [rip + 0x171bf01] 
180490CDF 488bc8                   mov      rcx, rax 
180490CE2 e8e9463700               call     0x1808053d0 
180490CE7 4c897d48                 mov      qword ptr [rbp + 0x48], r15 
180490CEB 488b5710                 mov      rdx, qword ptr [rdi + 0x10] 
180490CEF 4885d2                   test     rdx, rdx 
180490CF2 0f8480030000             je       0x180491078 
180490CF8 4c8b05e9737201           mov      r8, qword ptr [rip + 0x17273e9] 
180490CFF 488d4d00                 lea      rcx, [rbp] 
180490D03 e8e88a3800               call     0x1808197f0 
180490D08 0f104500                 movups   xmm0, xmmword ptr [rbp] 
180490D0C 0f114550                 movups   xmmword ptr [rbp + 0x50], xmm0 
180490D10 f20f104d10               movsd    xmm1, qword ptr [rbp + 0x10] 
180490D15 f20f114d60               movsd    qword ptr [rbp + 0x60], xmm1 
180490D1A 48c7450000000000         mov      qword ptr [rbp], 0 
180490D22 488d5d50                 lea      rbx, [rbp + 0x50] 
180490D26 48895d08                 mov      qword ptr [rbp + 8], rbx 
180490D2A 660f1f440000             nop      word ptr [rax + rax] 
180490D30 488b15996c7301           mov      rdx, qword ptr [rip + 0x1736c99] 
180490D37 488d4d50                 lea      rcx, [rbp + 0x50] 
180490D3B e840851d00               call     0x180669280 
180490D40 84c0                     test     al, al 
180490D42 0f846a010000             je       0x180490eb2 
180490D48 4c8b6d60                 mov      r13, qword ptr [rbp + 0x60] 
180490D4C 448bb5e8000000           mov      r14d, dword ptr [rbp + 0xe8] 
180490D53 33d2                     xor      edx, edx 
180490D55 488bcf                   mov      rcx, rdi 
180490D58 e853b6e9ff               call     0x18032c3b0 Map::GetMapX
180490D5D 8b8df0000000             mov      ecx, dword ptr [rbp + 0xf0] 
180490D63 ffc1                     inc      ecx 
180490D65 3bc8                     cmp      ecx, eax 
180490D67 0f4cc1                   cmovl    eax, ecx 
180490D6A 443bf0                   cmp      r14d, eax 
180490D6D 7dc1                     jge      0x180490d30 
180490D6F 4d85ed                   test     r13, r13 
180490D72 0f8416030000             je       0x18049108e 
180490D78 498b4d18                 mov      rcx, qword ptr [r13 + 0x18] 
180490D7C 4885c9                   test     rcx, rcx 
180490D7F 0f8404030000             je       0x180491089 
180490D85 4c8b050cc07101           mov      r8, qword ptr [rip + 0x171c00c] 
180490D8C 418bd6                   mov      edx, r14d 
180490D8F e87c493900               call     0x180825710 
180490D94 488bf8                   mov      rdi, rax 
180490D97 4885c0                   test     rax, rax 
180490D9A 0f84e4020000             je       0x180491084 
180490DA0 488d481c                 lea      rcx, [rax + 0x1c] 
180490DA4 33d2                     xor      edx, edx 
180490DA6 e8752a8100               call     0x180ca3820 
180490DAB 488bf0                   mov      rsi, rax 
180490DAE 488d4f20                 lea      rcx, [rdi + 0x20] 
180490DB2 33d2                     xor      edx, edx 
180490DB4 e8672a8100               call     0x180ca3820 
180490DB9 4533c9                   xor      r9d, r9d 
180490DBC 4c8bc0                   mov      r8, rax 
180490DBF 488b1552de7001           mov      rdx, qword ptr [rip + 0x170de52] 
180490DC6 488bce                   mov      rcx, rsi 
180490DC9 e882316e00               call     0x180b73f50 
180490DCE 488bf0                   mov      rsi, rax 
180490DD1 488b0d709f7001           mov      rcx, qword ptr [rip + 0x1709f70] 
180490DD8 83b9e000000000           cmp      dword ptr [rcx + 0xe0], 0 
180490DDF 7505                     jne      0x180490de6 
180490DE1 e8faf3dbff               call     0x1802501e0 
180490DE6 33d2                     xor      edx, edx 
180490DE8 488bce                   mov      rcx, rsi 
180490DEB e8005be500               call     0x1812e68f0 Debug::Log
180490DF0 488bb5f8000000           mov      rsi, qword ptr [rbp + 0xf8] 
180490DF7 488b4638                 mov      rax, qword ptr [rsi + 0x38] 
180490DFB 488b08                   mov      rcx, qword ptr [rax] 
180490DFE 8b4128                   mov      eax, dword ptr [rcx + 0x28] 
180490E01 c1e81f                   shr      eax, 0x1f 
180490E04 488d95e0000000           lea      rdx, [rbp + 0xe0] 
180490E0B 84c0                     test     al, al 
180490E0D 480f4595e0000000         cmovne   rdx, qword ptr [rbp + 0xe0] 
180490E15 448b4518                 mov      r8d, dword ptr [rbp + 0x18] 
180490E19 488b4d20                 mov      rcx, qword ptr [rbp + 0x20] 
180490E1D e8ce56e6ff               call     0x1802f64f0 
180490E22 488b4638                 mov      rax, qword ptr [rsi + 0x38] 
180490E26 488b5520                 mov      rdx, qword ptr [rbp + 0x20] 
180490E2A 488b08                   mov      rcx, qword ptr [rax] 
180490E2D e80ee5dbff               call     0x18024f340 
180490E32 4c8bd0                   mov      r10, rax 
180490E35 4885c0                   test     rax, rax 
180490E38 7469                     je       0x180490ea3 
180490E3A 4c8b08                   mov      r9, qword ptr [rax] 
180490E3D 4c8b05c4c07001           mov      r8, qword ptr [rip + 0x170c0c4] 
180490E44 410fb68830010000         movzx    ecx, byte ptr [r8 + 0x130] 
180490E4C 41388930010000           cmp      byte ptr [r9 + 0x130], cl 
180490E53 7215                     jb       0x180490e6a 
180490E55 0fb6d1                   movzx    edx, cl 
180490E58 498b89c8000000           mov      rcx, qword ptr [r9 + 0xc8] 
180490E5F 4c3944d1f8               cmp      qword ptr [rcx + rdx*8 - 8], r8 
180490E64 7504                     jne      0x180490e6a 
180490E66 b001                     mov      al, 1 
180490E68 eb02                     jmp      0x180490e6c 
180490E6A 32c0                     xor      al, al 
180490E6C 33d2                     xor      edx, edx 
180490E6E 84c0                     test     al, al 
180490E70 490f45d2                 cmovne   rdx, r10 
180490E74 4885d2                   test     rdx, rdx 
180490E77 742a                     je       0x180490ea3 
180490E79 4533c0                   xor      r8d, r8d 
180490E7C 488bcf                   mov      rcx, rdi 
180490E7F e81c8ce9ff               call     0x180329aa0 Grid::CanPlacing
180490E84 84c0                     test     al, al 
180490E86 741b                     je       0x180490ea3 
180490E88 4d85ff                   test     r15, r15 
180490E8B 0f84ed010000             je       0x18049107e 
180490E91 4c8b05a0bd7101           mov      r8, qword ptr [rip + 0x171bda0] 
180490E98 488bd7                   mov      rdx, rdi 
180490E9B 498bcf                   mov      rcx, r15 
180490E9E e8cd1fb7ff               call     0x180002e70 
180490EA3 41ffc6                   inc      r14d 
180490EA6 488bbdd0000000           mov      rdi, qword ptr [rbp + 0xd0] 
180490EAD e9a1feffff               jmp      0x180490d53 
180490EB2 488b15bf6a7301           mov      rdx, qword ptr [rip + 0x1736abf] 
180490EB9 488bcb                   mov      rcx, rbx 
180490EBC e8af12e7ff               call     0x180302170 <StartCoro>d__4::System.IDisposable.Dispose
180490EC1 eb25                     jmp      0x180490ee8 
180490EC3 488b15ae6a7301           mov      rdx, qword ptr [rip + 0x1736aae] 
180490ECA 488b4d08                 mov      rcx, qword ptr [rbp + 8] 
180490ECE e89d12e7ff               call     0x180302170 <StartCoro>d__4::System.IDisposable.Dispose
180490ED3 488b4d00                 mov      rcx, qword ptr [rbp] 
180490ED7 4885c9                   test     rcx, rcx 
180490EDA 0f85b4010000             jne      0x180491094 
180490EE0 4c8b6528                 mov      r12, qword ptr [rbp + 0x28] 
180490EE4 4c8b7d48                 mov      r15, qword ptr [rbp + 0x48] 
180490EE8 4d85ff                   test     r15, r15 
180490EEB 0f8487010000             je       0x180491078 
180490EF1 418b7f18                 mov      edi, dword ptr [r15 + 0x18] 
180490EF5 448bb5d8000000           mov      r14d, dword ptr [rbp + 0xd8] 
180490EFC 443bf7                   cmp      r14d, edi 
180490EFF 0f8f6e010000             jg       0x180491073 
180490F05 488b0d84727201           mov      rcx, qword ptr [rip + 0x1727284] 
180490F0C e8eff1dbff               call     0x180250100 
180490F11 488bd8                   mov      rbx, rax 
180490F14 488b15c58b7001           mov      rdx, qword ptr [rip + 0x1708bc5] 
180490F1B 488bc8                   mov      rcx, rax 
180490F1E e87d423000               call     0x1807951a0 
180490F23 4885db                   test     rbx, rbx 
180490F26 0f844c010000             je       0x180491078 
180490F2C 0f1f4000                 nop      dword ptr [rax] 
180490F30 44397320                 cmp      dword ptr [rbx + 0x20], r14d 
180490F34 7d1f                     jge      0x180490f55 
180490F36 4533c0                   xor      r8d, r8d 
180490F39 8bd7                     mov      edx, edi 
180490F3B 33c9                     xor      ecx, ecx 
180490F3D e8cec3e700               call     0x18130d310 Random::RandomRangeInt
180490F42 4c8b059f8c7001           mov      r8, qword ptr [rip + 0x1708c9f] 
180490F49 8bd0                     mov      edx, eax 
180490F4B 488bcb                   mov      rcx, rbx 
180490F4E e8ad772f00               call     0x180788700 
180490F53 ebdb                     jmp      0x180490f30 
180490F55 4c8b05948d7001           mov      r8, qword ptr [rip + 0x1708d94] 
180490F5C 488bd3                   mov      rdx, rbx 
180490F5F 488d4d00                 lea      rcx, [rbp] 
180490F63 e8b8a02f00               call     0x18078b020 
180490F68 0f104500                 movups   xmm0, xmmword ptr [rbp] 
180490F6C 0f114530                 movups   xmmword ptr [rbp + 0x30], xmm0 
180490F70 f20f104d10               movsd    xmm1, qword ptr [rbp + 0x10] 
180490F75 f20f114d40               movsd    qword ptr [rbp + 0x40], xmm1 
180490F7A 48c7450000000000         mov      qword ptr [rbp], 0 
180490F82 488d5d30                 lea      rbx, [rbp + 0x30] 
180490F86 48895d08                 mov      qword ptr [rbp + 8], rbx 
180490F8A 660f1f440000             nop      word ptr [rax + rax] 
180490F90 488b15e93e7301           mov      rdx, qword ptr [rip + 0x1733ee9] 
180490F97 488d4d30                 lea      rcx, [rbp + 0x30] 
180490F9B e840671d00               call     0x1806676e0 
180490FA0 84c0                     test     al, al 
180490FA2 0f8486000000             je       0x18049102e 
180490FA8 4c8b05e9bd7101           mov      r8, qword ptr [rip + 0x171bde9] 
180490FAF 8b5540                   mov      edx, dword ptr [rbp + 0x40] 
180490FB2 498bcf                   mov      rcx, r15 
180490FB5 e856473900               call     0x180825710 
180490FBA 488bd0                   mov      rdx, rax 
180490FBD 4d85e4                   test     r12, r12 
180490FC0 0f84de000000             je       0x1804910a4 
180490FC6 4c8b0d6bbc7101           mov      r9, qword ptr [rip + 0x171bc6b] 
180490FCD 41ff44241c               inc      dword ptr [r12 + 0x1c] 
180490FD2 498b4c2410               mov      rcx, qword ptr [r12 + 0x10] 
180490FD7 4d63442418               movsxd   r8, dword ptr [r12 + 0x18] 
180490FDC 4885c9                   test     rcx, rcx 
180490FDF 0f84ba000000             je       0x18049109f 
180490FE5 443b4118                 cmp      r8d, dword ptr [rcx + 0x18] 
180490FE9 7219                     jb       0x180491004 
180490FEB 498b4120                 mov      rax, qword ptr [r9 + 0x20] 
180490FEF 4c8b80c0000000           mov      r8, qword ptr [rax + 0xc0] 
180490FF6 4d8b4070                 mov      r8, qword ptr [r8 + 0x70] 
180490FFA 498bcc                   mov      rcx, r12 
180490FFD e8de6c3b00               call     0x180847ce0 
180491002 eb8c                     jmp      0x180490f90 
180491004 418d4001                 lea      eax, [r8 + 1] 
180491008 4189442418               mov      dword ptr [r12 + 0x18], eax 
18049100D 443b4118                 cmp      r8d, dword ptr [rcx + 0x18] 
180491011 0f8383000000             jae      0x18049109a 
180491017 4a8954c120               mov      qword ptr [rcx + r8*8 + 0x20], rdx 
18049101C 4a8d0cc1                 lea      rcx, [rcx + r8*8] 
180491020 4883c120                 add      rcx, 0x20 
180491024 e837e3dbff               call     0x18024f360 
180491029 e962ffffff               jmp      0x180490f90 
18049102E 488b15f33d7301           mov      rdx, qword ptr [rip + 0x1733df3] 
180491035 488bcb                   mov      rcx, rbx 
180491038 e83311e7ff               call     0x180302170 <StartCoro>d__4::System.IDisposable.Dispose
18049103D eb1d                     jmp      0x18049105c 
18049103F 488b15e23d7301           mov      rdx, qword ptr [rip + 0x1733de2] 
180491046 488b4d08                 mov      rcx, qword ptr [rbp + 8] 
18049104A e82111e7ff               call     0x180302170 <StartCoro>d__4::System.IDisposable.Dispose
18049104F 488b4d00                 mov      rcx, qword ptr [rbp] 
180491053 4885c9                   test     rcx, rcx 
180491056 7552                     jne      0x1804910aa 
180491058 4c8b6528                 mov      r12, qword ptr [rbp + 0x28] 
18049105C 498bc4                   mov      rax, r12 
18049105F 488da588000000           lea      rsp, [rbp + 0x88] 
180491066 415f                     pop      r15 
180491068 415e                     pop      r14 
18049106A 415d                     pop      r13 
18049106C 415c                     pop      r12 
18049106E 5f                       pop      rdi 
18049106F 5e                       pop      rsi 
180491070 5b                       pop      rbx 
180491071 5d                       pop      rbp 
180491072 c3                       ret       
180491073 498bc7                   mov      rax, r15 
180491076 ebe7                     jmp      0x18049105f 
180491078 e8d3f0dbff               call     0x180250150 
18049107D 90                       nop       
18049107E e8cdf0dbff               call     0x180250150 
180491083 90                       nop       
180491084 e8c7f0dbff               call     0x180250150 
180491089 e8c2f0dbff               call     0x180250150 
18049108E e8bdf0dbff               call     0x180250150 
180491093 90                       nop       
180491094 e8c7fdd6ff               call     0x180200e60 
180491099 90                       nop       
18049109A e8a1f0dbff               call     0x180250140 
18049109F e8acf0dbff               call     0x180250150 
1804910A4 e8a7f0dbff               call     0x180250150 
1804910A9 90                       nop       
1804910AA e8b1fdd6ff               call     0x180200e60 
1804910AF cc                       int3      
