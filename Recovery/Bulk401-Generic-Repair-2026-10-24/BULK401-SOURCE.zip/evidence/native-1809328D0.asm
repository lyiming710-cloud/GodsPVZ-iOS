# VA 1809328D0 END 180932910 bound=next-method-pointer first-pdata-end=18093290B SHA256 045de26925adda5382a40bc5ee2968cf6595c304ec4b9dbc795abd6fe6427dc8
1809328D0 4883ec28                 sub      rsp, 0x28 
1809328D4 488b4910                 mov      rcx, qword ptr [rcx + 0x10] 
1809328D8 4885c9                   test     rcx, rcx 
1809328DB 7428                     je       0x180932905 
1809328DD 488b4220                 mov      rax, qword ptr [rdx + 0x20] 
1809328E1 4c8b80c0000000           mov      r8, qword ptr [rax + 0xc0] 
1809328E8 498b4070                 mov      rax, qword ptr [r8 + 0x70] 
1809328EC 4c8b00                   mov      r8, qword ptr [rax] 
1809328EF 488b4220                 mov      rax, qword ptr [rdx + 0x20] 
1809328F3 488b90c0000000           mov      rdx, qword ptr [rax + 0xc0] 
1809328FA 488b5270                 mov      rdx, qword ptr [rdx + 0x70] 
1809328FE 4883c428                 add      rsp, 0x28 
180932902 49ffe0                   jmp      r8 
180932905 e846d891ff               call     0x180250150 
18093290A cc                       int3      
18093290B cc                       int3      
18093290C cc                       int3      
18093290D cc                       int3      
18093290E cc                       int3      
18093290F cc                       int3      
