# VA 1809D3A90 END 1809D3F50 bound=next-method-pointer first-pdata-end=1809D3F4A SHA256 a11387914bf3cba7a75503f92e881115079b0b90b50a2f41b53cad1a14687e58
1809D3A90 4889542410               mov      qword ptr [rsp + 0x10], rdx 
1809D3A95 48894c2408               mov      qword ptr [rsp + 8], rcx 
1809D3A9A 55                       push     rbp 
1809D3A9B 53                       push     rbx 
1809D3A9C 56                       push     rsi 
1809D3A9D 57                       push     rdi 
1809D3A9E 4154                     push     r12 
1809D3AA0 4155                     push     r13 
1809D3AA2 4156                     push     r14 
1809D3AA4 4157                     push     r15 
1809D3AA6 4883ec68                 sub      rsp, 0x68 
1809D3AAA 488d6c2430               lea      rbp, [rsp + 0x30] 
1809D3AAF 498b4020                 mov      rax, qword ptr [r8 + 0x20] 
1809D3AB3 498bf0                   mov      rsi, r8 
1809D3AB6 4c8bfa                   mov      r15, rdx 
1809D3AB9 48b9f0ffffffffffff0f     movabs   rcx, 0xffffffffffffff0 
1809D3AC3 4c8b88c0000000           mov      r9, qword ptr [rax + 0xc0] 
1809D3ACA 498b4160                 mov      rax, qword ptr [r9 + 0x60] 
1809D3ACE 8b80fc000000             mov      eax, dword ptr [rax + 0xfc] 
1809D3AD4 8bd8                     mov      ebx, eax 
1809D3AD6 898598000000             mov      dword ptr [rbp + 0x98], eax 
1809D3ADC 4883c00f                 add      rax, 0xf 
1809D3AE0 483bc3                   cmp      rax, rbx 
1809D3AE3 7703                     ja       0x1809d3ae8 
1809D3AE5 488bc1                   mov      rax, rcx 
1809D3AE8 4883e0f0                 and      rax, 0xfffffffffffffff0 
1809D3AEC e88f188fff               call     0x1802c5380 
1809D3AF1 482be0                   sub      rsp, rax 
1809D3AF4 488d430f                 lea      rax, [rbx + 0xf] 
1809D3AF8 4c8d742430               lea      r14, [rsp + 0x30] 
1809D3AFD 483bc3                   cmp      rax, rbx 
1809D3B00 7703                     ja       0x1809d3b05 
1809D3B02 488bc1                   mov      rax, rcx 
1809D3B05 4883e0f0                 and      rax, 0xfffffffffffffff0 
1809D3B09 e872188fff               call     0x1802c5380 
1809D3B0E 482be0                   sub      rsp, rax 
1809D3B11 488d442430               lea      rax, [rsp + 0x30] 
1809D3B16 48894510                 mov      qword ptr [rbp + 0x10], rax 
1809D3B1A 488d430f                 lea      rax, [rbx + 0xf] 
1809D3B1E 483bc3                   cmp      rax, rbx 
1809D3B21 7703                     ja       0x1809d3b26 
1809D3B23 488bc1                   mov      rax, rcx 
1809D3B26 4883e0f0                 and      rax, 0xfffffffffffffff0 
1809D3B2A e851188fff               call     0x1802c5380 
1809D3B2F 482be0                   sub      rsp, rax 
1809D3B32 488d430f                 lea      rax, [rbx + 0xf] 
1809D3B36 4c8d6c2430               lea      r13, [rsp + 0x30] 
1809D3B3B 483bc3                   cmp      rax, rbx 
1809D3B3E 7703                     ja       0x1809d3b43 
1809D3B40 488bc1                   mov      rax, rcx 
1809D3B43 4883e0f0                 and      rax, 0xfffffffffffffff0 
1809D3B47 e834188fff               call     0x1802c5380 
1809D3B4C 482be0                   sub      rsp, rax 
1809D3B4F 33ff                     xor      edi, edi 
1809D3B51 488d430f                 lea      rax, [rbx + 0xf] 
1809D3B55 897d00                   mov      dword ptr [rbp], edi 
1809D3B58 4c8d642430               lea      r12, [rsp + 0x30] 
1809D3B5D 483bc3                   cmp      rax, rbx 
1809D3B60 7703                     ja       0x1809d3b65 
1809D3B62 488bc1                   mov      rax, rcx 
1809D3B65 4883e0f0                 and      rax, 0xfffffffffffffff0 
1809D3B69 e812188fff               call     0x1802c5380 
1809D3B6E 482be0                   sub      rsp, rax 
1809D3B71 4c8bc3                   mov      r8, rbx 
1809D3B74 33d2                     xor      edx, edx 
1809D3B76 488d442430               lea      rax, [rsp + 0x30] 
1809D3B7B 488bc8                   mov      rcx, rax 
1809D3B7E 48894508                 mov      qword ptr [rbp + 8], rax 
1809D3B82 e8a92592ff               call     0x1802f6130 
1809D3B87 488b8580000000           mov      rax, qword ptr [rbp + 0x80] 
1809D3B8E 488d9588000000           lea      rdx, [rbp + 0x88] 
1809D3B95 4c8bc3                   mov      r8, rbx 
1809D3B98 488b4018                 mov      rax, qword ptr [rax + 0x18] 
1809D3B9C 48898590000000           mov      qword ptr [rbp + 0x90], rax 
1809D3BA3 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D3BA7 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D3BAE 488b4160                 mov      rax, qword ptr [rcx + 0x60] 
1809D3BB2 8b4828                   mov      ecx, dword ptr [rax + 0x28] 
1809D3BB5 c1e91f                   shr      ecx, 0x1f 
1809D3BB8 84c9                     test     cl, cl 
1809D3BBA 498bce                   mov      rcx, r14 
1809D3BBD 490f45d7                 cmovne   rdx, r15 
1809D3BC1 e82a2992ff               call     0x1802f64f0 
1809D3BC6 4c8b8590000000           mov      r8, qword ptr [rbp + 0x90] 
1809D3BCD 4d85c0                   test     r8, r8 
1809D3BD0 0f846e030000             je       0x1809d3f44 
1809D3BD6 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D3BDA 498bd6                   mov      rdx, r14 
1809D3BDD 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D3BE4 488b4160                 mov      rax, qword ptr [rcx + 0x60] 
1809D3BE8 8b4828                   mov      ecx, dword ptr [rax + 0x28] 
1809D3BEB c1e91f                   shr      ecx, 0x1f 
1809D3BEE 84c9                     test     cl, cl 
1809D3BF0 7503                     jne      0x1809d3bf5 
1809D3BF2 498b16                   mov      rdx, qword ptr [r14] 
1809D3BF5 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D3BF9 4c8d4d18                 lea      r9, [rbp + 0x18] 
1809D3BFD 48895518                 mov      qword ptr [rbp + 0x18], rdx 
1809D3C01 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D3C08 488d4500                 lea      rax, [rbp] 
1809D3C0C 48894520                 mov      qword ptr [rbp + 0x20], rax 
1809D3C10 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D3C14 4c8b9190000000           mov      r10, qword ptr [rcx + 0x90] 
1809D3C1B 498bd2                   mov      rdx, r10 
1809D3C1E 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D3C25 488d8590000000           lea      rax, [rbp + 0x90] 
1809D3C2C 4889442420               mov      qword ptr [rsp + 0x20], rax 
1809D3C31 488b8990000000           mov      rcx, qword ptr [rcx + 0x90] 
1809D3C38 488b09                   mov      rcx, qword ptr [rcx] 
1809D3C3B 41ff5210                 call     qword ptr [r10 + 0x10] 
1809D3C3F 4038bd90000000           cmp      byte ptr [rbp + 0x90], dil 
1809D3C46 0f84ca020000             je       0x1809d3f16 
1809D3C4C 488b9d80000000           mov      rbx, qword ptr [rbp + 0x80] 
1809D3C53 488d9588000000           lea      rdx, [rbp + 0x88] 
1809D3C5A 448b8598000000           mov      r8d, dword ptr [rbp + 0x98] 
1809D3C61 488b4318                 mov      rax, qword ptr [rbx + 0x18] 
1809D3C65 48898590000000           mov      qword ptr [rbp + 0x90], rax 
1809D3C6C 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D3C70 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D3C77 488b4160                 mov      rax, qword ptr [rcx + 0x60] 
1809D3C7B 8b4828                   mov      ecx, dword ptr [rax + 0x28] 
1809D3C7E c1e91f                   shr      ecx, 0x1f 
1809D3C81 84c9                     test     cl, cl 
1809D3C83 498bce                   mov      rcx, r14 
1809D3C86 490f45d7                 cmovne   rdx, r15 
1809D3C8A e8612892ff               call     0x1802f64f0 
1809D3C8F 4c8b8590000000           mov      r8, qword ptr [rbp + 0x90] 
1809D3C96 4d85c0                   test     r8, r8 
1809D3C99 0f84a5020000             je       0x1809d3f44 
1809D3C9F 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D3CA3 498bd6                   mov      rdx, r14 
1809D3CA6 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D3CAD 488b4160                 mov      rax, qword ptr [rcx + 0x60] 
1809D3CB1 8b4828                   mov      ecx, dword ptr [rax + 0x28] 
1809D3CB4 c1e91f                   shr      ecx, 0x1f 
1809D3CB7 84c9                     test     cl, cl 
1809D3CB9 7503                     jne      0x1809d3cbe 
1809D3CBB 498b16                   mov      rdx, qword ptr [r14] 
1809D3CBE 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D3CC2 4c8d4d18                 lea      r9, [rbp + 0x18] 
1809D3CC6 48895518                 mov      qword ptr [rbp + 0x18], rdx 
1809D3CCA 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D3CD1 488d8590000000           lea      rax, [rbp + 0x90] 
1809D3CD8 4889442420               mov      qword ptr [rsp + 0x20], rax 
1809D3CDD 4c8b9198000000           mov      r10, qword ptr [rcx + 0x98] 
1809D3CE4 498bd2                   mov      rdx, r10 
1809D3CE7 498b0a                   mov      rcx, qword ptr [r10] 
1809D3CEA 41ff5210                 call     qword ptr [r10 + 0x10] 
1809D3CEE 4c8b4310                 mov      r8, qword ptr [rbx + 0x10] 
1809D3CF2 4d85c0                   test     r8, r8 
1809D3CF5 0f8449020000             je       0x1809d3f44 
1809D3CFB 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D3CFF 4c8d4d18                 lea      r9, [rbp + 0x18] 
1809D3D03 488b5510                 mov      rdx, qword ptr [rbp + 0x10] 
1809D3D07 48895520                 mov      qword ptr [rbp + 0x20], rdx 
1809D3D0B 4889542420               mov      qword ptr [rsp + 0x20], rdx 
1809D3D10 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D3D17 8b4500                   mov      eax, dword ptr [rbp] 
1809D3D1A 898590000000             mov      dword ptr [rbp + 0x90], eax 
1809D3D20 488d8590000000           lea      rax, [rbp + 0x90] 
1809D3D27 48894518                 mov      qword ptr [rbp + 0x18], rax 
1809D3D2B 4c8b91a0000000           mov      r10, qword ptr [rcx + 0xa0] 
1809D3D32 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D3D36 498bd2                   mov      rdx, r10 
1809D3D39 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D3D40 488b89a0000000           mov      rcx, qword ptr [rcx + 0xa0] 
1809D3D47 488b09                   mov      rcx, qword ptr [rcx] 
1809D3D4A 41ff5210                 call     qword ptr [r10 + 0x10] 
1809D3D4E 8b9d98000000             mov      ebx, dword ptr [rbp + 0x98] 
1809D3D54 488b5510                 mov      rdx, qword ptr [rbp + 0x10] 
1809D3D58 448bc3                   mov      r8d, ebx 
1809D3D5B 488b4d08                 mov      rcx, qword ptr [rbp + 8] 
1809D3D5F e88c2792ff               call     0x1802f64f0 
1809D3D64 488b8580000000           mov      rax, qword ptr [rbp + 0x80] 
1809D3D6B 448bc3                   mov      r8d, ebx 
1809D3D6E 488b5508                 mov      rdx, qword ptr [rbp + 8] 
1809D3D72 498bcd                   mov      rcx, r13 
1809D3D75 488b4020                 mov      rax, qword ptr [rax + 0x20] 
1809D3D79 48898590000000           mov      qword ptr [rbp + 0x90], rax 
1809D3D80 e86b2792ff               call     0x1802f64f0 
1809D3D85 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D3D89 488d9588000000           lea      rdx, [rbp + 0x88] 
1809D3D90 448bc3                   mov      r8d, ebx 
1809D3D93 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D3D9A 488b4160                 mov      rax, qword ptr [rcx + 0x60] 
1809D3D9E 8b4828                   mov      ecx, dword ptr [rax + 0x28] 
1809D3DA1 c1e91f                   shr      ecx, 0x1f 
1809D3DA4 84c9                     test     cl, cl 
1809D3DA6 498bcc                   mov      rcx, r12 
1809D3DA9 490f45d7                 cmovne   rdx, r15 
1809D3DAD e83e2792ff               call     0x1802f64f0 
1809D3DB2 488b9d90000000           mov      rbx, qword ptr [rbp + 0x90] 
1809D3DB9 4885db                   test     rbx, rbx 
1809D3DBC 0f8482010000             je       0x1809d3f44 
1809D3DC2 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D3DC6 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D3DCD 488b4160                 mov      rax, qword ptr [rcx + 0x60] 
1809D3DD1 8b4828                   mov      ecx, dword ptr [rax + 0x28] 
1809D3DD4 c1e91f                   shr      ecx, 0x1f 
1809D3DD7 84c9                     test     cl, cl 
1809D3DD9 7508                     jne      0x1809d3de3 
1809D3DDB 4d8b2424                 mov      r12, qword ptr [r12] 
1809D3DDF 4d8b6d00                 mov      r13, qword ptr [r13] 
1809D3DE3 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D3DE7 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D3DEE 488b5140                 mov      rdx, qword ptr [rcx + 0x40] 
1809D3DF2 f6823501000001           test     byte ptr [rdx + 0x135], 1 
1809D3DF9 750b                     jne      0x1809d3e06 
1809D3DFB 488bca                   mov      rcx, rdx 
1809D3DFE e87d4c88ff               call     0x180258a80 
1809D3E03 488bd0                   mov      rdx, rax 
1809D3E06 4c8b0b                   mov      r9, qword ptr [rbx] 
1809D3E09 410fb7892e010000         movzx    ecx, word ptr [r9 + 0x12e] 
1809D3E11 663bf9                   cmp      di, cx 
1809D3E14 7322                     jae      0x1809d3e38 
1809D3E16 4d8b81b0000000           mov      r8, qword ptr [r9 + 0xb0] 
1809D3E1D 0f1f00                   nop      dword ptr [rax] 
1809D3E20 0fb7c7                   movzx    eax, di 
1809D3E23 4803c0                   add      rax, rax 
1809D3E26 493914c0                 cmp      qword ptr [r8 + rax*8], rdx 
1809D3E2A 0f84f7000000             je       0x1809d3f27 
1809D3E30 66ffc7                   inc      di 
1809D3E33 663bf9                   cmp      di, cx 
1809D3E36 72e8                     jb       0x1809d3e20 
1809D3E38 4533c0                   xor      r8d, r8d 
1809D3E3B 488bcb                   mov      rcx, rbx 
1809D3E3E e83d4588ff               call     0x180258380 
1809D3E43 4c896d18                 mov      qword ptr [rbp + 0x18], r13 
1809D3E47 488d9588000000           lea      rdx, [rbp + 0x88] 
1809D3E4E 4c896520                 mov      qword ptr [rbp + 0x20], r12 
1809D3E52 4c8d4d18                 lea      r9, [rbp + 0x18] 
1809D3E56 4c8b5008                 mov      r10, qword ptr [rax + 8] 
1809D3E5A 4c8bc3                   mov      r8, rbx 
1809D3E5D 4889542420               mov      qword ptr [rsp + 0x20], rdx 
1809D3E62 498bd2                   mov      rdx, r10 
1809D3E65 498b4a08                 mov      rcx, qword ptr [r10 + 8] 
1809D3E69 41ff5210                 call     qword ptr [r10 + 0x10] 
1809D3E6D 80bd8800000000           cmp      byte ptr [rbp + 0x88], 0 
1809D3E74 0f859c000000             jne      0x1809d3f16 
1809D3E7A 488b8580000000           mov      rax, qword ptr [rbp + 0x80] 
1809D3E81 498bce                   mov      rcx, r14 
1809D3E84 448b8598000000           mov      r8d, dword ptr [rbp + 0x98] 
1809D3E8B 488b5508                 mov      rdx, qword ptr [rbp + 8] 
1809D3E8F 488b5818                 mov      rbx, qword ptr [rax + 0x18] 
1809D3E93 e8582692ff               call     0x1802f64f0 
1809D3E98 4885db                   test     rbx, rbx 
1809D3E9B 0f84a3000000             je       0x1809d3f44 
1809D3EA1 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D3EA5 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D3EAC 488b4160                 mov      rax, qword ptr [rcx + 0x60] 
1809D3EB0 8b4828                   mov      ecx, dword ptr [rax + 0x28] 
1809D3EB3 c1e91f                   shr      ecx, 0x1f 
1809D3EB6 84c9                     test     cl, cl 
1809D3EB8 7503                     jne      0x1809d3ebd 
1809D3EBA 4d8b36                   mov      r14, qword ptr [r14] 
1809D3EBD 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D3EC1 4c8d4d18                 lea      r9, [rbp + 0x18] 
1809D3EC5 4c8bc3                   mov      r8, rbx 
1809D3EC8 4c897518                 mov      qword ptr [rbp + 0x18], r14 
1809D3ECC 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D3ED3 8b4500                   mov      eax, dword ptr [rbp] 
1809D3ED6 898580000000             mov      dword ptr [rbp + 0x80], eax 
1809D3EDC 488d8580000000           lea      rax, [rbp + 0x80] 
1809D3EE3 48894520                 mov      qword ptr [rbp + 0x20], rax 
1809D3EE7 4c8b91b0000000           mov      r10, qword ptr [rcx + 0xb0] 
1809D3EEE 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D3EF2 498bd2                   mov      rdx, r10 
1809D3EF5 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D3EFC 488d8580000000           lea      rax, [rbp + 0x80] 
1809D3F03 4889442420               mov      qword ptr [rsp + 0x20], rax 
1809D3F08 488b89b0000000           mov      rcx, qword ptr [rcx + 0xb0] 
1809D3F0F 488b09                   mov      rcx, qword ptr [rcx] 
1809D3F12 41ff5210                 call     qword ptr [r10 + 0x10] 
1809D3F16 488d6538                 lea      rsp, [rbp + 0x38] 
1809D3F1A 415f                     pop      r15 
1809D3F1C 415e                     pop      r14 
1809D3F1E 415d                     pop      r13 
1809D3F20 415c                     pop      r12 
1809D3F22 5f                       pop      rdi 
1809D3F23 5e                       pop      rsi 
1809D3F24 5b                       pop      rbx 
1809D3F25 5d                       pop      rbp 
1809D3F26 c3                       ret       
1809D3F27 0fb7cf                   movzx    ecx, di 
1809D3F2A 4803c9                   add      rcx, rcx 
1809D3F2D 496344c808               movsxd   rax, dword ptr [r8 + rcx*8 + 8] 
1809D3F32 48c1e004                 shl      rax, 4 
1809D3F36 480538010000             add      rax, 0x138 
1809D3F3C 4903c1                   add      rax, r9 
1809D3F3F e9fffeffff               jmp      0x1809d3e43 
1809D3F44 e807c287ff               call     0x180250150 
1809D3F49 cc                       int3      
1809D3F4A cc                       int3      
1809D3F4B cc                       int3      
1809D3F4C cc                       int3      
1809D3F4D cc                       int3      
1809D3F4E cc                       int3      
1809D3F4F cc                       int3      
