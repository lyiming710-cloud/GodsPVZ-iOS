# VA 1809D4710 END 1809D4890 bound=next-method-pointer first-pdata-end=1809D4890 SHA256 a7171580b870fde2f9388bbe80373474d08a22726b8f6c7d90c7ce4b0fd3196e
1809D4710 48895c2408               mov      qword ptr [rsp + 8], rbx 
1809D4715 48896c2410               mov      qword ptr [rsp + 0x10], rbp 
1809D471A 4889742418               mov      qword ptr [rsp + 0x18], rsi 
1809D471F 57                       push     rdi 
1809D4720 4156                     push     r14 
1809D4722 4157                     push     r15 
1809D4724 4883ec20                 sub      rsp, 0x20 
1809D4728 4d8bf0                   mov      r14, r8 
1809D472B 488bfa                   mov      rdi, rdx 
1809D472E 488bf1                   mov      rsi, rcx 
1809D4731 4885d2                   test     rdx, rdx 
1809D4734 0f841d010000             je       0x1809d4857 
1809D473A 448b4218                 mov      r8d, dword ptr [rdx + 0x18] 
1809D473E 33db                     xor      ebx, ebx 
1809D4740 ff421c                   inc      dword ptr [rdx + 0x1c] 
1809D4743 895a18                   mov      dword ptr [rdx + 0x18], ebx 
1809D4746 4585c0                   test     r8d, r8d 
1809D4749 7e0e                     jle      0x1809d4759 
1809D474B 488b4f10                 mov      rcx, qword ptr [rdi + 0x10] 
1809D474F 4533c9                   xor      r9d, r9d 
1809D4752 33d2                     xor      edx, edx 
1809D4754 e8973f2e00               call     0x180cb86f0 
1809D4759 498b4620                 mov      rax, qword ptr [r14 + 0x20] 
1809D475D 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D4764 488b5138                 mov      rdx, qword ptr [rcx + 0x38] 
1809D4768 488bcf                   mov      rcx, rdi 
1809D476B e83073c8ff               call     0x18065baa0 SwfAssocList`1::get_Count
1809D4770 3b4618                   cmp      eax, dword ptr [rsi + 0x18] 
1809D4773 7d1c                     jge      0x1809d4791 
1809D4775 498b4620                 mov      rax, qword ptr [r14 + 0x20] 
1809D4779 488bcf                   mov      rcx, rdi 
1809D477C 8b5618                   mov      edx, dword ptr [rsi + 0x18] 
1809D477F 03d2                     add      edx, edx 
1809D4781 4c8b80c0000000           mov      r8, qword ptr [rax + 0xc0] 
1809D4788 4d8b4048                 mov      r8, qword ptr [r8 + 0x48] 
1809D478C e88f11e3ff               call     0x180805920 
1809D4791 448b7e18                 mov      r15d, dword ptr [rsi + 0x18] 
1809D4795 4585ff                   test     r15d, r15d 
1809D4798 0f8ea0000000             jle      0x1809d483e 
1809D479E 6690                     nop       
1809D47A0 498b4620                 mov      rax, qword ptr [r14 + 0x20] 
1809D47A4 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D47AB 488b6950                 mov      rbp, qword ptr [rcx + 0x50] 
1809D47AF 3b5e18                   cmp      ebx, dword ptr [rsi + 0x18] 
1809D47B2 0f83ab000000             jae      0x1809d4863 
1809D47B8 488b4e10                 mov      rcx, qword ptr [rsi + 0x10] 
1809D47BC 4885c9                   test     rcx, rcx 
1809D47BF 0f8492000000             je       0x1809d4857 
1809D47C5 3b5918                   cmp      ebx, dword ptr [rcx + 0x18] 
1809D47C8 0f838f000000             jae      0x1809d485d 
1809D47CE 4c634718                 movsxd   r8, dword ptr [rdi + 0x18] 
1809D47D2 4863c3                   movsxd   rax, ebx 
1809D47D5 488b54c120               mov      rdx, qword ptr [rcx + rax*8 + 0x20] 
1809D47DA 498b4620                 mov      rax, qword ptr [r14 + 0x20] 
1809D47DE 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D47E5 488b4158                 mov      rax, qword ptr [rcx + 0x58] 
1809D47E9 ff471c                   inc      dword ptr [rdi + 0x1c] 
1809D47EC 488b4f10                 mov      rcx, qword ptr [rdi + 0x10] 
1809D47F0 4885c9                   test     rcx, rcx 
1809D47F3 7462                     je       0x1809d4857 
1809D47F5 443b4118                 cmp      r8d, dword ptr [rcx + 0x18] 
1809D47F9 7219                     jb       0x1809d4814 
1809D47FB 488b4020                 mov      rax, qword ptr [rax + 0x20] 
1809D47FF 488bcf                   mov      rcx, rdi 
1809D4802 4c8b80c0000000           mov      r8, qword ptr [rax + 0xc0] 
1809D4809 4d8b4070                 mov      r8, qword ptr [r8 + 0x70] 
1809D480D e8ce34e7ff               call     0x180847ce0 
1809D4812 eb1f                     jmp      0x1809d4833 
1809D4814 418d4001                 lea      eax, [r8 + 1] 
1809D4818 894718                   mov      dword ptr [rdi + 0x18], eax 
1809D481B 443b4118                 cmp      r8d, dword ptr [rcx + 0x18] 
1809D481F 733c                     jae      0x1809d485d 
1809D4821 4a8954c120               mov      qword ptr [rcx + r8*8 + 0x20], rdx 
1809D4826 4a8d0cc1                 lea      rcx, [rcx + r8*8] 
1809D482A 4883c120                 add      rcx, 0x20 
1809D482E e82dab87ff               call     0x18024f360 
1809D4833 ffc3                     inc      ebx 
1809D4835 413bdf                   cmp      ebx, r15d 
1809D4838 0f8c62ffffff             jl       0x1809d47a0 
1809D483E 488b5c2440               mov      rbx, qword ptr [rsp + 0x40] 
1809D4843 488b6c2448               mov      rbp, qword ptr [rsp + 0x48] 
1809D4848 488b742450               mov      rsi, qword ptr [rsp + 0x50] 
1809D484D 4883c420                 add      rsp, 0x20 
1809D4851 415f                     pop      r15 
1809D4853 415e                     pop      r14 
1809D4855 5f                       pop      rdi 
1809D4856 c3                       ret       
1809D4857 e8f4b887ff               call     0x180250150 
1809D485C cc                       int3      
1809D485D e8deb887ff               call     0x180250140 
1809D4862 cc                       int3      
1809D4863 488d0d56451d01           lea      rcx, [rip + 0x11d4556] 
1809D486A e8a1b687ff               call     0x18024ff10 
1809D486F 488bc8                   mov      rcx, rax 
1809D4872 e889b887ff               call     0x180250100 
1809D4877 33d2                     xor      edx, edx 
1809D4879 488bc8                   mov      rcx, rax 
1809D487C 488bd8                   mov      rbx, rax 
1809D487F e81cd82c00               call     0x180ca20a0 
1809D4884 488bd5                   mov      rdx, rbp 
1809D4887 488bcb                   mov      rcx, rbx 
1809D488A e881b887ff               call     0x180250110 
1809D488F cc                       int3      
