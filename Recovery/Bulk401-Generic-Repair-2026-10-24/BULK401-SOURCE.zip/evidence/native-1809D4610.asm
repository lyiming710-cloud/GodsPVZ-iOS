# VA 1809D4610 END 1809D46E0 bound=next-method-pointer first-pdata-end=1809D46D5 SHA256 1db7fe2518f3b5d17fb9ec5b0e65be2d4808071f1de32f69ac2c9c59595e5d4c
1809D4610 4055                     push     rbp 
1809D4612 4883ec40                 sub      rsp, 0x40 
1809D4616 488d6c2430               lea      rbp, [rsp + 0x30] 
1809D461B 498b4120                 mov      rax, qword ptr [r9 + 0x20] 
1809D461F 48895d20                 mov      qword ptr [rbp + 0x20], rbx 
1809D4623 48897530                 mov      qword ptr [rbp + 0x30], rsi 
1809D4627 498bf0                   mov      rsi, r8 
1809D462A 48897d38                 mov      qword ptr [rbp + 0x38], rdi 
1809D462E 4c8b90c0000000           mov      r10, qword ptr [rax + 0xc0] 
1809D4635 498b4260                 mov      rax, qword ptr [r10 + 0x60] 
1809D4639 8bb8fc000000             mov      edi, dword ptr [rax + 0xfc] 
1809D463F 4c8d570f                 lea      r10, [rdi + 0xf] 
1809D4643 4c3bd7                   cmp      r10, rdi 
1809D4646 770a                     ja       0x1809d4652 
1809D4648 49baf0ffffffffffff0f     movabs   r10, 0xffffffffffffff0 
1809D4652 4983e2f0                 and      r10, 0xfffffffffffffff0 
1809D4656 498bc2                   mov      rax, r10 
1809D4659 e8220d8fff               call     0x1802c5380 
1809D465E 4c8b4110                 mov      r8, qword ptr [rcx + 0x10] 
1809D4662 482be0                   sub      rsp, rax 
1809D4665 488d5c2430               lea      rbx, [rsp + 0x30] 
1809D466A 4d85c0                   test     r8, r8 
1809D466D 7460                     je       0x1809d46cf 
1809D466F 498b4120                 mov      rax, qword ptr [r9 + 0x20] 
1809D4673 895528                   mov      dword ptr [rbp + 0x28], edx 
1809D4676 48895d08                 mov      qword ptr [rbp + 8], rbx 
1809D467A 48895c2420               mov      qword ptr [rsp + 0x20], rbx 
1809D467F 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D4686 488d4528                 lea      rax, [rbp + 0x28] 
1809D468A 48894500                 mov      qword ptr [rbp], rax 
1809D468E 498b4120                 mov      rax, qword ptr [r9 + 0x20] 
1809D4692 4c8d4d00                 lea      r9, [rbp] 
1809D4696 4c8b5158                 mov      r10, qword ptr [rcx + 0x58] 
1809D469A 498bd2                   mov      rdx, r10 
1809D469D 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D46A4 488b4958                 mov      rcx, qword ptr [rcx + 0x58] 
1809D46A8 488b09                   mov      rcx, qword ptr [rcx] 
1809D46AB 41ff5210                 call     qword ptr [r10 + 0x10] 
1809D46AF 4c8bc7                   mov      r8, rdi 
1809D46B2 488bd3                   mov      rdx, rbx 
1809D46B5 488bce                   mov      rcx, rsi 
1809D46B8 e8331e92ff               call     0x1802f64f0 
1809D46BD 488b5d20                 mov      rbx, qword ptr [rbp + 0x20] 
1809D46C1 488b7530                 mov      rsi, qword ptr [rbp + 0x30] 
1809D46C5 488b7d38                 mov      rdi, qword ptr [rbp + 0x38] 
1809D46C9 488d6510                 lea      rsp, [rbp + 0x10] 
1809D46CD 5d                       pop      rbp 
1809D46CE c3                       ret       
1809D46CF e87cba87ff               call     0x180250150 
1809D46D4 cc                       int3      
1809D46D5 cc                       int3      
1809D46D6 cc                       int3      
1809D46D7 cc                       int3      
1809D46D8 cc                       int3      
1809D46D9 cc                       int3      
1809D46DA cc                       int3      
1809D46DB cc                       int3      
1809D46DC cc                       int3      
1809D46DD cc                       int3      
1809D46DE cc                       int3      
1809D46DF cc                       int3      
