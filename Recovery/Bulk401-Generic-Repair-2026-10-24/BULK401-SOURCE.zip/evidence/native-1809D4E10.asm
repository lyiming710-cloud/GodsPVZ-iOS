# VA 1809D4E10 END 1809D5020 bound=next-method-pointer first-pdata-end=1809D5020 SHA256 9aa918a704dae8576e4cf8a2043528bfe4d867904d7878276b71721a59779f9d
1809D4E10 4889542410               mov      qword ptr [rsp + 0x10], rdx 
1809D4E15 55                       push     rbp 
1809D4E16 4154                     push     r12 
1809D4E18 4155                     push     r13 
1809D4E1A 4156                     push     r14 
1809D4E1C 4157                     push     r15 
1809D4E1E 4883ec20                 sub      rsp, 0x20 
1809D4E22 488d6c2420               lea      rbp, [rsp + 0x20] 
1809D4E27 498b4020                 mov      rax, qword ptr [r8 + 0x20] 
1809D4E2B 4d8bf0                   mov      r14, r8 
1809D4E2E 48895d30                 mov      qword ptr [rbp + 0x30], rbx 
1809D4E32 48baf0ffffffffffff0f     movabs   rdx, 0xffffffffffffff0 
1809D4E3C 48897540                 mov      qword ptr [rbp + 0x40], rsi 
1809D4E40 488bf1                   mov      rsi, rcx 
1809D4E43 48897d48                 mov      qword ptr [rbp + 0x48], rdi 
1809D4E47 4c8b88c0000000           mov      r9, qword ptr [rax + 0xc0] 
1809D4E4E 498b4120                 mov      rax, qword ptr [r9 + 0x20] 
1809D4E52 8b98fc000000             mov      ebx, dword ptr [rax + 0xfc] 
1809D4E58 4c8d4b0f                 lea      r9, [rbx + 0xf] 
1809D4E5C 4c3bcb                   cmp      r9, rbx 
1809D4E5F 7703                     ja       0x1809d4e64 
1809D4E61 4c8bca                   mov      r9, rdx 
1809D4E64 4983e1f0                 and      r9, 0xfffffffffffffff0 
1809D4E68 498bc1                   mov      rax, r9 
1809D4E6B e810058fff               call     0x1802c5380 
1809D4E70 492be1                   sub      rsp, r9 
1809D4E73 488d4b0f                 lea      rcx, [rbx + 0xf] 
1809D4E77 4c8d6c2420               lea      r13, [rsp + 0x20] 
1809D4E7C 483bcb                   cmp      rcx, rbx 
1809D4E7F 7703                     ja       0x1809d4e84 
1809D4E81 488bca                   mov      rcx, rdx 
1809D4E84 4883e1f0                 and      rcx, 0xfffffffffffffff0 
1809D4E88 488bc1                   mov      rax, rcx 
1809D4E8B e8f0048fff               call     0x1802c5380 
1809D4E90 482be1                   sub      rsp, rcx 
1809D4E93 488d4b0f                 lea      rcx, [rbx + 0xf] 
1809D4E97 4c8d7c2420               lea      r15, [rsp + 0x20] 
1809D4E9C 483bcb                   cmp      rcx, rbx 
1809D4E9F 7703                     ja       0x1809d4ea4 
1809D4EA1 488bca                   mov      rcx, rdx 
1809D4EA4 4883e1f0                 and      rcx, 0xfffffffffffffff0 
1809D4EA8 488bc1                   mov      rax, rcx 
1809D4EAB e8d0048fff               call     0x1802c5380 
1809D4EB0 482be1                   sub      rsp, rcx 
1809D4EB3 4c8bc3                   mov      r8, rbx 
1809D4EB6 33d2                     xor      edx, edx 
1809D4EB8 4c8d642420               lea      r12, [rsp + 0x20] 
1809D4EBD 498bcc                   mov      rcx, r12 
1809D4EC0 e86b1292ff               call     0x1802f6130 
1809D4EC5 837e1800                 cmp      dword ptr [rsi + 0x18], 0 
1809D4EC9 0f8408010000             je       0x1809d4fd7 
1809D4ECF 448b5618                 mov      r10d, dword ptr [rsi + 0x18] 
1809D4ED3 4c8b4e10                 mov      r9, qword ptr [rsi + 0x10] 
1809D4ED7 41ffca                   dec      r10d 
1809D4EDA 44895618                 mov      dword ptr [rsi + 0x18], r10d 
1809D4EDE 4d85c9                   test     r9, r9 
1809D4EE1 0f8433010000             je       0x1809d501a 
1809D4EE7 453b5118                 cmp      r10d, dword ptr [r9 + 0x18] 
1809D4EEB 0f8323010000             jae      0x1809d5014 
1809D4EF1 498b01                   mov      rax, qword ptr [r9] 
1809D4EF4 4c8bc3                   mov      r8, rbx 
1809D4EF7 4983c120                 add      r9, 0x20 
1809D4EFB 498bcd                   mov      rcx, r13 
1809D4EFE 8b9004010000             mov      edx, dword ptr [rax + 0x104] 
1809D4F04 4963c2                   movsxd   rax, r10d 
1809D4F07 480fafd0                 imul     rdx, rax 
1809D4F0B 4903d1                   add      rdx, r9 
1809D4F0E e8dd1592ff               call     0x1802f64f0 
1809D4F13 488b7e10                 mov      rdi, qword ptr [rsi + 0x10] 
1809D4F17 4c8bc3                   mov      r8, rbx 
1809D4F1A 48637618                 movsxd   rsi, dword ptr [rsi + 0x18] 
1809D4F1E 33d2                     xor      edx, edx 
1809D4F20 498bcc                   mov      rcx, r12 
1809D4F23 e8081292ff               call     0x1802f6130 
1809D4F28 4c8bc3                   mov      r8, rbx 
1809D4F2B 498bd4                   mov      rdx, r12 
1809D4F2E 498bcf                   mov      rcx, r15 
1809D4F31 e8ba1592ff               call     0x1802f64f0 
1809D4F36 4885ff                   test     rdi, rdi 
1809D4F39 0f84db000000             je       0x1809d501a 
1809D4F3F 3b7718                   cmp      esi, dword ptr [rdi + 0x18] 
1809D4F42 0f83cc000000             jae      0x1809d5014 
1809D4F48 488b07                   mov      rax, qword ptr [rdi] 
1809D4F4B 4c8bc3                   mov      r8, rbx 
1809D4F4E 498bd7                   mov      rdx, r15 
1809D4F51 8b8804010000             mov      ecx, dword ptr [rax + 0x104] 
1809D4F57 480fafce                 imul     rcx, rsi 
1809D4F5B 4883c120                 add      rcx, 0x20 
1809D4F5F 4803cf                   add      rcx, rdi 
1809D4F62 e8891592ff               call     0x1802f64f0 
1809D4F67 3b7718                   cmp      esi, dword ptr [rdi + 0x18] 
1809D4F6A 0f83a4000000             jae      0x1809d5014 
1809D4F70 488b07                   mov      rax, qword ptr [rdi] 
1809D4F73 8b8804010000             mov      ecx, dword ptr [rax + 0x104] 
1809D4F79 498b4620                 mov      rax, qword ptr [r14 + 0x20] 
1809D4F7D 480fafce                 imul     rcx, rsi 
1809D4F81 4803f9                   add      rdi, rcx 
1809D4F84 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D4F8B 488b4120                 mov      rax, qword ptr [rcx + 0x20] 
1809D4F8F f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D4F96 7508                     jne      0x1809d4fa0 
1809D4F98 488bc8                   mov      rcx, rax 
1809D4F9B e8e03a88ff               call     0x180258a80 
1809D4FA0 4d8bc7                   mov      r8, r15 
1809D4FA3 488d5720                 lea      rdx, [rdi + 0x20] 
1809D4FA7 488bc8                   mov      rcx, rax 
1809D4FAA e8c1a387ff               call     0x18024f370 
1809D4FAF 488b4d38                 mov      rcx, qword ptr [rbp + 0x38] 
1809D4FB3 4c8bc3                   mov      r8, rbx 
1809D4FB6 498bd5                   mov      rdx, r13 
1809D4FB9 e8321592ff               call     0x1802f64f0 
1809D4FBE 488b5d30                 mov      rbx, qword ptr [rbp + 0x30] 
1809D4FC2 488b7540                 mov      rsi, qword ptr [rbp + 0x40] 
1809D4FC6 488b7d48                 mov      rdi, qword ptr [rbp + 0x48] 
1809D4FCA 488be5                   mov      rsp, rbp 
1809D4FCD 415f                     pop      r15 
1809D4FCF 415e                     pop      r14 
1809D4FD1 415d                     pop      r13 
1809D4FD3 415c                     pop      r12 
1809D4FD5 5d                       pop      rbp 
1809D4FD6 c3                       ret       
1809D4FD7 488d0d624e1d01           lea      rcx, [rip + 0x11d4e62] 
1809D4FDE e82daf87ff               call     0x18024ff10 
1809D4FE3 488bc8                   mov      rcx, rax 
1809D4FE6 e815b187ff               call     0x180250100 
1809D4FEB 488d0de6d91d01           lea      rcx, [rip + 0x11dd9e6] 
1809D4FF2 488bd8                   mov      rbx, rax 
1809D4FF5 e816af87ff               call     0x18024ff10 
1809D4FFA 488bd0                   mov      rdx, rax 
1809D4FFD 4533c0                   xor      r8d, r8d 
1809D5000 488bcb                   mov      rcx, rbx 
1809D5003 e808fc2c00               call     0x180ca4c10 
1809D5008 498bd6                   mov      rdx, r14 
1809D500B 488bcb                   mov      rcx, rbx 
1809D500E e8fdb087ff               call     0x180250110 
1809D5013 cc                       int3      
1809D5014 e827b187ff               call     0x180250140 
1809D5019 cc                       int3      
1809D501A e831b187ff               call     0x180250150 
1809D501F cc                       int3      
