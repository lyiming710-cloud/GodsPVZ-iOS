# VA 1809D3110 END 1809D3270 bound=next-method-pointer first-pdata-end=1809D3268 SHA256 16a140149d7e13f4257da791d3233eed4b39b8fe0f6e0d7357d782faed814778
1809D3110 48895c2408               mov      qword ptr [rsp + 8], rbx 
1809D3115 4889742410               mov      qword ptr [rsp + 0x10], rsi 
1809D311A 57                       push     rdi 
1809D311B 4883ec20                 sub      rsp, 0x20 
1809D311F 488bf9                   mov      rdi, rcx 
1809D3122 498bd8                   mov      rbx, r8 
1809D3125 488b4918                 mov      rcx, qword ptr [rcx + 0x18] 
1809D3129 488bf2                   mov      rsi, rdx 
1809D312C 4885c9                   test     rcx, rcx 
1809D312F 0f8427010000             je       0x1809d325c 
1809D3135 498b4020                 mov      rax, qword ptr [r8 + 0x20] 
1809D3139 4c8b88c0000000           mov      r9, qword ptr [rax + 0xc0] 
1809D3140 4d8b4178                 mov      r8, qword ptr [r9 + 0x78] 
1809D3144 e84750c0ff               call     0x1805d8190 
1809D3149 84c0                     test     al, al 
1809D314B 0f85fb000000             jne      0x1809d324c 
1809D3151 4c8b4710                 mov      r8, qword ptr [rdi + 0x10] 
1809D3155 4d85c0                   test     r8, r8 
1809D3158 0f84fe000000             je       0x1809d325c 
1809D315E 488b4f18                 mov      rcx, qword ptr [rdi + 0x18] 
1809D3162 4885c9                   test     rcx, rcx 
1809D3165 0f84f1000000             je       0x1809d325c 
1809D316B 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D316F 488bd6                   mov      rdx, rsi 
1809D3172 458b4018                 mov      r8d, dword ptr [r8 + 0x18] 
1809D3176 4c8b88c0000000           mov      r9, qword ptr [rax + 0xc0] 
1809D317D 4d8b8980000000           mov      r9, qword ptr [r9 + 0x80] 
1809D3184 e8274fc0ff               call     0x1805d80b0 
1809D3189 488b7f10                 mov      rdi, qword ptr [rdi + 0x10] 
1809D318D 4885ff                   test     rdi, rdi 
1809D3190 0f84c6000000             je       0x1809d325c 
1809D3196 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D319A 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D31A1 488b4710                 mov      rax, qword ptr [rdi + 0x10] 
1809D31A5 488b9188000000           mov      rdx, qword ptr [rcx + 0x88] 
1809D31AC 4885c0                   test     rax, rax 
1809D31AF 0f84a7000000             je       0x1809d325c 
1809D31B5 8b4018                   mov      eax, dword ptr [rax + 0x18] 
1809D31B8 394718                   cmp      dword ptr [rdi + 0x18], eax 
1809D31BB 7562                     jne      0x1809d321f 
1809D31BD 837f1800                 cmp      dword ptr [rdi + 0x18], 0 
1809D31C1 7507                     jne      0x1809d31ca 
1809D31C3 bb04000000               mov      ebx, 4 
1809D31C8 eb05                     jmp      0x1809d31cf 
1809D31CA 8b5f18                   mov      ebx, dword ptr [rdi + 0x18] 
1809D31CD 03db                     add      ebx, ebx 
1809D31CF 488b4220                 mov      rax, qword ptr [rdx + 0x20] 
1809D31D3 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D31DA 488b4118                 mov      rax, qword ptr [rcx + 0x18] 
1809D31DE f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D31E5 7508                     jne      0x1809d31ef 
1809D31E7 488bc8                   mov      rcx, rax 
1809D31EA e8915888ff               call     0x180258a80 
1809D31EF 8bd3                     mov      edx, ebx 
1809D31F1 488bc8                   mov      rcx, rax 
1809D31F4 e8e7c187ff               call     0x18024f3e0 
1809D31F9 448b4718                 mov      r8d, dword ptr [rdi + 0x18] 
1809D31FD 4533c9                   xor      r9d, r9d 
1809D3200 488b4f10                 mov      rcx, qword ptr [rdi + 0x10] 
1809D3204 488bd0                   mov      rdx, rax 
1809D3207 488bd8                   mov      rbx, rax 
1809D320A e8815a2e00               call     0x180cb8c90 
1809D320F 488d4f10                 lea      rcx, [rdi + 0x10] 
1809D3213 48895f10                 mov      qword ptr [rdi + 0x10], rbx 
1809D3217 488bd3                   mov      rdx, rbx 
1809D321A e841c187ff               call     0x18024f360 
1809D321F 48635718                 movsxd   rdx, dword ptr [rdi + 0x18] 
1809D3223 488b4f10                 mov      rcx, qword ptr [rdi + 0x10] 
1809D3227 8d4201                   lea      eax, [rdx + 1] 
1809D322A 894718                   mov      dword ptr [rdi + 0x18], eax 
1809D322D 4885c9                   test     rcx, rcx 
1809D3230 742a                     je       0x1809d325c 
1809D3232 3b5118                   cmp      edx, dword ptr [rcx + 0x18] 
1809D3235 732b                     jae      0x1809d3262 
1809D3237 488974d120               mov      qword ptr [rcx + rdx*8 + 0x20], rsi 
1809D323C 488d0cd1                 lea      rcx, [rcx + rdx*8] 
1809D3240 4883c120                 add      rcx, 0x20 
1809D3244 488bd6                   mov      rdx, rsi 
1809D3247 e814c187ff               call     0x18024f360 
1809D324C 488b5c2430               mov      rbx, qword ptr [rsp + 0x30] 
1809D3251 488b742438               mov      rsi, qword ptr [rsp + 0x38] 
1809D3256 4883c420                 add      rsp, 0x20 
1809D325A 5f                       pop      rdi 
1809D325B c3                       ret       
1809D325C e8efce87ff               call     0x180250150 
1809D3261 cc                       int3      
1809D3262 e8d9ce87ff               call     0x180250140 
1809D3267 cc                       int3      
1809D3268 cc                       int3      
1809D3269 cc                       int3      
1809D326A cc                       int3      
1809D326B cc                       int3      
1809D326C cc                       int3      
1809D326D cc                       int3      
1809D326E cc                       int3      
1809D326F cc                       int3      
