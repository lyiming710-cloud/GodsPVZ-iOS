# VA 1809D5B40 END 1809D5CB0 bound=next-method-pointer first-pdata-end=1809D5CA3 SHA256 31d110ddd1ccb6c5b1d4f6bb64e5515f17d26d677da0c465097c4f9a115d60b7
1809D5B40 4c89442418               mov      qword ptr [rsp + 0x18], r8 
1809D5B45 55                       push     rbp 
1809D5B46 4156                     push     r14 
1809D5B48 4157                     push     r15 
1809D5B4A 4883ec20                 sub      rsp, 0x20 
1809D5B4E 488d6c2420               lea      rbp, [rsp + 0x20] 
1809D5B53 4d8bf1                   mov      r14, r9 
1809D5B56 48895d20                 mov      qword ptr [rbp + 0x20], rbx 
1809D5B5A 48897528                 mov      qword ptr [rbp + 0x28], rsi 
1809D5B5E 4d8bc8                   mov      r9, r8 
1809D5B61 48897d38                 mov      qword ptr [rbp + 0x38], rdi 
1809D5B65 4863fa                   movsxd   rdi, edx 
1809D5B68 498b4620                 mov      rax, qword ptr [r14 + 0x20] 
1809D5B6C 4c8b90c0000000           mov      r10, qword ptr [rax + 0xc0] 
1809D5B73 498b4220                 mov      rax, qword ptr [r10 + 0x20] 
1809D5B77 448bb8fc000000           mov      r15d, dword ptr [rax + 0xfc] 
1809D5B7E 4d8d570f                 lea      r10, [r15 + 0xf] 
1809D5B82 4d3bd7                   cmp      r10, r15 
1809D5B85 770a                     ja       0x1809d5b91 
1809D5B87 49baf0ffffffffffff0f     movabs   r10, 0xffffffffffffff0 
1809D5B91 4983e2f0                 and      r10, 0xfffffffffffffff0 
1809D5B95 498bc2                   mov      rax, r10 
1809D5B98 e8e3f78eff               call     0x1802c5380 
1809D5B9D 482be0                   sub      rsp, rax 
1809D5BA0 488d742420               lea      rsi, [rsp + 0x20] 
1809D5BA5 3b7918                   cmp      edi, dword ptr [rcx + 0x18] 
1809D5BA8 0f83bc000000             jae      0x1809d5c6a 
1809D5BAE 488b5910                 mov      rbx, qword ptr [rcx + 0x10] 
1809D5BB2 488d5530                 lea      rdx, [rbp + 0x30] 
1809D5BB6 498b4620                 mov      rax, qword ptr [r14 + 0x20] 
1809D5BBA 4d8bc7                   mov      r8, r15 
1809D5BBD 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D5BC4 488b4120                 mov      rax, qword ptr [rcx + 0x20] 
1809D5BC8 8b4828                   mov      ecx, dword ptr [rax + 0x28] 
1809D5BCB c1e91f                   shr      ecx, 0x1f 
1809D5BCE 84c9                     test     cl, cl 
1809D5BD0 488bce                   mov      rcx, rsi 
1809D5BD3 490f45d1                 cmovne   rdx, r9 
1809D5BD7 e8140992ff               call     0x1802f64f0 
1809D5BDC 4885db                   test     rbx, rbx 
1809D5BDF 0f84b8000000             je       0x1809d5c9d 
1809D5BE5 3b7b18                   cmp      edi, dword ptr [rbx + 0x18] 
1809D5BE8 0f83a9000000             jae      0x1809d5c97 
1809D5BEE 488b03                   mov      rax, qword ptr [rbx] 
1809D5BF1 4d8bc7                   mov      r8, r15 
1809D5BF4 488bd6                   mov      rdx, rsi 
1809D5BF7 8b8804010000             mov      ecx, dword ptr [rax + 0x104] 
1809D5BFD 480fafcf                 imul     rcx, rdi 
1809D5C01 4883c120                 add      rcx, 0x20 
1809D5C05 4803cb                   add      rcx, rbx 
1809D5C08 e8e30892ff               call     0x1802f64f0 
1809D5C0D 3b7b18                   cmp      edi, dword ptr [rbx + 0x18] 
1809D5C10 0f8381000000             jae      0x1809d5c97 
1809D5C16 488b03                   mov      rax, qword ptr [rbx] 
1809D5C19 8b8804010000             mov      ecx, dword ptr [rax + 0x104] 
1809D5C1F 498b4620                 mov      rax, qword ptr [r14 + 0x20] 
1809D5C23 480fafcf                 imul     rcx, rdi 
1809D5C27 4803d9                   add      rbx, rcx 
1809D5C2A 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D5C31 488b4120                 mov      rax, qword ptr [rcx + 0x20] 
1809D5C35 f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D5C3C 7508                     jne      0x1809d5c46 
1809D5C3E 488bc8                   mov      rcx, rax 
1809D5C41 e83a2e88ff               call     0x180258a80 
1809D5C46 4c8bc6                   mov      r8, rsi 
1809D5C49 488d5320                 lea      rdx, [rbx + 0x20] 
1809D5C4D 488bc8                   mov      rcx, rax 
1809D5C50 e81b9787ff               call     0x18024f370 
1809D5C55 488b5d20                 mov      rbx, qword ptr [rbp + 0x20] 
1809D5C59 488b7528                 mov      rsi, qword ptr [rbp + 0x28] 
1809D5C5D 488b7d38                 mov      rdi, qword ptr [rbp + 0x38] 
1809D5C61 488be5                   mov      rsp, rbp 
1809D5C64 415f                     pop      r15 
1809D5C66 415e                     pop      r14 
1809D5C68 5d                       pop      rbp 
1809D5C69 c3                       ret       
1809D5C6A 488d0d4f311d01           lea      rcx, [rip + 0x11d314f] 
1809D5C71 e89aa287ff               call     0x18024ff10 
1809D5C76 488bc8                   mov      rcx, rax 
1809D5C79 e882a487ff               call     0x180250100 
1809D5C7E 33d2                     xor      edx, edx 
1809D5C80 488bc8                   mov      rcx, rax 
1809D5C83 488bd8                   mov      rbx, rax 
1809D5C86 e815c42c00               call     0x180ca20a0 
1809D5C8B 498bd6                   mov      rdx, r14 
1809D5C8E 488bcb                   mov      rcx, rbx 
1809D5C91 e87aa487ff               call     0x180250110 
1809D5C96 cc                       int3      
1809D5C97 e8a4a487ff               call     0x180250140 
1809D5C9C cc                       int3      
1809D5C9D e8aea487ff               call     0x180250150 
1809D5CA2 cc                       int3      
1809D5CA3 cc                       int3      
1809D5CA4 cc                       int3      
1809D5CA5 cc                       int3      
1809D5CA6 cc                       int3      
1809D5CA7 cc                       int3      
1809D5CA8 cc                       int3      
1809D5CA9 cc                       int3      
1809D5CAA cc                       int3      
1809D5CAB cc                       int3      
1809D5CAC cc                       int3      
1809D5CAD cc                       int3      
1809D5CAE cc                       int3      
1809D5CAF cc                       int3      
