# VA 1809D5770 END 1809D58A0 bound=next-method-pointer first-pdata-end=1809D5892 SHA256 93d6a2893c61e3e061d7f453091e4b8bf7d344f7634f9cac5a12bc954c797622
1809D5770 48895c2408               mov      qword ptr [rsp + 8], rbx 
1809D5775 4889742410               mov      qword ptr [rsp + 0x10], rsi 
1809D577A 57                       push     rdi 
1809D577B 4883ec20                 sub      rsp, 0x20 
1809D577F 8bfa                     mov      edi, edx 
1809D5781 498bf0                   mov      rsi, r8 
1809D5784 33d2                     xor      edx, edx 
1809D5786 488bd9                   mov      rbx, rcx 
1809D5789 e8e2c992ff               call     0x180302170 <StartCoro>d__4::System.IDisposable.Dispose
1809D578E 85ff                     test     edi, edi 
1809D5790 0f88ad000000             js       0x1809d5843 
1809D5796 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D579A 488b80c0000000           mov      rax, qword ptr [rax + 0xc0] 
1809D57A1 7446                     je       0x1809d57e9 
1809D57A3 488b4018                 mov      rax, qword ptr [rax + 0x18] 
1809D57A7 f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D57AE 7508                     jne      0x1809d57b8 
1809D57B0 488bc8                   mov      rcx, rax 
1809D57B3 e8c83288ff               call     0x180258a80 
1809D57B8 8bd7                     mov      edx, edi 
1809D57BA 488bc8                   mov      rcx, rax 
1809D57BD e81e9c87ff               call     0x18024f3e0 
1809D57C2 48894310                 mov      qword ptr [rbx + 0x10], rax 
1809D57C6 488d4b10                 lea      rcx, [rbx + 0x10] 
1809D57CA 488bd0                   mov      rdx, rax 
1809D57CD e88e9b87ff               call     0x18024f360 
1809D57D2 488b742438               mov      rsi, qword ptr [rsp + 0x38] 
1809D57D7 c7431800000000           mov      dword ptr [rbx + 0x18], 0 
1809D57DE 488b5c2430               mov      rbx, qword ptr [rsp + 0x30] 
1809D57E3 4883c420                 add      rsp, 0x20 
1809D57E7 5f                       pop      rdi 
1809D57E8 c3                       ret       
1809D57E9 488b4010                 mov      rax, qword ptr [rax + 0x10] 
1809D57ED f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D57F4 7508                     jne      0x1809d57fe 
1809D57F6 488bc8                   mov      rcx, rax 
1809D57F9 e8823288ff               call     0x180258a80 
1809D57FE 83b8e000000000           cmp      dword ptr [rax + 0xe0], 0 
1809D5805 7508                     jne      0x1809d580f 
1809D5807 488bc8                   mov      rcx, rax 
1809D580A e8d1a987ff               call     0x1802501e0 
1809D580F 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D5813 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D581A 488b4110                 mov      rax, qword ptr [rcx + 0x10] 
1809D581E f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D5825 7508                     jne      0x1809d582f 
1809D5827 488bc8                   mov      rcx, rax 
1809D582A e8513288ff               call     0x180258a80 
1809D582F 488b80b8000000           mov      rax, qword ptr [rax + 0xb8] 
1809D5836 488d4b10                 lea      rcx, [rbx + 0x10] 
1809D583A 488b10                   mov      rdx, qword ptr [rax] 
1809D583D 48895310                 mov      qword ptr [rbx + 0x10], rdx 
1809D5841 eb8a                     jmp      0x1809d57cd 
1809D5843 488d0d869c1f01           lea      rcx, [rip + 0x11f9c86] 
1809D584A e8c1a687ff               call     0x18024ff10 
1809D584F 488bc8                   mov      rcx, rax 
1809D5852 e8a9a887ff               call     0x180250100 
1809D5857 488d0dfa451d01           lea      rcx, [rip + 0x11d45fa] 
1809D585E 488bf8                   mov      rdi, rax 
1809D5861 e8aaa687ff               call     0x18024ff10 
1809D5866 488d0d93451d01           lea      rcx, [rip + 0x11d4593] 
1809D586D 488bd8                   mov      rbx, rax 
1809D5870 e89ba687ff               call     0x18024ff10 
1809D5875 4533c9                   xor      r9d, r9d 
1809D5878 4c8bc3                   mov      r8, rbx 
1809D587B 488bd0                   mov      rdx, rax 
1809D587E 488bcf                   mov      rcx, rdi 
1809D5881 e8aab11a00               call     0x180b80a30 
1809D5886 488bd6                   mov      rdx, rsi 
1809D5889 488bcf                   mov      rcx, rdi 
1809D588C e87fa887ff               call     0x180250110 
1809D5891 cc                       int3      
1809D5892 cc                       int3      
1809D5893 cc                       int3      
1809D5894 cc                       int3      
1809D5895 cc                       int3      
1809D5896 cc                       int3      
1809D5897 cc                       int3      
1809D5898 cc                       int3      
1809D5899 cc                       int3      
1809D589A cc                       int3      
1809D589B cc                       int3      
1809D589C cc                       int3      
1809D589D cc                       int3      
1809D589E cc                       int3      
1809D589F cc                       int3      
