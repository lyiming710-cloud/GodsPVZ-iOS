# VA 1809D5100 END 1809D52C0 bound=next-method-pointer first-pdata-end=1809D52B3 SHA256 1890ac8261dd3cceb4c20732c50ec01483d3dc080e643f1e16eefb93709b6fca
1809D5100 4889542410               mov      qword ptr [rsp + 0x10], rdx 
1809D5105 55                       push     rbp 
1809D5106 4154                     push     r12 
1809D5108 4155                     push     r13 
1809D510A 4156                     push     r14 
1809D510C 4157                     push     r15 
1809D510E 4883ec20                 sub      rsp, 0x20 
1809D5112 488d6c2420               lea      rbp, [rsp + 0x20] 
1809D5117 498b4020                 mov      rax, qword ptr [r8 + 0x20] 
1809D511B 4d8bf0                   mov      r14, r8 
1809D511E 48895d30                 mov      qword ptr [rbp + 0x30], rbx 
1809D5122 4c8bea                   mov      r13, rdx 
1809D5125 48897540                 mov      qword ptr [rbp + 0x40], rsi 
1809D5129 48897d48                 mov      qword ptr [rbp + 0x48], rdi 
1809D512D 488bf9                   mov      rdi, rcx 
1809D5130 4c8b88c0000000           mov      r9, qword ptr [rax + 0xc0] 
1809D5137 498b4120                 mov      rax, qword ptr [r9 + 0x20] 
1809D513B 448ba0fc000000           mov      r12d, dword ptr [rax + 0xfc] 
1809D5142 498d4c240f               lea      rcx, [r12 + 0xf] 
1809D5147 493bcc                   cmp      rcx, r12 
1809D514A 770a                     ja       0x1809d5156 
1809D514C 48b9f0ffffffffffff0f     movabs   rcx, 0xffffffffffffff0 
1809D5156 4883e1f0                 and      rcx, 0xfffffffffffffff0 
1809D515A 488bc1                   mov      rax, rcx 
1809D515D e81e028fff               call     0x1802c5380 
1809D5162 488b4710                 mov      rax, qword ptr [rdi + 0x10] 
1809D5166 482be1                   sub      rsp, rcx 
1809D5169 4c8d7c2420               lea      r15, [rsp + 0x20] 
1809D516E 4885c0                   test     rax, rax 
1809D5171 0f8430010000             je       0x1809d52a7 
1809D5177 8b4018                   mov      eax, dword ptr [rax + 0x18] 
1809D517A 394718                   cmp      dword ptr [rdi + 0x18], eax 
1809D517D 7562                     jne      0x1809d51e1 
1809D517F 837f1800                 cmp      dword ptr [rdi + 0x18], 0 
1809D5183 7507                     jne      0x1809d518c 
1809D5185 bb04000000               mov      ebx, 4 
1809D518A eb05                     jmp      0x1809d5191 
1809D518C 8b5f18                   mov      ebx, dword ptr [rdi + 0x18] 
1809D518F 03db                     add      ebx, ebx 
1809D5191 498b4020                 mov      rax, qword ptr [r8 + 0x20] 
1809D5195 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D519C 488b4118                 mov      rax, qword ptr [rcx + 0x18] 
1809D51A0 f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D51A7 7508                     jne      0x1809d51b1 
1809D51A9 488bc8                   mov      rcx, rax 
1809D51AC e8cf3888ff               call     0x180258a80 
1809D51B1 8bd3                     mov      edx, ebx 
1809D51B3 488bc8                   mov      rcx, rax 
1809D51B6 e825a287ff               call     0x18024f3e0 
1809D51BB 448b4718                 mov      r8d, dword ptr [rdi + 0x18] 
1809D51BF 4533c9                   xor      r9d, r9d 
1809D51C2 488b4f10                 mov      rcx, qword ptr [rdi + 0x10] 
1809D51C6 488bd0                   mov      rdx, rax 
1809D51C9 488bd8                   mov      rbx, rax 
1809D51CC e8bf3a2e00               call     0x180cb8c90 
1809D51D1 488d4f10                 lea      rcx, [rdi + 0x10] 
1809D51D5 48895f10                 mov      qword ptr [rdi + 0x10], rbx 
1809D51D9 488bd3                   mov      rdx, rbx 
1809D51DC e87fa187ff               call     0x18024f360 
1809D51E1 48637718                 movsxd   rsi, dword ptr [rdi + 0x18] 
1809D51E5 488d5538                 lea      rdx, [rbp + 0x38] 
1809D51E9 488b5f10                 mov      rbx, qword ptr [rdi + 0x10] 
1809D51ED 4d8bc4                   mov      r8, r12 
1809D51F0 8d4601                   lea      eax, [rsi + 1] 
1809D51F3 894718                   mov      dword ptr [rdi + 0x18], eax 
1809D51F6 498b4620                 mov      rax, qword ptr [r14 + 0x20] 
1809D51FA 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D5201 488b4120                 mov      rax, qword ptr [rcx + 0x20] 
1809D5205 8b4828                   mov      ecx, dword ptr [rax + 0x28] 
1809D5208 c1e91f                   shr      ecx, 0x1f 
1809D520B 84c9                     test     cl, cl 
1809D520D 498bcf                   mov      rcx, r15 
1809D5210 490f45d5                 cmovne   rdx, r13 
1809D5214 e8d71292ff               call     0x1802f64f0 
1809D5219 4885db                   test     rbx, rbx 
1809D521C 0f8485000000             je       0x1809d52a7 
1809D5222 3b7318                   cmp      esi, dword ptr [rbx + 0x18] 
1809D5225 0f8382000000             jae      0x1809d52ad 
1809D522B 488b03                   mov      rax, qword ptr [rbx] 
1809D522E 4d8bc4                   mov      r8, r12 
1809D5231 498bd7                   mov      rdx, r15 
1809D5234 8b8804010000             mov      ecx, dword ptr [rax + 0x104] 
1809D523A 480fafce                 imul     rcx, rsi 
1809D523E 4883c120                 add      rcx, 0x20 
1809D5242 4803cb                   add      rcx, rbx 
1809D5245 e8a61292ff               call     0x1802f64f0 
1809D524A 3b7318                   cmp      esi, dword ptr [rbx + 0x18] 
1809D524D 735e                     jae      0x1809d52ad 
1809D524F 488b03                   mov      rax, qword ptr [rbx] 
1809D5252 8b8804010000             mov      ecx, dword ptr [rax + 0x104] 
1809D5258 498b4620                 mov      rax, qword ptr [r14 + 0x20] 
1809D525C 480fafce                 imul     rcx, rsi 
1809D5260 4803d9                   add      rbx, rcx 
1809D5263 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D526A 488b4120                 mov      rax, qword ptr [rcx + 0x20] 
1809D526E f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D5275 7508                     jne      0x1809d527f 
1809D5277 488bc8                   mov      rcx, rax 
1809D527A e8013888ff               call     0x180258a80 
1809D527F 4d8bc7                   mov      r8, r15 
1809D5282 488d5320                 lea      rdx, [rbx + 0x20] 
1809D5286 488bc8                   mov      rcx, rax 
1809D5289 e8e2a087ff               call     0x18024f370 
1809D528E 488b5d30                 mov      rbx, qword ptr [rbp + 0x30] 
1809D5292 488b7540                 mov      rsi, qword ptr [rbp + 0x40] 
1809D5296 488b7d48                 mov      rdi, qword ptr [rbp + 0x48] 
1809D529A 488be5                   mov      rsp, rbp 
1809D529D 415f                     pop      r15 
1809D529F 415e                     pop      r14 
1809D52A1 415d                     pop      r13 
1809D52A3 415c                     pop      r12 
1809D52A5 5d                       pop      rbp 
1809D52A6 c3                       ret       
1809D52A7 e8a4ae87ff               call     0x180250150 
1809D52AC cc                       int3      
1809D52AD e88eae87ff               call     0x180250140 
1809D52B2 cc                       int3      
1809D52B3 cc                       int3      
1809D52B4 cc                       int3      
1809D52B5 cc                       int3      
1809D52B6 cc                       int3      
1809D52B7 cc                       int3      
1809D52B8 cc                       int3      
1809D52B9 cc                       int3      
1809D52BA cc                       int3      
1809D52BB cc                       int3      
1809D52BC cc                       int3      
1809D52BD cc                       int3      
1809D52BE cc                       int3      
1809D52BF cc                       int3      
