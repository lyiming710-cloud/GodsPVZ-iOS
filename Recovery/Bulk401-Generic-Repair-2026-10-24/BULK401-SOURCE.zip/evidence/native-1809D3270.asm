# VA 1809D3270 END 1809D34F0 bound=next-method-pointer first-pdata-end=1809D34E9 SHA256 66e1571284aa6ea403fb38e81fc21bebd9953449639464abbc9c573f4daccdb4
1809D3270 4889542410               mov      qword ptr [rsp + 0x10], rdx 
1809D3275 55                       push     rbp 
1809D3276 56                       push     rsi 
1809D3277 57                       push     rdi 
1809D3278 4154                     push     r12 
1809D327A 4155                     push     r13 
1809D327C 4156                     push     r14 
1809D327E 4157                     push     r15 
1809D3280 4883ec40                 sub      rsp, 0x40 
1809D3284 488d6c2430               lea      rbp, [rsp + 0x30] 
1809D3289 498b4020                 mov      rax, qword ptr [r8 + 0x20] 
1809D328D 4c8bf9                   mov      r15, rcx 
1809D3290 48895d68                 mov      qword ptr [rbp + 0x68], rbx 
1809D3294 4c8bf2                   mov      r14, rdx 
1809D3297 498bd8                   mov      rbx, r8 
1809D329A 48b9f0ffffffffffff0f     movabs   rcx, 0xffffffffffffff0 
1809D32A4 4c8b88c0000000           mov      r9, qword ptr [rax + 0xc0] 
1809D32AB 498b4160                 mov      rax, qword ptr [r9 + 0x60] 
1809D32AF 448ba0fc000000           mov      r12d, dword ptr [rax + 0xfc] 
1809D32B6 458bc4                   mov      r8d, r12d 
1809D32B9 498d44240f               lea      rax, [r12 + 0xf] 
1809D32BE 493bc4                   cmp      rax, r12 
1809D32C1 7703                     ja       0x1809d32c6 
1809D32C3 488bc1                   mov      rax, rcx 
1809D32C6 4883e0f0                 and      rax, 0xfffffffffffffff0 
1809D32CA e8b1208fff               call     0x1802c5380 
1809D32CF 482be0                   sub      rsp, rax 
1809D32D2 498d44240f               lea      rax, [r12 + 0xf] 
1809D32D7 488d7c2430               lea      rdi, [rsp + 0x30] 
1809D32DC 493bc0                   cmp      rax, r8 
1809D32DF 7703                     ja       0x1809d32e4 
1809D32E1 488bc1                   mov      rax, rcx 
1809D32E4 4883e0f0                 and      rax, 0xfffffffffffffff0 
1809D32E8 e893208fff               call     0x1802c5380 
1809D32ED 4d8b6f18                 mov      r13, qword ptr [r15 + 0x18] 
1809D32F1 488d5558                 lea      rdx, [rbp + 0x58] 
1809D32F5 482be0                   sub      rsp, rax 
1809D32F8 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D32FC 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D3303 488d742430               lea      rsi, [rsp + 0x30] 
1809D3308 488b4160                 mov      rax, qword ptr [rcx + 0x60] 
1809D330C 8b4828                   mov      ecx, dword ptr [rax + 0x28] 
1809D330F c1e91f                   shr      ecx, 0x1f 
1809D3312 84c9                     test     cl, cl 
1809D3314 488bcf                   mov      rcx, rdi 
1809D3317 490f45d6                 cmovne   rdx, r14 
1809D331B e8d03192ff               call     0x1802f64f0 
1809D3320 4d85ed                   test     r13, r13 
1809D3323 0f84ba010000             je       0x1809d34e3 
1809D3329 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D332D 488bd7                   mov      rdx, rdi 
1809D3330 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D3337 488b4160                 mov      rax, qword ptr [rcx + 0x60] 
1809D333B 8b4828                   mov      ecx, dword ptr [rax + 0x28] 
1809D333E c1e91f                   shr      ecx, 0x1f 
1809D3341 84c9                     test     cl, cl 
1809D3343 7503                     jne      0x1809d3348 
1809D3345 488b17                   mov      rdx, qword ptr [rdi] 
1809D3348 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D334C 4c8d4d60                 lea      r9, [rbp + 0x60] 
1809D3350 48895560                 mov      qword ptr [rbp + 0x60], rdx 
1809D3354 4d8bc5                   mov      r8, r13 
1809D3357 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D335E 488d4550                 lea      rax, [rbp + 0x50] 
1809D3362 4889442420               mov      qword ptr [rsp + 0x20], rax 
1809D3367 4c8b5178                 mov      r10, qword ptr [rcx + 0x78] 
1809D336B 498bd2                   mov      rdx, r10 
1809D336E 498b0a                   mov      rcx, qword ptr [r10] 
1809D3371 41ff5210                 call     qword ptr [r10 + 0x10] 
1809D3375 807d5000                 cmp      byte ptr [rbp + 0x50], 0 
1809D3379 0f8550010000             jne      0x1809d34cf 
1809D337F 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D3383 488d5558                 lea      rdx, [rbp + 0x58] 
1809D3387 4d8b6f18                 mov      r13, qword ptr [r15 + 0x18] 
1809D338B 4d8bc4                   mov      r8, r12 
1809D338E 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D3395 488b4160                 mov      rax, qword ptr [rcx + 0x60] 
1809D3399 8b4828                   mov      ecx, dword ptr [rax + 0x28] 
1809D339C c1e91f                   shr      ecx, 0x1f 
1809D339F 84c9                     test     cl, cl 
1809D33A1 488bcf                   mov      rcx, rdi 
1809D33A4 490f45d6                 cmovne   rdx, r14 
1809D33A8 e8433192ff               call     0x1802f64f0 
1809D33AD 498b4f10                 mov      rcx, qword ptr [r15 + 0x10] 
1809D33B1 4885c9                   test     rcx, rcx 
1809D33B4 0f8429010000             je       0x1809d34e3 
1809D33BA 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D33BE 488b90c0000000           mov      rdx, qword ptr [rax + 0xc0] 
1809D33C5 488b4270                 mov      rax, qword ptr [rdx + 0x70] 
1809D33C9 4c8b00                   mov      r8, qword ptr [rax] 
1809D33CC 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D33D0 488b90c0000000           mov      rdx, qword ptr [rax + 0xc0] 
1809D33D7 488b5270                 mov      rdx, qword ptr [rdx + 0x70] 
1809D33DB 41ffd0                   call     r8 
1809D33DE 448bc0                   mov      r8d, eax 
1809D33E1 4d85ed                   test     r13, r13 
1809D33E4 0f84f9000000             je       0x1809d34e3 
1809D33EA 488b4b20                 mov      rcx, qword ptr [rbx + 0x20] 
1809D33EE 488b91c0000000           mov      rdx, qword ptr [rcx + 0xc0] 
1809D33F5 488b4a60                 mov      rcx, qword ptr [rdx + 0x60] 
1809D33F9 8b5128                   mov      edx, dword ptr [rcx + 0x28] 
1809D33FC c1ea1f                   shr      edx, 0x1f 
1809D33FF 84d2                     test     dl, dl 
1809D3401 7503                     jne      0x1809d3406 
1809D3403 488b3f                   mov      rdi, qword ptr [rdi] 
1809D3406 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D340A 4c8d4d00                 lea      r9, [rbp] 
1809D340E 44894550                 mov      dword ptr [rbp + 0x50], r8d 
1809D3412 4d8bc5                   mov      r8, r13 
1809D3415 48897d00                 mov      qword ptr [rbp], rdi 
1809D3419 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D3420 488d4550                 lea      rax, [rbp + 0x50] 
1809D3424 48894508                 mov      qword ptr [rbp + 8], rax 
1809D3428 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D342C 4c8b9180000000           mov      r10, qword ptr [rcx + 0x80] 
1809D3433 498bd2                   mov      rdx, r10 
1809D3436 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D343D 488d4550                 lea      rax, [rbp + 0x50] 
1809D3441 4889442420               mov      qword ptr [rsp + 0x20], rax 
1809D3446 488b8980000000           mov      rcx, qword ptr [rcx + 0x80] 
1809D344D 488b09                   mov      rcx, qword ptr [rcx] 
1809D3450 41ff5210                 call     qword ptr [r10 + 0x10] 
1809D3454 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D3458 488d5558                 lea      rdx, [rbp + 0x58] 
1809D345C 498b7f10                 mov      rdi, qword ptr [r15 + 0x10] 
1809D3460 4d8bc4                   mov      r8, r12 
1809D3463 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D346A 488b4160                 mov      rax, qword ptr [rcx + 0x60] 
1809D346E 8b4828                   mov      ecx, dword ptr [rax + 0x28] 
1809D3471 c1e91f                   shr      ecx, 0x1f 
1809D3474 84c9                     test     cl, cl 
1809D3476 488bce                   mov      rcx, rsi 
1809D3479 490f45d6                 cmovne   rdx, r14 
1809D347D e86e3092ff               call     0x1802f64f0 
1809D3482 4885ff                   test     rdi, rdi 
1809D3485 745c                     je       0x1809d34e3 
1809D3487 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D348B 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D3492 488b4160                 mov      rax, qword ptr [rcx + 0x60] 
1809D3496 8b4828                   mov      ecx, dword ptr [rax + 0x28] 
1809D3499 c1e91f                   shr      ecx, 0x1f 
1809D349C 84c9                     test     cl, cl 
1809D349E 7503                     jne      0x1809d34a3 
1809D34A0 488b36                   mov      rsi, qword ptr [rsi] 
1809D34A3 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D34A7 4c8d4d58                 lea      r9, [rbp + 0x58] 
1809D34AB 4c8bc7                   mov      r8, rdi 
1809D34AE 48897558                 mov      qword ptr [rbp + 0x58], rsi 
1809D34B2 4889742420               mov      qword ptr [rsp + 0x20], rsi 
1809D34B7 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D34BE 4c8b9188000000           mov      r10, qword ptr [rcx + 0x88] 
1809D34C5 498bd2                   mov      rdx, r10 
1809D34C8 498b0a                   mov      rcx, qword ptr [r10] 
1809D34CB 41ff5210                 call     qword ptr [r10 + 0x10] 
1809D34CF 488b5d68                 mov      rbx, qword ptr [rbp + 0x68] 
1809D34D3 488d6510                 lea      rsp, [rbp + 0x10] 
1809D34D7 415f                     pop      r15 
1809D34D9 415e                     pop      r14 
1809D34DB 415d                     pop      r13 
1809D34DD 415c                     pop      r12 
1809D34DF 5f                       pop      rdi 
1809D34E0 5e                       pop      rsi 
1809D34E1 5d                       pop      rbp 
1809D34E2 c3                       ret       
1809D34E3 e868cc87ff               call     0x180250150 
1809D34E8 cc                       int3      
1809D34E9 cc                       int3      
1809D34EA cc                       int3      
1809D34EB cc                       int3      
1809D34EC cc                       int3      
1809D34ED cc                       int3      
1809D34EE cc                       int3      
1809D34EF cc                       int3      
