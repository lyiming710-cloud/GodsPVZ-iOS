# VA 1809D53A0 END 1809D56D0 bound=next-method-pointer first-pdata-end=1809D56CD SHA256 54e672e121a63a929bbe34b9268bff6786d7279d58388f5dc1cb1bcba2bc4b8b
1809D53A0 4c89442418               mov      qword ptr [rsp + 0x18], r8 
1809D53A5 55                       push     rbp 
1809D53A6 56                       push     rsi 
1809D53A7 57                       push     rdi 
1809D53A8 4154                     push     r12 
1809D53AA 4155                     push     r13 
1809D53AC 4156                     push     r14 
1809D53AE 4157                     push     r15 
1809D53B0 4883ec30                 sub      rsp, 0x30 
1809D53B4 488d6c2420               lea      rbp, [rsp + 0x20] 
1809D53B9 498b4120                 mov      rax, qword ptr [r9 + 0x20] 
1809D53BD 4d8bf9                   mov      r15, r9 
1809D53C0 48895d58                 mov      qword ptr [rbp + 0x58], rbx 
1809D53C4 4c8bf1                   mov      r14, rcx 
1809D53C7 4863f2                   movsxd   rsi, edx 
1809D53CA 49bcf0ffffffffffff0f     movabs   r12, 0xffffffffffffff0 
1809D53D4 4c8b90c0000000           mov      r10, qword ptr [rax + 0xc0] 
1809D53DB 498b4220                 mov      rax, qword ptr [r10 + 0x20] 
1809D53DF 8b98fc000000             mov      ebx, dword ptr [rax + 0xfc] 
1809D53E5 4c8d530f                 lea      r10, [rbx + 0xf] 
1809D53E9 4c3bd3                   cmp      r10, rbx 
1809D53EC 7703                     ja       0x1809d53f1 
1809D53EE 4d8bd4                   mov      r10, r12 
1809D53F1 4983e2f0                 and      r10, 0xfffffffffffffff0 
1809D53F5 498bc2                   mov      rax, r10 
1809D53F8 e883ff8eff               call     0x1802c5380 
1809D53FD 482be0                   sub      rsp, rax 
1809D5400 488d4b0f                 lea      rcx, [rbx + 0xf] 
1809D5404 488d442420               lea      rax, [rsp + 0x20] 
1809D5409 48894568                 mov      qword ptr [rbp + 0x68], rax 
1809D540D 483bcb                   cmp      rcx, rbx 
1809D5410 7703                     ja       0x1809d5415 
1809D5412 498bcc                   mov      rcx, r12 
1809D5415 4883e1f0                 and      rcx, 0xfffffffffffffff0 
1809D5419 488bc1                   mov      rax, rcx 
1809D541C e85fff8eff               call     0x1802c5380 
1809D5421 482be1                   sub      rsp, rcx 
1809D5424 488d4b0f                 lea      rcx, [rbx + 0xf] 
1809D5428 488d442420               lea      rax, [rsp + 0x20] 
1809D542D 48894550                 mov      qword ptr [rbp + 0x50], rax 
1809D5431 483bcb                   cmp      rcx, rbx 
1809D5434 7703                     ja       0x1809d5439 
1809D5436 498bcc                   mov      rcx, r12 
1809D5439 4883e1f0                 and      rcx, 0xfffffffffffffff0 
1809D543D 488bc1                   mov      rax, rcx 
1809D5440 e83bff8eff               call     0x1802c5380 
1809D5445 482be1                   sub      rsp, rcx 
1809D5448 488d4b0f                 lea      rcx, [rbx + 0xf] 
1809D544C 4c8d6c2420               lea      r13, [rsp + 0x20] 
1809D5451 483bcb                   cmp      rcx, rbx 
1809D5454 7703                     ja       0x1809d5459 
1809D5456 498bcc                   mov      rcx, r12 
1809D5459 4883e1f0                 and      rcx, 0xfffffffffffffff0 
1809D545D 488bc1                   mov      rax, rcx 
1809D5460 e81bff8eff               call     0x1802c5380 
1809D5465 482be1                   sub      rsp, rcx 
1809D5468 488d4b0f                 lea      rcx, [rbx + 0xf] 
1809D546C 488d442420               lea      rax, [rsp + 0x20] 
1809D5471 48894508                 mov      qword ptr [rbp + 8], rax 
1809D5475 483bcb                   cmp      rcx, rbx 
1809D5478 7703                     ja       0x1809d547d 
1809D547A 498bcc                   mov      rcx, r12 
1809D547D 4883e1f0                 and      rcx, 0xfffffffffffffff0 
1809D5481 488bc1                   mov      rax, rcx 
1809D5484 e8f7fe8eff               call     0x1802c5380 
1809D5489 482be1                   sub      rsp, rcx 
1809D548C 4c8bc3                   mov      r8, rbx 
1809D548F 33d2                     xor      edx, edx 
1809D5491 488d7c2420               lea      rdi, [rsp + 0x20] 
1809D5496 488bcf                   mov      rcx, rdi 
1809D5499 48897d00                 mov      qword ptr [rbp], rdi 
1809D549D e88e0c92ff               call     0x1802f6130 
1809D54A2 488d4b0f                 lea      rcx, [rbx + 0xf] 
1809D54A6 483bcb                   cmp      rcx, rbx 
1809D54A9 7703                     ja       0x1809d54ae 
1809D54AB 498bcc                   mov      rcx, r12 
1809D54AE 4883e1f0                 and      rcx, 0xfffffffffffffff0 
1809D54B2 488bc1                   mov      rax, rcx 
1809D54B5 e8c6fe8eff               call     0x1802c5380 
1809D54BA 482be1                   sub      rsp, rcx 
1809D54BD 4c8bc3                   mov      r8, rbx 
1809D54C0 33d2                     xor      edx, edx 
1809D54C2 4c8d642420               lea      r12, [rsp + 0x20] 
1809D54C7 498bcc                   mov      rcx, r12 
1809D54CA e8610c92ff               call     0x1802f6130 
1809D54CF 413b7618                 cmp      esi, dword ptr [r14 + 0x18] 
1809D54D3 0f83bb010000             jae      0x1809d5694 
1809D54D9 4d8b4e10                 mov      r9, qword ptr [r14 + 0x10] 
1809D54DD 4d85c9                   test     r9, r9 
1809D54E0 0f84e1010000             je       0x1809d56c7 
1809D54E6 458b5618                 mov      r10d, dword ptr [r14 + 0x18] 
1809D54EA 41ffca                   dec      r10d 
1809D54ED 453b5118                 cmp      r10d, dword ptr [r9 + 0x18] 
1809D54F1 0f83ca010000             jae      0x1809d56c1 
1809D54F7 498b01                   mov      rax, qword ptr [r9] 
1809D54FA 4c8bc3                   mov      r8, rbx 
1809D54FD 488b4d68                 mov      rcx, qword ptr [rbp + 0x68] 
1809D5501 4983c120                 add      r9, 0x20 
1809D5505 8b9004010000             mov      edx, dword ptr [rax + 0x104] 
1809D550B 4963c2                   movsxd   rax, r10d 
1809D550E 480fafd0                 imul     rdx, rax 
1809D5512 4903d1                   add      rdx, r9 
1809D5515 e8d60f92ff               call     0x1802f64f0 
1809D551A 488b5568                 mov      rdx, qword ptr [rbp + 0x68] 
1809D551E 4c8bc3                   mov      r8, rbx 
1809D5521 488bcf                   mov      rcx, rdi 
1809D5524 e8c70f92ff               call     0x1802f64f0 
1809D5529 488b5500                 mov      rdx, qword ptr [rbp] 
1809D552D 4c8bc3                   mov      r8, rbx 
1809D5530 488b4d50                 mov      rcx, qword ptr [rbp + 0x50] 
1809D5534 498b7e10                 mov      rdi, qword ptr [r14 + 0x10] 
1809D5538 e8b30f92ff               call     0x1802f64f0 
1809D553D 4885ff                   test     rdi, rdi 
1809D5540 0f8481010000             je       0x1809d56c7 
1809D5546 3b7718                   cmp      esi, dword ptr [rdi + 0x18] 
1809D5549 0f8372010000             jae      0x1809d56c1 
1809D554F 488b07                   mov      rax, qword ptr [rdi] 
1809D5552 4c8bc3                   mov      r8, rbx 
1809D5555 488b5550                 mov      rdx, qword ptr [rbp + 0x50] 
1809D5559 8b8804010000             mov      ecx, dword ptr [rax + 0x104] 
1809D555F 480fafce                 imul     rcx, rsi 
1809D5563 4883c120                 add      rcx, 0x20 
1809D5567 4803cf                   add      rcx, rdi 
1809D556A e8810f92ff               call     0x1802f64f0 
1809D556F 3b7718                   cmp      esi, dword ptr [rdi + 0x18] 
1809D5572 0f8349010000             jae      0x1809d56c1 
1809D5578 488b07                   mov      rax, qword ptr [rdi] 
1809D557B 8b8804010000             mov      ecx, dword ptr [rax + 0x104] 
1809D5581 498b4720                 mov      rax, qword ptr [r15 + 0x20] 
1809D5585 480fafce                 imul     rcx, rsi 
1809D5589 4803f9                   add      rdi, rcx 
1809D558C 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D5593 488b4120                 mov      rax, qword ptr [rcx + 0x20] 
1809D5597 f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D559E 7508                     jne      0x1809d55a8 
1809D55A0 488bc8                   mov      rcx, rax 
1809D55A3 e8d83488ff               call     0x180258a80 
1809D55A8 4c8b4550                 mov      r8, qword ptr [rbp + 0x50] 
1809D55AC 488d5720                 lea      rdx, [rdi + 0x20] 
1809D55B0 488bc8                   mov      rcx, rax 
1809D55B3 e8b89d87ff               call     0x18024f370 
1809D55B8 418b7618                 mov      esi, dword ptr [r14 + 0x18] 
1809D55BC 4c8bc3                   mov      r8, rbx 
1809D55BF 498b7e10                 mov      rdi, qword ptr [r14 + 0x10] 
1809D55C3 ffce                     dec      esi 
1809D55C5 33d2                     xor      edx, edx 
1809D55C7 41897618                 mov      dword ptr [r14 + 0x18], esi 
1809D55CB 498bcc                   mov      rcx, r12 
1809D55CE e85d0b92ff               call     0x1802f6130 
1809D55D3 4c8bc3                   mov      r8, rbx 
1809D55D6 498bd4                   mov      rdx, r12 
1809D55D9 498bcd                   mov      rcx, r13 
1809D55DC e80f0f92ff               call     0x1802f64f0 
1809D55E1 4885ff                   test     rdi, rdi 
1809D55E4 0f84dd000000             je       0x1809d56c7 
1809D55EA 3b7718                   cmp      esi, dword ptr [rdi + 0x18] 
1809D55ED 0f83ce000000             jae      0x1809d56c1 
1809D55F3 488b07                   mov      rax, qword ptr [rdi] 
1809D55F6 4c8bc3                   mov      r8, rbx 
1809D55F9 498bd5                   mov      rdx, r13 
1809D55FC 8b8804010000             mov      ecx, dword ptr [rax + 0x104] 
1809D5602 4863c6                   movsxd   rax, esi 
1809D5605 480fafc8                 imul     rcx, rax 
1809D5609 4883c120                 add      rcx, 0x20 
1809D560D 4803cf                   add      rcx, rdi 
1809D5610 e8db0e92ff               call     0x1802f64f0 
1809D5615 3b7718                   cmp      esi, dword ptr [rdi + 0x18] 
1809D5618 0f83a3000000             jae      0x1809d56c1 
1809D561E 488b07                   mov      rax, qword ptr [rdi] 
1809D5621 8b8804010000             mov      ecx, dword ptr [rax + 0x104] 
1809D5627 4863c6                   movsxd   rax, esi 
1809D562A 480fafc8                 imul     rcx, rax 
1809D562E 498b4720                 mov      rax, qword ptr [r15 + 0x20] 
1809D5632 4803f9                   add      rdi, rcx 
1809D5635 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D563C 488b4120                 mov      rax, qword ptr [rcx + 0x20] 
1809D5640 f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D5647 7508                     jne      0x1809d5651 
1809D5649 488bc8                   mov      rcx, rax 
1809D564C e82f3488ff               call     0x180258a80 
1809D5651 4d8bc5                   mov      r8, r13 
1809D5654 488d5720                 lea      rdx, [rdi + 0x20] 
1809D5658 488bc8                   mov      rcx, rax 
1809D565B e8109d87ff               call     0x18024f370 
1809D5660 488b5500                 mov      rdx, qword ptr [rbp] 
1809D5664 4c8bc3                   mov      r8, rbx 
1809D5667 488b4d08                 mov      rcx, qword ptr [rbp + 8] 
1809D566B e8800e92ff               call     0x1802f64f0 
1809D5670 488b5508                 mov      rdx, qword ptr [rbp + 8] 
1809D5674 4c8bc3                   mov      r8, rbx 
1809D5677 488b4d60                 mov      rcx, qword ptr [rbp + 0x60] 
1809D567B e8700e92ff               call     0x1802f64f0 
1809D5680 488b5d58                 mov      rbx, qword ptr [rbp + 0x58] 
1809D5684 488d6510                 lea      rsp, [rbp + 0x10] 
1809D5688 415f                     pop      r15 
1809D568A 415e                     pop      r14 
1809D568C 415d                     pop      r13 
1809D568E 415c                     pop      r12 
1809D5690 5f                       pop      rdi 
1809D5691 5e                       pop      rsi 
1809D5692 5d                       pop      rbp 
1809D5693 c3                       ret       
1809D5694 488d0d25371d01           lea      rcx, [rip + 0x11d3725] 
1809D569B e870a887ff               call     0x18024ff10 
1809D56A0 488bc8                   mov      rcx, rax 
1809D56A3 e858aa87ff               call     0x180250100 
1809D56A8 33d2                     xor      edx, edx 
1809D56AA 488bc8                   mov      rcx, rax 
1809D56AD 488bd8                   mov      rbx, rax 
1809D56B0 e8ebc92c00               call     0x180ca20a0 
1809D56B5 498bd7                   mov      rdx, r15 
1809D56B8 488bcb                   mov      rcx, rbx 
1809D56BB e850aa87ff               call     0x180250110 
1809D56C0 cc                       int3      
1809D56C1 e87aaa87ff               call     0x180250140 
1809D56C6 cc                       int3      
1809D56C7 e884aa87ff               call     0x180250150 
1809D56CC cc                       int3      
1809D56CD cc                       int3      
1809D56CE cc                       int3      
1809D56CF cc                       int3      
