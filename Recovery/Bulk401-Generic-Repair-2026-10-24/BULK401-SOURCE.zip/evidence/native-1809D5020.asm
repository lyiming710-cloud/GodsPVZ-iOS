# VA 1809D5020 END 1809D5100 bound=next-method-pointer first-pdata-end=1809D5049 SHA256 b1f048d71eb3fb5bfc504d293af68f560d4cb228737393a70572ee44865de079
1809D5020 4889742410               mov      qword ptr [rsp + 0x10], rsi 
1809D5025 57                       push     rdi 
1809D5026 4883ec20                 sub      rsp, 0x20 
1809D502A 488b4110                 mov      rax, qword ptr [rcx + 0x10] 
1809D502E 488bf2                   mov      rsi, rdx 
1809D5031 488bf9                   mov      rdi, rcx 
1809D5034 4885c0                   test     rax, rax 
1809D5037 0f84ab000000             je       0x1809d50e8 
1809D503D 8b4018                   mov      eax, dword ptr [rax + 0x18] 
1809D5040 394118                   cmp      dword ptr [rcx + 0x18], eax 
1809D5043 756c                     jne      0x1809d50b1 
1809D5045 83791800                 cmp      dword ptr [rcx + 0x18], 0 
1809D5049 48895c2430               mov      qword ptr [rsp + 0x30], rbx 
1809D504E 7507                     jne      0x1809d5057 
1809D5050 bb04000000               mov      ebx, 4 
1809D5055 eb05                     jmp      0x1809d505c 
1809D5057 8b5918                   mov      ebx, dword ptr [rcx + 0x18] 
1809D505A 03db                     add      ebx, ebx 
1809D505C 498b4020                 mov      rax, qword ptr [r8 + 0x20] 
1809D5060 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D5067 488b4118                 mov      rax, qword ptr [rcx + 0x18] 
1809D506B f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D5072 7508                     jne      0x1809d507c 
1809D5074 488bc8                   mov      rcx, rax 
1809D5077 e8043a88ff               call     0x180258a80 
1809D507C 8bd3                     mov      edx, ebx 
1809D507E 488bc8                   mov      rcx, rax 
1809D5081 e85aa387ff               call     0x18024f3e0 
1809D5086 448b4718                 mov      r8d, dword ptr [rdi + 0x18] 
1809D508A 4533c9                   xor      r9d, r9d 
1809D508D 488b4f10                 mov      rcx, qword ptr [rdi + 0x10] 
1809D5091 488bd0                   mov      rdx, rax 
1809D5094 488bd8                   mov      rbx, rax 
1809D5097 e8f43b2e00               call     0x180cb8c90 
1809D509C 488d4f10                 lea      rcx, [rdi + 0x10] 
1809D50A0 48895f10                 mov      qword ptr [rdi + 0x10], rbx 
1809D50A4 488bd3                   mov      rdx, rbx 
1809D50A7 e8b4a287ff               call     0x18024f360 
1809D50AC 488b5c2430               mov      rbx, qword ptr [rsp + 0x30] 
1809D50B1 48635718                 movsxd   rdx, dword ptr [rdi + 0x18] 
1809D50B5 488b4f10                 mov      rcx, qword ptr [rdi + 0x10] 
1809D50B9 8d4201                   lea      eax, [rdx + 1] 
1809D50BC 894718                   mov      dword ptr [rdi + 0x18], eax 
1809D50BF 4885c9                   test     rcx, rcx 
1809D50C2 7424                     je       0x1809d50e8 
1809D50C4 3b5118                   cmp      edx, dword ptr [rcx + 0x18] 
1809D50C7 7325                     jae      0x1809d50ee 
1809D50C9 488974d120               mov      qword ptr [rcx + rdx*8 + 0x20], rsi 
1809D50CE 488d0cd1                 lea      rcx, [rcx + rdx*8] 
1809D50D2 4883c120                 add      rcx, 0x20 
1809D50D6 488bd6                   mov      rdx, rsi 
1809D50D9 488b742438               mov      rsi, qword ptr [rsp + 0x38] 
1809D50DE 4883c420                 add      rsp, 0x20 
1809D50E2 5f                       pop      rdi 
1809D50E3 e978a287ff               jmp      0x18024f360 
1809D50E8 e863b087ff               call     0x180250150 
1809D50ED cc                       int3      
1809D50EE e84db087ff               call     0x180250140 
1809D50F3 cc                       int3      
1809D50F4 cc                       int3      
1809D50F5 cc                       int3      
1809D50F6 cc                       int3      
1809D50F7 cc                       int3      
1809D50F8 cc                       int3      
1809D50F9 cc                       int3      
1809D50FA cc                       int3      
1809D50FB cc                       int3      
1809D50FC cc                       int3      
1809D50FD cc                       int3      
1809D50FE cc                       int3      
1809D50FF cc                       int3      
