# VA 1809D34F0 END 1809D3520 bound=next-method-pointer first-pdata-end=1809D351F SHA256 97ad3c196d09405ede010597c36ba6de73d60790645324975e178e1d54abb87c
1809D34F0 4883ec28                 sub      rsp, 0x28 
1809D34F4 488b4910                 mov      rcx, qword ptr [rcx + 0x10] 
1809D34F8 4885c9                   test     rcx, rcx 
1809D34FB 741c                     je       0x1809d3519 
1809D34FD 498b4020                 mov      rax, qword ptr [r8 + 0x20] 
1809D3501 4c8b80c0000000           mov      r8, qword ptr [rax + 0xc0] 
1809D3508 498b80d0000000           mov      rax, qword ptr [r8 + 0xd0] 
1809D350F 4c8bc0                   mov      r8, rax 
1809D3512 4883c428                 add      rsp, 0x28 
1809D3516 48ff20                   jmp      qword ptr [rax] 
1809D3519 e832cc87ff               call     0x180250150 
1809D351E cc                       int3      
1809D351F cc                       int3      
