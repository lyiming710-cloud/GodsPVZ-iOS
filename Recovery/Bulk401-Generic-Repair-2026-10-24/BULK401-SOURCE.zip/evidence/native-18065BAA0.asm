# VA 18065BAA0 END 18065BAC0 bound=next-method-pointer first-pdata-end=18065BABB SHA256 18f0ba98c38585ffea5180285c000d976b53f46a523274e3f4f5f35f93829b96
18065BAA0 4883ec28                 sub      rsp, 0x28 
18065BAA4 488b4110                 mov      rax, qword ptr [rcx + 0x10] 
18065BAA8 4885c0                   test     rax, rax 
18065BAAB 7408                     je       0x18065bab5 
18065BAAD 8b4018                   mov      eax, dword ptr [rax + 0x18] 
18065BAB0 4883c428                 add      rsp, 0x28 
18065BAB4 c3                       ret       
18065BAB5 e89646bfff               call     0x180250150 
18065BABA cc                       int3      
18065BABB cc                       int3      
18065BABC cc                       int3      
18065BABD cc                       int3      
18065BABE cc                       int3      
18065BABF cc                       int3      
