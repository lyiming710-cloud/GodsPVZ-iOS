# VA 1809334F0 END 180933520 bound=next-method-pointer first-pdata-end=18093351F SHA256 2eb956470725d498f902d218cb78ab8bb3cc135a7d85173f3ab33dd77674c192
1809334F0 4883ec28                 sub      rsp, 0x28 
1809334F4 488b4910                 mov      rcx, qword ptr [rcx + 0x10] 
1809334F8 4885c9                   test     rcx, rcx 
1809334FB 741c                     je       0x180933519 
1809334FD 498b4020                 mov      rax, qword ptr [r8 + 0x20] 
180933501 4c8b80c0000000           mov      r8, qword ptr [rax + 0xc0] 
180933508 498b80d8000000           mov      rax, qword ptr [r8 + 0xd8] 
18093350F 4c8bc0                   mov      r8, rax 
180933512 4883c428                 add      rsp, 0x28 
180933516 48ff20                   jmp      qword ptr [rax] 
180933519 e832cc91ff               call     0x180250150 
18093351E cc                       int3      
18093351F cc                       int3      
