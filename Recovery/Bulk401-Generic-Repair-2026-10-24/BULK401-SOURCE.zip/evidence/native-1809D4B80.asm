# VA 1809D4B80 END 1809D4BB0 bound=next-method-pointer first-pdata-end=1809D4BA8 SHA256 d8857cd007aa5bc28f20b056dbb577e49e205c10a58b8f20c1fc684fa8537129
1809D4B80 4053                     push     rbx 
1809D4B82 4883ec20                 sub      rsp, 0x20 
1809D4B86 448b4118                 mov      r8d, dword ptr [rcx + 0x18] 
1809D4B8A 488bd9                   mov      rbx, rcx 
1809D4B8D 488b4910                 mov      rcx, qword ptr [rcx + 0x10] 
1809D4B91 4533c9                   xor      r9d, r9d 
1809D4B94 33d2                     xor      edx, edx 
1809D4B96 e8553b2e00               call     0x180cb86f0 
1809D4B9B c7431800000000           mov      dword ptr [rbx + 0x18], 0 
1809D4BA2 4883c420                 add      rsp, 0x20 
1809D4BA6 5b                       pop      rbx 
1809D4BA7 c3                       ret       
1809D4BA8 cc                       int3      
1809D4BA9 cc                       int3      
1809D4BAA cc                       int3      
1809D4BAB cc                       int3      
1809D4BAC cc                       int3      
1809D4BAD cc                       int3      
1809D4BAE cc                       int3      
1809D4BAF cc                       int3      
