# VA 1809D40C0 END 1809D42C0 bound=next-method-pointer first-pdata-end=1809D42B9 SHA256 de972f137d90fdd5e040af20e62fc04997fed221663fd6562282c833ec5f8979
1809D40C0 48895c2408               mov      qword ptr [rsp + 8], rbx 
1809D40C5 48896c2410               mov      qword ptr [rsp + 0x10], rbp 
1809D40CA 4889742418               mov      qword ptr [rsp + 0x18], rsi 
1809D40CF 48897c2420               mov      qword ptr [rsp + 0x20], rdi 
1809D40D4 4156                     push     r14 
1809D40D6 4883ec20                 sub      rsp, 0x20 
1809D40DA 8bfa                     mov      edi, edx 
1809D40DC 4d8bf0                   mov      r14, r8 
1809D40DF 33d2                     xor      edx, edx 
1809D40E1 488be9                   mov      rbp, rcx 
1809D40E4 e887e092ff               call     0x180302170 <StartCoro>d__4::System.IDisposable.Dispose
1809D40E9 498b4620                 mov      rax, qword ptr [r14 + 0x20] 
1809D40ED 4c8b88c0000000           mov      r9, qword ptr [rax + 0xc0] 
1809D40F4 498b01                   mov      rax, qword ptr [r9] 
1809D40F7 f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D40FE 7508                     jne      0x1809d4108 
1809D4100 488bc8                   mov      rcx, rax 
1809D4103 e8784988ff               call     0x180258a80 
1809D4108 488bc8                   mov      rcx, rax 
1809D410B e8f0bf87ff               call     0x180250100 
1809D4110 488bd8                   mov      rbx, rax 
1809D4113 33d2                     xor      edx, edx 
1809D4115 498b4620                 mov      rax, qword ptr [r14 + 0x20] 
1809D4119 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D4120 488b7148                 mov      rsi, qword ptr [rcx + 0x48] 
1809D4124 488bcb                   mov      rcx, rbx 
1809D4127 e844e092ff               call     0x180302170 <StartCoro>d__4::System.IDisposable.Dispose
1809D412C 85ff                     test     edi, edi 
1809D412E 0f8836010000             js       0x1809d426a 
1809D4134 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D4138 488b80c0000000           mov      rax, qword ptr [rax + 0xc0] 
1809D413F 7421                     je       0x1809d4162 
1809D4141 488b4018                 mov      rax, qword ptr [rax + 0x18] 
1809D4145 f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D414C 7508                     jne      0x1809d4156 
1809D414E 488bc8                   mov      rcx, rax 
1809D4151 e82a4988ff               call     0x180258a80 
1809D4156 8bd7                     mov      edx, edi 
1809D4158 488bc8                   mov      rcx, rax 
1809D415B e880b287ff               call     0x18024f3e0 
1809D4160 eb50                     jmp      0x1809d41b2 
1809D4162 488b4010                 mov      rax, qword ptr [rax + 0x10] 
1809D4166 f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D416D 7508                     jne      0x1809d4177 
1809D416F 488bc8                   mov      rcx, rax 
1809D4172 e8094988ff               call     0x180258a80 
1809D4177 83b8e000000000           cmp      dword ptr [rax + 0xe0], 0 
1809D417E 7508                     jne      0x1809d4188 
1809D4180 488bc8                   mov      rcx, rax 
1809D4183 e858c087ff               call     0x1802501e0 
1809D4188 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D418C 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D4193 488b4110                 mov      rax, qword ptr [rcx + 0x10] 
1809D4197 f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D419E 7508                     jne      0x1809d41a8 
1809D41A0 488bc8                   mov      rcx, rax 
1809D41A3 e8d84888ff               call     0x180258a80 
1809D41A8 488b80b8000000           mov      rax, qword ptr [rax + 0xb8] 
1809D41AF 488b00                   mov      rax, qword ptr [rax] 
1809D41B2 488d4b10                 lea      rcx, [rbx + 0x10] 
1809D41B6 488bd0                   mov      rdx, rax 
1809D41B9 488901                   mov      qword ptr [rcx], rax 
1809D41BC e89fb187ff               call     0x18024f360 
1809D41C1 c7431800000000           mov      dword ptr [rbx + 0x18], 0 
1809D41C8 488d4d10                 lea      rcx, [rbp + 0x10] 
1809D41CC 488bd3                   mov      rdx, rbx 
1809D41CF 48895d10                 mov      qword ptr [rbp + 0x10], rbx 
1809D41D3 e888b187ff               call     0x18024f360 
1809D41D8 498b4620                 mov      rax, qword ptr [r14 + 0x20] 
1809D41DC 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D41E3 488b4118                 mov      rax, qword ptr [rcx + 0x18] 
1809D41E7 f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D41EE 7508                     jne      0x1809d41f8 
1809D41F0 488bc8                   mov      rcx, rax 
1809D41F3 e8884888ff               call     0x180258a80 
1809D41F8 488bc8                   mov      rcx, rax 
1809D41FB e800bf87ff               call     0x180250100 
1809D4200 498b4e20                 mov      rcx, qword ptr [r14 + 0x20] 
1809D4204 8bd7                     mov      edx, edi 
1809D4206 488bd8                   mov      rbx, rax 
1809D4209 4c8b81c0000000           mov      r8, qword ptr [rcx + 0xc0] 
1809D4210 488bc8                   mov      rcx, rax 
1809D4213 4d8b4050                 mov      r8, qword ptr [r8 + 0x50] 
1809D4217 e8e440c1ff               call     0x1805e8300 
1809D421C 488d4d18                 lea      rcx, [rbp + 0x18] 
1809D4220 48895d18                 mov      qword ptr [rbp + 0x18], rbx 
1809D4224 488bd3                   mov      rdx, rbx 
1809D4227 e834b187ff               call     0x18024f360 
1809D422C 498b4620                 mov      rax, qword ptr [r14 + 0x20] 
1809D4230 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D4237 488b4928                 mov      rcx, qword ptr [rcx + 0x28] 
1809D423B e8a02363ff               call     0x1800065e0 
1809D4240 488d4d20                 lea      rcx, [rbp + 0x20] 
1809D4244 48894520                 mov      qword ptr [rbp + 0x20], rax 
1809D4248 488bd0                   mov      rdx, rax 
1809D424B 488b5c2430               mov      rbx, qword ptr [rsp + 0x30] 
1809D4250 488b6c2438               mov      rbp, qword ptr [rsp + 0x38] 
1809D4255 488b742440               mov      rsi, qword ptr [rsp + 0x40] 
1809D425A 488b7c2448               mov      rdi, qword ptr [rsp + 0x48] 
1809D425F 4883c420                 add      rsp, 0x20 
1809D4263 415e                     pop      r14 
1809D4265 e9f6b087ff               jmp      0x18024f360 
1809D426A 488d0d5fb21f01           lea      rcx, [rip + 0x11fb25f] 
1809D4271 e89abc87ff               call     0x18024ff10 
1809D4276 488bc8                   mov      rcx, rax 
1809D4279 e882be87ff               call     0x180250100 
1809D427E 488d0dd35b1d01           lea      rcx, [rip + 0x11d5bd3] 
1809D4285 488bf8                   mov      rdi, rax 
1809D4288 e883bc87ff               call     0x18024ff10 
1809D428D 488d0d6c5b1d01           lea      rcx, [rip + 0x11d5b6c] 
1809D4294 488bd8                   mov      rbx, rax 
1809D4297 e874bc87ff               call     0x18024ff10 
1809D429C 4533c9                   xor      r9d, r9d 
1809D429F 4c8bc3                   mov      r8, rbx 
1809D42A2 488bd0                   mov      rdx, rax 
1809D42A5 488bcf                   mov      rcx, rdi 
1809D42A8 e883c71a00               call     0x180b80a30 
1809D42AD 488bd6                   mov      rdx, rsi 
1809D42B0 488bcf                   mov      rcx, rdi 
1809D42B3 e858be87ff               call     0x180250110 
1809D42B8 cc                       int3      
1809D42B9 cc                       int3      
1809D42BA cc                       int3      
1809D42BB cc                       int3      
1809D42BC cc                       int3      
1809D42BD cc                       int3      
1809D42BE cc                       int3      
1809D42BF cc                       int3      
