# VA 1809D4520 END 1809D4610 bound=next-method-pointer first-pdata-end=1809D460C SHA256 70b53b40703ab85583483dd43ea392cdfc1dff4212a17efb75b969d9a0099046
1809D4520 4889542410               mov      qword ptr [rsp + 0x10], rdx 
1809D4525 55                       push     rbp 
1809D4526 57                       push     rdi 
1809D4527 4156                     push     r14 
1809D4529 4883ec30                 sub      rsp, 0x30 
1809D452D 488d6c2430               lea      rbp, [rsp + 0x30] 
1809D4532 498b4020                 mov      rax, qword ptr [r8 + 0x20] 
1809D4536 48895d30                 mov      qword ptr [rbp + 0x30], rbx 
1809D453A 498bd8                   mov      rbx, r8 
1809D453D 48897538                 mov      qword ptr [rbp + 0x38], rsi 
1809D4541 488bf2                   mov      rsi, rdx 
1809D4544 4c8b88c0000000           mov      r9, qword ptr [rax + 0xc0] 
1809D454B 498b4160                 mov      rax, qword ptr [r9 + 0x60] 
1809D454F 448b80fc000000           mov      r8d, dword ptr [rax + 0xfc] 
1809D4556 498d400f                 lea      rax, [r8 + 0xf] 
1809D455A 493bc0                   cmp      rax, r8 
1809D455D 770a                     ja       0x1809d4569 
1809D455F 48b8f0ffffffffffff0f     movabs   rax, 0xffffffffffffff0 
1809D4569 4883e0f0                 and      rax, 0xfffffffffffffff0 
1809D456D e80e0e8fff               call     0x1802c5380 
1809D4572 4c8b7118                 mov      r14, qword ptr [rcx + 0x18] 
1809D4576 488d5528                 lea      rdx, [rbp + 0x28] 
1809D457A 482be0                   sub      rsp, rax 
1809D457D 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D4581 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D4588 488d7c2430               lea      rdi, [rsp + 0x30] 
1809D458D 488b4160                 mov      rax, qword ptr [rcx + 0x60] 
1809D4591 8b4828                   mov      ecx, dword ptr [rax + 0x28] 
1809D4594 c1e91f                   shr      ecx, 0x1f 
1809D4597 84c9                     test     cl, cl 
1809D4599 488bcf                   mov      rcx, rdi 
1809D459C 480f45d6                 cmovne   rdx, rsi 
1809D45A0 e84b1f92ff               call     0x1802f64f0 
1809D45A5 4d85f6                   test     r14, r14 
1809D45A8 745c                     je       0x1809d4606 
1809D45AA 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D45AE 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D45B5 488b4160                 mov      rax, qword ptr [rcx + 0x60] 
1809D45B9 8b4828                   mov      ecx, dword ptr [rax + 0x28] 
1809D45BC c1e91f                   shr      ecx, 0x1f 
1809D45BF 84c9                     test     cl, cl 
1809D45C1 7503                     jne      0x1809d45c6 
1809D45C3 488b3f                   mov      rdi, qword ptr [rdi] 
1809D45C6 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D45CA 4c8d4d20                 lea      r9, [rbp + 0x20] 
1809D45CE 4d8bc6                   mov      r8, r14 
1809D45D1 48897d20                 mov      qword ptr [rbp + 0x20], rdi 
1809D45D5 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D45DC 488d4528                 lea      rax, [rbp + 0x28] 
1809D45E0 4889442420               mov      qword ptr [rsp + 0x20], rax 
1809D45E5 4c8b5168                 mov      r10, qword ptr [rcx + 0x68] 
1809D45E9 498bd2                   mov      rdx, r10 
1809D45EC 498b0a                   mov      rcx, qword ptr [r10] 
1809D45EF 41ff5210                 call     qword ptr [r10 + 0x10] 
1809D45F3 8b4528                   mov      eax, dword ptr [rbp + 0x28] 
1809D45F6 488b5d30                 mov      rbx, qword ptr [rbp + 0x30] 
1809D45FA 488b7538                 mov      rsi, qword ptr [rbp + 0x38] 
1809D45FE 488be5                   mov      rsp, rbp 
1809D4601 415e                     pop      r14 
1809D4603 5f                       pop      rdi 
1809D4604 5d                       pop      rbp 
1809D4605 c3                       ret       
1809D4606 e845bb87ff               call     0x180250150 
1809D460B cc                       int3      
1809D460C cc                       int3      
1809D460D cc                       int3      
1809D460E cc                       int3      
1809D460F cc                       int3      
