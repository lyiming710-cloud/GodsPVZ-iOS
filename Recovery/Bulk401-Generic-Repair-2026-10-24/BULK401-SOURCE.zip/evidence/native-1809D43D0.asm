# VA 1809D43D0 END 1809D44F0 bound=next-method-pointer first-pdata-end=1809D44E3 SHA256 f0b32c9ab58892651c3095a6bc2b5d472a913025520ad6926022da64a6be0aa0
1809D43D0 48895c2408               mov      qword ptr [rsp + 8], rbx 
1809D43D5 48896c2410               mov      qword ptr [rsp + 0x10], rbp 
1809D43DA 4889742418               mov      qword ptr [rsp + 0x18], rsi 
1809D43DF 57                       push     rdi 
1809D43E0 4883ec20                 sub      rsp, 0x20 
1809D43E4 8bea                     mov      ebp, edx 
1809D43E6 498bf0                   mov      rsi, r8 
1809D43E9 33d2                     xor      edx, edx 
1809D43EB 488bf9                   mov      rdi, rcx 
1809D43EE e87ddd92ff               call     0x180302170 <StartCoro>d__4::System.IDisposable.Dispose
1809D43F3 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D43F7 4c8b88c0000000           mov      r9, qword ptr [rax + 0xc0] 
1809D43FE 498b01                   mov      rax, qword ptr [r9] 
1809D4401 f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D4408 7508                     jne      0x1809d4412 
1809D440A 488bc8                   mov      rcx, rax 
1809D440D e86e4688ff               call     0x180258a80 
1809D4412 488bc8                   mov      rcx, rax 
1809D4415 e8e6bc87ff               call     0x180250100 
1809D441A 488b4e20                 mov      rcx, qword ptr [rsi + 0x20] 
1809D441E 488bd8                   mov      rbx, rax 
1809D4421 488b91c0000000           mov      rdx, qword ptr [rcx + 0xc0] 
1809D4428 488bc8                   mov      rcx, rax 
1809D442B 4c8b4a48                 mov      r9, qword ptr [rdx + 0x48] 
1809D442F 8bd5                     mov      edx, ebp 
1809D4431 4d8bc1                   mov      r8, r9 
1809D4434 41ff11                   call     qword ptr [r9] 
1809D4437 488d4f10                 lea      rcx, [rdi + 0x10] 
1809D443B 48895f10                 mov      qword ptr [rdi + 0x10], rbx 
1809D443F 488bd3                   mov      rdx, rbx 
1809D4442 e819af87ff               call     0x18024f360 
1809D4447 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D444B 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D4452 488b4118                 mov      rax, qword ptr [rcx + 0x18] 
1809D4456 f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D445D 7508                     jne      0x1809d4467 
1809D445F 488bc8                   mov      rcx, rax 
1809D4462 e8194688ff               call     0x180258a80 
1809D4467 488bc8                   mov      rcx, rax 
1809D446A e891bc87ff               call     0x180250100 
1809D446F 488b4e20                 mov      rcx, qword ptr [rsi + 0x20] 
1809D4473 488bd8                   mov      rbx, rax 
1809D4476 488b91c0000000           mov      rdx, qword ptr [rcx + 0xc0] 
1809D447D 488bc8                   mov      rcx, rax 
1809D4480 4c8b4a50                 mov      r9, qword ptr [rdx + 0x50] 
1809D4484 8bd5                     mov      edx, ebp 
1809D4486 4d8bc1                   mov      r8, r9 
1809D4489 41ff11                   call     qword ptr [r9] 
1809D448C 488d4f18                 lea      rcx, [rdi + 0x18] 
1809D4490 48895f18                 mov      qword ptr [rdi + 0x18], rbx 
1809D4494 488bd3                   mov      rdx, rbx 
1809D4497 e8c4ae87ff               call     0x18024f360 
1809D449C 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D44A0 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D44A7 488b4128                 mov      rax, qword ptr [rcx + 0x28] 
1809D44AB 488b10                   mov      rdx, qword ptr [rax] 
1809D44AE 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D44B2 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D44B9 488b4928                 mov      rcx, qword ptr [rcx + 0x28] 
1809D44BD ffd2                     call     rdx 
1809D44BF 488d4f20                 lea      rcx, [rdi + 0x20] 
1809D44C3 48894720                 mov      qword ptr [rdi + 0x20], rax 
1809D44C7 488bd0                   mov      rdx, rax 
1809D44CA 488b5c2430               mov      rbx, qword ptr [rsp + 0x30] 
1809D44CF 488b6c2438               mov      rbp, qword ptr [rsp + 0x38] 
1809D44D4 488b742440               mov      rsi, qword ptr [rsp + 0x40] 
1809D44D9 4883c420                 add      rsp, 0x20 
1809D44DD 5f                       pop      rdi 
1809D44DE e97dae87ff               jmp      0x18024f360 
1809D44E3 cc                       int3      
1809D44E4 cc                       int3      
1809D44E5 cc                       int3      
1809D44E6 cc                       int3      
1809D44E7 cc                       int3      
1809D44E8 cc                       int3      
1809D44E9 cc                       int3      
1809D44EA cc                       int3      
1809D44EB cc                       int3      
1809D44EC cc                       int3      
1809D44ED cc                       int3      
1809D44EE cc                       int3      
1809D44EF cc                       int3      
