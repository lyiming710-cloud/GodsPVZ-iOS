# VA 1809D4890 END 1809D4980 bound=next-method-pointer first-pdata-end=1809D4901 SHA256 072ca01eb9d77d42789eafd7dba9b5781643c502d023c485fb8120421f3616e5
1809D4890 4889742410               mov      qword ptr [rsp + 0x10], rsi 
1809D4895 57                       push     rdi 
1809D4896 4883ec20                 sub      rsp, 0x20 
1809D489A 488bf2                   mov      rsi, rdx 
1809D489D 488bf9                   mov      rdi, rcx 
1809D48A0 4885d2                   test     rdx, rdx 
1809D48A3 0f84c2000000             je       0x1809d496b 
1809D48A9 488b4a10                 mov      rcx, qword ptr [rdx + 0x10] 
1809D48AD 4885c9                   test     rcx, rcx 
1809D48B0 0f84b5000000             je       0x1809d496b 
1809D48B6 8b5718                   mov      edx, dword ptr [rdi + 0x18] 
1809D48B9 395118                   cmp      dword ptr [rcx + 0x18], edx 
1809D48BC 7c3f                     jl       0x1809d48fd 
1809D48BE 3b5618                   cmp      edx, dword ptr [rsi + 0x18] 
1809D48C1 7d0f                     jge      0x1809d48d2 
1809D48C3 448b4618                 mov      r8d, dword ptr [rsi + 0x18] 
1809D48C7 4533c9                   xor      r9d, r9d 
1809D48CA 442bc2                   sub      r8d, edx 
1809D48CD e81e3e2e00               call     0x180cb86f0 
1809D48D2 837f1800                 cmp      dword ptr [rdi + 0x18], 0 
1809D48D6 7e14                     jle      0x1809d48ec 
1809D48D8 448b4718                 mov      r8d, dword ptr [rdi + 0x18] 
1809D48DC 4533c9                   xor      r9d, r9d 
1809D48DF 488b5610                 mov      rdx, qword ptr [rsi + 0x10] 
1809D48E3 488b4f10                 mov      rcx, qword ptr [rdi + 0x10] 
1809D48E7 e8a4432e00               call     0x180cb8c90 
1809D48EC 8b4718                   mov      eax, dword ptr [rdi + 0x18] 
1809D48EF 894618                   mov      dword ptr [rsi + 0x18], eax 
1809D48F2 488b742438               mov      rsi, qword ptr [rsp + 0x38] 
1809D48F7 4883c420                 add      rsp, 0x20 
1809D48FB 5f                       pop      rdi 
1809D48FC c3                       ret       
1809D48FD 498b4020                 mov      rax, qword ptr [r8 + 0x20] 
1809D4901 48895c2430               mov      qword ptr [rsp + 0x30], rbx 
1809D4906 8d1c12                   lea      ebx, [rdx + rdx] 
1809D4909 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D4910 488b4118                 mov      rax, qword ptr [rcx + 0x18] 
1809D4914 f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D491B 7508                     jne      0x1809d4925 
1809D491D 488bc8                   mov      rcx, rax 
1809D4920 e85b4188ff               call     0x180258a80 
1809D4925 8bd3                     mov      edx, ebx 
1809D4927 488bc8                   mov      rcx, rax 
1809D492A e8b1aa87ff               call     0x18024f3e0 
1809D492F 448b4718                 mov      r8d, dword ptr [rdi + 0x18] 
1809D4933 4533c9                   xor      r9d, r9d 
1809D4936 488b4f10                 mov      rcx, qword ptr [rdi + 0x10] 
1809D493A 488bd0                   mov      rdx, rax 
1809D493D 488bd8                   mov      rbx, rax 
1809D4940 e84b432e00               call     0x180cb8c90 
1809D4945 488d4e10                 lea      rcx, [rsi + 0x10] 
1809D4949 48895e10                 mov      qword ptr [rsi + 0x10], rbx 
1809D494D 488bd3                   mov      rdx, rbx 
1809D4950 e80baa87ff               call     0x18024f360 
1809D4955 8b4718                   mov      eax, dword ptr [rdi + 0x18] 
1809D4958 488b5c2430               mov      rbx, qword ptr [rsp + 0x30] 
1809D495D 894618                   mov      dword ptr [rsi + 0x18], eax 
1809D4960 488b742438               mov      rsi, qword ptr [rsp + 0x38] 
1809D4965 4883c420                 add      rsp, 0x20 
1809D4969 5f                       pop      rdi 
1809D496A c3                       ret       
1809D496B e8e0b787ff               call     0x180250150 
1809D4970 cc                       int3      
1809D4971 cc                       int3      
1809D4972 cc                       int3      
1809D4973 cc                       int3      
1809D4974 cc                       int3      
1809D4975 cc                       int3      
1809D4976 cc                       int3      
1809D4977 cc                       int3      
1809D4978 cc                       int3      
1809D4979 cc                       int3      
1809D497A cc                       int3      
1809D497B cc                       int3      
1809D497C cc                       int3      
1809D497D cc                       int3      
1809D497E cc                       int3      
1809D497F cc                       int3      
