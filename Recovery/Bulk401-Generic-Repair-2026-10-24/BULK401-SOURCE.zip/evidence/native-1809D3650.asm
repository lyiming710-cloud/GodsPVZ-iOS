# VA 1809D3650 END 1809D36C0 bound=next-method-pointer first-pdata-end=1809D36BC SHA256 54493a0cd05de93625e5eb470fc3f673b78a257f62cbd46568af3200004d7a37
1809D3650 48895c2408               mov      qword ptr [rsp + 8], rbx 
1809D3655 4889742410               mov      qword ptr [rsp + 0x10], rsi 
1809D365A 57                       push     rdi 
1809D365B 4883ec20                 sub      rsp, 0x20 
1809D365F 488b5910                 mov      rbx, qword ptr [rcx + 0x10] 
1809D3663 488bf2                   mov      rsi, rdx 
1809D3666 488bf9                   mov      rdi, rcx 
1809D3669 4885db                   test     rbx, rbx 
1809D366C 7448                     je       0x1809d36b6 
1809D366E 448b4318                 mov      r8d, dword ptr [rbx + 0x18] 
1809D3672 4533c9                   xor      r9d, r9d 
1809D3675 488b4b10                 mov      rcx, qword ptr [rbx + 0x10] 
1809D3679 33d2                     xor      edx, edx 
1809D367B e870502e00               call     0x180cb86f0 
1809D3680 c7431800000000           mov      dword ptr [rbx + 0x18], 0 
1809D3687 488b4f18                 mov      rcx, qword ptr [rdi + 0x18] 
1809D368B 4885c9                   test     rcx, rcx 
1809D368E 7426                     je       0x1809d36b6 
1809D3690 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D3694 488b90c0000000           mov      rdx, qword ptr [rax + 0xc0] 
1809D369B 488b92c0000000           mov      rdx, qword ptr [rdx + 0xc0] 
1809D36A2 488b5c2430               mov      rbx, qword ptr [rsp + 0x30] 
1809D36A7 488b742438               mov      rsi, qword ptr [rsp + 0x38] 
1809D36AC 4883c420                 add      rsp, 0x20 
1809D36B0 5f                       pop      rdi 
1809D36B1 e9eaddbaff               jmp      0x1805814a0 
1809D36B6 e895ca87ff               call     0x180250150 
1809D36BB cc                       int3      
1809D36BC cc                       int3      
1809D36BD cc                       int3      
1809D36BE cc                       int3      
1809D36BF cc                       int3      
