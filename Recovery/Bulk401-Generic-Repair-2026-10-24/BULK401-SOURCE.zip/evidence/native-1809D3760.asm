# VA 1809D3760 END 1809D3850 bound=next-method-pointer first-pdata-end=1809D384D SHA256 8d6216f9623aef66f043857f7b7690ac45a7d936c9485515cdc70726970aecce
1809D3760 4889542410               mov      qword ptr [rsp + 0x10], rdx 
1809D3765 55                       push     rbp 
1809D3766 57                       push     rdi 
1809D3767 4156                     push     r14 
1809D3769 4883ec30                 sub      rsp, 0x30 
1809D376D 488d6c2430               lea      rbp, [rsp + 0x30] 
1809D3772 498b4020                 mov      rax, qword ptr [r8 + 0x20] 
1809D3776 48895d30                 mov      qword ptr [rbp + 0x30], rbx 
1809D377A 498bd8                   mov      rbx, r8 
1809D377D 48897538                 mov      qword ptr [rbp + 0x38], rsi 
1809D3781 488bf2                   mov      rsi, rdx 
1809D3784 4c8b88c0000000           mov      r9, qword ptr [rax + 0xc0] 
1809D378B 498b4160                 mov      rax, qword ptr [r9 + 0x60] 
1809D378F 448b80fc000000           mov      r8d, dword ptr [rax + 0xfc] 
1809D3796 498d400f                 lea      rax, [r8 + 0xf] 
1809D379A 493bc0                   cmp      rax, r8 
1809D379D 770a                     ja       0x1809d37a9 
1809D379F 48b8f0ffffffffffff0f     movabs   rax, 0xffffffffffffff0 
1809D37A9 4883e0f0                 and      rax, 0xfffffffffffffff0 
1809D37AD e8ce1b8fff               call     0x1802c5380 
1809D37B2 4c8b7118                 mov      r14, qword ptr [rcx + 0x18] 
1809D37B6 488d5528                 lea      rdx, [rbp + 0x28] 
1809D37BA 482be0                   sub      rsp, rax 
1809D37BD 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D37C1 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D37C8 488d7c2430               lea      rdi, [rsp + 0x30] 
1809D37CD 488b4160                 mov      rax, qword ptr [rcx + 0x60] 
1809D37D1 8b4828                   mov      ecx, dword ptr [rax + 0x28] 
1809D37D4 c1e91f                   shr      ecx, 0x1f 
1809D37D7 84c9                     test     cl, cl 
1809D37D9 488bcf                   mov      rcx, rdi 
1809D37DC 480f45d6                 cmovne   rdx, rsi 
1809D37E0 e80b2d92ff               call     0x1802f64f0 
1809D37E5 4d85f6                   test     r14, r14 
1809D37E8 745d                     je       0x1809d3847 
1809D37EA 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D37EE 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D37F5 488b4160                 mov      rax, qword ptr [rcx + 0x60] 
1809D37F9 8b4828                   mov      ecx, dword ptr [rax + 0x28] 
1809D37FC c1e91f                   shr      ecx, 0x1f 
1809D37FF 84c9                     test     cl, cl 
1809D3801 7503                     jne      0x1809d3806 
1809D3803 488b3f                   mov      rdi, qword ptr [rdi] 
1809D3806 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D380A 4c8d4d20                 lea      r9, [rbp + 0x20] 
1809D380E 4d8bc6                   mov      r8, r14 
1809D3811 48897d20                 mov      qword ptr [rbp + 0x20], rdi 
1809D3815 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D381C 488d4528                 lea      rax, [rbp + 0x28] 
1809D3820 4889442420               mov      qword ptr [rsp + 0x20], rax 
1809D3825 4c8b5178                 mov      r10, qword ptr [rcx + 0x78] 
1809D3829 498bd2                   mov      rdx, r10 
1809D382C 498b0a                   mov      rcx, qword ptr [r10] 
1809D382F 41ff5210                 call     qword ptr [r10 + 0x10] 
1809D3833 0fb64528                 movzx    eax, byte ptr [rbp + 0x28] 
1809D3837 488b5d30                 mov      rbx, qword ptr [rbp + 0x30] 
1809D383B 488b7538                 mov      rsi, qword ptr [rbp + 0x38] 
1809D383F 488be5                   mov      rsp, rbp 
1809D3842 415e                     pop      r14 
1809D3844 5f                       pop      rdi 
1809D3845 5d                       pop      rbp 
1809D3846 c3                       ret       
1809D3847 e804c987ff               call     0x180250150 
1809D384C cc                       int3      
1809D384D cc                       int3      
1809D384E cc                       int3      
1809D384F cc                       int3      
