# VA 180490A10 END 180490B20 bound=next-method-pointer first-pdata-end=180490B20 SHA256 b7ffb0367b1546fe0ba7e7f47dcf2a77923f73eb3d2070995c14c5d00aeeb3a7
180490A10 4c89442418               mov      qword ptr [rsp + 0x18], r8 
180490A15 55                       push     rbp 
180490A16 56                       push     rsi 
180490A17 57                       push     rdi 
180490A18 4156                     push     r14 
180490A1A 4157                     push     r15 
180490A1C 4883ec60                 sub      rsp, 0x60 
180490A20 488d6c2430               lea      rbp, [rsp + 0x30] 
180490A25 4983793800               cmp      qword ptr [r9 + 0x38], 0 
180490A2A 498bf0                   mov      rsi, r8 
180490A2D 48895d60                 mov      qword ptr [rbp + 0x60], rbx 
180490A31 448bfa                   mov      r15d, edx 
180490A34 498bd9                   mov      rbx, r9 
180490A37 4c8bf1                   mov      r14, rcx 
180490A3A 7508                     jne      0x180490a44 
180490A3C 488bcb                   mov      rcx, rbx 
180490A3F e8bc80dcff               call     0x180258b00 
180490A44 488b4338                 mov      rax, qword ptr [rbx + 0x38] 
180490A48 4c8b10                   mov      r10, qword ptr [rax] 
180490A4B 458b82fc000000           mov      r8d, dword ptr [r10 + 0xfc] 
180490A52 498d400f                 lea      rax, [r8 + 0xf] 
180490A56 493bc0                   cmp      rax, r8 
180490A59 770a                     ja       0x180490a65 
180490A5B 48b8f0ffffffffffff0f     movabs   rax, 0xffffffffffffff0 
180490A65 4883e0f0                 and      rax, 0xfffffffffffffff0 
180490A69 e81249e3ff               call     0x1802c5380 
180490A6E 482be0                   sub      rsp, rax 
180490A71 488d5570                 lea      rdx, [rbp + 0x70] 
180490A75 488b4338                 mov      rax, qword ptr [rbx + 0x38] 
180490A79 488d7c2430               lea      rdi, [rsp + 0x30] 
180490A7E 488b08                   mov      rcx, qword ptr [rax] 
180490A81 8b4128                   mov      eax, dword ptr [rcx + 0x28] 
180490A84 488bcf                   mov      rcx, rdi 
180490A87 c1e81f                   shr      eax, 0x1f 
180490A8A 84c0                     test     al, al 
180490A8C 480f45d6                 cmovne   rdx, rsi 
180490A90 e85b5ae6ff               call     0x1802f64f0 
180490A95 33d2                     xor      edx, edx 
180490A97 498bce                   mov      rcx, r14 
180490A9A e811b9e9ff               call     0x18032c3b0 Map::GetMapX
180490A9F 488b4b38                 mov      rcx, qword ptr [rbx + 0x38] 
180490AA3 448d40ff                 lea      r8d, [rax - 1] 
180490AA7 488b11                   mov      rdx, qword ptr [rcx] 
180490AAA 8b4a28                   mov      ecx, dword ptr [rdx + 0x28] 
180490AAD c1e91f                   shr      ecx, 0x1f 
180490AB0 84c9                     test     cl, cl 
180490AB2 7503                     jne      0x180490ab7 
180490AB4 488b3f                   mov      rdi, qword ptr [rdi] 
180490AB7 488b4338                 mov      rax, qword ptr [rbx + 0x38] 
180490ABB 4c8d4d08                 lea      r9, [rbp + 8] 
180490ABF 44894578                 mov      dword ptr [rbp + 0x78], r8d 
180490AC3 4d8bc6                   mov      r8, r14 
180490AC6 c7457000000000           mov      dword ptr [rbp + 0x70], 0 
180490ACD 44897d68                 mov      dword ptr [rbp + 0x68], r15d 
180490AD1 4c8b5008                 mov      r10, qword ptr [rax + 8] 
180490AD5 488d4568                 lea      rax, [rbp + 0x68] 
180490AD9 48894508                 mov      qword ptr [rbp + 8], rax 
180490ADD 498bd2                   mov      rdx, r10 
180490AE0 488d4570                 lea      rax, [rbp + 0x70] 
180490AE4 48897d10                 mov      qword ptr [rbp + 0x10], rdi 
180490AE8 48894518                 mov      qword ptr [rbp + 0x18], rax 
180490AEC 488d4578                 lea      rax, [rbp + 0x78] 
180490AF0 48894520                 mov      qword ptr [rbp + 0x20], rax 
180490AF4 488b4338                 mov      rax, qword ptr [rbx + 0x38] 
180490AF8 488b4808                 mov      rcx, qword ptr [rax + 8] 
180490AFC 488d4500                 lea      rax, [rbp] 
180490B00 4889442420               mov      qword ptr [rsp + 0x20], rax 
180490B05 488b09                   mov      rcx, qword ptr [rcx] 
180490B08 41ff5210                 call     qword ptr [r10 + 0x10] 
180490B0C 488b4500                 mov      rax, qword ptr [rbp] 
180490B10 488b5d60                 mov      rbx, qword ptr [rbp + 0x60] 
180490B14 488d6530                 lea      rsp, [rbp + 0x30] 
180490B18 415f                     pop      r15 
180490B1A 415e                     pop      r14 
180490B1C 5f                       pop      rdi 
180490B1D 5e                       pop      rsi 
180490B1E 5d                       pop      rbp 
180490B1F c3                       ret       
