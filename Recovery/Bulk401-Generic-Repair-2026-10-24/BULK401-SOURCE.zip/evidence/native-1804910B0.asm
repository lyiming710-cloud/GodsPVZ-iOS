# VA 1804910B0 END 1804915D0 bound=next-method-pointer first-pdata-end=1804915D0 SHA256 367bf16e1889f641088d7ac11a2456241e79bd57293cf46071b97f118f165667
1804910B0 44894c2420               mov      dword ptr [rsp + 0x20], r9d 
1804910B5 89542410                 mov      dword ptr [rsp + 0x10], edx 
1804910B9 48894c2408               mov      qword ptr [rsp + 8], rcx 
1804910BE 53                       push     rbx 
1804910BF 56                       push     rsi 
1804910C0 57                       push     rdi 
1804910C1 4154                     push     r12 
1804910C3 4155                     push     r13 
1804910C5 4156                     push     r14 
1804910C7 4157                     push     r15 
1804910C9 4881ec90000000           sub      rsp, 0x90 
1804910D0 418bf1                   mov      esi, r9d 
1804910D3 4d8bf8                   mov      r15, r8 
1804910D6 488bf9                   mov      rdi, rcx 
1804910D9 803d703f850100           cmp      byte ptr [rip + 0x1853f70], 0 
1804910E0 0f85f7000000             jne      0x1804911dd 
1804910E6 488d0d5b9c7001           lea      rcx, [rip + 0x1709c5b] 
1804910ED e8feeddbff               call     0x18024fef0 
1804910F2 488d0d0fbe7001           lea      rcx, [rip + 0x170be0f] 
1804910F9 e8f2eddbff               call     0x18024fef0 
1804910FE 488d0d73687301           lea      rcx, [rip + 0x1736873] 
180491105 e8e6eddbff               call     0x18024fef0 
18049110A 488d0d173d7301           lea      rcx, [rip + 0x1733d17] 
180491111 e8daeddbff               call     0x18024fef0 
180491116 488d0d633d7301           lea      rcx, [rip + 0x1733d63] 
18049111D e8ceeddbff               call     0x18024fef0 
180491122 488d0da7687301           lea      rcx, [rip + 0x17368a7] 
180491129 e8c2eddbff               call     0x18024fef0 
18049112E 488d0da33d7301           lea      rcx, [rip + 0x1733da3] 
180491135 e8b6eddbff               call     0x18024fef0 
18049113A 488d0de7687301           lea      rcx, [rip + 0x17368e7] 
180491141 e8aaeddbff               call     0x18024fef0 
180491146 488d0d9b8a7001           lea      rcx, [rip + 0x1708a9b] 
18049114D e89eeddbff               call     0x18024fef0 
180491152 488d0d978b7001           lea      rcx, [rip + 0x1708b97] 
180491159 e892eddbff               call     0x18024fef0 
18049115E 488d0d7b897001           lea      rcx, [rip + 0x170897b] 
180491165 e886eddbff               call     0x18024fef0 
18049116A 488d0d878c7001           lea      rcx, [rip + 0x1708c87] 
180491171 e87aeddbff               call     0x18024fef0 
180491176 488d0d13707201           lea      rcx, [rip + 0x1727013] 
18049117D e86eeddbff               call     0x18024fef0 
180491182 488d0dafba7101           lea      rcx, [rip + 0x171baaf] 
180491189 e862eddbff               call     0x18024fef0 
18049118E 488d0d536f7201           lea      rcx, [rip + 0x1726f53] 
180491195 e856eddbff               call     0x18024fef0 
18049119A 488d0d3fba7101           lea      rcx, [rip + 0x171ba3f] 
1804911A1 e84aeddbff               call     0x18024fef0 
1804911A6 488d0d93bb7101           lea      rcx, [rip + 0x171bb93] 
1804911AD e83eeddbff               call     0x18024fef0 
1804911B2 488d0ddfbb7101           lea      rcx, [rip + 0x171bbdf] 
1804911B9 e832eddbff               call     0x18024fef0 
1804911BE 488d0d3bcc7201           lea      rcx, [rip + 0x172cc3b] 
1804911C5 e826eddbff               call     0x18024fef0 
1804911CA 488d0d47da7001           lea      rcx, [rip + 0x170da47] 
1804911D1 e81aeddbff               call     0x18024fef0 
1804911D6 c605733e850101           mov      byte ptr [rip + 0x1853e73], 1 
1804911DD 0f57c0                   xorps    xmm0, xmm0 
1804911E0 33c0                     xor      eax, eax 
1804911E2 0f11442440               movups   xmmword ptr [rsp + 0x40], xmm0 
1804911E7 4889442450               mov      qword ptr [rsp + 0x50], rax 
1804911EC 488b0d0dcc7201           mov      rcx, qword ptr [rip + 0x172cc0d] 
1804911F3 e808efdbff               call     0x180250100 
1804911F8 488bd8                   mov      rbx, rax 
1804911FB 4889442458               mov      qword ptr [rsp + 0x58], rax 
180491200 488b15d9b97101           mov      rdx, qword ptr [rip + 0x171b9d9] 
180491207 488bc8                   mov      rcx, rax 
18049120A e8c1413700               call     0x1808053d0 
18049120F 48895c2438               mov      qword ptr [rsp + 0x38], rbx 
180491214 488b0de5cb7201           mov      rcx, qword ptr [rip + 0x172cbe5] 
18049121B e8e0eedbff               call     0x180250100 
180491220 4c8be0                   mov      r12, rax 
180491223 488b15b6b97101           mov      rdx, qword ptr [rip + 0x171b9b6] 
18049122A 488bc8                   mov      rcx, rax 
18049122D e89e413700               call     0x1808053d0 
180491232 4c89642460               mov      qword ptr [rsp + 0x60], r12 
180491237 488b5710                 mov      rdx, qword ptr [rdi + 0x10] 
18049123B 4885d2                   test     rdx, rdx 
18049123E 0f8454030000             je       0x180491598 
180491244 4c8b059d6e7201           mov      r8, qword ptr [rip + 0x1726e9d] 
18049124B 488d4c2420               lea      rcx, [rsp + 0x20] 
180491250 e89b853800               call     0x1808197f0 
180491255 0f10442420               movups   xmm0, xmmword ptr [rsp + 0x20] 
18049125A 0f11442468               movups   xmmword ptr [rsp + 0x68], xmm0 
18049125F f20f104c2430             movsd    xmm1, qword ptr [rsp + 0x30] 
180491265 f20f114c2478             movsd    qword ptr [rsp + 0x78], xmm1 
18049126B 48c744242000000000       mov      qword ptr [rsp + 0x20], 0 
180491274 488d5c2468               lea      rbx, [rsp + 0x68] 
180491279 48895c2428               mov      qword ptr [rsp + 0x28], rbx 
18049127E 6690                     nop       
180491280 488b1549677301           mov      rdx, qword ptr [rip + 0x1736749] 
180491287 488d4c2468               lea      rcx, [rsp + 0x68] 
18049128C e8ef7f1d00               call     0x180669280 
180491291 84c0                     test     al, al 
180491293 0f8431010000             je       0x1804913ca 
180491299 4c8b6c2478               mov      r13, qword ptr [rsp + 0x78] 
18049129E 6690                     nop       
1804912A0 33d2                     xor      edx, edx 
1804912A2 488bcf                   mov      rcx, rdi 
1804912A5 e806b1e9ff               call     0x18032c3b0 Map::GetMapX
1804912AA 8bc8                     mov      ecx, eax 
1804912AC 8b8424f0000000           mov      eax, dword ptr [rsp + 0xf0] 
1804912B3 ffc0                     inc      eax 
1804912B5 3bc1                     cmp      eax, ecx 
1804912B7 0f4cc8                   cmovl    ecx, eax 
1804912BA 3bf1                     cmp      esi, ecx 
1804912BC 0f8dfc000000             jge      0x1804913be 
1804912C2 4d85ed                   test     r13, r13 
1804912C5 0f84e3020000             je       0x1804915ae 
1804912CB 498b4d18                 mov      rcx, qword ptr [r13 + 0x18] 
1804912CF 4885c9                   test     rcx, rcx 
1804912D2 0f84d1020000             je       0x1804915a9 
1804912D8 4c8b05b9ba7101           mov      r8, qword ptr [rip + 0x171bab9] 
1804912DF 8bd6                     mov      edx, esi 
1804912E1 e82a443900               call     0x180825710 
1804912E6 488bf8                   mov      rdi, rax 
1804912E9 4885c0                   test     rax, rax 
1804912EC 0f84b2020000             je       0x1804915a4 
1804912F2 488d481c                 lea      rcx, [rax + 0x1c] 
1804912F6 33d2                     xor      edx, edx 
1804912F8 e823258100               call     0x180ca3820 
1804912FD 4c8bf0                   mov      r14, rax 
180491300 488d4f20                 lea      rcx, [rdi + 0x20] 
180491304 33d2                     xor      edx, edx 
180491306 e815258100               call     0x180ca3820 
18049130B 4533c9                   xor      r9d, r9d 
18049130E 4c8bc0                   mov      r8, rax 
180491311 488b1500d97001           mov      rdx, qword ptr [rip + 0x170d900] 
180491318 498bce                   mov      rcx, r14 
18049131B e8302c6e00               call     0x180b73f50 
180491320 4c8bf0                   mov      r14, rax 
180491323 488b0d1e9a7001           mov      rcx, qword ptr [rip + 0x1709a1e] 
18049132A 83b9e000000000           cmp      dword ptr [rcx + 0xe0], 0 
180491331 7505                     jne      0x180491338 
180491333 e8a8eedbff               call     0x1802501e0 
180491338 33d2                     xor      edx, edx 
18049133A 498bce                   mov      rcx, r14 
18049133D e8ae55e500               call     0x1812e68f0 Debug::Log
180491342 4d85ff                   test     r15, r15 
180491345 7468                     je       0x1804913af 
180491347 4d8b07                   mov      r8, qword ptr [r15] 
18049134A 488b15b7bb7001           mov      rdx, qword ptr [rip + 0x170bbb7] 
180491351 0fb68230010000           movzx    eax, byte ptr [rdx + 0x130] 
180491358 41388030010000           cmp      byte ptr [r8 + 0x130], al 
18049135F 7215                     jb       0x180491376 
180491361 0fb6c8                   movzx    ecx, al 
180491364 498b80c8000000           mov      rax, qword ptr [r8 + 0xc8] 
18049136B 483954c8f8               cmp      qword ptr [rax + rcx*8 - 8], rdx 
180491370 7504                     jne      0x180491376 
180491372 b001                     mov      al, 1 
180491374 eb02                     jmp      0x180491378 
180491376 32c0                     xor      al, al 
180491378 33d2                     xor      edx, edx 
18049137A 84c0                     test     al, al 
18049137C 490f45d7                 cmovne   rdx, r15 
180491380 4885d2                   test     rdx, rdx 
180491383 742a                     je       0x1804913af 
180491385 4533c0                   xor      r8d, r8d 
180491388 488bcf                   mov      rcx, rdi 
18049138B e81087e9ff               call     0x180329aa0 Grid::CanPlacing
180491390 84c0                     test     al, al 
180491392 741b                     je       0x1804913af 
180491394 4d85e4                   test     r12, r12 
180491397 0f8401020000             je       0x18049159e 
18049139D 4c8b0594b87101           mov      r8, qword ptr [rip + 0x171b894] 
1804913A4 488bd7                   mov      rdx, rdi 
1804913A7 498bcc                   mov      rcx, r12 
1804913AA e8c11ab7ff               call     0x180002e70 
1804913AF ffc6                     inc      esi 
1804913B1 488bbc24d0000000         mov      rdi, qword ptr [rsp + 0xd0] 
1804913B9 e9e2feffff               jmp      0x1804912a0 
1804913BE 8bb424e8000000           mov      esi, dword ptr [rsp + 0xe8] 
1804913C5 e9b6feffff               jmp      0x180491280 
1804913CA 488b15a7657301           mov      rdx, qword ptr [rip + 0x17365a7] 
1804913D1 488bcb                   mov      rcx, rbx 
1804913D4 e8970de7ff               call     0x180302170 <StartCoro>d__4::System.IDisposable.Dispose
1804913D9 488b742458               mov      rsi, qword ptr [rsp + 0x58] 
1804913DE eb29                     jmp      0x180491409 
1804913E0 488b1591657301           mov      rdx, qword ptr [rip + 0x1736591] 
1804913E7 488b4c2428               mov      rcx, qword ptr [rsp + 0x28] 
1804913EC e87f0de7ff               call     0x180302170 <StartCoro>d__4::System.IDisposable.Dispose
1804913F1 488b4c2420               mov      rcx, qword ptr [rsp + 0x20] 
1804913F6 4885c9                   test     rcx, rcx 
1804913F9 0f85b5010000             jne      0x1804915b4 
1804913FF 488b742438               mov      rsi, qword ptr [rsp + 0x38] 
180491404 4c8b642460               mov      r12, qword ptr [rsp + 0x60] 
180491409 4d85e4                   test     r12, r12 
18049140C 0f8486010000             je       0x180491598 
180491412 418b7c2418               mov      edi, dword ptr [r12 + 0x18] 
180491417 448bb424d8000000         mov      r14d, dword ptr [rsp + 0xd8] 
18049141F 443bf7                   cmp      r14d, edi 
180491422 0f8f6b010000             jg       0x180491593 
180491428 488b0d616d7201           mov      rcx, qword ptr [rip + 0x1726d61] 
18049142F e8ccecdbff               call     0x180250100 
180491434 488bd8                   mov      rbx, rax 
180491437 488b15a2867001           mov      rdx, qword ptr [rip + 0x17086a2] 
18049143E 488bc8                   mov      rcx, rax 
180491441 e85a3d3000               call     0x1807951a0 
180491446 4885db                   test     rbx, rbx 
180491449 0f8449010000             je       0x180491598 
18049144F 90                       nop       
180491450 44397320                 cmp      dword ptr [rbx + 0x20], r14d 
180491454 7d1f                     jge      0x180491475 
180491456 4533c0                   xor      r8d, r8d 
180491459 8bd7                     mov      edx, edi 
18049145B 33c9                     xor      ecx, ecx 
18049145D e8aebee700               call     0x18130d310 Random::RandomRangeInt
180491462 4c8b057f877001           mov      r8, qword ptr [rip + 0x170877f] 
180491469 8bd0                     mov      edx, eax 
18049146B 488bcb                   mov      rcx, rbx 
18049146E e88d722f00               call     0x180788700 
180491473 ebdb                     jmp      0x180491450 
180491475 4c8b0574887001           mov      r8, qword ptr [rip + 0x1708874] 
18049147C 488bd3                   mov      rdx, rbx 
18049147F 488d4c2420               lea      rcx, [rsp + 0x20] 
180491484 e8979b2f00               call     0x18078b020 
180491489 0f10442420               movups   xmm0, xmmword ptr [rsp + 0x20] 
18049148E 0f11442440               movups   xmmword ptr [rsp + 0x40], xmm0 
180491493 f20f104c2430             movsd    xmm1, qword ptr [rsp + 0x30] 
180491499 f20f114c2450             movsd    qword ptr [rsp + 0x50], xmm1 
18049149F 48c744242000000000       mov      qword ptr [rsp + 0x20], 0 
1804914A8 488d5c2440               lea      rbx, [rsp + 0x40] 
1804914AD 48895c2428               mov      qword ptr [rsp + 0x28], rbx 
1804914B2 488b15c7397301           mov      rdx, qword ptr [rip + 0x17339c7] 
1804914B9 488d4c2440               lea      rcx, [rsp + 0x40] 
1804914BE e81d621d00               call     0x1806676e0 
1804914C3 84c0                     test     al, al 
1804914C5 0f8481000000             je       0x18049154c 
1804914CB 4c8b05c6b87101           mov      r8, qword ptr [rip + 0x171b8c6] 
1804914D2 8b542450                 mov      edx, dword ptr [rsp + 0x50] 
1804914D6 498bcc                   mov      rcx, r12 
1804914D9 e832423900               call     0x180825710 
1804914DE 488bd0                   mov      rdx, rax 
1804914E1 4885f6                   test     rsi, rsi 
1804914E4 0f84da000000             je       0x1804915c4 
1804914EA 4c8b0d47b77101           mov      r9, qword ptr [rip + 0x171b747] 
1804914F1 ff461c                   inc      dword ptr [rsi + 0x1c] 
1804914F4 488b4e10                 mov      rcx, qword ptr [rsi + 0x10] 
1804914F8 4c634618                 movsxd   r8, dword ptr [rsi + 0x18] 
1804914FC 4885c9                   test     rcx, rcx 
1804914FF 0f84ba000000             je       0x1804915bf 
180491505 443b4118                 cmp      r8d, dword ptr [rcx + 0x18] 
180491509 7219                     jb       0x180491524 
18049150B 498b4120                 mov      rax, qword ptr [r9 + 0x20] 
18049150F 4c8b80c0000000           mov      r8, qword ptr [rax + 0xc0] 
180491516 4d8b4070                 mov      r8, qword ptr [r8 + 0x70] 
18049151A 488bce                   mov      rcx, rsi 
18049151D e8be673b00               call     0x180847ce0 
180491522 eb8e                     jmp      0x1804914b2 
180491524 418d4001                 lea      eax, [r8 + 1] 
180491528 894618                   mov      dword ptr [rsi + 0x18], eax 
18049152B 443b4118                 cmp      r8d, dword ptr [rcx + 0x18] 
18049152F 0f8385000000             jae      0x1804915ba 
180491535 4a8954c120               mov      qword ptr [rcx + r8*8 + 0x20], rdx 
18049153A 4a8d0cc1                 lea      rcx, [rcx + r8*8] 
18049153E 4883c120                 add      rcx, 0x20 
180491542 e819dedbff               call     0x18024f360 
180491547 e966ffffff               jmp      0x1804914b2 
18049154C 488b15d5387301           mov      rdx, qword ptr [rip + 0x17338d5] 
180491553 488bcb                   mov      rcx, rbx 
180491556 e8150ce7ff               call     0x180302170 <StartCoro>d__4::System.IDisposable.Dispose
18049155B eb20                     jmp      0x18049157d 
18049155D 488b15c4387301           mov      rdx, qword ptr [rip + 0x17338c4] 
180491564 488b4c2428               mov      rcx, qword ptr [rsp + 0x28] 
180491569 e8020ce7ff               call     0x180302170 <StartCoro>d__4::System.IDisposable.Dispose
18049156E 488b4c2420               mov      rcx, qword ptr [rsp + 0x20] 
180491573 4885c9                   test     rcx, rcx 
180491576 7552                     jne      0x1804915ca 
180491578 488b742438               mov      rsi, qword ptr [rsp + 0x38] 
18049157D 488bc6                   mov      rax, rsi 
180491580 4881c490000000           add      rsp, 0x90 
180491587 415f                     pop      r15 
180491589 415e                     pop      r14 
18049158B 415d                     pop      r13 
18049158D 415c                     pop      r12 
18049158F 5f                       pop      rdi 
180491590 5e                       pop      rsi 
180491591 5b                       pop      rbx 
180491592 c3                       ret       
180491593 498bc4                   mov      rax, r12 
180491596 ebe8                     jmp      0x180491580 
180491598 e8b3ebdbff               call     0x180250150 
18049159D 90                       nop       
18049159E e8adebdbff               call     0x180250150 
1804915A3 90                       nop       
1804915A4 e8a7ebdbff               call     0x180250150 
1804915A9 e8a2ebdbff               call     0x180250150 
1804915AE e89debdbff               call     0x180250150 
1804915B3 90                       nop       
1804915B4 e8a7f8d6ff               call     0x180200e60 
1804915B9 90                       nop       
1804915BA e881ebdbff               call     0x180250140 
1804915BF e88cebdbff               call     0x180250150 
1804915C4 e887ebdbff               call     0x180250150 
1804915C9 90                       nop       
1804915CA e891f8d6ff               call     0x180200e60 
1804915CF cc                       int3      
