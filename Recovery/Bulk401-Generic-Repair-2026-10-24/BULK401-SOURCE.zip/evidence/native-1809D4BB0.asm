# VA 1809D4BB0 END 1809D4CC0 bound=next-method-pointer first-pdata-end=1809D4CBF SHA256 ba3ef8e10ee233539fab18421eece8a9b5d31116f650a4e991faca9d78a89273
1809D4BB0 4055                     push     rbp 
1809D4BB2 4883ec20                 sub      rsp, 0x20 
1809D4BB6 488d6c2420               lea      rbp, [rsp + 0x20] 
1809D4BBB 498b4020                 mov      rax, qword ptr [r8 + 0x20] 
1809D4BBF 48895d10                 mov      qword ptr [rbp + 0x10], rbx 
1809D4BC3 48897518                 mov      qword ptr [rbp + 0x18], rsi 
1809D4BC7 498bf0                   mov      rsi, r8 
1809D4BCA 48897d20                 mov      qword ptr [rbp + 0x20], rdi 
1809D4BCE 4c8b88c0000000           mov      r9, qword ptr [rax + 0xc0] 
1809D4BD5 4c897528                 mov      qword ptr [rbp + 0x28], r14 
1809D4BD9 4c8bf2                   mov      r14, rdx 
1809D4BDC 498b4120                 mov      rax, qword ptr [r9 + 0x20] 
1809D4BE0 8bb8fc000000             mov      edi, dword ptr [rax + 0xfc] 
1809D4BE6 4c8d4f0f                 lea      r9, [rdi + 0xf] 
1809D4BEA 4c3bcf                   cmp      r9, rdi 
1809D4BED 770a                     ja       0x1809d4bf9 
1809D4BEF 49b9f0ffffffffffff0f     movabs   r9, 0xffffffffffffff0 
1809D4BF9 4983e1f0                 and      r9, 0xfffffffffffffff0 
1809D4BFD 498bc1                   mov      rax, r9 
1809D4C00 e87b078fff               call     0x1802c5380 
1809D4C05 492be1                   sub      rsp, r9 
1809D4C08 83791800                 cmp      dword ptr [rcx + 0x18], 0 
1809D4C0C 488d5c2420               lea      rbx, [rsp + 0x20] 
1809D4C11 7463                     je       0x1809d4c76 
1809D4C13 488b5110                 mov      rdx, qword ptr [rcx + 0x10] 
1809D4C17 4885d2                   test     rdx, rdx 
1809D4C1A 0f8499000000             je       0x1809d4cb9 
1809D4C20 448b4918                 mov      r9d, dword ptr [rcx + 0x18] 
1809D4C24 41ffc9                   dec      r9d 
1809D4C27 443b4a18                 cmp      r9d, dword ptr [rdx + 0x18] 
1809D4C2B 0f8382000000             jae      0x1809d4cb3 
1809D4C31 488b02                   mov      rax, qword ptr [rdx] 
1809D4C34 4c8bc7                   mov      r8, rdi 
1809D4C37 4883c220                 add      rdx, 0x20 
1809D4C3B 8b8804010000             mov      ecx, dword ptr [rax + 0x104] 
1809D4C41 4963c1                   movsxd   rax, r9d 
1809D4C44 480fafc8                 imul     rcx, rax 
1809D4C48 4803d1                   add      rdx, rcx 
1809D4C4B 488bcb                   mov      rcx, rbx 
1809D4C4E e89d1892ff               call     0x1802f64f0 
1809D4C53 4c8bc7                   mov      r8, rdi 
1809D4C56 488bd3                   mov      rdx, rbx 
1809D4C59 498bce                   mov      rcx, r14 
1809D4C5C e88f1892ff               call     0x1802f64f0 
1809D4C61 488b5d10                 mov      rbx, qword ptr [rbp + 0x10] 
1809D4C65 488b7518                 mov      rsi, qword ptr [rbp + 0x18] 
1809D4C69 488b7d20                 mov      rdi, qword ptr [rbp + 0x20] 
1809D4C6D 4c8b7528                 mov      r14, qword ptr [rbp + 0x28] 
1809D4C71 488be5                   mov      rsp, rbp 
1809D4C74 5d                       pop      rbp 
1809D4C75 c3                       ret       
1809D4C76 488d0dc3511d01           lea      rcx, [rip + 0x11d51c3] 
1809D4C7D e88eb287ff               call     0x18024ff10 
1809D4C82 488bc8                   mov      rcx, rax 
1809D4C85 e876b487ff               call     0x180250100 
1809D4C8A 488d0d47dd1d01           lea      rcx, [rip + 0x11ddd47] 
1809D4C91 488bd8                   mov      rbx, rax 
1809D4C94 e877b287ff               call     0x18024ff10 
1809D4C99 488bd0                   mov      rdx, rax 
1809D4C9C 4533c0                   xor      r8d, r8d 
1809D4C9F 488bcb                   mov      rcx, rbx 
1809D4CA2 e869ff2c00               call     0x180ca4c10 
1809D4CA7 488bd6                   mov      rdx, rsi 
1809D4CAA 488bcb                   mov      rcx, rbx 
1809D4CAD e85eb487ff               call     0x180250110 
1809D4CB2 cc                       int3      
1809D4CB3 e888b487ff               call     0x180250140 
1809D4CB8 cc                       int3      
1809D4CB9 e892b487ff               call     0x180250150 
1809D4CBE cc                       int3      
1809D4CBF cc                       int3      
