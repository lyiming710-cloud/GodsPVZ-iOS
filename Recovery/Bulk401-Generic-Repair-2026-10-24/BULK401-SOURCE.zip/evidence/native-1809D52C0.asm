# VA 1809D52C0 END 1809D53A0 bound=next-method-pointer first-pdata-end=1809D5397 SHA256 49fd2fc1f0e84cb347fa6fc5eae765c937066f3dfac0b9a8f4802407b6bf4909
1809D52C0 48895c2408               mov      qword ptr [rsp + 8], rbx 
1809D52C5 57                       push     rdi 
1809D52C6 4883ec20                 sub      rsp, 0x20 
1809D52CA 498bf8                   mov      rdi, r8 
1809D52CD 488bd9                   mov      rbx, rcx 
1809D52D0 3b5118                   cmp      edx, dword ptr [rcx + 0x18] 
1809D52D3 0f8385000000             jae      0x1809d535e 
1809D52D9 488b4110                 mov      rax, qword ptr [rcx + 0x10] 
1809D52DD 4885c0                   test     rax, rax 
1809D52E0 0f84ab000000             je       0x1809d5391 
1809D52E6 48634918                 movsxd   rcx, dword ptr [rcx + 0x18] 
1809D52EA 48ffc9                   dec      rcx 
1809D52ED 3b4818                   cmp      ecx, dword ptr [rax + 0x18] 
1809D52F0 0f8395000000             jae      0x1809d538b 
1809D52F6 488b7cc820               mov      rdi, qword ptr [rax + rcx*8 + 0x20] 
1809D52FB 4863ca                   movsxd   rcx, edx 
1809D52FE 3b5018                   cmp      edx, dword ptr [rax + 0x18] 
1809D5301 0f8384000000             jae      0x1809d538b 
1809D5307 48897cc820               mov      qword ptr [rax + rcx*8 + 0x20], rdi 
1809D530C 488bd7                   mov      rdx, rdi 
1809D530F 4883c020                 add      rax, 0x20 
1809D5313 488d0cc8                 lea      rcx, [rax + rcx*8] 
1809D5317 e844a087ff               call     0x18024f360 
1809D531C 48634318                 movsxd   rax, dword ptr [rbx + 0x18] 
1809D5320 488b5310                 mov      rdx, qword ptr [rbx + 0x10] 
1809D5324 8d48ff                   lea      ecx, [rax - 1] 
1809D5327 894b18                   mov      dword ptr [rbx + 0x18], ecx 
1809D532A 4885d2                   test     rdx, rdx 
1809D532D 7462                     je       0x1809d5391 
1809D532F 488d48ff                 lea      rcx, [rax - 1] 
1809D5333 3b4a18                   cmp      ecx, dword ptr [rdx + 0x18] 
1809D5336 7353                     jae      0x1809d538b 
1809D5338 48c744ca2000000000       mov      qword ptr [rdx + rcx*8 + 0x20], 0 
1809D5341 4883c220                 add      rdx, 0x20 
1809D5345 488d0cca                 lea      rcx, [rdx + rcx*8] 
1809D5349 33d2                     xor      edx, edx 
1809D534B e810a087ff               call     0x18024f360 
1809D5350 488b5c2430               mov      rbx, qword ptr [rsp + 0x30] 
1809D5355 488bc7                   mov      rax, rdi 
1809D5358 4883c420                 add      rsp, 0x20 
1809D535C 5f                       pop      rdi 
1809D535D c3                       ret       
1809D535E 488d0d5b3a1d01           lea      rcx, [rip + 0x11d3a5b] 
1809D5365 e8a6ab87ff               call     0x18024ff10 
1809D536A 488bc8                   mov      rcx, rax 
1809D536D e88ead87ff               call     0x180250100 
1809D5372 33d2                     xor      edx, edx 
1809D5374 488bc8                   mov      rcx, rax 
1809D5377 488bd8                   mov      rbx, rax 
1809D537A e821cd2c00               call     0x180ca20a0 
1809D537F 488bd7                   mov      rdx, rdi 
1809D5382 488bcb                   mov      rcx, rbx 
1809D5385 e886ad87ff               call     0x180250110 
1809D538A cc                       int3      
1809D538B e8b0ad87ff               call     0x180250140 
1809D5390 cc                       int3      
1809D5391 e8baad87ff               call     0x180250150 
1809D5396 cc                       int3      
1809D5397 cc                       int3      
1809D5398 cc                       int3      
1809D5399 cc                       int3      
1809D539A cc                       int3      
1809D539B cc                       int3      
1809D539C cc                       int3      
1809D539D cc                       int3      
1809D539E cc                       int3      
1809D539F cc                       int3      
