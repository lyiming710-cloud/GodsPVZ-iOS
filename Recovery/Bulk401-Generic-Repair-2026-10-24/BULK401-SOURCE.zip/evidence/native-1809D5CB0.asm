# VA 1809D5CB0 END 1809D5D30 bound=next-method-pointer first-pdata-end=1809D5CF0 SHA256 22e80a64f6537a7c318306572a69d95481e8a75c33327e97ea556bbee569b158
1809D5CB0 4057                     push     rdi 
1809D5CB2 4883ec20                 sub      rsp, 0x20 
1809D5CB6 498bf9                   mov      rdi, r9 
1809D5CB9 3b5118                   cmp      edx, dword ptr [rcx + 0x18] 
1809D5CBC 732b                     jae      0x1809d5ce9 
1809D5CBE 488b4110                 mov      rax, qword ptr [rcx + 0x10] 
1809D5CC2 4885c0                   test     rax, rax 
1809D5CC5 745e                     je       0x1809d5d25 
1809D5CC7 4863ca                   movsxd   rcx, edx 
1809D5CCA 3b5018                   cmp      edx, dword ptr [rax + 0x18] 
1809D5CCD 7350                     jae      0x1809d5d1f 
1809D5CCF 4c8944c820               mov      qword ptr [rax + rcx*8 + 0x20], r8 
1809D5CD4 498bd0                   mov      rdx, r8 
1809D5CD7 4883c020                 add      rax, 0x20 
1809D5CDB 488d0cc8                 lea      rcx, [rax + rcx*8] 
1809D5CDF 4883c420                 add      rsp, 0x20 
1809D5CE3 5f                       pop      rdi 
1809D5CE4 e9779687ff               jmp      0x18024f360 
1809D5CE9 488d0dd0301d01           lea      rcx, [rip + 0x11d30d0] 
1809D5CF0 48895c2430               mov      qword ptr [rsp + 0x30], rbx 
1809D5CF5 e816a287ff               call     0x18024ff10 
1809D5CFA 488bc8                   mov      rcx, rax 
1809D5CFD e8fea387ff               call     0x180250100 
1809D5D02 33d2                     xor      edx, edx 
1809D5D04 488bc8                   mov      rcx, rax 
1809D5D07 488bd8                   mov      rbx, rax 
1809D5D0A e891c32c00               call     0x180ca20a0 
1809D5D0F 488bd7                   mov      rdx, rdi 
1809D5D12 488bcb                   mov      rcx, rbx 
1809D5D15 e8f6a387ff               call     0x180250110 
1809D5D1A 488b5c2430               mov      rbx, qword ptr [rsp + 0x30] 
1809D5D1F e81ca487ff               call     0x180250140 
1809D5D24 cc                       int3      
1809D5D25 e826a487ff               call     0x180250150 
1809D5D2A cc                       int3      
1809D5D2B cc                       int3      
1809D5D2C cc                       int3      
1809D5D2D cc                       int3      
1809D5D2E cc                       int3      
1809D5D2F cc                       int3      
