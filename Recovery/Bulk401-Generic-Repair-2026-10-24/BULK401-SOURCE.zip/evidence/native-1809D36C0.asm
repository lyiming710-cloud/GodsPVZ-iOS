# VA 1809D36C0 END 1809D3730 bound=next-method-pointer first-pdata-end=1809D3721 SHA256 3440b285142622c4d36f84915f3d12ea02eaf4befadb1aee94bb733fc28a4717
1809D36C0 48895c2408               mov      qword ptr [rsp + 8], rbx 
1809D36C5 57                       push     rdi 
1809D36C6 4883ec20                 sub      rsp, 0x20 
1809D36CA 488bd9                   mov      rbx, rcx 
1809D36CD 488bfa                   mov      rdi, rdx 
1809D36D0 488b4910                 mov      rcx, qword ptr [rcx + 0x10] 
1809D36D4 4885c9                   test     rcx, rcx 
1809D36D7 7442                     je       0x1809d371b 
1809D36D9 488b4220                 mov      rax, qword ptr [rdx + 0x20] 
1809D36DD 4c8b80c0000000           mov      r8, qword ptr [rax + 0xc0] 
1809D36E4 498b80b8000000           mov      rax, qword ptr [r8 + 0xb8] 
1809D36EB 488bd0                   mov      rdx, rax 
1809D36EE ff10                     call     qword ptr [rax] 
1809D36F0 488b4b18                 mov      rcx, qword ptr [rbx + 0x18] 
1809D36F4 4885c9                   test     rcx, rcx 
1809D36F7 7422                     je       0x1809d371b 
1809D36F9 488b4720                 mov      rax, qword ptr [rdi + 0x20] 
1809D36FD 488b90c0000000           mov      rdx, qword ptr [rax + 0xc0] 
1809D3704 488b82c0000000           mov      rax, qword ptr [rdx + 0xc0] 
1809D370B 488bd0                   mov      rdx, rax 
1809D370E 488b5c2430               mov      rbx, qword ptr [rsp + 0x30] 
1809D3713 4883c420                 add      rsp, 0x20 
1809D3717 5f                       pop      rdi 
1809D3718 48ff20                   jmp      qword ptr [rax] 
1809D371B e830ca87ff               call     0x180250150 
1809D3720 cc                       int3      
1809D3721 cc                       int3      
1809D3722 cc                       int3      
1809D3723 cc                       int3      
1809D3724 cc                       int3      
1809D3725 cc                       int3      
1809D3726 cc                       int3      
1809D3727 cc                       int3      
1809D3728 cc                       int3      
1809D3729 cc                       int3      
1809D372A cc                       int3      
1809D372B cc                       int3      
1809D372C cc                       int3      
1809D372D cc                       int3      
1809D372E cc                       int3      
1809D372F cc                       int3      
