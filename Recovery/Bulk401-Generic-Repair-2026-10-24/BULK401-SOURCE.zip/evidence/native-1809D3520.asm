# VA 1809D3520 END 1809D3550 bound=next-method-pointer first-pdata-end=1809D354E SHA256 4d9bc4e6416d17c34197077cb32760ed45881d1ce808ae1311a66cc9302c50fb
1809D3520 4883ec28                 sub      rsp, 0x28 
1809D3524 488b4910                 mov      rcx, qword ptr [rcx + 0x10] 
1809D3528 4885c9                   test     rcx, rcx 
1809D352B 741b                     je       0x1809d3548 
1809D352D 498b4020                 mov      rax, qword ptr [r8 + 0x20] 
1809D3531 4c8b80c0000000           mov      r8, qword ptr [rax + 0xc0] 
1809D3538 4d8b80d0000000           mov      r8, qword ptr [r8 + 0xd0] 
1809D353F 4883c428                 add      rsp, 0x28 
1809D3543 e9c8110000               jmp      0x1809d4710 SwfList`1::AssignTo
1809D3548 e803cc87ff               call     0x180250150 
1809D354D cc                       int3      
1809D354E cc                       int3      
1809D354F cc                       int3      
