# VA 180805210 END 1808052E0 bound=next-method-pointer first-pdata-end=1808052E0 SHA256 9f2105667df143df57d16ab53d562445773f9caf0923a5ca6d69736800193dd7
180805210 48895c2408               mov      qword ptr [rsp + 8], rbx 
180805215 57                       push     rdi 
180805216 4883ec20                 sub      rsp, 0x20 
18080521A 488b4120                 mov      rax, qword ptr [rcx + 0x20] 
18080521E 488bd9                   mov      rbx, rcx 
180805221 f6803501000001           test     byte ptr [rax + 0x135], 1 
180805228 7508                     jne      0x180805232 
18080522A 488bc8                   mov      rcx, rax 
18080522D e84e38a5ff               call     0x180258a80 
180805232 488b80c0000000           mov      rax, qword ptr [rax + 0xc0] 
180805239 488b4018                 mov      rax, qword ptr [rax + 0x18] 
18080523D f6803501000001           test     byte ptr [rax + 0x135], 1 
180805244 7508                     jne      0x18080524e 
180805246 488bc8                   mov      rcx, rax 
180805249 e83238a5ff               call     0x180258a80 
18080524E 33d2                     xor      edx, edx 
180805250 488bc8                   mov      rcx, rax 
180805253 e888a1a4ff               call     0x18024f3e0 
180805258 488bf8                   mov      rdi, rax 
18080525B 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
18080525F f6803501000001           test     byte ptr [rax + 0x135], 1 
180805266 7508                     jne      0x180805270 
180805268 488bc8                   mov      rcx, rax 
18080526B e81038a5ff               call     0x180258a80 
180805270 488b80c0000000           mov      rax, qword ptr [rax + 0xc0] 
180805277 488b4010                 mov      rax, qword ptr [rax + 0x10] 
18080527B f6803501000001           test     byte ptr [rax + 0x135], 1 
180805282 7508                     jne      0x18080528c 
180805284 488bc8                   mov      rcx, rax 
180805287 e8f437a5ff               call     0x180258a80 
18080528C 488b80b8000000           mov      rax, qword ptr [rax + 0xb8] 
180805293 488938                   mov      qword ptr [rax], rdi 
180805296 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
18080529A f6803501000001           test     byte ptr [rax + 0x135], 1 
1808052A1 7508                     jne      0x1808052ab 
1808052A3 488bc8                   mov      rcx, rax 
1808052A6 e8d537a5ff               call     0x180258a80 
1808052AB 488b80c0000000           mov      rax, qword ptr [rax + 0xc0] 
1808052B2 488b4010                 mov      rax, qword ptr [rax + 0x10] 
1808052B6 f6803501000001           test     byte ptr [rax + 0x135], 1 
1808052BD 7508                     jne      0x1808052c7 
1808052BF 488bc8                   mov      rcx, rax 
1808052C2 e8b937a5ff               call     0x180258a80 
1808052C7 488b88b8000000           mov      rcx, qword ptr [rax + 0xb8] 
1808052CE 488bd7                   mov      rdx, rdi 
1808052D1 488b5c2430               mov      rbx, qword ptr [rsp + 0x30] 
1808052D6 4883c420                 add      rsp, 0x20 
1808052DA 5f                       pop      rdi 
1808052DB e980a0a4ff               jmp      0x18024f360 
