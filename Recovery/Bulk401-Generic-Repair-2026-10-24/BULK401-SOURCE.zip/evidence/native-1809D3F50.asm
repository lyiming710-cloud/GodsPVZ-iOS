# VA 1809D3F50 END 1809D40C0 bound=next-method-pointer first-pdata-end=1809D40BD SHA256 f21d96d8e699e0425fcd6a04d6cb1c7ce92af2f996a159e303e3594c97a4602a
1809D3F50 48895c2408               mov      qword ptr [rsp + 8], rbx 
1809D3F55 48896c2410               mov      qword ptr [rsp + 0x10], rbp 
1809D3F5A 4889742418               mov      qword ptr [rsp + 0x18], rsi 
1809D3F5F 57                       push     rdi 
1809D3F60 4883ec20                 sub      rsp, 0x20 
1809D3F64 488bf2                   mov      rsi, rdx 
1809D3F67 488bf9                   mov      rdi, rcx 
1809D3F6A 33d2                     xor      edx, edx 
1809D3F6C e8ffe192ff               call     0x180302170 <StartCoro>d__4::System.IDisposable.Dispose
1809D3F71 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D3F75 4c8b80c0000000           mov      r8, qword ptr [rax + 0xc0] 
1809D3F7C 498b00                   mov      rax, qword ptr [r8] 
1809D3F7F f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D3F86 7508                     jne      0x1809d3f90 
1809D3F88 488bc8                   mov      rcx, rax 
1809D3F8B e8f04a88ff               call     0x180258a80 
1809D3F90 488bc8                   mov      rcx, rax 
1809D3F93 e868c187ff               call     0x180250100 
1809D3F98 488b4e20                 mov      rcx, qword ptr [rsi + 0x20] 
1809D3F9C 488bd8                   mov      rbx, rax 
1809D3F9F 488b91c0000000           mov      rdx, qword ptr [rcx + 0xc0] 
1809D3FA6 488bc8                   mov      rcx, rax 
1809D3FA9 488b6a08                 mov      rbp, qword ptr [rdx + 8] 
1809D3FAD 33d2                     xor      edx, edx 
1809D3FAF e8bce192ff               call     0x180302170 <StartCoro>d__4::System.IDisposable.Dispose
1809D3FB4 488b4d20                 mov      rcx, qword ptr [rbp + 0x20] 
1809D3FB8 488b91c0000000           mov      rdx, qword ptr [rcx + 0xc0] 
1809D3FBF 488b4210                 mov      rax, qword ptr [rdx + 0x10] 
1809D3FC3 f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D3FCA 7508                     jne      0x1809d3fd4 
1809D3FCC 488bc8                   mov      rcx, rax 
1809D3FCF e8ac4a88ff               call     0x180258a80 
1809D3FD4 83b8e000000000           cmp      dword ptr [rax + 0xe0], 0 
1809D3FDB 7508                     jne      0x1809d3fe5 
1809D3FDD 488bc8                   mov      rcx, rax 
1809D3FE0 e8fbc187ff               call     0x1802501e0 
1809D3FE5 488b4520                 mov      rax, qword ptr [rbp + 0x20] 
1809D3FE9 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D3FF0 488b4110                 mov      rax, qword ptr [rcx + 0x10] 
1809D3FF4 f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D3FFB 7508                     jne      0x1809d4005 
1809D3FFD 488bc8                   mov      rcx, rax 
1809D4000 e87b4a88ff               call     0x180258a80 
1809D4005 488b80b8000000           mov      rax, qword ptr [rax + 0xb8] 
1809D400C 488d4b10                 lea      rcx, [rbx + 0x10] 
1809D4010 488b10                   mov      rdx, qword ptr [rax] 
1809D4013 48895310                 mov      qword ptr [rbx + 0x10], rdx 
1809D4017 e844b387ff               call     0x18024f360 
1809D401C c7431800000000           mov      dword ptr [rbx + 0x18], 0 
1809D4023 488d4f10                 lea      rcx, [rdi + 0x10] 
1809D4027 488bd3                   mov      rdx, rbx 
1809D402A 48895f10                 mov      qword ptr [rdi + 0x10], rbx 
1809D402E e82db387ff               call     0x18024f360 
1809D4033 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D4037 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D403E 488b4118                 mov      rax, qword ptr [rcx + 0x18] 
1809D4042 f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D4049 7508                     jne      0x1809d4053 
1809D404B 488bc8                   mov      rcx, rax 
1809D404E e82d4a88ff               call     0x180258a80 
1809D4053 488bc8                   mov      rcx, rax 
1809D4056 e8a5c087ff               call     0x180250100 
1809D405B 488b4e20                 mov      rcx, qword ptr [rsi + 0x20] 
1809D405F 488bd8                   mov      rbx, rax 
1809D4062 488b91c0000000           mov      rdx, qword ptr [rcx + 0xc0] 
1809D4069 488bc8                   mov      rcx, rax 
1809D406C 488b5220                 mov      rdx, qword ptr [rdx + 0x20] 
1809D4070 e80b42c1ff               call     0x1805e8280 
1809D4075 488d4f18                 lea      rcx, [rdi + 0x18] 
1809D4079 48895f18                 mov      qword ptr [rdi + 0x18], rbx 
1809D407D 488bd3                   mov      rdx, rbx 
1809D4080 e8dbb287ff               call     0x18024f360 
1809D4085 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D4089 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D4090 488b4928                 mov      rcx, qword ptr [rcx + 0x28] 
1809D4094 e8472563ff               call     0x1800065e0 
1809D4099 488d4f20                 lea      rcx, [rdi + 0x20] 
1809D409D 48894720                 mov      qword ptr [rdi + 0x20], rax 
1809D40A1 488bd0                   mov      rdx, rax 
1809D40A4 488b5c2430               mov      rbx, qword ptr [rsp + 0x30] 
1809D40A9 488b6c2438               mov      rbp, qword ptr [rsp + 0x38] 
1809D40AE 488b742440               mov      rsi, qword ptr [rsp + 0x40] 
1809D40B3 4883c420                 add      rsp, 0x20 
1809D40B7 5f                       pop      rdi 
1809D40B8 e9a3b287ff               jmp      0x18024f360 
1809D40BD cc                       int3      
1809D40BE cc                       int3      
1809D40BF cc                       int3      
