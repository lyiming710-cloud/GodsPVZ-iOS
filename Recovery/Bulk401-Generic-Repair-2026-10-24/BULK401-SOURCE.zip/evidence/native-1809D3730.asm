# VA 1809D3730 END 1809D3760 bound=next-method-pointer first-pdata-end=1809D375B SHA256 d54212551ff1f868c1558c55fb85b9cdc7013460695dea95276e00f487592daa
1809D3730 4883ec28                 sub      rsp, 0x28 
1809D3734 488b4918                 mov      rcx, qword ptr [rcx + 0x18] 
1809D3738 4885c9                   test     rcx, rcx 
1809D373B 7418                     je       0x1809d3755 
1809D373D 498b4020                 mov      rax, qword ptr [r8 + 0x20] 
1809D3741 4c8b80c0000000           mov      r8, qword ptr [rax + 0xc0] 
1809D3748 4d8b4078                 mov      r8, qword ptr [r8 + 0x78] 
1809D374C 4883c428                 add      rsp, 0x28 
1809D3750 e93b4ac0ff               jmp      0x1805d8190 
1809D3755 e8f6c987ff               call     0x180250150 
1809D375A cc                       int3      
1809D375B cc                       int3      
1809D375C cc                       int3      
1809D375D cc                       int3      
1809D375E cc                       int3      
1809D375F cc                       int3      
