# VA 1809D3850 END 1809D3A90 bound=next-method-pointer first-pdata-end=1809D3A8A SHA256 a1fdc5e9b21c010e1526499d7fad47f659c7732382dc6c09aac5928ad2a76897
1809D3850 48895c2410               mov      qword ptr [rsp + 0x10], rbx 
1809D3855 48896c2418               mov      qword ptr [rsp + 0x18], rbp 
1809D385A 4889742420               mov      qword ptr [rsp + 0x20], rsi 
1809D385F 57                       push     rdi 
1809D3860 4156                     push     r14 
1809D3862 4157                     push     r15 
1809D3864 4883ec20                 sub      rsp, 0x20 
1809D3868 33db                     xor      ebx, ebx 
1809D386A 488bf1                   mov      rsi, rcx 
1809D386D 488b4918                 mov      rcx, qword ptr [rcx + 0x18] 
1809D3871 4d8bf0                   mov      r14, r8 
1809D3874 895c2440                 mov      dword ptr [rsp + 0x40], ebx 
1809D3878 4c8bfa                   mov      r15, rdx 
1809D387B 4885c9                   test     rcx, rcx 
1809D387E 0f84cd010000             je       0x1809d3a51 
1809D3884 498b4020                 mov      rax, qword ptr [r8 + 0x20] 
1809D3888 4c8d442440               lea      r8, [rsp + 0x40] 
1809D388D 4c8b88c0000000           mov      r9, qword ptr [rax + 0xc0] 
1809D3894 4d8b8990000000           mov      r9, qword ptr [r9 + 0x90] 
1809D389B e8c026c1ff               call     0x1805e5f60 
1809D38A0 84c0                     test     al, al 
1809D38A2 0f8476010000             je       0x1809d3a1e 
1809D38A8 488b4e18                 mov      rcx, qword ptr [rsi + 0x18] 
1809D38AC 4885c9                   test     rcx, rcx 
1809D38AF 0f849c010000             je       0x1809d3a51 
1809D38B5 498b4620                 mov      rax, qword ptr [r14 + 0x20] 
1809D38B9 498bd7                   mov      rdx, r15 
1809D38BC 4c8b80c0000000           mov      r8, qword ptr [rax + 0xc0] 
1809D38C3 4d8b8098000000           mov      r8, qword ptr [r8 + 0x98] 
1809D38CA e891b0c0ff               call     0x1805de960 
1809D38CF 488b7e10                 mov      rdi, qword ptr [rsi + 0x10] 
1809D38D3 4885ff                   test     rdi, rdi 
1809D38D6 0f8475010000             je       0x1809d3a51 
1809D38DC 498b4620                 mov      rax, qword ptr [r14 + 0x20] 
1809D38E0 4863542440               movsxd   rdx, dword ptr [rsp + 0x40] 
1809D38E5 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D38EC 488ba9a0000000           mov      rbp, qword ptr [rcx + 0xa0] 
1809D38F3 3b5718                   cmp      edx, dword ptr [rdi + 0x18] 
1809D38F6 0f8361010000             jae      0x1809d3a5d 
1809D38FC 488b4710                 mov      rax, qword ptr [rdi + 0x10] 
1809D3900 4885c0                   test     rax, rax 
1809D3903 0f8448010000             je       0x1809d3a51 
1809D3909 48634f18                 movsxd   rcx, dword ptr [rdi + 0x18] 
1809D390D 48ffc9                   dec      rcx 
1809D3910 3b4818                   cmp      ecx, dword ptr [rax + 0x18] 
1809D3913 0f833e010000             jae      0x1809d3a57 
1809D3919 488b6cc820               mov      rbp, qword ptr [rax + rcx*8 + 0x20] 
1809D391E 488bca                   mov      rcx, rdx 
1809D3921 3b5018                   cmp      edx, dword ptr [rax + 0x18] 
1809D3924 0f832d010000             jae      0x1809d3a57 
1809D392A 4883c104                 add      rcx, 4 
1809D392E 48896cd020               mov      qword ptr [rax + rdx*8 + 0x20], rbp 
1809D3933 488bd5                   mov      rdx, rbp 
1809D3936 488d0cc8                 lea      rcx, [rax + rcx*8] 
1809D393A e821ba87ff               call     0x18024f360 
1809D393F 48635718                 movsxd   rdx, dword ptr [rdi + 0x18] 
1809D3943 488b4f10                 mov      rcx, qword ptr [rdi + 0x10] 
1809D3947 8d42ff                   lea      eax, [rdx - 1] 
1809D394A 894718                   mov      dword ptr [rdi + 0x18], eax 
1809D394D 4885c9                   test     rcx, rcx 
1809D3950 0f84fb000000             je       0x1809d3a51 
1809D3956 488d42ff                 lea      rax, [rdx - 1] 
1809D395A 3b4118                   cmp      eax, dword ptr [rcx + 0x18] 
1809D395D 0f83f4000000             jae      0x1809d3a57 
1809D3963 48895cc120               mov      qword ptr [rcx + rax*8 + 0x20], rbx 
1809D3968 33d2                     xor      edx, edx 
1809D396A 488d0cc1                 lea      rcx, [rcx + rax*8] 
1809D396E 4883c120                 add      rcx, 0x20 
1809D3972 e8e9b987ff               call     0x18024f360 
1809D3977 488b7e20                 mov      rdi, qword ptr [rsi + 0x20] 
1809D397B 4885ff                   test     rdi, rdi 
1809D397E 0f84cd000000             je       0x1809d3a51 
1809D3984 498b4620                 mov      rax, qword ptr [r14 + 0x20] 
1809D3988 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D398F 488b5140                 mov      rdx, qword ptr [rcx + 0x40] 
1809D3993 f6823501000001           test     byte ptr [rdx + 0x135], 1 
1809D399A 750b                     jne      0x1809d39a7 
1809D399C 488bca                   mov      rcx, rdx 
1809D399F e8dc5088ff               call     0x180258a80 
1809D39A4 488bd0                   mov      rdx, rax 
1809D39A7 4c8b0f                   mov      r9, qword ptr [rdi] 
1809D39AA 410fb7892e010000         movzx    ecx, word ptr [r9 + 0x12e] 
1809D39B2 663bd9                   cmp      bx, cx 
1809D39B5 731d                     jae      0x1809d39d4 
1809D39B7 4d8b81b0000000           mov      r8, qword ptr [r9 + 0xb0] 
1809D39BE 6690                     nop       
1809D39C0 0fb7c3                   movzx    eax, bx 
1809D39C3 4803c0                   add      rax, rax 
1809D39C6 493914c0                 cmp      qword ptr [r8 + rax*8], rdx 
1809D39CA 746b                     je       0x1809d3a37 
1809D39CC 66ffc3                   inc      bx 
1809D39CF 663bd9                   cmp      bx, cx 
1809D39D2 72ec                     jb       0x1809d39c0 
1809D39D4 4533c0                   xor      r8d, r8d 
1809D39D7 488bcf                   mov      rcx, rdi 
1809D39DA e8a14988ff               call     0x180258380 
1809D39DF 4c8b10                   mov      r10, qword ptr [rax] 
1809D39E2 4d8bc7                   mov      r8, r15 
1809D39E5 4c8b4808                 mov      r9, qword ptr [rax + 8] 
1809D39E9 488bd5                   mov      rdx, rbp 
1809D39EC 488bcf                   mov      rcx, rdi 
1809D39EF 41ffd2                   call     r10 
1809D39F2 84c0                     test     al, al 
1809D39F4 7528                     jne      0x1809d3a1e 
1809D39F6 488b4e18                 mov      rcx, qword ptr [rsi + 0x18] 
1809D39FA 4885c9                   test     rcx, rcx 
1809D39FD 7452                     je       0x1809d3a51 
1809D39FF 498b4620                 mov      rax, qword ptr [r14 + 0x20] 
1809D3A03 488bd5                   mov      rdx, rbp 
1809D3A06 448b442440               mov      r8d, dword ptr [rsp + 0x40] 
1809D3A0B 4c8b88c0000000           mov      r9, qword ptr [rax + 0xc0] 
1809D3A12 4d8b89b0000000           mov      r9, qword ptr [r9 + 0xb0] 
1809D3A19 e84270c1ff               call     0x1805eaa60 
1809D3A1E 488b5c2448               mov      rbx, qword ptr [rsp + 0x48] 
1809D3A23 488b6c2450               mov      rbp, qword ptr [rsp + 0x50] 
1809D3A28 488b742458               mov      rsi, qword ptr [rsp + 0x58] 
1809D3A2D 4883c420                 add      rsp, 0x20 
1809D3A31 415f                     pop      r15 
1809D3A33 415e                     pop      r14 
1809D3A35 5f                       pop      rdi 
1809D3A36 c3                       ret       
1809D3A37 0fb7cb                   movzx    ecx, bx 
1809D3A3A 4803c9                   add      rcx, rcx 
1809D3A3D 496344c808               movsxd   rax, dword ptr [r8 + rcx*8 + 8] 
1809D3A42 48c1e004                 shl      rax, 4 
1809D3A46 480538010000             add      rax, 0x138 
1809D3A4C 4903c1                   add      rax, r9 
1809D3A4F eb8e                     jmp      0x1809d39df 
1809D3A51 e8fac687ff               call     0x180250150 
1809D3A56 cc                       int3      
1809D3A57 e8e4c687ff               call     0x180250140 
1809D3A5C cc                       int3      
1809D3A5D 488d0d5c531d01           lea      rcx, [rip + 0x11d535c] 
1809D3A64 e8a7c487ff               call     0x18024ff10 
1809D3A69 488bc8                   mov      rcx, rax 
1809D3A6C e88fc687ff               call     0x180250100 
1809D3A71 33d2                     xor      edx, edx 
1809D3A73 488bc8                   mov      rcx, rax 
1809D3A76 488bd8                   mov      rbx, rax 
1809D3A79 e822e62c00               call     0x180ca20a0 
1809D3A7E 488bd5                   mov      rdx, rbp 
1809D3A81 488bcb                   mov      rcx, rbx 
1809D3A84 e887c687ff               call     0x180250110 
1809D3A89 cc                       int3      
1809D3A8A cc                       int3      
1809D3A8B cc                       int3      
1809D3A8C cc                       int3      
1809D3A8D cc                       int3      
1809D3A8E cc                       int3      
1809D3A8F cc                       int3      
