# VA 1809D46E0 END 1809D4710 bound=next-method-pointer first-pdata-end=1809D470B SHA256 1568ba791d5cfbd7e247423565d4da9648f552447cfed4d37f047d0aeb000a55
1809D46E0 4883ec28                 sub      rsp, 0x28 
1809D46E4 488b4910                 mov      rcx, qword ptr [rcx + 0x10] 
1809D46E8 4885c9                   test     rcx, rcx 
1809D46EB 7418                     je       0x1809d4705 
1809D46ED 498b4020                 mov      rax, qword ptr [r8 + 0x20] 
1809D46F1 4c8b80c0000000           mov      r8, qword ptr [rax + 0xc0] 
1809D46F8 4d8b4058                 mov      r8, qword ptr [r8 + 0x58] 
1809D46FC 4883c428                 add      rsp, 0x28 
1809D4700 e97b026eff               jmp      0x1800b4980 
1809D4705 e846ba87ff               call     0x180250150 
1809D470A cc                       int3      
1809D470B cc                       int3      
1809D470C cc                       int3      
1809D470D cc                       int3      
1809D470E cc                       int3      
1809D470F cc                       int3      
