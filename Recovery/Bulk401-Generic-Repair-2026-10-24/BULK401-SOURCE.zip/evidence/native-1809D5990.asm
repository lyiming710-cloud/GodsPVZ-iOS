# VA 1809D5990 END 1809D5A00 bound=next-method-pointer first-pdata-end=1809D59C1 SHA256 54bc1bf275e1338b213bdcfcef56b707e5030815ac0ad6986fc639a7e45d8e65
1809D5990 4057                     push     rdi 
1809D5992 4883ec20                 sub      rsp, 0x20 
1809D5996 498bf8                   mov      rdi, r8 
1809D5999 3b5118                   cmp      edx, dword ptr [rcx + 0x18] 
1809D599C 731c                     jae      0x1809d59ba 
1809D599E 488b4910                 mov      rcx, qword ptr [rcx + 0x10] 
1809D59A2 4885c9                   test     rcx, rcx 
1809D59A5 744f                     je       0x1809d59f6 
1809D59A7 3b5118                   cmp      edx, dword ptr [rcx + 0x18] 
1809D59AA 7344                     jae      0x1809d59f0 
1809D59AC 4863c2                   movsxd   rax, edx 
1809D59AF 488b44c120               mov      rax, qword ptr [rcx + rax*8 + 0x20] 
1809D59B4 4883c420                 add      rsp, 0x20 
1809D59B8 5f                       pop      rdi 
1809D59B9 c3                       ret       
1809D59BA 488d0dff331d01           lea      rcx, [rip + 0x11d33ff] 
1809D59C1 48895c2430               mov      qword ptr [rsp + 0x30], rbx 
1809D59C6 e845a587ff               call     0x18024ff10 
1809D59CB 488bc8                   mov      rcx, rax 
1809D59CE e82da787ff               call     0x180250100 
1809D59D3 33d2                     xor      edx, edx 
1809D59D5 488bc8                   mov      rcx, rax 
1809D59D8 488bd8                   mov      rbx, rax 
1809D59DB e8c0c62c00               call     0x180ca20a0 
1809D59E0 488bd7                   mov      rdx, rdi 
1809D59E3 488bcb                   mov      rcx, rbx 
1809D59E6 e825a787ff               call     0x180250110 
1809D59EB 488b5c2430               mov      rbx, qword ptr [rsp + 0x30] 
1809D59F0 e84ba787ff               call     0x180250140 
1809D59F5 cc                       int3      
1809D59F6 e855a787ff               call     0x180250150 
1809D59FB cc                       int3      
1809D59FC cc                       int3      
1809D59FD cc                       int3      
1809D59FE cc                       int3      
1809D59FF cc                       int3      
