# VA 1809D58A0 END 1809D5990 bound=next-method-pointer first-pdata-end=1809D598F SHA256 342df9580f43a10b27faf874e22c30870ad2a28234c9a952e11fc0c4c9ca1bbb
1809D58A0 4055                     push     rbp 
1809D58A2 4156                     push     r14 
1809D58A4 4157                     push     r15 
1809D58A6 4883ec20                 sub      rsp, 0x20 
1809D58AA 488d6c2420               lea      rbp, [rsp + 0x20] 
1809D58AF 498b4120                 mov      rax, qword ptr [r9 + 0x20] 
1809D58B3 4d8bf8                   mov      r15, r8 
1809D58B6 48895d20                 mov      qword ptr [rbp + 0x20], rbx 
1809D58BA 48897528                 mov      qword ptr [rbp + 0x28], rsi 
1809D58BE 498bf1                   mov      rsi, r9 
1809D58C1 48897d30                 mov      qword ptr [rbp + 0x30], rdi 
1809D58C5 4c8b90c0000000           mov      r10, qword ptr [rax + 0xc0] 
1809D58CC 4863da                   movsxd   rbx, edx 
1809D58CF 498b4220                 mov      rax, qword ptr [r10 + 0x20] 
1809D58D3 448bb0fc000000           mov      r14d, dword ptr [rax + 0xfc] 
1809D58DA 4d8d560f                 lea      r10, [r14 + 0xf] 
1809D58DE 4d3bd6                   cmp      r10, r14 
1809D58E1 770a                     ja       0x1809d58ed 
1809D58E3 49baf0ffffffffffff0f     movabs   r10, 0xffffffffffffff0 
1809D58ED 4983e2f0                 and      r10, 0xfffffffffffffff0 
1809D58F1 498bc2                   mov      rax, r10 
1809D58F4 e887fa8eff               call     0x1802c5380 
1809D58F9 482be0                   sub      rsp, rax 
1809D58FC 488d7c2420               lea      rdi, [rsp + 0x20] 
1809D5901 3b5918                   cmp      ebx, dword ptr [rcx + 0x18] 
1809D5904 7350                     jae      0x1809d5956 
1809D5906 488b5110                 mov      rdx, qword ptr [rcx + 0x10] 
1809D590A 4885d2                   test     rdx, rdx 
1809D590D 747a                     je       0x1809d5989 
1809D590F 3b5a18                   cmp      ebx, dword ptr [rdx + 0x18] 
1809D5912 736f                     jae      0x1809d5983 
1809D5914 488b02                   mov      rax, qword ptr [rdx] 
1809D5917 4d8bc6                   mov      r8, r14 
1809D591A 4883c220                 add      rdx, 0x20 
1809D591E 8b8804010000             mov      ecx, dword ptr [rax + 0x104] 
1809D5924 480fafcb                 imul     rcx, rbx 
1809D5928 4803d1                   add      rdx, rcx 
1809D592B 488bcf                   mov      rcx, rdi 
1809D592E e8bd0b92ff               call     0x1802f64f0 
1809D5933 4d8bc6                   mov      r8, r14 
1809D5936 488bd7                   mov      rdx, rdi 
1809D5939 498bcf                   mov      rcx, r15 
1809D593C e8af0b92ff               call     0x1802f64f0 
1809D5941 488b5d20                 mov      rbx, qword ptr [rbp + 0x20] 
1809D5945 488b7528                 mov      rsi, qword ptr [rbp + 0x28] 
1809D5949 488b7d30                 mov      rdi, qword ptr [rbp + 0x30] 
1809D594D 488be5                   mov      rsp, rbp 
1809D5950 415f                     pop      r15 
1809D5952 415e                     pop      r14 
1809D5954 5d                       pop      rbp 
1809D5955 c3                       ret       
1809D5956 488d0d63341d01           lea      rcx, [rip + 0x11d3463] 
1809D595D e8aea587ff               call     0x18024ff10 
1809D5962 488bc8                   mov      rcx, rax 
1809D5965 e896a787ff               call     0x180250100 
1809D596A 33d2                     xor      edx, edx 
1809D596C 488bc8                   mov      rcx, rax 
1809D596F 488bd8                   mov      rbx, rax 
1809D5972 e829c72c00               call     0x180ca20a0 
1809D5977 488bd6                   mov      rdx, rsi 
1809D597A 488bcb                   mov      rcx, rbx 
1809D597D e88ea787ff               call     0x180250110 
1809D5982 cc                       int3      
1809D5983 e8b8a787ff               call     0x180250140 
1809D5988 cc                       int3      
1809D5989 e8c2a787ff               call     0x180250150 
1809D598E cc                       int3      
1809D598F cc                       int3      
