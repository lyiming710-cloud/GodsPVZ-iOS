# VA 1809D4D50 END 1809D4E10 bound=next-method-pointer first-pdata-end=1809D4E08 SHA256 353b82be19a1d245372f3a97ce8042e2cca9aa3642abc988bbae054cf842ce77
1809D4D50 48895c2408               mov      qword ptr [rsp + 8], rbx 
1809D4D55 57                       push     rdi 
1809D4D56 4883ec20                 sub      rsp, 0x20 
1809D4D5A 83791800                 cmp      dword ptr [rcx + 0x18], 0 
1809D4D5E 488bfa                   mov      rdi, rdx 
1809D4D61 745c                     je       0x1809d4dbf 
1809D4D63 4c634118                 movsxd   r8, dword ptr [rcx + 0x18] 
1809D4D67 488b5110                 mov      rdx, qword ptr [rcx + 0x10] 
1809D4D6B 458d48ff                 lea      r9d, [r8 - 1] 
1809D4D6F 44894918                 mov      dword ptr [rcx + 0x18], r9d 
1809D4D73 4885d2                   test     rdx, rdx 
1809D4D76 0f8486000000             je       0x1809d4e02 
1809D4D7C 498d40ff                 lea      rax, [r8 - 1] 
1809D4D80 3b4218                   cmp      eax, dword ptr [rdx + 0x18] 
1809D4D83 7377                     jae      0x1809d4dfc 
1809D4D85 488b5cc220               mov      rbx, qword ptr [rdx + rax*8 + 0x20] 
1809D4D8A 4885d2                   test     rdx, rdx 
1809D4D8D 7473                     je       0x1809d4e02 
1809D4D8F 498d48ff                 lea      rcx, [r8 - 1] 
1809D4D93 443b4a18                 cmp      r9d, dword ptr [rdx + 0x18] 
1809D4D97 7363                     jae      0x1809d4dfc 
1809D4D99 48c744ca2000000000       mov      qword ptr [rdx + rcx*8 + 0x20], 0 
1809D4DA2 4883c220                 add      rdx, 0x20 
1809D4DA6 488d0cca                 lea      rcx, [rdx + rcx*8] 
1809D4DAA 33d2                     xor      edx, edx 
1809D4DAC e8afa587ff               call     0x18024f360 
1809D4DB1 488bc3                   mov      rax, rbx 
1809D4DB4 488b5c2430               mov      rbx, qword ptr [rsp + 0x30] 
1809D4DB9 4883c420                 add      rsp, 0x20 
1809D4DBD 5f                       pop      rdi 
1809D4DBE c3                       ret       
1809D4DBF 488d0d7a501d01           lea      rcx, [rip + 0x11d507a] 
1809D4DC6 e845b187ff               call     0x18024ff10 
1809D4DCB 488bc8                   mov      rcx, rax 
1809D4DCE e82db387ff               call     0x180250100 
1809D4DD3 488d0dfedb1d01           lea      rcx, [rip + 0x11ddbfe] 
1809D4DDA 488bd8                   mov      rbx, rax 
1809D4DDD e82eb187ff               call     0x18024ff10 
1809D4DE2 488bd0                   mov      rdx, rax 
1809D4DE5 4533c0                   xor      r8d, r8d 
1809D4DE8 488bcb                   mov      rcx, rbx 
1809D4DEB e820fe2c00               call     0x180ca4c10 
1809D4DF0 488bd7                   mov      rdx, rdi 
1809D4DF3 488bcb                   mov      rcx, rbx 
1809D4DF6 e815b387ff               call     0x180250110 
1809D4DFB cc                       int3      
1809D4DFC e83fb387ff               call     0x180250140 
1809D4E01 cc                       int3      
1809D4E02 e849b387ff               call     0x180250150 
1809D4E07 cc                       int3      
1809D4E08 cc                       int3      
1809D4E09 cc                       int3      
1809D4E0A cc                       int3      
1809D4E0B cc                       int3      
1809D4E0C cc                       int3      
1809D4E0D cc                       int3      
1809D4E0E cc                       int3      
1809D4E0F cc                       int3      
