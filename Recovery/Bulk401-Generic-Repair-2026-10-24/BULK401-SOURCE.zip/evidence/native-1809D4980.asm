# VA 1809D4980 END 1809D4B80 bound=next-method-pointer first-pdata-end=1809D4B75 SHA256 82d52f274e4b488d9bce81886fdc80d18f71eff42cf12f3e4503dbb73be9ee1a
1809D4980 4055                     push     rbp 
1809D4982 57                       push     rdi 
1809D4983 4154                     push     r12 
1809D4985 4156                     push     r14 
1809D4987 4157                     push     r15 
1809D4989 4883ec40                 sub      rsp, 0x40 
1809D498D 488d6c2430               lea      rbp, [rsp + 0x30] 
1809D4992 498b4020                 mov      rax, qword ptr [r8 + 0x20] 
1809D4996 4c8bf2                   mov      r14, rdx 
1809D4999 48895d40                 mov      qword ptr [rbp + 0x40], rbx 
1809D499D 4c8bf9                   mov      r15, rcx 
1809D49A0 498bd8                   mov      rbx, r8 
1809D49A3 48897550                 mov      qword ptr [rbp + 0x50], rsi 
1809D49A7 4c8b80c0000000           mov      r8, qword ptr [rax + 0xc0] 
1809D49AE 498b4020                 mov      rax, qword ptr [r8 + 0x20] 
1809D49B2 448b80fc000000           mov      r8d, dword ptr [rax + 0xfc] 
1809D49B9 498d400f                 lea      rax, [r8 + 0xf] 
1809D49BD 493bc0                   cmp      rax, r8 
1809D49C0 770a                     ja       0x1809d49cc 
1809D49C2 48b8f0ffffffffffff0f     movabs   rax, 0xffffffffffffff0 
1809D49CC 4883e0f0                 and      rax, 0xfffffffffffffff0 
1809D49D0 e8ab098fff               call     0x1802c5380 
1809D49D5 482be0                   sub      rsp, rax 
1809D49D8 488d742430               lea      rsi, [rsp + 0x30] 
1809D49DD 4d85f6                   test     r14, r14 
1809D49E0 0f8489010000             je       0x1809d4b6f 
1809D49E6 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D49EA 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D49F1 488b4130                 mov      rax, qword ptr [rcx + 0x30] 
1809D49F5 498bce                   mov      rcx, r14 
1809D49F8 488bd0                   mov      rdx, rax 
1809D49FB ff10                     call     qword ptr [rax] 
1809D49FD 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D4A01 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D4A08 488b4138                 mov      rax, qword ptr [rcx + 0x38] 
1809D4A0C 4c8b00                   mov      r8, qword ptr [rax] 
1809D4A0F 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D4A13 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D4A1A 488b5138                 mov      rdx, qword ptr [rcx + 0x38] 
1809D4A1E 498bce                   mov      rcx, r14 
1809D4A21 41ffd0                   call     r8 
1809D4A24 488b4b20                 mov      rcx, qword ptr [rbx + 0x20] 
1809D4A28 8bf8                     mov      edi, eax 
1809D4A2A 488b91c0000000           mov      rdx, qword ptr [rcx + 0xc0] 
1809D4A31 488b4a40                 mov      rcx, qword ptr [rdx + 0x40] 
1809D4A35 4c8b01                   mov      r8, qword ptr [rcx] 
1809D4A38 488b4b20                 mov      rcx, qword ptr [rbx + 0x20] 
1809D4A3C 488b91c0000000           mov      rdx, qword ptr [rcx + 0xc0] 
1809D4A43 498bcf                   mov      rcx, r15 
1809D4A46 488b5240                 mov      rdx, qword ptr [rdx + 0x40] 
1809D4A4A 41ffd0                   call     r8 
1809D4A4D 3bf8                     cmp      edi, eax 
1809D4A4F 7d42                     jge      0x1809d4a93 
1809D4A51 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D4A55 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D4A5C 488b4140                 mov      rax, qword ptr [rcx + 0x40] 
1809D4A60 4c8b00                   mov      r8, qword ptr [rax] 
1809D4A63 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D4A67 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D4A6E 488b5140                 mov      rdx, qword ptr [rcx + 0x40] 
1809D4A72 498bcf                   mov      rcx, r15 
1809D4A75 41ffd0                   call     r8 
1809D4A78 488b4b20                 mov      rcx, qword ptr [rbx + 0x20] 
1809D4A7C 488b91c0000000           mov      rdx, qword ptr [rcx + 0xc0] 
1809D4A83 498bce                   mov      rcx, r14 
1809D4A86 4c8b4a48                 mov      r9, qword ptr [rdx + 0x48] 
1809D4A8A 8d1400                   lea      edx, [rax + rax] 
1809D4A8D 4d8bc1                   mov      r8, r9 
1809D4A90 41ff11                   call     qword ptr [r9] 
1809D4A93 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D4A97 33ff                     xor      edi, edi 
1809D4A99 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D4AA0 488b4140                 mov      rax, qword ptr [rcx + 0x40] 
1809D4AA4 4c8b00                   mov      r8, qword ptr [rax] 
1809D4AA7 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D4AAB 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D4AB2 488b5140                 mov      rdx, qword ptr [rcx + 0x40] 
1809D4AB6 498bcf                   mov      rcx, r15 
1809D4AB9 41ffd0                   call     r8 
1809D4ABC 448be0                   mov      r12d, eax 
1809D4ABF 85c0                     test     eax, eax 
1809D4AC1 0f8e93000000             jle      0x1809d4b5a 
1809D4AC7 660f1f840000000000       nop      word ptr [rax + rax] 
1809D4AD0 488b4b20                 mov      rcx, qword ptr [rbx + 0x20] 
1809D4AD4 488d4548                 lea      rax, [rbp + 0x48] 
1809D4AD8 4c8d4d00                 lea      r9, [rbp] 
1809D4ADC 897d48                   mov      dword ptr [rbp + 0x48], edi 
1809D4ADF 4d8bc7                   mov      r8, r15 
1809D4AE2 48894500                 mov      qword ptr [rbp], rax 
1809D4AE6 48897508                 mov      qword ptr [rbp + 8], rsi 
1809D4AEA 488b91c0000000           mov      rdx, qword ptr [rcx + 0xc0] 
1809D4AF1 4889742420               mov      qword ptr [rsp + 0x20], rsi 
1809D4AF6 4c8b5250                 mov      r10, qword ptr [rdx + 0x50] 
1809D4AFA 498bca                   mov      rcx, r10 
1809D4AFD 498bd2                   mov      rdx, r10 
1809D4B00 488b09                   mov      rcx, qword ptr [rcx] 
1809D4B03 41ff5210                 call     qword ptr [r10 + 0x10] 
1809D4B07 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D4B0B 488bd6                   mov      rdx, rsi 
1809D4B0E 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D4B15 488b4120                 mov      rax, qword ptr [rcx + 0x20] 
1809D4B19 8b4828                   mov      ecx, dword ptr [rax + 0x28] 
1809D4B1C c1e91f                   shr      ecx, 0x1f 
1809D4B1F 84c9                     test     cl, cl 
1809D4B21 7503                     jne      0x1809d4b26 
1809D4B23 488b16                   mov      rdx, qword ptr [rsi] 
1809D4B26 488b4320                 mov      rax, qword ptr [rbx + 0x20] 
1809D4B2A 4c8d4d48                 lea      r9, [rbp + 0x48] 
1809D4B2E 48895548                 mov      qword ptr [rbp + 0x48], rdx 
1809D4B32 4d8bc6                   mov      r8, r14 
1809D4B35 4889542420               mov      qword ptr [rsp + 0x20], rdx 
1809D4B3A 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D4B41 4c8b5158                 mov      r10, qword ptr [rcx + 0x58] 
1809D4B45 498bd2                   mov      rdx, r10 
1809D4B48 498b0a                   mov      rcx, qword ptr [r10] 
1809D4B4B 41ff5210                 call     qword ptr [r10 + 0x10] 
1809D4B4F ffc7                     inc      edi 
1809D4B51 413bfc                   cmp      edi, r12d 
1809D4B54 0f8c76ffffff             jl       0x1809d4ad0 
1809D4B5A 488b5d40                 mov      rbx, qword ptr [rbp + 0x40] 
1809D4B5E 488b7550                 mov      rsi, qword ptr [rbp + 0x50] 
1809D4B62 488d6510                 lea      rsp, [rbp + 0x10] 
1809D4B66 415f                     pop      r15 
1809D4B68 415e                     pop      r14 
1809D4B6A 415c                     pop      r12 
1809D4B6C 5f                       pop      rdi 
1809D4B6D 5d                       pop      rbp 
1809D4B6E c3                       ret       
1809D4B6F e8dcb587ff               call     0x180250150 
1809D4B74 cc                       int3      
1809D4B75 cc                       int3      
1809D4B76 cc                       int3      
1809D4B77 cc                       int3      
1809D4B78 cc                       int3      
1809D4B79 cc                       int3      
1809D4B7A cc                       int3      
1809D4B7B cc                       int3      
1809D4B7C cc                       int3      
1809D4B7D cc                       int3      
1809D4B7E cc                       int3      
1809D4B7F cc                       int3      
