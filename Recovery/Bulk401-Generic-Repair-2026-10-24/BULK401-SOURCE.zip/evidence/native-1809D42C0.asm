# VA 1809D42C0 END 1809D43D0 bound=next-method-pointer first-pdata-end=1809D43C3 SHA256 7ad819ec62d74963cf5556805ad101d0cc18f1e07aaf1c3bbb88f1375f0f2c2d
1809D42C0 48895c2408               mov      qword ptr [rsp + 8], rbx 
1809D42C5 4889742410               mov      qword ptr [rsp + 0x10], rsi 
1809D42CA 57                       push     rdi 
1809D42CB 4883ec20                 sub      rsp, 0x20 
1809D42CF 488bf2                   mov      rsi, rdx 
1809D42D2 488bf9                   mov      rdi, rcx 
1809D42D5 33d2                     xor      edx, edx 
1809D42D7 e894de92ff               call     0x180302170 <StartCoro>d__4::System.IDisposable.Dispose
1809D42DC 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D42E0 4c8b80c0000000           mov      r8, qword ptr [rax + 0xc0] 
1809D42E7 498b00                   mov      rax, qword ptr [r8] 
1809D42EA f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D42F1 7508                     jne      0x1809d42fb 
1809D42F3 488bc8                   mov      rcx, rax 
1809D42F6 e8854788ff               call     0x180258a80 
1809D42FB 488bc8                   mov      rcx, rax 
1809D42FE e8fdbd87ff               call     0x180250100 
1809D4303 488b4e20                 mov      rcx, qword ptr [rsi + 0x20] 
1809D4307 488bd8                   mov      rbx, rax 
1809D430A 488b91c0000000           mov      rdx, qword ptr [rcx + 0xc0] 
1809D4311 488bc8                   mov      rcx, rax 
1809D4314 4c8b4208                 mov      r8, qword ptr [rdx + 8] 
1809D4318 498bd0                   mov      rdx, r8 
1809D431B 41ff10                   call     qword ptr [r8] 
1809D431E 488d4f10                 lea      rcx, [rdi + 0x10] 
1809D4322 48895f10                 mov      qword ptr [rdi + 0x10], rbx 
1809D4326 488bd3                   mov      rdx, rbx 
1809D4329 e832b087ff               call     0x18024f360 
1809D432E 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D4332 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D4339 488b4118                 mov      rax, qword ptr [rcx + 0x18] 
1809D433D f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D4344 7508                     jne      0x1809d434e 
1809D4346 488bc8                   mov      rcx, rax 
1809D4349 e8324788ff               call     0x180258a80 
1809D434E 488bc8                   mov      rcx, rax 
1809D4351 e8aabd87ff               call     0x180250100 
1809D4356 488b4e20                 mov      rcx, qword ptr [rsi + 0x20] 
1809D435A 488bd8                   mov      rbx, rax 
1809D435D 488b91c0000000           mov      rdx, qword ptr [rcx + 0xc0] 
1809D4364 488bc8                   mov      rcx, rax 
1809D4367 4c8b4220                 mov      r8, qword ptr [rdx + 0x20] 
1809D436B 498bd0                   mov      rdx, r8 
1809D436E 41ff10                   call     qword ptr [r8] 
1809D4371 488d4f18                 lea      rcx, [rdi + 0x18] 
1809D4375 48895f18                 mov      qword ptr [rdi + 0x18], rbx 
1809D4379 488bd3                   mov      rdx, rbx 
1809D437C e8dfaf87ff               call     0x18024f360 
1809D4381 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D4385 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D438C 488b4128                 mov      rax, qword ptr [rcx + 0x28] 
1809D4390 488b10                   mov      rdx, qword ptr [rax] 
1809D4393 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D4397 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D439E 488b4928                 mov      rcx, qword ptr [rcx + 0x28] 
1809D43A2 ffd2                     call     rdx 
1809D43A4 488d4f20                 lea      rcx, [rdi + 0x20] 
1809D43A8 48894720                 mov      qword ptr [rdi + 0x20], rax 
1809D43AC 488bd0                   mov      rdx, rax 
1809D43AF 488b5c2430               mov      rbx, qword ptr [rsp + 0x30] 
1809D43B4 488b742438               mov      rsi, qword ptr [rsp + 0x38] 
1809D43B9 4883c420                 add      rsp, 0x20 
1809D43BD 5f                       pop      rdi 
1809D43BE e99daf87ff               jmp      0x18024f360 
1809D43C3 cc                       int3      
1809D43C4 cc                       int3      
1809D43C5 cc                       int3      
1809D43C6 cc                       int3      
1809D43C7 cc                       int3      
1809D43C8 cc                       int3      
1809D43C9 cc                       int3      
1809D43CA cc                       int3      
1809D43CB cc                       int3      
1809D43CC cc                       int3      
1809D43CD cc                       int3      
1809D43CE cc                       int3      
1809D43CF cc                       int3      
