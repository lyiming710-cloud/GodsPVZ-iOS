# VA 1809D3550 END 1809D3650 bound=next-method-pointer first-pdata-end=1809D35DD SHA256 d5ddc373c3df00770765bc392fb749d58318826cde61a7ff0c24a5c89545fba0
1809D3550 4889742410               mov      qword ptr [rsp + 0x10], rsi 
1809D3555 57                       push     rdi 
1809D3556 4883ec20                 sub      rsp, 0x20 
1809D355A 488b7910                 mov      rdi, qword ptr [rcx + 0x10] 
1809D355E 488bf2                   mov      rsi, rdx 
1809D3561 4885ff                   test     rdi, rdi 
1809D3564 0f84dd000000             je       0x1809d3647 
1809D356A 498b4020                 mov      rax, qword ptr [r8 + 0x20] 
1809D356E 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D3575 4c8b81d8000000           mov      r8, qword ptr [rcx + 0xd8] 
1809D357C 4885d2                   test     rdx, rdx 
1809D357F 0f84c2000000             je       0x1809d3647 
1809D3585 488b4a10                 mov      rcx, qword ptr [rdx + 0x10] 
1809D3589 4885c9                   test     rcx, rcx 
1809D358C 0f84b5000000             je       0x1809d3647 
1809D3592 8b5718                   mov      edx, dword ptr [rdi + 0x18] 
1809D3595 395118                   cmp      dword ptr [rcx + 0x18], edx 
1809D3598 7c3f                     jl       0x1809d35d9 
1809D359A 3b5618                   cmp      edx, dword ptr [rsi + 0x18] 
1809D359D 7d0f                     jge      0x1809d35ae 
1809D359F 448b4618                 mov      r8d, dword ptr [rsi + 0x18] 
1809D35A3 4533c9                   xor      r9d, r9d 
1809D35A6 442bc2                   sub      r8d, edx 
1809D35A9 e842512e00               call     0x180cb86f0 
1809D35AE 837f1800                 cmp      dword ptr [rdi + 0x18], 0 
1809D35B2 7e14                     jle      0x1809d35c8 
1809D35B4 448b4718                 mov      r8d, dword ptr [rdi + 0x18] 
1809D35B8 4533c9                   xor      r9d, r9d 
1809D35BB 488b5610                 mov      rdx, qword ptr [rsi + 0x10] 
1809D35BF 488b4f10                 mov      rcx, qword ptr [rdi + 0x10] 
1809D35C3 e8c8562e00               call     0x180cb8c90 
1809D35C8 8b4718                   mov      eax, dword ptr [rdi + 0x18] 
1809D35CB 894618                   mov      dword ptr [rsi + 0x18], eax 
1809D35CE 488b742438               mov      rsi, qword ptr [rsp + 0x38] 
1809D35D3 4883c420                 add      rsp, 0x20 
1809D35D7 5f                       pop      rdi 
1809D35D8 c3                       ret       
1809D35D9 498b4020                 mov      rax, qword ptr [r8 + 0x20] 
1809D35DD 48895c2430               mov      qword ptr [rsp + 0x30], rbx 
1809D35E2 8d1c12                   lea      ebx, [rdx + rdx] 
1809D35E5 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D35EC 488b4118                 mov      rax, qword ptr [rcx + 0x18] 
1809D35F0 f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D35F7 7508                     jne      0x1809d3601 
1809D35F9 488bc8                   mov      rcx, rax 
1809D35FC e87f5488ff               call     0x180258a80 
1809D3601 8bd3                     mov      edx, ebx 
1809D3603 488bc8                   mov      rcx, rax 
1809D3606 e8d5bd87ff               call     0x18024f3e0 
1809D360B 448b4718                 mov      r8d, dword ptr [rdi + 0x18] 
1809D360F 4533c9                   xor      r9d, r9d 
1809D3612 488b4f10                 mov      rcx, qword ptr [rdi + 0x10] 
1809D3616 488bd0                   mov      rdx, rax 
1809D3619 488bd8                   mov      rbx, rax 
1809D361C e86f562e00               call     0x180cb8c90 
1809D3621 488d4e10                 lea      rcx, [rsi + 0x10] 
1809D3625 48895e10                 mov      qword ptr [rsi + 0x10], rbx 
1809D3629 488bd3                   mov      rdx, rbx 
1809D362C e82fbd87ff               call     0x18024f360 
1809D3631 8b4718                   mov      eax, dword ptr [rdi + 0x18] 
1809D3634 488b5c2430               mov      rbx, qword ptr [rsp + 0x30] 
1809D3639 894618                   mov      dword ptr [rsi + 0x18], eax 
1809D363C 488b742438               mov      rsi, qword ptr [rsp + 0x38] 
1809D3641 4883c420                 add      rsp, 0x20 
1809D3645 5f                       pop      rdi 
1809D3646 c3                       ret       
1809D3647 e804cb87ff               call     0x180250150 
1809D364C cc                       int3      
1809D364D cc                       int3      
1809D364E cc                       int3      
1809D364F cc                       int3      
