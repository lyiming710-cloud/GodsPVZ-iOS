# VA 1809D56D0 END 1809D5770 bound=next-method-pointer first-pdata-end=1809D5761 SHA256 940c1f9048d764fde1a793267d7f3ead7df37348bc294b05823da2a4a6b1f73b
1809D56D0 48895c2408               mov      qword ptr [rsp + 8], rbx 
1809D56D5 57                       push     rdi 
1809D56D6 4883ec20                 sub      rsp, 0x20 
1809D56DA 488bfa                   mov      rdi, rdx 
1809D56DD 488bd9                   mov      rbx, rcx 
1809D56E0 33d2                     xor      edx, edx 
1809D56E2 e889ca92ff               call     0x180302170 <StartCoro>d__4::System.IDisposable.Dispose
1809D56E7 488b4720                 mov      rax, qword ptr [rdi + 0x20] 
1809D56EB 4c8b80c0000000           mov      r8, qword ptr [rax + 0xc0] 
1809D56F2 498b4010                 mov      rax, qword ptr [r8 + 0x10] 
1809D56F6 f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D56FD 7508                     jne      0x1809d5707 
1809D56FF 488bc8                   mov      rcx, rax 
1809D5702 e8793388ff               call     0x180258a80 
1809D5707 83b8e000000000           cmp      dword ptr [rax + 0xe0], 0 
1809D570E 7508                     jne      0x1809d5718 
1809D5710 488bc8                   mov      rcx, rax 
1809D5713 e8c8aa87ff               call     0x1802501e0 
1809D5718 488b4720                 mov      rax, qword ptr [rdi + 0x20] 
1809D571C 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D5723 488b4110                 mov      rax, qword ptr [rcx + 0x10] 
1809D5727 f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D572E 7508                     jne      0x1809d5738 
1809D5730 488bc8                   mov      rcx, rax 
1809D5733 e8483388ff               call     0x180258a80 
1809D5738 488b80b8000000           mov      rax, qword ptr [rax + 0xb8] 
1809D573F 488d4b10                 lea      rcx, [rbx + 0x10] 
1809D5743 488b10                   mov      rdx, qword ptr [rax] 
1809D5746 48895310                 mov      qword ptr [rbx + 0x10], rdx 
1809D574A e8119c87ff               call     0x18024f360 
1809D574F c7431800000000           mov      dword ptr [rbx + 0x18], 0 
1809D5756 488b5c2430               mov      rbx, qword ptr [rsp + 0x30] 
1809D575B 4883c420                 add      rsp, 0x20 
1809D575F 5f                       pop      rdi 
1809D5760 c3                       ret       
1809D5761 cc                       int3      
1809D5762 cc                       int3      
1809D5763 cc                       int3      
1809D5764 cc                       int3      
1809D5765 cc                       int3      
1809D5766 cc                       int3      
1809D5767 cc                       int3      
1809D5768 cc                       int3      
1809D5769 cc                       int3      
1809D576A cc                       int3      
1809D576B cc                       int3      
1809D576C cc                       int3      
1809D576D cc                       int3      
1809D576E cc                       int3      
1809D576F cc                       int3      
