# VA 1804B2F00 END 1804B2FB0 bound=next-method-pointer first-pdata-end=1804B2F46 SHA256 f13a9a81e480b77fe85e25c075e68ee098ed104d3fdf1092745cbe1b2ae42ac0
1804B2F00 48895c2410               mov      qword ptr [rsp + 0x10], rbx 
1804B2F05 48896c2418               mov      qword ptr [rsp + 0x18], rbp 
1804B2F0A 56                       push     rsi 
1804B2F0B 4883ec20                 sub      rsp, 0x20 
1804B2F0F 4983783800               cmp      qword ptr [r8 + 0x38], 0 
1804B2F14 498bd8                   mov      rbx, r8 
1804B2F17 0fb6ea                   movzx    ebp, dl 
1804B2F1A 488bf1                   mov      rsi, rcx 
1804B2F1D 751b                     jne      0x1804b2f3a 
1804B2F1F 488d0ddad56f01           lea      rcx, [rip + 0x16fd5da] 
1804B2F26 e8c5cfd9ff               call     0x18024fef0 
1804B2F2B 48837b3800               cmp      qword ptr [rbx + 0x38], 0 
1804B2F30 7508                     jne      0x1804b2f3a 
1804B2F32 488bcb                   mov      rcx, rbx 
1804B2F35 e8c65bdaff               call     0x180258b00 
1804B2F3A 4885f6                   test     rsi, rsi 
1804B2F3D 746a                     je       0x1804b2fa9 
1804B2F3F 488b4338                 mov      rax, qword ptr [rbx + 0x38] 
1804B2F43 488bce                   mov      rcx, rsi 
1804B2F46 48897c2430               mov      qword ptr [rsp + 0x30], rdi 
1804B2F4B 488b10                   mov      rdx, qword ptr [rax] 
1804B2F4E e82dadfbff               call     0x18046dc80 
1804B2F53 488bf8                   mov      rdi, rax 
1804B2F56 4084ed                   test     bpl, bpl 
1804B2F59 7436                     je       0x1804b2f91 
1804B2F5B 488b0d9ed56f01           mov      rcx, qword ptr [rip + 0x16fd59e] 
1804B2F62 83b9e000000000           cmp      dword ptr [rcx + 0xe0], 0 
1804B2F69 7505                     jne      0x1804b2f70 
1804B2F6B e870d2d9ff               call     0x1802501e0 
1804B2F70 33d2                     xor      edx, edx 
1804B2F72 488bcf                   mov      rcx, rdi 
1804B2F75 e8f6c8e600               call     0x18131f870 Object::op_Implicit
1804B2F7A 84c0                     test     al, al 
1804B2F7C 7513                     jne      0x1804b2f91 
1804B2F7E 488b4338                 mov      rax, qword ptr [rbx + 0x38] 
1804B2F82 488bce                   mov      rcx, rsi 
1804B2F85 488b5010                 mov      rdx, qword ptr [rax + 0x10] 
1804B2F89 e8f2a2fbff               call     0x18046d280 
1804B2F8E 488bf8                   mov      rdi, rax 
1804B2F91 488b5c2438               mov      rbx, qword ptr [rsp + 0x38] 
1804B2F96 488bc7                   mov      rax, rdi 
1804B2F99 488b7c2430               mov      rdi, qword ptr [rsp + 0x30] 
1804B2F9E 488b6c2440               mov      rbp, qword ptr [rsp + 0x40] 
1804B2FA3 4883c420                 add      rsp, 0x20 
1804B2FA7 5e                       pop      rsi 
1804B2FA8 c3                       ret       
1804B2FA9 e8a2d1d9ff               call     0x180250150 
1804B2FAE cc                       int3      
1804B2FAF cc                       int3      
