# VA 1809D5A00 END 1809D5B40 bound=next-method-pointer first-pdata-end=1809D5B39 SHA256 48f3e605538fb0d2c37787ae1e8dcad90afe822bc987d7cfbc25c7cdcc7c87e8
1809D5A00 48895c2408               mov      qword ptr [rsp + 8], rbx 
1809D5A05 4889742410               mov      qword ptr [rsp + 0x10], rsi 
1809D5A0A 57                       push     rdi 
1809D5A0B 4883ec20                 sub      rsp, 0x20 
1809D5A0F 498bf0                   mov      rsi, r8 
1809D5A12 8bfa                     mov      edi, edx 
1809D5A14 488bd9                   mov      rbx, rcx 
1809D5A17 3b5118                   cmp      edx, dword ptr [rcx + 0x18] 
1809D5A1A 0f8cd6000000             jl       0x1809d5af6 
1809D5A20 488b4110                 mov      rax, qword ptr [rcx + 0x10] 
1809D5A24 4885c0                   test     rax, rax 
1809D5A27 0f8406010000             je       0x1809d5b33 
1809D5A2D 3b5018                   cmp      edx, dword ptr [rax + 0x18] 
1809D5A30 746c                     je       0x1809d5a9e 
1809D5A32 498b4020                 mov      rax, qword ptr [r8 + 0x20] 
1809D5A36 488b80c0000000           mov      rax, qword ptr [rax + 0xc0] 
1809D5A3D 85d2                     test     edx, edx 
1809D5A3F 7f6d                     jg       0x1809d5aae 
1809D5A41 488b4010                 mov      rax, qword ptr [rax + 0x10] 
1809D5A45 f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D5A4C 7508                     jne      0x1809d5a56 
1809D5A4E 488bc8                   mov      rcx, rax 
1809D5A51 e82a3088ff               call     0x180258a80 
1809D5A56 83b8e000000000           cmp      dword ptr [rax + 0xe0], 0 
1809D5A5D 7508                     jne      0x1809d5a67 
1809D5A5F 488bc8                   mov      rcx, rax 
1809D5A62 e879a787ff               call     0x1802501e0 
1809D5A67 488b4620                 mov      rax, qword ptr [rsi + 0x20] 
1809D5A6B 488b88c0000000           mov      rcx, qword ptr [rax + 0xc0] 
1809D5A72 488b4110                 mov      rax, qword ptr [rcx + 0x10] 
1809D5A76 f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D5A7D 7508                     jne      0x1809d5a87 
1809D5A7F 488bc8                   mov      rcx, rax 
1809D5A82 e8f92f88ff               call     0x180258a80 
1809D5A87 488b80b8000000           mov      rax, qword ptr [rax + 0xb8] 
1809D5A8E 488d4b10                 lea      rcx, [rbx + 0x10] 
1809D5A92 488b10                   mov      rdx, qword ptr [rax] 
1809D5A95 48895310                 mov      qword ptr [rbx + 0x10], rdx 
1809D5A99 e8c29887ff               call     0x18024f360 
1809D5A9E 488b5c2430               mov      rbx, qword ptr [rsp + 0x30] 
1809D5AA3 488b742438               mov      rsi, qword ptr [rsp + 0x38] 
1809D5AA8 4883c420                 add      rsp, 0x20 
1809D5AAC 5f                       pop      rdi 
1809D5AAD c3                       ret       
1809D5AAE 488b4018                 mov      rax, qword ptr [rax + 0x18] 
1809D5AB2 f6803501000001           test     byte ptr [rax + 0x135], 1 
1809D5AB9 7508                     jne      0x1809d5ac3 
1809D5ABB 488bc8                   mov      rcx, rax 
1809D5ABE e8bd2f88ff               call     0x180258a80 
1809D5AC3 8bd7                     mov      edx, edi 
1809D5AC5 488bc8                   mov      rcx, rax 
1809D5AC8 e8139987ff               call     0x18024f3e0 
1809D5ACD 837b1800                 cmp      dword ptr [rbx + 0x18], 0 
1809D5AD1 488bf8                   mov      rdi, rax 
1809D5AD4 7e13                     jle      0x1809d5ae9 
1809D5AD6 448b4318                 mov      r8d, dword ptr [rbx + 0x18] 
1809D5ADA 4533c9                   xor      r9d, r9d 
1809D5ADD 488b4b10                 mov      rcx, qword ptr [rbx + 0x10] 
1809D5AE1 488bd0                   mov      rdx, rax 
1809D5AE4 e8a7312e00               call     0x180cb8c90 
1809D5AE9 48897b10                 mov      qword ptr [rbx + 0x10], rdi 
1809D5AED 488d4b10                 lea      rcx, [rbx + 0x10] 
1809D5AF1 488bd7                   mov      rdx, rdi 
1809D5AF4 eba3                     jmp      0x1809d5a99 
1809D5AF6 488d0dd3991f01           lea      rcx, [rip + 0x11f99d3] 
1809D5AFD e80ea487ff               call     0x18024ff10 
1809D5B02 488bc8                   mov      rcx, rax 
1809D5B05 e8f6a587ff               call     0x180250100 
1809D5B0A 488d0def421d01           lea      rcx, [rip + 0x11d42ef] 
1809D5B11 488bd8                   mov      rbx, rax 
1809D5B14 e8f7a387ff               call     0x18024ff10 
1809D5B19 488bd0                   mov      rdx, rax 
1809D5B1C 4533c0                   xor      r8d, r8d 
1809D5B1F 488bcb                   mov      rcx, rbx 
1809D5B22 e899ae1a00               call     0x180b809c0 
1809D5B27 488bd6                   mov      rdx, rsi 
1809D5B2A 488bcb                   mov      rcx, rbx 
1809D5B2D e8dea587ff               call     0x180250110 
1809D5B32 cc                       int3      
1809D5B33 e818a687ff               call     0x180250150 
1809D5B38 cc                       int3      
1809D5B39 cc                       int3      
1809D5B3A cc                       int3      
1809D5B3B cc                       int3      
1809D5B3C cc                       int3      
1809D5B3D cc                       int3      
1809D5B3E cc                       int3      
1809D5B3F cc                       int3      
