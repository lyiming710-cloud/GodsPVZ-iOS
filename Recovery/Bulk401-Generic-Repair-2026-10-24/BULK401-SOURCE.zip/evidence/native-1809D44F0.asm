# VA 1809D44F0 END 1809D4520 bound=next-method-pointer first-pdata-end=1809D451B SHA256 005b341b71b7c8bd23d4bb26bc067982fd5065224144afb8e3e01704e4e3d11b
1809D44F0 4883ec28                 sub      rsp, 0x28 
1809D44F4 488b4918                 mov      rcx, qword ptr [rcx + 0x18] 
1809D44F8 4885c9                   test     rcx, rcx 
1809D44FB 7418                     je       0x1809d4515 
1809D44FD 498b4020                 mov      rax, qword ptr [r8 + 0x20] 
1809D4501 4c8b80c0000000           mov      r8, qword ptr [rax + 0xc0] 
1809D4508 4d8b4068                 mov      r8, qword ptr [r8 + 0x68] 
1809D450C 4883c428                 add      rsp, 0x28 
1809D4510 e99b61c1ff               jmp      0x1805ea6b0 
1809D4515 e836bc87ff               call     0x180250150 
1809D451A cc                       int3      
1809D451B cc                       int3      
1809D451C cc                       int3      
1809D451D cc                       int3      
1809D451E cc                       int3      
1809D451F cc                       int3      
