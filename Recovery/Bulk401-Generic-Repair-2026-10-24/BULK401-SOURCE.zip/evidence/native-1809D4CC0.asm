# VA 1809D4CC0 END 1809D4D50 bound=next-method-pointer first-pdata-end=1809D4CF6 SHA256 b77f033ab104d4416bd00253e3039968a6189b727c7e760339f0de37915f5723
1809D4CC0 4057                     push     rdi 
1809D4CC2 4883ec20                 sub      rsp, 0x20 
1809D4CC6 83791800                 cmp      dword ptr [rcx + 0x18], 0 
1809D4CCA 488bfa                   mov      rdi, rdx 
1809D4CCD 7420                     je       0x1809d4cef 
1809D4CCF 488b5110                 mov      rdx, qword ptr [rcx + 0x10] 
1809D4CD3 4885d2                   test     rdx, rdx 
1809D4CD6 7463                     je       0x1809d4d3b 
1809D4CD8 48634118                 movsxd   rax, dword ptr [rcx + 0x18] 
1809D4CDC 48ffc8                   dec      rax 
1809D4CDF 3b4218                   cmp      eax, dword ptr [rdx + 0x18] 
1809D4CE2 7351                     jae      0x1809d4d35 
1809D4CE4 488b44c220               mov      rax, qword ptr [rdx + rax*8 + 0x20] 
1809D4CE9 4883c420                 add      rsp, 0x20 
1809D4CED 5f                       pop      rdi 
1809D4CEE c3                       ret       
1809D4CEF 488d0d4a511d01           lea      rcx, [rip + 0x11d514a] 
1809D4CF6 48895c2430               mov      qword ptr [rsp + 0x30], rbx 
1809D4CFB e810b287ff               call     0x18024ff10 
1809D4D00 488bc8                   mov      rcx, rax 
1809D4D03 e8f8b387ff               call     0x180250100 
1809D4D08 488d0dc9dc1d01           lea      rcx, [rip + 0x11ddcc9] 
1809D4D0F 488bd8                   mov      rbx, rax 
1809D4D12 e8f9b187ff               call     0x18024ff10 
1809D4D17 488bd0                   mov      rdx, rax 
1809D4D1A 4533c0                   xor      r8d, r8d 
1809D4D1D 488bcb                   mov      rcx, rbx 
1809D4D20 e8ebfe2c00               call     0x180ca4c10 
1809D4D25 488bd7                   mov      rdx, rdi 
1809D4D28 488bcb                   mov      rcx, rbx 
1809D4D2B e8e0b387ff               call     0x180250110 
1809D4D30 488b5c2430               mov      rbx, qword ptr [rsp + 0x30] 
1809D4D35 e806b487ff               call     0x180250140 
1809D4D3A cc                       int3      
1809D4D3B e810b487ff               call     0x180250150 
1809D4D40 cc                       int3      
1809D4D41 cc                       int3      
1809D4D42 cc                       int3      
1809D4D43 cc                       int3      
1809D4D44 cc                       int3      
1809D4D45 cc                       int3      
1809D4D46 cc                       int3      
1809D4D47 cc                       int3      
1809D4D48 cc                       int3      
1809D4D49 cc                       int3      
1809D4D4A cc                       int3      
1809D4D4B cc                       int3      
1809D4D4C cc                       int3      
1809D4D4D cc                       int3      
1809D4D4E cc                       int3      
1809D4D4F cc                       int3      
