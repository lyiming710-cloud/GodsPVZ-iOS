// Original-PC-backed reconstruction, scoped to eleven compiler blockers and
// their damaged SwfList.Push dependency. No generated C++ is patched.
internal static partial class Program
{
    private const int GEmpty = 0x11000830, GPop = 0x11000831,
        GPush = 0x11000832, GComponent = 0x11000833, GAssocAdd = 0x11000834;
    private const int GListItem = 0x0A000527, GDictItem = 0x0A000528,
        GDictContains = 0x0A000529, GDictAdd = 0x0A00052A,
        GListCount = 0x0A00052B, GListPush = 0x0A00052C;
    private const int GMapBounded = 0x2B0000C2;
    private const int GData = 0x0A0003CD, GSize = 0x0A0003CE,
        GList = 0x0A0003CF, GDict = 0x0A0003D0, GTypeT = 0x1B00009E;

    private static byte[] GMapWrapperBody()
    {
        // Original RGCTX index 1 resolves to 0x06000290<T>. The full-shared
        // stack/rgctx ABI scaffolding is not managed program behavior.
        var b = new IL();
        return b.Arg(0).Arg(1).Arg(2).Integer(0).Arg(0).Call(0x06000289)
            .Integer(1).Op(0x59).Call(GMapBounded).Op(0x2A).Finish();
    }
    private static byte[] GAssocItemBody(bool byIndex)
    {
        var b = new IL();
        return b.Arg(0).Field(byIndex ? GList : GDict).Arg(1)
            .Virtual(byIndex ? GListItem : GDictItem).Op(0x2A).Finish();
    }
    private static byte[] GAssocCountBody() => new IL().Arg(0).Field(GList)
        .Virtual(GListCount).Op(0x2A).Finish();
    private static byte[] GAssocContainsBody() => new IL().Arg(0).Field(GDict)
        .Arg(1).Virtual(GDictContains).Op(0x2A).Finish();
    private static byte[] GAssocAddBody()
    {
        var b = new IL();
        b.Arg(0).Field(GDict).Arg(1).Virtual(GDictContains).Branch(0x3A,"done");
        // Reload after comparer callbacks. Original native 9D3151 first reads
        // _list; 9D3189 reloads it again after Dictionary.Add's callbacks.
        b.Arg(0).Field(GList).Store(0);
        b.Arg(0).Field(GDict).Arg(1).Load(0).Virtual(GListCount).Virtual(GDictAdd);
        b.Arg(0).Field(GList).Arg(1).Virtual(GListPush);
        return b.Label("done").Op(0x2A).Finish();
    }
    private static void GThrowEmpty(IL b) => b.Ref(0x72,0x7002DC20)
        .New(0x0A0003DC).Op(0x7A); // InvalidOperationException("empty list")
    private static byte[] GPopBody()
    {
        var b = new IL();
        b.Arg(0).Field(GSize).Branch(0x3A,"nonempty");GThrowEmpty(b);
        b.Label("nonempty").Arg(0).Field(GSize).Integer(1).Op(0x59).Store(0);
        // Decrement before a null-data or bounds failure, as in both original
        // reference and fully-shared implementations (9D4D6F / 9D4EDA).
        b.Arg(0).Load(0).Set(GSize);
        b.Arg(0).Field(GData).Load(0).Ref(0xA3,GTypeT).Store(1);
        b.Address(2).Op(0xFE,0x15).Op(BitConverter.GetBytes(GTypeT));
        b.Arg(0).Field(GData).Load(0).Load(2).Ref(0xA4,GTypeT);
        return b.Load(1).Op(0x2A).Finish();
    }
    private static byte[] GPeekBody()
    {
        var b = new IL();
        b.Arg(0).Field(GSize).Branch(0x3A,"nonempty");GThrowEmpty(b);
        return b.Label("nonempty").Arg(0).Field(GData).Arg(0).Field(GSize)
            .Integer(1).Op(0x59).Ref(0xA3,GTypeT).Op(0x2A).Finish();
    }
    private static byte[] GItemBody()
    {
        var b = new IL();
        // Original 9D5999 uses unsigned jae, so negative indices are rejected
        // before reading _data. Signed bounds comparisons change exceptions.
        b.Arg(1).Arg(0).Field(GSize).Branch(0x44,"inrange"); // blt.un
        b.New(0x0A00007B).Op(0x7A);
        return b.Label("inrange").Arg(0).Field(GData).Arg(1)
            .Ref(0xA3,GTypeT).Op(0x2A).Finish();
    }
    private static byte[] GCapacityBody() => new IL().Arg(0).Field(GData)
        .Op(0x8E,0x69,0x2A).Finish(); // ldlen, conv.i4, ret
    private static byte[] GPushBody()
    {
        var b = new IL();
        b.Arg(0).Field(GSize).Arg(0).Field(GData).Op(0x8E,0x69).Branch(0x40,"append");
        b.Arg(0).Field(GSize).Branch(0x3A,"double");
        b.Integer(4).Store(1).Branch(0x38,"allocate");
        b.Label("double").Arg(0).Field(GSize).Integer(2).Op(0x5A).Store(1);
        b.Label("allocate").Load(1).Ref(0x8D,GTypeT).Store(0);
        b.Arg(0).Field(GData).Load(0).Arg(0).Field(GSize).Call(0x0A0003D5);
        b.Arg(0).Load(0).Set(GData);
        // _size++ occurs before the array store and its possible exception.
        b.Label("append").Arg(0).Field(GSize).Store(2);
        b.Arg(0).Load(2).Integer(1).Op(0x58).Set(GSize);
        return b.Arg(0).Field(GData).Load(2).Arg(1).Ref(0xA4,GTypeT).Op(0x2A).Finish();
    }
    private static byte[] GComponentBody()
    {
        var b = new IL();
        b.Arg(0).Virtual(0x2B0000B2).Store(0);
        b.Arg(1).Branch(0x39,"done");
        // Boxing !!0 is a no-allocation reference conversion under the real
        // UnityEngine.Component constraint, retaining Unity fake-null behavior.
        b.Load(0).Ref(0x8C,0x1B00001B).Call(0x0A00000B).Branch(0x3A,"done");
        b.Arg(0).Virtual(0x2B0000B3).Store(0);
        return b.Label("done").Load(0).Op(0x2A).Finish();
    }
}
