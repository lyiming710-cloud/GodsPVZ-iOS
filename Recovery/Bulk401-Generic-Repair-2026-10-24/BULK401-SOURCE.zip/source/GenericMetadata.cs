using System.Buffers.Binary;
using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Reflection.PortableExecutable;

internal static partial class Program
{
    private static byte[] AppendGenericMetadata(byte[] before,out object evidence)
    {
        using var pe=new PEReader(new MemoryStream(before,false));
        var h=pe.PEHeaders;var md=pe.GetMetadataReader();
        Require(md.GetTableRowCount(TableIndex.MemberRef)==1318 &&
            md.GetTableRowCount(TableIndex.StandAloneSig)==2095 &&
            md.GetTableRowCount(TableIndex.TypeSpec)==181 &&
            md.GetTableRowCount(TableIndex.MethodSpec)==193,"Exact R4 metadata checkpoint");
        int rootAt=FileOffset(h,h.CorHeader!.MetadataDirectory.RelativeVirtualAddress);
        byte[] old=before[rootAt..checked(rootAt+h.CorHeader.MetadataDirectory.Size)];
        int p=Align(checked(16+Read32(old,12)),4);
        int count=BinaryPrimitives.ReadUInt16LittleEndian(old.AsSpan(p+2,2));p+=4;
        var streams=new List<(int Header,string Name,int Offset,int Size)>();
        for(int i=0;i<count;i++)
        {
            int end=Array.IndexOf(old,(byte)0,p+8);Require(end>=p+8,"Stream name");
            streams.Add((p,System.Text.Encoding.UTF8.GetString(old,p+8,end-p-8),Read32(old,p),Read32(old,p+4)));
            p=Align(end+1,4);
        }
        Require(streams.Select(s=>s.Name).Distinct().Count()==count &&
            streams.All(s=>s.Size>=0 && s.Offset>=p && s.Offset<=old.Length-s.Size),"Unique bounded streams");
        var ordered=streams.OrderBy(s=>s.Offset).ToArray();
        for(int i=1;i<count;i++)Require(ordered[i-1].Offset+ordered[i-1].Size<=ordered[i].Offset,"No overlapping streams");
        var payloads=streams.ToDictionary(s=>s.Name,s=>old[s.Offset..checked(s.Offset+s.Size)]);
        var tables=new WidthAwareTables(payloads["#~"],md);
        var blob=new List<byte>(payloads["#Blob"]);
        var names=new List<byte>(payloads["#Strings"]);
        uint Blob(string hex)
        {
            byte[] data=Convert.FromHexString(hex);int at=blob.Count;
            var b=new BlobBuilder();b.WriteCompressedInteger(data.Length);b.WriteBytes(data);
            blob.AddRange(b.ToArray());return checked((uint)at);
        }
        // Member signatures retain generic slots !0 / !1 on closed declaring
        // TypeSpecs. Reusing Dictionary<object,int> changes value-type cases.
        var members=new[] {
            (Token:GListItem, Owner:0x9B, Def:0x8EA, Name:"get_Item", Sig:"2001130008", Pin:"151284d8011300"),
            (Token:GDictItem, Owner:0x9F, Def:0x8D5, Name:"get_Item", Sig:"200113011300", Pin:"1512811102130008"),
            (Token:GDictContains, Owner:0x9F, Def:0x8D7, Name:"ContainsKey", Sig:"2001021300", Pin:"1512811102130008"),
            (Token:GDictAdd, Owner:0x9F, Def:0x8D8, Name:"Add", Sig:"20020113001301", Pin:"1512811102130008"),
            (Token:GListCount, Owner:0x9B, Def:0x8EC, Name:"get_Count", Sig:"200008", Pin:"151284d8011300"),
            (Token:GListPush, Owner:0x9B, Def:0x8E5, Name:"Push", Sig:"2001011300", Pin:"151284d8011300")
        };
        foreach(var m in members)
        {
            var owner=md.GetTypeSpecification(MetadataTokens.TypeSpecificationHandle(m.Owner));
            Require(Convert.ToHexString(md.GetBlobBytes(owner.Signature)).Equals(m.Pin,StringComparison.OrdinalIgnoreCase),"Pinned generic owner");
            uint nameAt;
            if(m.Name=="ContainsKey")
            {
                nameAt=checked((uint)names.Count);
                names.AddRange(System.Text.Encoding.UTF8.GetBytes(m.Name));names.Add(0);
            }
            else
            {
                var name=md.GetMethodDefinition(MetadataTokens.MethodDefinitionHandle(m.Def)).Name;
                Require(md.GetString(name)==m.Name,"Existing method name identity");
                nameAt=checked((uint)MetadataTokens.GetHeapOffset(name));
            }
            tables.Append(10,m.Token,checked((uint)((m.Owner<<3)|4)),nameAt,Blob(m.Sig));
        }
        string[] locals=["0700","07030813001300","07031d13000808","07011e00","0701151284d8011300"];
        for(int i=0;i<locals.Length;i++)tables.Append(17,GEmpty+i,Blob(locals[i]));
        var bounded=md.GetMethodDefinition(MetadataTokens.MethodDefinitionHandle(0x290));
        Require(md.GetString(bounded.Name)=="RandomGet_Grid_TestPlace" &&
            Convert.ToHexString(md.GetBlobBytes(bounded.Signature))=="30010415120D01128190081E000808","Bounded Map overload identity");
        tables.Append(43,GMapBounded,0x290u<<1,Blob("0a011e00"));
        payloads["#~"]=tables.Write(names.Count,blob.Count,payloads["#GUID"].Length,out var widths);
        payloads["#Blob"]=blob.ToArray();
        payloads["#Strings"]=names.ToArray();
        using var rootStream=new MemoryStream();rootStream.Write(old,0,ordered[0].Offset);
        var headers=new List<(int At,int Offset,int Size)>();
        for(int i=0;i<count;i++)
        {
            var s=ordered[i];while(rootStream.Position%4!=0)rootStream.WriteByte(0);
            headers.Add((s.Header,checked((int)rootStream.Position),payloads[s.Name].Length));rootStream.Write(payloads[s.Name]);
            int oldEnd=s.Offset+s.Size,next=i+1<count?ordered[i+1].Offset:old.Length;
            rootStream.Write(old,oldEnd,next-oldEnd);
        }
        while(rootStream.Position%4!=0)rootStream.WriteByte(0);
        byte[] root=rootStream.ToArray();
        foreach(var s in headers){Write32(root,s.At,s.Offset);Write32(root,s.At+4,s.Size);}
        int at=Align(before.Length,4),endAt=checked(at+root.Length);
        byte[] image=new byte[Align(endAt,h.PEHeader!.FileAlignment)];before.CopyTo(image,0);root.CopyTo(image,at);
        ExtendReadonlySection(image,h,endAt);var section=h.SectionHeaders.Last();
        Write32(image,h.CorHeaderStartOffset+8,checked(section.VirtualAddress+at-section.PointerToRawData));
        Write32(image,h.CorHeaderStartOffset+12,root.Length);
        evidence=new {state="CONSTRUCTION_ONLY",members,locals,methodspec="0x2B0000C2:0x06000290<!!0>",
            blob_bytes=blob.Count,old_metadata_and_heap_prefixes_preserved=true,widths};
        return image;
    }
}
