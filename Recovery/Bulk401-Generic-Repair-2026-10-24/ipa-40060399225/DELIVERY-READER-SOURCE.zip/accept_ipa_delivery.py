"""Read the downloaded artifact bytes and save the final build checkpoint.

This verifies delivery, compiler coverage and package structure. It does not
execute an iOS binary or promote any unproven gameplay equivalence.
"""
from pathlib import Path, PurePosixPath
import hashlib,json,plistlib,re,struct,subprocess,zipfile,datetime

work=Path(__file__).resolve().parent
repo=work.parent/'repo-native113'
checkpoint=repo/'Recovery/Bulk401-Generic-Repair-2026-10-24'
evidence=work/'ipa-40060399225/evidence'
delivery=work.parent.parent/'build/output/Bulk401-2026-10-24'
ipa=delivery/'GodsPVZ_1.0.2_bulk401_unsigned.ipa'
out=checkpoint/'ipa-40060399225';out.mkdir(exist_ok=True)
gh=r'C:\Program Files\GitHub CLI\gh.exe'

def sha(data):return hashlib.sha256(data).hexdigest()
def load(path):return json.loads(path.read_text('utf-8'))
def dump(path,data):path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n','utf-8')
run=json.loads(subprocess.check_output([gh,'run','view','40060399225','--repo','lyiming710-cloud/GodsPVZ-iOS','--json','databaseId,headSha,status,conclusion,jobs,url'],cwd=repo))
assert run['status']=='completed' and run['conclusion']=='success'
assert run['headSha']=='769f4fc720cb79c4fd90e7aceda709f7f13250fa'
assert len(run['jobs'])==1 and run['jobs'][0]['conclusion']=='success'
run['observed_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
dump(checkpoint/'REUSE-RUN-40060399225.json',run)
ci=load(evidence/'ipa-output/IPA-VALIDATION.json')
binding=load(evidence/'reuse-evidence/bulk401-export-binding.json')
compiler=load(evidence/'actual-export-compiler/REPORT.json')
results=load(evidence/'actual-export-compiler/ALL-RESULTS.json')
inventory=load(evidence/'actual-export-compiler/SOURCE-INVENTORY.json')
bound={PurePosixPath(r['path']).name:r for r in binding['files'] if r['path'].endswith(('.c','.cpp'))}
assert compiler['candidate_sha256']==ci['candidate_sha256']==binding['candidate_sha256']=='6de4db6c94b80a43876aea060b573ed60c1fa7170cff485103d2c808b94762ae'
assert compiler['workflow_head']==ci['workflow_head']==binding['workflow_head']=='4b42bb841af9b70c44019746037aeccbc4c42d26'
assert ci['packaging_workflow_head']==run['headSha']
assert len(results)==len(inventory)==len(bound)==325
assert {r['file'] for r in results}=={r['file'] for r in inventory}==set(bound)
for row in results+inventory:
    source=bound[row['file']]
    assert row['bytes']==source['bytes'] and row['sha256']==source['sha256']
assert (compiler['attempted'],compiler['cpp'],compiler['c'])==(325,259,66)
assert compiler['failed']==compiler['diagnostics']==compiler['unparsed']==0
for row in results:
    assert row['exit_code']==row['error_count']==0 and row['unparsed_errors']==[]
    log=evidence/'actual-export-compiler/logs'/(row['file']+'.log')
    assert log.is_file()
    text=log.read_text('utf-8',errors='replace')
    assert ': error:' not in text and ': fatal error:' not in text
controls=load(evidence/'actual-export-compiler/COMPILER-CONTROLS.json')+load(evidence/'actual-export-compiler/C-COMPILER-CONTROLS.json')
assert len(controls)==6 and all(c['expectation_met'] for c in controls)
assert load(evidence/'reuse-evidence/FLAG-CONTROLS.json')['checks']==13
assert load(evidence/'reuse-evidence/PIPELINE-CONTROLS.json')['passed']==21
buildlog=(evidence/'reuse-evidence/xcodebuild.log').read_text('utf-8',errors='replace')
assert '** BUILD SUCCEEDED **' in buildlog and '** BUILD FAILED **' not in buildlog
assert re.search(r'^.*: (?:fatal )?error:',buildlog,re.M) is None
warnings=[x for x in buildlog.splitlines() if ': warning:' in x or x.startswith('warning:')]

assert ipa.is_file() and ipa.stat().st_size==ci['ipa_bytes']==187371396
assert sha(ipa.read_bytes())==ci['ipa_sha256']=='13cd203c01cddca272e5245761168b6f383701102ef1442d4a8843186a674013'

def macho(data,expected_role):
    assert len(data)>=32
    magic,cpu,subtype,role,ncmds,extent,flags,reserved=struct.unpack_from('<8I',data)
    assert magic==0xfeedfacf and cpu==0x0100000c and role==expected_role
    at=32;end=at+extent;platform=None;signatures=[]
    assert end<=len(data)
    for _ in range(ncmds):
        assert at+8<=end
        cmd,size=struct.unpack_from('<II',data,at)
        assert size>=8 and at+size<=end
        if cmd==0x32:
            assert size>=24
            platform=struct.unpack_from('<I',data,at+8)[0]
        if cmd==0x1d:
            assert size==16
            signatures.append(struct.unpack_from('<II',data,at+8))
        at+=size
    assert at==end and platform==2 and all(length==0 for offset,length in signatures)
    return dict(bytes=len(data),sha256=sha(data),cpu='arm64',platform='physical_ios',filetype=role,nonempty_code_signature=False)

with zipfile.ZipFile(ipa) as z:
    assert z.testzip() is None
    names=z.namelist();assert len(names)==len(set(names))==ci['zip_entries']==647
    for name in names:
        path=PurePosixPath(name)
        assert not path.is_absolute() and '..' not in path.parts and '\\' not in name
        assert name=='Payload/' or name.startswith('Payload/GodsPVZ.app/')
        assert '_CodeSignature' not in path.parts and not name.endswith('.mobileprovision')
    root='Payload/GodsPVZ.app/'
    info=plistlib.loads(z.read(root+'Info.plist'))
    assert info['CFBundleIdentifier']==ci['bundle_id']=='com.tipsGodsStudio.godsPVZ'
    executable=info['CFBundleExecutable'];assert executable and '/' not in executable and '\\' not in executable
    main=macho(z.read(root+executable),2)
    framework=macho(z.read(root+'Frameworks/UnityFramework.framework/UnityFramework'),6)
    assert main['sha256']==ci['main_binary']['sha256'] and framework['sha256']==ci['unity_framework']['sha256']
    assert (z.getinfo(root+executable).external_attr>>16)&0o111
    assert (z.getinfo(root+'Frameworks/UnityFramework.framework/UnityFramework').external_attr>>16)&0o111
    metadata=[n for n in names if n.endswith('/Managed/Metadata/global-metadata.dat')]
    assert len(metadata)==1
    md=z.read(metadata[0]);original=next(x for x in binding['files'] if x['path'].endswith('global-metadata.dat'))
    assert len(md)==ci['metadata_bytes']==original['bytes'] and sha(md)==ci['metadata_sha256']==original['sha256']
    report=dict(scope='DOWNLOADED_UNSIGNED_IPA_BYTES_STRUCTURE_AND_BUILD_EVIDENCE_READBACK_ONLY',
        pass_=True,ipa_filename=ipa.name,ipa_bytes=ipa.stat().st_size,ipa_sha256=sha(ipa.read_bytes()),
        candidate_sha256=binding['candidate_sha256'],export_run=40016440758,build_run=40060399225,
        export_head=binding['workflow_head'],build_head=run['headSha'],bundle_id=info['CFBundleIdentifier'],
        minimum_os=info.get('MinimumOSVersion'),zip_crc='PASS',zip_entries=len(names),
        uncompressed_bytes=sum(x.file_size for x in z.infolist()),main_binary=main,unity_framework=framework,
        metadata_sha256=sha(md),metadata_bytes=len(md),generated_cpp_checked=259,generated_c_checked=66,
        generated_source_failures=0,raw_compiler_logs_read=325,compiler_controls=6,xcode_build_link='PASS',
        xcode_warning_lines=len(warnings),device_execution='NOT_PERFORMED',gameplay_equivalence='NOT_PROVEN',
        signing='UNSIGNED_AS_REQUESTED',production_branch_changed=False,
        github_artifact_id=12547243098,
        download_url='https://github.com/lyiming710-cloud/GodsPVZ-iOS/actions/runs/40060399225/artifacts/12547243098')

dump(out/'DELIVERY-READBACK.json',report)
dump(delivery/'DELIVERY-READBACK.json',report)
dump(out/'IPA-VALIDATION.json',ci);dump(out/'ACTUAL-EXPORT-COMPILER-REPORT.json',compiler)
dump(out/'XCODE-WARNINGS.json',dict(scope='OBSERVED_BUILD_WARNINGS_NO_SOURCE_CHANGES',lines=warnings))
with zipfile.ZipFile(out/'ALL-BUILD-EVIDENCE.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(evidence.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(evidence).as_posix())
with zipfile.ZipFile(out/'DELIVERY-READER-SOURCE.zip','w',zipfile.ZIP_DEFLATED) as z:
    z.write(__file__,'accept_ipa_delivery.py')
current=load(checkpoint/'CURRENT-RESULT.json')
current.update(state='UNSIGNED_IPA_DELIVERED_AND_DOWNLOADED_BYTES_VERIFIED',unity='REAL_EXPORT_PASS',
    xcode='REAL_ALL_GENERATED_SOURCES_AND_XCODE_BUILD_LINK_PASS',reuse_build_run=run,
    actual_export_apple_compiler=compiler,ipa=dict(filename=ipa.name,bytes=report['ipa_bytes'],sha256=report['ipa_sha256'],
    github_artifact_id=12547243098,build_run=40060399225,download_url=report['download_url'],
    validation='PASS_BUILD_STRUCTURE_AND_DOWNLOAD_BYTES',device_execution='NOT_PERFORMED',gameplay_equivalence='NOT_PROVEN'))
dump(checkpoint/'CURRENT-RESULT.json',current)
(checkpoint/'README.md').write_text('''# Bulk401: unsigned IPA delivered - 2026-10-24

The requested unsigned physical-iOS arm64 IPA has been built, packaged, uploaded, downloaded and checked against its exact bytes. The completed Mac run is [40060399225](https://github.com/lyiming710-cloud/GodsPVZ-iOS/actions/runs/40060399225), source `769f4fc720cb79c4fd90e7aceda709f7f13250fa`; the successful original Unity export is run 40016440758, source `4b42bb841af9b70c44019746037aeccbc4c42d26`.

[Download the unsigned IPA artifact](https://github.com/lyiming710-cloud/GodsPVZ-iOS/actions/runs/40060399225/artifacts/12547243098). The artifact ZIP contains `GodsPVZ_1.0.2_bulk401_unsigned.ipa`, 187,371,396 bytes (178.7 MiB), SHA-256 `13cd203c01cddca272e5245761168b6f383701102ef1442d4a8843186a674013`. GitHub artifact availability follows its 90-day retention, subject to repository deletion or policy.

The fixed candidate remains `6de4db6c94b80a43876aea060b573ed60c1fa7170cff485103d2c808b94762ae`. All 259 CPP + 66 C files in its actual Unity export passed Apple arm64 precheck. The real Xcode build/link succeeded, followed by unsigned packaging. Independent readback rechecked all 325 compiler source identities and raw logs, all six compiler controls, the build success marker, the downloaded IPA hash/size, every ZIP CRC, executable permissions, thin arm64 physical-iOS Mach-O roles, absence of signing/provisioning artifacts, bundle identifier and unchanged exported metadata. Build warnings remain recorded in `ipa-40060399225/XCODE-WARNINGS.json`; they were not represented as zero warnings.

No device execution or full-game semantic acceptance has been performed. The delivered IPA is unsigned as requested. The main branch, old candidates, frozen semantic checkers and historical evidence are unchanged.

The repair reconstructs twelve methods (11 direct generic blockers plus damaged Push dependency), bringing the cumulative construction scope to 401. Reopened isolation preserves 1916 non-target methods and byte-identical inherited 389 bodies. Existing finite-context static checks passed, actual candidate CIL passed 269 assertions and seven semantic mutants, and 139 controlled original-native cases matched. These finite controlled results are not universal gameplay equivalence. Independent portable-profile Linux and Apple checks also passed all 1030 generated C/C++ files before the real export.

`BULK401-SOURCE.zip` contains aggregate construction source and native evidence; `RUNTIME-AND-REVIEW-TOOLS.zip` contains earlier executable fixtures and independent checks; `MEMBER-ACCESS-RAW.zip` preserves the full reference audit. `compiler-40012442171/` and `apple-40014022885/` retain independent compiler evidence. The large generated-code archive remains attached to its named Actions run, with identity in `COMPILER-READBACK.json`.

`real-export-40016440758/` preserves sanitized Unity evidence, the original failed precheck log, 327-file archive binding readback, the same-path repair source and its 13 controls. The precheck falsely rejected the correct export path before Clang began; the Bulk401-specific fix retained exact SDK/architecture/include checks and left the historical Bulk389 auditor unchanged. Its expanded 21 handoff controls preserve distinct export/build commits. The successful retry reused the hash-locked archive without rerunning Unity, and the retry workflow is now manual-only.

`ipa-40060399225/DELIVERY-READBACK.json` is the final delivery readback. `ALL-BUILD-EVIDENCE.zip` preserves all actual-export compiler logs/results, source inventory, flags, controls, export and build provenance, full Xcode build log and CI packaging validation. `CURRENT-RESULT.json` records current states; `METHODBODY-SPEC.md` records method/native evidence and limits. The first full-run failure and intermediate snapshots remain available as historical evidence, not current failure claims.
''','utf-8')
remaining=repo/'Recovery/REMAINING-WORK-2026-10-23.md'
old=remaining.read_text('utf-8')
marker='以下保留 Bulk389 R4 阶段的历史过程，不代表最新门状态。'
assert marker in old
history=old[old.index(marker):]
remaining.write_text('''# 当前剩余工作：未签名 IPA 已交付，更新于 2026-10-24

**用户要求的未签名 IPA 已实际生成。Mac 运行 40060399225 完成真实 Xcode 编译／链接、打包及上传；下载后逐字节校验通过。**

- 文件：GodsPVZ_1.0.2_bulk401_unsigned.ipa，187,371,396 字节，SHA-256 `13cd203c01cddca272e5245761168b6f383701102ef1442d4a8843186a674013`。
- [下载构建产物](https://github.com/lyiming710-cloud/GodsPVZ-iOS/actions/runs/40060399225/artifacts/12547243098)。
- 新候选 `6de4db6c…` 累计 401 个目标；1916 非目标未变，旧 389 方法体逐字节不变。
- 新候选真实 Unity 导出成功，实际导出的 259 CPP + 66 C 全部通过 Apple 预检查；真实 Xcode 编译／链接成功。325 份编译日志及其源文件身份已独立回读。
- IPA 的 SHA-256、大小、ZIP CRC、arm64 真机平台、Mach-O 角色、可执行权限、Bundle ID、未签名状态及导出 metadata 绑定均已核实。
- 真机启动、游戏运行及完整行为还原仍未验收；编译和结构通过不能替代这些结果。主分支未修改。

权威入口：[Bulk401 交付与证据](Bulk401-Generic-Repair-2026-10-24/README.md)。完整成功构建日志与下载校验在该目录的 `ipa-40060399225/`；历史失败和修复过程保留在证据及 Git 历史中。

'''+history,'utf-8')
manifest=[dict(path=p.relative_to(checkpoint).as_posix(),bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(checkpoint.rglob('*')) if p.is_file() and p.name!='MANIFEST.json']
dump(checkpoint/'MANIFEST.json',manifest)
print(json.dumps({k:v for k,v in report.items() if k not in ('main_binary','unity_framework')},ensure_ascii=True))
