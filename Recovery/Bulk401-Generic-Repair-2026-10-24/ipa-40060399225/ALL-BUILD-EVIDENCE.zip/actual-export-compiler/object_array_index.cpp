int f(int* a, void* i) { return a[static_cast<unsigned long>(i)]; }
