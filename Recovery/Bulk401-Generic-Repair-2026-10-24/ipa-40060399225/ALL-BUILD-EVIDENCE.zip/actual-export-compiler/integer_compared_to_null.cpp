bool f(int i) { return i == nullptr; }
