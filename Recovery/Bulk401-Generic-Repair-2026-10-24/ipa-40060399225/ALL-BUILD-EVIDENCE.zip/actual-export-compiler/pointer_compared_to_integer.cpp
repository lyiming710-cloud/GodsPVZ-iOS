bool f(int* p) { return p == (int)0; }
