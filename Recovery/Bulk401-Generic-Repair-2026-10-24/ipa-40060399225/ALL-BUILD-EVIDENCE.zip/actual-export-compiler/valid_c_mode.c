#ifdef __cplusplus
#error C_mode_required
#endif
int value=42;
