int value=deliberately_missing;
