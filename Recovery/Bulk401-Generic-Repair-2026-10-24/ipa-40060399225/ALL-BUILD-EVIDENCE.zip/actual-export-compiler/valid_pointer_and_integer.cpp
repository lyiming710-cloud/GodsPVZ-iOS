bool f(int* p, int i) { return p == nullptr && i == 0; }
