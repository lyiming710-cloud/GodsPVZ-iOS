"""Restore five complete original actor/catalog callers. Authoring only.

Original-PC identities, constants and generic contracts are input evidence;
neither expected test output nor runtime exception suppression enters a body.
"""
import json,sys
import source_common as s
from construction import Context,old
c=Context()

def typedef(name):
 rows=[k for k,r in enumerate(s.pe.net.mdtables.TypeDef.rows,1)if str(r.TypeName)==name and not str(r.TypeNamespace)]
 assert len(rows)==1,(name,rows)
 return 0x02000000|rows[0]

def signature(name,value=False):
 token=typedef(name) if '.'not in name else c.type(name)
 return bytes([0x11 if value else 0x12])+old.labels.comp(((token&0xffffff)<<2)|(1 if token>>24==1 else 0))

def generic(owner,name,arg):
 matches=[]
 for rid,row in enumerate(s.pe.net.mdtables.MethodSpec.rows,1):
  if row.Instantiation.value!=b'\x0a\x01'+signature(arg):continue
  definition=row.Method.row
  if row.Method.table.name!='MemberRef' or str(definition.Name)!=name or definition.Class.table.name not in ['TypeRef','TypeDef']:continue
  cls=definition.Class.row;full=(str(cls.TypeNamespace)+'.'if str(cls.TypeNamespace)else'')+str(cls.TypeName)
  if full==owner:matches.append(0x2b000000|rid)
 assert len(matches)==1,(owner,name,arg,matches)
 return matches[0]

def call(b,owner,name,args=(),virtual=False):return b.token(0x6f if virtual else 0x28,c.meth(owner,name,args))
def sf(b,field):return b.token(0x7e,c.fld('ResourceManager',field))
def field(b,owner,name,arg=0):return b.arg(arg).token(0x7b,c.fld(owner,name))
def site(b,va,kind,text,emit):return b.site(va,kind,text,emit)

# Every VA is a unique semantic operation in the original complete CFG. The
# field reads remain separate so external APIs cannot silently change which
# static list or object value is consumed by a later operation.
catalogs=[
 dict(rid=0x228,kind='Device',enum='DeviceType',field='devicePrefabs',prefix='加载装置',
  pos=[0x180339118,0x180339140,0x180339161,0x180339174,0x1803391ca,0x1803391f4,0x180339222,0x180339245,0x180339283,0x1803392a9,0x1803392b8,0x1803392da,0x1803392f7,0x180339319,0x180339356,0x180339366,0x180339372,0x180339396,0x1803393af,0x1803393d8,0x1803393f2,0x1803393f5,0x18033940e,0x180339436,0x180339477]),
 dict(rid=0x22b,kind='Project',enum='ProjectType',field='projectPrefabs',prefix='加载掉落物',
  pos=[0x18033a108,0x18033a130,0x18033a151,0x18033a164,0x18033a1ba,0x18033a1e4,0x18033a212,0x18033a235,0x18033a273,0x18033a299,0x18033a2a8,0x18033a2ca,0x18033a2e7,0x18033a309,0x18033a346,0x18033a356,0x18033a362,0x18033a386,0x18033a39f,0x18033a3c8,0x18033a3e2,0x18033a3e5,0x18033a3fe,0x18033a426,0x18033a467]),
 dict(rid=0x234,kind='Zombie',enum='ZombieType',field='zombiePrefabs',prefix=None,
  pos=[0x18033bb54,0x18033bb7c,0x18033bb9d,0x18033bbb0,0x18033bc0a,0x18033bc34,0x18033bc62,0x18033bc85,0x18033bcc3,0x18033bce9,0x18033bcf8,0x18033bd1a,None,None,0x18033bd56,0x18033bd66,0x18033bd72,0x18033bd96,0x18033bdaf,0x18033bdd8,0x18033bdf2,0x18033bdf5,0x18033be0e,0x18033be36,0x18033be77])]

def catalog(q):
 rid=q['rid'];kind=q['kind'];et=typedef(q['enum']);f=q['field'];owner='System.Collections.Generic.List`1<'+kind+'>';p=q['pos'];b=c.begin(rid)
 l,local_token=c.append_locals(rid,[b'\x0e',signature('System.Collections.IEnumerator'),signature(q['enum'],True),b'\x0e',signature(kind),signature('System.IDisposable')]);base,en,val,name,pref,disp=range(l,l+6)
 site(b,p[0],'CALL','Original two-part prefab directory',lambda x:call(x.token(0x72,c.string('prefabs')).token(0x72,c.string(kind)),'System.IO.Path','Combine',('System.String','System.String')).store(base))
 site(b,p[1],'CALL','Original runtime enum type handle',lambda x:call(x.token(0xd0,et),'System.Type','GetTypeFromHandle',('System.RuntimeTypeHandle',)))
 site(b,p[2],'CALL','Enumerate original enum values; do not substitute a frozen path list',lambda x:call(x,'System.Enum','GetValues',('System.Type',)))
 site(b,p[3],'CALL','Use non-generic Array enumerator',lambda x:call(x,'System.Array','GetEnumerator',virtual=True).store(en))
 b.mark('try').mark('loop')
 site(b,p[4],'CALL','MoveNext before every original element',lambda x:call(x.loc(en),'System.Collections.IEnumerator','MoveNext',virtual=True).branch(0x39,'leave'))
 site(b,p[5],'CALL','Read the current boxed enum',lambda x:call(x.loc(en),'System.Collections.IEnumerator','get_Current',virtual=True))
 site(b,p[6],'LOOP_STATE','Unbox to the original concrete enum',lambda x:x.token(0xa5,et).store(val))
 site(b,p[7],'CALL','Resolve type again in the original GetName order',lambda x:call(x.token(0xd0,et),'System.Type','GetTypeFromHandle',('System.RuntimeTypeHandle',)))
 site(b,p[8],'CALL','Original enum name, including undefined/duplicate enum behavior',lambda x:call(x.loc(val).token(0x8c,et),'System.Enum','GetName',('System.Type','System.Object')).store(name))
 site(b,p[9],'CALL','Combine original directory and enum name',lambda x:call(x.loc(base).loc(name),'System.IO.Path','Combine',('System.String','System.String')))
 site(b,p[10],'CALL','Original closed InternalResourceLoader.Load<'+kind+'>',lambda x:x.token(0x28,generic('InternalResourceLoader','Load',kind)).store(pref))
 site(b,p[11],'CALL','Respect destroyed or unassigned Unity object semantics',lambda x:call(x.loc(pref),'UnityEngine.Object','op_Implicit',('UnityEngine.Object',)).branch(0x3a,'pad'))
 if q['prefix'] is not None:
  site(b,p[12],'CALL','Retain exact original missing-resource message',lambda x:call(x.token(0x72,c.string(q['prefix'])).loc(name).token(0x72,c.string('失败')),'System.String','Concat',('System.String','System.String','System.String')))
  site(b,p[13],'CALL','Log a missing resource and continue',lambda x:call(x,'UnityEngine.Debug','Log',('System.Object',)))
 b.branch(0x38,'loop').mark('pad')
 site(b,p[14],'FIELD_READ','Reload the current static catalog before each padding comparison',lambda x:sf(x,f))
 site(b,p[15],'CALL','Read catalog Count',lambda x:call(x,owner,'get_Count',virtual=True))
 site(b,p[16],'CONTROL_FLOW','Keep null slots until Count is strictly greater than loaded prefab.ID',lambda x:x.loc(pref).token(0x7b,c.fld(kind,'ID')).branch(0x3d,'set'))
 site(b,p[17],'FIELD_READ','Reload static catalog for each Add',lambda x:sf(x,f))
 site(b,p[18],'CALL','Pad with null rather than appending a prefab and compressing IDs',lambda x:call(x.op('14'),owner,'Add',(kind,),True).branch(0x38,'pad'))
 b.mark('set')
 site(b,p[19],'FIELD_READ','Reload static catalog for indexed assignment',lambda x:sf(x,f))
 site(b,p[20],'FIELD_READ','Read loaded prefab.ID for the actual destination',lambda x:x.loc(pref).token(0x7b,c.fld(kind,'ID')))
 site(b,p[21],'CALL','Set the slot selected by the prefab ID',lambda x:x.loc(pref).token(0x6f,c.closed_ref(owner,'set_Item',bytes.fromhex('200201081300'))).branch(0x38,'loop'))
 b.mark('leave').branch(0xdd,'return').mark('finally')
 site(b,p[22],'CONTROL_FLOW','Original IDisposable interface test belongs in finally',lambda x:x.loc(en).token(0x75,c.type('System.IDisposable')).store(disp).loc(disp).branch(0x39,'finally-end'))
 site(b,p[23],'CALL','Dispose on normal exit and CLR exception unwind',lambda x:call(x.loc(disp),'System.IDisposable','Dispose',virtual=True))
 b.mark('finally-end').op('dc').mark('return')
 site(b,p[24],'RETURN_VALUE','Return the current static catalog, without clearing existing slots',lambda x:sf(x,f).op('2a'))
 eh=[dict(kind='finally',try_start=b.labels['try'],try_end=b.labels['finally'],handler_start=b.labels['finally'],handler_end=b.labels['return'])]
 c.add(rid,b,'Restore original enum enumeration, sparse prefab.ID indexing, logging and IDisposable finally',local_token=local_token,new_eh=eh)

def plant_catalog():
 rid=0x229;b=c.begin(rid);f='plantPrefabs';owner='System.Collections.Generic.List`1<Plant>';ec='System.Collections.Generic.List`1/Enumerator<Card>';cardlist='System.Collections.Generic.List`1<Card>'
 # Original List<Card>.GetEnumerator return is Enumerator<!0>; close it here
 # with Card, not a TypeSpec containing an out-of-scope VAR 0.
 sig=s.pe.net.mdtables.MemberRef.rows[(c.meth(cardlist,'GetEnumerator')&0xffffff)-1].Signature.value
 assert sig==bytes.fromhex('2000151151011300')
 l,local_token=c.append_locals(rid,[signature('Board'),b'\x0e',bytes.fromhex('15115101')+signature('Card'),signature('Card'),b'\x0e',signature('Plant')]);board,base,en,card,name,pref=range(l,l+6)
 et=typedef('PlantType')
 # Native inlined the original public getters. Retain their legal managed
 # access: neither access a private backing field nor widen its visibility.
 assert [i['opcode'] for i in s.methods[s.tok(0x16f)]['instructions']]==['ldarg.0','ldfld','ret']
 assert s.methods[s.tok(0x16f)]['instructions'][1]['operand']['identity']=='Board BoardManager::board'
 site(b,0x18033962b,'CALL','Original BoardManager singleton through its unchanged public getter',lambda x:call(x,'BoardManager','get_Instance'))
 site(b,0x180339648,'CALL','Original Unity-null singleton gate returns null',lambda x:call(x,'UnityEngine.Object','op_Implicit',('UnityEngine.Object',)).branch(0x39,'null'))
 site(b,0x18033967f,'CALL','Read the singleton a second time through its legal public getter',lambda x:call(x,'BoardManager','get_Instance'))
 site(b,0x18033968b,'CALL','Original board through unchanged two-instruction native Board_OnPlay getter',lambda x:call(x,'BoardManager','Board_OnPlay',virtual=True).store(board))
 site(b,0x1803396a9,'CALL','Without a live board, return existing catalog without loading unrelated plants',lambda x:call(x.loc(board),'UnityEngine.Object','op_Implicit',('UnityEngine.Object',)).branch(0x39,'return'))
 site(b,0x1803396dc,'CALL','Original plant directory',lambda x:call(x.token(0x72,c.string('prefabs')).token(0x72,c.string('Plant')),'System.IO.Path','Combine',('System.String','System.String')).store(base))
 site(b,0x1803396ed,'FIELD_READ','Read the actual board Banks object',lambda x:x.loc(board).token(0x7b,c.fld('Board','banks')))
 site(b,0x1803396fd,'FIELD_READ','Enumerate selected bank cards rather than every PlantType',lambda x:x.token(0x7b,c.fld('Banks','cardList')))
 site(b,0x180339716,'CALL','Original concrete List<Card> enumerator',lambda x:call(x,cardlist,'GetEnumerator',virtual=True).store(en))
 b.mark('try').mark('loop')
 site(b,0x180339750,'CALL','Preserve card iteration order',lambda x:call(x.loca(en),ec,'MoveNext').branch(0x39,'leave'))
 site(b,0x18033975d,'LOOP_STATE','Read the original current Card',lambda x:call(x.loca(en),ec,'get_Current').store(card))
 b.mark('pad')
 site(b,0x180339796,'FIELD_READ','Reload static plant catalog for padding',lambda x:sf(x,f))
 site(b,0x1803397a6,'CALL','Read plant catalog Count',lambda x:call(x,owner,'get_Count',virtual=True))
 site(b,0x1803397b3,'FIELD_READ','The slot key comes from Card.plantData',lambda x:x.loc(card).token(0x7b,c.fld('Card','plantData')))
 site(b,0x1803397c0,'CONTROL_FLOW','Pad by Card.PlantData.plantID, not the enum or the loaded prefab ID',lambda x:x.token(0x7b,c.fld('Card/PlantData','plantID')).branch(0x3d,'existing'))
 site(b,0x1803397e5,'FIELD_READ','Reload static list for padding',lambda x:sf(x,f))
 site(b,0x1803397fe,'CALL','Create null slots for unselected/missing IDs',lambda x:call(x.op('14'),owner,'Add',('Plant',),True).branch(0x38,'pad'))
 b.mark('existing')
 site(b,0x180339827,'FIELD_READ','Reload catalog before existing-slot lookup',lambda x:sf(x,f))
 site(b,0x18033982e,'FIELD_READ','Read card data again before lookup',lambda x:x.loc(card).token(0x7b,c.fld('Card','plantData')))
 site(b,0x18033984e,'CALL','Read the selected card data slot',lambda x:call(x.token(0x7b,c.fld('Card/PlantData','plantID')),owner,'get_Item',('System.Int32',),True))
 site(b,0x180339873,'CALL','Live existing prefab skips reloading; destroyed Unity object does not',lambda x:call(x.op('14'),'UnityEngine.Object','op_Inequality',('UnityEngine.Object','UnityEngine.Object')).branch(0x3a,'loop'))
 site(b,0x1803398a1,'CALL','Original PlantType runtime handle',lambda x:call(x.token(0xd0,et),'System.Type','GetTypeFromHandle',('System.RuntimeTypeHandle',)))
 site(b,0x1803398a9,'FIELD_READ','Load path name is based on Card.cardPlantType',lambda x:x.loc(card).token(0x7b,c.fld('Card','cardPlantType')).token(0x8c,et))
 site(b,0x1803398e8,'CALL','Original enum name for this bank card',lambda x:call(x,'System.Enum','GetName',('System.Type','System.Object')).store(name))
 site(b,0x18033990e,'CALL','Combine original plant path',lambda x:call(x.loc(base).loc(name),'System.IO.Path','Combine',('System.String','System.String')))
 site(b,0x18033991d,'CALL','Original InternalResourceLoader.Load<Plant>',lambda x:x.token(0x28,generic('InternalResourceLoader','Load','Plant')).store(pref))
 site(b,0x18033993f,'CALL','Missing/destroyed loaded plant is logged and skipped',lambda x:call(x.loc(pref),'UnityEngine.Object','op_Implicit',('UnityEngine.Object',)).branch(0x3a,'set'))
 site(b,0x18033995c,'CALL','Retain exact original plant failure message',lambda x:call(x.token(0x72,c.string('加载植物')).loc(name).token(0x72,c.string('失败')),'System.String','Concat',('System.String','System.String','System.String')))
 site(b,0x18033997e,'CALL','Original missing plant log',lambda x:call(x,'UnityEngine.Debug','Log',('System.Object',)).branch(0x38,'loop'))
 b.mark('set')
 site(b,0x1803399ae,'FIELD_READ','Reload static plant list for assignment',lambda x:sf(x,f))
 site(b,0x1803399b5,'FIELD_READ','Read card data again after the resource API',lambda x:x.loc(card).token(0x7b,c.fld('Card','plantData')))
 site(b,0x1803399d5,'FIELD_READ','Use the actual post-load data ID',lambda x:x.token(0x7b,c.fld('Card/PlantData','plantID')))
 site(b,0x1803399d8,'CALL','Assign loaded plant by selected card data ID',lambda x:x.loc(pref).token(0x6f,c.closed_ref(owner,'set_Item',bytes.fromhex('200201081300'))).branch(0x38,'loop'))
 b.mark('leave').branch(0xdd,'return').mark('finally')
 site(b,0x1803399ec,'CALL','Preserve value-type enumerator Dispose in finally',lambda x:call(x.loca(en),ec,'Dispose'))
 b.op('dc').mark('return')
 site(b,0x180339a34,'RETURN_VALUE','Return current static catalog',lambda x:sf(x,f).op('2a'))
 b.mark('null');site(b,0x180339a3d,'RETURN_VALUE','Original no-BoardManager return is null',lambda x:x.op('142a'))
 eh=[dict(kind='finally',try_start=b.labels['try'],try_end=b.labels['finally'],handler_start=b.labels['finally'],handler_end=b.labels['return'])]
 c.add(rid,b,'Restore original live BoardManager/board gates and bank-selected sparse plant catalog with finally',local_token=local_token,new_eh=eh)

def on_hand():
 rid=0x3a4;b=c.begin(rid);l,local_token=c.append_locals(rid,[signature('UnityEngine.Rendering.SortingGroup')])
 site(b,0x180358bb1,'CONTROL_FLOW','Assign cardOnBank only for an actual on-bank card; null card still throws',lambda x:field(x,'Card','isOnBank',1).branch(0x39,'sorting'))
 site(b,0x180358bbe,'FIELD_WRITE','Preserve previous cardOnBank when card is not on bank',lambda x:x.arg(0).arg(1).token(0x7d,c.fld('Plant','cardOnBank')))
 b.mark('sorting')
 site(b,0x180358bcd,'FIELD_READ','Capture the original SortingGroup before setting isOnField',lambda x:field(x,'Plant','animationSortingGroup').store(l))
 site(b,0x180358bd4,'FIELD_WRITE','Original on-hand state is not on field',lambda x:x.arg(0).op('16').token(0x7d,c.fld('Plant','isOnField')))
 site(b,0x180358bf8,'CALL','Use Unity Object equality, including unassigned serialized wrappers',lambda x:call(x.loc(l).op('14'),'UnityEngine.Object','op_Equality',('UnityEngine.Object','UnityEngine.Object')).branch(0x39,'have-group'))
 site(b,0x180358c01,'FIELD_READ','Original animation part owns the new SortingGroup',lambda x:x.arg(0).arg(0).token(0x7b,c.fld('Plant','ani_aniPart')))
 site(b,0x180358c18,'CALL','Use genuine GameObject.AddComponent<SortingGroup>, not the default-return SDK extension',lambda x:x.token(0x6f,generic('UnityEngine.GameObject','AddComponent','UnityEngine.Rendering.SortingGroup')))
 site(b,0x180358c24,'FIELD_WRITE','Store the created component',lambda x:x.token(0x7d,c.fld('Plant','animationSortingGroup')))
 b.mark('have-group')
 site(b,0x180358c33,'FIELD_READ','Reload SortingGroup for layer name',lambda x:field(x,'Plant','animationSortingGroup'))
 site(b,0x180358c4d,'CALL','Original UI sorting layer',lambda x:call(x.token(0x72,c.string('UI')),'UnityEngine.Rendering.SortingGroup','set_sortingLayerName',('System.String',),True))
 site(b,0x180358c52,'FIELD_READ','Reload SortingGroup for order',lambda x:field(x,'Plant','animationSortingGroup'))
 site(b,0x180358c6a,'CALL','Original on-hand order 10000',lambda x:call(x.i4(10000),'UnityEngine.Rendering.SortingGroup','set_sortingOrder',('System.Int32',),True))
 site(b,0x180358c74,'CALL','Read this plant transform before the mouse transform',lambda x:call(x.arg(0),'UnityEngine.Component','get_transform'))
 site(b,0x180358c86,'CALL','Read actual MouseManager transform',lambda x:call(x.arg(2),'UnityEngine.Component','get_transform',virtual=True))
 site(b,0x180358c99,'CALL','Original one-argument SetParent keeps world position; false overload is incorrect',lambda x:call(x,'UnityEngine.Transform','SetParent',('UnityEngine.Transform',),True))
 site(b,0x180358c9e,'FIELD_READ','Original animator is required',lambda x:field(x,'Plant','animator'))
 site(b,0x180358cb7,'CALL','Freeze animation speed parameter with float zero',lambda x:call(x.token(0x72,c.string('speed')).r4(0),'UnityEngine.Animator','SetFloat',('System.String','System.Single'),True))
 site(b,0x180358cbc,'FIELD_READ','Original shadow is required',lambda x:field(x,'Plant','shadow'))
 site(b,0x180358ccd,'CALL','Hide shadow on hand',lambda x:call(x.op('16'),'UnityEngine.GameObject','SetActive',('System.Boolean',),True))
 site(b,0x180358cd2,'FIELD_READ','Original attack range UI controller is required',lambda x:field(x,'Plant','attackRangeUIController'))
 site(b,0x180358cec,'CALL','Collapse actual attack range view',lambda x:call(x,'AttackRangeUIController','CollapseView',virtual=True).op('2a'))
 c.add(rid,b,'Restore original complete on-hand caller: conditional bank binding, Unity-null AddComponent, SetParent(transform) and required UI calls; remove invented board assignment',local_token=local_token)

for q in catalogs:catalog(q)
plant_catalog();on_hand()
c.save_authored(sys.argv[1])
