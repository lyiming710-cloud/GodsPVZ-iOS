"""Verify every returned byte and trajectory; retain the failed planting and loss."""
from pathlib import Path,PurePosixPath
import collections,hashlib,json,sys
Q=Path(__file__).resolve().parent;W=Q.parent;D=W/'r23-gameplay-run-40614900915';g=D/'gameplay'
sys.path.insert(0,str(W));from archive_support import js
def digest(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
m=json.loads((g/'DELIVERY-MANIFEST.json').read_bytes())
for r in m['files']:
 p=PurePosixPath(r['path']);assert not p.is_absolute()and'..'not in p.parts
 f=g/p;assert f.stat().st_size==r['size']and digest(f)==r['sha256'],r['path']
report=json.loads((g/'GAMEPLAY-RESULT.json').read_bytes());expected='1d244776ee85083c2ed298c4f749f96b6c5ae820a78d50b0ce47480691775122'
assert report['candidate_sha256']==expected and report['workflow_head']=='a98851f970269f45ae762442bbe06cf07ff7eb3f'
host=json.loads((g/'HOST-RESULT.json').read_bytes());assert host['candidate_unchanged']and not report['game_dll_changed']
assert(D/'editor/license-return-exit.txt').read_text().strip()=='0'
resources=json.loads((D/'editor/r23-actual-original-resource-values.json').read_bytes());assert resources['candidate_sha256']==expected and resources['passed_leaf_checks']==9902 and resources['failed_leaf_checks']==resources['unresolved_reference_checks']==0
units={};count=0;by_kind=collections.Counter()
for line in(g/'UNIT-TRAJECTORIES.jsonl').open(encoding='utf-8'):
 r=json.loads(line);count+=1;by_kind[r['kind']]+=1;k=(r['kind'],r['instance'])
 if k not in units:units[k]=dict(kind=r['kind'],instance=r['instance'],ID=r['ID'],samples=0,first=r,last=r,moved_active=False)
 u=units[k];u['samples']+=1;u['last']=r
 if r['active']:
  if'first_active'not in u:u['first_active']=r
  u['last_active']=r;u['moved_active']|=any(r[c]!=u['first_active'][c]for c in['x','y','z'])
assert count==report['unit_samples']
bank=[json.loads(x)for x in(g/'BANK-OBSERVATIONS.jsonl').read_text().splitlines()];devices=[json.loads(x)for x in(g/'DEVICE-OBSERVATIONS.jsonl').read_text().splitlines()]
result=dict(scope='ACTUAL_R23_UNITY_RUNTIME_FAILURE_READBACK_NOT_GAMEPLAY_PASS',run=40614900915,candidate_sha256=expected,source_commit=report['workflow_head'],delivery_files_verified=len(m['files']),all_trajectory_records_read=count,records_by_kind=dict(by_kind),unique_by_kind=dict(collections.Counter(u['kind']for u in units.values())),active_moving_zombies=sum(u['kind']=='Zombie'and u['moved_active']for u in units.values()),actual_resource_leaf_checks=9902,resource_failures=0,seat_return_exit=0,host=host,observed_game_seconds=report['observed_game_seconds'],board_started=report['board_started'],planting_attempts=report['planting_attempts'],plant_on_field=False,plant_sourced_projectiles=report['projectiles_with_live_plant_source'],bank_visible_observations=sum(x['visibility'].startswith('True')for x in bank),bank_hide_states=sorted(set(x['animator_hide']for x in bank)),device_rows=len(devices),actual_errors=report['runtime_errors'],checks=report['checks'],complex_gameplay_pass=False,ipa=None,findings=[
 'Actual bank hide bool is false and cards are visible; original SetBool correction is confirmed in real Unity.',
 'Actual OS card and grass clicks occurred, but Plant.SetPrefabState_onHand threw before hand state completed; a live prefab reference was an insufficient hand-state check.',
 'Final original screenshot shows the loss dialog. The helper waited to wall timeout because it did not detect actual defeat; no restart or forced resume is accepted.',
 'Device rows show Roadblock instances initialized as ID2 and TNT as ID4. Native Load_devicePrefabs pads and assigns by the loaded prefab.ID; current CIL appends and compresses the index space.',
 'Original thirteen Device resource components decode and round-trip exactly; do not alter their correct original IDs or add null checks to mask selection of the wrong prefab.'
 ])
js(D/'ACTUAL-READBACK.json',result);js(D/'UNIT-ENDPOINTS.json',list(units.values()))
print(json.dumps({k:v for k,v in result.items()if k not in['actual_errors','checks','findings','host']}))
