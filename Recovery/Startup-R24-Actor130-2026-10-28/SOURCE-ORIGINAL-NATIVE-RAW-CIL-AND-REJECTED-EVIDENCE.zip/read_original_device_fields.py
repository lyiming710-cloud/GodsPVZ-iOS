"""Decode original Device fields, then require exact consumption and rewriting.

This diagnoses source data; it neither changes a prefab nor reinterprets native
ID branches to match the currently observed faulty objects.
"""
from pathlib import Path
import hashlib,json,sys,zipfile
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1]
sys.path[:0]=[str(W/'gameplay-complex-2026-10-27/type-tree-tool'),str(W/'python-deps'),str(ROOT/'audit/stage9-native3/python-deps')]
import dnfile,UnityPy
from UnityPy.helpers.TypeTreeGenerator import TypeTreeGenerator
from UnityPy.helpers.TypeTreeNode import TypeTreeNode
from UnityPy.helpers import TypeTreeHelper as H
from UnityPy.streams import EndianBinaryReader,EndianBinaryWriter
sha=lambda b:hashlib.sha256(b).hexdigest()
candidate=W/'startup-r23-battle-loop/correction1.dll';assert sha(candidate.read_bytes())=='1d244776ee85083c2ed298c4f749f96b6c5ae820a78d50b0ce47480691775122'
g=TypeTreeGenerator('2022.3.44f1');seen=set();loaded=[]
paths=[candidate]+sorted((ROOT/'audit/local-preflight/exact-editor-tools/aot-resolver').glob('*.dll'))+sorted((ROOT/'audit/local-preflight/exact-editor-tools/resolver').glob('*.dll'))+sorted((ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support').glob('*.dll'))
for p in paths:
 pe=dnfile.dnPE(str(p));table=pe.net.mdtables.Assembly
 if table is None:pe.close();continue
 name=str(table.rows[0].Name);pe.close()
 if name in seen:continue
 seen.add(name);b=p.read_bytes();g.load_dll(b);loaded.append(dict(file=str(p.relative_to(ROOT)),assembly=name,sha256=sha(b)))
nodes=json.loads(g.get_nodes_as_json('GodsPVZRuntime1.dll','Device'));(Q/'DEVICE-TYPE-TREE-UNADAPTED.json').write_text(json.dumps(nodes,indent=2)+'\n')
changes=[]
for i,n in enumerate(nodes):
 if n['m_Name']=='m_Enabled'and n['m_Level']==1:changes.append(dict(index=i,before=dict(n),reason='MonoBehaviour enabled byte alignment'));n['m_MetaFlag']|=16384
 if n['m_Type']=='string'and i+3<len(nodes)and nodes[i+1]['m_Name']=='Array'and nodes[i+3]['m_Name']=='data'and nodes[i+3]['m_Type']=='string':changes.append(dict(index=i,before=dict(n),reason='string array wrapper'));n['m_Type']='vector'
tree=TypeTreeNode.from_list([TypeTreeNode(n['m_Level'],n['m_Type'],n['m_Name'],0,0,m_MetaFlag=n['m_MetaFlag'])for n in nodes])
census=json.loads((W/'gameplay-complex-2026-10-27/EMPTY-ROOT-COMPONENT-DATA-CENSUS.json').read_bytes());targets=[r for r in census['all_rows']if r['owner']=='Device'];assert len(targets)==13
with zipfile.ZipFile(ROOT/'GodsPVZ_1.0.2.zip')as z:raw=z.read(next(n for n in z.namelist()if n.endswith('/resources.assets')))
assert sha(raw)=='b84c445e60b52b446ae1989557541b3206a518ffc9ea64d8abd1d2a3d8472317'
env=UnityPy.load(raw);objects={o.path_id:o for o in env.objects};rows=[];values={};gaps=[]
for r in targets:
 try:
  o=objects[r['original_component']];b=o.get_raw_data();assert sha(b)==r['original_component_sha256']
  reader=EndianBinaryReader(b,endian='<');decoded=H.read_typetree(tree,reader,byte_size=len(b),check_read=True);writer=EndianBinaryWriter(endian='<');H.write_typetree(decoded,tree,writer);assert writer.bytes==b
  values[r['resource']]=decoded;rows.append(dict(resource=r['resource'],original_component=o.path_id,bytes=len(b),sha256=sha(b),source_path=r['captured_source'],original_ID=decoded['ID'],original_type=decoded['deviceType'],original_health=decoded['healthPoint'],original_attack_range=decoded['attackRangeUIController'],byte_exact_round_trip=True))
 except Exception as ex:gaps.append(dict(resource=r['resource'],error=repr(ex)))
result=dict(scope='ORIGINAL_DEVICE_SERIALIZED_FIELDS_READ_ONLY_NO_REPAIR',candidate_field_metadata_sha256=sha(candidate.read_bytes()),original_resources_sha256=sha(raw),references=loaded,schema_adaptations=changes,targets=len(targets),decoded=len(rows),rows=rows,unmodeled=gaps,game_dll_changed=False,project_changed=False)
for name,data in [('DEVICE-TYPE-TREE-ADAPTED.json',nodes),('ORIGINAL-DEVICE-FIELD-CENSUS.json',result),('ORIGINAL-DEVICE-SERIALIZED-VALUES.json',values)]:
 (Q/name).write_bytes((json.dumps(data,indent=2,ensure_ascii=False)+'\n').encode())
print(json.dumps(dict(decoded=len(rows),rows=rows,unmodeled=gaps),ensure_ascii=True))
