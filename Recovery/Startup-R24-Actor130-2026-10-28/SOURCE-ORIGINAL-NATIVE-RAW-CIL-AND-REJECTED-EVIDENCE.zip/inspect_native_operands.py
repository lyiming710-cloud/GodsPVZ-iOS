"""Decode immutable PC literals, method specs and direct call identities."""
import json,struct
import source_common as s
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
meta=(s.I/'original-pc/global-metadata.dat').read_bytes();assert s.sha(meta)=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9'
lo,ln,ld,ldn=struct.unpack_from('<4I',meta,8);strings=struct.unpack_from('<I',meta,24)[0];mo=struct.unpack_from('<I',meta,48)[0]
types=json.loads((s.I/'maps/native-types.json').read_bytes());mv=struct.unpack('<16Q',s.pc.get_data(0x1818c6d00-s.base,128));read=lambda va,n:s.pc.get_data(va-s.base,n);qword=lambda va:struct.unpack('<Q',read(va,8))[0]
def text(index):return meta[strings+index:meta.index(0,strings+index)].decode('utf-8')
def typename(ptr):
 data,bits=struct.unpack('<QI',read(ptr,12));kind=(bits>>16)&255
 if kind in[0x11,0x12]:
  t=types[data];return (t['namespace']+'.'if t['namespace']else'')+t['name']
 return {1:'System.Void',8:'System.Int32',0xe:'System.String',0x1c:'System.Object'}.get(kind,'kind:'+hex(kind))
def spec(index):
 assert index<mv[8];md,cls,mth=struct.unpack('<3i',read(mv[9]+12*index,12));name=text(struct.unpack_from('<I',meta,mo+36*md)[0]);owners=[t for t in types if t['methodStart']<=md<t['methodStart']+t['methods']];assert len(owners)==1
 def arguments(index):
  if index<0:return []
  ptr=qword(mv[3]+8*index);argc,argv=struct.unpack('<2Q',read(ptr,16));assert argc<20;return [typename(qword(argv+8*k))for k in range(argc)]
 return dict(owner=(owners[0]['namespace']+'.'if owners[0]['namespace']else'')+owners[0]['name'],method=name,method_definition_index=md,class_inst=cls,method_inst=mth,class_args=arguments(cls),method_args=arguments(mth))
def slot(i):
 va=i.address+i.size+i.operands[1].mem.disp;encoded=qword(va);kind=encoded>>29;index=(encoded&0x1fffffff)>>1
 result=dict(slot_va=hex(va),encoded=hex(encoded),kind=kind,index=index)
 if kind==5:
  assert index<ln//8;n,start=struct.unpack_from('<II',meta,lo+8*index);assert start+n<=ldn;result['string']=meta[ld+start:ld+start+n].decode('utf-8')
 elif kind==1:result['class']=typename(qword(mv[7]+8*index))
 elif kind==6:result['methodspec']=spec(index)
 return result
mp=json.loads((s.I/'maps/native-method-map.json').read_bytes());by={}
for r in mp:by.setdefault(r['va'],[]).append(r)
result=[]
for rid in[0x348,0x349,0x3a4,0x324,0x32b,0x305,0x304,0x30b,0x3a2,0x228,0x229,0x234,0x22b,0x3a6]:
 cfg=s.save_native(rid);rows=[]
 for r in cfg['instructions']:
  i=next(s.dis.disasm(bytes.fromhex(r['bytes']),int(r['va'],16)));v=None
  if len(i.operands)==2 and i.operands[1].type==X86_OP_MEM and i.operands[1].mem.base==X86_REG_RIP:
   if i.mnemonic=='mov'and i.size>=7:v=slot(i)
   elif i.mnemonic in['movss','divss','mulss','comiss']:
    at=i.address+i.size+i.operands[1].mem.disp;v=dict(constant_va=hex(at),f32=struct.unpack('<f',read(at,4))[0],bits=read(at,4).hex())
  if i.mnemonic in['call','jmp']and r['operands']in by:v=by[r['operands']]
  if v is not None:rows.append(dict(va=r['va'],op=r['op'],operands=r['operands'],resolved=v))
 result.append(dict(token=s.tok(rid),rows=rows,outside=cfg['outside_boundaries'],indirect=cfg['indirect_jumps']))
(s.Q/'ORIGINAL-OPERAND-RESOLUTION.json').write_text(json.dumps(result,indent=2)+'\n')
for d in result:
 print(d['token'])
 for r in d['rows']:
  v=r['resolved']
  if isinstance(v,dict)and('string'in v or'methodspec'in v or'f32'in v):print(r['va'],json.dumps(v,ensure_ascii=True))
