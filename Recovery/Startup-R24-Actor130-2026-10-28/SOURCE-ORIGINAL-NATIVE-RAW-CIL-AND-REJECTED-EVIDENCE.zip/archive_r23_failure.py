"""Preserve the complete actual failed R23 run before publishing R24."""
from pathlib import Path
import hashlib,json,sys
Q=Path(__file__).resolve().parent;W=Q.parent;R=W.parents[1]/'audit/repo-native113';sys.path.insert(0,str(W))
from archive_support import js,pack,manifest
D=W/'r23-gameplay-run-40614900915';C=R/'Recovery/Startup-R23-Actual-Gameplay-2026-10-28';assert not C.exists();C.mkdir()
summary=json.loads((D/'ACTUAL-READBACK.json').read_bytes());assert summary['run']==40614900915 and summary['complex_gameplay_pass']is False
(C/'.gitattributes').write_bytes(b'* -text\n');js(C/'ACTUAL-40614900915.json',summary)
items=[];screens=[]
for p in sorted(D.rglob('*')):
 if not p.is_file():continue
 target=(p.relative_to(D).as_posix(),p.read_bytes())
 (screens if p.suffix.lower()=='.png' else items).append(target)
pack(C/'ACTUAL-R23-FULL-LOGS-AND-LOADED-SDK.zip',items)
group=[];size=0;index=1
for item in screens:
 if group and size+len(item[1])>30000000:
  pack(C/f'ACTUAL-R23-ALL-SCREENS-{index:02d}.zip',group);index+=1;group=[];size=0
 group.append(item);size+=len(item[1])
if group:pack(C/f'ACTUAL-R23-ALL-SCREENS-{index:02d}.zip',group)
(C/'README.md').write_text('''# R23 actual Unity failure, run 40614900915

Fixed source `a98851f970269f45ae762442bbe06cf07ff7eb3f`, game DLL `1d244776ee85083c2ed298c4f749f96b6c5ae820a78d50b0ce47480691775122`. This is a real Editor/player-loop and X11 OS-input result. All 80 delivered files and 60,703 trajectory records were independently read and hashed. Resource checks: 70 routes, 9,902 original field/reference checks passed, zero failures. License return exited zero.

Bank Animator `hide=false` and visible cards confirm R23's exact SetBool correction in real Unity. Actual OS selection, confirmation, start, bank-card and grass clicks occurred. Forty-one zombie instances / seven types were observed; eighteen were active and moved. Planting failed: no plant on field and no plant-sourced projectile. This is not accepted zombie path correctness or normal combat.

Actual runtime errors: Device.EnemySeeking_Zombie NRE 7,100 times; Plant.SetPrefabState_onHand unassigned SortingGroup once; Device.InjuryStatusUpdate NRE four times. Device catalog compression selects Roadblock for ID2 and TNT for ID4. Original Device components decode and round-trip exactly, so their original serialized IDs must be preserved. Restore the catalog algorithm, not defensive skips.

The old helper's live-hand check falsely accepted an assigned reference while `handItemType=None` and `plantTypeOnHand=Null`. Its final screenshot is the real loss dialog; it did not detect defeat and waited to its wall deadline. Both diagnostic defects remain in the preserved raw evidence. There is no new IPA, iPad acceptance or gameplay pass.
''','utf-8')
manifest(C)
P=R/'Recovery/Startup-R23-Runtime-Correction-2026-10-28';j=json.loads((P/'PROGRESS.json').read_bytes());js(P/'PROGRESS-BEFORE-ACTUAL-40614900915.json',j)
j.update(status='ACTUAL_R23_UNITY_COMPLETED_FAILURE',actual_unity_run=40614900915,actual_resource_leaf_checks_passed=9902,actual_bank_hide_false=True,actual_planting_pass=False,actual_complex_gameplay_pass=False,actual_observed_game_seconds=summary['observed_game_seconds'],ipa=None)
js(P/'PROGRESS.json',j)
with(P/'README.md').open('a',encoding='utf-8')as f:f.write('\nActual run 40614900915 completed with failure: bank bool correction is observed, but plant setup throws, catalog IDs select wrong Device prefabs and the game reaches its loss dialog. [Complete original failure evidence](../Startup-R23-Actual-Gameplay-2026-10-28/README.md). No new IPA.\n')
manifest(P)
print(json.dumps(dict(archived_run=40614900915,files=len(list(C.iterdir())),screens=len(screens),actual_gameplay_pass=False)))
