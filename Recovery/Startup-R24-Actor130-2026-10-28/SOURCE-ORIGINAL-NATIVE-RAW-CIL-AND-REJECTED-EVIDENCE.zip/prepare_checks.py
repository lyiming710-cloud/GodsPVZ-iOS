"""Bind unchanged shared checkers to the completed 130-position R24 cohort."""
import json,shutil
import source_common as s
for name in ['run_static.py','run_exact_jit.py','verify_isolation.py']:
 text=(s.W/'startup-r22-board-loop'/name).read_text('utf-8')
 text=text.replace('startup-r21-ui-batch100/authored1.dll','startup-r23-battle-loop/correction1.dll').replace('75160a3233f1e1ab13a44f712efb4b47fdeb9b57bd38fa25f180276bb7b50e15','1d244776ee85083c2ed298c4f749f96b6c5ae820a78d50b0ce47480691775122')
 text=text.replace('EXACT_CANDIDATE_FIVE_METHOD_112_POSITION','EXACT_CANDIDATE_FIVE_METHOD_130_POSITION')
 (s.Q/name).write_text(text,'utf-8')
shutil.copyfile(s.W/'startup-r23-battle-loop/ALL-METHODS.json',s.Q/'ALL-METHODS.json')
report=json.loads((s.Q/'authored1.json').read_bytes());assert report['new_unique_repair_positions']==130 and report['new_unique_methods']==5
(s.Q/'SHARED-TEST-START.json').write_text(json.dumps(dict(scope='SHARED_CHECKS_AFTER_COMPLETED_130_DISTINCT_NATIVE_POSITION_COHORT',candidate_sha256=report['candidate_sha256'],methods=5,positions=130,old_frozen_checkers_unchanged=True,gameplay_pass=False),indent=2)+'\n','utf-8')
print('R24_SHARED_CHECKS_BOUND_AFTER_130_POSITIONS')
