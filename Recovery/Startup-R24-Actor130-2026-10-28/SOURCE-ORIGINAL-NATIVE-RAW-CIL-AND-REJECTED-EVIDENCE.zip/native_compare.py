"""Execute five byte-rechecked PC callers with explicit finite leaf contracts.

No DllMain, Unity runtime or original nested game behavior is claimed. Normal
paths and fake-null objects are compared to exact raw candidate CIL. Injected
exception unwind remains UNSUPPORTED; the candidate finally is kept intact.
"""
from pathlib import Path
import collections,ctypes as C,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
cases=json.loads((Q/'CASES.json').read_bytes());actual=json.loads(Path(sys.argv[1]).read_bytes());byname={r['name']:r for r in actual['results']};enums=json.loads((Q/'FIXTURE-ENUM-CONSTANTS.json').read_bytes());spec=json.loads((Q/'ORIGINAL-OPERAND-RESOLUTION.json').read_bytes());state={};rows=[]

def log(*v):state['trace'].append(':'.join('1'if x is True else'0'if x is False else'null'if x is None else str(x).replace('\\','/')for x in v))
def tag(p):return 'null'if not p else state['objects'][p]['tag']
def obj(tag_,kind='UObj',size=1024,alive=True):
 p=im.alloc(size);state['objects'][p]=dict(tag=tag_,kind=kind,alive=alive);return p
def string(value):p=im.alloc(32);state['strings'][p]=value;return p
def getstring(p):return state['strings'].get(p,'')
def sequence(items):
 p=im.alloc(64);a=im.alloc(32+8*1024);put64(p+0x10,a);put32(p+0x18,len(items));put32(a+0x18,1024)
 state['lists'][p]=list(items)
 for k,v in enumerate(items):put64(a+0x20+k*8,v)
 return p
def field_list():return get64(statics['ResourceManager']+state['list_offset'])
def prefab(kind,id_,label,alive=True):
 p=obj(label,kind,alive=alive);put32(p+{'Device':0x5c,'Zombie':0x60,'Project':0x24,'Plant':0x60}[kind],id_);return p
def reset_list(items):put64(statics['ResourceManager']+state['list_offset'],sequence(items))
def live(p):return bool(p and state['objects'][p]['alive'])
def implicit(p,m):
 v=live(p);log('implicit',tag(p),v)
 if state['mode']=='id-callback'and p and state['objects'][p]['kind']=='Device':put32(p+0x5c,6)
 return v
def equality(a,b,m):v=(not live(a)and not live(b))or a==b;log('eq',tag(a),tag(b),v);return v
def inequality(a,b,m):v=not((not live(a)and not live(b))or a==b);log('ne',tag(a),tag(b),v);return v
def box(cls,p):
 out=im.alloc(32);put64(out,cls);put32(out+0x10,get32(p));return out
def enumvalues(typ,m):log('values');return state['enum-array']
def arrayenum(p,m):log('getEnum');state['enum_index']=-1;return state['enum']
def arraycall(index,method,p):
 if index==0:
  state['enum_index']+=1;v=state['enum_index']<len(state['enum_items']);log('move',v);return int(v)
 assert index==1;log('current',state['enum_index']);return state['enum_items'][state['enum_index']]
def enumname(typ,v,m):
 value=get32(v+0x10);log('name',value);return string(enums[state['kind']+'Type'].get(str(value),''))
def load(path,method):
 name=getstring(path).replace('\\','/');log('load',name);value=state['loads'].get(name,0)
 if state['mode']=='replace-static':reset_list([prefab('Device',0,'replacement-0'),prefab('Device',1,'replacement-1')])
 return value
def add(p,v,m):
 rows_=state['lists'][p];rows_.append(v);put64(get64(p+0x10)+0x20+8*(len(rows_)-1),v);put32(p+0x18,len(rows_))
def setitem(p,index,v,m):
 assert 0<=index<len(state['lists'][p]);state['lists'][p][index]=v;put64(get64(p+0x10)+0x20+8*index,v)
def item(p,index,m):return state['lists'][p][index]
def listenum(out,p,m):put64(out,p);put32(out+8,0);put64(out+16,0);return out
def listmove(p,m):
 seq=get64(p);index=get32(p+8);items=state['lists'][seq]
 if index>=len(items):return False
 put64(p+16,items[index]);put32(p+8,index+1);return True
def transform(p,m):log('transform',tag(p));return state['objects'][p]['transform']
def parent(p,other,m):log('parent',tag(p),tag(other),True);state['objects'][p].update(parent=other,worldStay=True)
def addcomponent(p,m):log('addComponent',tag(p),'SortingGroup');return obj('created-group','SortingGroup')
def layer(p,v,m):log('layer',tag(p),getstring(v));state['objects'][p]['layer']=getstring(v)
def order(p,v,m):log('order',tag(p),v);state['objects'][p]['order']=v
def animfloat(p,name,v,m):log('float',tag(p),getstring(name),int(v));state['objects'][p]['speed']=v
def active(p,v,m):log('active',tag(p),bool(v));state['objects'][p]['active']=bool(v)
def collapse(p,m):log('collapse',tag(p));state['objects'][p]['collapsed']=True

def setup(q):
 state.clear();state.update(q=q,kind=q['kind'],mode=q['mode'],objects={},lists={},strings={},loads={},trace=[],list_offset={'Device':0x170,'Zombie':0x160,'Project':0x168,'Plant':0x150}[q['kind']])
 reset_list([0 if v is None else prefab(q['kind'],v,'existing-'+str(v))for v in q.get('existing',[])])
 for e in q.get('loads',[]):state['loads']['prefabs/'+q['kind']+'/'+e['name']]=prefab(q['kind'],e['id'],'prefab-'+e['name'],not e.get('destroyed',False))
 for slot,value in literal_slots.items():put64(slot,string(value))
 enumcls=classes[q['kind']+'Type'];state['enum-array']=im.alloc(64);state['enum']=obj('array-enumerator');state['enum_items']=[]
 for value in q.get('values',[]):
  p=im.alloc(32);put64(p,enumcls);put32(p+0x10,value);state['enum_items'].append(p)
 manager=obj('manager','BoardManager',alive=q['mode']!='dead-manager');board=obj('board','Board',alive=q['mode']!='dead-board');banks=im.alloc(256);put64(manager+0x48,0 if q['mode']=='no-board'else board);put64(statics['BoardManager'],0 if q['mode']=='no-manager'else manager);put64(board+0x128,banks);cards=[]
 for e in q.get('cards',[]):
  p=obj('card-'+str(e['id']),'Card');data=im.alloc(128);put32(data+0x18,e['id']);put64(p+0x30,data);put32(p+0x28,e['type']);cards.append(p)
 put64(banks+0x30,sequence(cards))
 plant=obj('plant','Plant');mouse=obj('mouse','MouseManager');card=obj('card','Card');oldcard=obj('old-card');oldboard=obj('old-plant-board','Board');pTr=obj('plant-tr','Transform');mTr=obj('mouse-tr','Transform');part=obj('animation-part','GameObject');shadow=obj('shadow','GameObject');anim=obj('animator','Animator');ar=obj('attack-range','AttackRangeUIController')
 state.update(plant=plant,mouse=mouse,card=card,pTr=pTr,shadow=shadow,anim=anim,ar=ar)
 state['objects'][plant]['transform']=pTr;state['objects'][mouse]['transform']=mTr;state['objects'][pTr].update(parent=0,worldStay=False);state['objects'][shadow]['active']=True;state['objects'][anim]['speed']=17;state['objects'][ar]['collapsed']=False
 put64(plant+0x1f0,oldcard);put64(plant+0x1e8,oldboard);C.c_ubyte.from_address(plant+0xb0).value=1;C.c_ubyte.from_address(card+0x54).value=q.get('onBank',False)
 group=0 if q.get('group','null')=='null'else obj('existing-group','SortingGroup',alive=q['group']!='destroyed');put64(plant+0x170,group);put64(plant+0x158,part);put64(plant+0x178,shadow);put64(plant+0x168,anim);put64(plant+0x70,ar)

def snapshot(rid,result):
 if rid!=0x3a4:return dict(list=[tag(p)for p in state['lists'][field_list()]],returned_null=not bool(result))
 p=state['plant'];group=get64(p+0x170);o=state['objects'][group]if group else{};tr=state['objects'][state['pTr']]
 return dict(card=tag(get64(p+0x1f0)),board=tag(get64(p+0x1e8)),onField=bool(C.c_ubyte.from_address(p+0xb0).value),group=tag(group),layer=o.get('layer'),order=o.get('order'),parent=tag(tr['parent']),worldStay=tr['worldStay'],speed=state['objects'][state['anim']]['speed'],shadow=state['objects'][state['shadow']]['active'],collapsed=state['objects'][state['ar']]['collapsed'])

for rid in[0x228,0x229,0x22b,0x234,0x3a4]:
 im=NativeImage();statics={};classes={};literal_slots={};cfg=json.loads((Q/'native-source-complete'/f'0x{0x6000000|rid:08X}.json').read_bytes())
 for d in spec:
  for r in d['rows']:
   v=r['resolved']
   if isinstance(v,dict)and'class'in v:
    name=v['class']
    if name not in classes:
     cls=im.alloc(512);sf_=im.alloc(4096);put64(cls+0xb8,sf_);put64(cls+0x40,cls+0x100);put32(cls+0xe0,1);classes[name]=cls;statics[name]=sf_
    put64(int(v['slot_va'],16),classes[name])
   if isinstance(v,dict)and'string'in v:literal_slots[int(v['slot_va'],16)]=v['string']
 im.hook(0x18024fef0,None,[P],lambda p:None);im.hook(0x1802501e0,None,[P],lambda p:None)
 im.hook(0x180c84600,P,[P,P,P],lambda a,b,m:string(getstring(a)+'/'+getstring(b)));im.hook(0x180ccee30,P,[P,P],lambda p,m:p);im.hook(0x180cdd3b0,P,[P,P],enumvalues);im.hook(0x180cba170,P,[P,P],arrayenum);im.hook(0x180002cd0,P,[I,P,P],arraycall)
 im.hook(0x18024f540,P,[P],lambda p:p+0x10);im.hook(0x18024f340,P,[P,P],box);im.hook(0x180cdcd20,P,[P,P,P],enumname);im.hook(0x18047ba00,P,[P,P],load)
 im.hook(0x18131f870,C.c_bool,[P,P],implicit);im.hook(0x18131f760,C.c_bool,[P,P,P],equality);im.hook(0x18131f900,C.c_bool,[P,P,P],inequality)
 im.hook(0x180b73f50,P,[P,P,P,P],lambda a,b,c,m:string(getstring(a)+getstring(b)+getstring(c)));im.hook(0x1812e68f0,None,[P,P],lambda p,m:log('debug',getstring(p)))
 im.hook(0x180002e70,None,[P,P,P],add);im.hook(0x180855ab0,None,[P,I,P,P],setitem);im.hook(0x180825710,P,[P,I,P],item)
 im.hook(0x18024f380,P,[P,P],lambda p,cls:p);im.hook(0x180002d90,None,[I,P,P],lambda i,m,p:log('dispose'));im.hook(0x1808197f0,P,[P,P,P],listenum);im.hook(0x180669280,C.c_bool,[P,P],listmove);im.hook(0x180302170,None,[P,P],lambda p,m:None)
 im.hook(0x18046d280,P,[P,P],addcomponent);im.hook(0x181348060,None,[P,P,P],layer);im.hook(0x1813480b0,None,[P,I,P],order);im.hook(0x181304510,P,[P,P],transform);im.hook(0x18132e8b0,None,[P,P,P],parent);im.hook(0x1812dbab0,None,[P,P,F,P],animfloat);im.hook(0x18131bad0,None,[P,C.c_bool,P],active);im.hook(0x180394350,None,[P,P],collapse)
 im.verify_caller(rid,int(cfg['entry'],16),cfg)
 for q in cases:
  if q['token']!=f'0x{0x6000000|rid:08X}':continue
  expected=byname[q['name']]
  if 'native_unwind'in q:rows.append(dict(name=q['name'],token=q['token'],status='UNSUPPORTED_ORIGINAL_WINDOWS_SEH_EXCEPTION_UNWIND',cil_error=expected['error'],candidate_finally_preserved=True));continue
  setup(q);result=C.CFUNCTYPE(P,P,P,P,P)(int(cfg['entry'],16))(state['plant'],state['card'],state['mouse'],None)if rid==0x3a4 else C.CFUNCTYPE(P,P)(int(cfg['entry'],16))(None)
  assert not im.errors,im.errors;got=dict(state=snapshot(rid,result),trace=state['trace']);diff={k:dict(native=got[k],cil=expected[k])for k in['state','trace']if got[k]!=expected[k]}
  if expected['error']:diff['cil_error']=expected['error']
  rows.append(dict(name=q['name'],token=q['token'],status='ZERO_DIFFERENCE'if not diff else'DIFFERENCE',native=got,cil=expected,differences=diff))
 im.close()
result=dict(scope='FIVE_UNTOUCHED_PC_CALLERS_VS_EXACT_RAW_CIL_FINITE_CONTROLLED_LEAF_CONTRACTS_NOT_UNITY',candidate_sha256=actual['candidate_sha256'],original_pc_sha256=PC_SHA,counts=dict(collections.Counter(r['status']for r in rows)),rows=rows,whole_game_behavior_proven=False,ipa=None)
(Q/'NATIVE-COMPARE.json').write_text(json.dumps(result,indent=2)+'\n','utf-8');print(json.dumps({k:v for k,v in result.items()if k!='rows'},indent=2));print(json.dumps([r for r in rows if r['status']=='DIFFERENCE'][:3],indent=2))
assert not any(r['status']=='DIFFERENCE'for r in rows)
