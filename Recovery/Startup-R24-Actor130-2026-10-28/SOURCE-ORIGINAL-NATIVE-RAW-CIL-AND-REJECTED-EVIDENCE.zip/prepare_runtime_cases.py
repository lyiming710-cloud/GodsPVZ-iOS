"""Independent finite cases and exact original enum constants for raw CIL tests."""
import json,struct
import source_common as s
enum_names={};defs=[]
for name in ['DeviceType','ZombieType','ProjectType','PlantType']:
 t=next(r for r in s.pe.net.mdtables.TypeDef.rows if str(r.TypeName)==name and not str(r.TypeNamespace));rows=[]
 for f in t.FieldList:
  constants=[x for x in s.pe.net.mdtables.Constant.rows if x.Parent.table.name=='Field'and x.Parent.row_index==f.row_index]
  if not constants:continue
  assert len(constants)==1 and constants[0].Type==8;value=struct.unpack('<i',constants[0].Value.value)[0];rows.append((str(f.row.Name),value))
 enum_names[name]={str(v):k for k,v in rows};defs.append('public enum '+name+' {'+','.join(k+'='+str(v)for k,v in rows)+'}')
(s.Q/'runtime/Enums.cs').write_text('\n'.join(defs)+'\n','utf-8')
(s.Q/'FIXTURE-ENUM-CONSTANTS.json').write_text(json.dumps(enum_names,indent=2)+'\n','utf-8');cases=[]
for kind,rid in [('Device',0x228),('Project',0x22b),('Zombie',0x234)]:
 en=enum_names[kind+'Type'];values=[int(k)for k in en if int(k)>=0][:7];assert len(values)>=5
 patterns=[[],[values[0]],[values[1],values[3]],[values[0],values[2],values[5]],values]
 for n,vals in enumerate(patterns):
  for existing in [[],[90,None,92]]:
   for mode in ['normal','destroyed-first','sparse-id','duplicate-id']:
    loads=[]
    for k,v in enumerate(vals):
     if n%2==0 and k==0:continue
     loads.append(dict(name=en[str(v)],id=(2*k+2 if mode=='sparse-id'else 4 if mode=='duplicate-id'else v),destroyed=(mode=='destroyed-first'and k==0)))
    cases.append(dict(name=kind+'-'+str(n)+'-'+str(len(existing))+'-'+mode,token=s.tok(rid),kind=kind,mode='normal',values=vals,existing=existing,loads=loads))
 if kind=='Device':
  cases.append(dict(name='Device-id-changes-in-presence-api',token=s.tok(rid),kind=kind,mode='id-callback',values=[2],existing=[],loads=[dict(name=en['2'],id=2)]))
  cases.append(dict(name='Device-static-list-replaced-by-load-api',token=s.tok(rid),kind=kind,mode='replace-static',values=[4],existing=[],loads=[dict(name=en['4'],id=4)]))
  cases.append(dict(name='Device-load-throws-finally-retained',token=s.tok(rid),kind=kind,mode='throw-load',values=[2],existing=[],loads=[],native_unwind='UNSUPPORTED_WINDOWS_SEH_NOT_MODELED'))
for mode in ['normal','no-manager','dead-manager','no-board','dead-board']:
 cases.append(dict(name='Plant-gate-'+mode,token=s.tok(0x229),kind='Plant',mode=mode,existing=[90,None,92],cards=[],loads=[]))
for mode,cards,existing in [
 ('normal',[],[]),('normal',[dict(id=0,type=0)],[]),('normal',[dict(id=4,type=0),dict(id=1,type=1)],[]),('normal',[dict(id=1,type=0),dict(id=1,type=1)],[]),('normal',[dict(id=2,type=1)],[90,None,92]),('throw-load',[dict(id=2,type=0)],[])]:
 en=enum_names['PlantType'];loads=[dict(name=en[str(i)],id=17)for i in[0,1]]
 cases.append(dict(name='Plant-bank-'+str(len(cases)),token=s.tok(0x229),kind='Plant',mode=mode,existing=existing,cards=cards,loads=loads,**({'native_unwind':'UNSUPPORTED_WINDOWS_SEH_NOT_MODELED'}if mode=='throw-load'else{})))
for bank in[False,True]:
 for group in['null','live','destroyed']:
  cases.append(dict(name='OnHand-'+str(bank)+'-'+group,token=s.tok(0x3a4),kind='Plant',mode='normal',onBank=bank,group=group))
(s.Q/'CASES.json').write_text(json.dumps(cases,indent=2)+'\n','utf-8');print(json.dumps(dict(cases=len(cases),by_token={t:sum(q['token']==t for q in cases)for t in sorted({q['token']for q in cases})},unmodeled_native_unwind=sum('native_unwind'in q for q in cases))))
