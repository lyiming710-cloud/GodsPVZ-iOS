"""Read raw PC field/type flags with image and token/owner binding; no repairs/tests."""
from pathlib import Path
import hashlib,json,struct,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import pefile,dnfile
I=ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc';b=(I/'global-metadata.dat').read_bytes();raw=(I/'GameAssembly.dll').read_bytes();pcsha=hashlib.sha256(raw).hexdigest();metasha=hashlib.sha256(b).hexdigest()
assert pcsha=='9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d' and metasha=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9'
p=pefile.PE(data=raw);base=p.OPTIONAL_HEADER.ImageBase
n=lambda va,c:p.get_data(va-base,c);u=lambda a,o=0:struct.unpack_from('<I',a,o)[0];q=lambda a,o=0:struct.unpack_from('<Q',a,o)[0]
reg=0x1818c6d00;pairs=[(q(n(reg+16*i,16)),q(n(reg+16*i,16),8)) for i in range(8)];types_count,types_ptr=pairs[3];tdo=u(b,160);tdsize=u(b,164);fo=u(b,96);so=u(b,24);io=u(b,168);isz=u(b,172);st=lambda i:b[so+i:b.index(0,so+i)].decode('utf-8');assert pairs[5][0]==pairs[6][0]==tdsize//88==7696 and types_count==27557
images=[dict(name=st(u(b,io+40*i)),start=u(b,io+40*i+8),count=u(b,io+40*i+12)) for i in range(isz//40)];image=next(x for x in images if x['name']=='Assembly-CSharp.dll');assert image=={'name':'Assembly-CSharp.dll','start':5088,'count':319}
candidate=W/'startup-r20-sites100/authored3.dll';data=candidate.read_bytes();assert hashlib.sha256(data).hexdigest()=='d887b370c95c2966dc40d80648d85c286bb42d85004c32d095f64f004e095b37';managed=dnfile.dnPE(data=data);rows=[];type_rows=[]
for index in range(image['start'],image['start']+image['count']):
    t=tdo+88*index;token=u(b,t+84);name=st(u(b,t));ns=st(u(b,t+4));mt=managed.net.mdtables.TypeDef.rows[(token&0xffffff)-1];assert str(mt.TypeName)==name and str(mt.TypeNamespace)==ns,(index,name,mt.TypeName)
    original=u(b,t+28);current=mt.struct.Flags;tr=dict(type=name,namespace=ns,type_token=hex(token),native_type_definition_file_offset=t,original_flags=original,current_flags=current,flags_differ=original!=current)
    if name in ['System0','System1','System3','HPUIController_Zombie','Element','ElementManager','Damage']:
        parent_index=u(b,t+16);assert parent_index<types_count;at=q(n(types_ptr+8*parent_index,8));bits=u(n(at+8,4));kind=(bits>>16)&255
        if kind in [0x11,0x12]:
            parentdef=q(n(at,8));assert parentdef<tdsize//88;pt=tdo+88*parentdef;pn=st(u(b,pt));pns=st(u(b,pt+4));current_parent=mt.Extends.row
            tr.update(original_parent=('.'.join([pns,pn]) if pns else pn),current_parent=('.'.join([str(current_parent.TypeNamespace),str(current_parent.TypeName)]) if str(current_parent.TypeNamespace) else str(current_parent.TypeName)),original_parent_type_bytes=n(at,16).hex());tr['parent_same']=tr['original_parent']==tr['current_parent']
    type_rows.append(tr)
    for k in range(struct.unpack_from('<H',b,t+68)[0]):
        at=fo+12*(u(b,t+32)+k);fname=st(u(b,at));ftoken=u(b,at+8);findex=u(b,at+4);assert findex<types_count;native_type=q(n(types_ptr+8*findex,8));flags=u(n(native_type+8,4));attrs=flags&65535;mf=managed.net.mdtables.Field.rows[(ftoken&0xffffff)-1]
        assert str(mf.Name)==fname and any(x.row is mf for x in mt.FieldList),(name,fname,mf.Name)
        rows.append(dict(type=name,namespace=ns,type_token=hex(token),field=fname,field_token=hex(ftoken),native_field_definition_file_offset=at,native_field_definition_bytes=b[at:at+12].hex(),native_type_index=findex,native_il2cpp_type_va=hex(native_type),native_type_bytes=n(native_type,16).hex(),original_attrs=attrs,current_attrs=mf.struct.Flags,notserialized_original=bool(attrs&0x80),notserialized_current=bool(mf.struct.Flags&0x80),flags_differ=attrs!=mf.struct.Flags))
result=dict(scope='READONLY_ORIGINAL_PC_FIELD_AND_TYPE_FLAGS_FROM_RAW_METADATAREGISTRATION_NO_CANDIDATE_CHANGE',candidate_sha256=hashlib.sha256(data).hexdigest(),pc_sha256=pcsha,metadata_sha256=metasha,registration=hex(reg),registration_raw=n(reg,128).hex(),original_image=image,mapped_fields=len(rows),field_attribute_differences=sum(r['flags_differ'] for r in rows),notserialized_differences=sum(r['notserialized_original']!=r['notserialized_current'] for r in rows),mapped_types=len(type_rows),type_flag_differences=sum(r['flags_differ'] for r in type_rows),type_rows=type_rows,rows=rows,no_game_changes=True,not_a_runtime_or_build_result=True)
(Q/'READONLY-FIELD-AND-TYPE-ATTRIBUTES.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in result.items() if k not in ['rows','type_rows','registration_raw']}));print(json.dumps([r for r in type_rows if 'original_parent' in r]));print(json.dumps([r for r in type_rows if r['flags_differ']]))
