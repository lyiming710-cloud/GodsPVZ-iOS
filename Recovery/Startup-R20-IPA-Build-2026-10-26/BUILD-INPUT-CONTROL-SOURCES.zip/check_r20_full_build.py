"""Physical build-input and export-binding guards; no fake game qualification."""
from pathlib import Path
import importlib.util,json,shutil,sys,tempfile
sys.dont_write_bytecode=True
from archive_support import sha,js,pack,manifest
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';D=R/'Recovery/Startup-R20-IPA-Build-2026-10-26';actions=R/'scripts/actions';sys.path.insert(0,str(actions))
import validate_startup_r20_build_inputs as build
import startup_r20_export_binding as export
positive=build.validate();assert positive['test_build_allowed'] and positive['remaining_runtime_profiles']==25 and positive['candidate_sha256']==build.CANDIDATE
root=Path(tempfile.mkdtemp(prefix='r20-build-guard-controls-',dir=W)).resolve();assert root.is_relative_to(W.resolve());results=[]
try:
    for name,expected in [('wrong_editor_candidate','Wrong actual Editor candidate/run'),('zero_frames','Real startup probe did not pass'),('missing_component','Real asset binding audit did not pass')]:
        target=root/name;shutil.copytree(build.EDITOR,target);p=target/'ACTUAL-EDITOR-READBACK.json';j=json.loads(p.read_bytes())
        if name=='wrong_editor_candidate':j['candidate_sha256']='0'*64
        elif name=='zero_frames':j['startup']['frames']=0
        else:j['asset']['missing_components']=1
        js(p,j);manifest(target);error=None
        try:build.validate_editor(target)
        except ValueError as e:error=str(e)
        assert error and expected in error,(name,error)
        results.append(dict(name=name,kind='PHYSICAL_REHASHED_EDITOR_EVIDENCE',rejected=True,error=error,outer_manifest_recomputed=True))
    x=root/'synthetic-export-binding-only';source=x/'Il2CppOutputProject/Source/il2cppOutput';source.mkdir(parents=True);(x/'Data/Managed/Metadata').mkdir(parents=True);(x/'Unity-iPhone.xcodeproj').mkdir()
    (x/'Data/Managed/Metadata/global-metadata.dat').write_bytes(b'SYNTHETIC_TOOL_BINDING_CONTROL_NOT_GAME_METADATA')
    (x/'Unity-iPhone.xcodeproj/project.pbxproj').write_bytes(b'SYNTHETIC_TOOL_BINDING_CONTROL_NOT_A_PROJECT')
    for name in ['GodsPVZRuntime1.cpp','GenericMethods.cpp','Registration.c']:(source/name).write_bytes(b'// synthetic binding-only fixture\n')
    candidate=W/'startup-r20-sites100/authored3.dll';binding=export.create(x,candidate,'guard-fixture-head');assert binding['candidate_sha256']==build.CANDIDATE and len(binding['files'])==5
    # Only the binding algorithm is exercised. These synthetic bytes are never
    # called a real export, passed to a compiler, or used as game evidence.
    p=source/'GenericMethods.cpp';before=p.read_bytes();p.write_bytes(before+b'changed\n');error=None
    try:export.validate(x,'guard-fixture-head')
    except ValueError as e:error=str(e)
    assert error and 'Changed export file:' in error;results.append(dict(name='changed_generated_source',kind='SYNTHETIC_EXPORT_BINDING_ONLY',rejected=True,error=error));p.write_bytes(before)
    extra=source/'Omitted.cpp';extra.write_bytes(b'new source');error=None
    try:export.validate(x,'guard-fixture-head')
    except ValueError as e:error=str(e)
    assert error and 'Incomplete/duplicate exported file binding' in error;results.append(dict(name='unlisted_generated_source',kind='SYNTHETIC_EXPORT_BINDING_ONLY',rejected=True,error=error));extra.unlink()
    error=None
    try:export.validate(x,'wrong-head')
    except ValueError as e:error=str(e)
    assert error and 'Export candidate/workflow binding mismatch' in error;results.append(dict(name='wrong_export_workflow_head',kind='SYNTHETIC_EXPORT_BINDING_ONLY',rejected=True,error=error))
finally:
    assert root.resolve().is_relative_to(W.resolve());shutil.rmtree(root)
report=dict(scope='BUILD_INPUT_AND_BYTE_BINDING_GUARDS_ONLY_NO_UNITY_OR_GAME_TEST',positive_actual_evidence=positive,negative_controls=len(results),rejected=len(results),controls=results,
    synthetic_export_never_compiled=True,no_game_dll_changed=True,unchanged_real_compiler_flags=True,ipa=None)
js(D/'BUILD-INPUT-CONTROLS.json',report)
files=[actions/'validate_startup_r20_build_inputs.py',actions/'startup_r20_export_binding.py',actions/'prepare_startup_r20_unity.py',Path(__file__),W/'archive_support.py']
pack(D/'BUILD-INPUT-CONTROL-SOURCES.zip',[(p.name,p.read_bytes()) for p in files]);manifest(D);print(json.dumps(report,indent=2))
