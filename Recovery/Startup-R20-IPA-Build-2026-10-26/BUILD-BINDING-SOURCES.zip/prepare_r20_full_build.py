"""Compose the existing real Editor/export/Apple packaging stages for exact R20."""
from pathlib import Path
import ast,json
from archive_support import sha,js,pack,manifest
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';D=R/'Recovery/Startup-R20-IPA-Build-2026-10-26';assert not (D/'DERIVATION.json').exists();D.mkdir(exist_ok=True)
(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text\n*.md -text\n*.yml -text\n*.zip -text\n')
rows=[];files=[]
derivations=[('bulk401_export_binding.py','startup_r20_export_binding.py',[
 ('from prepare_bulk401_unity import CANDIDATE','from prepare_startup_r20_unity import CANDIDATE'),('bulk401-export-binding.json','startup-r20-export-binding.json'),('BULK401_EXPORT_BINDING_PASS','STARTUP_R20_EXPORT_BINDING_PASS')]),
 ('audit_bulk401_real_export.py','audit_startup_r20_real_export.py',[
 ('from bulk401_export_binding import validate','from startup_r20_export_binding import validate')]),
 ('package_bulk401_ipa.py','package_startup_r20_ipa.py',[
 ('from bulk401_export_binding import validate as validate_binding','from startup_r20_export_binding import validate as validate_binding'),('GodsPVZ_1.0.2_bulk401_unsigned.ipa','GodsPVZ_1.0.2_startup_r20_unsigned.ipa')])]
for source,dest,replacements in derivations:
    p=R/'scripts/actions'/source;q=R/'scripts/actions'/dest;before=p.read_bytes();s=before.decode().replace('\r\n','\n')
    for a,b in replacements:assert a in s;s=s.replace(a,b)
    if q.exists():assert q.read_text('utf-8')==s,'Refuse to overwrite unrelated partial source'
    ast.parse(s);q.write_bytes(s.encode());rows.append(dict(parent=source,parent_sha256=sha(before),derived=dest,derived_sha256=sha(q.read_bytes()),replacements=[dict(before=a,after=b) for a,b in replacements],newlines_normalized_to_lf=True,algorithm_and_assertions_unchanged=True));files.extend([(p.relative_to(R).as_posix(),before),(q.relative_to(R).as_posix(),q.read_bytes())])
original=R/'.github/workflows/bulk401-startup-runtime-gate.yml';old=original.read_bytes();(D/'PARENT-BULK401-FULL-WORKFLOW.yml').write_bytes(old)
diag=R/'.github/workflows/startup-r20-editor-diagnostic.yml';s=diag.read_text('utf-8');base=old.decode().replace('\r\n','\n')
s=s.replace('name: Startup R20 restricted real Editor and shader diagnostic','name: Startup R20 exact candidate - unsigned iOS test build')
assert s.count('  workflow_dispatch:\n')==1;s=s.replace('  workflow_dispatch:\n','''  workflow_dispatch:
    inputs:
      audit_only:
        description: Run actual Editor diagnosis without exporting or linking an IPA
        type: boolean
        default: true
        required: true
''',1)
s=s.replace('group: startup-r20-editor-diagnostic','group: startup-r20-real-ios-test-build')
marker='      - name: Validate current R20 byte and evidence binding before large setup\n';assert marker in s
s=s.replace(marker,'      - name: Require exact current candidate and actual Editor proof for test build\n        run: python3 scripts/actions/validate_startup_r20_build_inputs.py > "$RUNNER_TEMP/R20-BUILD-INPUTS.json"\n'+marker,1)
a=base.index('  apple_preflight:\n');b=base.index('  export:\n',a);apple_preflight=base[a:b]
assert s.count('  export:\n')==1;s=s.replace('  export:\n',apple_preflight+'  export:\n',1).replace('needs: [conversion_binding, editor_helper_preflight]','needs: [conversion_binding, editor_helper_preflight, apple_preflight]')
a=base.index('      - name: Export unsigned iOS Xcode project');b=base.index('      - name: Return Personal seat',a);export=base[a:b]
export=export.replace('stage9-bulk401-ios','stage9-startup-r2').replace('bulk401_export_binding.py','startup_r20_export_binding.py').replace('bulk401-export-binding.json','startup-r20-export-binding.json').replace('with bulk401 candidate','with exact R20 candidate').replace('GodsPVZ-Stage9-bulk401-unsigned-Xcode','GodsPVZ-Startup-R20-unsigned-Xcode').replace('bulk401_runtime_qualification','r20_full_game_qualification').replace('bulk401_direct_il2cpp_conversion','r20_portable_il2cpp_conversion')
marker='      - name: Return Personal seat';assert s.count(marker)==1;s=s.replace(marker,export+marker,1)
a=base.index('      - name: Upload unsigned Xcode project archive');tail=base[a:]
for a,b in [('stage9-bulk401-ios','stage9-startup-r2'),('GodsPVZ-Stage9-bulk401-unsigned-Xcode','GodsPVZ-Startup-R20-unsigned-Xcode'),('bulk401_export_binding.py','startup_r20_export_binding.py'),('audit_bulk401_real_export.py','audit_startup_r20_real_export.py'),('package_bulk401_ipa.py','package_startup_r20_ipa.py'),('fixed Bulk401 input','fixed R20 input'),('Bulk401-APPLE-BUILD-EVIDENCE','Startup-R20-APPLE-BUILD-EVIDENCE'),('GodsPVZ_1.0.2_bulk401_unsigned_ipa','GodsPVZ_1.0.2_startup_r20_unsigned_ipa')]:tail=tail.replace(a,b)
s+='\n'+tail
dest=R/'.github/workflows/startup-r20-real-ios-test-build.yml';assert not dest.exists();dest.write_bytes(s.encode());original.write_bytes(s.encode())
assert s.count('CODE_SIGNING_ALLOWED=NO')==1 and s.count('CODE_SIGNING_REQUIRED=NO')==1
assert 'audit_startup_r20_real_export.py' in s and 'GodsPVZCustomShaderAudit.BeginAfterStartup' in s and 'GodsPVZStartupAudit.BeginPlayProbe' in s
files.extend([(diag.relative_to(R).as_posix(),diag.read_bytes()),(dest.relative_to(R).as_posix(),dest.read_bytes()),(original.relative_to(R).as_posix(),original.read_bytes())])
for p in [R/'scripts/actions/validate_startup_r20_build_inputs.py',R/'scripts/actions/bulk401_apple_flags.py',R/'scripts/actions/bind_startup_r20_diagnostic.py']:files.append((p.relative_to(R).as_posix(),p.read_bytes()))
files.append((Path(__file__).name,Path(__file__).read_bytes()));pack(D/'BUILD-BINDING-SOURCES.zip',files)
js(D/'DERIVATION.json',dict(scope='EXACT_R20_REAL_EDITOR_EXPORT_AND_UNSIGNED_TEST_IPA_COMPOSITION',candidate_sha256='d887b370c95c2966dc40d80648d85c286bb42d85004c32d095f64f004e095b37',script_derivations=rows,parent_full_workflow_sha256=sha(old),diagnostic_workflow_sha256=sha(diag.read_bytes()),workflow_sha256=sha(dest.read_bytes()),
    original_full_export_apple_compile_package_assertions_preserved=True,existing_r20_editor_shader_and_playmode_checks_retained=True,
    actual_export_source_inventory_dynamic_all_c_and_cpp_no_exclusions=True,compiler_flags_six_controls_and_macho_metadata_checks_unchanged=True,
    code_signing_allowed=False,new_game_code_changes=0,remaining_method_profiles=25,product_acceptance=False))
js(D/'PROGRESS.json',dict(status='PREPARED_NOT_DISPATCHED',candidate_sha256='d887b370c95c2966dc40d80648d85c286bb42d85004c32d095f64f004e095b37',actual_editor_diagnostic=40224994102,unity_export='PENDING',actual_export_apple_compilation='PENDING',xcode_link='PENDING',ipa=None,ipad_acceptance=False))
(D/'README.md').write_bytes('''# R20 当前候选未签名测试IPA构建

固定输入d887b370…095b37。现有104处/8方法、精确Linux/Apple各1029源码检查及真实Editor2049帧/脚本资源/着色器读回作为构建依据。当前R19有限方法75，25个完整profile仍待完成；构建测试包不提升这些方法或全游戏/真机资格。

组合现有R20受限Editor流程和已使用的Bulk401真实导出/Apple构建：全部原包/Editor/模块/迁移/插件SHA与GUID、76项着色器编译、20项受控像素、实际MainMenu探针均保留；随后用同一精确DLL真正运行BuildIOS，绑定全部实际导出C/CPP/metadata/pbx文件到候选与工作流SHA，在Xcode链接前检查每一实际生成C/CPP。数量从实际目录普查，不排除泛型或其他源码。

两个输入相关模块仅替换候选来源/绑定模块名/产物名称；源码审核算法、Apple arm64/iPhoneOS18.5参数、六个编译控制、无签名Xcode参数、Mach-O/metadata/ZIP验证不变。注册入口bulk401-startup-runtime-gate.yml指向本次定义；audit_only默认true，实际测试包请求需明确false。不会启用签名。

本目录初始状态为准备完成，运行、导出、链接、IPA哈希与设备结论以真实回读更新。没有产物前不声称已生成IPA，构建成功也不等于iPad黑屏已解决。
'''.encode());manifest(D)
