"""Independent synthetic metadata oracle. Does not import the patcher's schemas.

Fixtures test numeric table encoding, not assembly loadability or game behavior.
Official System.Reflection.Metadata supplies a second row-width/count reader.
"""
from pathlib import Path
import struct,json,hashlib,subprocess,sys,copy
B=Path(__file__).resolve().parent;Q=B.parent;R=Q.parents[1]
DOT=R/'.local/dotnet10/dotnet.exe';PATCH=Q/'source/bin/Release/net10.0/Bulk388.dll'
SC={0:'h s g g g',1:'ResolutionScope s s',2:'i s s TypeDefOrRef @4 @6',4:'h s b',6:'i h h s b @8',8:'h h s',9:'@2 TypeDefOrRef',10:'MemberRefParent s b',11:'h HasConstant b',12:'HasCustomAttribute CustomAttributeType b',13:'HasFieldMarshal b',14:'h HasDeclSecurity b',15:'h i @2',16:'i @4',17:'b',18:'@2 @20',20:'h s TypeDefOrRef',21:'@2 @23',23:'h s b',24:'h @6 HasSemantics',25:'@2 MethodDefOrRef MethodDefOrRef',26:'s',27:'b',28:'h MemberForwarded s @26',29:'i @4',32:'i h h h h i b s s',33:'i',34:'i i i',35:'h h h h i b s s b',36:'i @35',37:'i i i @35',38:'i s b',39:'i i s s Implementation',40:'i i s Implementation',41:'@2 @2',42:'h h TypeOrMethodDef s',43:'MethodDefOrRef b',44:'@42 TypeDefOrRef'}
SC={k:v.split() for k,v in SC.items()}
# Legal (table, tag) associations; CustomAttributeType tags are 2 and 3.
CG={'TypeDefOrRef':(2,[(2,0),(1,1),(27,2)]),'HasConstant':(2,[(4,0),(8,1),(23,2)]),'HasCustomAttribute':(5,list(zip([6,4,1,2,8,9,10,0,14,23,20,17,26,27,32,35,38,39,40,42,44,43],range(22)))),'HasFieldMarshal':(1,[(4,0),(8,1)]),'HasDeclSecurity':(2,[(2,0),(6,1),(32,2)]),'MemberRefParent':(3,[(2,0),(1,1),(26,2),(6,3),(27,4)]),'HasSemantics':(1,[(20,0),(23,1)]),'MethodDefOrRef':(1,[(6,0),(10,1)]),'MemberForwarded':(1,[(4,0),(6,1)]),'Implementation':(2,[(38,0),(35,1),(39,2)]),'CustomAttributeType':(3,[(6,2),(10,3)]),'ResolutionScope':(2,[(0,0),(26,1),(35,2),(1,3)]),'TypeOrMethodDef':(1,[(2,0),(6,1)])}
def width(c,flags,counts):
 if c=='h':return 2
 if c=='i':return 4
 if c in 'sbg':return 4 if flags & {'s':1,'b':4,'g':2}[c] else 2
 if c[0]=='@':return 4 if counts.get(int(c[1:]),0)>=65536 else 2
 bits,refs=CG[c];return 4 if max(counts.get(t,0) for t,tag in refs)>=(1<<(16-bits)) else 2
def default(c):
 if c=='b':return 65530
 if c=='s':return 1
 if c=='g':return 1
 if c in ('h','i'):return 0
 if c[0]=='@':return 1
 bits,refs=CG[c];return (1<<bits)|refs[0][1]
def payload(rows,flags):
 counts={t:len(v) for t,v in rows.items()};valid=sum(1<<t for t in rows)
 out=bytearray(struct.pack('<IBBBBQQ',0,2,0,flags,1,valid,0))
 for t in sorted(rows):out+=struct.pack('<I',counts[t])
 for t in sorted(rows):
  for row in rows[t]:
   for c,v in zip(SC[t],row):out+=v.to_bytes(width(c,flags,counts),'little')
 return bytes(out)
def read(payload):
 flags=payload[6];valid=struct.unpack_from('<Q',payload,8)[0];p=24;counts={}
 for t in range(64):
  if valid>>t&1:counts[t]=struct.unpack_from('<I',payload,p)[0];p+=4
 rows={};locations={}
 for t,n in counts.items():
  rows[t]=[]
  for r in range(n):
   values=[]
   for i,c in enumerate(SC[t]):
    w=width(c,flags,counts);locations[t,r,i]=(p,w)
    if p+w>len(payload):raise ValueError('truncated column')
    values.append(int.from_bytes(payload[p:p+w],'little'));p+=w
   rows[t].append(values)
 if p!=len(payload):raise ValueError('unexpected trailing data')
 return rows,locations
def root(table,strings=32,blobs=65535,guids=16):
 ver=b'v4.0.30319\0\0';streams=[('#~',table),('#Strings',b'\0x\0'+bytes(max(0,strings-3))),('#US',b'\0'),('#GUID',bytes(guids)),('#Blob',bytes(blobs))]
 header=bytearray(struct.pack('<IHHII',0x424a5342,1,1,0,len(ver))+ver+struct.pack('<HH',0,len(streams)))
 total=len(header)+sum(8+((len(n)+1+3)//4*4) for n,b in streams);total=(total+3)//4*4
 chunks=bytearray();pos=total
 for name,data in streams:
  pad=(-pos)%4;chunks+=bytes(pad);pos+=pad
  header+=struct.pack('<II',pos,len(data))+name.encode()+bytes((-len(name))%4 or 4)
  chunks+=data;pos+=len(data)
 header+=bytes(total-len(header));return bytes(header+chunks)
def put(path,data):
 if path.exists():raise FileExistsError(path)
 path.write_bytes(data);return str(path)
def main():
 out=B/'fixtures-v2';out.mkdir(exist_ok=False);jobs=[];specs={}
 # The framework reader deliberately excludes obsolete assembly processor/OS tables.
 # Keep the first rejected attempt; test every table it actually supports here.
 base={t:[[default(c) for c in cols]] for t,cols in SC.items() if t not in (33,34,36,37)}
 def add(name,rows=None,flags=0,s=32,b=65535,g=16,append=None,expect_reject=False,damage=None):
  rows=copy.deepcopy(rows if rows is not None else base);p=payload(rows,flags);rp=out/(name+'.metadata');tp=out/(name+'.tables')
  rootpath=put(rp,root(p,32,65535,16));original=p
  if damage:p=damage(p)
  put(tp,p)
  job=dict(name=name,root=rootpath,payload=str(tp),tables=list(rows),strings=s,blobs=b,guids=g,out=str(out/(name+'.result-tables')))
  if append:job['append']=append
  jobs.append(job);expected=copy.deepcopy(rows)
  for a in append or []:expected[a['table']].append(a['values'])
  specs[name]=dict(rows=expected,flags=flags|(1 if s>=65536 else 0)|(4 if b>=65536 else 0)|(2 if g>=65536 else 0),reject=expect_reject,original=original.hex())
 for kind in ['blob','string','guid']:
  for size in [65535,65536,65537]:add(f'{kind}-{size}',**{dict(blob='b',string='s',guid='g')[kind]:size})
 add('already-wide-no-shrink',flags=7)
 add('append-high-blob',b=65540,append=[dict(table=17,token=0x11000002,values=[65536])])
 # Every coded-index threshold is exercised through a real row-count transition.
 for name,(bits,refs) in CG.items():
  table=next(t for t,tag in refs if t not in (0,32));threshold=1<<(16-bits)
  rows=copy.deepcopy(base);rows[table]=[rows[table][0][:] for _ in range(threshold-1)]
  add('coded-'+name,rows=rows,append=[dict(table=table,token=(table<<24)+threshold,values=rows[table][0])])
 for table in [4,6,8,20,23,26,35,42]:
  rows=copy.deepcopy(base);rows[table]=[rows[table][0][:] for _ in range(65535)]
  add('simple-'+str(table),rows=rows,append=[dict(table=table,token=(table<<24)+65536,values=rows[table][0])])
 add('bad-original-extra-flags',damage=lambda p:p[:6]+bytes([0x40])+p[7:],expect_reject=True)
 add('bad-original-truncated',damage=lambda p:p[:-1],expect_reject=True)
 add('bad-original-count',damage=lambda p:p[:24]+struct.pack('<I',2)+p[28:],expect_reject=True)
 add('bad-append-token',append=[dict(table=17,token=0x11000003,values=[1])],expect_reject=True)
 add('bad-column-count',append=[dict(table=17,token=0x11000002,values=[1,2])],expect_reject=True)
 add('bad-narrow-overflow',append=[dict(table=17,token=0x11000002,values=[65536])],expect_reject=True)
 add('bad-negative-heap',b=-1,expect_reject=True)
 (B/'rewrite-jobs-v2.json').write_text(json.dumps(jobs),encoding='utf-8');(B/'expected-v2.json').write_text(json.dumps(specs),encoding='utf-8')
 print(json.dumps({'jobs':len(jobs),'positive':sum(not s['reject'] for s in specs.values()),'negative':sum(s['reject'] for s in specs.values())}))
if __name__=='__main__':main()
