"""Eight original-native-backed floating-point bodies; construction only.

Restore two lost bounded switches, cached animator/hash order, native rounding
and exact float constants. No MethodDef is added or field visibility changed.
"""
from pathlib import Path
import hashlib,importlib.util,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
s=importlib.util.spec_from_file_location('metadata_writer',W/'startup-r2/construct.py');writer=importlib.util.module_from_spec(s);s.loader.exec_module(writer)
sha=lambda b:hashlib.sha256(b).hexdigest()
def comp(n):
    if n<128:return bytes([n])
    if n<16384:return (0x8000|n).to_bytes(2,'big')
    assert n<0x20000000;return (0xc0000000|n).to_bytes(4,'big')
class IL:
    def __init__(self):self.b=bytearray();self.labels={};self.patches=[]
    def emit(self,b):self.b.extend(b);return self
    def mark(self,name):assert name not in self.labels;self.labels[name]=len(self.b);return self
    def branch(self,op,label):at=len(self.b);self.emit(bytes([op])+b'\0'*4);self.patches.append((at,label));return self
    def switch(self,labels):
        at=len(self.b);self.emit(b'\x45'+struct.pack('<I',len(labels))+b'\0'*4*len(labels));self.patches.append((at,list(labels)));return self
    def arg(self,n):assert n<4;return self.emit(bytes([2+n]))
    def loc(self,n):return self.emit(bytes([0x11,n]))
    def store(self,n):return self.emit(bytes([0x13,n]))
    def op(self,n):return self.emit(bytes.fromhex(n))
    def token(self,op,token):return self.emit(bytes([op])+struct.pack('<I',token))
    def i4(self,n):return self.token(0x20,n&0xffffffff)
    def i8(self,n):return self.emit(b'\x21'+struct.pack('<q',n))
    def r4(self,value=None,bits=None):return self.emit(b'\x22'+(bytes.fromhex(bits)[::-1] if bits is not None else struct.pack('<f',value)))
    def r8(self,value):return self.emit(b'\x23'+struct.pack('<d',value))
    def finish(self):
        for at,label in self.patches:
            if isinstance(label,list):
                end=at+5+4*len(label)
                for k,name in enumerate(label):struct.pack_into('<i',self.b,at+5+4*k,self.labels[name]-end)
            else:struct.pack_into('<i',self.b,at+1,self.labels[label]-(at+5))
        return bytes(self.b)

def build(output,report):
    output=Path(output);report=Path(report);assert not output.exists() and not report.exists()
    before=(W/'startup-r12/candidate1.dll').read_bytes();assert sha(before)=='28946ce7343a4ca7479fb1a3aeb6b191bcc74aae5292a8b0a18f06c5019e1bd5';pe=dnfile.dnPE(data=before);out=bytearray(before)
    spec=json.loads((Q/'TABLE-SPECIFICATION.json').read_bytes());assert not spec['runtime_outputs_used'];targets={0xf8,0x18e,0x44e,0x602,0x607,0x835,0x863,0x887}
    def body(rid):
        row=pe.net.mdtables.MethodDef.rows[rid-1];at=pe.get_offset_from_rva(row.Rva);h=1 if before[at]&3==2 else (struct.unpack_from('<H',before,at)[0]>>12)*4;size=before[at]>>2 if h==1 else struct.unpack_from('<I',before,at+4)[0];return row,at,h,before[at+h:at+h+size]
    for rid in targets:assert sum(r.Rva==pe.net.mdtables.MethodDef.rows[rid-1].Rva for r in pe.net.mdtables.MethodDef.rows)==1,'No hidden body alias'
    cli=pe.get_offset_from_rva(pe.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress);mrva,msize=struct.unpack_from('<II',before,cli+8);mat=pe.get_offset_from_rva(mrva)
    root,streams=writer.metadata_root(before[mat:mat+msize]);values={n:b for n,_,b in streams};th,rows,tail,counts=writer.tables_decode(values['#~']);new_refs=[];new_sigs=[];changes=[];allowed=set()
    def name_index(name):
        data=name.encode()+b'\0';at=values['#Strings'].find(data)
        if at>=0 and (at==0 or values['#Strings'][at-1]==0):return at
        at=len(values['#Strings']);values['#Strings']+=data;return at
    def math_ref(name):
        for rid,row in enumerate(pe.net.mdtables.MemberRef.rows,1):
            if str(row.Name)==name and row.Signature.value==bytes.fromhex('00010d0d') and getattr(row.Class.row,'TypeName',None)=='Math' and getattr(row.Class.row,'TypeNamespace',None)=='System':return 0xa000000|rid
        floor=next((rid,row) for rid,row in enumerate(pe.net.mdtables.MemberRef.rows,1) if str(row.Name)=='Floor' and row.Signature.value==bytes.fromhex('00010d0d') and getattr(row.Class.row,'TypeName',None)=='Math')
        parent=rows[10][floor[0]-1];rows[10].append([parent[0],name_index(name),parent[2]]);token=0xa000000|len(rows[10]);new_refs.append(dict(token=f'0x{token:08X}',name=name,signature='00010d0d',owner_coded_index=parent[0]));return token
    floor=math_ref('Floor');ceiling=math_ref('Ceiling');truncate=math_ref('Truncate')
    def signature(rid,extra):
        _,at,h,_=body(rid);assert h==12;token=int.from_bytes(before[at+8:at+12],'little');old=pe.net.mdtables.StandAloneSig.rows[(token&0xffffff)-1].Signature.value;assert old[0]==7 and old[1]<128
        new=bytes([7,old[1]+len(extra)])+old[2:]+b''.join(extra);idx=len(values['#Blob']);values['#Blob']+=comp(len(new))+new;rows[17].append([idx]);newtoken=0x11000000|len(rows[17]);new_sigs.append(dict(method=f'0x{0x6000000|rid:08X}',old_token=f'0x{token:08X}',new_token=f'0x{newtoken:08X}',old=old.hex(),new=new.hex(),appended_local_encodings=[x.hex() for x in extra]));return newtoken
    def patch(rid,offset,expected,new,why):
        _,at,h,code=body(rid);assert len(expected)==len(new) and code[offset:offset+len(expected)]==expected;loc=at+h+offset;out[loc:loc+len(new)]=new;allowed.update(range(loc,loc+len(new)));changes.append(dict(token=f'0x{0x6000000|rid:08X}',kind='fixed_width',offset=offset,file_offset=loc,before=expected.hex(),after=new.hex(),reason=why))
    for rid,offsets in [(0xf8,[107]),(0x835,[70]),(0x863,[0,15]),(0x887,[0,15])]:
        for at in offsets:patch(rid,at,bytes.fromhex('2000000000'),bytes.fromhex('2200000000'),'Original native XORPS is positive float zero')
    patch(0xf8,85,b'\x02\x7b'+struct.pack('<I',0x04000110),bytes.fromhex('110600000000'),'Use captured V6; original native reads value once after testing multi')
    # Full DamageText.Update: capture animator after time read 1, hash before
    # time read 2. NaN follows the nonzero path, as native JP || JNE requires.
    _,_,_,old=body(0x602)
    def tok(code,at,op):assert code[at]==op;return int.from_bytes(code[at+1:at+5],'little')
    anim=tok(old,132,0x7b);speed_hash=tok(old,10,0x7e);time=tok(old,70,0x28);set_float=tok(old,145,0x28)
    afield=pe.net.mdtables.Field.rows[(anim&0xffffff)-1];assert str(afield.Name)=='animator' and afield.Signature.value[0]==6
    damage_sig=signature(0x602,[afield.Signature.value[1:]])
    b=IL().token(0x28,time).store(0).arg(0).token(0x7b,anim).store(8).loc(0).r4(0).op('fe01').branch(0x39,'nonzero')
    b.token(0x7e,speed_hash).store(4).r4(0).store(3).branch(0x38,'apply')
    b.mark('nonzero').token(0x7e,speed_hash).store(4).r4(1).token(0x28,time).op('5b').store(3)
    b.mark('apply').loc(8).loc(4).loc(3).token(0x6f,set_float).op('2a');damage=b.finish()
    _,at,h,oldcode=body(0x602);assert h==12 and len(damage)<=len(oldcode);out[at+h:at+h+len(damage)]=damage;struct.pack_into('<I',out,at+4,len(damage));struct.pack_into('<I',out,at+8,damage_sig);allowed.update(range(at+h,at+h+len(damage)));allowed.update(range(at+4,at+12));changes.append(dict(token='0x06000602',kind='inplace_complete_body',file_offset=at,old_code_size=len(oldcode),new_code_size=len(damage),new_code=damage.hex(),local_sig=f'0x{damage_sig:08X}',unused_old_slot_preserved=True))
    # Static device CD switch: original unsigned (id - 4) selects 11 entries.
    b=IL().arg(0).i4(4).op('59').switch(['device'+str(n) for n in range(11)]).r4(0).op('2a')
    for n,row in enumerate(spec['device_constants']):b.mark('device'+str(n)).r4(bits=row['constant']['bits']).op('2a')
    device=b.finish()
    # BoardEntry's bounded type table, then finite level partitions or level*10.
    b=IL().arg(0).token(0x7b,0x040007fa).switch(['group'+str(n) for n in spec['board_type_selectors']]).r4(0).op('2a')
    for n,group in enumerate(spec['board_groups']):
        b.mark('group'+str(n));lookup=group['level_constants'];formula=group['formula']
        if formula:b.arg(0).token(0x7b,0x040007fb).op('6b').r4(bits=formula['factor']['bits']).op('5a2a')
        elif not lookup:b.r4(0).op('2a')
        else:
            maximum=max(int(x) for x in lookup);b.arg(0).token(0x7b,0x040007fb).i4(1).op('59').switch([f'g{n}level{k}' for k in range(1,maximum+1)]).r4(0).op('2a')
            for k in range(1,maximum+1):b.mark(f'g{n}level{k}').r4(bits=lookup.get(str(k),dict(bits='00000000'))['bits']).op('2a')
    board=b.finish()
    # Native custom rounding is not equivalent to ideal MathF.Round at every
    # half-neighbor. Preserve float32 +/-0.5 before Floor/Ceiling and tie parity.
    _,_,_,old=body(0x44e);a1=tok(old,6,0x7b);a2=tok(old,62,0x7b);buff=tok(old,77,0x7b);text=tok(old,86,0x72);increment=tok(old,91,0x28);max_=tok(old,140,0x28)
    tou_sig=signature(0x44e,[b'\x0d',b'\x0c'])
    b=IL().arg(1).i4(1).op('fe01').branch(0x3a,'armor1').arg(1).i4(2).op('fe01').branch(0x3a,'armor2').r4(0).branch(0x38,'base')
    b.mark('armor1').arg(0).token(0x7b,a1).branch(0x38,'base');b.mark('armor2').arg(0).token(0x7b,a2)
    b.mark('base').store(5).arg(0).token(0x7b,buff).loc(5).token(0x72,text).token(0x6f,increment).store(6).loc(6).loc(5).op('586b').store(7)
    b.loc(7).op('6c').token(0x28,truncate).store(11).loc(7).r4(0).op('fe05').branch(0x3a,'negative')
    b.loc(7).op('6c').loc(11).op('59').r8(0.5).op('fe01').branch(0x3a,'positive_tie')
    b.loc(7).r4(0.5).op('586b').store(12).loc(12).op('6c').token(0x28,floor).op('6b').branch(0x38,'max')
    b.mark('positive_tie').loc(11).op('6a').i8(1).op('5f').i8(0).op('fe01').branch(0x3a,'even')
    b.loc(11).op('6b').r4(1).op('586b').branch(0x38,'max')
    b.mark('negative').loc(7).op('6c').loc(11).op('59').r8(-0.5).op('fe01').branch(0x3a,'negative_tie')
    b.loc(7).r4(0.5).op('596b').store(12).loc(12).op('6c').token(0x28,ceiling).op('6b').branch(0x38,'max')
    b.mark('negative_tie').loc(11).op('6a').i8(1).op('5f').i8(0).op('fe01').branch(0x3a,'even')
    b.loc(11).op('6b').r4(1).op('596b').branch(0x38,'max');b.mark('even').loc(11).op('6b')
    b.mark('max').r4(0).token(0x28,max_).op('2a');tou=b.finish()
    last=pe.sections[-1];assert last.Name.rstrip(b'\0')==b'.n29meta' and last.Characteristics==0x40000040 and last.PointerToRawData+last.SizeOfRawData==len(before)
    for rid,code,local_token in [(0x18e,device,0),(0x607,board,0),(0x44e,tou,tou_sig)]:
        start=writer.align(len(out),4);out.extend(b'\0'*(start-len(out)));rva=last.VirtualAddress+start-last.PointerToRawData;oldrow,at,h,oldcode=body(rid);flags=0x3013 if local_token else 0x3003
        out.extend(struct.pack('<HHII',flags,3 if rid==0x44e else 2,len(code),local_token));out.extend(code);rows[6][rid-1][0]=rva;changes.append(dict(token=f'0x{0x6000000|rid:08X}',kind='relocated_complete_body',old_rva=hex(oldrow.Rva),new_rva=hex(rva),file_offset=start,old_code_size=len(oldcode),new_code_size=len(code),new_code=code.hex(),local_sig=f'0x{local_token:08X}',old_code_slot_preserved=True))
    values['#~']=writer.tables_encode(th,rows,tail,counts);metadata=bytearray(root)
    for name,header,_ in streams:
        start=writer.align(len(metadata),4);metadata.extend(b'\0'*(start-len(metadata)));struct.pack_into('<II',metadata,header,start,len(values[name]));metadata.extend(values[name])
    start=writer.align(len(out),4);out.extend(b'\0'*(start-len(out)));out.extend(metadata);end=len(out);raw_size=writer.align(end-last.PointerToRawData,pe.OPTIONAL_HEADER.FileAlignment);out.extend(b'\0'*(last.PointerToRawData+raw_size-len(out)))
    sh=last.get_file_offset();opt=pe.OPTIONAL_HEADER.get_file_offset();updates={sh+8:end-last.PointerToRawData,sh+16:raw_size,opt+8:pe.OPTIONAL_HEADER.SizeOfInitializedData+raw_size-last.SizeOfRawData,opt+56:writer.align(last.VirtualAddress+end-last.PointerToRawData,pe.OPTIONAL_HEADER.SectionAlignment),opt+64:0,cli+8:last.VirtualAddress+start-last.PointerToRawData,cli+12:len(metadata)}
    for at,value in updates.items():struct.pack_into('<I',out,at,value);allowed.update(range(at,at+4))
    assert all(a==b or i in allowed for i,(a,b) in enumerate(zip(before,out)));output.write_bytes(out)
    result=dict(scope='EIGHT_NATIVE_BACKED_BODIES_CONSTRUCTED_NOT_YET_RUNTIME_QUALIFIED',parent_sha256=sha(before),candidate_sha256=sha(out),bytes=len(out),method_targets=8,unchanged_methoddefs=2309,new_memberrefs=new_refs,new_local_signatures=new_sigs,changes=changes,table_spec_sha256=sha((Q/'TABLE-SPECIFICATION.json').read_bytes()),header_updates={str(k):v for k,v in updates.items()},runtime='PENDING',unity_or_ipa=False)
    report.write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in result.items() if k not in ['changes','header_updates','new_local_signatures']},indent=2))
if __name__=='__main__':build(*sys.argv[1:])
