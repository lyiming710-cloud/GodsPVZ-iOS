from pathlib import Path
import collections,hashlib,json,struct,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];O=Q/'runtime-results';sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
from cil_contracts import check
raw=(Q/'candidate1.dll').read_bytes();digest=hashlib.sha256(raw).hexdigest();assert digest=='5454887dc125cf56b7de5fc6079441075b91972e64db40e52f70d1129a87c73f';dot=ROOT/'.local/dotnet10/dotnet.exe';fixture=Q/'runtime/bin/Release/net10.0/Fixture.dll';native=json.loads((O/'NATIVE.json').read_bytes());cil=json.loads((O/'ACTUAL-CIL.json').read_bytes());neg=json.loads((O/'MANAGED-NEGATIVE.json').read_bytes());a=native['results'];b=cil['results'];assert cil['candidate_sha256']==neg['candidate_sha256']==digest and len(a)==len(b)==168;diff=[dict(native=x,cil=y) for x,y in zip(a,b) if x!=y];(O/'BASELINE.json').write_bytes((json.dumps(dict(cases=len(a),differences=diff),indent=2)+'\n').encode());assert not diff and len(cil['closed_jit'])==6 and all(r['status']=='JIT_PREPARED_NO_EXECUTION' for r in cil['closed_jit']) and all(n>0 for n in native['executed_original_entries'].values())
nc=json.loads((O/'NEGATIVE-CASES.json').read_bytes());assert len(nc)==len(neg['results'])==72
for c,r in zip(nc,neg['results']):
    mask=c['mask'];assert r['error']=='System.ArgumentOutOfRangeException' and r['param']=='capacity' and r['message'].startswith('capacity must be >= 0');assert r['state']==dict(list_same_old=True,dict_same_old=True,comp_same_old=True,list_size=7 if mask&1 else None,list_data_length=2 if mask&1 else None,list_data_same_shared=False if mask&1 else None,dict_count=3 if mask&2 else None,comp_same_default=False,dict_comparer_same_default=False if mask&2 else None)
pe=dnfile.dnPE(data=raw);methods={int(m['token'],16)&0xffffff:m for m in json.loads((Q/'METHOD-CIL.json').read_bytes())['methods']};mutants={}
def body(data,rid):
    at=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[rid-1].Rva);h=(struct.unpack_from('<H',data,at)[0]>>12)*4;n=struct.unpack_from('<I',data,at+4)[0];return at,h,data[at+h:at+h+n]
def replace(name,rid,code):
    parent=(W/'startup-r15/candidate1.dll').read_bytes();at,h,old=body(raw,rid);assert len(code)<=len(body(parent,rid)[2]);data=bytearray(raw);data[at+h:at+h+len(code)]=code;struct.pack_into('<I',data,at+4,len(code));mutants[name]=bytes(data)
def rewrite(name,rid,replacements):
    at,h,old=body(raw,rid);ins=methods[rid]['instructions'];new=bytearray()
    for k,i in enumerate(ins):p=i['offset'];end=ins[k+1]['offset'] if k+1<len(ins) else len(old);new.extend(replacements.get(p,old[p:end]))
    replace(name,rid,bytes(new))
for rid,label in [(0x8d2,'default'),(0x8d3,'capacity')]:
    for i in methods[rid]['instructions']:
        if i['opcode']=='stfld':field=i['operand']['identity'].split('::')[-1];rewrite(label+'-omits-'+field,rid,{i['offset']:bytes.fromhex('2626')})
    at,h,code=body(raw,rid);width=12 if rid==0x8d3 else 11;assert len(code)==6+2*width+11+1;replace(label+'-dictionary-before-list',rid,code[:6]+code[6+width:6+2*width]+code[6:6+width]+code[6+2*width:])
ins=methods[0x8d3]['instructions'];calls=[(k,i) for k,i in enumerate(ins) if i['opcode']=='newobj'];li,lc=calls[0];di,dc=calls[1];rewrite('capacity-list-always-default',0x8d3,{ins[li-1]['offset']:b'\0',lc['offset']:bytes.fromhex('733505000a')});rewrite('capacity-dictionary-always-zero',0x8d3,{ins[di-1]['offset']:b'\x16'})
parent=(W/'startup-r15/candidate1.dll').read_bytes();old=bytearray(raw)
for rid in methods:at,h,code=body(parent,rid);old[at+h:at+h+len(code)]=code;struct.pack_into('<I',old,at+4,len(code))
mutants['historical-placeholder-constructors-restored']=bytes(old);controls=[];export=ROOT/'audit/bulk250-r1-evidence-39702928368/bulk250-r1-run/tools_bin/CilExporter/bin/CilExporter.dll';sup=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support';known_blind={'default-dictionary-before-list','capacity-dictionary-always-zero'}
for name,data in mutants.items():
    dll=O/(name+'.dll');dll.write_bytes(data);out=[]
    for group,cases in [('normal','CASES.json'),('negative','NEGATIVE-CASES.json')]:
        output=O/(name+'-'+group+'.json');p=subprocess.run([str(dot),str(fixture),str(dll),str(O/cases),str(output)],capture_output=True,timeout=40);(O/(name+'-'+group+'.stdout.log')).write_bytes(p.stdout);(O/(name+'-'+group+'.stderr.log')).write_bytes(p.stderr);assert p.returncode==0,(name,p.returncode,p.stderr[-700:]);r=json.loads(output.read_bytes());assert r['candidate_sha256']==hashlib.sha256(data).hexdigest();out.append(r)
    normal=sum(x!=y for x,y in zip(a,out[0]['results']));negative=sum(x!=y for x,y in zip(neg['results'],out[1]['results']));assert len(out[0]['results'])==168 and len(out[1]['results'])==72
    file=O/(name+'-cil.json');p=subprocess.run([str(dot),str(export),str(dll),str(file),str(sup),'0x060008D2,0x060008D3'],capture_output=True);assert p.returncode==0;bad=[]
    for m in json.loads(file.read_text('utf-8-sig'))['methods']:
        try:check(m)
        except AssertionError as e:bad.append(dict(token=m['token'],reason=str(e)))
    assert bad,name
    if name in known_blind:assert normal+negative==0,name
    else:assert normal+negative>0,name
    controls.append(dict(name=name,mutant_sha256=hashlib.sha256(data).hexdigest(),normal_runtime_differences=normal,managed_negative_differences=negative,exact_cil_callee_order_contract_rejected=True,contract_failures=bad,runtime_alone_adequate=name not in known_blind))
result=dict(scope='TWO_COMPLETE_ASSOC_CTORS_ALL_FOUR_PC_NATIVE_VARIANTS_VS_DIRECT_ACTUAL_DLL_CLOSED_CLR',candidate_sha256=digest,pass_=True,native_cil_cases=168,managed_negative_cases=72,closed_contexts=['System.Int32','System.String','24_BYTE_VALUE_TYPE'],closed_jit_prepared=6,executed_original_entries=native['executed_original_entries'],actual_original_list_constructor_helpers_executed=True,normal_differences=[],negative_controls=controls,runtime_blind_contract_controls=sorted(known_blind),readonly_or_visibility_changed=False,real_dictionary_capacity_allocator_and_comparer_implementation=False,native_exception_execution=False,whole_game=False,ipa=None);(O/'RESULT.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in result.items() if k!='negative_controls'},indent=2));print('Physical controls',len(controls))
