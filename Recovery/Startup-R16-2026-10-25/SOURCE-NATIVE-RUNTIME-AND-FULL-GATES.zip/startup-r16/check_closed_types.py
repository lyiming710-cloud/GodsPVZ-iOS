"""Finite closed models plus actual authenticated mscorlib interface rows."""
from pathlib import Path
import copy,hashlib,importlib.util,json,re,sys
Q=Path(__file__).resolve().parent;ROOT=Q.parents[2];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
sdk=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support/mscorlib.dll';p=dnfile.dnPE(data=sdk.read_bytes());rid=next(k for k,r in enumerate(p.net.mdtables.TypeDef.rows,1) if str(r.TypeNamespace)=='System.Collections.Generic' and str(r.TypeName)=='EqualityComparer`1');facts=[]
def integer(data,at=0):
    c=data[at]
    if c<128:return c,at+1
    if c<192:return ((c&63)<<8)|data[at+1],at+2
    return ((c&31)<<24)|int.from_bytes(data[at+1:at+4],'big'),at+4
for k,r in enumerate(p.net.mdtables.InterfaceImpl.rows,1):
    if r.Class.row_index!=rid:continue
    if r.Interface.table.name=='TypeSpec':
        b=r.Interface.row.Signature.value;assert b[:2]==b'\x15\x12';value,end=integer(b,2);tag=value&3;index=value>>2;row=(p.net.mdtables.TypeDef.rows if tag==0 else p.net.mdtables.TypeRef.rows)[index-1];assert b[end:]==b'\x01\x13\x00';name=str(row.TypeNamespace)+'.'+str(row.TypeName)+'<T>';signature=b.hex()
    else:row=r.Interface.row;name=str(row.TypeNamespace)+'.'+str(row.TypeName);signature=None
    facts.append(dict(interfaceimpl_row=k,owner='System.Collections.Generic.EqualityComparer`1<T>',interface=name,signature=signature))
assert {r['interface'] for r in facts}=={'System.Collections.Generic.IEqualityComparer`1<T>','System.Collections.IEqualityComparer'}
f=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py';assert hashlib.sha256(f.read_bytes()).hexdigest()=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14';s=importlib.util.spec_from_file_location('frozen',f);v=importlib.util.module_from_spec(s);s.loader.exec_module(v);source=json.loads((Q/'ALL-CIL.json').read_text('utf-8-sig'));models=[];results=[]
for m in source['methods']:
    if m['token'] not in ['0x060008D2','0x060008D3']:continue
    for value in ['System.Int32','System.String']:
        def bind(x):
            if isinstance(x,str):return re.sub(r'(?<![\w.])T(?!\w)',value,x)
            if isinstance(x,list):return [bind(y) for y in x]
            if isinstance(x,dict):return {bind(k):bind(y) for k,y in x.items()}
            return x
        d=bind(copy.deepcopy(m));types=bind(copy.deepcopy(source['types']));d['owner']=m['owner']+'<'+value+'>'
        for k in types:
            if k in source['types']:types[k]=copy.deepcopy(source['types'][k])
        fact=copy.deepcopy(source['types'][m['owner']]);fact.pop('unbound',None);fact.pop('unresolved',None);types[d['owner']]=fact;types[bind('System.Collections.Generic.EqualityComparer`1<T>')]['interfaces']=[bind(r['interface']) for r in facts]
        try:r=v.verify(d,types)
        except Exception as e:r=dict(token=d['token'],status='FAIL_OR_UNSUPPORTED',error=str(e))
        results.append(dict(r,context=value));models.append((d,types,value))
controls=[]
for name,token,alter in [('wrong-list-argument-width','0x060008D3',lambda d:next(i for i in d['instructions'] if i['opcode']=='newobj')['operand']['args'].__setitem__(0,'System.Int64')),('wrong-default-return','0x060008D2',lambda d:next(i for i in reversed(d['instructions']) if i['opcode']=='call')['operand'].update(ret='System.String'))]:
    d,t,_=copy.deepcopy(next(x for x in models if x[0]['token']==token and x[2]=='System.Int32'));alter(d)
    try:r=v.verify(d,t);rejected=r['status']!='PASS';why=r
    except Exception as e:rejected=True;why=str(e)
    controls.append(dict(name=name,rejected=rejected,reason=why))
r=dict(scope='FINITE_INT32_STRING_CLOSED_MODELS_WITH_RAW_AUTHENTIC_SDK_INTERFACE_EDGES',candidate_sha256=hashlib.sha256((Q/'candidate1.dll').read_bytes()).hexdigest(),checker_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),checker_modified=False,mscorlib_sha256=hashlib.sha256(sdk.read_bytes()).hexdigest(),interface_metadata_rows=facts,passed=sum(x['status']=='PASS' for x in results),total=len(results),results=results,negative_controls=controls,global_census_not_overwritten=True,universal_generic_proof=False);(Q/'CLOSED-TYPES-TWO.json').write_bytes((json.dumps(r,indent=2)+'\n').encode());print(json.dumps(r,indent=2));assert r['passed']==r['total']==4 and all(c['rejected'] for c in controls)
