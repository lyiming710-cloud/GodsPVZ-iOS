"""Execute all four original Assoc callers and real restored List callees.
Object allocation, dictionary constructors and default-comparer are explicit
controlled contracts; native exception construction/unwind are not executed.
"""
from pathlib import Path
import ctypes as C,json,sys
Q=Path(__file__).resolve().parent;W=Q.parent;sys.dont_write_bytecode=True;sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
im=NativeImage();state={};rows=[]
def arr(n):
    assert 0<=n<=64;p=im.alloc(32+n*state['element_size']);put64(p,state['array_class']);put64(p+0x18,n);return p
def alloc(cls):
    assert cls in [state['list_class'],state['dict_class']];p=im.alloc(128);put64(p,cls)
    if cls==state['dict_class']:state['dicts'][p]=dict(count=-1,comparer=0)
    return p
def array_new(cls,n):assert cls==state['array_class'];return arr(n)
def barrier(at,value):assert get64(at)==(value or 0)
def dict0(p,method):assert method==state['dict0'];state['dicts'][p]=dict(count=0,comparer=state['default'])
def dict1(p,capacity,method):assert method==state['dict1'] and 0<=capacity<=64;state['dicts'][p]=dict(count=0,comparer=state['default'])
def default(method):assert method==state['default_method'];return state['default']
def reject(*args):raise AssertionError('Unmodeled native class initialization/negative throw')
try:
    cfgs=[json.loads((Q/row['file']).read_bytes()) for row in json.loads((Q/'RESEARCH.json').read_bytes())['caller_cfgs']];helpers=[json.loads((W/'startup-r15'/f'{rid:04X}.native.json').read_bytes()) for rid in [0x8e3,0x8e4,0x8f1]]
    def check():
        for cfg in cfgs+helpers:
            for i in cfg['instructions']:assert C.string_at(int(i['va'],16),len(bytes.fromhex(i['bytes'])))==bytes.fromhex(i['bytes'])
        assert C.string_at(0x180302170,3)==bytes.fromhex('c20000')
    check();im.hook(0x180250100,P,[P],alloc);im.hook(0x18024f3e0,P,[P,C.c_uint64],array_new);im.hook(0x18024f360,None,[P,P],barrier);im.hook(0x1805e8280,None,[P,P],dict0);im.hook(0x1805e8300,None,[P,I,P],dict1);im.hook(0x1800065e0,P,[P],default);im.hook(0x180258a80,P,[P],reject);im.hook(0x1802501e0,None,[P],reject);im.hook(0x180250110,None,[P,P],reject);check()
    functions={(cfg['variant'],int(cfg['token'],16)&0xffffff):(C.CFUNCTYPE(None,P,P) if cfg['token'].endswith('D2') else C.CFUNCTYPE(None,P,I,P))(int(cfg['entry'],16)) for cfg in cfgs};counts={hex(int(c['entry'],16)):0 for c in cfgs}
    for c in json.loads(Path(sys.argv[1]).read_bytes()):
        state.clear();state.update(element_size={'int':4,'string':8,'wide':24}[c['value_type']],dicts={});lc=im.alloc(512);dc=im.alloc(512);ac=im.alloc(512);ownerclass=im.alloc(512);lctx=im.alloc(128);ctx=im.alloc(512);statics=im.alloc(128);state.update(list_class=lc,dict_class=dc,array_class=ac);put64(lc+0xc0,lctx);put64(lc+0xb8,statics);put32(lc+0xe0,1);put64(lctx+0x10,lc);put64(lctx+0x18,ac);put64(ownerclass+0xc0,ctx)
        for cls in [lc,dc,ac,ownerclass]:C.c_ubyte.from_address(cls+0x135).value=1
        put32(ac+0x104,state['element_size']);shared=arr(0);put64(statics,shared)
        def method(code,cls):p=im.alloc(128);put64(p,code);put64(p+0x20,cls);return p
        list0=method(0x1809d56d0,lc);list1=method(0x1809d5770,lc);d0=method(0x1805e8280,dc);d1=method(0x1805e8300,dc);getdefault=method(0x1800065e0,ownerclass);state.update(dict0=d0,dict1=d1,default_method=getdefault,default=im.alloc(64));m=method(0,ownerclass)
        for offset,v in [(0,lc),(8,list0),(0x18,dc),(0x20,d0),(0x28,getdefault),(0x48,list1),(0x50,d1)]:put64(ctx+offset,v)
        oldlist=im.alloc(64) if c['mask']&1 else 0
        if oldlist:put64(oldlist+0x10,arr(2));put32(oldlist+0x18,7)
        oldcomp=im.alloc(64) if c['mask']&4 else 0;olddict=im.alloc(128) if c['mask']&2 else 0
        if olddict:state['dicts'][olddict]=dict(count=3,comparer=im.alloc(64))
        owner=im.alloc(64);put64(owner+0x10,oldlist);put64(owner+0x18,olddict);put64(owner+0x20,oldcomp);variant='reference' if c['value_type']=='string' else 'fully-shared';rid=0x8d2 if c['kind']=='default' else 0x8d3;f=functions[variant,rid]
        if rid==0x8d2:f(owner,m)
        else:f(owner,c['capacity'],m)
        cfg=next(cfg for cfg in cfgs if cfg['variant']==variant and int(cfg['token'],16)&0xffffff==rid);counts[cfg['entry']]+=1;assert not im.errors,im.errors;l=get64(owner+0x10);d=get64(owner+0x18);comp_=get64(owner+0x20);data=get64(l+0x10) if l else 0;di=state['dicts'].get(d);after=dict(list_same_old=l==oldlist,dict_same_old=d==olddict,comp_same_old=comp_==oldcomp,list_size=get32(l+0x18) if l else None,list_data_length=get64(data+0x18) if data else None,list_data_same_shared=data==shared if l else None,dict_count=di['count'] if di else None,comp_same_default=comp_==state['default'],dict_comparer_same_default=di['comparer']==state['default'] if di else None);rows.append(dict(name=c['name'],kind=c['kind'],value_type=c['value_type'],state=after,error=None,param=None,message=None))
    r=dict(scope='ALL_FOUR_REFERENCE_FULLY_SHARED_ORIGINAL_ASSOC_CALLERS_WITH_REAL_LIST_CTORS_CONTROLLED_BCL_ALLOCATION_GC',original_sha256=PC_SHA,all_caller_and_list_helper_bytes_preserved=True,executed_original_entries=counts,indirect_targets_from_raw_rgctx=True,callback_errors=im.errors,native_exception_execution=False,real_unity=False,results=rows);Path(sys.argv[2]).write_bytes((json.dumps(r,indent=2)+'\n').encode());print(json.dumps(dict(cases=len(rows),entries=counts)))
finally:im.close()
