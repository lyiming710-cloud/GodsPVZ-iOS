"""Two exact Assoc constructors via legal public list/dictionary/comparer APIs."""
from pathlib import Path
import hashlib,importlib.util,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
def mod(name,path):s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
writer=mod('metadata_writer',W/'startup-r2/construct.py');helper=mod('labels_only',W/'startup-r13/construct.py');IL=helper.IL;comp=helper.comp;sha=lambda b:hashlib.sha256(b).hexdigest()
def build(output,report_path):
    output=Path(output);report_path=Path(report_path);assert not output.exists() and not report_path.exists();before=(W/'startup-r15/candidate1.dll').read_bytes();assert sha(before)=='261068dda5af1f6915ea7c2183fa8b2b0d69092db6777e5643a39552669ccba1';pe=dnfile.dnPE(data=before);out=bytearray(before);evidence=json.loads((Q/'RESEARCH.json').read_bytes());assert evidence['indirect_callees_bound_by_rgctx'];cli=pe.get_offset_from_rva(pe.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress);mrva,msize=struct.unpack_from('<II',before,cli+8);mat=pe.get_offset_from_rva(mrva);root,streams=writer.metadata_root(before[mat:mat+msize]);values={n:b for n,_,b in streams};th,rows,tail,counts=writer.tables_decode(values['#~']);newrows=[]
    def name(s):
        b=s.encode()+b'\0';at=values['#Strings'].find(b)
        if at>=0 and (at==0 or values['#Strings'][at-1]==0):return at
        at=len(values['#Strings']);values['#Strings']+=b;return at
    blobs={r.Signature.value:rows[10][i-1][2] for i,r in enumerate(pe.net.mdtables.MemberRef.rows,1)}
    def blob(b):
        if b not in blobs:blobs[b]=len(values['#Blob']);values['#Blob']+=comp(len(b))+b
        return blobs[b]
    def spec(b):
        for i,r in enumerate(pe.net.mdtables.TypeSpec.rows,1):
            if r.Signature.value==b:return i
        rows[27].append([blob(b)]);newrows.append(dict(table='TypeSpec',rid=len(rows[27]),signature=b.hex()));return len(rows[27])
    def member(parent,n,sig):
        for i,r in enumerate(pe.net.mdtables.MemberRef.rows,1):
            if rows[10][i-1][0]==parent and str(r.Name)==n and r.Signature.value==sig:return 0xa000000|i
        rows[10].append([parent,name(n),blob(sig)]);t=0xa000000|len(rows[10]);newrows.append(dict(table='MemberRef',token=f'0x{t:08X}',name=n,owner_coded=parent,signature=sig.hex()));return t
    fields={str(r.Name):(i,r) for i,r in enumerate(pe.net.mdtables.MemberRef.rows,1) if str(r.Name) in ['_list','_dict','_comp']};assert set(fields)=={'_list','_dict','_comp'}
    for i,r in fields.values():assert r.Class.table.name=='TypeSpec' and r.Class.row.Signature.value==bytes.fromhex('151284bc011300')
    lspec=spec(fields['_list'][1].Signature.value[1:]);dspec=spec(fields['_dict'][1].Signature.value[1:]);scope=next(rows[1][i-1][0] for i,r in enumerate(pe.net.mdtables.TypeRef.rows,1) if str(r.TypeName)=='IEqualityComparer`1' and str(r.TypeNamespace)=='System.Collections.Generic');rows[1].append([scope,name('EqualityComparer`1'),name('System.Collections.Generic')]);eref=len(rows[1]);newrows.append(dict(table='TypeRef',rid=eref,name='System.Collections.Generic.EqualityComparer`1',resolution_scope=scope));esig=b'\x15\x12'+comp((eref<<2)|1)+b'\x01\x13\x00';espec=spec(esig)
    l0=member((lspec<<3)|4,'.ctor',bytes.fromhex('200001'));l1=member((lspec<<3)|4,'.ctor',bytes.fromhex('20010108'));d0=member((dspec<<3)|4,'.ctor',bytes.fromhex('200001'));d1=member((dspec<<3)|4,'.ctor',bytes.fromhex('20010108'));default=member((espec<<3)|4,'get_Default',b'\x00\x00'+esig);base_ctor=next(0xa000000|i for i,r in enumerate(pe.net.mdtables.MemberRef.rows,1) if str(r.Name)=='.ctor' and getattr(r.Class.row,'TypeName',None)=='Object' and r.Signature.value==bytes.fromhex('200001'));allowed=set();changes=[]
    for rid,cap in [(0x8d2,False),(0x8d3,True)]:
        b=IL().arg(0).token(0x28,base_ctor).arg(0)
        if cap:b.arg(1)
        b.token(0x73,l1 if cap else l0).token(0x7d,0xa000000|fields['_list'][0]).arg(0)
        if cap:b.arg(1)
        code=b.token(0x73,d1 if cap else d0).token(0x7d,0xa000000|fields['_dict'][0]).arg(0).token(0x28,default).token(0x7d,0xa000000|fields['_comp'][0]).op('2a').finish();row=pe.net.mdtables.MethodDef.rows[rid-1];assert sum(r.Rva==row.Rva for r in pe.net.mdtables.MethodDef.rows)==1;at=pe.get_offset_from_rva(row.Rva);h=(struct.unpack_from('<H',before,at)[0]>>12)*4;assert h==12;n=struct.unpack_from('<I',before,at+4)[0];assert len(code)<n;out[at+h:at+h+len(code)]=code;struct.pack_into('<I',out,at+4,len(code));allowed.update(range(at+4,at+8));allowed.update(range(at+h,at+h+len(code)));changes.append(dict(token=f'0x{0x6000000|rid:08X}',file_offset=at,rva=hex(row.Rva),old_code_size=n,new_code_size=len(code),code=code.hex(),unused_old_slot_preserved=True))
    values['#~']=writer.tables_encode(th,rows,tail,counts);meta=bytearray(root)
    for n,at,_ in streams:
        start=writer.align(len(meta),4);meta.extend(b'\0'*(start-len(meta)));struct.pack_into('<II',meta,at,start,len(values[n]));meta.extend(values[n])
    last=pe.sections[-1];assert last.Name.rstrip(b'\0')==b'.n29meta' and last.Characteristics==0x40000040 and last.PointerToRawData+last.SizeOfRawData==len(before);start=writer.align(len(out),4);out.extend(b'\0'*(start-len(out)));out.extend(meta);end=len(out);raw_size=writer.align(end-last.PointerToRawData,pe.OPTIONAL_HEADER.FileAlignment);out.extend(b'\0'*(last.PointerToRawData+raw_size-len(out)));sh=last.get_file_offset();opt=pe.OPTIONAL_HEADER.get_file_offset();updates={sh+8:end-last.PointerToRawData,sh+16:raw_size,opt+8:pe.OPTIONAL_HEADER.SizeOfInitializedData+raw_size-last.SizeOfRawData,opt+56:writer.align(last.VirtualAddress+end-last.PointerToRawData,pe.OPTIONAL_HEADER.SectionAlignment),opt+64:0,cli+8:last.VirtualAddress+start-last.PointerToRawData,cli+12:len(meta)}
    for at,value in updates.items():struct.pack_into('<I',out,at,value);allowed.update(range(at,at+4))
    assert all(x==y or i in allowed for i,(x,y) in enumerate(zip(before,out)));output.write_bytes(out);r=dict(scope='TWO_NATIVE_BACKED_ASSOC_CONSTRUCTORS_CONSTRUCTED_RUNTIME_PENDING',parent_sha256=sha(before),candidate_sha256=sha(out),bytes=len(out),method_targets=2,unchanged_methoddefs=2315,new_metadata_rows=newrows,changes=changes,header_updates={str(k):v for k,v in updates.items()},rvas_locals_maxstack_visibility_unchanged=True,runtime='PENDING',ipa=None);report_path.write_bytes((json.dumps(r,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in r.items() if k not in ['changes','header_updates']},indent=2))
if __name__=='__main__':build(*sys.argv[1:])
