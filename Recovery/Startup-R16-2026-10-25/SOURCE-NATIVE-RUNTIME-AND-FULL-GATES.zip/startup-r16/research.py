"""Bind both reference and fully-shared Assoc constructors to original bytes."""
from pathlib import Path
import hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import pefile
from capstone import *
from capstone.x86_const import X86_OP_IMM
I=ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs';raw=(I/'original-pc/GameAssembly.dll').read_bytes();metadata=(I/'original-pc/global-metadata.dat').read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest();assert sha(raw)=='9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d' and sha(metadata)=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9';p=pefile.PE(data=raw);base=p.OPTIONAL_HEADER.ImageBase;read=lambda at,n:p.get_data(at-base,n);u=lambda b,o=0:struct.unpack_from('<I',b,o)[0];q=lambda b,o=0:struct.unpack_from('<Q',b,o)[0];mv=struct.unpack('<16Q',read(0x1818c6d00,128));cv=struct.unpack('<17Q',read(0x1815e88c0,136));mo=u(metadata,48);so=u(metadata,24);types=json.loads((I/'maps/native-types.json').read_text('utf-8-sig'));string=lambda i:metadata[so+i:metadata.index(0,so+i)].decode();historical=json.loads((ROOT/'audit/bulk400-generic-repair-2026-10-24/evidence/original-generic-bindings.json').read_bytes());bindings=[];cfgs=[];dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True
funcs=[struct.unpack('<iiii',read(mv[5]+16*k,16)) for k in range(mv[4])]
for r in historical['methods']:
    if r['token'] not in ['0x060008D2','0x060008D3']:continue
    si=r['method_spec_index'];gi=r['generic_pointer_index'];definition,ci,mi=struct.unpack('<iii',read(mv[9]+si*12,12));assert (definition,ci,mi)==(r['definition_index'],r['class_inst_index'],r['method_inst_index']);assert u(metadata,mo+definition*36+24)==int(r['token'],16);assert len([x for x in funcs if x[0]==si and x[1]==gi])==1 and q(read(cv[3]+gi*8,8))==int(r['va'],16);bindings.append(r);entry=int(r['va'],16);pending=[entry];ins={};indirect=[]
    while pending:
        at=pending.pop()
        while at not in ins:
            i=next(dis.disasm(read(at,15),at));ins[at]=i;assert len(ins)<250
            if i.group(CS_GRP_RET) or i.mnemonic in ['int3','ud2']:break
            if i.group(CS_GRP_JUMP):
                assert i.operands[0].type==X86_OP_IMM;dest=i.operands[0].imm
                if dest!=0x18024f360:pending.append(dest)
                if i.mnemonic=='jmp':break
            if i.mnemonic=='call' and i.operands[0].type!=X86_OP_IMM:indirect.append(dict(source=hex(at),operand=i.op_str))
            at+=i.size
    rows=[dict(va=hex(i.address),op=i.mnemonic,operands=i.op_str,bytes=i.bytes.hex()) for i in sorted(ins.values(),key=lambda x:x.address)];variant='reference' if r['class_args']==['object'] else 'fully-shared';cfg=dict(token=r['token'],variant=variant,entry=hex(entry),scope='COMPLETE_CALLER_DIRECT_CFG_WITH_INDIRECT_CALLS_BOUND_SEPARATELY',instructions=rows,indirect_calls=indirect);name=r['token'][-4:]+'-'+variant;(Q/(name+'.native.json')).write_bytes((json.dumps(cfg,indent=2)+'\n').encode());(Q/(name+'.native.txt')).write_text('\n'.join(f"{i['va']} {i['op']} {i['operands']}" for i in rows)+'\n');cfgs.append(dict(file=name+'.native.json',entry=hex(entry),instructions=len(rows),indirect_calls=indirect))
assert len(bindings)==4
# Read the actual Assembly-CSharp RGCTX range, not only historical labels.
module=None
for k in range(cv[15]):
    at=q(read(cv[16]+k*8,8));name=read(q(read(at,8)),160).split(b'\0')[0].decode()
    if name=='Assembly-CSharp.dll':module=at
assert module;rv=struct.unpack('<18Q',read(module,144));nr,rp,nd,dp=rv[8:12];t=next(t for t in types if t['name']=='SwfAssocList`1');tok=int(t['token'],16);rgctx=[]
for k in range(nr):
    token,start,length=struct.unpack('<Iii',read(rp+12*k,12))
    if token!=tok:continue
    for j in range(length):
        kind,data=struct.unpack('<QQ',read(dp+(start+j)*16,16));row=dict(index=j,kind=kind,data=hex(data))
        if kind==3:
            si=u(read(data,4));definition,ci,mi=struct.unpack('<iii',read(mv[9]+si*12,12));at=mo+definition*36;owner=types[u(metadata,at+4)];row.update(method_spec_index=si,definition_index=definition,owner=owner['namespace']+'.'+owner['name'],name=string(u(metadata,at)),parameter_count=struct.unpack_from('<H',metadata,at+34)[0],method_token=hex(u(metadata,at+24)))
        rgctx.append(row)
by={r['index']:r for r in rgctx};assert by[1]['name']=='.ctor' and by[1]['owner']=='FTRuntime.Internal.SwfList`1' and by[1]['parameter_count']==0;assert by[9]['name']=='.ctor' and by[9]['owner']=='FTRuntime.Internal.SwfList`1' and by[9]['parameter_count']==1;assert by[4]['owner']=='System.Collections.Generic.Dictionary`2' and by[4]['parameter_count']==0;assert by[10]['owner']=='System.Collections.Generic.Dictionary`2' and by[10]['parameter_count']==1;assert by[5]['owner']=='System.Collections.Generic.EqualityComparer`1' and by[5]['name']=='get_Default' and by[5]['parameter_count']==0
report=dict(original_sha256=sha(raw),metadata_sha256=sha(metadata),raw_registration_bindings_rechecked=True,bindings=bindings,caller_cfgs=cfgs,raw_rgctx=rgctx,indirect_callees_bound_by_rgctx=True,runtime='PENDING');(Q/'RESEARCH.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(dict(cfgs=cfgs,rgctx_methods=[r for r in rgctx if r['kind']==3]),indent=2))
