"""Raw all-body/metadata append isolation and complete native-backed CIL contract."""
from pathlib import Path
import hashlib,importlib.util,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
from cil_contracts import check
def mod(n,p):s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
writer=mod('metadata_read',W/'startup-r2/construct.py');reader=mod('body_read',ROOT/'audit/native111-publication-2026-10-20/repository/scripts/actions/static_gates.py');sha=lambda b:hashlib.sha256(b).hexdigest();a=(W/'startup-r15/candidate1.dll').read_bytes();b=(Q/'candidate1.dll').read_bytes();assert sha(a)=='261068dda5af1f6915ea7c2183fa8b2b0d69092db6777e5643a39552669ccba1' and sha(b)=='5454887dc125cf56b7de5fc6079441075b91972e64db40e52f70d1129a87c73f' and b==(Q/'candidate2.dll').read_bytes();pp=dnfile.dnPE(data=a);cp=dnfile.dnPE(data=b);targets={0x8d2,0x8d3};allowed=set();changed=[]
def meta(data,p):
    cli=p.get_offset_from_rva(p.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress);rva,n=struct.unpack_from('<II',data,cli+8);at=p.get_offset_from_rva(rva);_,ss=writer.metadata_root(data[at:at+n]);v={n:b for n,_,b in ss};_,rows,_,_=writer.tables_decode(v['#~']);return at,v,rows
_,pv,pr=meta(a,pp)
def metadata_check(data,p):
    at,v,rows=meta(data,p);assert at==len(a) and set(v)==set(pv) and set(rows)==set(pr)
    for n in pv:
        if n in ['#Strings','#Blob']:assert v[n].startswith(pv[n])
        elif n!='#~':assert v[n]==pv[n]
    for t in pr:
        extra={1:1,27:1,10:5}.get(t,0);assert len(rows[t])==len(pr[t])+extra and rows[t][:len(pr[t])]==pr[t]
    r=p.net.mdtables.TypeRef.rows[-1];assert str(r.TypeNamespace)=='System.Collections.Generic' and str(r.TypeName)=='EqualityComparer`1' and r.ResolutionScope.table.name=='AssemblyRef' and str(r.ResolutionScope.row.Name)=='mscorlib';assert rows[1][-1][0]==next(pr[1][k-1][0] for k,r in enumerate(pp.net.mdtables.TypeRef.rows,1) if str(r.TypeName)=='IEqualityComparer`1')
    esig=b'\x15\x12'+((0x8000|((len(rows[1])<<2)|1)).to_bytes(2,'big'))+b'\x01\x13\x00';assert p.net.mdtables.TypeSpec.rows[-1].Signature.value==esig
    signatures=[('200001','151284d8011300'),('20010108','151284d8011300'),('200001','1512811102130008'),('20010108','1512811102130008')]
    for r,(sig,owner) in zip(p.net.mdtables.MemberRef.rows[-5:-1],signatures):assert str(r.Name)=='.ctor' and r.Signature.value.hex()==sig and r.Class.table.name=='TypeSpec' and r.Class.row.Signature.value.hex()==owner
    r=p.net.mdtables.MemberRef.rows[-1];assert str(r.Name)=='get_Default' and r.Signature.value==b'\x00\x00'+esig and r.Class.row.Signature.value==esig
metadata_check(b,cp)
old=json.loads((W/'startup-r15/ALL-CIL.json').read_text('utf-8-sig'));old={int(m['token'],16)&0xffffff:m for m in old['methods']};cil=json.loads((Q/'ALL-CIL.json').read_text('utf-8-sig'));methods={int(m['token'],16)&0xffffff:m for m in cil['methods']}
for rid,(x,y) in enumerate(zip(pp.net.mdtables.MethodDef.rows,cp.net.mdtables.MethodDef.rows),1):
    assert x.Rva==y.Rva
    if not x.Rva:continue
    at=pp.get_offset_from_rva(x.Rva);n=reader.parse_raw_method_body_span(a,at)[0];m=reader.parse_raw_method_body_span(b,at)[0]
    if a[at:at+n]!=b[at:at+m]:changed.append(rid)
    if rid not in targets:assert n==m and a[at:at+n]==b[at:at+m];continue
    assert a[at]&3==b[at]&3==3;h=(struct.unpack_from('<H',a,at)[0]>>12)*4;assert h==12;n=struct.unpack_from('<I',a,at+4)[0];m=struct.unpack_from('<I',b,at+4)[0];assert m<n and a[at:at+4]==b[at:at+4] and a[at+8:at+h]==b[at+8:at+h] and a[at+h+m:at+h+n]==b[at+h+m:at+h+n];allowed.update(range(at+4,at+8));allowed.update(range(at+h,at+h+m));assert methods[rid]['locals']==old[rid]['locals'] and methods[rid]['maxStack']==old[rid]['maxStack'] and methods[rid]['handlers']==old[rid]['handlers']==[];check(methods[rid])
assert set(changed)==targets
sh=pp.sections[-1].get_file_offset();opt=pp.OPTIONAL_HEADER.get_file_offset();cli=pp.get_offset_from_rva(pp.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress);allowed.update(at+i for at in [sh+8,sh+16,opt+8,opt+56,opt+64,cli+8,cli+12] for i in range(4));assert pp.sections[-1].Characteristics==cp.sections[-1].Characteristics==0x40000040
def boundary(data):assert len(data)==len(b) and not any(x!=y and k not in allowed for k,(x,y) in enumerate(zip(a,data)));metadata_check(data,dnfile.dnPE(data=data))
boundary(b);controls=[]
for n,at in [('old-metadata',pp.get_offset_from_rva(pp.net.struct.MetaDataRva)),('unrelated-body',pp.get_offset_from_rva(pp.net.mdtables.MethodDef.rows[0x526-1].Rva)+12),('target-maxstack',pp.get_offset_from_rva(pp.net.mdtables.MethodDef.rows[0x8d2-1].Rva)+2)]:
    d=bytearray(b);d[at]^=1
    try:boundary(d)
    except AssertionError:controls.append(dict(name=n,rejected=True));continue
    raise AssertionError('Boundary false accept')
r=dict(scope='INDEPENDENT_WHOLE_PREFIX_ALL_METHODS_METADATA_AND_BOUND_CALLEE_ORDER_SPECIFICATION',candidate_sha256=sha(b),parent_sha256=sha(a),pass_=True,changed_methods=2,unchanged_methoddefs=2315,new_typerefs=1,new_typespecs=1,new_memberrefs=5,new_methoddefs=0,old_metadata_all_rows_and_heap_prefixes_preserved=True,rvas_locals_maxstack_visibility_readonly_flags_unchanged=True,unused_old_slots_preserved=True,negative_isolation_controls=controls,whole_game=False);(Q/'ISOLATION-AND-CIL-SPEC.json').write_bytes((json.dumps(r,indent=2)+'\n').encode());(Q/'METHOD-CIL.json').write_bytes((json.dumps(dict(types=cil['types'],methods=[methods[r] for r in sorted(targets)]),indent=2)+'\n').encode());print(json.dumps(r,indent=2))
