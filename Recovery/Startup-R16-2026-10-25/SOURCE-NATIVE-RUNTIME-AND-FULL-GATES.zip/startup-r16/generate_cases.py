from pathlib import Path
import json
Q=Path(__file__).resolve().parent;O=Q/'runtime-results';O.mkdir(exist_ok=True);rows=[];neg=[]
for t in ['int','string','wide']:
    for mask in range(8):
        for kind,capacity in [('default',0),('capacity',0),('capacity',1),('capacity',2),('capacity',5),('capacity',17),('capacity',31)]:rows.append(dict(name=f'case-{len(rows):04d}',kind=kind,value_type=t,mask=mask,capacity=capacity))
        for capacity in [-2147483648,-17,-1]:neg.append(dict(name=f'negative-{len(neg):04d}',kind='capacity',value_type=t,mask=mask,capacity=capacity))
(O/'CASES.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode());(O/'NEGATIVE-CASES.json').write_bytes((json.dumps(neg,indent=2)+'\n').encode());print('NORMAL',len(rows),'MANAGED_NEGATIVE',len(neg))
