from pathlib import Path
import hashlib,json,shutil
Q=Path(__file__).resolve().parent;W=Q.parent;old='261068dda5af1f6915ea7c2183fa8b2b0d69092db6777e5643a39552669ccba1';new='5454887dc125cf56b7de5fc6079441075b91972e64db40e52f70d1129a87c73f';rows=[];sha=lambda b:hashlib.sha256(b).hexdigest()
for name in ['full_type_census_r15.py','interface_facts_r15.py','census_lexical_tails.py','full_member_access.py']:
    src=W/'startup-r15'/name;b=src.read_bytes();s=b.decode().replace(old,new).replace('startup-r15','startup-r16');out=Q/name.replace('_r15','_r16');out.write_bytes(s.encode());rows.append(dict(source=str(src.relative_to(W)),source_sha256=sha(b),derived=str(out.relative_to(W)),derived_sha256=sha(out.read_bytes()),changes='Exact child hash and output path only'))
shutil.copy2(W/'startup-r15/ALL-METHODS.json',Q/'ALL-METHODS.json');(Q/'METHODS.json').write_bytes((json.dumps(dict(methods=[dict(token=f'0x{0x6000000|rid:08X}') for rid in [0x8d2,0x8d3]]),indent=2)+'\n').encode());(Q/'DRIVER-DERIVATION.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode());print('Prepared',len(rows),'readonly derivatives')
