"""Bind the preserved Apple precheck to the returned exact fifty-method sources.

Only candidate/run/archive identities and output labels change; flags, controls,
runtime-header validation and the compile algorithm are retained.
"""
from pathlib import Path
import ast, json
from archive_support import sha, js, pack, manifest

W = Path(__file__).resolve().parent
R = W.parents[1]/'audit/repo-native113'
D = R/'Recovery/Startup-R17-Batch50-2026-10-25'
A = W/'r17-compiler-run-40166633598'
candidate = 'd2a645ad0d8164af5fbdcbd9fcaa578d5a28b27e7b13f3012cdb51e63a256091'
actual = json.loads((D/'ACTUAL-COMPILER-40166633598.json').read_bytes())
assert actual['pass_'] and actual['candidate_sha256'] == candidate
assert actual['cpp']['attempted'] == 756 and actual['c']['attempted'] == 274 and actual['raw_generated_sources_rehashed'] == 1030
generated = A/'startup-r17-generated.tar.gz'
new_archive_sha = sha(generated.read_bytes())
assert any(x['file'] == generated.name and x['sha256'] == new_archive_sha for x in actual['downloaded_archives'])

source = R/'scripts/actions/check_startup_r10_apple.py'
before = source.read_bytes()
text = before.decode().replace('STARTUP-R10-COMPILER-REPORT.json', 'STARTUP-R17-BATCH50-COMPILER-REPORT.json')
text = text.replace('r10', 'r17').replace('R10', 'R17').replace('40120380134', '40166633598')
text = text.replace('9f030dc1c48e6d77e854979091a223fb636c93b1b528b8c6b9fbb2397a34d72e', candidate)
ast.parse(text)
dest = R/'scripts/actions/check_startup_r17_apple.py'
assert not dest.exists()
dest.write_bytes(text.encode())

workflow = R/'.github/workflows/bulk401-apple-compiler-check.yml'
parent = workflow.read_bytes()
snapshot = D/'PARENT-R10-APPLE-WORKFLOW.yml'
assert not snapshot.exists()
snapshot.write_bytes(parent)
text = parent.decode().replace('Startup R10', 'Startup R17 Batch50').replace('Startup-R10', 'Startup-R17-Batch50')
text = text.replace('startup-r10', 'startup-r17').replace('check_startup_r10_apple.py', 'check_startup_r17_apple.py')
text = text.replace('40120380134', '40166633598').replace('f5b49c19690a65d8f747ff666fb80ca8655d7d65c29b65766f41820229be0f8c', new_archive_sha)
assert 'r10' not in text.lower() and 'secrets.' not in text
workflow.write_bytes(text.encode())
js(D/'APPLE-GATE-INPUT.json', dict(scope='CURRENT_FIFTY_BATCH_ALL_FRESH_PORTABLE_SOURCES_APPLE_ARM64_SYNTAX_ONLY',
    candidate_sha256=candidate, conversion_run=40166633598, generated_archive_sha256=new_archive_sha,
    raw_sources_previously_rehashed=1030, preserved_runtime_export_run=39988665189,
    preserved_export_sha256='93d32bb83a6d93b1c9d8a490bf057db7cfe2e35dad1219ab4924b6ec38538e04',
    parent_driver_sha256=sha(before), driver_sha256=sha(dest.read_bytes()),
    parent_workflow_sha256=sha(parent), workflow_sha256=sha(workflow.read_bytes()),
    input_and_label_only_derivation=True, compile_algorithm_flags_and_controls_unchanged=True,
    actual_new_unity_export=False, linking=False, ipa=None))
files = [source, dest, workflow, R/'scripts/actions/audit_bulk389_all_generated_cpp.py',
    R/'scripts/actions/bulk389_export_binding.py',
    R/'Recovery/Bulk389-Qualification-2026-10-23/apple-failure-39988665189/APPLE-COMPILE-COMMAND.json']
pack(D/'APPLE-BINDING-SOURCES.zip', [(p.relative_to(R).as_posix(), p.read_bytes()) for p in files] + [(Path(__file__).name, Path(__file__).read_bytes())])
manifest(D)
print(json.dumps(dict(candidate_sha256=candidate, generated_archive_sha256=new_archive_sha, apple_precheck_prepared=True, new_unity_export=False)))
