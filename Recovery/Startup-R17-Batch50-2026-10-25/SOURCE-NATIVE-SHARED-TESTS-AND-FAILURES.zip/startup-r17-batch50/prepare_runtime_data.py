from pathlib import Path
import json,struct,sys
Q=Path(__file__).resolve().parent;ROOT=Q.parents[2];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
raw=(Q/'candidate1.dll').read_bytes();pe=dnfile.dnPE(data=raw);cil=json.loads((Q/'METHOD-CIL.json').read_bytes());ms={m['token']:m for m in cil['methods']};plan=json.loads((Q/'SOURCE-PLAN.json').read_bytes());fields=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_text('utf-8-sig'));fieldmap={int(r['token'],16):r for r in fields};nested={r.NestedClass.row_index:r.EnclosingClass.row_index for r in pe.net.mdtables.NestedClass.rows}
def typename(rid):
    r=pe.net.mdtables.TypeDef.rows[rid-1]
    return typename(nested[rid])+'/'+str(r.TypeName) if rid in nested else (str(r.TypeNamespace)+'.' if str(r.TypeNamespace) else '')+str(r.TypeName)
types={typename(k):r for k,r in enumerate(pe.net.mdtables.TypeDef.rows,1)};shapes={};cases=[];methods=[];hosts=set()
for p in plan['plans']:
    if not p['group'].startswith('COROUTINE'):continue
    m=ms[p['token']];constructor=p['group']=='COROUTINE_CORRECT_OBJECT_BASE_CONSTRUCTOR';state=m['owner'] if constructor else next(i['operand']['owner'] for i in m['instructions'] if i['opcode']=='newobj' and i['operand']['args']==['System.Int32']);sf=[]
    for f in types[state].FieldList:
        name=str(f.row.Name);role={'<>1__state':'state','<>4__this':'owner','<>2__current':'current','textComponent':'text','ctrl':'ctrl'}.get(name)
        if role:sf.append(dict(name=name,role=role,offset=fieldmap[0x4000000|f.row_index]['offset']))
    assert any(f['role']=='state' and f['offset']==0x10 for f in sf);shapes[state]=sf
    if not constructor:hosts.add(m['owner'])
    methods.append(dict(token=p['token'],group='ctor' if constructor else 'factory',name=m['name'],state_type=state,source_owner=m['owner'],native_entry=p['native_entry'],returns_iterator=m['ret']=='System.Collections.IEnumerator',args=m['args']))
    if constructor:
        for value in [-2147483648,-17,-1,0,1,2,99,65536,2147483647]:cases.append(dict(name=f'case-{len(cases):04d}',token=p['token'],kind='ctor',mode='none',state_arg=value,host_text=1,arg=1,state_type=state))
    else:
        for mode in ['none','allocate-mutates-text','getcomponent-mutates-text','start-mutates-text']:
            for host_text in [0,1,2]:
                for arg in [0,1]:cases.append(dict(name=f'case-{len(cases):04d}',token=p['token'],kind='factory',mode=mode,state_arg=0,host_text=host_text,arg=arg,state_type=state))
O=Q/'coroutine-runtime-results';O.mkdir(exist_ok=True);(O/'CASES.json').write_bytes((json.dumps(cases,indent=2)+'\n').encode());(Q/'COROUTINE-RUNTIME-SHAPES.json').write_bytes((json.dumps(dict(methods=methods,state_shapes=shapes,host_types=sorted(hosts),state_types=sorted(shapes)),indent=2)+'\n').encode());print('Coroutine methods',len(methods),'cases',len(cases),'state types',len(shapes))
