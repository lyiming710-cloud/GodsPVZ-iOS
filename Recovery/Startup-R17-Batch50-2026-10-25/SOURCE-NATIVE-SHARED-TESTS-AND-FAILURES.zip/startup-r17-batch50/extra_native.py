from pathlib import Path
import ctypes as C,json,sys
Q=Path(__file__).resolve().parent;W=Q.parent;sys.dont_write_bytecode=True;sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
im=NativeImage();state={};rows=[];dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True
def actor(id_):p=im.alloc(64);state['actors'][p]=id_;return p
def alloc(cls):
    state['trace'].append('Allocate');p=im.alloc(128);put64(p,cls)
    if state['ctrl'] and state['case']['mode']=='allocate-flips-live':state['live']=not state['live']
    state['wait']=p;return p
def subscribe(wait,ctrl,method):
    assert not method and (ctrl or 0)==state['ctrl'];state['trace'].append('Subscribe:'+('ctrl' if ctrl else 'null')+':'+str(int(state['live'] if ctrl else False)))
    if ctrl and state['live']:put64(wait+0x10,ctrl)
    return im.alloc(128) if state['case']['mode']=='subscribe-returns-other' else wait
def vsync(method):assert not method;v=state['case']['vsync'];state['trace'].append('VSync:'+str(v));return v
def frame(value,method):assert not method;state['frame']=value;state['trace'].append('Frame:'+str(value))
def platform(method):
    assert not method;c=state['case'];value=c['platform1'] if state['platforms']==0 else c['platform2'];state['platforms']+=1;state['trace'].append('Platform:'+str(value));return value
def touch(value,method):assert not method;state['simulate']=bool(value);state['trace'].append('Touch:'+str(int(value)))
def transform(owner,method):
    assert owner==state['owner'] and not method;state['trace'].append('Transform')
    if state['case']['mode']=='transform-flips-smoothing':C.c_ubyte.from_address(owner+0x58).value^=1
    return actor('transform')
def barrier(at,value):assert get64(at)==(value or 0)
def arrayclear(data,index,count,method):
    assert index==0 and not method and 0<=count<=get64(data+0x18);state['trace'].append('ArrayClear:'+str(count));C.memset(data+32,0,count*4);mode=state['case']['mode']
    if mode=='clear-replaces-dictionary':new=im.alloc(64);state['dicts'][new]=dict(id='dict-new',count=9);put64(state['owner']+0x18,new)
    if mode=='clear-mutates-size':put32(state['list']+0x18,19)
def dictclear(p,method):assert method==state['dict_clear_method'];state['trace'].append('DictClear:'+state['dicts'][p]['id']);state['dicts'][p]['count']=0
def reject(*args):raise AssertionError('Native exceptional path or unsupported class-init')
try:
    cfgs={f'0x{0x6000000|rid:08X}':json.loads((Q/'native-source'/f'0x{0x6000000|rid:08X}.json').read_bytes()) for rid in [0x8a6,0x8a7,0x8a8,0x8a9,0x75a]};clears={v:json.loads((Q/'native-source'/('0x060008DA-'+v+'.json')).read_bytes()) for v in ['reference','fully-shared']};listclear=json.loads((Q/'native-source/0x060008E8-reference.json').read_bytes());allcfg=list(cfgs.values())+list(clears.values())+[listclear];globals_=set()
    for cfg in allcfg:
        for r in cfg['instructions']:
            i=next(dis.disasm(bytes.fromhex(r['bytes']),int(r['va'],16)))
            if i.mnemonic not in ['lea','mov']:continue
            for o in i.operands:
                if o.type==X86_OP_MEM and o.mem.base==X86_REG_RIP:
                    at=i.address+i.size+o.mem.disp;encoded=int.from_bytes(im.pe.get_data(at-im.base,8),'little')
                    if encoded<=0xffffffff and encoded>>29 in range(1,8):globals_.add(at)
    for at in globals_:im.class_slot(at)
    def init(at):assert at in globals_;im.class_slot(at)
    im.hook(0x18024fef0,None,[P],init);im.hook(0x1802501e0,None,[P],lambda p:None);im.hook(0x180250100,P,[P],alloc);im.hook(0x18024f360,None,[P,P],barrier)
    for at in [0x1803cbd20,0x1803cb7f0,0x1803cba50,0x1803cb470]:im.hook(at,P,[P,P,P],subscribe)
    im.hook(0x1812f5bb0,I,[P],vsync);im.hook(0x1812df480,None,[I,P],frame);im.hook(0x1812df3d0,I,[P],platform);im.hook(0x181364fe0,None,[C.c_bool,P],touch);im.hook(0x181304510,P,[P,P],transform);im.hook(0x180cb86f0,None,[P,I,I,P],arrayclear);im.hook(0x1805814a0,None,[P,P],dictclear);im.hook(0x180250150,None,[P],reject)
    for cfg in allcfg:
        for i in cfg['instructions']:assert C.string_at(int(i['va'],16),len(bytes.fromhex(i['bytes'])))==bytes.fromhex(i['bytes'])
    assert C.string_at(0x18030f300,7)==im.pe.get_data(0x30f300,7) and C.string_at(0x180302170,3)==bytes.fromhex('c20000')
    for c in json.loads(Path(sys.argv[1]).read_bytes()):
        state.clear();state.update(case=c,trace=[],actors={},ctrl=0,live=False);kind=c['kind'];owner=im.alloc(256);state['owner']=owner
        if kind=='wait':
            ctrl=actor('ctrl') if c['ctrl_kind'] else 0;state.update(ctrl=ctrl,live=c['ctrl_kind']==1);cfg=cfgs[c['token']];value=C.CFUNCTYPE(P,P,P)(int(cfg['entry'],16))(ctrl,None);assert value==state['wait'];target=get64(value+0x10);after=dict(id='wait',target='ctrl' if target else None,target_live=state['live'] if target else None,ctrl_live=state['live'] if ctrl else None)
        elif kind=='camera':
            state.update(frame=1234,platforms=0,simulate=True);C.c_ubyte.from_address(owner+0x58).value=c['smoothing'];C.c_ubyte.from_address(owner+0x5a).value=not c['smoothing'];C.CFUNCTYPE(None,P,P)(int(cfgs[c['token']]['entry'],16))(owner,None);after=dict(frame=state['frame'],platform_calls=state['platforms'],simulate=state['simulate'],transform=state['actors'].get(get64(owner+0x20)),smoothing=bool(C.c_ubyte.from_address(owner+0x58).value),previous=bool(C.c_ubyte.from_address(owner+0x5a).value))
        else:
            length,size=c['length'],c['size'];arr=im.alloc(32+4*length);put64(arr+0x18,length)
            for k in range(length):put32(arr+32+4*k,k+1)
            lst=im.alloc(64);put64(lst+0x10,arr);put32(lst+0x18,size);old=im.alloc(64);state.update(list=lst,dicts={old:dict(id='dict',count=c['dict_count'])});put64(owner+0x10,lst);put64(owner+0x18,old);method=im.alloc(128);klass=im.alloc(512);ctx=im.alloc(512);put64(method+0x20,klass);put64(klass+0xc0,ctx);lc=im.alloc(128);put64(lc,0x1809d4b80);dc=im.alloc(128);put64(dc,0x1805814a0);state['dict_clear_method']=dc;put64(ctx+0xb8,lc);put64(ctx+0xc0,dc);cfg=clears[c['variant']];C.CFUNCTYPE(None,P,P)(int(cfg['entry'],16))(owner,method);current=state['dicts'][get64(owner+0x18)];after=dict(size=get32(lst+0x18),data=[get32(arr+32+4*k) for k in range(length)],dict_id=current['id'],dict_count=current['count'],old_dict_count=state['dicts'][old]['count'])
        assert not im.errors,im.errors;rows.append(dict(name=c['name'],token=c['token'],kind=kind,trace=list(state['trace']),state=after,error=None))
    r=dict(scope='SIX_ORIGINAL_PC_CALLERS_WITH_REAL_LIST_CLEAR_AND_BASE_HELPERS_CONTROLLED_SDK_CALLEES',original_sha256=PC_SHA,all_caller_and_list_clear_bytes_rechecked=True,base_helper_original_bytes_executed=True,real_unity=False,native_exception_execution=False,callback_errors=im.errors,results=rows);Path(sys.argv[2]).write_bytes((json.dumps(r,indent=2)+'\n').encode());print(json.dumps(dict(cases=len(rows))))
finally:im.close()
