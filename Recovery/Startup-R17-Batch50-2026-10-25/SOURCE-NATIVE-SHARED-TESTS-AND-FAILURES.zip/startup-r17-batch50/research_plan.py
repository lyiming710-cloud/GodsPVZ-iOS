"""Read-only evidence and construction roster. No validation suites execute.

User requested fifty new changed methods before the next shared test round.
Prior R16 runtime/static exports are reused only as exact source input data.
"""
from pathlib import Path
import hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile,pefile
from capstone import *
from capstone.x86_const import X86_OP_IMM
sha=lambda b:hashlib.sha256(b).hexdigest();parent=(W/'startup-r16/candidate1.dll').read_bytes();assert sha(parent)=='5454887dc125cf56b7de5fc6079441075b91972e64db40e52f70d1129a87c73f';pe=dnfile.dnPE(data=parent);cil=json.loads((W/'startup-r16/ALL-CIL.json').read_text('utf-8-sig'));methods={m['token']:m for m in cil['methods']};access=json.loads((W/'startup-r16/MEMBER-ACCESS-ALL-2297.json').read_bytes());factory_tokens=sorted({r['token'] for r in access['members'] if not r['allowed'] and r.get('member','').endswith('::<>1__state')});assert len(factory_tokens)==27
I=ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs';raw=(I/'original-pc/GameAssembly.dll').read_bytes();assert sha(raw)=='9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d';pc=pefile.PE(data=raw);base=pc.OPTIONAL_HEADER.ImageBase;fields=json.loads((I/'maps/native-fields.json').read_text('utf-8-sig'));field_map={int(r['token'],16):r for r in fields};dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True
def pointer(token):return int.from_bytes(pc.get_data(0x181b82d60-base+((int(token,16)&0xffffff)-1)*8,8),'little')
def code(token):
    r=pe.net.mdtables.MethodDef.rows[(int(token,16)&0xffffff)-1];at=pe.get_offset_from_rva(r.Rva);h=1 if parent[at]&3==2 else (struct.unpack_from('<H',parent,at)[0]>>12)*4;n=parent[at]>>2 if h==1 else struct.unpack_from('<I',parent,at+4)[0];return parent[at+h:at+h+n]
def operand_token(token,ins):
    b=code(token);at=ins['offset'];return int.from_bytes(b[at+1:at+5],'little')
plans=[];ctors={}
for token in factory_tokens:
    m=methods[token];ins=m['instructions'];stores=[(k,i) for k,i in enumerate(ins) if i['opcode']=='stfld' and i['operand']['identity'].endswith('::<>1__state')];assert len(stores)==1;k,store=stores[0];load,zero=ins[k-2:k];assert load['opcode'].startswith('ldloc') and zero['opcode'].startswith('ldc.i4') and zero['operand'] in [0,None];new=[i for i in ins[:k] if i['opcode']=='newobj' and i['operand']['owner']==store['operand']['owner'] and i['operand']['args']==['System.Int32']];assert len(new)==1;creation=new[0];ctor_token=f'0x{operand_token(token,creation):08X}';assert ctor_token in methods;ctor=methods[ctor_token];assert ctor['owner']==store['operand']['owner'];ctor_ins=ctor['instructions'];calls=[i for i in ctor_ins if i['opcode']=='call'];assert len(calls)>=1 and calls[0]['operand']['name']=='System.IDisposable.Dispose' and calls[0]['operand']['args']==[];old_base=operand_token(ctor_token,calls[0]);assert old_base>>24==6 and pointer(f'0x{old_base:08X}')==0x180302170
    row=pe.net.mdtables.MethodDef.rows[(int(ctor_token,16)&0xffffff)-1];assert row.Flags.mdPublic;statewrites=[(j,i) for j,i in enumerate(ctor_ins) if i['opcode']=='stfld' and i['operand']['identity']==store['operand']['identity']];assert len(statewrites)==1;j,_=statewrites[0];assert ctor_ins[j-1]['opcode'].startswith('ldarg') and ctor_ins[j-1]['operand']==dict(index=1)
    assert operand_token(token,store)==operand_token(ctor_token,statewrites[0][1]);nativefield=field_map[operand_token(token,store)];assert nativefield['offset']==0x10
    # The second state write is contiguous ldloc / ldc.i4.0 / stfld, after
    # newobj(0), stloc and only nops. No intervening call can change the state.
    ni=ins.index(creation);prev=ins[ni-1];assert prev['opcode'].startswith('ldc.i4') and prev['operand'] in [0,None];between=ins[ni+1:k-2];assert between and all(i['opcode'].startswith('stloc') or i['opcode']=='nop' for i in between)
    start=load['offset'];end=store['offset']+5;plans.append(dict(token=token,name=m['name'],group='COROUTINE_FACTORY_DUPLICATE_PRIVATE_STATE_WRITE',ctor_token=ctor_token,state_field=store['operand']['identity'],state_field_token=hex(operand_token(token,store)),native_state_offset=0x10,remove_span=dict(start=start,end=end,bytes=code(token)[start:end].hex()),reason='Public constructor writes its Int32 argument to the state once; native factory inlines that same single write. Remove duplicated inaccessible caller write, preserving all offsets.',test_status='NOT_RUN_BATCH_THRESHOLD_NOT_REACHED'))
    ctors[ctor_token]=dict(token=ctor_token,name=ctor['name'],group='COROUTINE_CORRECT_OBJECT_BASE_CONSTRUCTOR',call_offset=calls[0]['offset'],old_call_token=hex(old_base),native_old_alias_va=hex(pointer(f'0x{old_base:08X}')),reason='The native empty Object constructor shares a pointer with empty Dispose; managed reconstruction incorrectly bound the alias to IDisposable.Dispose. Restore the actual Object base constructor contract.',test_status='NOT_RUN_BATCH_THRESHOLD_NOT_REACHED')
plans.extend(ctors.values());assert len(ctors)==17
for rid in [0x8a6,0x8a7,0x8a8,0x8a9]:
    token=f'0x{0x6000000|rid:08X}';m=methods[token];ctor=next(i for i in m['instructions'] if i['opcode']=='newobj');subscribe=next(i for i in m['instructions'] if i['opcode']=='call' and i['operand']['name']=='Subscribe');ctoken=f'0x{operand_token(token,ctor):08X}';c=methods[ctoken];assert c['args']==['FTRuntime.SwfClipController'] and any(i['opcode']=='call' and i['operand']['name']=='Subscribe' for i in c['instructions']);assert pe.net.mdtables.MethodDef.rows[(int(ctoken,16)&0xffffff)-1].Flags.mdPublic;plans.append(dict(token=token,name=m['name'],group='WAIT_FACTORY_CALL_PUBLIC_CTOR_WITH_ACTUAL_CONTROLLER',ctor_token=ctoken,private_subscription_token=hex(operand_token(token,subscribe)),reason='Public constructor already performs Subscribe. Replace ctor(null)+second inaccessible Subscribe(controller) with one constructor(controller), preserving the original single subscription path.',test_status='NOT_RUN_BATCH_THRESHOLD_NOT_REACHED'))
plans.append(dict(token='0x060008DA',name=methods['0x060008DA']['name'],group='ASSOC_CLEAR_CALL_OWN_PUBLIC_LIST_CLEAR',reason='Restore legal list.Clear then reloaded dictionary.Clear; native reference variant inlines list clearing and the fully-shared variant calls the same RGCTX list method.',test_status='NOT_RUN_BATCH_THRESHOLD_NOT_REACHED'))
plans.append(dict(token='0x0600075A',name=methods['0x0600075A']['name'],group='CAMERA_AWAKE_NATIVE_INT32_SENTINELS',reason='Recover original Int32 Application.targetFrameRate=-1 on the vSyncCount<=0 path, retaining platform/transform ordering.',test_status='NOT_RUN_BATCH_THRESHOLD_NOT_REACHED'))
assert len(plans)==len({r['token'] for r in plans})==50
# Extract complete pdata-owned caller bytes. External tails and exceptional
# branches are retained as explicit boundaries rather than followed blindly.
runtime=pc.DIRECTORY_ENTRY_EXCEPTION
def native(token):
    entry=pointer(token);assert entry;fn=next(x.struct for x in runtime if x.struct.BeginAddress<=entry-base<x.struct.EndAddress);end=base+fn.EndAddress;pending=[entry];ins={};outside=[];indirect=[]
    while pending:
        at=pending.pop()
        while at not in ins:
            if not base+fn.BeginAddress<=at<end:outside.append(dict(target=hex(at),kind='OUTSIDE_DECLARED_RUNTIME_FUNCTION'));break
            i=next(dis.disasm(pc.get_data(at-base,15),at));ins[at]=i;assert len(ins)<1500
            if i.group(CS_GRP_RET) or i.mnemonic in ['int3','ud2']:break
            if i.group(CS_GRP_JUMP):
                if i.operands[0].type==X86_OP_IMM:
                    target=i.operands[0].imm
                    if base+fn.BeginAddress<=target<end:pending.append(target)
                    else:outside.append(dict(source=hex(at),target=hex(target),kind='EXTERNAL_TAIL_OR_SEPARATE_FUNCLET_REVIEW'))
                else:indirect.append(dict(source=hex(at),operand=i.op_str))
                if i.mnemonic=='jmp':break
            at+=i.size
    return dict(token=token,entry=hex(entry),runtime_begin=hex(base+fn.BeginAddress),runtime_end=hex(end),scope='READ_ONLY_DECLARED_RUNTIME_FUNCTION_CFG_WITH_EXPLICIT_UNFOLLOWED_BOUNDARIES',instructions=[dict(va=hex(i.address),op=i.mnemonic,operands=i.op_str,bytes=i.bytes.hex()) for i in sorted(ins.values(),key=lambda i:i.address)],outside_boundaries=outside,indirect_jumps=indirect)
native_dir=Q/'native-source';native_dir.mkdir(exist_ok=True)
for plan in plans:
    token=plan['token'];(Q/(token+'.parent-cil.json')).write_bytes((json.dumps(methods[token],indent=2)+'\n').encode())
    if token=='0x060008DA':continue
    cfg=native(token);(native_dir/(token+'.json')).write_bytes((json.dumps(cfg,indent=2)+'\n').encode());(native_dir/(token+'.txt')).write_text('\n'.join(f"{r['va']} {r['op']} {r['operands']}" for r in cfg['instructions'])+'\n');plan['native_entry']=cfg['entry'];plan['native_instructions']=len(cfg['instructions']);plan['native_boundaries']=cfg['outside_boundaries']
report=dict(scope='FIFTY_NEW_SOURCE_REPAIR_PLAN_NOT_TESTED_OR_ACCEPTED',parent_sha256=sha(parent),new_unique_methods=50,groups={g:sum(r['group']==g for r in plans) for g in sorted({r['group'] for r in plans})},plans=plans,tests_run=False,batch_test_trigger='After 50 new distinct method bodies are concretely constructed',ipa=None);(Q/'SOURCE-PLAN.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in report.items() if k!='plans'},indent=2))
