"""Read-only whole-assembly tail census. Never treats graph facts as behavior.

Separate known Cpp2IL unreachable warnings from reachable missing-code stubs.
No global rewrite is performed by this script. Frozen type checker untouched.
"""
from pathlib import Path
import json,hashlib,collections
Q=Path(__file__).resolve().parent;raw=(Q/'candidate3.dll').read_bytes();digest=hashlib.sha256(raw).hexdigest()
assert digest=='d2a645ad0d8164af5fbdcbd9fcaa578d5a28b27e7b13f3012cdb51e63a256091'
cil=json.loads((Q/'ALL-CIL.json').read_text('utf-8-sig'));rows=[]
for m in cil['methods']:
    ins=m['instructions']
    if not ins or ins[-1]['opcode'] in ['ret','br','br.s','throw','rethrow','endfinally','endfilter','leave','leave.s','jmp']:continue
    assert ins[-1]['opcode']=='pop' and ins[-2]['opcode']=='ldstr'
    offsets=[i['offset'] for i in ins];index={i['offset']:i for i in ins};edges={};supported=not m['handlers']
    for n,at in enumerate(offsets):
        i=index[at];op=i['opcode'];follow=offsets[n+1:n+2]
        if op in ['ret','throw','rethrow','endfinally','endfilter','jmp']:to=[]
        elif op in ['br','br.s','leave','leave.s']:to=[i['operand']['target']]
        elif op.startswith('br') or op.split('.')[0] in ['beq','bge','bgt','ble','blt','bne']:to=[i['operand']['target']]+follow
        elif op=='switch':supported=False;to=[]
        else:to=follow
        assert all(t in index for t in to);edges[at]=to
    reached=set();pending=[offsets[0]]
    while pending:
        at=pending.pop()
        if at in reached:continue
        reached.add(at);pending+=edges[at]
    unreachable=supported and not {ins[-2]['offset'],ins[-1]['offset']}&reached
    row=dict(token=m['token'],name=m['name'],ret=m['ret'],tail=ins[-2:],handlers=len(m['handlers']),direct_cfg_supported=supported,tail_unreachable=unreachable,
        status='UNREACHABLE_VOID_WARNING_FORM_REPAIR_ELIGIBLE_NOT_YET_REPAIRED' if unreachable and m['ret']=='System.Void' else 'QUARANTINED_REACHABLE_OR_NONVOID_TAIL_REQUIRES_SEPARATE_SPECIFICATION',
        runtime_equivalence_proven=False)
    rows.append(row)
report=dict(scope='READ_ONLY_METHOD_FORM_RISK_CENSUS_NOT_GAMEPLAY_BUG_COUNT',candidate_sha256=digest,methods_scanned=len(cil['methods']),unterminated_lexical_tails=len(rows),
            counts=dict(collections.Counter(r['status'] for r in rows)),mutations_performed=0,rows=rows)
(Q/'LEXICAL-TAIL-CENSUS.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in report.items() if k!='rows'},indent=2))
