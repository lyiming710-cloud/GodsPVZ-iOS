"""Read only the extra callee/native contracts needed by the fifty-body author."""
from pathlib import Path
import hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile,pefile
from capstone import *
from capstone.x86_const import X86_OP_IMM
sha=lambda b:hashlib.sha256(b).hexdigest();raw=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/GameAssembly.dll').read_bytes();assert sha(raw)=='9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d';pc=pefile.PE(data=raw);base=pc.OPTIONAL_HEADER.ImageBase;plan=json.loads((Q/'SOURCE-PLAN.json').read_bytes());source=json.loads((W/'startup-r16/ALL-CIL.json').read_text('utf-8-sig'));methods={r['token']:r for r in source['methods']};p=dnfile.dnPE(data=(W/'startup-r16/candidate1.dll').read_bytes());dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True
def pointer(token):return int.from_bytes(pc.get_data(0x181b82d60-base+((int(token,16)&0xffffff)-1)*8,8),'little')
def cfg(entry):
    f=next(x.struct for x in pc.DIRECTORY_ENTRY_EXCEPTION if x.struct.BeginAddress<=entry-base<x.struct.EndAddress);lo=base+f.BeginAddress;hi=base+f.EndAddress;pending=[entry];ins={};boundaries=[]
    while pending:
        at=pending.pop()
        while at not in ins:
            if not lo<=at<hi:boundaries.append(dict(target=hex(at),kind='OUTSIDE_PDATA_RANGE'));break
            i=next(dis.disasm(pc.get_data(at-base,15),at));ins[at]=i
            if i.group(CS_GRP_RET) or i.mnemonic in ['int3','ud2']:break
            if i.group(CS_GRP_JUMP):
                if i.operands[0].type==X86_OP_IMM:
                    dest=i.operands[0].imm
                    if lo<=dest<hi:pending.append(dest)
                    else:boundaries.append(dict(source=hex(at),target=hex(dest),kind='EXTERNAL_TAIL'))
                else:boundaries.append(dict(source=hex(at),target=i.op_str,kind='INDIRECT_TAIL_BOUND_BY_RAW_RGCXT'))
                if i.mnemonic=='jmp':break
            at+=i.size
    return dict(entry=hex(entry),scope='ORIGINAL_PDATA_OWNED_CALLER_CFG_NO_EXECUTION',instructions=[dict(va=hex(i.address),op=i.mnemonic,operands=i.op_str,bytes=i.bytes.hex()) for i in sorted(ins.values(),key=lambda i:i.address)],boundaries=boundaries)
evidence=[]
for row in plan['plans']:
    if row['group']=='COROUTINE_CORRECT_OBJECT_BASE_CONSTRUCTOR':
        c=json.loads((Q/'native-source'/(row['token']+'.json')).read_bytes());assert any(i['op']=='call' and i['operands']=='0x180302170' for i in c['instructions']);assert any(i['op']=='mov' and '+ 0x10]' in i['operands'] for i in c['instructions']);evidence.append(dict(token=row['token'],group=row['group'],native_base_constructor='0x180302170',native_base_bytes=pc.get_data(0x302170,3).hex(),native_store_offset=0x10))
    if row['group']=='WAIT_FACTORY_CALL_PUBLIC_CTOR_WITH_ACTUAL_CONTROLLER':
        ctor=methods[row['ctor_token']];cfg_=cfg(pointer(row['ctor_token']));(Q/'native-source'/(row['ctor_token']+'.json')).write_bytes((json.dumps(cfg_,indent=2)+'\n').encode());(Q/(row['ctor_token']+'.dependency-cil.json')).write_bytes((json.dumps(ctor,indent=2)+'\n').encode());subscribe=next(i for i in ctor['instructions'] if i['opcode']=='call' and i['operand']['name']=='Subscribe');evidence.append(dict(token=row['token'],group=row['group'],public_constructor=row['ctor_token'],constructor_native_entry=cfg_['entry'],constructor_private_subscription=subscribe['operand']['identity'],original_factory_private_subscription=row['private_subscription_token'],single_subscription_required=True))
bindings=json.loads((ROOT/'audit/bulk400-generic-repair-2026-10-24/evidence/original-generic-bindings.json').read_bytes());regs=json.loads((W/'startup-r16/RESEARCH.json').read_bytes());rgs={r['index']:r for r in regs['raw_rgctx']};assert rgs[23]['method_token']=='0x60008e8' and rgs[24]['owner']=='System.Collections.Generic.Dictionary`2' and rgs[24]['name']=='Clear' and rgs[24]['parameter_count']==0
for r in bindings['methods']:
    if r['token'] not in ['0x060008DA','0x060008E8']:continue
    cfg_=cfg(int(r['va'],16));variant='reference' if r['class_args']==['object'] else 'fully-shared';(Q/'native-source'/(r['token']+'-'+variant+'.json')).write_bytes((json.dumps(dict(cfg_,token=r['token'],variant=variant,binding=r),indent=2)+'\n').encode())
evidence.append(dict(token='0x060008DA',group='ASSOC_CLEAR_CALL_OWN_PUBLIC_LIST_CLEAR',raw_rgctx_list_clear=rgs[23],raw_rgctx_dictionary_clear=rgs[24],list_cil_dependency=methods['0x060008E8'],dictionary_clear_missing_from_parent_body=True));(Q/'0x060008E8.dependency-cil.json').write_bytes((json.dumps(methods['0x060008E8'],indent=2)+'\n').encode())
# Public SDK declaration only: establish the legal generic Dictionary.Clear
# MemberRef contract, without invoking a test or any candidate method.
sdk=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support/mscorlib.dll';core=dnfile.dnPE(data=sdk.read_bytes());t=next(t for t in core.net.mdtables.TypeDef.rows if str(t.TypeName)=='Dictionary`2' and str(t.TypeNamespace)=='System.Collections.Generic');clear=next(m.row for m in t.MethodList if str(m.row.Name)=='Clear');assert clear.Flags.mdPublic and clear.Signature.value==bytes.fromhex('200001');evidence.append(dict(group='AUTHENTIC_PUBLIC_DICTIONARY_CLEAR_DECLARATION',sdk_sha256=sha(sdk.read_bytes()),method='System.Void Dictionary<TKey,TValue>.Clear()',signature='200001',public=True))
r=dict(scope='READ_ONLY_NATIVE_AND_EXISTING_CIL_SOURCE_CONTRACTS_NO_TEST_EXECUTION',parent_sha256=plan['parent_sha256'],entries=evidence,tests_run=False);(Q/'EXTRA-SOURCE-EVIDENCE.json').write_bytes((json.dumps(r,indent=2)+'\n').encode());print('Source evidence retained for',len(evidence),'contracts; no suites executed')
