"""Original forty-four complete caller bodies, with explicit external contracts."""
from pathlib import Path
import ctypes as C,json,sys
Q=Path(__file__).resolve().parent;W=Q.parent;sys.dont_write_bytecode=True;sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
im=NativeImage();config=json.loads((Q/'COROUTINE-RUNTIME-SHAPES.json').read_bytes());methods={m['token']:m for m in config['methods']};state={};rows=[];dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True
def actor(id_):p=im.alloc(64);state['actors'][p]=id_;return p
def snapshot(p,shape):
    result={}
    for f in shape:
        at=p+f['offset'];role=f['role'];v=get32(at) if role=='state' else get64(at);result[role]=v if role=='state' else ('host' if v==state['owner'] else 'other-host' if v else None) if role=='owner' else state['actors'].get(v)
    return result
def allocate(cls):
    state['trace'].append('Allocate')
    if state['case']['mode']=='allocate-mutates-text':put64(state['owner']+0x20,actor('text-allocated'))
    p=im.alloc(256);put64(p,cls);return p
def start(owner,coroutine,method):
    assert owner==state['owner'] and not method;state['trace'].append('Start');state['started']=coroutine
    if state['case']['mode']=='start-mutates-text':put64(owner+0x20,actor('text-start'))
    return actor('coroutine')
def component(owner,method):
    assert owner==state['owner'];state['trace'].append('GetComponent')
    if state['case']['mode']=='getcomponent-mutates-text':put64(owner+0x20,actor('text-component'))
    return actor('component')
def barrier(at,value):assert get64(at)==(value or 0)
try:
    cfgs={t:json.loads((Q/'native-source'/(t+'.json')).read_bytes()) for t in methods};globals_=set()
    for cfg in cfgs.values():
        for r in cfg['instructions']:
            i=next(dis.disasm(bytes.fromhex(r['bytes']),int(r['va'],16)))
            if i.mnemonic not in ['lea','mov']:continue
            for o in i.operands:
                if o.type==X86_OP_MEM and o.mem.base==X86_REG_RIP:
                    at=i.address+i.size+o.mem.disp;encoded=int.from_bytes(im.pe.get_data(at-im.base,8),'little')
                    if encoded<=0xffffffff and encoded>>29 in range(1,8):globals_.add(at)
    for at in globals_:im.class_slot(at)
    def init(at):assert at in globals_;im.class_slot(at)
    im.hook(0x18024fef0,None,[P],init);im.hook(0x18024f360,None,[P,P],barrier);im.hook(0x180250100,P,[P],allocate);im.hook(0x18131dbe0,P,[P,P,P],start);im.hook(0x18042e9f0,P,[P,P],component)
    for token,cfg in cfgs.items():im.verify_caller(int(token,16)&0xffffff,int(cfg['entry'],16),cfg)
    assert C.string_at(0x180302170,3)==bytes.fromhex('c20000')
    for c in json.loads(Path(sys.argv[1]).read_bytes()):
        state.clear();state.update(case=c,actors={},trace=[],started=0);owner=im.alloc(256);state['owner']=owner;put64(owner+0x20,0 if c['host_text']==0 else actor('text-old' if c['host_text']==1 else 'text-other'));m=methods[c['token']];entry=int(m['native_entry'],16);shape=config['state_shapes'][c['state_type']];error=None
        if c['kind']=='ctor':
            result=im.alloc(256)
            for f in shape:
                if f['role']=='state':put32(result+f['offset'],123)
                elif f['role']=='owner':put64(result+f['offset'],owner)
                else:put64(result+f['offset'],actor(f['role']+'-seed'))
            before=C.string_at(result,256);C.CFUNCTYPE(None,P,I,P)(entry)(result,c['state_arg'],None);after=C.string_at(result,256);assert before[:0x10]==after[:0x10] and before[0x14:]==after[0x14:]
        else:
            value=C.CFUNCTYPE(P,P,P,P)(entry)(owner,0 if c['arg']==0 else actor('argument'),None) if m['args'] else C.CFUNCTYPE(P,P,P)(entry)(owner,None);result=value if m['returns_iterator'] else state['started']
        assert not im.errors,im.errors;rows.append(dict(name=c['name'],token=c['token'],kind=c['kind'],trace=list(state['trace']),state=snapshot(result,shape) if result else None,host_text=state['actors'].get(get64(owner+0x20)),error=error))
    report=dict(scope='FORTY_FOUR_ORIGINAL_PC_COMPLETE_CALLERS_WITH_CONTROLLED_HEAP_AND_ENGINE_CALLS',original_sha256=PC_SHA,all_caller_bytes_rechecked=True,object_base_constructor_original_bytes_executed=True,callback_errors=im.errors,real_unity_execution=False,native_exception_unwind=False,results=rows);Path(sys.argv[2]).write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(dict(cases=len(rows))))
finally:im.close()
