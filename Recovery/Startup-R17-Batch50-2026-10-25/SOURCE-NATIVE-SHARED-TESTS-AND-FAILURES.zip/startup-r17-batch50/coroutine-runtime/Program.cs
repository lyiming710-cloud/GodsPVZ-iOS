using System.Collections;using System.Reflection;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public class Actor(string id){public string Id=id;}
public class Host{public Actor? Text;public Actor? GetComponent(){Program.Trace.Add("GetComponent");if(Program.Current.mode=="getcomponent-mutates-text")Text=new("text-component");return new("component");}public Actor StartCoroutine(IEnumerator state){Program.Trace.Add("Start");Program.Started=(State)state;if(Program.Current.mode=="start-mutates-text")Text=new("text-start");return new("coroutine");}}
public class State:IEnumerator
{
    public int Number;public Host? Owner;public Actor? Text,Ctrl,CurrentValue;public State(int number){Program.Trace.Add("Allocate");if(Program.Current.mode=="allocate-mutates-text")Program.Owner.Text=new("text-allocated");Number=number;}public object? Current=>CurrentValue;public bool MoveNext()=>false;public void Reset()=>throw new NotSupportedException();
}
public class Case{public string name{get;set;}="";public string token{get;set;}="";public string kind{get;set;}="";public string mode{get;set;}="none";public string state_type{get;set;}="";public int state_arg{get;set;}public int host_text{get;set;}public int arg{get;set;}}
public class Shape{public string name{get;set;}="";public string role{get;set;}="";public int offset{get;set;}}
public class Method{public string token{get;set;}="";public string group{get;set;}="";public bool returns_iterator{get;set;}public string[] args{get;set;}=[];}
public class Config{public Method[] methods{get;set;}=[];public Dictionary<string,Shape[]> state_shapes{get;set;}=[];public string[] host_types{get;set;}=[];public string[] state_types{get;set;}=[];}
public static class Program
{
    public static Case Current=new();public static Host Owner=new();public static State? Started;public static List<string> Trace=[];static Config Data=new();
    static Type Map(MC.TypeReference t)
    {
        if(Data.state_types.Contains(t.FullName))return typeof(State);if(Data.host_types.Contains(t.FullName))return typeof(Host);
        return t.FullName switch{"System.Void"=>typeof(void),"System.Int32"=>typeof(int),"System.Boolean"=>typeof(bool),"System.Single"=>typeof(float),"System.Object"=>typeof(object),"System.String"=>typeof(string),"System.IntPtr"=>typeof(IntPtr),"System.Collections.IEnumerator"=>typeof(IEnumerator),"UnityEngine.MonoBehaviour" or "UnityEngine.Component"=>typeof(Host),"UnityEngine.Coroutine" or "TMPro.TMP_Text" or "FTRuntime.SwfClipController"=>typeof(Actor),_=>throw new NotSupportedException(t.FullName)};
    }
    static FieldInfo Field(MC.FieldReference f)
    {
        string name=f.Name switch{"<>1__state"=>nameof(State.Number),"<>4__this"=>nameof(State.Owner),"<>2__current"=>nameof(State.CurrentValue),"textComponent"=>nameof(State.Text),"ctrl"=>nameof(State.Ctrl),"m_TextComponent"=>nameof(Host.Text),_=>throw new NotSupportedException(f.FullName)};return Map(f.DeclaringType).GetField(name)!;
    }
    static MethodBase Method(MC.MethodReference m)
    {
        if(m.DeclaringType.FullName=="System.Object"&&m.Name==".ctor")return typeof(object).GetConstructor(Type.EmptyTypes)!;
        if(Data.state_types.Contains(m.DeclaringType.FullName)&&m.Name==".ctor")return typeof(State).GetConstructor(new[]{typeof(int)})!;
        if(m.Name=="StartCoroutine")return typeof(Host).GetMethod(nameof(Host.StartCoroutine))!;
        if(m.Name=="GetComponent")return typeof(Host).GetMethod(nameof(Host.GetComponent))!;
        throw new NotSupportedException(m.FullName);
    }
    static object Snapshot(State s,Shape[] fields){var d=new Dictionary<string,object?>();foreach(var f in fields)d[f.role]=f.role switch{"state"=>s.Number,"owner"=>s.Owner==null?null:ReferenceEquals(s.Owner,Owner)?"host":"other-host","text"=>s.Text?.Id,"ctrl"=>s.Ctrl?.Id,"current"=>s.CurrentValue?.Id,_=>throw new Exception(f.role)};return d;}
    public static void Main(string[] args)
    {
        Data=JsonSerializer.Deserialize<Config>(File.ReadAllText(args[1]))!;using var module=MC.ModuleDefinition.ReadModule(args[0]);var emitted=Data.methods.ToDictionary(x=>x.token,x=>ActualCil.Emit((MC.MethodDefinition)module.LookupToken(Convert.ToInt32(x.token,16)),Map,Field,Method));var methods=Data.methods.ToDictionary(x=>x.token);var rows=new List<object>();
        foreach(var c in JsonSerializer.Deserialize<List<Case>>(File.ReadAllText(args[2]))!)
        {
            Current=c;Trace=[];Started=null;Owner=new(){Text=c.host_text==0?null:new(c.host_text==1?"text-old":"text-other")};State? result=null;string? error=null;var m=methods[c.token];
            try{if(c.kind=="ctor"){result=(State)System.Runtime.CompilerServices.RuntimeHelpers.GetUninitializedObject(typeof(State));result.Number=123;result.Owner=Owner;result.Text=new("text-seed");result.Ctrl=new("ctrl-seed");result.CurrentValue=new("current-seed");emitted[c.token].Invoke(null,new object?[]{result,c.state_arg});}else{object?[] call=m.args.Length==0?new object?[]{Owner}:new object?[]{Owner,c.arg==0?null:new Actor("argument")};var value=emitted[c.token].Invoke(null,call);result=m.returns_iterator?(State?)value:Started;}}catch(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;error=e.GetType().FullName;}
            rows.Add(new{name=c.name,token=c.token,kind=c.kind,trace=Trace.ToArray(),state=result==null?null:Snapshot(result,Data.state_shapes[c.state_type]),host_text=Owner.Text?.Id,error});
        }
        File.WriteAllText(args[3],JsonSerializer.Serialize(new{scope="FORTY_FOUR_COMPLETE_ACTUAL_CANDIDATE_CIL_BODIES_WITH_CONTROLLED_ALLOCATION_STARTCOROUTINE_GETCOMPONENT",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),all_source_instructions_emitted=true,real_unity_execution=false,results=rows},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{cases=rows.Count}));
    }
}
