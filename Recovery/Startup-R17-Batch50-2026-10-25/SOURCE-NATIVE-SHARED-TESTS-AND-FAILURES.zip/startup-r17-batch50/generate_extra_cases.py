from pathlib import Path
import json
Q=Path(__file__).resolve().parent;O=Q/'extra-runtime-results';O.mkdir(exist_ok=True);rows=[]
for rid in [0x8a6,0x8a7,0x8a8,0x8a9]:
    for ctrl in [0,1,2]:
        for mode in ['none','allocate-flips-live','subscribe-returns-other']:rows.append(dict(name=f'case-{len(rows):04d}',kind='wait',token=f'0x{0x6000000|rid:08X}',ctrl_kind=ctrl,mode=mode))
for v in [-2147483648,-1,0,1,2,2147483647]:
    for p1,p2 in [(0,0),(8,11),(11,0),(0,11),(11,8),(8,0)]:
        for s in [False,True]:
            for mode in ['none','transform-flips-smoothing']:rows.append(dict(name=f'case-{len(rows):04d}',kind='camera',token='0x0600075A',vsync=v,platform1=p1,platform2=p2,smoothing=s,mode=mode))
for variant in ['reference','fully-shared']:
    for length in [0,1,3,7]:
        for size in range(length+1):
            for count in [0,3,9]:
                for mode in ['none','clear-replaces-dictionary','clear-mutates-size']:rows.append(dict(name=f'case-{len(rows):04d}',kind='clear',token='0x060008DA',length=length,size=size,dict_count=count,variant=variant,mode=mode))
(O/'CASES.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode());print('EXTRA CASES',len(rows))
