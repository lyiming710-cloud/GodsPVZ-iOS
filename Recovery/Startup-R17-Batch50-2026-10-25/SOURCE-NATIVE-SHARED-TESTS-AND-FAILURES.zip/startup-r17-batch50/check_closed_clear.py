from pathlib import Path
import copy,hashlib,importlib.util,json,re,sys
Q=Path(__file__).resolve().parent;ROOT=Q.parents[2];sys.dont_write_bytecode=True;source=json.loads((Q/'ALL-CIL.json').read_text('utf-8-sig'));original=next(m for m in source['methods'] if m['token']=='0x060008DA');f=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py';assert hashlib.sha256(f.read_bytes()).hexdigest()=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14';s=importlib.util.spec_from_file_location('unchanged_frozen',f);v=importlib.util.module_from_spec(s);s.loader.exec_module(v);models=[];rows=[]
for value in ['System.Int32','System.String']:
    def bind(x):
        if isinstance(x,str):return re.sub(r'(?<![\w.])T(?!\w)',value,x)
        if isinstance(x,list):return [bind(a) for a in x]
        if isinstance(x,dict):return {bind(k):bind(a) for k,a in x.items()}
        return x
    d=bind(copy.deepcopy(original));types=bind(copy.deepcopy(source['types']));d['owner']=original['owner']+'<'+value+'>'
    for k in types:
        if k in source['types']:types[k]=copy.deepcopy(source['types'][k])
    fact=copy.deepcopy(source['types'][original['owner']]);fact.pop('unbound',None);fact.pop('unresolved',None);types[d['owner']]=fact
    try:r=v.verify(d,types)
    except Exception as e:r=dict(token=d['token'],status='FAIL_OR_UNSUPPORTED',error=str(e))
    rows.append(dict(r,context=value));models.append((d,types))
d,t=copy.deepcopy(models[0]);next(i for i in d['instructions'] if i['opcode']=='ldfld')['operand']['owner']='FTRuntime.Internal.SwfAssocList`1<System.String>'
try:r=v.verify(d,t);rejected=r['status']!='PASS';why=r
except Exception as e:rejected=True;why=str(e)
active=json.loads((Q/'ACTIVE-INPUT.json').read_bytes());report=dict(scope='FINITE_INT32_STRING_GENERIC_CLEAR_MODELS_FROZEN_CHECKER_UNCHANGED',candidate_sha256=active['candidate_sha256'],passed=sum(r['status']=='PASS' for r in rows),total=2,results=rows,negative_control=dict(name='wrong-closed-receiver',rejected=rejected,reason=why),global_raw_census_preserved=True,universal_generic_proof=False);(Q/'CLOSED-CLEAR-TYPES.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(report,indent=2));assert report['passed']==2 and rejected
