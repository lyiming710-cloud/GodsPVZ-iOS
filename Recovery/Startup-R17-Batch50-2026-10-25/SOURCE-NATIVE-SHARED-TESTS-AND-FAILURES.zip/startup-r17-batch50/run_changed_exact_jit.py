"""Broad actual-DLL JIT precheck, no gameplay invocation or Unity license."""
from pathlib import Path
import concurrent.futures,collections,hashlib,json,subprocess
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];O=Q/'changed-exact-jit-results';O.mkdir(exist_ok=True)
dll=Q/'candidate3.dll';digest=hashlib.sha256(dll.read_bytes()).hexdigest();assert digest=='d2a645ad0d8164af5fbdcbd9fcaa578d5a28b27e7b13f3012cdb51e63a256091'
tokens=[r['token'] for r in json.loads((Q/'METHODS.json').read_bytes())['methods']];assert len(tokens)==50
dot=ROOT/'.local/dotnet10/dotnet.exe';probe=W/'startup-r5/jit-probe/bin/Release/net10.0/Probe.dll';support=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'
def one(token):
    out=O/(token+'.json')
    try:p=subprocess.run([str(dot),str(probe),str(dll),str(support),token,str(out)],capture_output=True,timeout=20)
    except subprocess.TimeoutExpired:
        r=dict(token=token,status='TIMEOUT_UNSUPPORTED',method_executed=False);out.write_bytes((json.dumps(r)+'\n').encode());return r
    (O/(token+'.stdout.log')).write_bytes(p.stdout);(O/(token+'.stderr.log')).write_bytes(p.stderr)
    if p.returncode or not out.exists():
        r=dict(token=token,status='PROCESS_FAILURE',exit_code=p.returncode,method_executed=False);out.write_bytes((json.dumps(r)+'\n').encode());return r
    r=json.loads(out.read_bytes());assert r['input_sha256']==digest and not r['method_executed'];return r
rows=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    for future in concurrent.futures.as_completed([pool.submit(one,t) for t in tokens]):
        rows.append(future.result())
        if len(rows)%50==0:
            progress=dict(completed=len(rows),total=len(tokens),counts=dict(collections.Counter(r['status'] for r in rows)))
            (O/'PROGRESS.json').write_bytes((json.dumps(progress)+'\n').encode());print(json.dumps(progress),flush=True)
report=dict(scope='CHANGED_FIFTY_EXACT_CLR_JIT_PRECHECK_NO_GAMEPLAY_EXECUTION',candidate_sha256=digest,methods=len(rows),counts=dict(collections.Counter(r['status'] for r in rows)),
    actual_method_execution=False,semantic_or_whole_game_acceptance=False,clr_width_permissiveness_known=True,rows=sorted(rows,key=lambda r:r['token']))
(O/'RESULT.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in report.items() if k!='rows'},indent=2))
