using System.Reflection;using System.Runtime.CompilerServices;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public class Actor(string id){public string Id=id;}
public class Ctrl(string id,bool live){public string Id=id;public bool Live=live;}
public class Wait
{
    public Ctrl? Target;public string Id="wait";
    public Wait(Ctrl? ctrl){Program.Trace.Add("Allocate");if(ctrl!=null&&Program.Current.mode=="allocate-flips-live")ctrl.Live=!ctrl.Live;Subscribe(ctrl);}
    public Wait Subscribe(Ctrl? ctrl){Program.Trace.Add("Subscribe:"+(ctrl?.Id??"null")+":"+(ctrl?.Live==true?1:0));if(ctrl?.Live==true)Target=ctrl;return Program.Current.mode=="subscribe-returns-other"?new Wait{Id="other"}:this;}
    private Wait(){}
}
public class Camera{public Actor? cameraTransform;public bool MovementSmoothing,previousSmoothing;public Actor GetTransform(){Program.Trace.Add("Transform");if(Program.Current.mode=="transform-flips-smoothing")MovementSmoothing=!MovementSmoothing;return new("transform");}}
public class ListState{public int[] Data=[];public int Size;public void Clear(){Program.Trace.Add("ArrayClear:"+Size);Array.Clear(Data,0,Size);if(Program.Current.mode=="clear-replaces-dictionary")Program.Assoc._dict=new("dict-new",9);if(Program.Current.mode=="clear-mutates-size")Size=19;Size=0;}}
public class DictState(string id,int count){public string Id=id;public int Count=count;public void Clear(){Program.Trace.Add("DictClear:"+Id);Count=0;}}
public class AssocState{public ListState? _list;public DictState? _dict;}
public class Case{public string name{get;set;}="";public string kind{get;set;}="";public string token{get;set;}="";public string mode{get;set;}="none";public string variant{get;set;}="reference";public int ctrl_kind{get;set;}=1;public int vsync{get;set;}public int platform1{get;set;}public int platform2{get;set;}public bool smoothing{get;set;}public int length{get;set;}public int size{get;set;}public int dict_count{get;set;}}
public static class Program
{
    public static Case Current=new();public static List<string> Trace=[];public static Camera Cam=new();public static AssocState Assoc=new();public static int Frame,Platforms;public static bool Simulate;
    public static int VSync(){Trace.Add("VSync:"+Current.vsync);return Current.vsync;}public static void SetFrame(int x){Trace.Add("Frame:"+x);Frame=x;}public static int Platform(){int x=Platforms++==0?Current.platform1:Current.platform2;Trace.Add("Platform:"+x);return x;}public static void Touch(bool x){Trace.Add("Touch:"+(x?1:0));Simulate=x;}
    static Type Map(MC.TypeReference t)
    {
        string n=t.FullName;if(n.StartsWith("FTRuntime.Yields.SwfWait"))return typeof(Wait);if(n.StartsWith("FTRuntime.Internal.SwfAssocList`1"))return typeof(AssocState);if(n.StartsWith("FTRuntime.Internal.SwfList`1"))return typeof(ListState);if(n.StartsWith("System.Collections.Generic.Dictionary`2"))return typeof(DictState);
        return n switch{"System.Void"=>typeof(void),"System.Int32" or "UnityEngine.RuntimePlatform"=>typeof(int),"System.Boolean"=>typeof(bool),"System.Object"=>typeof(object),"System.IntPtr"=>typeof(IntPtr),"FTRuntime.SwfClipController"=>typeof(Ctrl),"TMPro.Examples.CameraController" or "UnityEngine.Component"=>typeof(Camera),"UnityEngine.Transform"=>typeof(Actor),_=>throw new NotSupportedException(n)};
    }
    static FieldInfo Field(MC.FieldReference f)=>Map(f.DeclaringType).GetField(f.Name)!;
    static MethodBase Method(MC.MethodReference m)
    {
        if(m.Name==".ctor"&&m.DeclaringType.FullName.StartsWith("FTRuntime.Yields.SwfWait"))return typeof(Wait).GetConstructor(new[]{typeof(Ctrl)})!;
        if(m.Name=="Subscribe")return typeof(Wait).GetMethod(nameof(Wait.Subscribe))!;
        if(m.Name=="Clear")return Map(m.DeclaringType).GetMethod("Clear")!;
        if(m.Name=="get_transform")return typeof(Camera).GetMethod(nameof(Camera.GetTransform))!;
        return m.Name switch{"get_vSyncCount"=>typeof(Program).GetMethod(nameof(VSync))!,"set_targetFrameRate"=>typeof(Program).GetMethod(nameof(SetFrame))!,"get_platform"=>typeof(Program).GetMethod(nameof(Platform))!,"set_simulateMouseWithTouches"=>typeof(Program).GetMethod(nameof(Touch))!,_=>throw new NotSupportedException(m.FullName)};
    }
    public static void Main(string[] args)
    {
        using var module=MC.ModuleDefinition.ReadModule(args[0]);string[] tokens=["0x060008A6","0x060008A7","0x060008A8","0x060008A9","0x0600075A","0x060008DA"];var emitted=tokens.ToDictionary(t=>t,t=>ActualCil.Emit((MC.MethodDefinition)module.LookupToken(Convert.ToInt32(t,16)),Map,Field,Method));var rows=new List<object>();
        foreach(var c in JsonSerializer.Deserialize<List<Case>>(File.ReadAllText(args[1]))!)
        {
            Current=c;Trace=[];object? state=null;string? error=null;
            try
            {
                if(c.kind=="wait"){Ctrl? ctrl=c.ctrl_kind==0?null:new("ctrl",c.ctrl_kind==1);var w=(Wait)emitted[c.token].Invoke(null,new object?[]{ctrl})!;state=new{id=w.Id,target=w.Target?.Id,target_live=w.Target?.Live,ctrl_live=ctrl?.Live};}
                else if(c.kind=="camera"){Frame=1234;Platforms=0;Simulate=true;Cam=new(){MovementSmoothing=c.smoothing,previousSmoothing=!c.smoothing};emitted[c.token].Invoke(null,new object?[]{Cam});state=new{frame=Frame,platform_calls=Platforms,simulate=Simulate,transform=Cam.cameraTransform?.Id,smoothing=Cam.MovementSmoothing,previous=Cam.previousSmoothing};}
                else {var list=new ListState{Size=c.size,Data=Enumerable.Range(1,c.length).ToArray()};var old=new DictState("dict",c.dict_count);Assoc=new(){_list=list,_dict=old};emitted[c.token].Invoke(null,new object?[]{Assoc});state=new{size=list.Size,data=list.Data,dict_id=Assoc._dict?.Id,dict_count=Assoc._dict?.Count,old_dict_count=old.Count};}
            }catch(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;error=e.GetType().FullName;}
            rows.Add(new{name=c.name,token=c.token,kind=c.kind,trace=Trace.ToArray(),state,error});
        }
        var nulls=new List<object>();foreach(bool nullList in new[]{true,false}){Current=new();Trace=[];var list=new ListState{Data=[1,2,3],Size=2};Assoc=new(){_list=nullList?null:list,_dict=nullList?new("dict",3):null};string? error=null;try{emitted["0x060008DA"].Invoke(null,new object?[]{Assoc});}catch(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;error=e.GetType().FullName;}nulls.Add(new{null_list=nullList,error,trace=Trace.ToArray(),size=list.Size,data=list.Data});}
        File.WriteAllText(args[2],JsonSerializer.Serialize(new{scope="SIX_COMPLETE_ACTUAL_CANDIDATE_CIL_CALLERS_CONTROLLED_WAIT_ENGINE_AND_COLLECTION_CALLEES",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),all_source_instructions_emitted=true,real_unity_execution=false,results=rows,managed_null_controls=nulls},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{cases=rows.Count}));
    }
}
