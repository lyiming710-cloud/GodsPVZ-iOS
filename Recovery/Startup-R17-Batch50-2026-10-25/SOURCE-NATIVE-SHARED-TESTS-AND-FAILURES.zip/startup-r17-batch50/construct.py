"""Construct exactly fifty new source repairs before any new test round."""
from pathlib import Path
import hashlib,importlib.util,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
def mod(n,p):s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
writer=mod('raw_metadata',W/'startup-r2/construct.py');labels=mod('il_labels',W/'startup-r13/construct.py');IL=labels.IL;sha=lambda b:hashlib.sha256(b).hexdigest()
def build(output,report_path,capture_fix=False):
    output=Path(output);report_path=Path(report_path);assert not output.exists() and not report_path.exists();parent=(W/'startup-r16/candidate1.dll').read_bytes();digest=sha(parent);assert digest=='5454887dc125cf56b7de5fc6079441075b91972e64db40e52f70d1129a87c73f';pe=dnfile.dnPE(data=parent);out=bytearray(parent);plan=json.loads((Q/'SOURCE-PLAN.json').read_bytes());extra=json.loads((Q/'EXTRA-SOURCE-EVIDENCE.json').read_bytes());assert plan['new_unique_methods']==50 and extra['parent_sha256']==digest and not plan['tests_run'];changes=[];allowed=set()
    def body(token):
        row=pe.net.mdtables.MethodDef.rows[(int(token,16)&0xffffff)-1];at=pe.get_offset_from_rva(row.Rva);h=1 if parent[at]&3==2 else (struct.unpack_from('<H',parent,at)[0]>>12)*4;n=parent[at]>>2 if h==1 else struct.unpack_from('<I',parent,at+4)[0];assert sum(r.Rva==row.Rva for r in pe.net.mdtables.MethodDef.rows)==1;return at,h,parent[at+h:at+h+n]
    base_ctor=next(0xa000000|k for k,r in enumerate(pe.net.mdtables.MemberRef.rows,1) if str(r.Name)=='.ctor' and getattr(r.Class.row,'TypeName',None)=='Object' and r.Signature.value==bytes.fromhex('200001'))
    cli=pe.get_offset_from_rva(pe.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress);mrva,msize=struct.unpack_from('<II',parent,cli+8);mat=pe.get_offset_from_rva(mrva);root,streams=writer.metadata_root(parent[mat:mat+msize]);values={n:b for n,_,b in streams};th,rows,tail,counts=writer.tables_decode(values['#~']);newrefs=[]
    def member(owner):
        for k,r in enumerate(pe.net.mdtables.MemberRef.rows,1):
            if str(r.Name)=='Clear' and rows[10][k-1][0]==owner and r.Signature.value==bytes.fromhex('200001'):return 0xa000000|k
        n=values['#Strings'].find(b'Clear\0');assert n>=0 and values['#Strings'][n-1]==0;sig=next(rows[10][k-1][2] for k,r in enumerate(pe.net.mdtables.MemberRef.rows,1) if r.Signature.value==bytes.fromhex('200001'));rows[10].append([owner,n,sig]);token=0xa000000|len(rows[10]);newrefs.append(dict(token=f'0x{token:08X}',name='Clear',owner_coded=owner,signature='200001'));return token
    listclear=member(1244);dictclear=member(1276);newlocals=[]
    for p in plan['plans']:
        token=p['token'];at,h,old=body(token);code=bytearray(old);group=p['group'];bounds=[];new_size=len(old)
        if group=='COROUTINE_FACTORY_DUPLICATE_PRIVATE_STATE_WRITE' and token=='0x06000784' and capture_fix:
            m=json.loads((Q/(token+'.parent-cil.json')).read_bytes());ins=m['instructions'];local_count=len(m['locals']);assert local_count<128 and h==12
            def itok(i):return int.from_bytes(old[i['offset']+1:i['offset']+5],'little')
            text=itok(next(i for i in ins if i['opcode']=='ldfld' and i['operand']['identity'].endswith('::m_TextComponent')));owner=itok(next(i for i in ins if i['opcode']=='stfld' and i['operand']['identity'].endswith('::<>4__this')));target=itok(next(i for i in ins if i['opcode']=='stfld' and i['operand']['identity'].endswith('::textComponent')));ctor=itok(next(i for i in ins if i['opcode']=='newobj'));start_coroutine=itok(next(i for i in ins if i['opcode']=='call'))
            old_sig_token=int.from_bytes(parent[at+8:at+12],'little');old_sig=pe.net.mdtables.StandAloneSig.rows[(old_sig_token&0xffffff)-1].Signature.value;assert old_sig[:2]==bytes([7,local_count]);field_sig=pe.net.mdtables.Field.rows[(text&0xffffff)-1].Signature.value;assert field_sig[0]==6;new_sig=bytes([7,local_count+1])+old_sig[2:]+field_sig[1:];index=len(values['#Blob']);values['#Blob']+=labels.comp(len(new_sig))+new_sig;rows[17].append([index]);sig_token=0x11000000|len(rows[17]);struct.pack_into('<I',out,at+8,sig_token);bounds.append((at+8,at+12));newlocals.append(dict(method=token,old_token=hex(old_sig_token),new_token=hex(sig_token),old_signature=old_sig.hex(),new_signature=new_sig.hex(),appended_type='TMPro.TMP_Text',reason='Capture original native RSI text receiver before allocation'))
            code=bytearray(IL().arg(0).token(0x7b,text).store(local_count).op('16').token(0x73,ctor).store(1).loc(1).arg(0).token(0x7d,owner).loc(1).loc(local_count).token(0x7d,target).arg(0).loc(1).token(0x28,start_coroutine).op('262a').finish());new_size=len(code);bounds.append((at+h,at+h+new_size))
        elif group=='COROUTINE_FACTORY_DUPLICATE_PRIVATE_STATE_WRITE':
            start,end=p['remove_span']['start'],p['remove_span']['end'];assert old[start:end].hex()==p['remove_span']['bytes'];code[start:end]=b'\0'*(end-start);bounds.append((at+h+start,at+h+end))
        elif group=='COROUTINE_CORRECT_OBJECT_BASE_CONSTRUCTOR':
            off=p['call_offset'];assert old[off]==0x28 and int.from_bytes(old[off+1:off+5],'little')==int(p['old_call_token'],16);code[off:off+5]=b'\x28'+struct.pack('<I',base_ctor);bounds.append((at+h+off,at+h+off+5))
        elif group=='WAIT_FACTORY_CALL_PUBLIC_CTOR_WITH_ACTUAL_CONTROLLER':
            # One constructor call replaces ctor(null) plus a second Subscribe.
            code=bytearray(IL().arg(0).token(0x73,int(p['ctor_token'],16)).op('2a').finish());new_size=len(code);bounds.append((at+h,at+h+new_size))
        elif group=='ASSOC_CLEAR_CALL_OWN_PUBLIC_LIST_CLEAR':
            code=bytearray(IL().arg(0).token(0x7b,0x0a0003cf).token(0x6f,listclear).arg(0).token(0x7b,0x0a0003d0).token(0x6f,dictclear).op('2a').finish());new_size=len(code);bounds.append((at+h,at+h+new_size))
        elif group=='CAMERA_AWAKE_NATIVE_INT32_SENTINELS':
            assert old[10:19]==bytes.fromhex('21ffffffff00000000');code[10:19]=bytes.fromhex('20ffffffff00000000');bounds.append((at+h+10,at+h+19))
        else:raise ValueError(group)
        assert len(code)<=len(old) and code!=old;out[at+h:at+h+len(code)]=code
        if new_size!=len(old):
            assert h==12;struct.pack_into('<I',out,at+4,new_size);bounds.append((at+4,at+8))
        for a,b in bounds:allowed.update(range(a,b))
        changes.append(dict(token=token,name=p['name'],group=group,rva=hex(pe.net.mdtables.MethodDef.rows[(int(token,16)&0xffffff)-1].Rva),file_offset=at,old_code_size=len(old),new_code_size=new_size,old_code_sha256=sha(old),new_code_sha256=sha(code),changed_code=bytes(code).hex(),write_ranges=[dict(start=a,end=b) for a,b in bounds],source_status='CONSTRUCTED_UNTESTED',acceptance='PENDING_SHARED_BATCH_TESTS'))
    assert len(changes)==len({r['token'] for r in changes})==50
    values['#~']=writer.tables_encode(th,rows,tail,counts);metadata=bytearray(root)
    for n,header,_ in streams:
        start=writer.align(len(metadata),4);metadata.extend(b'\0'*(start-len(metadata)));struct.pack_into('<II',metadata,header,start,len(values[n]));metadata.extend(values[n])
    last=pe.sections[-1];assert last.Name.rstrip(b'\0')==b'.n29meta' and last.Characteristics==0x40000040 and last.PointerToRawData+last.SizeOfRawData==len(parent);start=writer.align(len(out),4);out.extend(b'\0'*(start-len(out)));out.extend(metadata);end=len(out);raw_size=writer.align(end-last.PointerToRawData,pe.OPTIONAL_HEADER.FileAlignment);out.extend(b'\0'*(last.PointerToRawData+raw_size-len(out)));sh=last.get_file_offset();opt=pe.OPTIONAL_HEADER.get_file_offset();updates={sh+8:end-last.PointerToRawData,sh+16:raw_size,opt+8:pe.OPTIONAL_HEADER.SizeOfInitializedData+raw_size-last.SizeOfRawData,opt+56:writer.align(last.VirtualAddress+end-last.PointerToRawData,pe.OPTIONAL_HEADER.SectionAlignment),opt+64:0,cli+8:last.VirtualAddress+start-last.PointerToRawData,cli+12:len(metadata)}
    for a,v in updates.items():struct.pack_into('<I',out,a,v);allowed.update(range(a,a+4))
    assert all(x==y or i in allowed for i,(x,y) in enumerate(zip(parent,out))),'Construction attempted an unplanned prefix write';output.write_bytes(out);report=dict(scope='FIFTY_SELECTED_METHOD_BODIES_WITH_CAPTURE_CORRECTION_RUNTIME_PENDING' if capture_fix else 'FIFTY_NEW_METHOD_BODIES_CONSTRUCTED_BEFORE_FIRST_SHARED_TEST',parent_sha256=digest,candidate_sha256=sha(out),bytes=len(out),new_unique_methods=50,unchanged_methoddefs_expected=2267,groups=plan['groups'],new_memberrefs=newrefs,new_private_local_signatures=newlocals,changes=changes,header_updates={str(k):v for k,v in updates.items()},test_status='CAPTURE_CORRECTION_AWAITING_SHARED_RECHECK' if capture_fix else 'NOT_RUN_THRESHOLD_JUST_REACHED',first_fifty_constructed_before_tests=True,qualified_methods=0,unity_or_ipa=False);report_path.write_bytes((json.dumps(report,indent=2)+'\n').encode());(Q/'METHODS.json').write_bytes((json.dumps(dict(methods=[dict(token=r['token']) for r in changes]),indent=2)+'\n').encode());print(json.dumps({k:v for k,v in report.items() if k not in ['changes','header_updates']},indent=2))
if __name__=='__main__':build(sys.argv[1],sys.argv[2],len(sys.argv)>3 and sys.argv[3]=='--capture-fix')
