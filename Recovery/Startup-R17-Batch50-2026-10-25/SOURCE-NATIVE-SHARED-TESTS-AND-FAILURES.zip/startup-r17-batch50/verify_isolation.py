"""Independent all-MethodDef and raw metadata boundary audit after batch fifty."""
from pathlib import Path
import hashlib,importlib.util,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
def mod(n,p):s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
writer=mod('metadata_read',W/'startup-r2/construct.py');reader=mod('body_read',ROOT/'audit/native111-publication-2026-10-20/repository/scripts/actions/static_gates.py');sha=lambda b:hashlib.sha256(b).hexdigest();a=(W/'startup-r16/candidate1.dll').read_bytes();b=(Q/'candidate3.dll').read_bytes();assert sha(a)=='5454887dc125cf56b7de5fc6079441075b91972e64db40e52f70d1129a87c73f' and sha(b)=='d2a645ad0d8164af5fbdcbd9fcaa578d5a28b27e7b13f3012cdb51e63a256091' and b==(Q/'candidate4.dll').read_bytes();pp=dnfile.dnPE(data=a);cp=dnfile.dnPE(data=b)
parent_cil=json.loads((W/'startup-r16/ALL-CIL.json').read_text('utf-8-sig'));old={r['token']:r for r in parent_cil['methods']};new_cil=json.loads((Q/'ALL-CIL.json').read_text('utf-8-sig'));new={r['token']:r for r in new_cil['methods']};access=json.loads((W/'startup-r16/MEMBER-ACCESS-ALL-2297.json').read_bytes());factories={r['token'] for r in access['members'] if not r['allowed'] and r.get('member','').endswith('::<>1__state')};assert len(factories)==27;ctors={}
for token in factories:
    i=old[token]['instructions'];store=next(i for i in i if i['opcode']=='stfld' and i['operand']['identity'].endswith('::<>1__state'));ctor=next(m for m in old.values() if m['owner']==store['operand']['owner'] and m['name'].endswith('::.ctor(System.Int32)'));ctors[ctor['token']]=ctor
assert len(ctors)==17;waits={f'0x{0x6000000|rid:08X}' for rid in [0x8a6,0x8a7,0x8a8,0x8a9]};targets=factories|set(ctors)|waits|{'0x060008DA','0x0600075A'};assert len(targets)==50
def meta(data,p):
    cli=p.get_offset_from_rva(p.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress);rva,size=struct.unpack_from('<II',data,cli+8);at=p.get_offset_from_rva(rva);_,ss=writer.metadata_root(data[at:at+size]);values={n:b for n,_,b in ss};_,rows,_,_=writer.tables_decode(values['#~']);return at,values,rows
_,pv,pr=meta(a,pp)
def metadata_check(data,p):
    at,v,rows=meta(data,p);assert at==len(a) and set(v)==set(pv) and set(rows)==set(pr)
    for n in pv:
        if n=='#Blob':assert v[n].startswith(pv[n])
        elif n!='#~':assert v[n]==pv[n]
    for t in pr:
        if t==10:assert rows[t][:-2]==pr[t] and len(rows[t])==len(pr[t])+2
        elif t==17:assert rows[t][:-1]==pr[t] and len(rows[t])==len(pr[t])+1
        else:assert rows[t]==pr[t]
    for r,sig in zip(p.net.mdtables.MemberRef.rows[-2:],['151284d8011300','1512811102130008']):assert str(r.Name)=='Clear' and r.Signature.value==bytes.fromhex('200001') and r.Class.table.name=='TypeSpec' and r.Class.row.Signature.value.hex()==sig
    assert p.net.mdtables.StandAloneSig.rows[-1].Signature.value==bytes.fromhex('07041283e41283e812823d128081')
metadata_check(b,cp);allowed=set();changed=[];shape=[]
def loc(data,p,token):
    row=p.net.mdtables.MethodDef.rows[(int(token,16)&0xffffff)-1];at=p.get_offset_from_rva(row.Rva);h=1 if data[at]&3==2 else (struct.unpack_from('<H',data,at)[0]>>12)*4;n=data[at]>>2 if h==1 else struct.unpack_from('<I',data,at+4)[0];return at,h,data[at+h:at+h+n]
for rid,(x,y) in enumerate(zip(pp.net.mdtables.MethodDef.rows,cp.net.mdtables.MethodDef.rows),1):
    assert x.Rva==y.Rva
    if not x.Rva:continue
    token=f'0x{0x6000000|rid:08X}';at=pp.get_offset_from_rva(x.Rva);n=reader.parse_raw_method_body_span(a,at)[0];m=reader.parse_raw_method_body_span(b,at)[0]
    if a[at:at+n]!=b[at:at+m]:changed.append(token)
    if token not in targets:assert n==m and a[at:at+n]==b[at:at+m];continue
    at,h,oc=loc(a,pp,token);bt,j,nc=loc(b,cp,token);assert at==bt and h==j and old[token]['locals']+(['TMPro.TMP_Text'] if token=='0x06000784' else [])==new[token]['locals'] and old[token]['maxStack']==new[token]['maxStack'] and old[token]['handlers']==new[token]['handlers'];expected=bytearray(oc)
    if token=='0x06000784':
        i=new[token]['instructions'];assert [x['opcode'] for x in i]==['ldarg.0','ldfld','stloc.s','ldc.i4.0','newobj','stloc.s','ldloc.s','ldarg.0','stfld','ldloc.s','ldloc.s','stfld','ldarg.0','ldloc.s','call','pop','ret'];assert i[1]['operand']['identity'].endswith('::m_TextComponent') and i[2]['operand']['index']==i[10]['operand']['index']==3 and i[5]['operand']['index']==i[6]['operand']['index']==i[9]['operand']['index']==i[13]['operand']['index']==1 and i[8]['operand']['identity'].endswith('::<>4__this') and i[11]['operand']['identity'].endswith('::textComponent') and i[14]['operand']['name']=='StartCoroutine';assert int.from_bytes(b[at+8:at+12],'little')==0x11000000|len(cp.net.mdtables.StandAloneSig.rows);allowed.update(range(at+8,at+12))
    elif token in factories:
        ins=old[token]['instructions'];k=next(k for k,i in enumerate(ins) if i['opcode']=='stfld' and i['operand']['identity'].endswith('::<>1__state'));start=ins[k-2]['offset'];end=ins[k]['offset']+5;assert all(i['opcode'].startswith(('ldloc','ldc.i4','stfld')) for i in ins[k-2:k+1]);expected[start:end]=b'\0'*(end-start);assert bytes(expected)==nc;allowed.update(range(at+h+start,at+h+end));assert not any(i['opcode']=='stfld' and i['operand']['identity'].endswith('::<>1__state') for i in new[token]['instructions'])
    elif token in ctors:
        call=next(i for i in old[token]['instructions'] if i['opcode']=='call');k=call['offset'];expected[k:k+5]=bytes.fromhex('28b600000a');assert expected==nc;allowed.update(range(at+h+k,at+h+k+5));first=next(i for i in new[token]['instructions'] if i['opcode']=='call');assert first['operand']['identity']=='System.Void System.Object::.ctor()'
    elif token in waits:
        ins=new[token]['instructions'];assert [i['opcode'] for i in ins]==['ldarg.0','newobj','ret'] and ins[1]['operand']['args']==['FTRuntime.SwfClipController'];assert ins[1]['operand']['identity']==next(i['operand']['identity'] for i in old[token]['instructions'] if i['opcode']=='newobj')
    elif token=='0x060008DA':
        i=new[token]['instructions'];assert [x['opcode'] for x in i]==['ldarg.0','ldfld','callvirt','ldarg.0','ldfld','callvirt','ret'];assert [x['operand']['identity'] for x in i if x['opcode']=='callvirt']==['System.Void FTRuntime.Internal.SwfList`1<T>::Clear()','System.Void System.Collections.Generic.Dictionary`2<T,System.Int32>::Clear()'];assert i[1]['operand']['identity'].endswith('::_list') and i[4]['operand']['identity'].endswith('::_dict')
    else:assert token=='0x0600075A';assert oc[10:19]==bytes.fromhex('21ffffffff00000000');expected[10:19]=bytes.fromhex('20ffffffff00000000');assert expected==nc;allowed.update(range(at+h+10,at+h+19))
    if token in waits or token in ['0x060008DA','0x06000784']:assert h==12 and len(nc)<len(oc) and a[at:at+4]==b[at:at+4] and (token=='0x06000784' or a[at+8:at+h]==b[at+8:at+h]) and a[at+h+len(nc):at+h+len(oc)]==b[at+h+len(nc):at+h+len(oc)];allowed.update(range(at+4,at+8));allowed.update(range(at+h,at+h+len(nc)))
    shape.append(dict(token=token,decoded_and_raw_contract_checked=True))
assert set(changed)==targets
sh=pp.sections[-1].get_file_offset();opt=pp.OPTIONAL_HEADER.get_file_offset();cli=pp.get_offset_from_rva(pp.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress);allowed.update(at+i for at in [sh+8,sh+16,opt+8,opt+56,opt+64,cli+8,cli+12] for i in range(4));assert pp.sections[-1].Characteristics==cp.sections[-1].Characteristics==0x40000040
def boundary(data):assert len(data)==len(b) and not any(x!=y and k not in allowed for k,(x,y) in enumerate(zip(a,data)));metadata_check(data,dnfile.dnPE(data=data))
boundary(b);controls=[]
for name,at in [('non-target-body',pp.get_offset_from_rva(pp.net.mdtables.MethodDef.rows[0x526-1].Rva)+12),('old-metadata',pp.get_offset_from_rva(pp.net.struct.MetaDataRva)),('constructor-maxstack',loc(a,pp,next(iter(ctors)))[0]+2)]:
    data=bytearray(b);data[at]^=1
    try:boundary(data)
    except AssertionError:controls.append(dict(name=name,rejected=True));continue
    raise AssertionError('False boundary accept')
r=dict(scope='INDEPENDENT_ALL_METHODDEF_METADATA_AND_FIFTY_DECODED_CIL_SOURCE_CONTRACTS',candidate_sha256=sha(b),parent_sha256=sha(a),pass_=True,changed_methods=50,unchanged_methoddefs=2267,old_metadata_rows_heap_prefixes_preserved=True,new_memberrefs=2,new_private_local_signatures=1,new_typespecs=0,new_methoddefs=0,rvas_maxstack_visibility_and_readonly_flags_unchanged=True,old_local_entries_preserved_one_text_local_appended=True,unused_old_slots_preserved=True,negative_controls=controls,shape_rows=shape,whole_game_acceptance=False);(Q/'ISOLATION-AND-CIL-SPEC.json').write_bytes((json.dumps(r,indent=2)+'\n').encode());(Q/'METHOD-CIL.json').write_bytes((json.dumps(dict(types=new_cil['types'],methods=[new[t] for t in sorted(targets)]),indent=2)+'\n').encode());print(json.dumps({k:v for k,v in r.items() if k!='shape_rows'},indent=2))
