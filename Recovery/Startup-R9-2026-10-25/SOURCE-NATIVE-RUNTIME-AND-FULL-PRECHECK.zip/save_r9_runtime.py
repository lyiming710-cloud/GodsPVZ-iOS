from pathlib import Path
import json
from archive_support import sha,js,pack,variants,manifest
W=Path(__file__).resolve().parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113';Q=W/'startup-r9';D=R/'Recovery/Startup-R9-2026-10-25';D.mkdir(exist_ok=True)
data=(Q/'candidate1.dll').read_bytes();digest=sha(data);assert digest=='738ebc37ebdea606011294728ffeaa6a2128d19417905856729efe5947f5577e'
new=json.loads((Q/'runtime-results/RESULT.json').read_bytes());assert new['pass_'] and new['constant_cases']==80 and new['simple_cases']==912
isolation=json.loads((Q/'ISOLATION.json').read_bytes());assert isolation['pass_'] and len(isolation['actual_changed_tokens'])==6 and isolation['untouched_methoddefs']==2311
whole=json.loads((Q/'all-exact-jit-results/RESULT.json').read_bytes());assert whole['counts']==dict(JIT_PREPARED_NO_EXECUTION=2246,UNSUPPORTED=50,REJECTED=1)
runtime=[]
for name in ['admin','board','system','buff','events']:
    value=json.loads((Q/f'{name}-runtime-results/RESULT.json').read_bytes());assert value['pass_'] and value['candidate_sha256']==digest;runtime.append(dict(suite=name,result=value))
assert sum(r['result']['cases'] for r in runtime)==2475
js(Q/'RUNTIME-SUMMARY.json',dict(scope='TWELVE_METHODS_IN_SEPARATE_ORIGINAL_PC_CALLER_SCOPES_NOT_FULL_GAME',candidate_sha256=digest,methods=12,prior_cases=2475,new_cases=992,total_cases=3467,prior_suites=runtime,new_suite=new,whole_game_acceptance=False))
js(Q/'PHYSICAL-VARIANTS.json',dict(scope='EXACT_RECONSTRUCTION_OF_EXECUTED_CURRENT_FAULT_VARIANTS',variants=variants(Q,data)))
js(Q/'NEXT-JIT-QUEUE.json',dict(candidate_sha256=digest,scope='LAST_CLR_JIT_REJECTION_NOT_LAST_GAME_BUG',rows=[r for r in whole['rows'] if r['status']=='REJECTED'],note='Plant.PC_Nutknight native converts Floor result with CVTTSD2SI before integer clamp. A float-zero substitution would lose overflow/NaN behavior; method needs full dataflow qualification.'))
(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text whitespace=cr-at-eol\n*.md -text\n*.zip -text\n')
for name in ['CONSTRUCTION.json','ISOLATION.json','INDEPENDENT-CIL-SPEC.json','FROZEN-UNION.json','INT64-NEGATIVE-WIDTH.json','LEXICAL-TAIL-CENSUS.json','RUNTIME-SUMMARY.json','NEXT-JIT-QUEUE.json']:(D/name).write_bytes((Q/name).read_bytes())
(D/'EXACT-JIT-SIX.json').write_bytes((Q/'exact-jit-results/RESULT.json').read_bytes());(D/'EXACT-JIT-ALL-2297.json').write_bytes((Q/'all-exact-jit-results/RESULT.json').read_bytes())
pack(D/'STARTUP-R9-CANDIDATE.zip',[('STARTUP-R9.dll',data)])
items=[]
for p in sorted(Q.rglob('*')):
    if not p.is_file() or any(x in ['obj','__pycache__'] for x in p.relative_to(Q).parts):continue
    if p.suffix=='.dll' and 'bin' not in p.relative_to(Q).parts:continue
    if p.name=='Mono.Cecil.dll' or p.suffix=='.exe':continue
    items.append((p.relative_to(W).as_posix(),p.read_bytes()))
for p in sorted((W/'startup-r5').rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(W/'startup-r5')
    if any(x in ['obj','__pycache__'] or x.endswith('-runtime-results') for x in rel.parts):continue
    if p.suffix=='.dll' and 'bin' not in rel.parts:continue
    if p.name=='Mono.Cecil.dll' or p.suffix=='.exe':continue
    if p.suffix not in ['.py','.cs','.csproj','.dll','.json','.pdb']:continue
    items.append((p.relative_to(W).as_posix(),p.read_bytes()))
for folder in ['remaining-native','administrator-next-native','next-runtime-native']:
    for p in sorted((W/folder).glob('*')):
        if p.is_file() and ('.normal-cfg.' in p.name or p.name in ['construct_r9.py','FMOD-HELPER-CFG.json']):items.append((p.relative_to(W).as_posix(),p.read_bytes()))
for p in [W/'archive_support.py',Path(__file__),W/'startup-r5/runtime-admin/bin/Release/net10.0/Mono.Cecil.dll']:items.append((p.relative_to(W).as_posix(),p.read_bytes()))
for p in [ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py',ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support/Unity.VisualScripting.Core.exe']:items.append(('required-tools/'+p.name,p.read_bytes()))
pack(D/'SOURCE-NATIVE-RUNTIME-AND-FULL-PRECHECK.zip',items)
js(D/'CURRENT-RESULT.json',dict(status='SIX_NATIVE_BACKED_BODIES_AND_TWELVE_SCOPED_CALLER_TESTS_FULL_PIPELINE_HELD',candidate_sha256=digest,parent_sha256='6189387c6af11108eba9a9855bfd6d6af567ec000a4999d1ed1b0328ba0e1d08',bytes=len(data),direct_method_targets=6,
    physical_body_slots=3,untouched_methoddefs=2311,metadata_and_rvas_unchanged=True,new_runtime_cases=992,prior_runtime_cases=2475,total_scoped_runtime_cases=3467,scoped_caller_methods=12,
    original_native_constant_methods=5,original_fmod_helper_executed=True,whole_assembly={'methods':2297,'jit':whole['counts'],'raw_frozen':{'pass':2137,'fail_or_unsupported':160},'interface_fact_frozen':{'pass':2165,'fail_or_unsupported':132},'member_rejected_sites':216,'member_rejected_methods':111,'member_unresolved':0,'unterminated_lexical_tails':0,'all_pass':False},
    frozen_union={'methods':186,'pass':174,'fail_or_unsupported':12},last_jit_rejection='0x06000383 Plant.PC_Nutknight',r9_unity='NOT_RUN',r9_il2cpp='NOT_RUN',r9_apple_cpp='NOT_RUN',ipa=None,ipad_device_acceptance=False,
    separate_parent_editor_result='R8 run 40115001552 scoped PASS; does not promote this child'))
(D/'README.md').write_bytes('''# Startup R9 — original constant bodies and real native fmod caller recovery

Candidate `738ebc37ebdea606011294728ffeaa6a2128d19417905856729efe5947f5577e`, 18,863,104 bytes; parent R8 `6189387c…0e1d08`. Six methods change, spanning three physical body slots. Four false-return methods share one managed RVA. An independent audit compares the raw body of every MethodDef, confirms exactly the six selected logical methods change, and verifies all other 2,311 MethodDefs plus metadata/RVAs remain intact. Shared slots have no unselected aliases.

## Original machine-code specifications

AttackRange.TestInCircles_Rect, AttackRange.TestInRects_Position, Device.CanPlaceOnWater and Zombie.CanAttack_Device all map through the original PC CodeGenModule to `0x1802FFCB0`: `xor al,al; ret`. Plant.CanBear maps to `0x18034E180`: `mov al,1; ret`. These are complete original constant functions: zero argument/object reads, calls or branches. Their damaged CIL consisted only of decompiler warnings. Restored CIL loads the proven boolean and returns, retaining signatures/virtual dispatch metadata. No guessed default behavior is introduced.

SimpleScript.Update is reconstructed from its complete 30-instruction original normal CFG and actual original 141-instruction fmod helper. The body evaluates the original `The <#0050FF>count is: </color>{0:2}` format with frame modulo 1000, calls the existing public TMP SetText, then caches frame after SetText and before deltaTime, adds delta to cached frame and writes back. CIL rem replaces an unavailable/private System.MathF.FMod reference. Existing field/method/string tokens and local signature are reused; CodeSize is shortened and MaxStack becomes four. No metadata row or field visibility changes. The damaged global-address placeholder prefix is removed with the whole target body reconstruction.

## Executed qualification and counterevidence

The exact original PC constant code runs in 80 argument/receiver cases. Actual CIL instructions are emitted and executed in matching concrete CLR methods. SimpleScript runs 912 controlled text/time cases against the original PC caller and original fmod helper, including signed zero, subnormals, finite extremes, quiet NaN, delta infinity and callback changes to frame/text. All 992 new case records match. Original caller/helper bytes are rechecked after hook setup; literal identity is decoded from original metadata. Native CRT-domain/errno behavior, native exception unwind, NaN payload identity and actual TMP formatting remain outside scope. The managed null-text control actually throws NullReferenceException without updating frame; the native guard is read statically and not executed as an exception oracle.

Four physical fault variants are rejected by execution: all five booleans inverted (80 differing cases), remainder replaced by addition (864), frame read moved after delta callback (153), and omitted frame write (630). Two harness construction mistakes are preserved. The first selected the text token while locating a frame mutation span, without changing the candidate. The second repeatedly toggled one shared false-body slot through four aliases, canceling that mutation: its aggregate PASS detected only the independent true body. The negative builder is corrected to edit each physical slot once and assert that every logical target is inverted; the corrected control detects all 80 boolean cases. No frozen verifier is changed.

The prior six caller scopes are rerun on exact R9 and preserve all 2,475 matching records. Thus 12 methods have 3,467 controlled caller case records across the separate suites. Their narrow contracts and unsupported native unwind/game scopes remain explicit. The prior Int64 fault is still invisible to permissive CLR truncation and is rejected by the unchanged frozen width checker instead.

## Full prechecks and remaining work

A fresh direct JIT check on every one of the 2,297 bodies reports 2,246 prepared, one rejected (Plant.PC_Nutknight), and 50 unsupported open generic methods. This is no-method-execution validation, not whole-game acceptance. There are zero unterminated lexical tails. The unchanged frozen checker still has 160 raw FAIL_OR_UNSUPPORTED cases, or 132 after exact InterfaceImpl facts; 216 access sites across 111 methods are rejected. These queues overlap and are not a total bug count. The changed/prior union is 186 methods: 174 PASS, 12 retained type failures. All new six targets and the prior 45 pass their type scopes.

PC_Nutknight requires native-backed integer dataflow reconstruction. Native converts Floor with CVTTSD2SI before integer clamping; replacing an integer zero with float zero would miss the original NaN/overflow conversion behavior. This method is held. Parent R8 has an independently accepted real Editor/MainMenu/shader diagnostic at run 40115001552; that does not qualify R9 or an IPA. R9 Unity/IL2CPP/Apple compilation, Board gameplay, audio, iPad execution and a new unsigned IPA remain pending.

Archives include candidate bytes, per-member manifests, constructor, independent CIL specification and all-MethodDef raw audit, original CFGs, live CLR/native fixture binaries/sources, full JIT/type/access records, all failed controls and exact reconstructable fault deltas. Native oracles require Windows x64 with the existing hash-locked PC inputs. The existing authentic runtime support folder remains required. Read CURRENT-RESULT and every per-suite scope before promoting anything.
'''.encode())
manifest(D);print(json.dumps(dict(checkpoint=str(D),candidate_sha256=digest,scoped_cases=3467,archives={p.name:p.stat().st_size for p in D.glob('*.zip')})))
