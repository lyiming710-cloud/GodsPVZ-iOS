"""Original-PC-backed constant bodies and SimpleScript.Update, six targets."""
from pathlib import Path
import hashlib,json,struct,sys
W=Path(__file__).resolve().parent.parent;ROOT=W.parents[1];Q=W/'startup-r9';Q.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'));import dnfile,pefile
sha=lambda b:hashlib.sha256(b).hexdigest();parent=(W/'startup-r8/candidate1.dll').read_bytes();assert sha(parent)=='6189387c6af11108eba9a9855bfd6d6af567ec000a4999d1ed1b0328ba0e1d08'
original=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/GameAssembly.dll').read_bytes();assert sha(original)=='9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d'
native=pefile.PE(data=original,fast_load=True);pe=dnfile.dnPE(data=parent);out=bytearray(parent);changes=[];evidence=[]
def loc(rid):
    at=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[rid-1].Rva);tiny=parent[at]&3==2;head=1 if tiny else (struct.unpack_from('<H',parent,at)[0]>>12)*4;size=parent[at]>>2 if tiny else struct.unpack_from('<I',parent,at+4)[0];return at,head,size,tiny
def write(token,code,max_stack=None):
    at,head,old_size,tiny=loc(token&0xffffff);assert len(code)<=old_size
    old=parent[at+head:at+head+old_size];out[at+head:at+head+len(code)]=code
    if tiny:assert len(code)<64;out[at]=(len(code)<<2)|2
    else:
        struct.pack_into('<I',out,at+4,len(code))
        if max_stack is not None:struct.pack_into('<H',out,at+2,max_stack)
    changes.append(dict(token=f'0x{token:08X}',file_offset=at,header_bytes=head,old_code_size=old_size,new_code_size=len(code),old_code=old.hex(),new_code=code.hex(),
        max_stack_before=8 if tiny else struct.unpack_from('<H',parent,at+2)[0],max_stack_after=8 if tiny else struct.unpack_from('<H',out,at+2)[0],unused_old_bytes_preserved=True))
for rid,value in [(0xD5,False),(0xD6,False),(0x312,False),(0x35A,True),(0x489,False)]:
    va=int.from_bytes(native.get_data(0x181B82D60-native.OPTIONAL_HEADER.ImageBase+(rid-1)*8,8),'little')
    expected=bytes.fromhex('b001c3' if value else '32c0c3');assert native.get_data(va-native.OPTIONAL_HEADER.ImageBase,3)==expected
    cfg=json.loads((W/f'next-runtime-native/{rid:04X}.normal-cfg.json').read_bytes());assert cfg['entry']==hex(va) and len(cfg['instructions'])==2 and not cfg['edges'] and not cfg['indirect_jumps'] and not cfg['tail_targets']
    evidence.append(dict(token=f'0x{0x06000000|rid:08X}',native_va=hex(va),native_bytes=expected.hex(),value=value,argument_or_object_reads=0,branches=0,calls=0))
    write(0x06000000|rid,bytes([0x17 if value else 0x16,0x2a]))
# All six referenced operands already exist in this exact method/metadata.
at,head,size,tiny=loc(0x76d);assert not tiny and size==129;old=parent[at+head:at+head+size]
def operand(offset,opcode):assert old[offset]==opcode;return old[offset+1:offset+5]
frame=operand(48,0x7b);text=operand(68,0x7b);fmt=operand(73,0x72);set_text=operand(82,0x28);delta=operand(92,0x28)
# Evaluate receiver/format/remainder; then cache frame AFTER SetText and BEFORE
# deltaTime, matching original native reads at 0x1803B5379 / 0x1803B5380.
code=b'\x02\x7b'+text+b'\x72'+fmt+b'\x02\x7b'+frame+b'\x22'+struct.pack('<f',1000.0)+b'\x5d\x6f'+set_text
code+=b'\x02\x7b'+frame+b'\x0b\x28'+delta+b'\x07\x58\x0c\x02\x08\x7d'+frame+b'\x2a'
write(0x0600076d,code,4)
data=bytes(out);allowed=set()
for c in changes:
    at=c['file_offset'];head=c['header_bytes'];allowed.update(range(at+head,at+head+c['new_code_size']))
    if head==1:allowed.add(at)
    else:
        allowed.update(range(at+4,at+8))
        if c['max_stack_before']!=c['max_stack_after']:allowed.update(range(at+2,at+4))
assert len(data)==len(parent) and all(a==b or i in allowed for i,(a,b) in enumerate(zip(parent,data)))
for n in [1,2]:(Q/f'candidate{n}.dll').write_bytes(data)
report=dict(scope='FIVE_EXACT_ORIGINAL_CONSTANT_BODIES_AND_ONE_30_INSTRUCTION_PC_CALLER_RECOVERY',parent_sha256=sha(parent),candidate_sha256=sha(data),bytes=len(data),method_targets=6,untouched_methoddefs=2311,
    metadata_rvas_local_signatures_eh_unchanged=True,constant_native_evidence=evidence,changes=changes,original_pc_sha256=sha(original),runtime_qualified=False,unity_export=False,ipa=None)
(Q/'CONSTRUCTION.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in report.items() if k not in ['changes']},indent=2))
