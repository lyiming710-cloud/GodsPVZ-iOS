using System.Security.Cryptography;using System.Text.Json;using Mono.Cecil;using Mono.Cecil.Cil;
// Declarative semantic shape check independent of byte-construction offsets.
public static class Program
{
    public static void Main(string[] args)
    {
        byte[] raw=File.ReadAllBytes(args[0]);string digest=Convert.ToHexString(SHA256.HashData(raw)).ToLowerInvariant();if(digest!="738ebc37ebdea606011294728ffeaa6a2128d19417905856729efe5947f5577e")throw new InvalidOperationException("Wrong candidate");
        using var module=ModuleDefinition.ReadModule(new MemoryStream(raw));var rows=new List<object>();
        foreach(var pair in new[]{(0x060000D5,false),(0x060000D6,false),(0x06000312,false),(0x0600035A,true),(0x06000489,false)})
        {
            var m=(MethodDefinition)module.LookupToken(pair.Item1);var ins=m.Body.Instructions;
            if(m.ReturnType.FullName!="System.Boolean"||m.Body.ExceptionHandlers.Count!=0||ins.Count!=2||ins[0].OpCode.Code!=(pair.Item2?Code.Ldc_I4_1:Code.Ldc_I4_0)||ins[1].OpCode.Code!=Code.Ret)throw new InvalidOperationException("Wrong original constant body");
            rows.Add(new{token="0x"+pair.Item1.ToString("X8"),name=m.FullName,rva=m.RVA,code_size=m.Body.CodeSize,constant=pair.Item2,instructions=2,argument_reads=0});
        }
        var simple=(MethodDefinition)module.LookupToken(0x0600076D);var s=simple.Body.Instructions;
        Code[] expected=[Code.Ldarg_0,Code.Ldfld,Code.Ldstr,Code.Ldarg_0,Code.Ldfld,Code.Ldc_R4,Code.Rem,Code.Callvirt,Code.Ldarg_0,Code.Ldfld,Code.Stloc_1,Code.Call,Code.Ldloc_1,Code.Add,Code.Stloc_2,Code.Ldarg_0,Code.Ldloc_2,Code.Stfld,Code.Ret];
        if(!s.Select(i=>i.OpCode.Code).SequenceEqual(expected)||simple.Body.ExceptionHandlers.Count!=0||simple.Body.MaxStackSize!=4)throw new InvalidOperationException("Wrong caller opcode/stack shape");
        if(((FieldReference)s[1].Operand).FullName!="TMPro.TextMeshPro TMPro.Examples.SimpleScript::m_textMeshPro")throw new InvalidOperationException("Wrong text receiver");
        foreach(int i in new[]{4,9,17})if(((FieldReference)s[i].Operand).FullName!="System.Single TMPro.Examples.SimpleScript::m_frame")throw new InvalidOperationException("Wrong frame field");
        if((string)s[2].Operand!="The <#0050FF>count is: </color>{0:2}"||(float)s[5].Operand!=1000f)throw new InvalidOperationException("Wrong literal/remainder divisor");
        if(((MethodReference)s[7].Operand).FullName!="System.Void TMPro.TMP_Text::SetText(System.String,System.Single)"||((MethodReference)s[11].Operand).FullName!="System.Single UnityEngine.Time::get_deltaTime()")throw new InvalidOperationException("Wrong external contracts");
        if(simple.Body.Variables[1].VariableType.FullName!="System.Single"||simple.Body.Variables[2].VariableType.FullName!="System.Single")throw new InvalidOperationException("Wrong cached float locals");
        rows.Add(new{token="0x0600076D",name=simple.FullName,rva=simple.RVA,code_size=simple.Body.CodeSize,instructions=s.Count,frame_cached_after_text_before_time=true,delta_then_cached_frame_add=true});
        File.WriteAllText(args[1],JsonSerializer.Serialize(new{scope="INDEPENDENT_CIL_SHAPE_FOR_ORIGINAL_NATIVE_SPEC_NOT_WHOLE_GAME_ACCEPTANCE",candidate_sha256=digest,methods=6,pass=true,rows},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine("INDEPENDENT_CIL_SPEC_PASS methods=6");
    }
}
