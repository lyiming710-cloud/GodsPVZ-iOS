from pathlib import Path
import hashlib,importlib.util,json,struct,subprocess,sys,collections
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'));import dnfile
sha=lambda b:hashlib.sha256(b).hexdigest();parent=(W/'startup-r8/candidate1.dll').read_bytes();data=(Q/'candidate1.dll').read_bytes();assert sha(parent)=='6189387c6af11108eba9a9855bfd6d6af567ec000a4999d1ed1b0328ba0e1d08' and sha(data)=='738ebc37ebdea606011294728ffeaa6a2128d19417905856729efe5947f5577e'
spec=importlib.util.spec_from_file_location('raw_reader',ROOT/'audit/native111-publication-2026-10-20/repository/scripts/actions/static_gates.py');raw=importlib.util.module_from_spec(spec);spec.loader.exec_module(raw)
pp=dnfile.dnPE(data=parent);cp=dnfile.dnPE(data=data);targets={0xD5,0xD6,0x312,0x35A,0x489,0x76D};changed=[];groups={};allowed=set()
def body(b,p,row):
    if not row.Rva:return b''
    at=p.get_offset_from_rva(row.Rva);span=raw.parse_raw_method_body_span(b,at)[0];return b[at:at+span]
proof=json.loads((Q/'INDEPENDENT-CIL-SPEC.json').read_bytes());assert proof['pass'] and proof['methods']==6 and proof['candidate_sha256']==sha(data)
for rid,(a,b) in enumerate(zip(pp.net.mdtables.MethodDef.rows,cp.net.mdtables.MethodDef.rows),1):
    assert a.Rva==b.Rva
    if body(parent,pp,a)!=body(data,cp,b):changed.append(rid)
    if a.Rva:groups.setdefault(a.Rva,[]).append(rid)
assert set(changed)==targets,{'actual_changed':changed,'expected':sorted(targets)}
for r in proof['rows']:
    rid=int(r['token'],16)&0xffffff;at=cp.get_offset_from_rva(r['rva']);tiny=data[at]&3==2;head=1 if tiny else (struct.unpack_from('<H',data,at)[0]>>12)*4
    allowed.update(range(at+head,at+head+r['code_size']))
    if tiny:allowed.add(at)
    else:
        allowed.update(range(at+4,at+8))
        if rid==0x76d:allowed.update(range(at+2,at+4))
assert len(parent)==len(data) and all(a==b or i in allowed for i,(a,b) in enumerate(zip(parent,data)))
def boundary(b):
    if len(b)!=len(data) or any(x!=y and i not in allowed for i,(x,y) in enumerate(zip(parent,b))):raise ValueError('Outside exact target code/header spans')
controls=[]
for name,at in [('unrelated-GameStart',pp.get_offset_from_rva(pp.net.mdtables.MethodDef.rows[0x526-1].Rva)+12),('metadata',pp.get_offset_from_rva(pp.net.struct.MetaDataRva))]:
    b=bytearray(data);b[at]^=1
    try:boundary(bytes(b))
    except ValueError:controls.append(dict(name=name,rejected=True));continue
    raise AssertionError('Non-target false accept')
aliases={hex(rva):[f'0x{0x6000000|rid:08X}' for rid in rids] for rva,rids in groups.items() if set(rids)&targets}
(Q/'ISOLATION.json').write_bytes((json.dumps(dict(scope='INDEPENDENT_EVERY_METHODDEF_RAW_BODY_AND_WHOLE_FILE_BOUNDARY',candidate_sha256=sha(data),pass_=True,method_targets=6,untouched_methoddefs=2311,
    actual_changed_tokens=[f'0x{0x6000000|rid:08X}' for rid in changed],physical_body_alias_groups=aliases,metadata_rvas_unchanged=True,negative_controls=controls),indent=2)+'\n').encode())
DOT=ROOT/'.local/dotnet10/dotnet.exe';SUPPORT=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support';EXPORT=ROOT/'audit/bulk250-r1-evidence-39702928368/bulk250-r1-run/tools_bin/CilExporter/bin/CilExporter.dll';CHECKER=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py'
assert sha(CHECKER.read_bytes())=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14'
spec=importlib.util.spec_from_file_location('unchanged_frozen',CHECKER);checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
tokens=sorted({m['token'] for m in json.loads((W/'startup-r8/METHODS.json').read_bytes())['methods']}|{f'0x{0x6000000|rid:08X}' for rid in targets})
(Q/'METHODS.json').write_bytes((json.dumps(dict(methods=[dict(token=t) for t in tokens]),indent=2)+'\n').encode())
def run(name,args):
    p=subprocess.run([str(x) for x in args],capture_output=True);(Q/(name+'.stdout.log')).write_bytes(p.stdout);(Q/(name+'.stderr.log')).write_bytes(p.stderr);assert p.returncode==0,(name,p.returncode,p.stderr[:600])
run('union-cil-export',[DOT,EXPORT,Q/'candidate1.dll',Q/'UNION-CIL.json',SUPPORT,','.join(tokens)])
cil=json.loads((Q/'UNION-CIL.json').read_text('utf-8-sig'));rows=[]
for m in cil['methods']:
    try:r=checker.verify(m,cil['types'])
    except Exception as e:r=dict(token=m['token'],status='FAIL_OR_UNSUPPORTED',error=str(e))
    rows.append(r)
assert all(r['status']=='PASS' for r in rows if int(r['token'],16)&0xffffff in targets)
prior45={m['token'] for m in json.loads((W/'startup-r6/FORTY-FIVE-CIL.json').read_bytes())['methods']};assert all(r['status']=='PASS' for r in rows if r['token'] in prior45)
report=dict(scope='UNCHANGED_FROZEN_UNION_TYPE_CHECK_NOT_RUNTIME_PROOF',candidate_sha256=sha(data),methods=len(tokens),counts=dict(collections.Counter(r['status'] for r in rows)),new_six_passed=True,results=rows)
(Q/'FROZEN-UNION.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
O=Q/'buff-runtime-results';O.mkdir(exist_ok=True);bad=bytearray(data);at=cp.get_offset_from_rva(cp.net.mdtables.MethodDef.rows[0x5e7-1].Rva);head=(struct.unpack_from('<H',data,at)[0]>>12)*4
for offset in [279,819]:assert data[at+head+offset]==0x20;bad[at+head+offset:at+head+offset+9]=b'\x21'+struct.pack('<q',4294967295)
mutant=O/'int64-sentinel-restored.dll';mutant.write_bytes(bad);run('int64-export',[DOT,EXPORT,mutant,Q/'INT64-CONTROL-CIL.json',SUPPORT,'0x060005E7']);bad_cil=json.loads((Q/'INT64-CONTROL-CIL.json').read_text('utf-8-sig'))
try:failure=checker.verify(bad_cil['methods'][0],bad_cil['types'])
except Exception as e:failure=dict(token='0x060005E7',status='FAIL',error=str(e))
assert failure['status']!='PASS'
(Q/'INT64-NEGATIVE-WIDTH.json').write_bytes((json.dumps(dict(scope='UNCHANGED_FROZEN_WIDTH_GATE_ON_PHYSICAL_INT64_MUTANT',baseline_passed=True,mutant_sha256=sha(bad),checker_sha256=sha(CHECKER.read_bytes()),runtime_did_not_distinguish=True,rejected=True,result=failure),indent=2)+'\n').encode())
print(json.dumps(dict(actual_changed_methods=len(changed),body_alias_groups=aliases,union_methods=len(tokens),frozen_counts=report['counts'],new_six_passed=True,prior45_passed=True,int64_control_rejected=True),indent=2))
