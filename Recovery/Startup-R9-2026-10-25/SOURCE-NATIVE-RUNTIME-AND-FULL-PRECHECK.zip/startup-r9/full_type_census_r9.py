# Input-bound R6 invocation derived from run_full_type_census.py sha256=690574ab08300ac20c1f47fbfd822e6f23877233806331a45c74e8968b06451b; frozen verifier unchanged.
from pathlib import Path
import hashlib,importlib.util,json,subprocess,collections
W=Path(__file__).resolve().parent.parent;ROOT=W.parents[1];Q=W/'startup-r9'
candidate=Q/'candidate1.dll';digest=hashlib.sha256(candidate.read_bytes()).hexdigest()
assert digest=='738ebc37ebdea606011294728ffeaa6a2128d19417905856729efe5947f5577e'
tokens=[r['token'] for r in json.loads((Q/'ALL-METHODS.json').read_bytes())['methods']]
assert len(tokens)==2297
dot=ROOT/'.local/dotnet10/dotnet.exe';export=ROOT/'audit/bulk250-r1-evidence-39702928368/bulk250-r1-run/tools_bin/CilExporter/bin/CilExporter.dll'
support=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'
proc=subprocess.run([str(dot),str(export),str(candidate),str(Q/'ALL-CIL.json'),str(support),','.join(tokens)],capture_output=True)
(Q/'all-cil-export.log').write_bytes(proc.stdout+proc.stderr);assert proc.returncode==0
f=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py'
assert hashlib.sha256(f.read_bytes()).hexdigest()=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14'
spec=importlib.util.spec_from_file_location('unchanged_frozen',f);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
cil=json.loads((Q/'ALL-CIL.json').read_text('utf-8-sig'));results=[]
for method in cil['methods']:
    try:result=v.verify(method,cil['types'])
    except Exception as error:result=dict(token=method['token'],method=method['name'],status='FAIL_OR_UNSUPPORTED',error=str(error))
    results.append(result)
counts=collections.Counter(r['status'] for r in results)
report=dict(scope='WHOLE_ASSEMBLY_UNCHANGED_FROZEN_STACK_CENSUS_ONLY_NOT_SEMANTIC_ACCEPTANCE',candidate_sha256=digest,checker_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),
            cil_export_sha256=hashlib.sha256((Q/'ALL-CIL.json').read_bytes()).hexdigest(),total=len(results),counts=dict(counts),all_pass=len(results)==counts['PASS'],results=results)
(Q/'FROZEN-STACK-ALL-2297.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2))
