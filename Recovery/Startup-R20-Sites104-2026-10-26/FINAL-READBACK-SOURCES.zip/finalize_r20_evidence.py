"""Close the finite R20 evidence batch without promoting Unity/IPA/device gates."""
from pathlib import Path
from collections import Counter
import csv,io,json,re,subprocess
from archive_support import sha,js,pack,manifest
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';D=R/'Recovery/Startup-R20-Sites104-2026-10-26';Q=W/'startup-r20-sites100'
run=40221471927;head='a66b11bdbb364d21f910c5a21209dcef97922afd'
A=W/'r20-apple-control-run-40221471927/Startup-R20-Apple-Damage-Control-40221471927-1'
meta=json.loads(subprocess.check_output([r'C:\Program Files\GitHub CLI\gh.exe','run','view',str(run),'--repo','lyiming710-cloud/GodsPVZ-iOS','--json','headSha,status,conclusion,url,jobs']))
assert meta['headSha']==head and meta['status']=='completed' and meta['conclusion']=='success'
assert {j['name']:j['conclusion'] for j in meta['jobs']}=={'damage_control_replay':'success','compiler':'skipped'}
js(A/'RUN.json',meta);v=json.loads((A/'RESULT.json').read_bytes());row=v['control']
assert v['source_commit']==head and v['header_export_run']==39988665189
assert v['expectation_met'] and v['raw_control_log_preserved'] and not v['game_dll_changed'] and not v['full_source_compilation']
assert not v['unity_export'] and not v['linked'] and v['ipa'] is None
assert row['exit_code']!=0 and row['error_count']==34 and row['warning_count']==28 and not row['unparsed_errors']
source=(A/'DAMAGED-SOURCE.cpp').read_bytes();assert len(source)==row['bytes']==1406979 and sha(source)==row['sha256']=='11427c29119a74621ebe7f94a0e043de4bfe7a0cd00f7ac0b2c2de5928ba0017'
log=(A/ v['raw_log']['file']).read_bytes();text=log.decode('utf-8')
assert len(log)==v['raw_log']['bytes'] and sha(log)==v['raw_log']['sha256']
assert sum(bool(re.search(r': (?:fatal )?error:',line)) for line in text.splitlines())==34
assert sum(': warning:' in line for line in text.splitlines())==28
assert '/Source/il2cppOutput/Generics__63.cpp' in text and '/fresh-generated/' not in text
flags=json.loads((A/'FLAGS.json').read_bytes());prior=W/'r20-apple-run-40220652002/Startup-R20-Sites104-Apple-40220652002-1'
captured=json.loads((prior/'APPLE-CPP-FLAGS.json').read_bytes())
prefix='/Users/runner/work/_temp/'
assert [x.replace(prefix+'fresh-generated/il2cppOutput/cpp',prefix+'frozen-export/xcode/Il2CppOutputProject/Source/il2cppOutput') for x in captured]==flags
pack(D/f'ACTUAL-APPLE-CONTROL-EVIDENCE-{run}.zip',[(p.relative_to(A).as_posix(),p.read_bytes()) for p in sorted(A.rglob('*')) if p.is_file()]+[(Path(__file__).name,Path(__file__).read_bytes())])
js(D/f'ACTUAL-APPLE-CONTROL-{run}.json',dict(scope='INDEPENDENT_RAW_CONTROL_REPLAY_READBACK',run_id=run,url=meta['url'],
    source_commit=head,expectation_met=True,control_source_sha256=sha(source),raw_log_sha256=sha(log),raw_errors=34,raw_warnings=28,
    flags_identical_to_prior_damaged_control=True,full_source_job_skipped=True,game_candidate_changed=False,new_unity_export=False,linked=False,ipa=None))
status=json.loads((D/'PROGRESS.json').read_bytes());status.update(
    status='R20_FINITE_RUNTIME_AND_EXACT_LINUX_APPLE_CHECKS_COMPLETE_PRODUCT_PENDING',
    apple_damage_control_raw_log=f'PASS_INDEPENDENT_REPLAY_34_ERRORS_RUN_{run}',
    apple_damage_control_log_collision_fixed=True,apple_damage_control_replay_run=run,
    r19_runtime_profiles_still_pending=35,whole_game_accepted=False)
js(D/'PROGRESS.json',status);js(Q/'PROGRESS.json',status)
construction=json.loads((D/'CONSTRUCTION.json').read_bytes());positions=Counter(s['method'] for s in construction['repair_sites'])
manager=json.loads((D/'NATIVE-MANAGERS.json').read_bytes());counts=manager['per_method']|{'0x060006A7':216}
controls=json.loads((D/'RUNTIME-CONTROLS.json').read_bytes());faults={r['token']:r['behavioral_differences'] for r in controls['results']}
coverage=json.loads((D/'GENERATED-COVERAGE-40219580971.json').read_bytes());definitions={r['token']:r['cpp_file'] for r in coverage['targets']}
matrix=[dict(token=r['token'],name=r['name'],authored_positions=positions[r['token']],
    native_normal_records=counts[r['token']],native_cil_differences=0,
    historical_empty_body_control_differences=faults[r['token']],frozen_type='PASS',member_rejections=0,
    jit_prepared=True,generated_definition=definitions[r['token']],linux_syntax='PASS',apple_syntax='PASS',
    unity_lifecycle_and_product_acceptance='NOT_PROVEN') for r in construction['changes']]
assert len(matrix)==8 and sum(r['authored_positions'] for r in matrix)==104 and sum(r['native_normal_records'] for r in matrix)==768
js(D/'PER-METHOD-STATUS.json',dict(candidate_sha256=status['candidate_sha256'],rows=matrix))
buf=io.StringIO(newline='');writer=csv.DictWriter(buf,fieldnames=list(matrix[0]));writer.writeheader();writer.writerows(matrix)
(D/'PER-METHOD-STATUS.csv').write_bytes(buf.getvalue().encode())
source_queue=R/'Recovery/Whole-Program-Census-2026-10-26/UNIFIED-WORK-QUEUE.json';old=json.loads(source_queue.read_bytes());work=[]
for item in old['rows']:
    r=dict(item);r['parent_census_priority']=r.pop('priority')
    if r['token'] in counts:
        assert r['parent_census_priority']=='P0_SOURCE_GAP' and r['known_body_gap']
        r.update(parent_census_had_empty_body_gap=True,current_cil_empty_body_gap=False,
            current_state='BODY_RESTORED_FINITE_CHECKS_PASS_ENGINE_PRODUCT_PENDING',
            repair_positions=positions[r['token']],normal_native_records=counts[r['token']],
            current_required_action='Complete actual Unity lifecycle/resource integration and product acceptance; finite tests do not close those gates')
    else:r.update(current_state='PARENT_REVIEW_OR_RUNTIME_PROFILE_PENDING_NO_R20_BODY_CHANGE')
    work.append(r)
assert len(work)==156 and sum(r['token'] in counts for r in work)==8
js(D/'CURRENT-WORK-QUEUE.json',dict(scope='UPDATED_STATES_FOR_PARENT_156_METHOD_AUDIT_QUEUE_NOT_A_REMAINING_BUG_COUNT',
    candidate_sha256=status['candidate_sha256'],parent_queue_sha256=sha(source_queue.read_bytes()),tracked_methods=156,
    eight_source_bodies_restored_with_finite_tests=8,other_parent_followup_work_items=148,
    original_priority_counts=old['priority_counts'],formal_product_acceptance=False,rows=work))
js(D/'EVIDENCE-BATCH-COMPLETE.json',dict(scope='FINITE_EVIDENCE_BATCH_COMPLETE_NOT_GAME_QUALIFICATION',
    candidate_sha256=status['candidate_sha256'],repair_positions=104,changed_methods=8,
    source_authored_before_shared_testing=True,normal_native_comparison_records=768,behavioral_omission_controls_detected=8,
    linux_run=40219580971,apple_run=40220652002,apple_raw_control_replay=run,
    compiler_units_each=1029,unity_editor_export=False,player_link=False,ipa=None,ipad_acceptance=False,
    next_work='R19 remaining 35 whole-caller profiles and whole-game integration; future source changes accumulate over 100 native-backed positions before shared testing'))
p=D/'README.md';text=p.read_text('utf-8')
text=text.replace('当前候选 Apple 检查已使用精确 Linux 生成包准备；编译参数、1,029 源文件检查、六个控制和损坏 R4 34-error 控制沿用原算法。实际结果见后续 ACTUAL-APPLE 文件，未执行前不记通过。',
    '当前候选 Apple run 40220652002 的 1,029 个单元及其全部源码身份/原始日志均通过回读；六个编译控制符合预期。损坏 R4 的原始日志覆盖问题另由 run 40221471927 单独补跑，真实 34-error 日志已完整保存，未重跑正常源码，也未修改候选。')
text+='''
## 本批有限证据收尾

[控制补跑 40221471927](https://github.com/lyiming710-cloud/GodsPVZ-iOS/actions/runs/40221471927) 只运行一个历史损坏编译单元，正常源码 job 明确 skipped。独立回读物理源文件（SHA 11427c29…）、原始日志（SHA ea1198d1…）和完整 flags：34 条错误、28 条警告与非零进程结果全部一致；参数与先前损坏控制完全相同。目录隔离解决日志覆盖，初始缺项仍原样保留在历史证据中。

PER-METHOD-STATUS.json/CSV 提供八方法逐项位置数、运行对照、故障差异、类型/访问/JIT 和 Linux/Apple 状态。CURRENT-WORK-QUEUE.json 只更新历史 156 个方法工作项中本批八个的当前状态；其余 148 个是不同类别的后续审查/验证工作，不是 148 个已确认 bug。原 R19 的 35 个完整运行 profile、四个其他语义标记、92 个工具覆盖审查及17 个 Reset 上下文保持各自状态。下一批新源码仍先累计超过 100 个有原版依据的位置再集中检测。

本批有限运行/编译证据已收尾；新的持证 Editor 场景/资源验收、链接、IPA 和真机门仍未完成。
''';p.write_bytes(text.encode())
p=R/'README.md';text=p.read_text('utf-8').replace('a damaged-control raw-log collision is recorded and being replayed separately.','a damaged-control raw-log collision is preserved and resolved by a separately verified 34-error replay.');p.write_bytes(text.encode())
p=R/'Recovery/STATUS.md';text=p.read_text('utf-8');marker='## Latest checkpoint - 2026-10-26\n';assert marker in text
text=text.replace(marker,marker+'\nR20 finite batch evidence is complete: 104 positions/eight methods, 768 native normal comparisons, eight detected omission controls, exact Linux and Apple 1,029-unit syntax passes. The control-only replay 40221471927 preserves and independently verifies all 34 damaged-source errors/28 warnings with unchanged Apple flags; normal compiler job skipped. No new game bytes, Editor export, link, IPA or device result. Per-method matrix and current audit-work states are archived.\n',1);p.write_bytes(text.encode())
pack(D/'FINAL-READBACK-SOURCES.zip',[(p.name,p.read_bytes()) for p in [W/'record_r20_apple.py',W/'verify_r20_generated_coverage.py',Path(__file__)]]);manifest(D)
print(json.dumps(dict(batch_positions=104,methods=8,normal_native_records=768,linux_source_logs=1029,apple_source_logs=1029,
    control_replay_raw_errors=34,control_replay_raw_warnings=28,ipa=None)))
