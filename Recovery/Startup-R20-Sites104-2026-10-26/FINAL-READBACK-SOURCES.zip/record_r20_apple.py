"""Independently check exact Apple source/log evidence, preserving log collision."""
from pathlib import Path,PurePosixPath
import json,re,subprocess
from archive_support import sha,js,pack,manifest
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';D=R/'Recovery/Startup-R20-Sites104-2026-10-26'
run=40220652002;head='7ea18ecf0e5e2217fdaba4931fcbf2d018bb3087';expected='d887b370c95c2966dc40d80648d85c286bb42d85004c32d095f64f004e095b37'
A=W/'r20-apple-run-40220652002/Startup-R20-Sites104-Apple-40220652002-1'
meta=json.loads(subprocess.check_output([r'C:\Program Files\GitHub CLI\gh.exe','run','view',str(run),'--repo','lyiming710-cloud/GodsPVZ-iOS','--json','headSha,status,conclusion,url,jobs']))
assert meta['headSha']==head and meta['status']=='completed' and meta['conclusion']=='success';js(A/'RUN.json',meta)
actual=json.loads((A/'APPLE-REPORT.json').read_bytes());rows=json.loads((A/'ALL-APPLE-RESULTS.json').read_bytes())
base=json.loads((D/'ACTUAL-COMPILER-40219580971.json').read_bytes())
assert actual['candidate_sha256']==expected==base['candidate_sha256'] and actual['source_conversion_run']==base['run_id']==40219580971
assert actual['apple_audit_source_commit']==head and actual['header_export_run']==39988665189
assert actual['attempted']==len(rows)==1029 and actual['cpp']==755 and actual['c']==274
assert actual['failed']==actual['diagnostics']==actual['unparsed_error_lines']==0
assert not actual['actual_unity_export_for_new_candidate'] and not actual['linked'] and actual['ipa'] is None
files={PurePosixPath(r['file']).name:r for r in base['source_rows']}
assert len(files)==len(rows)==len({r['file'] for r in rows}) and set(files)=={r['file'] for r in rows}
identities=[]
for r in rows:
    prior=files[r['file']];assert r['bytes']==prior['bytes'] and r['sha256']==prior['sha256']
    assert r['exit_code']==r['error_count']==0 and not r['unparsed_errors']
    log=A/'logs'/(r['file']+'.log');data=log.read_bytes();text=data.decode('utf-8',errors='replace')
    assert not re.search(r': (?:fatal )?error:',text)
    assert sum(': warning:' in x for x in text.splitlines())==r['warning_count']
    identities.append(dict(file=log.relative_to(A).as_posix(),bytes=len(data),sha256=sha(data)))
cpp=json.loads((A/'APPLE-CPP-FLAGS.json').read_bytes());c=json.loads((A/'APPLE-C-FLAGS.json').read_bytes())
for flags in [cpp,c]:
    assert '/Xcode_16.4.app/' in flags[0] and flags[flags.index('-arch')+1]=='arm64'
    assert flags[flags.index('-isysroot')+1].endswith('/iPhoneOS18.5.sdk')
    assert '-fsyntax-only' in flags and '-ferror-limit=0' in flags
assert '-std=c++11' in cpp and '-std=c11' in c and c[c.index('-x')+1]=='c'
cppcontrols=json.loads((A/'COMPILER-CONTROLS.json').read_bytes());ccontrols=json.loads((A/'C-COMPILER-CONTROLS.json').read_bytes())
assert len(cppcontrols)==4 and len(ccontrols)==2
for r in cppcontrols+ccontrols:
    assert r['expectation_met']
    data=(A/'logs'/(r['file']+'.log')).read_bytes();text=data.decode('utf-8',errors='replace')
    assert sum(bool(re.search(r': (?:fatal )?error:',line)) for line in text.splitlines())==r['error_count']
assert all((r['exit_code']==0)==r['expected_success'] for r in cppcontrols)
cc={r['file']:r for r in ccontrols};assert cc['valid_c_mode.c']['exit_code']==0 and cc['bad_c_identifier.c']['exit_code']!=0
damaged=json.loads((A/'DAMAGED-R4-CONTROL.json').read_bytes());assert damaged['exit_code']!=0 and damaged['error_count']==34
assert sum(r['severity'] in ['error','fatal error'] for r in damaged['diagnostics'])==34
collision=(A/'logs/Generics__63.cpp.log').read_bytes();text=collision.decode('utf-8',errors='replace')
assert ': error:' not in text and '/fresh-generated/il2cppOutput/cpp/Generics__63.cpp' in text
assert damaged['sha256']!=files['Generics__63.cpp']['sha256']
problem=dict(scope='APPLE_DAMAGE_CONTROL_RAW_LOG_BASENAME_COLLISION',affected_r20_run=run,
    game_candidate_unchanged=expected,damaged_json_errors=34,damaged_json_exit=damaged['exit_code'],
    damaged_source_sha256=damaged['sha256'],later_normal_source_sha256=files['Generics__63.cpp']['sha256'],
    retained_log_sha256=sha(collision),retained_log_error_count=0,
    root_cause='run_one stores logs by basename; later normal source overwrote earlier damaged-control log',
    later_all_source_result_valid=True,damaged_raw_log_preserved=False,raw_control_replay='PENDING',
    control_json_diagnostics_are_preserved=True,not_a_game_candidate_failure=True)
js(D/'APPLE-LOG-COLLISION.json',problem)
old=W/'r19-apple-run-40197688048'
pack(D/'APPLE-LOG-COLLISION-ORIGINAL-EVIDENCE.zip',[
    ('R20/original-driver.py',(R/'scripts/actions/check_startup_r20_apple.py').read_bytes()),
    ('R20/DAMAGED-R4-CONTROL.json',(A/'DAMAGED-R4-CONTROL.json').read_bytes()),
    ('R20/overwritten-log-now-normal.log',collision),
    ('R19/DAMAGED-R4-CONTROL.json',(old/'DAMAGED-R4-CONTROL.json').read_bytes()),
    ('R19/overwritten-log-now-normal.log',(old/'logs/Generics__63.cpp.log').read_bytes())])
result=dict(scope='ACTUAL_R20_ALL_FRESH_PORTABLE_SOURCES_APPLE_ARM64_SYNTAX_ONLY',run_id=run,url=meta['url'],
    pass_=True,actual=actual,source_records_rechecked=len(rows),raw_source_logs_rechecked=len(identities),
    log_identities=identities,compiler='Xcode 16.4 Apple Clang',sdk='iPhoneOS18.5',architecture='arm64',
    compiler_controls=cppcontrols+ccontrols,damaged_control_json_errors=34,
    damaged_control_raw_log_status='OVERWRITTEN_BY_LATER_NORMAL_SOURCE_REPLAY_PENDING',
    warning_count=sum(r['warning_count'] for r in rows),new_unity_export=False,linked=False,ipa=None,ipad_acceptance=False)
pack(D/f'ACTUAL-APPLE-EVIDENCE-{run}.zip',[(p.relative_to(A).as_posix(),p.read_bytes()) for p in sorted(A.rglob('*')) if p.is_file()]+[(Path(__file__).name,Path(__file__).read_bytes())])
js(D/f'ACTUAL-APPLE-{run}.json',result)
status=json.loads((D/'PROGRESS.json').read_bytes());status.update(apple=f'PASS_1029_ARM64_SYNTAX_UNITS_RUN_{run}',
    apple_source_and_log_readbacks=1029,apple_warning_count=result['warning_count'],apple_damage_control_raw_log='PENDING_REPLAY_AFTER_OVERWRITE')
js(D/'PROGRESS.json',status);js(W/'startup-r20-sites100/PROGRESS.json',status);manifest(D)
print(json.dumps(dict(run_id=run,cpp=755,c=274,all_source_logs_rechecked=1029,warnings=result['warning_count'],control_raw_log='PENDING_REPLAY',ipa=None)))
