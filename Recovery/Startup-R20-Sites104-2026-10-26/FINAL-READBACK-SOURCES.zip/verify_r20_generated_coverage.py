"""Exact generated registration/definition census; no semantic promotion."""
from pathlib import Path
import ast,hashlib,json,re,tarfile
from archive_support import sha,js,pack,manifest
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';D=R/'Recovery/Startup-R20-Sites104-2026-10-26';Q=W/'startup-r20-sites100'
# Reuse precisely the previously reviewed archive parser, without executing the
# old script's R19-specific main program or changing its source patterns.
source=W/'verify_r19_generated_coverage.py';tree=ast.parse(source.read_text('utf-8'))
fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='read')
exec(compile(ast.Module(body=[fn],type_ignores=[]),str(source),'exec'),globals())
matches=list((W/'r19-candidate9-compiler-40195582520').rglob('startup-r19-generated.tar.gz'))
assert len(matches)==1,matches
old_archive=matches[0]
assert sha(old_archive.read_bytes())=='2638628c5fbea4669e064af4db9df65e3a5022cb3420550d00ea517cf7698a47'
new_archive=W/'r20-compiler-40219580971/Startup-R20-Sites104-compiler-40219580971-1/startup-r20-generated.tar.gz'
assert sha(new_archive.read_bytes())=='15a60954eb4a1a600c807412bc557833a9a4c798dc1e14e0e16fa6efa9c9d88d'
old,od=read(old_archive);new,nd=read(new_archive)
assert old==new and set(od)==set(nd) and len(nd)==2267
construction=json.loads((Q/'authored3.json').read_bytes())
actual=json.loads((D/'ACTUAL-COMPILER-40219580971.json').read_bytes())
assert actual['candidate_sha256']==construction['candidate_sha256']
assert actual['raw_generated_sources_rehashed']==actual['raw_source_logs_rechecked']==1029
targets=[]
for r in construction['changes']:
    symbol=new[(int(r['token'],16)&0xffffff)-1]
    assert symbol!='NULL' and symbol in nd
    targets.append(dict(token=r['token'],name=r['name'],symbol=symbol,cpp_file=nd[symbol]))
assert len(targets)==8
result=dict(scope='R20_GENERATED_GAME_REGISTRATION_AND_DEFINITION_COVERAGE_ONLY',run_id=40219580971,
    candidate_sha256=construction['candidate_sha256'],registered_method_rows=len(new),
    pointer_entries_identical_to_exact_r19=True,ordinary_definition_sets_identical_to_exact_r19=True,
    ordinary_generated_game_definitions=len(nd),eight_targets_registered_and_defined=True,targets=targets,
    all_returned_source_hashes_and_logs_rechecked=1029,
    parser_parent_sha256=sha(source.read_bytes()),parser_algorithm_unchanged=True,
    generated_archive_sha256=sha(new_archive.read_bytes()),formal_or_product_acceptance=False)
js(D/'GENERATED-COVERAGE-40219580971.json',result)
pack(D/'GENERATED-COVERAGE-SOURCE.zip',[(source.name,source.read_bytes()),(Path(__file__).name,Path(__file__).read_bytes()),
    ('CURRENT-POINTERS.json',json.dumps(new,indent=2).encode()),('CURRENT-ORDINARY-DEFINITIONS.json',json.dumps(nd,indent=2).encode())])
manifest(D)
print(json.dumps({k:v for k,v in result.items() if k!='targets'}))
