"""Archive the >100-position construction before compiler/runtime promotion."""
from pathlib import Path
import ast,json
from archive_support import sha,js,pack,manifest
W=Path(__file__).resolve().parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113';Q=W/'startup-r20-sites100';P=Q/'shared-authored1';D=R/'Recovery/Startup-R20-Sites104-2026-10-26';assert not D.exists();D.mkdir()
j=json.loads((Q/'authored1.json').read_bytes());gate=json.loads((Q/'SHARED-TEST-START.json').read_bytes());digest=j['candidate_sha256'];assert j['new_unique_repair_positions']==104 and j['distinct_changed_methods']==8 and gate['repeat_identical'] and digest==sha((Q/'authored1.dll').read_bytes())
isolation=json.loads((P/'ISOLATION.json').read_bytes());assert isolation['pass_'] and isolation['unchanged_methoddefs']==2309;frozen=json.loads((P/'FROZEN-WITH-INTERFACE-FACTS.json').read_bytes());access=json.loads((P/'MEMBER-EXIT.json').read_bytes());jit=json.loads((P/'jit/RESULT.json').read_bytes());assert access['exit_code']==0 and jit['counts']=={'JIT_PREPARED_NO_EXECUTION':8}
(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text\n*.md -text\n*.zip -text\n*.yml -text\n');oldpolicy=(R/'Recovery/BATCH-POLICY.json').read_bytes();(D/'PARENT-BATCH-POLICY.json').write_bytes(oldpolicy)
policy=dict(updated_on='2026-10-26',instruction='User requested more than one hundred repair positions before testing',effective_batch='R20',baseline_checkpoint='Startup-R19-Batch100-2026-10-25',baseline_candidate_sha256=j['parent_sha256'],counting_unit='Distinct native-backed semantic operation positions; changed MethodDefs reported separately',threshold_positions=100,comparison='strictly_greater_than',authored_positions=104,changed_methoddefs=8,repair_kind_counts=j['repair_kind_counts'],position_identity=['MethodDef','original native instruction VA'],count_each_position_once=True,exclude_argument_stack_instructions_metadata_helpers_gc_barriers_whitespace_and_repeat_edits=True,do_not_count_as_independent_game_bug_total=True,source_inspection_and_construction_guards_remain_enabled=True,shared_test_started_only_after_threshold=True,unsupported_or_correct_code_must_not_be_changed_to_fill_count=True,historical_R19_policy_and_counts_preserved='PARENT-BATCH-POLICY.json')
js(R/'Recovery/BATCH-POLICY.json',policy);js(D/'BATCH-POLICY.json',policy)
pack(D/'STARTUP-R20-SITES104-CANDIDATE.zip',[('STARTUP-R20-SITES104.dll',(Q/'authored1.dll').read_bytes())]);pack(D/'SOURCE-AND-STATIC-EVIDENCE.zip',[('startup-r20-sites100/'+f.relative_to(Q).as_posix(),f.read_bytes()) for f in sorted(Q.rglob('*')) if f.is_file() and f.suffix!='.dll' and '__pycache__' not in f.parts])
for src,name in [(Q/'authored1.json','CONSTRUCTION.json'),(Q/'SHARED-TEST-START.json','SHARED-TEST-START.json'),(Q/'CHECK-DERIVATION.json','CHECK-DERIVATION.json'),(P/'ISOLATION.json','ISOLATION.json'),(P/'FROZEN-RAW.json','FROZEN-RAW.json'),(P/'FROZEN-WITH-INTERFACE-FACTS.json','FROZEN-WITH-INTERFACE-FACTS.json'),(P/'MEMBER-EXIT.json','MEMBER-EXIT.json'),(P/'jit/RESULT.json','EXACT-JIT.json')]:(D/name).write_bytes(src.read_bytes())
src=R/'scripts/actions/check_startup_r19_compiler.py';driver_before=src.read_bytes();driver=driver_before.decode().replace(j['parent_sha256'],digest).replace('STARTUP_R19','STARTUP_R20').replace('STARTUP-R19-BATCH100','STARTUP-R20-SITES104').replace('Startup R19 Batch100','Startup R20 Sites104');ast.parse(driver);dest=R/'scripts/actions/check_startup_r20_compiler.py';assert not dest.exists();dest.write_bytes(driver.encode())
wf=R/'.github/workflows/bulk401-generic-compiler-check.yml';wf_before=wf.read_bytes();(D/'PARENT-COMPILER-WORKFLOW.yml').write_bytes(wf_before);text=wf_before.decode().replace(j['parent_sha256'],digest).replace('startup-r19','startup-r20').replace('Startup R19 Batch100','Startup R20 Sites104').replace('STARTUP-R19-BATCH100','STARTUP-R20-SITES104').replace('Startup-R19-Batch100-2026-10-25','Startup-R20-Sites104-2026-10-26').replace('Startup-R19-Batch100','Startup-R20-Sites104').replace('exact R19 Batch100','exact R20 Sites104').replace('check_startup_r19_compiler.py','check_startup_r20_compiler.py');assert j['parent_sha256'] not in text and digest in text;wf.write_bytes(text.encode());(R/'.github/workflows/startup-r20-compiler-check.yml').write_bytes(text.encode())
js(D/'COMPILER-DERIVATION.json',dict(scope='INPUT_ONLY_DERIVATIVE_FOR_104_POSITION_EIGHT_METHOD_COMPILER_DIAGNOSTIC',candidate_sha256=digest,parent_driver_sha256=sha(driver_before),driver_sha256=sha(dest.read_bytes()),parent_workflow_sha256=sha(wf_before),workflow_sha256=sha(wf.read_bytes()),compiler_flags_and_six_controls_unchanged=True,repair_positions=104,changed_methods=8,semantic_promotion=False))
pack(D/'COMPILER-BINDING-SOURCES.zip',[(f.relative_to(R).as_posix(),f.read_bytes()) for f in [src,dest,wf,R/'.github/workflows/startup-r20-compiler-check.yml']]+[('prepare_r20_checkpoint.py',Path(__file__).read_bytes())])
progress=dict(status='AUTHORED_104_POSITIONS_IN_EIGHT_METHODS_SHARED_CHECKS_STARTED_AFTER_THRESHOLD',candidate_sha256=digest,parent_sha256=j['parent_sha256'],new_repair_positions=104,changed_methods=8,repair_kind_counts=j['repair_kind_counts'],count_is_not_distinct_methods_or_bug_count=True,repeat_identical=True,unchanged_methoddefs=2309,old_shared_ret_slots_preserved=True,new_memberrefs=isolation['new_memberrefs'],new_local_signatures=isolation['new_locals'],new_methodspecs=isolation['new_methodspecs'],changed_type_pass=8,whole_type_counts=frozen['counts'],member_actual_exit=access['exit_code'],jit_prepared_no_execution=8,native_runtime_profiles='PENDING',compiler='PREPARED_NOT_RUN',apple='NOT_RUN',unity='NOT_RUN',ipa=None,ipad_acceptance=False,qualified_methods=0)
js(D/'PROGRESS.json',progress);js(Q/'PROGRESS.json',progress)
doc='''# R20：先完成 104 个修复位置，再统一检测

本批基线是固定 R19 candidate9（'''+j['parent_sha256']+'''）。新候选 SHA-256：`'''+digest+'''`。

按用户 2026-10-26 的“先一共修复一百个地方以上再检测”，本批记录 **104 个原版语义操作位置，分布在 8 个 MethodDef**。这不是 104 个方法，也不是 104 个独立游戏 bug。每个位置以“MethodDef + 原版指令地址”去重，记录原版指令字节和新 CIL 区间；类型分别为 35 个调用、15 个字段写入、41 个字段读取、11 个控制流位置和两个循环状态位置。普通参数/栈指令、元数据初始化、GC barrier、空白和重复修改不计。历史 R19 的 100-method 政策保存在 PARENT-BATCH-POLICY.json。

## 实际恢复范围

- DeviceManager.Start：原版板块初始化、资源加载、字段赋值、预览初始化顺序。
- DeviceManager.Update：Unity 对象判定后的 board 重载、mouse 捕获、无符号手持物分区、道具 -1 sentinel、仅状态改变时调用显示刷新。
- ProjectManager.Start/Update：prefab 加载，以及分别读取全局存档链的金币/钻石初始化；逐帧项目和钱库更新。
- SunManager.Start/Update：银行 UI 文本绑定、初始落阳光时间；真实整数格式化、文本回调后的 board 捕获、游戏开始/暂停/结束条件及原版两个更新调用顺序。
- ZombieManager.Start：prefab 赋值和关卡数据初始化。
- SavesUIController.LoadPlayerSaves：旧 UI 项销毁和列表重载/清理、实际存档数量、逐项实例化/父级绑定/ID 与管理器赋值/Start0/Add，以及最后 ID=-1 的新建项。

这些原方法与许多正常空回调共用同一 ret 槽位。本批为八个目标追加独立方法体，保留所有旧槽位。只追加两个 MemberRef、三个局部签名和一个 Instantiate<SavesUIController_PlayerSave> MethodSpec。

## 检测顺序与当前结论

先完成 104 处构造，再重建第二份相同候选并记录 SHARED-TEST-START.json，之后才执行共享检测。八个新方法的冻结类型检查、实际成员访问、真实 DLL JIT 准备均通过；全程序集保留原有 70 条失败或不支持项。独立隔离检查确认其余 2,309 个 MethodDef、旧堆/表行/方法体/权限不变，三个出界物理负控制被拒绝。

当前尚无这八个完整调用方的原版运行对照、当前候选 IL2CPP/Apple 实测结果、新 Unity 导出、链接后 IPA 或 iPad 验收。编译工作流已绑定这个新候选，仅作诊断；不得继承 R19 的编译绿色作为 R20 通过。qualified_methods=0。原 R19 的 35 个待运行对照方法和其他全量清单问题保持开放。
''';(D/'README.md').write_bytes(doc.encode());manifest(D)
p=R/'README.md';t=p.read_text(encoding='utf-8');marker='Reverse-recovery workspace for the GodsPVZ 1.0.2 Unity IL2CPP builds supplied by the repository owner.\n';t=t.replace(marker,marker+'\nLatest [R20 Sites104](Recovery/Startup-R20-Sites104-2026-10-26/README.md) authors 104 native-backed operation positions across eight previously empty methods before shared testing. Isolation/type/access/JIT checks pass at their stated scope; runtime/compiler/Unity/IPA/device qualification remains pending. Counts are positions and methods separately.\n',1);p.write_bytes(t.encode())
p=R/'Recovery/STATUS.md';t=p.read_text(encoding='utf-8');marker=next(x+'\n' for x in t.splitlines() if x.startswith('## Latest checkpoint'));t=t.replace(marker,marker+'\n[R20 Sites104](Startup-R20-Sites104-2026-10-26/README.md): 104 native-backed operation positions in eight restored manager/save-list methods were authored before shared tests. Eight target type/access/JIT-preparation checks pass; 2,309 other MethodDefs and shared old ret slots are unchanged. Runtime/compiler/current Unity export/IPA/iPad acceptance remain pending. This supersedes the cadence counting unit for R20 only; original R19 history remains intact.\n',1);p.write_bytes(t.encode());print(json.dumps(progress))
