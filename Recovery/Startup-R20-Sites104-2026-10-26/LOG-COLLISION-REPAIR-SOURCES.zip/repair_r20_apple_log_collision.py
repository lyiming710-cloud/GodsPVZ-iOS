"""Keep the failed evidence, isolate the control log, and replay only that unit."""
from pathlib import Path
import json,subprocess
from archive_support import sha,js,pack,manifest
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';D=R/'Recovery/Startup-R20-Sites104-2026-10-26'
problem=json.loads((D/'APPLE-LOG-COLLISION.json').read_bytes());assert problem['damaged_json_errors']==34 and not problem['damaged_raw_log_preserved']
driver=R/'scripts/actions/check_startup_r20_apple.py';wf=R/'.github/workflows/bulk401-apple-compiler-check.yml';copy=R/'.github/workflows/startup-r20-apple-compiler-check.yml'
assert wf.read_bytes()==copy.read_bytes()
old=driver.read_bytes();oldwf=wf.read_bytes()
pack(D/'PRE-LOG-COLLISION-APPLE-BINDING.zip',[(driver.relative_to(R).as_posix(),old),(wf.relative_to(R).as_posix(),oldwf),(copy.relative_to(R).as_posix(),copy.read_bytes())])
before="known=run_one(oldcpp/'Generics__63.cpp',old_flags,root,out)"
driver_before_line=before
after="control_out=out/'damaged-r4-control';control_out.mkdir();(control_out/'logs').mkdir()\nknown=run_one(oldcpp/'Generics__63.cpp',old_flags,root,control_out)"
text=old.decode();assert text.count(before)==1;text=text.replace(before,after);driver.write_bytes(text.encode())
text=oldwf.decode();assert text.count('  workflow_dispatch:\n')==1
text=text.replace('  workflow_dispatch:\n','''  workflow_dispatch:
    inputs:
      damage_control_only:
        description: Replay only the real damaged unit after a raw-log collision
        type: boolean
        default: false
''')
before='  compiler:\n    runs-on: macos-15';assert text.count(before)==1
text=text.replace(before,'  compiler:\n    if: ${{ !inputs.damage_control_only }}\n    runs-on: macos-15')
text+='''
  damage_control_replay:
    if: ${{ inputs.damage_control_only }}
    runs-on: macos-15
    timeout-minutes: 15
    steps:
      - uses: actions/checkout@v4
      - name: Select exact Xcode
        run: |
          sudo xcode-select -s /Applications/Xcode_16.4.app/Contents/Developer
          xcodebuild -version
      - uses: actions/download-artifact@v4
        with:
          github-token: ${{ github.token }}
          repository: lyiming710-cloud/GodsPVZ-iOS
          run-id: 39988665189
          name: GodsPVZ-Stage9-bulk389-unsigned-Xcode
          path: ${{ runner.temp }}/frozen-xcode-input
      - name: Restore the unchanged damaged diagnostic source and headers
        shell: bash
        run: |
          set -euo pipefail
          old="$RUNNER_TEMP/frozen-xcode-input/GodsPVZ-Stage9-bulk389-unsigned-Xcode.tar.zst"
          [ "$(shasum -a 256 "$old" | awk '{print $1}')" = '93d32bb83a6d93b1c9d8a490bf057db7cfe2e35dad1219ab4924b6ec38538e04' ]
          command -v zstd >/dev/null || brew install zstd
          mkdir -p "$RUNNER_TEMP/frozen-export"
          zstd -dc "$old" | tar -xf - -C "$RUNNER_TEMP/frozen-export"
      - name: Replay one damaged Apple unit with separately preserved raw log
        shell: bash
        run: |
          set -euo pipefail
          python3 scripts/actions/check_startup_r20_apple_damage_control.py \\
            --xcode-dir "$RUNNER_TEMP/frozen-export/xcode" \\
            --output-dir "$RUNNER_TEMP/r20-damage-control-only"
      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: Startup-R20-Apple-Damage-Control-${{ github.run_id }}-${{ github.run_attempt }}
          path: ${{ runner.temp }}/r20-damage-control-only/
          retention-days: 30
          if-no-files-found: error
'''
wf.write_bytes(text.encode());copy.write_bytes(text.encode())
extra=R/'scripts/actions/check_startup_r20_apple_damage_control.py'
pack(D/'LOG-COLLISION-REPAIR-SOURCES.zip',[(p.relative_to(R).as_posix(),p.read_bytes()) for p in [driver,wf,copy,extra]]+[(Path(__file__).name,Path(__file__).read_bytes())])
js(D/'LOG-COLLISION-REPAIR.json',dict(scope='RAW_LOG_RETENTION_FIX_NO_GAME_OR_COMPILER_RULE_CHANGE',
    driver_before_sha256=sha(old),driver_after_sha256=sha(driver.read_bytes()),
    exact_driver_before_line=driver_before_line,exact_driver_replacement=after,
    change='Dedicated output/log directory for the damaged R4 control; optional control-only job',
    frozen_run_one_flags_parser_controls_and_thresholds_unchanged=True,
    candidate_sha256='d887b370c95c2966dc40d80648d85c286bb42d85004c32d095f64f004e095b37',
    new_game_methods_or_positions=0,original_collision_evidence_saved_before_fix=True,control_replay='PREPARED_NOT_RUN'))
assets=json.loads(subprocess.check_output([r'C:\Program Files\GitHub CLI\gh.exe','release','view','bulk152-actions-checkpoint-2026-10-20','--repo','lyiming710-cloud/GodsPVZ-iOS','--json','assets']))['assets']
asset=next(r for r in assets if r['name']=='Startup-R20-Sites104-Linux-40219580971-generated.tar.gz')
assert asset['size']==152239861 and asset['digest']=='sha256:15a60954eb4a1a600c807412bc557833a9a4c798dc1e14e0e16fa6efa9c9d88d'
js(D/'GENERATED-SOURCE-RELEASE-RECEIPT.json',dict(scope='PERSISTENT_SOURCE_ARCHIVE_REMOTE_GITHUB_ASSET_METADATA_READBACK',asset=asset,
    local_sha256='15a60954eb4a1a600c807412bc557833a9a4c798dc1e14e0e16fa6efa9c9d88d',
    independently_rehashed_all_generated_sources=1029,source_run=40219580971,
    note='Remote API digest and size match; this is not a second download of the uploaded bytes'))
p=D/'README.md';text=p.read_text('utf-8');text+='''
## 当前候选 Apple 实测和日志保存纠正

[Apple run 40220652002](https://github.com/lyiming710-cloud/GodsPVZ-iOS/actions/runs/40220652002) 的 755 C++/274 C arm64 语法单元全部通过。逐一核对 1,029 个返回源文件身份与原始日志，0 错误，保留 10,572 条警告；Xcode 16.4/iPhoneOS18.5/arm64 参数、六个编译控制均核对。没有新 Unity 导出或播放器链接。

回读时发现历史 Apple driver 的 run_one 只按 basename 保存日志：损坏的历史 Generics__63.cpp 先产生 34 条错误，随后同名正常文件覆盖其 raw log。JSON 中原始 34 条错误及非零进程结果仍保存；正常源码的 1,029 个日志有效，损坏控制 raw log 单列为缺项。这个问题在历史 R19 原始证据中也存在。本次先保存覆盖前 driver/两份 JSON 与现存日志，再为损坏控制增加独立日志目录，并只补跑该一个控制单元，未修改候选、编译参数、解析或判定规则。补跑未完成前不把 raw log 记作已保留。

完整生成源码包（152,239,861 字节）另外上传到仓库 Release，远端资产大小与 SHA-256 元数据已匹配，避免仅依赖短期 Actions artifact。见 GENERATED-SOURCE-RELEASE-RECEIPT.json。
''';p.write_bytes(text.encode())
p=R/'README.md';text=p.read_text('utf-8').replace('Apple is prepared; no new Unity export, linked IPA or iPad acceptance.','Exact Apple arm64 syntax also passes all 1,029 units; a damaged-control raw-log collision is recorded and being replayed separately. No new Unity export, linked IPA or iPad acceptance.');p.write_bytes(text.encode())
p=R/'Recovery/STATUS.md';text=p.read_text('utf-8');marker='## Latest checkpoint - 2026-10-26\n';assert marker in text
text=text.replace(marker,marker+'\nR20 exact Apple run 40220652002: all 1,029 source/log records rechecked, zero errors and 10,572 retained warnings. Six compiler controls meet their expectations. A historical damaged/normal basename collision overwrote the damaged raw log while preserving its 34-error JSON; evidence is saved before a log-directory fix and control-only replay. This does not alter the candidate or the valid normal-source result. Product/IPA/device gates remain open.\n',1);p.write_bytes(text.encode())
manifest(D)
