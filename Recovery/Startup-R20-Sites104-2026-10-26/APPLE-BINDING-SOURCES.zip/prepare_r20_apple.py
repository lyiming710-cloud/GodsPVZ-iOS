"""Input-only Apple diagnostic binding after independently checking R20 sources."""
from pathlib import Path
import ast,json
from archive_support import sha,js,pack,manifest
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';D=R/'Recovery/Startup-R20-Sites104-2026-10-26'
linux=json.loads((D/'ACTUAL-COMPILER-40219580971.json').read_bytes())
assert linux['pass_'] and linux['raw_generated_sources_rehashed']==linux['raw_source_logs_rechecked']==1029
expected='d887b370c95c2966dc40d80648d85c286bb42d85004c32d095f64f004e095b37'
assert linux['candidate_sha256']==expected
assert any(x['sha256']=='15a60954eb4a1a600c807412bc557833a9a4c798dc1e14e0e16fa6efa9c9d88d' for x in linux['downloaded_archives'])
parent=R/'scripts/actions/check_startup_r19_apple.py';dest=R/'scripts/actions/check_startup_r20_apple.py'
assert not dest.exists();old=parent.read_bytes();text=old.decode();changes=[]
for before,after in [
 ('Startup R19','Startup R20'),('startup-r19','startup-r20'),
 ('STARTUP-R19-BATCH100','STARTUP-R20-SITES104'),('STARTUP_R19','STARTUP_R20'),
 ('0ba5bc7ec9603d14a1c0bde6d784d232aa78efaa1700304e75e4f2b56ef7dec2',expected),
 ('40195582520','40219580971')]:
    assert before in text;changes.append(dict(before=before,after=after,occurrences=text.count(before)));text=text.replace(before,after)
ast.parse(text);dest.write_bytes(text.encode())
wf=R/'.github/workflows/bulk401-apple-compiler-check.yml';oldwf=wf.read_bytes()
assert not (D/'PARENT-APPLE-COMPILER-WORKFLOW.yml').exists();(D/'PARENT-APPLE-COMPILER-WORKFLOW.yml').write_bytes(oldwf)
text=oldwf.decode();wfchanges=[]
for before,after in [
 ('Startup R19 Batch100','Startup R20 Sites104'),('Startup-R19-Batch100','Startup-R20-Sites104'),
 ('startup-r19','startup-r20'),('40195582520','40219580971'),
 ('2638628c5fbea4669e064af4db9df65e3a5022cb3420550d00ea517cf7698a47',
  '15a60954eb4a1a600c807412bc557833a9a4c798dc1e14e0e16fa6efa9c9d88d'),
 ('check_startup_r19_apple.py','check_startup_r20_apple.py')]:
    assert before in text;wfchanges.append(dict(before=before,after=after,occurrences=text.count(before)));text=text.replace(before,after)
wf.write_bytes(text.encode());(R/'.github/workflows/startup-r20-apple-compiler-check.yml').write_bytes(text.encode())
js(D/'APPLE-DERIVATION.json',dict(scope='INPUT_ONLY_R20_APPLE_BINDING_FLAGS_AND_CONTROLS_UNCHANGED',
    candidate_sha256=expected,source_conversion_run=40219580971,header_export_run=39988665189,
    parent_driver_sha256=sha(old),driver_sha256=sha(dest.read_bytes()),driver_changes=changes,
    parent_workflow_sha256=sha(oldwf),workflow_sha256=sha(wf.read_bytes()),workflow_changes=wfchanges,
    all_source_hash_checks_1029_and_six_controls_retained=True,
    historical_header_validation_sdk_arm64_flags_and_34_error_control_unchanged=True,
    new_unity_export=False,linked=False,ipa=None,status='PREPARED_NOT_RUN'))
files=[parent,dest,wf,R/'.github/workflows/startup-r20-apple-compiler-check.yml']
pack(D/'APPLE-BINDING-SOURCES.zip',[(p.relative_to(R).as_posix(),p.read_bytes()) for p in files]+[(Path(__file__).name,Path(__file__).read_bytes())])
manifest(D)
