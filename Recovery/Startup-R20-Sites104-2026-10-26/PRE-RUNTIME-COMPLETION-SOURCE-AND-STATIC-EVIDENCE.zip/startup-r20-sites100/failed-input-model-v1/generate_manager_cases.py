"""Finite lifecycle ordering and callback/field-capture cases after threshold."""
from pathlib import Path
import itertools,json,collections
Q=Path(__file__).resolve().parent;assert json.loads((Q/'SHARED-TEST-START.json').read_bytes())['repair_positions']>100;rows=[]
def add(rid,**v):
 q=dict(name='m'+str(len(rows)).zfill(5),token=f'0x{0x6000000|rid:08X}',mode='none',native_supported=True);q.update(v);rows.append(q)
for board,resource,mode in itertools.product([0,1],[0,1],['none','entry-fields','load-fields']):add(0x17e,board=board,resource=resource,mode=mode)
for board,hand,prop,display,mode in itertools.product([0,1,2],[-2147483648,-1,0,1,2,3,2147483647],[-1,0,1],[0,1],['none','alive-fields']):add(0x180,board=board,hand=hand,prop=prop,display=display,mode=mode)
add(0x180,board=1,hand=1,display=0,prop_present=0,native_supported=False)
for coin,diamond,resource,mode in itertools.product([-2147483648,-1,0,2147483647],[-1,0,2147483647],[0,1],['none','load-fields']):add(0x1f8,coin=coin,diamond=diamond,resource=resource,mode=mode)
for missing in ['global','manager','save']:add(0x1f8,**{missing:0},native_supported=False)
for mode in ['none','update-fields']:add(0x1f9,mode=mode)
for board,banks,bank_text,mode in itertools.product([0,1,2],[0,1],[0,1],['none','next-fields']):add(0x25e,board=board,banks=banks,bank_text=bank_text,mode=mode,native_supported=bool(board and banks))
for board,start,pause,finish,point,mode in itertools.product([0,1,2],[0,1],[0,1],[0,1],[-2147483648,-1,0,2147483647],['none','text-fields','fall-fields']):add(0x25f,board=board,start=start,pause=pause,finish=finish,point=point,mode=mode,native_supported=bool(board or mode=='text-fields'))
add(0x25f,board=1,text_present=0,native_supported=False)
for resource,mode in itertools.product([0,1],['none','load-fields','entry-fields']):add(0x271,resource=resource,mode=mode)
(Q/'MANAGER-CASES.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(records=len(rows),native=sum(r['native_supported'] for r in rows),per_method=dict(collections.Counter(r['token'] for r in rows)))))
