using System.Globalization;using System.Reflection;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public class UObj{public string Tag="";public bool Live=true;}
public class Device{}
public class Project{}
public class Zombie{}
public class Prop{public int propType;}
public class Mouse{public int handItemType;public Prop? propOnHand=new();}
public class Banks{public Text? sunPointText;}
public class Board:UObj{public Mouse mouseManager=new();public Banks? banks=new();public bool gameStart,gamePause,isFinished;}
public class Text:UObj
{
 public string? Last;public string? text{set{Last=value;Program.Trace.Add("Text:"+Tag+":"+value);if(Program.Mode=="text-fields"){Program.Sun.board=Program.OtherBoard;Program.Sun.sunPoint=88;}}}
}
public class DeviceManager
{
 public Board? board;public List<Device>? devicePrefabList;public bool display_Ban_device;
 public void Start_BoardEntry(){Program.Trace.Add("DeviceEntry:"+Program.Tag(board));if(Program.Mode=="entry-fields")board=Program.OtherBoard;}
 public void SetPreDevice()=>Program.Trace.Add("Pre:"+Program.ListName(devicePrefabList)+":"+Program.Tag(board));
 public void DisplayBan_device()=>Program.Trace.Add("Display:"+(display_Ban_device?1:0));
}
public class ProjectManager
{
 public List<Project>? projectPrefabs;public int money_Coin,money_Diamond;
 public void Update_Projects(){Program.Trace.Add("Projects:"+money_Coin);if(Program.Mode=="update-fields")money_Coin=123;}
 public void Update_MoneyBank()=>Program.Trace.Add("MoneyBank:"+money_Coin);
}
public class SunManager
{
 public Board? board;public Text? sunPointText;public int sunPoint;
 public void SetNextSunFallTime(){Program.Trace.Add("Next:"+Program.Tag(sunPointText));if(Program.Mode=="next-fields"){board=Program.OtherBoard;sunPoint=99;}}
 public void Update_SunFall(){Program.Trace.Add("SunFall:"+Program.Tag(board));if(Program.Mode=="fall-fields"){board=Program.OtherBoard;Program.OtherBoard.isFinished=true;}}
 public void Update_Suns()=>Program.Trace.Add("Suns:"+Program.Tag(board));
}
public class ZombieManager{public Board? board;public List<Zombie>? zombiePrefabList;public void Start_BoardEntry(){Program.Trace.Add("ZombieEntry:"+Program.ListName(zombiePrefabList));if(Program.Mode=="entry-fields")board=Program.OtherBoard;}}
public class Save{public int coins,diamond;}
public class SavesManager{public Save? playerSave;}
public class LawnApp{public SavesManager? savesManager;}
public static class Global{public static LawnApp? gLawnApp;}
public static class Resource
{
 public static List<Device>? Load_devicePrefabs(){Program.Trace.Add("LoadDevice");if(Program.Mode=="load-fields"){Program.Dev.board=Program.OtherBoard;Program.Dev.devicePrefabList=Program.OtherDevices;}return Program.N("resource",1)==0?null:Program.Devices;}
 public static List<Project>? Load_projectPrefabs(){Program.Trace.Add("LoadProject");if(Program.Mode=="load-fields")Global.gLawnApp=Program.OtherApp;return Program.N("resource",1)==0?null:Program.Projects;}
 public static List<Zombie>? Load_zombiePrefabs(){Program.Trace.Add("LoadZombie");if(Program.Mode=="load-fields"){Program.Zombies.board=Program.OtherBoard;Program.Zombies.zombiePrefabList=Program.OtherZombies;}return Program.N("resource",1)==0?null:Program.ZombiePrefabs;}
}
public static class Program
{
 public static JsonElement Case;public static List<string> Trace=[];public static DeviceManager Dev=null!;public static ProjectManager Proj=null!;public static SunManager Sun=null!;public static ZombieManager Zombies=null!;public static Board OtherBoard=null!;public static LawnApp OtherApp=null!;public static List<Device> Devices=null!,OtherDevices=null!,OldDevices=null!;public static List<Project> Projects=null!,OldProjects=null!;public static List<Zombie> ZombiePrefabs=null!,OtherZombies=null!,OldZombies=null!;public static Text Text=null!,OtherText=null!,StaleText=null!;
 public static string Mode=>Case.GetProperty("mode").GetString()!;public static int N(string k,int d=0)=>Case.TryGetProperty(k,out var v)?v.GetInt32():d;public static string Tag(UObj? v)=>v?.Tag??"null";
 public static string ListName(object? v)=>v==null?"null":ReferenceEquals(v,Devices)?"devices":ReferenceEquals(v,OldDevices)?"old-devices":ReferenceEquals(v,OtherDevices)?"other-devices":ReferenceEquals(v,Projects)?"projects":ReferenceEquals(v,OldProjects)?"old-projects":ReferenceEquals(v,ZombiePrefabs)?"zombies":ReferenceEquals(v,OldZombies)?"old-zombies":ReferenceEquals(v,OtherZombies)?"other-zombies":throw new Exception("Unknown list identity");
 public static bool Alive(UObj? p){bool live=p!=null&&p.Live;Trace.Add("Alive:"+Tag(p)+":"+(live?1:0));if(Mode=="alive-fields")Dev.board=OtherBoard;return live;}
 static Type Map(MC.TypeReference t)
 {
  if(t is MC.GenericInstanceType g&&g.ElementType.FullName=="System.Collections.Generic.List`1")return typeof(List<>).MakeGenericType(g.GenericArguments.Select(Map).ToArray());
  return t.FullName switch{"System.Void"=>typeof(void),"System.Boolean"=>typeof(bool),"System.Int32" or "ItemType"=>typeof(int),"System.String"=>typeof(string),"UnityEngine.Object"=>typeof(UObj),"DeviceManager"=>typeof(DeviceManager),"ProjectManager"=>typeof(ProjectManager),"SunManager"=>typeof(SunManager),"ZombieManager"=>typeof(ZombieManager),"ResourceManager"=>typeof(Resource),"Device"=>typeof(Device),"Project"=>typeof(Project),"Zombie"=>typeof(Zombie),"Board"=>typeof(Board),"Banks"=>typeof(Banks),"MouseManager"=>typeof(Mouse),"Prop"=>typeof(Prop),"TMPro.TMP_Text" or "TMPro.TextMeshProUGUI"=>typeof(Text),"GlobalStaticVars"=>typeof(Global),"GlobalStaticVars/LawnApp"=>typeof(LawnApp),"SavesManager"=>typeof(SavesManager),"Save"=>typeof(Save),_=>throw new NotSupportedException(t.FullName)};
 }
 static FieldInfo Field(MC.FieldReference f)=>Map(f.DeclaringType).GetField(f.Name)!;
 static MethodBase Method(MC.MethodReference m)=>m.DeclaringType.FullName=="UnityEngine.Object"?typeof(Program).GetMethod("Alive")!:Map(m.DeclaringType).GetMethod(m.Name,BindingFlags.Public|BindingFlags.Instance|BindingFlags.Static,null,m.Parameters.Select(p=>Map(p.ParameterType)).ToArray(),null)!;
 static object Snapshot(int rid)=>rid switch{0x17e or 0x180=>new{board=Tag(Dev.board),prefabs=ListName(Dev.devicePrefabList),display=Dev.display_Ban_device},0x1f8 or 0x1f9=>new{prefabs=ListName(Proj.projectPrefabs),coin=Proj.money_Coin,diamond=Proj.money_Diamond,global=ReferenceEquals(Global.gLawnApp,OtherApp)?"other":"initial"},0x25e or 0x25f=>new{board=Tag(Sun.board),text_owner=Tag(Sun.sunPointText),point=Sun.sunPoint,text=Text.Last,other_text=OtherText.Last,stale_text=StaleText.Last,other_finished=OtherBoard.isFinished},0x271=>new{board=Tag(Zombies.board),prefabs=ListName(Zombies.zombiePrefabList)},_=>throw new Exception()};
 public static void Main(string[] args)
 {
  CultureInfo.CurrentCulture=CultureInfo.InvariantCulture;var resolver=new MC.DefaultAssemblyResolver();resolver.AddSearchDirectory(args[1]);using var asm=MC.AssemblyDefinition.ReadAssembly(args[0],new MC.ReaderParameters{AssemblyResolver=resolver});int[] ids={0x17e,0x180,0x1f8,0x1f9,0x25e,0x25f,0x271};var methods=ids.ToDictionary(r=>r,r=>ActualCil.Emit((MC.MethodDefinition)asm.MainModule.LookupToken(0x6000000|r),Map,Field,Method));using var cases=JsonDocument.Parse(File.ReadAllText(args[2]));var rows=new List<object>();
  foreach(var q in cases.RootElement.EnumerateArray())
  {
   Case=q;Trace.Clear();Text=new(){Tag="text"};OtherText=new(){Tag="other-text"};StaleText=new(){Tag="stale-text"};OtherBoard=new(){Tag="other-board",gameStart=true,banks=new(){sunPointText=OtherText},mouseManager=new(){handItemType=2,propOnHand=new(){propType=9}}};var board=N("board",1)==0?null:new Board{Tag="board",Live=N("board",1)==1,gameStart=N("start")==1,gamePause=N("pause")==1,isFinished=N("finish")==1,banks=N("banks",1)==0?null:new(){sunPointText=N("bank_text",1)==0?null:Text},mouseManager=new(){handItemType=N("hand"),propOnHand=N("prop_present",1)==0?null:new(){propType=N("prop")}}};Devices=[];OtherDevices=[];OldDevices=[];Projects=[];OldProjects=[];ZombiePrefabs=[];OtherZombies=[];OldZombies=[];Dev=new(){board=board,devicePrefabList=OldDevices,display_Ban_device=N("display")==1};Proj=new(){projectPrefabs=OldProjects,money_Coin=-7,money_Diamond=-9};Sun=new(){board=board,sunPointText=N("text_present",1)==0?null:StaleText,sunPoint=N("point")};Zombies=new(){board=board,zombiePrefabList=OldZombies};OtherApp=new(){savesManager=new(){playerSave=new(){coins=900,diamond=901}}};Global.gLawnApp=N("global",1)==0?null:new(){savesManager=N("manager",1)==0?null:new(){playerSave=N("save",1)==0?null:new(){coins=N("coin"),diamond=N("diamond")}}};int rid=Convert.ToInt32(q.GetProperty("token").GetString(),16)&0xffffff;string? error=null;
   try{methods[rid].Invoke(null,[rid is 0x17e or 0x180?Dev:rid is 0x1f8 or 0x1f9?Proj:rid is 0x25e or 0x25f?Sun:(object)Zombies]);}catch(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;error=e.GetType().FullName;}
   rows.Add(new{name=q.GetProperty("name").GetString(),token=q.GetProperty("token").GetString(),error,trace=Trace.ToArray(),state=Snapshot(rid)});
  }
  File.WriteAllText(args[3],JsonSerializer.Serialize(new{scope="SEVEN_COMPLETE_RESTORED_MANAGER_CIL_BODIES_CONTROLLED_GAME_AND_ENGINE_LEAVES",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),methods=7,results=rows,eh_removed=false,private_access_bypass=false,unity_or_product_acceptance=false},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{records=rows.Count,methods=7}));
 }
}
