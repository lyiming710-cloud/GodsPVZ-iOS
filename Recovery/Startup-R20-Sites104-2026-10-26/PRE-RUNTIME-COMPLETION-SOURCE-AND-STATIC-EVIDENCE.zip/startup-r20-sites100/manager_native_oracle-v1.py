"""Seven original lifecycle callers; explicit modeled game/Unity leaves."""
from pathlib import Path
import collections,ctypes as C,functools,hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
im=NativeImage();state={};ids=[0x17e,0x180,0x1f8,0x1f9,0x25e,0x25f,0x271];cfgs={r:json.loads((Q/'native-source-complete'/f'0x{0x6000000|r:08X}.json').read_bytes()) for r in ids};fields=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_bytes())
@functools.lru_cache(None)
def off(owner,name):
 rs=[r for r in fields if r['type']==owner and r['namespace']=='' and r['name']==name];assert len(rs)==1,(owner,name,rs);return rs[0]['offset']
def at(owner,name):return state[owner]+off(owner,name)
def put8(p,v):C.c_ubyte.from_address(p).value=bool(v)
def get8(p):return bool(C.c_ubyte.from_address(p).value)
def tag(p):return 'null' if not p else state['tags'][p]
def make(label,size=1024):
 p=im.alloc(size);state['tags'][p]=label;return p
def mode():return state['q']['mode']
def string(s):
 b=s.encode('utf-16-le');p=im.alloc(24+len(b));put32(p+0x10,len(b)//2);C.memmove(p+0x14,b,len(b));return p
def text(p):return None if not p else C.string_at(p+0x14,get32(p+0x10)*2).decode('utf-16-le')
def resource(method,kind):
 assert not method;state['trace'].append('Load'+kind)
 if mode()=='load-fields':
  if kind=='Device':put64(at('DeviceManager','board'),state['other-board']);put64(at('DeviceManager','devicePrefabList'),state['other-devices'])
  elif kind=='Project':put64(global_static,state['other-app'])
  else:put64(at('ZombieManager','board'),state['other-board']);put64(at('ZombieManager','zombiePrefabList'),state['other-zombies'])
 return 0 if state['q'].get('resource',1)==0 else state[{'Device':'devices','Project':'projects','Zombie':'zombies'}[kind]]
def device_entry(p,method):
 assert p==state['DeviceManager'] and not method;state['trace'].append('DeviceEntry:'+tag(get64(at('DeviceManager','board'))))
 if mode()=='entry-fields':put64(at('DeviceManager','board'),state['other-board'])
def pre(p,method):assert p==state['DeviceManager'] and not method;state['trace'].append('Pre:'+tag(get64(at('DeviceManager','devicePrefabList')))+':'+tag(get64(at('DeviceManager','board'))))
def alive(p,method):
 assert not method;v=bool(p and state['live'].get(p,True));state['trace'].append('Alive:'+tag(p)+':'+str(int(v)))
 if mode()=='alive-fields':put64(at('DeviceManager','board'),state['other-board'])
 return v
def display(p,method):assert p==state['DeviceManager'] and not method;state['trace'].append('Display:'+str(int(get8(at('DeviceManager','display_Ban_device')))))
def projects(p,method):
 assert p==state['ProjectManager'] and not method;state['trace'].append('Projects:'+str(get32(at('ProjectManager','money_Coin'))))
 if mode()=='update-fields':put32(at('ProjectManager','money_Coin'),123)
def money(p,method):assert p==state['ProjectManager'] and not method;state['trace'].append('MoneyBank:'+str(get32(at('ProjectManager','money_Coin'))))
def nextsun(p,method):
 assert p==state['SunManager'] and not method;state['trace'].append('Next:'+tag(get64(at('SunManager','sunPointText'))))
 if mode()=='next-fields':put64(at('SunManager','board'),state['other-board']);put32(at('SunManager','sunPoint'),99)
def fall(p,method):
 assert p==state['SunManager'] and not method;state['trace'].append('SunFall:'+tag(get64(at('SunManager','board'))))
 if mode()=='fall-fields':put64(at('SunManager','board'),state['other-board']);put8(state['other-board']+off('Board','isFinished'),True)
def suns(p,method):assert p==state['SunManager'] and not method;state['trace'].append('Suns:'+tag(get64(at('SunManager','board'))))
def zombies(p,method):
 assert p==state['ZombieManager'] and not method;state['trace'].append('ZombieEntry:'+tag(get64(at('ZombieManager','zombiePrefabList'))))
 if mode()=='entry-fields':put64(at('ZombieManager','board'),state['other-board'])
def format_int(p,method):assert not method;return string(str(get32(p)))
def settext(p,value,method):
 assert not method and tag(p) in ['text','other-text','stale-text'];value=text(value);state['texts'][tag(p)]=value;state['trace'].append('Text:'+tag(p)+':'+value)
 if mode()=='text-fields':put64(at('SunManager','board'),state['other-board']);put32(at('SunManager','sunPoint'),88)
def snapshot(rid):
 if rid in [0x17e,0x180]:return dict(board=tag(get64(at('DeviceManager','board'))),prefabs=tag(get64(at('DeviceManager','devicePrefabList'))),display=get8(at('DeviceManager','display_Ban_device')))
 if rid in [0x1f8,0x1f9]:return dict(prefabs=tag(get64(at('ProjectManager','projectPrefabs'))),coin=get32(at('ProjectManager','money_Coin')),diamond=get32(at('ProjectManager','money_Diamond')),**{'global':'other' if get64(global_static)==state['other-app'] else 'initial'})
 if rid in [0x25e,0x25f]:return dict(board=tag(get64(at('SunManager','board'))),text_owner=tag(get64(at('SunManager','sunPointText'))),point=get32(at('SunManager','sunPoint')),text=state['texts']['text'],other_text=state['texts']['other-text'],stale_text=state['texts']['stale-text'],other_finished=get8(state['other-board']+off('Board','isFinished')))
 return dict(board=tag(get64(at('ZombieManager','board'))),prefabs=tag(get64(at('ZombieManager','zombiePrefabList'))))
try:
 dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True;slots=set()
 for cfg in cfgs.values():
  for row in cfg['instructions']:
   i=next(dis.disasm(bytes.fromhex(row['bytes']),int(row['va'],16)))
   if i.mnemonic not in ['mov','lea']:continue
   for o in i.operands:
    if o.type!=X86_OP_MEM or o.mem.base!=X86_REG_RIP:continue
    a=i.address+i.size+o.mem.disp;b=im.pe.get_data(a-im.base,8)
    if len(b)!=8:continue
    code=int.from_bytes(b,'little')
    if code>0xffffffff or code>>29 not in range(1,8) or a in slots:continue
    assert code>>29==1;slots.add(a);im.class_slot(a)
 def rip(va):
  i=next(dis.disasm(im.pe.get_data(va-im.base,15),va));return next(i.address+i.size+o.mem.disp for o in i.operands if o.type==X86_OP_MEM and o.mem.base==X86_REG_RIP)
 global_static=get64(get64(rip(0x180323a8d))+0xb8)
 def init(a):assert a in slots,hex(a)
 def barrier(a,p):assert get64(a)==(p or 0)
 im.hook(0x18024fef0,None,[P],init);im.hook(0x1802501e0,None,[P],lambda p:None);im.hook(0x18024f360,None,[P,P],barrier);im.hook(0x180338ff0,P,[P],lambda m:resource(m,'Device'));im.hook(0x180339fe0,P,[P],lambda m:resource(m,'Project'));im.hook(0x18033ba50,P,[P],lambda m:resource(m,'Zombie'));im.hook(0x180313b90,None,[P,P],device_entry);im.hook(0x180313500,None,[P,P],pre);im.hook(0x18131f870,C.c_bool,[P,P],alive);im.hook(0x1803125e0,None,[P,P],display);im.hook(0x180323fd0,None,[P,P],projects);im.hook(0x180323d70,None,[P,P],money);im.hook(0x180340b80,None,[P,P],nextsun);im.hook(0x180340e60,None,[P,P],fall);im.hook(0x180341050,None,[P,P],suns);im.hook(0x180342300,None,[P,P],zombies);im.hook(0x180ca3820,P,[P,P],format_int)
 def guarded_text(a,b,c):
  try:settext(a,b,c)
  except Exception as e:im.errors.append(dict(callback='virtual-text',error=repr(e)))
 cb=C.CFUNCTYPE(None,P,P,P)(guarded_text);im.callbacks.append(cb);text_entry=C.cast(cb,P).value
 for rid,cfg in cfgs.items():im.verify_caller(rid,int(cfg['entry'],16),cfg)
 rows=[];cases=json.loads((Q/'MANAGER-CASES.json').read_bytes())
 for q in cases:
  if not q['native_supported']:continue
  state.clear();state.update(q=q,tags={},live={},trace=[],texts={'text':None,'other-text':None,'stale-text':None})
  for label in ['DeviceManager','ProjectManager','SunManager','ZombieManager','board','other-board','banks','other-banks','mouse','other-mouse','prop','other-prop','text','other-text','stale-text','devices','old-devices','other-devices','projects','old-projects','zombies','old-zombies','other-zombies','app','other-app','manager','other-manager','save','other-save']:state[label]=make(label)
  state['live'][state['board']]=q.get('board',1)==1
  for label in ['text','other-text','stale-text']:cls=im.alloc(2048);put64(state[label],cls);put64(cls+0x558,text_entry)
  for label,other in [('board',False),('other-board',True)]:
   p=state[label];put64(p+off('Board','mouseManager'),state['other-mouse' if other else 'mouse']);put64(p+off('Board','banks'),state['other-banks' if other else 'banks'] if other or q.get('banks',1) else 0)
   for name,key,default in [('gameStart','start',1 if other else 0),('gamePause','pause',0),('isFinished','finish',0)]:put8(p+off('Board',name),default if other else q.get(key,default))
  put64(state['banks']+off('Banks','sunPointText'),state['text'] if q.get('bank_text',1) else 0);put64(state['other-banks']+off('Banks','sunPointText'),state['other-text'])
  for label,other in [('mouse',False),('other-mouse',True)]:put32(state[label]+off('MouseManager','handItemType'),2 if other else q.get('hand',0));put64(state[label]+off('MouseManager','propOnHand'),state['other-prop' if other else 'prop'] if other or q.get('prop_present',1) else 0)
  put32(state['prop']+off('Prop','propType'),q.get('prop',0));put32(state['other-prop']+off('Prop','propType'),9)
  for owner in ['DeviceManager','SunManager','ZombieManager']:put64(at(owner,'board'),state['board'] if q.get('board',1) else 0)
  put64(at('DeviceManager','devicePrefabList'),state['old-devices']);put8(at('DeviceManager','display_Ban_device'),q.get('display',0));put64(at('ProjectManager','projectPrefabs'),state['old-projects']);put32(at('ProjectManager','money_Coin'),-7);put32(at('ProjectManager','money_Diamond'),-9);put64(at('ZombieManager','zombiePrefabList'),state['old-zombies']);put64(at('SunManager','sunPointText'),state['stale-text']);put32(at('SunManager','sunPoint'),q.get('point',0));put64(global_static,state['app'])
  for label,mgr,save in [('app','manager','save'),('other-app','other-manager','other-save')]:put64(state[label]+off('LawnApp','savesManager'),state[mgr]);put64(state[mgr]+off('SavesManager','playerSave'),state[save])
  put32(state['save']+off('Save','coins'),q.get('coin',0));put32(state['save']+off('Save','diamond'),q.get('diamond',0));put32(state['other-save']+off('Save','coins'),900);put32(state['other-save']+off('Save','diamond'),901)
  rid=int(q['token'],16)&0xffffff;owner='DeviceManager' if rid in [0x17e,0x180] else 'ProjectManager' if rid in [0x1f8,0x1f9] else 'SunManager' if rid in [0x25e,0x25f] else 'ZombieManager';C.CFUNCTYPE(None,P,P)(int(cfgs[rid]['entry'],16))(state[owner],None);assert not im.errors,(q,im.errors);rows.append(dict(name=q['name'],token=q['token'],error=None,trace=list(state['trace']),state=snapshot(rid)))
 actual=json.loads(Path(sys.argv[1]).read_bytes());assert actual['candidate_sha256']==hashlib.sha256((Q/'authored1.dll').read_bytes()).hexdigest();byname={r['name']:r for r in actual['results']};assert set(byname)=={q['name'] for q in cases};diff=[dict(original=r,actual=byname[r['name']]) for r in rows if r!=byname[r['name']]]
 report=dict(scope='SEVEN_UNCHANGED_NATIVE_MANAGER_CALLERS_VS_COMPLETE_CANDIDATE_CIL_CONTROLLED_LEAVES',candidate_sha256=actual['candidate_sha256'],original_pc_sha256=hashlib.sha256(im.raw).hexdigest(),caller_bytes_verified=7,normal_records=len(rows),per_method=dict(collections.Counter(r['token'] for r in rows)),results=rows,differences=diff,managed_only_exception_records=[r for r in actual['results'] if not next(q for q in cases if q['name']==r['name'])['native_supported']],callback_errors=im.errors,controlled_leaves=['Resource prefab loaders','Board entry/preview/display/project/bank/sun leaf calls','Unity Object predicate and TMP virtual setter','Int32 decimal formatting','Initialized metadata/GC barrier'],limitations=['No callee gameplay internals, static constructor side effects, Unity rendering or native SEH','Finite normal callback cases are not universal equivalence'],formal_or_product_acceptance=False);Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k not in ['results','differences','managed_only_exception_records']}));print('differences',len(diff));assert not diff
finally:im.close()
