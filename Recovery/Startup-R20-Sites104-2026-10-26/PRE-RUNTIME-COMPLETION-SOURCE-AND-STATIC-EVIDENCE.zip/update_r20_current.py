"""Persist the real Card-chain correction and its failed predecessor."""
from pathlib import Path
import json
from archive_support import js,pack,manifest,sha
W=Path(__file__).resolve().parent;ROOT=W.parents[1];Q=W/'startup-r20-sites100';P=Q/'shared-authored3';R=ROOT/'audit/repo-native113';D=R/'Recovery/Startup-R20-Sites104-2026-10-26';a=json.loads((Q/'authored1.json').read_bytes());b=json.loads((Q/'authored3.json').read_bytes());old=a['candidate_sha256'];new=b['candidate_sha256'];native=json.loads((Q/'NATIVE-MANAGERS-AUTHORED3.json').read_bytes());failed=json.loads((Q/'shared-authored1/NATIVE-MANAGERS-FAILED-AUTHORED1.json').read_bytes());assert len(failed['differences'])==27 and not native['differences'] and native['normal_records']==552 and native['candidate_sha256']==new
assert b['new_unique_repair_positions']==104 and b['distinct_changed_methods']==8
for name in ['STARTUP-R20-SITES104-CANDIDATE.zip','SOURCE-AND-STATIC-EVIDENCE.zip','CONSTRUCTION.json','COMPILER-DERIVATION.json']:
 dest=D/('PRE-CARD-CORRECTION-'+name);assert not dest.exists();dest.write_bytes((D/name).read_bytes())
pack(D/'STARTUP-R20-SITES104-CANDIDATE.zip',[('STARTUP-R20-SITES104.dll',(Q/'authored3.dll').read_bytes())])
for src,name in [(Q/'authored3.json','CONSTRUCTION.json'),(Q/'CORRECTION-AUTHORED3.json','CORRECTION-AUTHORED3.json'),(Q/'ACTIVE-INPUT.json','ACTIVE-INPUT.json'),(P/'ISOLATION.json','ISOLATION.json'),(P/'FROZEN-RAW.json','FROZEN-RAW.json'),(P/'FROZEN-WITH-INTERFACE-FACTS.json','FROZEN-WITH-INTERFACE-FACTS.json'),(P/'MEMBER-EXIT.json','MEMBER-EXIT.json'),(P/'jit/RESULT.json','EXACT-JIT.json'),(Q/'NATIVE-MANAGERS-AUTHORED3.json','NATIVE-MANAGERS.json'),(Q/'shared-authored1/NATIVE-MANAGERS-FAILED-AUTHORED1.json','NATIVE-MANAGERS-FAILED-AUTHORED1.json')]:(D/name).write_bytes(src.read_bytes())
items=[]
for f in sorted(Q.rglob('*')):
 if not f.is_file() or '__pycache__' in f.parts or 'obj' in f.parts:continue
 if f.suffix=='.dll' and 'bin' not in f.parts:continue
 items.append(('startup-r20-sites100/'+f.relative_to(Q).as_posix(),f.read_bytes()))
items.append(('update_r20_current.py',Path(__file__).read_bytes()));pack(D/'SOURCE-AND-STATIC-EVIDENCE.zip',items)
for p in [R/'scripts/actions/check_startup_r20_compiler.py',R/'.github/workflows/bulk401-generic-compiler-check.yml',R/'.github/workflows/startup-r20-compiler-check.yml']:
 data=p.read_bytes();assert old.encode() in data;p.write_bytes(data.replace(old.encode(),new.encode()))
js(D/'COMPILER-DERIVATION.json',dict(scope='CARD_FIELD_CORRECTION_INPUT_ONLY_REBINDING_CONTROLS_AND_FLAGS_UNCHANGED',superseded_candidate_sha256=old,candidate_sha256=new,superseded_compiler_run=40218209871,superseded_run_ui_conclusion='success',superseded_complete_artifact_independent_readback=False,does_not_qualify_current_candidate=True,repair_positions_remain=104,changed_methods_remain=8,driver_sha256=sha((R/'scripts/actions/check_startup_r20_compiler.py').read_bytes()),workflow_sha256=sha((R/'.github/workflows/bulk401-generic-compiler-check.yml').read_bytes())))
pack(D/'COMPILER-BINDING-SOURCES.zip',[(p.relative_to(R).as_posix(),p.read_bytes()) for p in [R/'scripts/actions/check_startup_r19_compiler.py',R/'scripts/actions/check_startup_r20_compiler.py',R/'.github/workflows/bulk401-generic-compiler-check.yml',R/'.github/workflows/startup-r20-compiler-check.yml']]+[('update_r20_current.py',Path(__file__).read_bytes())])
j=json.loads((D/'PROGRESS.json').read_bytes());assert j['candidate_sha256']==old;j.update(status='CARD_CHAIN_CORRECTED_SEVEN_FINITE_RUNTIME_PROFILES_SAVE_UI_PENDING',candidate_sha256=new,superseded_candidate_sha256=old,superseded_native_manager_mismatches=27,current_native_manager_mismatches=0,manager_normal_comparison_records=552,finite_runtime_profile_methods=7,managed_only_manager_records=85,save_ui_runtime_profile='PENDING',native_harness_initial_process_failures=2,native_harness_failure_not_counted_as_detection=True,compiler='CURRENT_INPUT_REBOUND_NOT_RUN',superseded_compiler_run=40218209871,qualified_methods=0);js(D/'PROGRESS.json',j);js(Q/'PROGRESS.json',j)
p=D/'README.md';s=p.read_text(encoding='utf-8');s=s.replace('新候选 SHA-256：`'+old+'`','当前修正候选 SHA-256：`'+new+'`',1);s+='''
## 实际运行对照发现并修正 Card 对象链

最初 authored1/authored2 将 DeviceManager.Update 的 MouseManager+0x68 错写为 Prop+0xB0。初版原生执行桩也只构造了 Prop 对象，首次到达真实 Card 路径发生进程异常；两次崩溃和输入/桩源码已保留，不算检测通过。核对原版字段表后给原生桩和 CLR fixture 同时补充独立 Card/Prop 对象，并给它们相反的 sentinel 值，原版 552 条正常记录与旧候选产生 27 处真实差异。

修正为 MouseManager.cardOfBankOnHand -> Card.cardDeviceType，分别对应原版 +0x68、+0x2C。authored3/authored4 字节一致，只有 DeviceManager.Update 相对旧候选改变；仍为原来的八个目标/104 个位置，不额外计数。新候选七个管理器方法的 552 条完整 CIL/原版正常对照一致；85 条 CLR-only 空引用记录另列。调用链内的资源、游戏叶函数和文本设置是明确受控的依赖，这不是实际 Unity 生命周期或画面验收。存档列表重建的完整运行对照尚待完成。

旧候选的 GitHub Linux run 40218209871 界面显示 success，但它属于旧 SHA，既不能证明旧候选语义正确，也不能资格化当前新 SHA；其完整源文件/原始日志尚未独立回读。当前工作流已重新绑定新 SHA。PRE-CARD-CORRECTION 文件、旧 27 处差异和原生桩进程异常均保留。
''';p.write_bytes(s.encode());manifest(D)
p=R/'Recovery/STATUS.md';s=p.read_text(encoding='utf-8');marker=next(x+'\n' for x in s.splitlines() if x.startswith('## Latest checkpoint'));s=s.replace(marker,marker+'\nR20 Card-chain correction: only DeviceManager.Update changes relative to initial R20. Corrected authored3 has seven finite native/CIL profiles /552 matching normal records, versus 27 mismatches in the preserved predecessor. Initial native-harness null-Card process failures are retained as failures. 104 positions/eight targets remain unchanged. Save-list runtime, current-SHA compiler and product gates remain pending.\n',1);p.write_bytes(s.encode());print(json.dumps(dict(candidate_sha256=new,normal_records=552,finite_profiles=7,remaining_save_ui_profile=1)))
