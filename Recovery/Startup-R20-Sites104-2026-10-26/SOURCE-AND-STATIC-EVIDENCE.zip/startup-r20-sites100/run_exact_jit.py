"""Exact DLL JIT preparation; it does not invoke gameplay or Unity."""
from pathlib import Path
import sys,json,hashlib,subprocess,concurrent.futures,collections
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];stem=sys.argv[1];P=Q/('shared-'+stem)/'jit';P.mkdir(parents=True,exist_ok=True)
data=(Q/(stem+'.dll')).read_bytes();digest=hashlib.sha256(data).hexdigest();report=json.loads((Q/(stem+'.json')).read_bytes());assert digest==report['candidate_sha256'] and report['new_unique_methods']==8 and report['new_unique_repair_positions']>100 and (Q/'SHARED-TEST-START.json').exists()
dot=ROOT/'.local/dotnet10/dotnet.exe';probe=W/'startup-r5/jit-probe/bin/Release/net10.0/Probe.dll';support=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'
def one(token):
    out=P/(token+'.json')
    try:p=subprocess.run([str(dot),str(probe),str(Q/(stem+'.dll')),str(support),token,str(out)],capture_output=True,timeout=20)
    except subprocess.TimeoutExpired:return dict(token=token,status='TIMEOUT_UNSUPPORTED',method_executed=False)
    (P/(token+'.stdout.log')).write_bytes(p.stdout);(P/(token+'.stderr.log')).write_bytes(p.stderr)
    if p.returncode or not out.exists():return dict(token=token,status='PROCESS_FAILURE',exit_code=p.returncode,method_executed=False)
    r=json.loads(out.read_bytes());assert r['input_sha256']==digest and not r['method_executed'];return r
rows=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    for f in concurrent.futures.as_completed([pool.submit(one,r['token']) for r in report['changes']]):
        rows.append(f.result())
        if len(rows)%25==0:print(json.dumps(dict(completed=len(rows),counts=dict(collections.Counter(r['status'] for r in rows)))),flush=True)
result=dict(scope='EXACT_CANDIDATE_EIGHT_METHOD_104_POSITION_JIT_PREPARATION_NO_GAMEPLAY_INVOCATION',candidate_sha256=digest,methods=len(rows),counts=dict(collections.Counter(r['status'] for r in rows)),rows=sorted(rows,key=lambda r:r['token']),gameplay_execution=False)
(P/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))
