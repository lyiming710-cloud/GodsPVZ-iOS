"""Real whole-body omission controls; process failures never count as detection.

Each variant changes only the target MethodDef RVA back to the historical empty
body in R19. The complete candidate CIL is still emitted by the frozen rehost.
These controls test sensitivity to omitted behavior, not universal equivalence.
"""
from pathlib import Path
import hashlib,json,struct,subprocess,sys

Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1]
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
sha=lambda b:hashlib.sha256(b).hexdigest()
def js(p,v):p.write_bytes((json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode())
current=(Q/'authored3.dll').read_bytes();parent=(W/'startup-r19-batch100/candidate9.dll').read_bytes()
assert sha(current)=='d887b370c95c2966dc40d80648d85c286bb42d85004c32d095f64f004e095b37'
assert sha(parent)=='0ba5bc7ec9603d14a1c0bde6d784d232aa78efaa1700304e75e4f2b56ef7dec2'
rehost=W/'startup-r5/runtime-common/Rehost.cs'
assert sha(rehost.read_bytes())=='59b1e80892d0038ee188f0ef36d1af25ce37ae6df71016ba6617cc221ca51d40'
now=dnfile.dnPE(data=current);old=dnfile.dnPE(data=parent)
dotnet=ROOT/'.local/dotnet10/dotnet.exe';refs=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'
out=Q/'runtime-controls-authored3-attempt2';out.mkdir(exist_ok=False)
results=[]
for rid in [0x17e,0x180,0x1f8,0x1f9,0x25e,0x25f,0x271,0x6a7]:
    token=f'0x{0x6000000|rid:08X}';kind='SAVE-UI' if rid==0x6a7 else 'MANAGERS'
    oracle=json.loads((Q/f'NATIVE-{kind}-AUTHORED3.json').read_bytes())
    baseline=json.loads((Q/f'FULL-CIL-{kind}-AUTHORED3.json').read_bytes())
    expected={r['name']:r for r in oracle['results']}
    actual={r['name']:r for r in baseline['results']}
    assert all(actual[n]==v for n,v in expected.items())
    assert oracle['candidate_sha256']==baseline['candidate_sha256']==sha(current)
    before=old.net.mdtables.MethodDef.rows[rid-1];after=now.net.mdtables.MethodDef.rows[rid-1]
    at=old.get_offset_from_rva(before.Rva)
    assert parent[at:at+2]==bytes.fromhex('062a'),'Historical body is not tiny ret'
    where=after.struct.get_file_offset();assert struct.unpack_from('<I',current,where)[0]==after.Rva
    data=bytearray(current);struct.pack_into('<I',data,where,before.Rva)
    assert bytes(data[:where])==current[:where] and bytes(data[where+4:])==current[where+4:]
    v=out/f'{token}-reverted.dll';v.write_bytes(data)
    fixture=Q/('runtime-save-ui' if rid==0x6a7 else 'runtime-managers')/'bin/Release/net10.0/Fixture.dll'
    assert fixture.is_file(),fixture
    casefile=Q/('SAVE-UI-CASES.json' if rid==0x6a7 else 'MANAGER-CASES.json')
    returned=out/f'{token}-actual.json'
    cmd=[str(dotnet),str(fixture),str(v),str(refs),str(casefile),str(returned)]
    cp=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (out/f'{token}.stdout.log').write_bytes(cp.stdout);(out/f'{token}.stderr.log').write_bytes(cp.stderr)
    assert cp.returncode==0,('CONTROL_PROCESS_FAILURE_IS_NOT_DETECTION',token,cp.returncode)
    got=json.loads(returned.read_bytes());assert got['candidate_sha256']==sha(data)
    observed={r['name']:r for r in got['results']};assert set(observed)==set(actual)
    differences=[dict(name=n,expected=e,actual=observed[n]) for n,e in expected.items() if e!=observed[n]]
    assert differences and all(r['expected']['token']==token for r in differences)
    assert all(r['actual']['error'] is None for r in differences),'InvalidProgram/exception is not behavior detection'
    row=dict(token=token,variant_sha256=sha(data),physical_dll_bytes=len(data),methoddef_rva_file_offset=where,
        current_rva=after.Rva,reverted_parent_rva=before.Rva,parent_body='tiny ret',
        process_exit=cp.returncode,normal_comparison_records=len(expected),
        target_comparison_records=sum(r['token']==token for r in expected.values()),
        behavioral_differences=len(differences),other_method_differences=0,detected=True,
        actual_result_sha256=sha(returned.read_bytes()),differences=differences)
    js(out/f'{token}-detection.json',row);results.append(row)
    print(json.dumps({k:v for k,v in row.items() if k!='differences'}),flush=True)
assert sha(rehost.read_bytes())=='59b1e80892d0038ee188f0ef36d1af25ce37ae6df71016ba6617cc221ca51d40'
report=dict(scope='ACTUAL_COMPLETE_CIL_PHYSICAL_RVA_REVERSION_CONTROLS',candidate_sha256=sha(current),
    controls=len(results),detected=sum(r['detected'] for r in results),process_failures=0,
    no_exception_counted_as_detection=True,normal_baseline_native_comparisons=768,
    frozen_rehost_sha256=sha(rehost.read_bytes()),results=results,
    limitations=['Whole-method omission controls do not prove sensitivity to every instruction mutation',
        'Controlled engine leaves and finite test inputs; no actual Unity or iPad acceptance'],
    formal_or_product_acceptance=False)
js(out/'RESULT.json',report)
