from pathlib import Path
import itertools,json
Q=Path(__file__).resolve().parent;assert json.loads((Q/'SHARED-TEST-START.json').read_bytes())['repair_positions']>100;rows=[]
for old,saved,skip,mode in itertools.product(['','L','LDN','LL'],[0,1,3],['none','first','odd'],['none','destroy-replaces','start-count','start-list','start-manager','parent-content']):rows.append(dict(name='u'+str(len(rows)).zfill(4),old=old,saved=saved,skip=skip,mode=mode,native_supported=True))
for missing in ['manager','list']:rows.append(dict(name='u'+str(len(rows)).zfill(4),old='',saved=0,skip='none',mode='none',native_supported=False,**{missing:0}))
(Q/'SAVE-UI-CASES.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print('save UI cases',len(rows))
