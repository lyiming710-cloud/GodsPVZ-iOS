"""Original save-list caller with real inlined list mutations and modeled leaves."""
from pathlib import Path
import ctypes as C,functools,hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
im=NativeImage();state={};cfg=json.loads((Q/'native-source-complete/0x060006A7.json').read_bytes());fields=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_bytes())
@functools.lru_cache(None)
def off(owner,name):
 rs=[r for r in fields if r['type']==owner and r['namespace']=='' and r['name']==name];assert len(rs)==1,(owner,name,rs);return rs[0]['offset']
def at(name):return state['page']+off('SavesUIController',name)
def mode():return state['q']['mode']
def tag(p):return 'null' if not p else state['tags'][p]
def make(label,size=1024):
 p=im.alloc(size);state['tags'][p]=label;return p
def array(values,capacity):
 assert capacity>=len(values);p=im.alloc(32+8*capacity);put32(p+0x18,capacity)
 for i,v in enumerate(values):put64(p+0x20+8*i,v)
 return p
def reflist(label,values):
 p=make(label);put64(p+0x10,array(values,len(values)));put32(p+0x18,len(values));put32(p+0x1c,0);return p
def row(label,live=True):
 p=make(label);obj=make(label+'-object');tr=make(label+'-transform');state['live'][p]=live;state['objects'][p]=obj;state['transforms'][p]=tr;state['parents'][tr]=None;put32(p+off('SavesUIController_PlayerSave','playerSaveID'),-777);return p
def unequal(p,b,method):
 assert not b and not method;v=bool(p and state['live'][p]);state['trace'].append('Unequal:'+tag(p)+':'+str(int(v)));return v
def alive(p,method):
 assert not method;v=bool(p and state['live'][p]);state['trace'].append('Alive:'+tag(p)+':'+str(int(v)));return v
def getitem(p,index,method):
 assert method in handles and 0<=index<get32(p+0x18);return get64(get64(p+0x10)+0x20+8*index)
def gameobject(p,method):assert not method;state['trace'].append('Object:'+tag(p));return state['objects'][p]
def destroy(p,method):
 assert not method;state['trace'].append('Destroy:'+tag(p));state['destroyed'].add(tag(p))
 if not state['destroy_changed']:
  state['destroy_changed']=True
  if mode()=='destroy-replaces':put64(at('playerSaveList'),state['other-list'])
def clear_array(p,start,count,method):
 assert not method and 0<=start<=start+count<=get32(p+0x18)
 for i in range(start,start+count):put64(p+0x20+8*i,0)
def instantiate(prefab,method):
 assert method in handles and prefab==get64(at('playerSavePrefab'));n=state['calls'];state['calls']+=1;assert n<32;state['trace'].append('Instantiate:'+str(n));skip=state['q']['skip']
 if skip=='first' and n==0 or skip=='odd' and n&1:return 0
 p=row('new'+str(n));state['created'].append(p);return p
def component_transform(p,method):assert not method;state['trace'].append('Transform:'+tag(p));return state['transforms'][p]
def content_transform(p,method):assert not method and tag(p) in ['content','other-content'];state['trace'].append('ParentTransform:'+tag(p));return state['parent'] if tag(p)=='content' else state['other-parent']
def setparent(p,parent,stays,method):
 assert not method and p in state['parents'];state['parents'][p]=tag(parent);state['trace'].append('Parent:'+tag(p)+':'+tag(parent)+':'+str(int(stays)))
 if mode()=='parent-content':put64(at('playerListContent'),state['other-content'])
def start(p,method):
 assert not method and p in state['created'];ident=get32(p+off('SavesUIController_PlayerSave','playerSaveID'));mgr=get64(p+off('SavesUIController_PlayerSave','savesManager'));owner=get64(p+off('SavesUIController_PlayerSave','savesUIController'));state['trace'].append('Start:'+tag(p)+':'+str(ident)+':'+tag(mgr)+':'+tag(owner))
 if not state['start_changed']:
  state['start_changed']=True
  if mode()=='start-count':put32(at('saveNum'),0)
  if mode()=='start-list':put64(at('playerSaveList'),state['other-list'])
  if mode()=='start-manager':put64(at('savesManager'),state['other-manager'])
def add_core(p,value,increment):
 assert tag(p) in ['initial-list','other-list'];size=get32(p+0x18);arr=get64(p+0x10);capacity=get32(arr+0x18)
 if increment:put32(p+0x1c,get32(p+0x1c)+1)
 if size>=capacity:
  assert size==capacity;newcap=4 if capacity==0 else 2*capacity;values=[get64(arr+0x20+8*i) for i in range(size)];arr=array(values,newcap);put64(p+0x10,arr)
 put64(arr+0x20+8*size,value);put32(p+0x18,size+1)
def add(p,value,method):assert method in handles;add_core(p,value,True)
def resize_add(p,value,method):assert method in handles;add_core(p,value,False)
def liststate(p):
 n=get32(p+0x18);a=get64(p+0x10);return dict(items=[tag(get64(a+0x20+8*i)) for i in range(n)],size=n,capacity=get32(a+0x18),version=get32(p+0x1c))
def snapshot():
 def child(p):return dict(tag=tag(p),id=get32(p+off('SavesUIController_PlayerSave','playerSaveID')),manager=tag(get64(p+off('SavesUIController_PlayerSave','savesManager'))),owner=tag(get64(p+off('SavesUIController_PlayerSave','savesUIController'))),parent=state['parents'][state['transforms'][p]])
 p=get64(at('playerSaveList'));return dict(root='other' if p==state['other-list'] else 'initial' if p==state['initial-list'] else 'null',save_num=get32(at('saveNum')),manager=tag(get64(at('savesManager'))),content=tag(get64(at('playerListContent'))),initial=liststate(state['initial-list']),other=liststate(state['other-list']),created=[child(p) for p in state['created']],destroyed=sorted(state['destroyed']),instantiate_calls=state['calls'])
try:
 dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True;slots=set();handles=set()
 for raw in cfg['instructions']:
  i=next(dis.disasm(bytes.fromhex(raw['bytes']),int(raw['va'],16)))
  if i.mnemonic not in ['mov','lea']:continue
  for o in i.operands:
   if o.type!=X86_OP_MEM or o.mem.base!=X86_REG_RIP:continue
   a=i.address+i.size+o.mem.disp;b=im.pe.get_data(a-im.base,8)
   if len(b)!=8:continue
   code=int.from_bytes(b,'little')
   if code>0xffffffff or code>>29 not in range(1,8) or a in slots:continue
   assert code>>29!=5,'No fabricated string metadata';slots.add(a);info=im.class_slot(a);handles.add(info)
   # Model only opaque generic context pointers traversed by the inlined
   # final AddWithResize call. Callee algorithms remain explicit contracts.
   context=im.alloc(512);nested=im.alloc(512);leaf=im.alloc(512);put64(info+0x20,context);put64(context+0xc0,nested);put64(nested+0x70,leaf);handles.add(leaf)
 def init(a):assert a in slots,hex(a)
 def barrier(a,p):assert get64(a)==(p or 0)
 im.hook(0x18024fef0,None,[P],init);im.hook(0x1802501e0,None,[P],lambda p:None);im.hook(0x18024f360,None,[P,P],barrier);im.hook(0x180825710,P,[P,I,P],getitem);im.hook(0x18131f900,C.c_bool,[P,P,P],unequal);im.hook(0x18131f870,C.c_bool,[P,P],alive);im.hook(0x1813044d0,P,[P,P],gameobject);im.hook(0x18131e940,None,[P,P],destroy);im.hook(0x180cb86f0,None,[P,I,I,P],clear_array);im.hook(0x1804a0690,P,[P,P],instantiate);im.hook(0x181304510,P,[P,P],component_transform);im.hook(0x18131c070,P,[P,P],content_transform);im.hook(0x18132e900,None,[P,P,C.c_bool,P],setparent);im.hook(0x1803a9c00,None,[P,P],start);im.hook(0x180002e70,None,[P,P,P],add);im.hook(0x180847ce0,None,[P,P,P],resize_add);im.verify_caller(0x6a7,int(cfg['entry'],16),cfg)
 rows=[];cases=json.loads((Q/'SAVE-UI-CASES.json').read_bytes())
 for q in cases:
  if not q['native_supported']:continue
  state.clear();state.update(q=q,tags={},live={},trace=[],objects={},transforms={},parents={},created=[],destroyed=set(),calls=0,destroy_changed=False,start_changed=False)
  for label in ['page','manager','other-manager','save-list','other-save-list','content','other-content','parent','other-parent']:state[label]=make(label)
  state['prefab']=row('prefab');initial=[];other=[]
  for i,ch in enumerate(q['old']):initial.append(0 if ch=='N' else row('old'+str(i),ch=='L'));other.append(0 if ch=='N' else row('other-old'+str(i),ch=='L'))
  state['initial-list']=reflist('initial-list',initial);state['other-list']=reflist('other-list',other)
  saved=reflist('saved-list',[make('save'+str(i)) for i in range(q['saved'])]);other_saved=reflist('other-saved-list',[make('other-save0'),make('other-save1')]);put64(state['save-list']+off('SaveList','saveList'),saved);put64(state['other-save-list']+off('SaveList','saveList'),other_saved);put64(state['manager']+off('SavesManager','saveList'),state['save-list']);put64(state['other-manager']+off('SavesManager','saveList'),state['other-save-list']);put64(at('savesManager'),state['manager']);put64(at('playerSavePrefab'),state['prefab']);put64(at('playerListContent'),state['content']);put64(at('playerSaveList'),state['initial-list']);put32(at('saveNum'),-7)
  if '--trace-cases' in sys.argv:print(json.dumps(dict(starting_case=q['name'])),flush=True)
  C.CFUNCTYPE(None,P,P)(int(cfg['entry'],16))(state['page'],None);assert not im.errors,(q,im.errors);rows.append(dict(name=q['name'],token='0x060006A7',error=None,trace=list(state['trace']),state=snapshot()))
 actual=json.loads(Path(sys.argv[1]).read_bytes());assert actual['candidate_sha256']==hashlib.sha256((Q/'authored3.dll').read_bytes()).hexdigest();byname={r['name']:r for r in actual['results']};assert set(byname)=={q['name'] for q in cases};diff=[dict(original=r,actual=byname[r['name']]) for r in rows if r!=byname[r['name']]]
 report=dict(scope='ORIGINAL_SAVE_UI_REBUILD_CALLER_VS_COMPLETE_CANDIDATE_CIL_REAL_CLR_REFERENCE_LISTS',candidate_sha256=actual['candidate_sha256'],original_pc_sha256=hashlib.sha256(im.raw).hexdigest(),caller_bytes_verified=True,normal_records=len(rows),results=rows,differences=diff,managed_only_exception_records=[r for r in actual['results'] if not next(q for q in cases if q['name']==r['name'])['native_supported']],callback_errors=im.errors,controlled_leaves=['Unity lifetime/Instantiate/Destroy/component transforms/SetParent','Child Start0 callbacks','Reference-list item/Add/AddWithResize and Array.Clear','Typed opaque generic metadata context and GC'],real_native_inlined_list_clear_and_final_add_executed=True,clr_reference_list_version_capacity_observed=True,limitations=['No engine destruction scheduling, prefab internals, actual child initialization or native SEH','Modeled list resize contract is finite small-capacity scope','No actual UI rendering or universal equivalence proof'],formal_or_product_acceptance=False);Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k not in ['results','differences','managed_only_exception_records']}));print('differences',len(diff));assert not diff
finally:im.close()
