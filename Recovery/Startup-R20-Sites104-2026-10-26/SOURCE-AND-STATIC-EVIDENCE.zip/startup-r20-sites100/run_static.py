"""Run immutable exporter/checkers against an exact R19 candidate."""
from pathlib import Path
import hashlib,json,subprocess,sys,collections,importlib.util
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True
stem=sys.argv[1];P=Q/('shared-'+stem);P.mkdir(exist_ok=True);candidate=Q/(stem+'.dll');report=json.loads((Q/(stem+'.json')).read_bytes());digest=hashlib.sha256(candidate.read_bytes()).hexdigest()
assert report['new_unique_methods']==8 and report['new_unique_repair_positions']>100 and report['candidate_sha256']==digest and (Q/'SHARED-TEST-START.json').exists()
dot=ROOT/'.local/dotnet10/dotnet.exe';support=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'
def save(name,obj):(P/name).write_bytes((json.dumps(obj,indent=2)+'\n').encode())
if sys.argv[2]=='member':
    tool=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/member-bin/MemberAccess.dll'
    assert hashlib.sha256(tool.read_bytes()).hexdigest()=='d21ae9d0b39cbadc7c0412c87f41942e86d7eff25b22212c2c64cdd1fc4833db'
    p=subprocess.run([str(dot),str(tool),str(candidate),str(support),str(Q/'ALL-METHODS.json'),str(P/'MEMBER-ACCESS-ALL.json')],capture_output=True)
    (P/'member.stdout.log').write_bytes(p.stdout);(P/'member.stderr.log').write_bytes(p.stderr);save('MEMBER-EXIT.json',dict(candidate_sha256=digest,exit_code=p.returncode))
    print(p.stdout.decode());print('Actual member exit:',p.returncode);assert p.returncode in [0,2]
else:
    exporter=ROOT/'audit/bulk250-r1-evidence-39702928368/bulk250-r1-run/tools_bin/CilExporter/bin/CilExporter.dll'
    assert hashlib.sha256(exporter.read_bytes()).hexdigest()=='0a9964ecd2cfa0f5f7e57ecb41b5809c6f305070285734a36cdebc2747798dc0'
    tokens=[r['token'] for r in json.loads((Q/'ALL-METHODS.json').read_bytes())['methods']];assert len(tokens)==2297
    p=subprocess.run([str(dot),str(exporter),str(candidate),str(P/'ALL-CIL.json'),str(support),','.join(tokens)],capture_output=True)
    (P/'export.stdout.log').write_bytes(p.stdout);(P/'export.stderr.log').write_bytes(p.stderr);assert p.returncode==0
    frozen=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py';fh=hashlib.sha256(frozen.read_bytes()).hexdigest();assert fh=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14'
    spec=importlib.util.spec_from_file_location('unchanged_frozen_r19',frozen);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
    cil=json.loads((P/'ALL-CIL.json').read_bytes());results=[];targets={r['token'] for r in report['changes']}
    for m in cil['methods']:
        try:r=v.verify(m,cil['types'])
        except Exception as e:r=dict(token=m['token'],method=m['name'],status='FAIL_OR_UNSUPPORTED',error=str(e))
        results.append(r)
    counts=dict(collections.Counter(r['status'] for r in results));changed=[r for r in results if r['token'] in targets]
    summary=dict(scope='IMMUTABLE_WHOLE_ASSEMBLY_TYPE_STACK_CENSUS_NOT_BEHAVIORAL_ACCEPTANCE',candidate_sha256=digest,checker_sha256=fh,total=len(results),counts=counts,changed_counts=dict(collections.Counter(r['status'] for r in changed)),results=results)
    save('FROZEN-RAW.json',summary);print(json.dumps({k:x for k,x in summary.items() if k!='results'},indent=2));print(json.dumps([r for r in changed if r['status']!='PASS'],indent=2))
