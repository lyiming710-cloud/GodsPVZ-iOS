"""Construct source-backed positions; never start a test automatically."""
import sys
from construction import Context
import source_managers,source_save_list
def build(stem):
 c=Context();source_managers.populate(c);source_save_list.populate(c);c.save_authored(stem)
if __name__=='__main__':build(sys.argv[1])
