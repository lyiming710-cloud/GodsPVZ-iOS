using System.Reflection;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public class UObj{public string Tag="";public bool Live=true;}
public class Transform:UObj
{
 public string? Parent;
 public void SetParent(Transform p,bool stays){Parent=p.Tag;Program.Trace.Add("Parent:"+Tag+":"+p.Tag+":"+(stays?1:0));if(Program.Mode=="parent-content")Program.Page.playerListContent=Program.OtherContent;}
}
public class GameObject:UObj{public Transform Value=null!;public Transform transform{get{Program.Trace.Add("ParentTransform:"+Tag);return Value;}}}
public class Component:UObj
{
 public GameObject Obj=null!;public Transform Value=null!;
 public GameObject gameObject{get{Program.Trace.Add("Object:"+Tag);return Obj;}}
 public Transform transform{get{Program.Trace.Add("Transform:"+Tag);return Value;}}
}
public class Save{}
public class SaveList{public List<Save> saveList=[];}
public class SavesManager:UObj{public SaveList saveList=new();}
public class SavePage:UObj{public SavesManager? savesManager;public SaveRow playerSavePrefab=null!;public GameObject playerListContent=null!;public int saveNum=-7;public List<SaveRow>? playerSaveList;}
public class SaveRow:Component
{
 public SavesManager? savesManager;public SavePage? savesUIController;public int playerSaveID=-777;
 public void Start0()
 {
  Program.Trace.Add("Start:"+Tag+":"+playerSaveID+":"+Program.Tag(savesManager)+":"+Program.Tag(savesUIController));
  if(!Program.StartChanged){Program.StartChanged=true;if(Program.Mode=="start-count")Program.Page.saveNum=0;if(Program.Mode=="start-list")Program.Page.playerSaveList=Program.OtherList;if(Program.Mode=="start-manager")Program.Page.savesManager=Program.OtherManager;}
 }
}
public static class Program
{
 public static JsonElement Case;public static List<string> Trace=[];public static SavePage Page=null!;public static SavesManager OtherManager=null!;public static GameObject OtherContent=null!;public static List<SaveRow> InitialList=null!,OtherList=null!;public static List<SaveRow> Created=[];public static HashSet<string> Destroyed=[];public static bool DestroyChanged,StartChanged;public static int Calls;
 public static string Mode=>Case.GetProperty("mode").GetString()!;public static int N(string k,int d=0)=>Case.TryGetProperty(k,out var v)?v.GetInt32():d;public static string Tag(UObj? p)=>p?.Tag??"null";
 public static bool Alive(UObj? p){bool value=p!=null&&p.Live;Trace.Add("Alive:"+Tag(p)+":"+(value?1:0));return value;}
 public static bool Unequal(UObj? p,UObj? b){if(b!=null)throw new Exception();bool value=p!=null&&p.Live;Trace.Add("Unequal:"+Tag(p)+":"+(value?1:0));return value;}
 public static void Destroy(UObj p){Trace.Add("Destroy:"+p.Tag);Destroyed.Add(p.Tag);if(!DestroyChanged){DestroyChanged=true;if(Mode=="destroy-replaces")Page.playerSaveList=OtherList;}}
 public static T? Instantiate<T>(T prefab) where T:UObj
 {
  if(prefab!=Page.playerSavePrefab)throw new Exception("Prefab identity");int n=Calls++;if(n>=32)throw new Exception("Unbounded create loop");Trace.Add("Instantiate:"+n);string skip=Case.GetProperty("skip").GetString()!;if(skip=="first"&&n==0||skip=="odd"&&(n&1)!=0)return null;SaveRow r=Row("new"+n,true);Created.Add(r);return (T)(UObj)r;
 }
 public static SaveRow Row(string tag,bool live)=>new(){Tag=tag,Live=live,Obj=new(){Tag=tag+"-object",Value=new(){Tag=tag+"-object-transform"}},Value=new(){Tag=tag+"-transform"}};
 static Type Map(MC.TypeReference t)
 {
  if(t is MC.GenericInstanceType g&&g.ElementType.FullName=="System.Collections.Generic.List`1")return typeof(List<>).MakeGenericType(g.GenericArguments.Select(Map).ToArray());
  return t.FullName switch{"System.Void"=>typeof(void),"System.Boolean"=>typeof(bool),"System.Int32"=>typeof(int),"System.Object"=>typeof(object),"UnityEngine.Object"=>typeof(UObj),"UnityEngine.Component"=>typeof(Component),"UnityEngine.GameObject"=>typeof(GameObject),"UnityEngine.Transform"=>typeof(Transform),"SavesUIController"=>typeof(SavePage),"SavesUIController_PlayerSave"=>typeof(SaveRow),"SavesManager"=>typeof(SavesManager),"SaveList"=>typeof(SaveList),"Save"=>typeof(Save),_=>throw new NotSupportedException(t.FullName)};
 }
 static FieldInfo Field(MC.FieldReference f)=>Map(f.DeclaringType).GetField(f.Name)!;
 static MethodBase Method(MC.MethodReference m)
 {
  if(m is MC.GenericInstanceMethod g&&m.Name=="Instantiate")return typeof(Program).GetMethod("Instantiate")!.MakeGenericMethod(g.GenericArguments.Select(Map).ToArray());
  if(m.DeclaringType.FullName=="UnityEngine.Object")return typeof(Program).GetMethod(m.Name=="op_Implicit"?"Alive":m.Name=="op_Inequality"?"Unequal":m.Name)!;
  return Map(m.DeclaringType).GetMethod(m.Name,BindingFlags.Public|BindingFlags.Instance|BindingFlags.Static,null,m.Parameters.Select(p=>Map(p.ParameterType)).ToArray(),null)!;
 }
 static object ListState(List<SaveRow> list)=>new{items=list.Select(x=>Tag(x)).ToArray(),size=list.Count,capacity=list.Capacity,version=(int)typeof(List<SaveRow>).GetField("_version",BindingFlags.Instance|BindingFlags.NonPublic)!.GetValue(list)!};
 public static void Main(string[] args)
 {
  var resolver=new MC.DefaultAssemblyResolver();resolver.AddSearchDirectory(args[1]);using var asm=MC.AssemblyDefinition.ReadAssembly(args[0],new MC.ReaderParameters{AssemblyResolver=resolver});var code=ActualCil.Emit((MC.MethodDefinition)asm.MainModule.LookupToken(0x60006a7),Map,Field,Method);using var cases=JsonDocument.Parse(File.ReadAllText(args[2]));var rows=new List<object>();
  foreach(var q in cases.RootElement.EnumerateArray())
  {
   Case=q;Trace.Clear();Created=[];Destroyed=[];DestroyChanged=false;StartChanged=false;Calls=0;string pattern=q.GetProperty("old").GetString()!;var first=new List<SaveRow?>();var second=new List<SaveRow?>();for(int k=0;k<pattern.Length;k++){first.Add(pattern[k]=='N'?null:Row("old"+k,pattern[k]=='L'));second.Add(pattern[k]=='N'?null:Row("other-old"+k,pattern[k]=='L'));}InitialList=new(first!);OtherList=new(second!);OtherContent=new(){Tag="other-content",Value=new(){Tag="other-parent"}};OtherManager=new(){Tag="other-manager",saveList=new(){saveList=Enumerable.Range(0,2).Select(_=>new Save()).ToList()}};Page=new(){Tag="page",savesManager=N("manager",1)==0?null:new(){Tag="manager",saveList=new(){saveList=Enumerable.Range(0,N("saved")).Select(_=>new Save()).ToList()}},playerSavePrefab=Row("prefab",true),playerListContent=new(){Tag="content",Value=new(){Tag="parent"}},playerSaveList=N("list",1)==0?null:InitialList};string? error=null;
   try{code.Invoke(null,[Page]);}catch(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;error=e.GetType().FullName;}
   var state=new{root=Page.playerSaveList==OtherList?"other":Page.playerSaveList==InitialList?"initial":"null",save_num=Page.saveNum,manager=Tag(Page.savesManager),content=Tag(Page.playerListContent),initial=ListState(InitialList),other=ListState(OtherList),created=Created.Select(x=>new{tag=x.Tag,id=x.playerSaveID,manager=Tag(x.savesManager),owner=Tag(x.savesUIController),parent=x.Value.Parent}).ToArray(),destroyed=Destroyed.Order().ToArray(),instantiate_calls=Calls};rows.Add(new{name=q.GetProperty("name").GetString(),token="0x060006A7",error,trace=Trace.ToArray(),state});
  }
  File.WriteAllText(args[3],JsonSerializer.Serialize(new{scope="COMPLETE_SAVE_UI_CANDIDATE_CIL_REAL_CLR_LISTS_CONTROLLED_UNITY_AND_START0",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),methods=1,results=rows,private_list_reflection_is_observation_only=true,eh_removed=false,private_access_bypass=false,unity_or_product_acceptance=false},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{records=rows.Count,methods=1}));
 }
}
