"""Authoring only: count concrete native-backed operations, not IL bytes."""
import collections,importlib.util,json,struct
import source_common as s
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
old=load('r20_append_only_writer',s.W/'startup-r19-batch100/construction.py');IL=old.IL
class Context(old.Context):
 def __init__(self):super().__init__();self.sites=[];self.site_keys=set();self.active=None;self.cfgs={}
 def begin(self,rid):
  self.active=s.tok(rid);self.cfgs[self.active]=s.save_native(rid);return TracedIL(self)
 def repair(self,b,va,kind,description,emit):
  assert kind in ['FIELD_READ','FIELD_WRITE','CALL','CONTROL_FLOW','LOOP_STATE','RETURN_VALUE'];key=(self.active,va);assert key not in self.site_keys,('Repeated native repair position',key)
  native=next(r for r in self.cfgs[self.active]['instructions'] if int(r['va'],16)==va)
  assert not(kind=='CALL' and native['operands'] in ['0x18024f360','0x18024fef0','0x1802501e0','0x180250150','0x180250140']),'Runtime scaffolding does not add repair count'
  start=len(b.b);emit(b);end=len(b.b);assert end>start;self.site_keys.add(key);self.sites.append(dict(method=self.active,native_va=hex(va),native_instruction=native,kind=kind,description=description,new_cil_start=start,new_cil_end=end,qualification='AUTHORED_UNTESTED'));return b
 def native_method(self,va):
  found=[int(t,16) for t,p in s.pointers.items() if p==va];assert len(found)==1,(hex(va),found);return found[0]
 def class_sig(self,owner):
  name=owner.rsplit('/',1)[-1].rsplit('.',1)[-1];found=[k for k,r in enumerate(s.pe.net.mdtables.TypeDef.rows,1) if str(r.TypeName)==name];assert len(found)==1,owner;return b'\x12'+old.labels.comp(found[0]<<2)
 def closed_generic(self,owner,name,arg):
  signature=b'\x0a\x01'+self.class_sig(arg)
  candidates=[]
  for k,r in enumerate(s.pe.net.mdtables.MethodSpec.rows,1):
   if r.Instantiation.value!=signature or r.Method.table.name!='MemberRef':continue
   m=r.Method.row
   if str(m.Name)!=name or m.Class.table.name!='TypeRef':continue
   t=m.Class.row;fullname=(str(t.TypeNamespace)+'.' if str(t.TypeNamespace) else '')+str(t.TypeName)
   if fullname==owner:candidates.append((0x2b000000|k,m.Signature.value.hex()))
  assert len(candidates)<=1,(owner,name,arg,candidates)
  if candidates:return candidates[0][0]
  # The lost body has no matching closed reference left in the image.
  # Reuse the exact existing generic T(T) declaration, append only MethodSpec.
  definitions=[]
  for k,m in enumerate(s.pe.net.mdtables.MemberRef.rows,1):
   if str(m.Name)!=name or m.Class.table.name!='TypeRef' or m.Signature.value!=bytes.fromhex('1001011e001e00'):continue
   t=m.Class.row;fullname=(str(t.TypeNamespace)+'.' if str(t.TypeNamespace) else '')+str(t.TypeName)
   if fullname==owner:definitions.append(k)
  assert len(definitions)==1,(owner,name,arg,definitions);coded=(definitions[0]<<1)|1;self.rows[43].append([coded,self.blob(signature)]);token=0x2b000000|len(self.rows[43]);self.new_specs.append(dict(token=hex(token),definition=hex(0xa000000|definitions[0]),argument=arg,signature=signature.hex()));return token
 def save_authored(self,stem):
  # R19's writer required a unique old RVA. These newly found stubs share
  # ret bodies with unrelated legitimate callbacks, so every target is
  # relocated and the entire original body region is kept byte-identical.
  out=bytearray(s.parent);pe=s.pe;last=pe.sections[-1];assert last.Name.rstrip(b'\0')==b'.n29meta' and last.Characteristics==0x40000040 and last.PointerToRawData+last.SizeOfRawData==len(out);changes=[]
  for token,v in sorted(self.bodies.items()):
   rid=int(token,16)&0xffffff;slot=s.body(token);md=pe.net.mdtables.MethodDef.rows[rid-1];m=s.methods[token];assert not m['handlers'],'Existing EH requires an explicit reconstruction';assert not v.get('new_eh')
   old_locals=int.from_bytes(s.parent[slot['offset']+8:slot['offset']+12],'little') if slot['header']==12 else 0;locals_=v['local_token'] or old_locals;start=old.writer.align(len(out),4);out.extend(b'\0'*(start-len(out)));newrva=last.VirtualAddress+start-last.PointerToRawData;stack=max(m['maxStack'],v['maxstack']);out.extend(struct.pack('<HHII',0x3013 if locals_ else 0x3003,stack,len(v['code']),locals_)+v['code']);self.rows[6][rid-1][0]=newrva
   changes.append(dict(token=token,name=m['name'],old_rva=hex(md.Rva),new_rva=hex(newrva),old_rva_alias_count=sum(r.Rva==md.Rva for r in pe.net.mdtables.MethodDef.rows),kind='APPENDED_TARGET_BODY_SHARED_OLD_SLOT_UNCHANGED',old_code_size=slot['code_size'],new_code_size=len(v['code']),old_maxstack=m['maxStack'],new_maxstack=stack,local_sig=hex(locals_),old_code_sha256=s.sha(slot['code']),new_code_sha256=s.sha(v['code']),new_code=v['code'].hex(),reason=v['reason'],group=v['group'],native_evidence_sha256=v['native_evidence_sha256'],qualification='AUTHORED_UNTESTED'))
  self.values['#~']=old.writer.tables_encode(self.th,self.rows,self.tail,self.counts);metadata=bytearray(self.root)
  for name,header,_ in self.streams:
   start=old.writer.align(len(metadata),4);metadata.extend(b'\0'*(start-len(metadata)));struct.pack_into('<II',metadata,header,start,len(self.values[name]));metadata.extend(self.values[name])
  start=old.writer.align(len(out),4);out.extend(b'\0'*(start-len(out)));out.extend(metadata);end=len(out);rawsize=old.writer.align(end-last.PointerToRawData,pe.OPTIONAL_HEADER.FileAlignment);out.extend(b'\0'*(last.PointerToRawData+rawsize-len(out)));sh=last.get_file_offset();opt=pe.OPTIONAL_HEADER.get_file_offset();updates={sh+8:end-last.PointerToRawData,sh+16:rawsize,opt+8:pe.OPTIONAL_HEADER.SizeOfInitializedData+rawsize-last.SizeOfRawData,opt+56:old.writer.align(last.VirtualAddress+end-last.PointerToRawData,pe.OPTIONAL_HEADER.SectionAlignment),opt+64:0,self.cli+8:last.VirtualAddress+start-last.PointerToRawData,self.cli+12:len(metadata)};allowed=set()
  for at,value in updates.items():struct.pack_into('<I',out,at,value);allowed.update(range(at,at+4))
  assert all(a==b or k in allowed for k,(a,b) in enumerate(zip(s.parent,out))),'Writer attempted to change an old body or unrelated prefix';path=s.Q/(stem+'.dll');assert not path.exists();path.write_bytes(out);p=s.Q/(stem+'.json');j=dict(parent_sha256=s.sha(s.parent),candidate_sha256=s.sha(out),bytes=len(out),new_unique_methods=len(changes),changes=changes,new_memberrefs=self.new_refs,new_local_signatures=self.new_sigs,new_methodspecs=self.new_specs,header_updates=updates,tests_run=False,qualified_methods=0,unity_or_ipa=False);keys={(r['method'],r['native_va']) for r in self.sites};assert len(keys)==len(self.sites)
  assert set(r['method'] for r in self.sites)==set(self.bodies)
  for row in self.sites:assert row['new_cil_end']<=len(self.bodies[row['method']]['code'])
  j.update(batch='R20',counting_unit='DISTINCT_NATIVE_BACKED_SEMANTIC_OPERATION_POSITIONS',new_unique_repair_positions=len(self.sites),distinct_changed_methods=len(self.bodies),shared_test_threshold=100,threshold_comparison='strictly_greater_than_100_positions',threshold_met=len(self.sites)>100,shared_tests_started=False,repair_sites=self.sites,repair_kind_counts=dict(collections.Counter(r['kind'] for r in self.sites)),not_a_count_of_independent_game_bugs=True)
  p.write_text(json.dumps(j,indent=2)+'\n',encoding='utf-8');(s.Q/'AUTHORING-PROGRESS.json').write_text(json.dumps({k:v for k,v in j.items() if k not in ['repair_sites','changes','header_updates']},indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(authored_positions=len(self.sites),changed_methods=len(self.bodies),threshold_met=len(self.sites)>100,shared_tests_started=False)))
class TracedIL(IL):
 def __init__(self,c):super().__init__();self.c=c
 def site(self,va,kind,description,emit):return self.c.repair(self,va,kind,description,emit)
