"""Bind unchanged shared-check algorithms only after 104 authored positions."""
from pathlib import Path
import hashlib,json
Q=Path(__file__).resolve().parent;W=Q.parent;sha=lambda b:hashlib.sha256(b).hexdigest();a=json.loads((Q/'authored1.json').read_bytes());gate=json.loads((Q/'SHARED-TEST-START.json').read_bytes());assert a['new_unique_repair_positions']==gate['repair_positions']==104 and a['distinct_changed_methods']==gate['distinct_methods']==8 and gate['repeat_identical'] and a['candidate_sha256']==gate['candidate_sha256']==sha((Q/'authored1.dll').read_bytes())
(Q/'ALL-METHODS.json').write_bytes((W/'startup-r19-batch100/ALL-METHODS.json').read_bytes())
rows=[]
for name in ['run_static.py','supplement_interface_facts.py','run_exact_jit.py','verify_isolation.py']:
 source=W/'startup-r19-batch100'/name;old=source.read_text(encoding='utf-8');new=old;edits=[]
 def replace(before,after):
  global new
  n=new.count(before);assert n>0,(name,before);new=new.replace(before,after);edits.append(dict(before=before,after=after,occurrences=n))
 if name=='run_static.py':replace("report['new_unique_methods']==100","report['new_unique_methods']==8 and report['new_unique_repair_positions']>100")
 elif name=='supplement_interface_facts.py':replace("Q=W/'startup-r19-batch100'/","Q=W/'startup-r20-sites100'/")
 elif name=='run_exact_jit.py':
  replace("report['new_unique_methods']==100","report['new_unique_methods']==8 and report['new_unique_repair_positions']>100");replace('EXACT_CANDIDATE_HUNDRED_JIT_PREPARATION','EXACT_CANDIDATE_EIGHT_METHOD_104_POSITION_JIT_PREPARATION')
 else:
  replace("W/'startup-r18-batch50/candidate1.dll'","W/'startup-r19-batch100/candidate9.dll'");replace('a6aa9f91087db194251c4c989fd80ffd982b3b7a59413b0745592bc43b548abb','0ba5bc7ec9603d14a1c0bde6d784d232aa78efaa1700304e75e4f2b56ef7dec2');replace("len(report['changes'])==100","len(report['changes'])==8 and report['new_unique_repair_positions']>100");replace('len(targets)==100','len(targets)==8');replace('changed_methods=100,unchanged_methoddefs=2217','changed_methods=8,unchanged_methoddefs=2309')
 dest=Q/name;assert not dest.exists();dest.write_text(new,encoding='utf-8');rows.append(dict(file=name,source=source.as_posix(),source_sha256=sha(source.read_bytes()),bound_sha256=sha(dest.read_bytes()),changes=edits,algorithm_changes=False))
(Q/'CHECK-DERIVATION.json').write_text(json.dumps(dict(candidate_sha256=a['candidate_sha256'],repair_positions=104,shared_tests_after_threshold=True,files=rows,frozen_checker_modified=False),indent=2)+'\n',encoding='utf-8');print('Prepared four input-bound checks after threshold=104; frozen checker unchanged')
