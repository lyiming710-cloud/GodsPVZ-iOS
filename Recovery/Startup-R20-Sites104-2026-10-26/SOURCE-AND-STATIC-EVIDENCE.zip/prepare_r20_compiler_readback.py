"""Bind the unchanged R19 compiler readback algorithm to R20 identities."""
from pathlib import Path
from archive_support import sha,js
W=Path(__file__).resolve().parent
source=W/'record_r19_compiler.py';target=W/'record_r20_compiler.py'
assert not target.exists()
text=source.read_text('utf-8');changes=[]
for before,after in [
 ('Startup-R19-Batch100-2026-10-25','Startup-R20-Sites104-2026-10-26'),
 ('startup-r19','startup-r20'),
 ('STARTUP-R19-BATCH100','STARTUP-R20-SITES104'),
 ('22342656','22777856'),
 ('EXACT_R19_CANDIDATE','EXACT_R20_CANDIDATE')]:
    assert before in text
    changes.append(dict(before=before,after=after,occurrences=text.count(before)))
    text=text.replace(before,after)
target.write_bytes(text.encode())
js(W/'startup-r20-sites100/COMPILER-READBACK-DERIVATION.json',dict(
    parent_file=source.name,parent_sha256=sha(source.read_bytes()),
    derived_file=target.name,derived_sha256=sha(target.read_bytes()),changes=changes,
    all_source_hash_log_diagnostics_and_control_assertions_preserved=True))
