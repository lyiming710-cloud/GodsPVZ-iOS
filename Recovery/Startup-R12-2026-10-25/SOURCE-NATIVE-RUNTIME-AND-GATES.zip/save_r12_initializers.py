from pathlib import Path
import json
from archive_support import sha,js,pack,variants,manifest
W=Path(__file__).resolve().parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113';Q=W/'startup-r12';D=R/'Recovery/Startup-R12-2026-10-25';D.mkdir(exist_ok=True)
data=(Q/'candidate1.dll').read_bytes();digest=sha(data);assert digest=='28946ce7343a4ca7479fb1a3aeb6b191bcc74aae5292a8b0a18f06c5019e1bd5' and data==(Q/'candidate2.dll').read_bytes()
ind=json.loads((Q/'ISOLATION-AND-INDEPENDENT.json').read_bytes());runtime=json.loads((Q/'runtime-results/RESULT.json').read_bytes());types=json.loads((Q/'FROZEN-WITH-INTERFACE-FACTS.json').read_bytes());members=json.loads((Q/'MEMBER-ACCESS-ALL-2297.json').read_bytes());bad=[r for r in types['results'] if r['status']!='PASS'];access=[r for r in members['members'] if not r['allowed']]
assert ind['pass_'] and runtime['pass_'] and runtime['cases']==90 and len(bad)==128 and len(access)==145 and members['unresolved']==0
assert runtime['frozen_width_control']['rejected_methods']==3 and not runtime['runtime_alone_adequate']
js(Q/'REMAINING-QUEUES.json',dict(scope='OVERLAPPING_GATE_QUEUES_NOT_GAME_BUG_COUNT',candidate_sha256=digest,type_fail_or_unsupported=128,member_rejected_sites=145,member_rejected_methods=70,union_methods=len({r['token'] for r in bad+access}),type_rows=bad,access_rows=access,whole_assembly_pass=False))
js(Q/'PHYSICAL-VARIANTS.json',dict(variants=variants(Q,data)))
(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text whitespace=cr-at-eol\n*.md -text\n*.zip -text\n')
for name in ['CONSTRUCTION.json','ISOLATION-AND-INDEPENDENT.json','FROZEN-THREE.json','REMAINING-QUEUES.json','LEXICAL-TAIL-CENSUS.json','DRIVER-DERIVATION.json']:(D/name).write_bytes((Q/name).read_bytes())
(D/'RUNTIME-RESULT.json').write_bytes((Q/'runtime-results/RESULT.json').read_bytes())
pack(D/'STARTUP-R12-CANDIDATE.zip',[('STARTUP-R12.dll',data)])
items=[]
for p in sorted(Q.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(Q)
    if any(x in ['obj','__pycache__'] for x in rel.parts):continue
    if p.suffix=='.dll' and 'bin' not in rel.parts:continue
    if p.suffix=='.exe' or p.name=='Mono.Cecil.dll':continue
    items.append((p.relative_to(W).as_posix(),p.read_bytes()))
for p in [Path(__file__),W/'archive_support.py',W/'startup-r5/native_runtime_common.py',W/'startup-r5/runtime-common/Rehost.cs',W/'startup-r12/runtime/bin/Release/net10.0/Mono.Cecil.dll']:items.append((p.relative_to(W).as_posix(),p.read_bytes()))
for p in [ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py',ROOT/'audit/native111-publication-2026-10-20/repository/scripts/actions/static_gates.py']:items.append(('required-tools/'+p.name,p.read_bytes()))
pack(D/'SOURCE-NATIVE-RUNTIME-AND-GATES.zip',items)
js(D/'CURRENT-RESULT.json',dict(status='THREE_NATIVE_INITIALIZER_TRAMPOLINES_RECOVERED_WIDER_GATES_HELD',candidate_sha256=digest,parent_sha256='e101c701802969bffe370841abc92cd01ec75592097d60b2b9e3629c5c107637',bytes=len(data),changed_methods=3,unchanged_methoddefs=2314,entire_metadata_headers_rvas_locals_maxstack_unchanged=True,
    actual_native_caller_cases=90,actual_native_caller_instructions=9,real_load_callee_implementations=False,prior_13_caller_scopes='Last rerun on exact R11: 5583 records; all those caller bodies and metadata remain byte-identical here; not rerun on R12',r11_isolated_operation_cases=532,changed_three_actual_jit='3/3 PREPARED_NO_EXECUTION',
    frozen_raw=dict(pass_=2141,fail_or_unsupported=156),frozen_with_interface_facts=dict(pass_=2169,fail_or_unsupported=128),member_access=dict(rejected_sites=145,rejected_methods=70,unresolved=0,actual_exit=2),unterminated_lexical_tails=0,
    r12_il2cpp='NOT_RUN',r12_unity='NOT_RUN',r12_apple='NOT_RUN',parent_r11_linux_run=40121851208,ancestor_r10_apple_run=40121853897,full_player_export_held=True,ipa=None,ipad_acceptance=False))
(D/'README.md').write_bytes('''# Startup R12: three native initializer trampoline Int32 sentinels

Candidate `28946ce7343a4ca7479fb1a3aeb6b191bcc74aae5292a8b0a18f06c5019e1bd5` (19,731,968 bytes), directly based on R11 `e101c701…c107637`. Exactly three methods change: System0.Start0 (`0x06000064`), System1.Start1 (`0x0600007C`) and System3.Start3 (`0x0600009A`). Each replaces the invalid I8 4294967295 with I4 -1 and four NOPs in its existing nine-byte slot. All metadata, headers, RVAs, CodeSize, locals, MaxStack, branch/EH offsets and the other 2,314 MethodDefs remain identical. Construction is reproducible and separate independent raw/CIL/native binding verifies the full file, including a physical unrelated-code rejection control.

## Exact original specification

The original PC functions at 0x18030A020, 0x18030AF30 and 0x18030D710 each have exactly three instructions: clear R8D (null hidden MethodInfo), load EDX=FFFFFFFF (Int32 -1), and tail-jump to the loader. Each actual tail address is independently matched through the original PC method-pointer table to the existing CIL callee: LoadPlantData (`0x06000073` -> 0x180308BD0), LoadZombieInfo (`0x06000081` -> 0x18030A600), LoadSuppliesInfo (`0x0600009E` -> 0x18030D140). No loader body is changed or guessed.

Original native bytes execute against controlled loader callbacks and all actual candidate CIL instructions execute in concrete CLR methods. All 90 records match across null/non-null receiver identities, Int32 boundary states and mutating callbacks. Native callback asserts hidden MethodInfo is null; original caller bytes are rechecked after hook setup. Real loader internals, native exception unwind, Unity and full gameplay are outside scope. This proves the three caller trampolines under those explicit callee contracts.

Physical wrong-zero and early-return faults each produce 90 differing records. Restoring all three original I8 faults yields exactly the R11 DLL and zero runtime differences on this permissive CLR. The unchanged frozen type checker independently rejects all three physical bad-width methods. Both the non-detection and rejection are retained; execution alone is insufficient. All three actual repaired methods also prepare under CLR JIT.

## Current whole-assembly state and compiler boundaries

Fresh type checking covers all 2,297 bodies: 2,141 PASS/156 FAIL_OR_UNSUPPORTED raw, or 2,169 PASS/128 FAIL_OR_UNSUPPORTED after exact nongeneric InterfaceImpl facts. This does not turn unsupported operations into proven game defects or proven correct behavior. The unchanged visibility auditor exits 2 with 145 rejected sites across 70 methods and zero unresolved members. Zero unterminated lexical tails remain. Detailed overlapping queues are archived; they are not an additive gameplay bug count.

The prior 13 controlled caller scopes were last rerun on exact R11 with 5,583 matching records; R11 also has 532 isolated pure-operation cases. Those 13 caller bodies and all metadata are unchanged in R12, but no rerun of those records on this exact R12 DLL is claimed. They are kept separate from R12's 90 new records. A fresh whole-assembly JIT run is not claimed; the three changed methods are directly checked.

R11 separately passed fresh IL2CPP and 756 C++/274 C Linux checks at run 40121851208. R10 separately passed physical Apple arm64 syntax checks on all 1,030 generated sources at run 40121853897. There are 17 source-file differences between the generated R10 and R11 trees, so the R10 Apple result is not silently applied to R11 or R12. R12 has no fresh IL2CPP, Unity export, Apple compilation, link, IPA or iPad acceptance. Wider type/access and gameplay scopes keep full player promotion held.

## Reproduction

Use the exact R11 parent and fresh paths for construct_and_static.py; build runtime/Fixture.csproj, run run_runtime.py, then verify_independent.py to complete the frozen-width countercontrol and raw proof. Whole-driver source hashes are recorded in DRIVER-DERIVATION. Native execution requires Windows x64 and immutable original GameAssembly SHA `9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d`. Existing authentic support, pinned frozen checker/Cecil exporter/access auditor and .NET/Cecil dependencies are required as in R11. The ZIP is an evidence/source bundle rather than a full SDK distribution; per-member and top-level SHA manifests are verified.
'''.encode());manifest(D);print(json.dumps(dict(checkpoint=str(D),candidate_sha256=digest,scoped_cases=90,remaining_type_or_unsupported=128,remaining_access_sites=145,archives={p.name:p.stat().st_size for p in D.glob('*.zip')})))
