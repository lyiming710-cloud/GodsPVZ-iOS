from pathlib import Path
import hashlib,json,subprocess
Q=Path(__file__).resolve().parent;ROOT=Q.parents[2];exe=ROOT/'.local/dotnet10/dotnet.exe';tool=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/member-bin/MemberAccess.dll'
assert hashlib.sha256(tool.read_bytes()).hexdigest()=='d21ae9d0b39cbadc7c0412c87f41942e86d7eff25b22212c2c64cdd1fc4833db'
candidate=Q/'candidate1.dll';assert hashlib.sha256(candidate.read_bytes()).hexdigest()=='28946ce7343a4ca7479fb1a3aeb6b191bcc74aae5292a8b0a18f06c5019e1bd5'
p=subprocess.run([str(exe),str(tool),str(candidate),str(ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'),str(Q/'ALL-METHODS.json'),str(Q/'MEMBER-ACCESS-ALL-2297.json')],capture_output=True)
(Q/'all-member.stdout.log').write_bytes(p.stdout);(Q/'all-member.stderr.log').write_bytes(p.stderr)
(Q/'all-member-exit.json').write_text(json.dumps(dict(exit_code=p.returncode,zero_expected_only_if_all_allowed=True),indent=2)+'\n');print(p.stdout.decode());print('Actual audit exit',p.returncode)
assert p.returncode in (0,2)
raise SystemExit(p.returncode)
