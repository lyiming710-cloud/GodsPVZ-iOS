"""Three complete native initializer trampolines; exact I4 sentinel recovery.

All three original functions are XOR R8D,R8D; MOV EDX,FFFFFFFF; JMP target.
The target is independently bound to the actual existing CIL callee MethodDef.
"""
from pathlib import Path
import hashlib,importlib.util,json,struct,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile,pefile
sha=lambda b:hashlib.sha256(b).hexdigest();before=(W/'startup-r11/candidate1.dll').read_bytes();assert sha(before)=='e101c701802969bffe370841abc92cd01ec75592097d60b2b9e3629c5c107637'
native_bytes=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/GameAssembly.dll').read_bytes();assert sha(native_bytes)=='9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d'
pe=dnfile.dnPE(data=before);pc=pefile.PE(data=native_bytes);base=pc.OPTIONAL_HEADER.ImageBase;out=bytearray(before);sites=[];allowed=set()
def pointer(rid):return int.from_bytes(pc.get_data(0x181b82d60-base+(rid-1)*8,8),'little')
for rid,method in [(0x64,'Start0'),(0x7c,'Start1'),(0x9a,'Start3')]:
    row=pe.net.mdtables.MethodDef.rows[rid-1];assert str(row.Name)==method;at=pe.get_offset_from_rva(row.Rva);head=1 if before[at]&3==2 else (struct.unpack_from('<H',before,at)[0]>>12)*4;size=before[at]>>2 if head==1 else struct.unpack_from('<I',before,at+4)[0]
    code=before[at+head:at+head+size];assert size==16 and code[:10]==b'\x02\x21'+struct.pack('<q',4294967295) and code[10]==0x28 and code[-1]==0x2a
    callee=int.from_bytes(code[11:15],'little');assert callee>>24==6;callee_rid=callee&0xffffff;target=pointer(callee_rid);entry=pointer(rid);native=pc.get_data(entry-base,13)
    assert native[:8]==bytes.fromhex('4533c0baffffffff') and native[8]==0xe9 and entry+13+struct.unpack_from('<i',native,9)[0]==target
    assert len({r.Rva for r in pe.net.mdtables.MethodDef.rows if r.Rva==row.Rva})==1 and sum(r.Rva==row.Rva for r in pe.net.mdtables.MethodDef.rows)==1
    change=b'\x20'+struct.pack('<i',-1)+b'\0'*4;offset=at+head+1;out[offset:offset+9]=change;allowed.update(range(offset,offset+9))
    sites.append(dict(token=f'0x{0x6000000|rid:08X}',method=method,file_offset=offset,old=code[1:10].hex(),new=change.hex(),native_entry=hex(entry),native_bytes=native.hex(),callee_token=f'0x{callee:08X}',callee_name=str(pe.net.mdtables.MethodDef.rows[callee_rid-1].Name),native_callee=hex(target),native_hidden_method_info='NULL',sentinel=-1))
assert len(out)==len(before) and all(a==b or i in allowed for i,(a,b) in enumerate(zip(before,out)))
for n in [1,2]:p=Q/f'candidate{n}.dll';assert not p.exists();p.write_bytes(out)
report=dict(scope='THREE_ORIGINAL_THREE_INSTRUCTION_TRAMPOLINES_LITERAL_WIDTH_ONLY',parent_sha256=sha(before),candidate_sha256=sha(out),bytes=len(out),sites=sites,untouched_methoddefs=2314,metadata_headers_rvas_locals_maxstack_branch_eh_unchanged=True,runtime_equivalence='PENDING',unity_or_ipa=False)
(Q/'CONSTRUCTION.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());(Q/'METHODS.json').write_text(json.dumps(dict(methods=[dict(token=r['token']) for r in sites]),indent=2)+'\n')
dot=ROOT/'.local/dotnet10/dotnet.exe';export=ROOT/'audit/bulk250-r1-evidence-39702928368/bulk250-r1-run/tools_bin/CilExporter/bin/CilExporter.dll';sup=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'
p=subprocess.run([str(dot),str(export),str(Q/'candidate1.dll'),str(Q/'METHOD-CIL.json'),str(sup),','.join(r['token'] for r in sites)],capture_output=True);(Q/'cil-export.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0
checker=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py';assert sha(checker.read_bytes())=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14'
s=importlib.util.spec_from_file_location('frozen',checker);v=importlib.util.module_from_spec(s);s.loader.exec_module(v);c=json.loads((Q/'METHOD-CIL.json').read_text('utf-8-sig'));results=[v.verify(m,c['types']) for m in c['methods']];assert all(r['status']=='PASS' for r in results)
(Q/'FROZEN-THREE.json').write_text(json.dumps(dict(candidate_sha256=sha(out),scope='UNCHANGED_FROZEN_TYPE_ONLY',results=results),indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='sites'},indent=2))
