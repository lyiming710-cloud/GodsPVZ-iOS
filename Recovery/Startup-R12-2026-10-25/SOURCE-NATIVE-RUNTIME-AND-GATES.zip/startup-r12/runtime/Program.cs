using System.Reflection;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public sealed class State(int id,int value)
{
    public int Id=id,Value=value;
    public void LoadPlantData(int n)=>Program.Handle(this,nameof(LoadPlantData),n);
    public void LoadZombieInfo(int n)=>Program.Handle(this,nameof(LoadZombieInfo),n);
    public void LoadSuppliesInfo(int n)=>Program.Handle(this,nameof(LoadSuppliesInfo),n);
}
public sealed class Case{public string name{get;set;}="";public string token{get;set;}="";public int id{get;set;}=1;public int value{get;set;}=0;public string mode{get;set;}="none";}
public static class Program
{
    public static List<string> Trace=[];public static Case Current=new();
    public static void Handle(State? s,string name,int n){Trace.Add(name+":"+(s?.Id.ToString()??"null")+":"+n);if(s!=null&&Current.mode=="mutate")s.Value=unchecked(s.Value+17);}
    static Type Map(MC.TypeReference t)=>t.FullName switch{"System.Void"=>typeof(void),"System.Int32"=>typeof(int),"System0" or "System1" or "System3"=>typeof(State),_=>throw new NotSupportedException(t.FullName)};
    public static void Main(string[] args)
    {
        using var module=MC.ModuleDefinition.ReadModule(args[0]);var delegates=new Dictionary<string,Action<State>>();
        foreach(int token in new[]{0x06000064,0x0600007C,0x0600009A}){var source=(MC.MethodDefinition)module.LookupToken(token);delegates["0x"+token.ToString("X8")]=ActualCil.Emit(source,Map,f=>throw new NotSupportedException(f.FullName),m=>typeof(State).GetMethod(m.Name)!).CreateDelegate<Action<State>>();}
        var rows=new List<object>();foreach(var c in JsonSerializer.Deserialize<List<Case>>(File.ReadAllText(args[1]))!){Current=c;Trace=[];State? s=c.id==0?null:new(c.id,c.value);string? error=null;try{delegates[c.token](s!);}catch(Exception e){error=e.GetType().FullName;}rows.Add(new{name=c.name,trace=Trace.ToArray(),value=s?.Value,error});}
        File.WriteAllText(args[2],JsonSerializer.Serialize(new{scope="COMPLETE_ACTUAL_CANDIDATE_INITIALIZER_CIL_CONTROLLED_LOAD_CALLEES",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),all_source_instructions_emitted=true,real_load_implementation=false,unity_execution=false,results=rows},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine("Executed "+rows.Count+" cases");
    }
}
