"""Independently bind three raw CIL trampolines to immutable native encodings.

No constructor plan/offset map is read. Entire-file equality is required outside
the three actual immediate slots; every original MethodDef raw body is compared.
"""
from pathlib import Path
import hashlib,importlib.util,json,struct,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile,pefile
sha=lambda b:hashlib.sha256(b).hexdigest()
def mod(name,path):s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
reader=mod('raw_reader',ROOT/'audit/native111-publication-2026-10-20/repository/scripts/actions/static_gates.py')
a=(W/'startup-r11/candidate1.dll').read_bytes();b=(Q/'candidate1.dll').read_bytes();assert sha(a)=='e101c701802969bffe370841abc92cd01ec75592097d60b2b9e3629c5c107637' and sha(b)=='28946ce7343a4ca7479fb1a3aeb6b191bcc74aae5292a8b0a18f06c5019e1bd5' and b==(Q/'candidate2.dll').read_bytes()
pp=dnfile.dnPE(data=a);cp=dnfile.dnPE(data=b);targets={0x64,0x7c,0x9a};allowed=set();rows=[]
pcraw=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/GameAssembly.dll').read_bytes();assert sha(pcraw)=='9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d';pc=pefile.PE(data=pcraw);base=pc.OPTIONAL_HEADER.ImageBase
for rid,(old,new) in enumerate(zip(pp.net.mdtables.MethodDef.rows,cp.net.mdtables.MethodDef.rows),1):
    assert old.Rva==new.Rva
    if not old.Rva:continue
    at=pp.get_offset_from_rva(old.Rva);span=reader.parse_raw_method_body_span(a,at)[0];assert span==reader.parse_raw_method_body_span(b,at)[0]
    if rid not in targets:assert a[at:at+span]==b[at:at+span];continue
    header=1 if b[at]&3==2 else (struct.unpack_from('<H',b,at)[0]>>12)*4;code=b[at+header:at+span];oldcode=a[at+header:at+span];assert len(code)==16 and b[at:at+header]==a[at:at+header]
    assert oldcode==b'\x02\x21'+struct.pack('<q',4294967295)+code[10:] and code[:10]==bytes.fromhex('0220ffffffff00000000') and code[10]==0x28 and code[-1]==0x2a
    call=int.from_bytes(code[11:15],'little');entry=int.from_bytes(pc.get_data(0x181b82d60-base+(rid-1)*8,8),'little');target=int.from_bytes(pc.get_data(0x181b82d60-base+((call&0xffffff)-1)*8,8),'little');machine=pc.get_data(entry-base,13)
    assert machine[:8]==bytes.fromhex('4533c0baffffffff') and machine[8]==0xe9 and entry+13+struct.unpack_from('<i',machine,9)[0]==target
    allowed.update(range(at+header+1,at+header+10));rows.append(dict(token=f'0x{0x6000000|rid:08X}',callee_token=f'0x{call:08X}',native_entry=hex(entry),native_callee=hex(target),code_size=16,original_native_bytes=machine.hex()))
def boundary(data):
    if len(data)!=len(a) or any(x!=y and i not in allowed for i,(x,y) in enumerate(zip(a,data))):raise ValueError('Unrelated file change')
boundary(b);m=bytearray(b);p=pp.get_offset_from_rva(pp.net.mdtables.MethodDef.rows[0x526-1].Rva)+12;m[p]^=1
try:boundary(m);raise AssertionError('Isolation false accept')
except ValueError:pass
dot=ROOT/'.local/dotnet10/dotnet.exe';exp=ROOT/'audit/bulk250-r1-evidence-39702928368/bulk250-r1-run/tools_bin/CilExporter/bin/CilExporter.dll';sup=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support';probe=W/'startup-r5/jit-probe/bin/Release/net10.0/Probe.dll'
f=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py';assert sha(f.read_bytes())=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14';checker=mod('frozen',f)
def run(args,log):
    p=subprocess.run([str(x) for x in args],capture_output=True);(Q/log).write_bytes(p.stdout+p.stderr);assert p.returncode==0
run([dot,exp,Q/'runtime-results/original-int64-width.dll',Q/'INT64-CONTROL-CIL.json',sup,','.join(r['token'] for r in rows)],'negative-export.log');c=json.loads((Q/'INT64-CONTROL-CIL.json').read_text('utf-8-sig'));failures=[]
for method in c['methods']:
    try:r=checker.verify(method,c['types'])
    except Exception as e:r=dict(token=method['token'],status='FAIL',error=str(e))
    assert r['status']!='PASS' and 'I8' in r['error'];failures.append(r)
runtime=json.loads((Q/'runtime-results/RESULT.json').read_bytes());assert runtime['pass_'] and runtime['cases']==90;control=next(r for r in runtime['controls'] if r['name']=='original-int64-width');assert control['runtime_differences']==0 and control['mutant_sha256']==sha(a)
runtime['runtime_alone_adequate']=False;runtime['frozen_width_control']=dict(rejected_methods=3,checker_sha256=sha(f.read_bytes()),results=failures);(Q/'runtime-results/RESULT.json').write_bytes((json.dumps(runtime,indent=2)+'\n').encode())
jits=[]
for r in rows:
    output=Q/('JIT-'+r['token']+'.json');run([dot,probe,Q/'candidate1.dll',sup,r['token'],output],'jit-'+r['token']+'.log');jit=json.loads(output.read_bytes());assert jit['status']=='JIT_PREPARED_NO_EXECUTION' and jit['input_sha256']==sha(b);jits.append(jit)
result=dict(scope='INDEPENDENT_NATIVE_POINTER_RAW_FILE_AND_FROZEN_WIDTH_BINDING',candidate_sha256=sha(b),pass_=True,changed_methods=3,unchanged_methoddefs=2314,entire_metadata_and_headers_unchanged=True,entire_file_outside_three_nine_byte_slots_unchanged=True,rows=rows,jit=jits,negative_isolation_control_rejected=True,int64_runtime_undetected_but_frozen_rejected=failures,actual_unity_or_ipa=False)
(Q/'ISOLATION-AND-INDEPENDENT.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in result.items() if k not in ['jit','int64_runtime_undetected_but_frozen_rejected']},indent=2))
