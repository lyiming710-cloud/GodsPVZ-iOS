from pathlib import Path
import ctypes as C,json,sys
Q=Path(__file__).resolve().parent;W=Q.parent;sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
im=NativeImage();proof=json.loads((Q/'CONSTRUCTION.json').read_bytes());cases=json.loads(Path(sys.argv[1]).read_bytes());state={};rows=[]
try:
    for site in proof['sites']:
        entry=int(site['native_entry'],16);rid=int(site['token'],16)&0xffffff;assert int.from_bytes(im.pe.get_data(0x181b82d60-im.base+(rid-1)*8,8),'little')==entry;assert C.string_at(entry,13)==bytes.fromhex(site['native_bytes'])
        rid=int(site['callee_token'],16)&0xffffff;target=int(site['native_callee'],16);assert int.from_bytes(im.pe.get_data(0x181b82d60-im.base+(rid-1)*8,8),'little')==target
        def call(p,n,method,name=site['callee_name']):
            assert not method,'Original XOR R8D,R8D must pass null MethodInfo';state['trace'].append(name+':'+(str(get32(p+0x10)) if p else 'null')+':'+str(n))
            if p and state['case']['mode']=='mutate':put32(p+0x14,C.c_int32(get32(p+0x14)+17).value)
        im.hook(target,None,[P,I,P],call)
    for site in proof['sites']:assert C.string_at(int(site['native_entry'],16),13)==bytes.fromhex(site['native_bytes'])
    sites={r['token']:r for r in proof['sites']}
    for case in cases:
        state.clear();state.update(case=case,trace=[]);p=im.alloc(64) if case['id'] else 0
        if p:put32(p+0x10,case['id']);put32(p+0x14,case['value'])
        C.CFUNCTYPE(None,P,P)(int(sites[case['token']]['native_entry'],16))(p,None);assert not im.errors,im.errors
        rows.append(dict(name=case['name'],trace=list(state['trace']),value=get32(p+0x14) if p else None,error=None))
    Path(sys.argv[2]).write_bytes((json.dumps(dict(scope='THREE_ORIGINAL_PC_TRAMPOLINES_CONTROLLED_LOADS',original_sha256=PC_SHA,original_caller_instructions=9,original_bytes_preserved=True,callback_errors=im.errors,real_load_implementation=False,native_unwind=False,results=rows),indent=2)+'\n').encode())
finally:im.close()
