from pathlib import Path
import hashlib,itertools,json,struct,subprocess,sys
Q=Path(__file__).resolve().parent;ROOT=Q.parents[2];O=Q/'runtime-results';O.mkdir(exist_ok=True)
proof=json.loads((Q/'CONSTRUCTION.json').read_bytes());candidate=Q/'candidate1.dll';raw=candidate.read_bytes();assert hashlib.sha256(raw).hexdigest()==proof['candidate_sha256']
cases=[dict(name='case-'+str(k),token=t,id=i,value=v,mode=m) for k,(t,i,v,m) in enumerate(itertools.product([r['token'] for r in proof['sites']],[0,1,2],[-2147483648,-1,0,1,2147483647],['none','mutate']))];assert len(cases)==90
(O/'CASES.json').write_bytes((json.dumps(cases,indent=2)+'\n').encode());dot=ROOT/'.local/dotnet10/dotnet.exe';fixture=Q/'runtime/bin/Release/net10.0/Fixture.dll'
def run(name,args):
    p=subprocess.run([str(x) for x in args],capture_output=True,timeout=60);(O/(name+'.stdout.log')).write_bytes(p.stdout);(O/(name+'.stderr.log')).write_bytes(p.stderr);assert p.returncode==0,(name,p.returncode,p.stderr[-800:])
run('native',[sys.executable,Q/'native_oracle.py',O/'CASES.json',O/'NATIVE.json']);run('actual-cil',[dot,fixture,candidate,O/'CASES.json',O/'ACTUAL-CIL.json'])
native=json.loads((O/'NATIVE.json').read_bytes())['results'];actual=json.loads((O/'ACTUAL-CIL.json').read_bytes())['results'];assert native==actual
controls=[]
for mode in ['wrong-zero-sentinel','early-return','original-int64-width']:
    b=bytearray(raw)
    for site in proof['sites']:
        at=site['file_offset']
        if mode=='wrong-zero-sentinel':b[at+1:at+5]=struct.pack('<i',0)
        elif mode=='early-return':assert b[at-1]==2;b[at-1]=0x2a
        else:b[at:at+9]=bytes.fromhex(site['old'])
    dll=O/(mode+'.dll');dll.write_bytes(b);run(mode,[dot,fixture,dll,O/'CASES.json',O/(mode+'.json')]);rows=json.loads((O/(mode+'.json')).read_bytes())['results'];detected=sum(x!=y for x,y in zip(native,rows))
    if mode!='original-int64-width':assert detected==90
    controls.append(dict(name=mode,mutant_sha256=hashlib.sha256(b).hexdigest(),runtime_differences=detected,requires_frozen_width_gate=mode=='original-int64-width'))
report=dict(scope='THREE_COMPLETE_NATIVE_TRAMPOLINES_VS_COMPLETE_ACTUAL_CIL_WITH_CONTROLLED_LOAD_CALLEES',candidate_sha256=proof['candidate_sha256'],cases=90,pass_=True,differences=0,controls=controls,hidden_native_method_info_null_verified=True,callee_load_behavior_not_recovered_here=True,native_exception_unwind=False,unity_or_ipa=False)
(O/'RESULT.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(report,indent=2))
