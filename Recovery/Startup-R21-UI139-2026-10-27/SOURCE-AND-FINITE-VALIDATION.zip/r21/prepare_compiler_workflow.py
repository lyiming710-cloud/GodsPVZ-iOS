"""Scope-bind the existing compiler census without changing its algorithm."""
from pathlib import Path
import hashlib,json
Q=Path(__file__).resolve().parent;W=Q.parent;R=W.parents[1]/'audit/repo-native113';changes=[]
for old,new in [('scripts/actions/check_startup_r20_compiler.py','scripts/actions/check_startup_r21_compiler.py'),('.github/workflows/startup-r20-compiler-check.yml','.github/workflows/startup-r21-compiler-check.yml')]:
 p=R/old;text=p.read_text('utf-8');bound=text
 for a,b in [('Startup-R20-Sites104-2026-10-26','Startup-R21-UI139-2026-10-27'),('STARTUP-R20-SITES104','STARTUP-R21-UI139'),('d887b370c95c2966dc40d80648d85c286bb42d85004c32d095f64f004e095b37','75160a3233f1e1ab13a44f712efb4b47fdeb9b57bd38fa25f180276bb7b50e15'),('R20 Sites104','R21 UI139'),('R20-Sites104','R21-UI139'),('STARTUP_R20','STARTUP_R21'),('startup-r20','startup-r21'),('check_startup_r20_compiler','check_startup_r21_compiler')]:bound=bound.replace(a,b)
 target=R/new;assert not target.exists();target.write_bytes(bound.encode());changes.append(dict(source=old,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bound=new,bound_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),compiler_algorithm_changed=False))
(Q/'COMPILER-WORKFLOW-DERIVATION.json').write_text(json.dumps(changes,indent=2)+'\n',encoding='utf-8');print('Derived exact R21 compiler workflow; no relaxed checks')
