"""Archive constructed R21 and finite observations without promoting game acceptance."""
from pathlib import Path
import hashlib,json,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113';sys.path.insert(0,str(W))
from archive_support import js,pack,manifest,variants,sha
D=R/'Recovery/Startup-R21-UI139-2026-10-27';assert not D.exists();D.mkdir();S=Q/'shared-authored1'
candidate=(Q/'authored1.dll').read_bytes();h=sha(candidate);assert h=='75160a3233f1e1ab13a44f712efb4b47fdeb9b57bd38fa25f180276bb7b50e15' and (Q/'authored2.dll').read_bytes()==candidate
construction=json.loads((Q/'authored1.json').read_bytes());assert construction['new_unique_methods']==7 and construction['new_unique_repair_positions']==139
for name,count in [('BUTTON-NATIVE-COMPARE.json',300),('AUDIO-NATIVE-COMPARE.json',44)]:
 j=json.loads((Q/name).read_bytes());assert j['candidate_sha256']==h and j['records']==count and not j['differences'] and not j['callback_errors']
controls=json.loads((Q/'PHYSICAL-CONTROLS.json').read_bytes());assert controls['controls']==controls['rejected']==15
(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text\n*.md -text\n*.zip -text\n*.py -text\n*.cs -text\n*.yml -text\n')
pack(D/'STARTUP-R21-UI139-CANDIDATE.zip',[('STARTUP-R21-UI139.dll',candidate)])
names={'CONSTRUCTION.json':Q/'authored1.json','SHARED-TEST-START.json':Q/'SHARED-TEST-START.json','ISOLATION.json':S/'ISOLATION.json','FROZEN-WITH-INTERFACE-FACTS.json':S/'FROZEN-WITH-INTERFACE-FACTS.json','MEMBER-EXIT.json':S/'MEMBER-EXIT.json','EXACT-JIT.json':S/'jit/RESULT.json','BUTTON-NATIVE-COMPARE.json':Q/'BUTTON-NATIVE-COMPARE.json','AUDIO-NATIVE-COMPARE.json':Q/'AUDIO-NATIVE-COMPARE.json','PHYSICAL-CONTROLS.json':Q/'PHYSICAL-CONTROLS.json','PARENT-BATCH-POLICY.json':Q/'PARENT-BATCH-POLICY.json'}
for name,p in names.items():(D/name).write_bytes(p.read_bytes())
js(Q/'PHYSICAL-CONTROL-DELTAS.json',variants(Q/'physical-controls',candidate))
source=[]
for p in sorted(Q.rglob('*')):
 if not p.is_file() or any(x in p.parts for x in ['bin','obj','__pycache__']):continue
 if p.name in ['authored1.dll','authored2.dll'] or p.suffix=='.dll':continue
 if p==Q/'archive_checkpoint.py':continue
 source.append(('r21/'+p.relative_to(Q).as_posix(),p.read_bytes()))
source += [('frozen/Rehost.cs',(W/'startup-r5/runtime-common/Rehost.cs').read_bytes()),('frozen/native_runtime_common.py',(W/'startup-r5/native_runtime_common.py').read_bytes()),('frozen/verify_types_reviewed.py',(ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py').read_bytes()),('frozen/Mono.Cecil.dll',(ROOT/'audit/bulk400-generic-repair-2026-10-24/runtime/Mono.Cecil.dll').read_bytes()),('r21/archive_checkpoint.py',Path(__file__).read_bytes())]
pack(D/'SOURCE-AND-FINITE-VALIDATION.zip',source)
js(D/'PROGRESS.json',dict(status='CONSTRUCTED_STATIC_AND_FINITE_CALLER_CHECKS_PASS_COMPILER_AND_REAL_UI_PENDING',parent_sha256=construction['parent_sha256'],candidate_sha256=h,bytes=len(candidate),authored_positions=139,changed_methods=7,omitted_audio_loads_restored=115,button_repairs=24,finite_normal_records=344,physical_negative_controls=15,unchanged_methoddefs=2310,whole_type_counts={'PASS':2227,'FAIL_OR_UNSUPPORTED':70},qualified_methods=0,whole_game_accepted=False,ipad_acceptance=False,unity_interaction='NOT_RUN_FOR_R21',fresh_il2cpp_compiler='NOT_RUN_FOR_R21',apple_compiler='NOT_RUN_FOR_R21',ipa=None,remaining_root_diagnosis=['ZombieHome.Awake null receiver identity','Actual plant-detail route after adding missing OpenPlantHome diagnostic step','Board terrain-only state and actual device touch'],r20_failed_run=40301285361))
(D/'README.md').write_bytes('''# R21：音效完整注册与按钮颜色/状态恢复（139处，7方法）

本批针对用户R20设备反馈：选植物/确认无效、关卡菜单失效、图鉴显示异常。实际R20 Editor诊断40301285361已重现选卡进入ChooseThis后mouseClips[8]越界、Board菜单boardClips[11]越界，以及ZombieHome.Awake空引用。植物图鉴诊断漏打开植物页、菜单目标只搜持久事件等工具缺陷另列，不能作为游戏根因。

候选75160a32…7b50e15，唯一父输入d887b370…095b37。两次独立构造字节完全相同。达到139个实际原版支持位置后才启动本批共享测试。

ResourceManager.LoadAudioClips（0x0600021B）恢复原版固定顺序126个加载中的115个缺失项；保留31个BGM槽位（含原版本身空路径和缺失资源返回null）、九组音效列表、没有项目的Device目录计算、重复调用追加行为。禁止枚举文件夹排序、删除空槽位或用占位音效改变索引。原版RDI先捕获列表接收者，之后计算路径/加载，候选保持顺序。Load<AudioClip>共享原生代码的调用点泛型上下文及方法定义绑定已保存。

Button_z的Awake、QuitSelect、Select、Press、Highlight、PointExit（0x060005F8–5FD）恢复12个虚调用、10个颜色读取、2处相邻bool组合写入，共24位置。每个Text/Image颜色从自身字段取值；Select/Press的原生word 0x0100对应interactable=false和selected=true。保留组件真假判断、接收者捕获/重新读取、门控和回调可观察顺序。

集中结果：7目标类型检查通过，实际JIT准备7/7通过（不执行游戏），成员审计0错误/未解析，2310个非目标MethodDef及旧代码槽/元数据/权限保持；300个按钮+44个音效有限用例通过完整候选CIL与原版未改机器码调用方对照，包含空/假Unity组件、派生虚调用、回调变更字段、初始列表/容量/版本、重复注册和加载期间替换/修改列表。15个物理DLL语义破坏变体全部检出，崩溃不计为语义负控制。运行时叶函数是明确受控模型，不能替代Unity资源解码、静态构造器、渲染、音频硬件或iPad输入。保留首轮harness上下文不完整、工具路径和指令编码假设失误记录；没有把这些包装为游戏失败或通过。

全程序集未建模/失败的类型项目仍为70，不宣称游戏整体恢复完成。僵尸图鉴空引用尚未定位。新候选尚未运行真实Unity界面、完整IL2CPP/Apple编译或导出新IPA；先完成这些门再交付测试包。未选植物时NaN已确认是原版占位文本，不据此改掉原版行为。
'''.encode());manifest(D);print(json.dumps(dict(checkpoint=D.name,candidate_sha256=h,source_files=len(source),source_zip_bytes=(D/'SOURCE-AND-FINITE-VALIDATION.zip').stat().st_size)))
