"""Six complete original Button_z bodies, with only actual repairs counted."""
import json
import source_common as s

PLAN={
 0x5f8:('normal',0x18039b281,0x18039b291,0x18039b2cf,0x18039b2df,None),
 0x5f9:('normal',0x18039b652,0x18039b662,0x18039b6a0,0x18039b6b0,None),
 0x5fa:('selected',0x18039b73a,0x18039b74d,0x18039b78b,0x18039b79b,0x18039b6fd),
 0x5fb:('selected',0x18039b568,0x18039b57b,0x18039b5b9,0x18039b5c9,0x18039b52b),
 0x5fc:('highlight',0x18039b36f,0x18039b382,0x18039b3c0,0x18039b3d0,None),
 0x5fd:('normal',0x18039b46c,0x18039b47c,0x18039b4ba,0x18039b4ca,None),
}
def populate(c):
 alive=c.meth('UnityEngine.Object','op_Implicit',('UnityEngine.Object',))
 setters=[c.meth('TMPro.TMP_Text','set_color',('UnityEngine.Color',)),c.meth('UnityEngine.UI.Graphic','set_color',('UnityEngine.Color',))]
 proof=[]
 for rid,(prefix,tr,tc,ir,ic,packed) in PLAN.items():
  m=s.methods[s.tok(rid)];assert not m['handlers'];assert all(i['opcode']=='call' for i in m['instructions'] if i['opcode'] in ['call','callvirt'] and i['operand']['name']=='set_color')
  b=c.begin(rid);local_token=None;capture=None
  if rid in [0x5fb,0x5fc,0x5fd]:b.arg(0).token(0x7b,c.fld('Button_z','interactable')).branch(0x39,'ret')
  if rid==0x5fd:b.arg(0).token(0x7b,c.fld('Button_z','selected')).branch(0x3a,'ret')
  if rid==0x5f9:b.arg(0).arg(1).token(0x7d,c.fld('Button_z','interactable'))
  if rid in [0x5f9,0x5fa,0x5fb]:
   # Native snapshots the text reference around the two flag writes, then
   # rereads the actual field after Unity truthiness before virtual dispatch.
   field=s.pe.net.mdtables.Field.rows[(c.fld('Button_z','textMeshProUGUI')&0xffffff)-1]
   capture,local_token=c.append_locals(rid,[field.Signature.value[1:]])
   b.arg(0).token(0x7b,c.fld('Button_z','textMeshProUGUI')).store(capture)
  if packed:
   def flags(x):x.arg(0).i4(0).token(0x7d,c.fld('Button_z','interactable')).arg(0).i4(1).token(0x7d,c.fld('Button_z','selected'))
   b.site(packed,'FIELD_WRITE','Restore both adjacent bools from native word 0x0100: interactable=false, selected=true',flags)
  elif rid==0x5f9:b.arg(0).i4(0).token(0x7d,c.fld('Button_z','selected'))
  if capture is None:b.arg(0).token(0x7b,c.fld('Button_z','textMeshProUGUI'))
  else:b.loc(capture)
  b.token(0x28,alive).branch(0x39,'image')
  for receiver,suffix,readva,callva,setter,label in [('textMeshProUGUI','Text',tr,tc,setters[0],'image'),('image','Image',ir,ic,setters[1],'ret')]:
   if suffix=='Image':b.mark('image').arg(0).token(0x7b,c.fld('Button_z','image')).token(0x28,alive).branch(0x39,'ret')
   b.arg(0).token(0x7b,c.fld('Button_z',receiver))
   emit=lambda x,name=prefix+'Color_'+suffix:x.arg(0).token(0x7b,c.fld('Button_z',name))
   if rid==0x5f8:emit(b) # Awake already reads the right fields; do not count unchanged reads.
   else:b.site(readva,'FIELD_READ','Load '+prefix+'Color_'+suffix+' before use, independently of the other component',emit)
   b.site(callva,'CALL','Preserve original virtual color setter dispatch for '+suffix,lambda x,t=setter:x.token(0x6f,t))
  b.mark('ret').op('2a')
  c.add(rid,b,'Restore original value-type color data flow, virtual setter dispatch and packed selected flags',maxstack=3,local_token=local_token,group='ui-button-color-and-state')
  proof.append(dict(token=s.tok(rid),prefix=prefix,native_color_read_vas=[hex(tr),hex(ir)],native_virtual_setter_vas=[hex(tc),hex(ic)],packed_bool_write_va=hex(packed) if packed else None,old_awake_correct_reads_not_counted=rid==0x5f8))
 (s.Q/'BUTTON-SOURCE-SPECIFICATION.json').write_bytes((json.dumps(proof,indent=2)+'\n').encode())
