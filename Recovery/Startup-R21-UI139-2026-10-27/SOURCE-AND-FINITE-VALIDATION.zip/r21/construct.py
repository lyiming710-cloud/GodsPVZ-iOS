"""Author UI/audio changes only; never run a check or fixture automatically."""
import sys
from construction import Context
import source_audio,source_buttons

c=Context();source_audio.populate(c);source_buttons.populate(c);c.save_authored(sys.argv[1])
