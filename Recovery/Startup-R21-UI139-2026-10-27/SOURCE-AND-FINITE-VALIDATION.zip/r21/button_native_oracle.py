"""Execute unchanged original PC Button_z callers; color setters/predicate modeled."""
from pathlib import Path
import collections,ctypes as C,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
im=NativeImage();state={};cfgs={r:json.loads((Q/'native-source-complete'/f'0x{0x6000000|r:08X}.json').read_bytes()) for r in range(0x5f8,0x5fe)}
def put8(p,v):C.c_ubyte.from_address(p).value=bool(v)
def get8(p):return bool(C.c_ubyte.from_address(p).value)
def color(i):return struct.pack('<4I',0x3f000000+i*0x10001,0x80000000+i,0x7fc00000+i,0xbf000000+i*0x111)
def colbits(b):return ','.join(f'{x:08X}' for x in struct.unpack('<4I',b))
def setcol(offset,i):C.memmove(state['button']+offset,color(i),16)
def tag(p):return 'null' if not p else state['tags'][p]
def alive(p,method):
 assert not method;v=bool(p and state['live'][p]);state['trace'].append('Alive:'+tag(p)+':'+str(int(v)));state['alives']+=1
 if state['q']['mode']=='alive-text' and state['alives']==1:
  put64(state['button']+0x20,state['other-text'])
  for o,i in [(0x70,20),(0x80,21),(0xa0,22)]:setcol(o,i)
 if state['q']['mode']=='alive-image' and tag(p) in ['image','other-image']:
  put64(state['button']+0x28,state['other-image'])
  for o,i in [(0x30,23),(0x40,24),(0x60,25)]:setcol(o,i)
 return v
def setter(p,value,method):
 assert not method;label=tag(p);kind='TEXT' if 'text' in label else 'IMAGE';raw=C.string_at(value,16);state['colors'][label]=raw;state['written'][label]=True;state['trace'].append(kind+':'+label+':'+colbits(raw))
 if state['q']['mode']=='text-fields' and kind=='TEXT':
  put64(state['button']+0x28,state['other-image'])
  for o,i in [(0x30,26),(0x40,27),(0x60,28)]:setcol(o,i)
 if state['q']['mode']=='text-flags' and kind=='TEXT':put8(state['button']+0xb1,False);put8(state['button']+0xb0,True)
try:
 dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True;slots=set()
 for cfg in cfgs.values():
  for row in cfg['instructions']:
   i=next(dis.disasm(bytes.fromhex(row['bytes']),int(row['va'],16)))
   for o in i.operands:
    if o.type==X86_OP_MEM and o.mem.base==X86_REG_RIP:
     a=i.address+i.size+o.mem.disp;code=int.from_bytes(im.pe.get_data(a-im.base,8),'little')
     if code<=0xffffffff and code>>29==1:slots.add(a);im.class_slot(a)
 im.hook(0x18024fef0,None,[P],lambda p:None if p in slots else (_ for _ in ()).throw(AssertionError(hex(p))));im.hook(0x1802501e0,None,[P],lambda p:None);im.hook(0x18131f870,C.c_bool,[P,P],alive)
 def guarded(a,b,c):
  try:setter(a,b,c)
  except Exception as e:im.errors.append(dict(callback='virtual-color',error=repr(e)))
 cb=C.CFUNCTYPE(None,P,P,P)(guarded);im.callbacks.append(cb);entry=C.cast(cb,P).value
 for rid,cfg in cfgs.items():im.verify_caller(rid,int(cfg['entry'],16),cfg)
 rows=[]
 for q in json.loads((Q/'BUTTON-CASES.json').read_bytes()):
  state.clear();state.update(q=q,tags={},live={},colors={},written={},trace=[],alives=0)
  for label in ['button','text','image','other-text','other-image']:
   p=im.alloc(256);state[label]=p;state['tags'][p]=label
   if label!='button':
    state['live'][p]=q.get(label,1)==1;state['colors'][label]=b'\0'*16;state['written'][label]=False;cls=im.alloc(1024);put64(p,cls);put64(cls+0x2a8,entry)
  b=state['button'];put64(b+0x20,state['text'] if q['text'] else 0);put64(b+0x28,state['image'] if q['image'] else 0);put8(b+0xb0,q['interactable']);put8(b+0xb1,q['selected'])
  for o,i in [(0x30,1),(0x40,2),(0x50,3),(0x60,4),(0x70,5),(0x80,6),(0x90,7),(0xa0,8)]:setcol(o,i)
  rid=int(q['token'],16)&0xffffff
  if rid==0x5f9:C.CFUNCTYPE(None,P,C.c_bool,P)(int(cfgs[rid]['entry'],16))(b,q['arg'],None)
  else:C.CFUNCTYPE(None,P,P)(int(cfgs[rid]['entry'],16))(b,None)
  assert not im.errors,(q,im.errors)
  rows.append(dict(name=q['name'],token=q['token'],error=None,trace=list(state['trace']),state=dict(interactable=get8(b+0xb0),selected=get8(b+0xb1),text=tag(get64(b+0x20)),image=tag(get64(b+0x28)),objects=[dict(tag=l,written=state['written'][l],color=colbits(state['colors'][l])) for l in ['text','image','other-text','other-image']])))
 actual=json.loads(Path(sys.argv[1]).read_bytes());byname={r['name']:r for r in actual['results']};assert set(byname)=={r['name'] for r in rows};diff=[dict(original=r,actual=byname[r['name']]) for r in rows if r!=byname[r['name']]]
 report=dict(scope='SIX_UNCHANGED_NATIVE_BUTTON_CALLERS_VS_COMPLETE_ACTUAL_CIL',candidate_sha256=actual['candidate_sha256'],original_pc_sha256=PC_SHA,caller_bytes_verified=6,records=len(rows),per_method=dict(collections.Counter(r['token'] for r in rows)),results=rows,differences=diff,callback_errors=im.errors,controlled_leaves=['Unity.Object op_Implicit with declared callback mutations','TMP_Text and Graphic virtual color setters; no rendering','Initialized metadata/static-constructor scaffolding'],limitations=['Finite caller behavior, not Unity rendering, device input or universal equivalence','No Windows SEH exercise'],formal_or_product_acceptance=False)
 Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(records=len(rows),differences=len(diff),callback_errors=im.errors)));assert not diff
finally:im.close()
