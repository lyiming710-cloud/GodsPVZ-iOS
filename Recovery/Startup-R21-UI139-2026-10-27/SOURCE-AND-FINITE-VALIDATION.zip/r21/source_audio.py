"""Restore all 126 ordered native loads, including original empty BGM slots."""
import json
import source_common as s

def populate(c):
 plan=json.loads((s.W/'r21-device-interaction-2026-10-26/ORIGINAL-AUDIO-ORDERED-PLAN.json').read_bytes())
 assert plan['candidate_sha256']==s.sha(s.parent) and plan['native_entries']==126 and plan['omitted_load_positions']==115
 rid=0x21b;b=c.begin(rid);folder,sig=c.append_locals(rid,[b'\x0e'])
 combine=c.meth('System.IO.Path','Combine',('System.String','System.String'))
 add=c.meth('System.Collections.Generic.List`1<UnityEngine.AudioClip>','Add',('UnityEngine.AudioClip',))
 old=s.methods[s.tok(rid)];loads=[s.operand_token(s.tok(rid),i) for i in old['instructions'] if i['opcode']=='call' and i['operand']['owner']=='InternalResourceLoader' and i['operand']['name']=='Load']
 assert len(loads)==11 and len(set(loads))==1 and loads[0]>>24==43;load=loads[0]
 current_folder=None
 for event in plan['events']:
  if event['kind']=='FOLDER':
   current_folder=event['parts'];assert len(current_folder)==2
   b.token(0x72,c.string(current_folder[0])).token(0x72,c.string(current_folder[1])).token(0x28,combine).store(folder)
  else:
   entry=plan['rows'][event['entry']];assert entry['path_parts'][:2]==current_folder
   # Receiver evaluated before path construction/resource loading, as native
   # RDI captures the current list before either potentially observable call.
   b.token(0x7e,c.fld('ResourceManager',entry['field'])).loc(folder).token(0x72,c.string(entry['path_parts'][2])).token(0x28,combine)
   if entry['omitted_in_shipped_cil']:b.site(int(entry['load_va'],16),'CALL','Restore omitted ordered audio load for '+entry['field']+': '+entry['path'],lambda x:x.token(0x28,load))
   else:b.token(0x28,load) # Existing eleven loads are not counted again.
   b.token(0x6f,add)
 b.op('2a')
 c.add(rid,b,'Restore complete original ordered audio registration; preserve null/empty BGM slots, nine list groups, unused Device path and repeat-call append behavior',maxstack=4,local_token=sig,group='complete-native-audio-registration')
 (s.Q/'ORIGINAL-AUDIO-ORDERED-PLAN.json').write_bytes((json.dumps(plan,indent=2)+'\n').encode())
