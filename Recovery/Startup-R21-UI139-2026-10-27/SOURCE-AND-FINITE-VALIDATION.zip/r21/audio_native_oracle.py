"""Complete original audio-registration caller, raw literal slots, modeled leaves."""
from pathlib import Path
import ctypes as C,hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
im=NativeImage();state={};cfg=json.loads((Q/'native-source-complete/0x0600021B.json').read_bytes());meta=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/global-metadata.dat').read_bytes();assert hashlib.sha256(meta).hexdigest()=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9';lo,ln,ld,ldn=struct.unpack_from('<4I',meta,8)
groups={'BGMs':0xf8,'boardClips':0x100,'buttonClips':0x108,'plantClips':0x110,'deviceClips':0x118,'zombieClips':0x120,'projectClips':0x128,'particleClips':0x130,'mouseClips':0x138,'dialogueClips':0x140}
present=set(json.loads((Q/'AUDIO-RESOURCE-PATHS.json').read_bytes()))
def string(s):
 b=s.encode('utf-16-le');p=im.alloc(24+len(b));put32(p+0x10,len(b)//2);C.memmove(p+0x14,b,len(b));return p
def text(p):assert p;return C.string_at(p+0x14,get32(p+0x10)*2).decode('utf-16-le')
def clip(tag):
 if tag not in state['clips']:p=im.alloc(24);state['clips'][tag]=p;state['tags'][p]=tag
 return state['clips'][tag]
def array(capacity):p=im.alloc(32+8*capacity);put32(p+0x18,capacity);return p
def resize_add(p,value,method):
 assert method in handles;count=get32(p+0x18);old=get64(p+0x10);cap=get32(old+0x18);new=array(4 if not cap else cap*2);assert count==cap
 if count:C.memmove(new+0x20,old+0x20,8*count)
 put64(p+0x10,new);put64(new+0x20+8*count,value);put32(p+0x18,count+1)
def add(p,value,method):
 assert p and method in handles;put32(p+0x1c,get32(p+0x1c)+1);count=get32(p+0x18);arr=get64(p+0x10)
 if count==get32(arr+0x18):resize_add(p,value,method)
 else:put64(arr+0x20+count*8,value);put32(p+0x18,count+1)
def reflist(label,count):
 p=im.alloc(48);put64(p+0x10,array(0));state['lists'][label]=p
 for i in range(count):add(p,clip('seed:'+label+':'+str(i)),list_handle)
 return p
def combine(left,right,method):
 assert not method;a,b=text(left),text(right);assert a and not b.startswith(('\\','/')) and ':' not in b
 return string(a if not b else a+'\\'+b)
def load(path,method):
 assert method==audio_handle;path=text(path);state['loads']+=1;state['trace'].append('Load:'+path);q=state['q']
 if state['loads']==q['trigger']:
  p=static+groups[q['target']]
  if q['mode']=='replace':put64(p,reflist('replacement',3))
  if q['mode']=='append':add(get64(p),clip('callback-added'),list_handle)
 return clip('clip:'+path) if path.replace('\\','/').lower() in present else 0
def barrier(p,value):assert get64(p)==(value or 0)
try:
 dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True;slots={};handles=set();classes=[]
 for row in cfg['instructions']:
  i=next(dis.disasm(bytes.fromhex(row['bytes']),int(row['va'],16)))
  if i.mnemonic not in ['mov','lea']:continue
  for o in i.operands:
   if o.type!=X86_OP_MEM or o.mem.base!=X86_REG_RIP:continue
   a=i.address+i.size+o.mem.disp;v=int.from_bytes(im.pe.get_data(a-im.base,8),'little')
   if v>0xffffffff or v>>29 not in range(1,8) or a in slots:continue
   kind=v>>29;index=(v&0x1fffffff)>>1
   if kind==5:
    assert index<ln//8;n,start=struct.unpack_from('<II',meta,lo+index*8);assert start+n<=ldn;p=string(meta[ld+start:ld+start+n].decode('utf-8'))
   elif kind==1:
    p=im.class_slot(a);static_mem=im.alloc(1024);put64(p+0xb8,static_mem);generic=im.alloc(1024);ctx=im.alloc(1024);handle=im.alloc(128);put64(p+0x20,generic);put64(generic+0xc0,ctx);put64(ctx+0x70,handle);handles.add(handle);classes.append(p)
   elif kind==6:
    p=im.alloc(128);handles.add(p)
    # Original BGM inlining reads the closed MethodInfo's declaring class
    # and RGCTX resize handle. An all-zero opaque handle is insufficient.
    generic=im.alloc(1024);ctx=im.alloc(1024);handle=im.alloc(128);put64(p+0x20,generic);put64(generic+0xc0,ctx);put64(ctx+0x70,handle);handles.add(handle)
   else:raise AssertionError((hex(a),hex(v)))
   put64(a,p);slots[a]=(kind,index,p)
 assert slots[0x181bac018][:2]==(6,74424);audio_handle=slots[0x181bac018][2];list_handle=next(iter(handles));static=get64(get64(0x181bb6478)+0xb8)
 im.hook(0x18024fef0,None,[P],lambda p:None if p in slots else (_ for _ in ()).throw(AssertionError(hex(p))));im.hook(0x1802501e0,None,[P],lambda p:None);im.hook(0x18024f360,None,[P,P],barrier);im.hook(0x180c84600,P,[P,P,P],combine);im.hook(0x18047ba00,P,[P,P],load);im.hook(0x180002e70,None,[P,P,P],add);im.hook(0x180847ce0,None,[P,P,P],resize_add);im.verify_caller(0x21b,int(cfg['entry'],16),cfg)
 rows=[]
 for q in json.loads((Q/'AUDIO-CASES.json').read_bytes()):
  state.clear();state.update(q=q,clips={},tags={},lists={},trace=[],loads=0)
  for group,offset in groups.items():put64(static+offset,reflist(group,q['initial']))
  for k in range(q['repeat']):C.CFUNCTYPE(None,P)(int(cfg['entry'],16))(None)
  assert not im.errors,(q,im.errors);bindings={g:next(label for label,p in state['lists'].items() if p==get64(static+offset)) for g,offset in groups.items()};lists={}
  for label,p in state['lists'].items():
   count=get32(p+0x18);arr=get64(p+0x10);lists[label]=dict(count=count,capacity=get32(arr+0x18),version=get32(p+0x1c),items=[state['tags'][v] if (v:=get64(arr+0x20+8*i)) else 'null' for i in range(count)])
  rows.append(dict(name=q['name'],token='0x0600021B',error=None,trace=list(state['trace']),state=dict(loads=state['loads'],bindings=bindings,lists=lists)))
 actual=json.loads(Path(sys.argv[1]).read_bytes());byname={r['name']:r for r in actual['results']};assert set(byname)=={r['name'] for r in rows};diff=[dict(original=r,actual=byname[r['name']]) for r in rows if r!=byname[r['name']]]
 report=dict(scope='UNCHANGED_ORIGINAL_AUDIO_CALLER_VS_COMPLETE_ACTUAL_CIL',candidate_sha256=actual['candidate_sha256'],original_pc_sha256=PC_SHA,caller_bytes_verified=True,records=len(rows),results=rows,differences=diff,callback_errors=im.errors,controlled_leaves=['Path.Combine restricted to original literal nonrooted parts; CLR uses actual BCL independently','Generic audio loading with resource-existence/null contract, not Unity decode success','List reference Add/resize, including original inline BGM mutations','Initialized metadata/static-constructor scaffolding and GC barrier'],limitations=['Finite caller equivalence, not resource decode, audio hardware, actual static constructors, Unity, iOS or universal behavior','No Windows SEH test'],formal_or_product_acceptance=False)
 Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(records=len(rows),differences=len(diff),callback_errors=im.errors)));assert not diff
finally:im.close()
