from pathlib import Path
import itertools,json
Q=Path(__file__).resolve().parent;D=Q.parent/'r21-device-interaction-2026-10-26';catalog=json.loads((D/'PC-RESOURCE-CONTAINER.json').read_bytes());print('catalog structure',type(catalog).__name__)
# The raw catalog identity is retained; this set only models resource existence,
# not decode/load success or Unity AudioClip internals.
assert isinstance(catalog,dict) and isinstance(catalog['m_Container'],list)
paths=[r[0] for r in catalog['m_Container']];assert all(isinstance(p,str) for p in paths)
(Q/'AUDIO-RESOURCE-PATHS.json').write_text(json.dumps(sorted(set(p.replace('\\','/').lower() for p in paths)),indent=2)+'\n',encoding='utf-8')
cases=[]
for initial,repeat in itertools.product([0,1,3,5],[1,2]):cases.append(dict(name=f'stable-{initial}-{repeat}',initial=initial,repeat=repeat,mode='stable',trigger=-1,target='BGMs'))
plan=json.loads((Q/'ORIGINAL-AUDIO-ORDERED-PLAN.json').read_bytes());first={}
for i,row in enumerate(plan['rows'],1):first.setdefault(row['field'],i)
for group,trigger in first.items():
 for mode,repeat in itertools.product(['replace','append'],[1,2]):cases.append(dict(name=f'{mode}-{group}-{repeat}',initial=1,repeat=repeat,mode=mode,trigger=trigger,target=group))
(Q/'AUDIO-CASES.json').write_text(json.dumps(cases,indent=2)+'\n',encoding='utf-8');print('audio cases',len(cases),'resources',len(paths))
