"""Independent physical DLL mutants, run through complete actual-CIL fixtures."""
from pathlib import Path
import hashlib,json,struct,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'));import dnfile
sha=lambda b:hashlib.sha256(b).hexdigest();data=(Q/'authored1.dll').read_bytes();assert sha(data)=='75160a3233f1e1ab13a44f712efb4b47fdeb9b57bd38fa25f180276bb7b50e15'
pe=dnfile.dnPE(data=data);cil=json.loads((Q/'shared-authored1/ALL-CIL.json').read_bytes());methods={m['token']:m for m in cil['methods']};M=Q/'physical-controls';M.mkdir(exist_ok=True)
def codeat(rid):
 at=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[rid-1].Rva);h=1 if data[at]&3==2 else (struct.unpack_from('<H',data,at)[0]>>12)*4;return at+h
def execute(label,rid,offset,before,after,profile):
 at=codeat(rid)+offset;assert data[at:at+len(before)]==before and len(before)==len(after);mutant=bytearray(data);mutant[at:at+len(after)]=after;p=M/(label+'.dll')
 if p.exists():assert p.read_bytes()==mutant
 else:p.write_bytes(mutant)
 prefix='BUTTON' if profile=='buttons' else 'AUDIO'
 out=M/(label+'.json');cmd=[str(ROOT/'.local/dotnet10/dotnet.exe'),str(Q/('runtime-'+profile)/'bin/Release/net10.0/Fixture.dll'),str(p),str(ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'),str(Q/(prefix+'-CASES.json')),str(out)]
 if profile=='audio':cmd.append(str(Q/'AUDIO-RESOURCE-PATHS.json'))
 log=M/(label+'.log')
 if log.exists() and not out.exists():log.rename(M/(label+'.initial-tool-path-failure.log'))
 r=subprocess.run(cmd,capture_output=True,timeout=40);log.write_bytes(r.stdout+r.stderr);assert r.returncode==0,(label,r.returncode)
 actual=json.loads(out.read_bytes());assert actual['candidate_sha256']==sha(mutant);native=json.loads((Q/(prefix+'-NATIVE-COMPARE.json')).read_bytes());byname={r['name']:r for r in actual['results']};diff=[dict(original=r,actual=byname[r['name']]) for r in native['results'] if r!=byname[r['name']]];assert diff,label
 return dict(label=label,token=f'0x{0x6000000|rid:08X}',candidate_sha256=sha(mutant),file_offset=at,before=before.hex(),after=after.hex(),physical_byte_delta_only=True,process_exit=0,differences=len(diff),example=diff[0])
rows=[]
for rid in range(0x5f8,0x5fe):
 m=methods[f'0x{0x6000000|rid:08X}'];call=next(i for i in m['instructions'] if i['opcode']=='callvirt' and i['operand']['name']=='set_color')
 rows.append(execute(f'{rid:x}-wrong-nonvirtual',rid,call['offset'],b'\x6f',b'\x28','buttons'))
 image=next(i for i in m['instructions'] if i['opcode']=='ldfld' and i['operand']['identity'].endswith('Color_Image'))
 text=next(i for i in m['instructions'] if i['opcode']=='ldfld' and i['operand']['identity'].endswith('Color_Text'))
 at=codeat(rid);rows.append(execute(f'{rid:x}-wrong-image-color',rid,image['offset']+1,data[at+image['offset']+1:at+image['offset']+5],data[at+text['offset']+1:at+text['offset']+5],'buttons'))
 if rid in [0x5fa,0x5fb]:
  index=next(k for k,i in enumerate(m['instructions']) if i['opcode']=='stfld' and i['operand']['identity'].endswith('::selected'));constant=m['instructions'][index-1]
  assert constant['opcode']=='ldc.i4' and constant['operand']==1;rows.append(execute(f'{rid:x}-wrong-selected-flag',rid,constant['offset']+1,b'\x01\x00\x00\x00',b'\x00\x00\x00\x00','buttons'))
m=methods['0x0600021B'];load=next(i for i in m['instructions'] if i['opcode']=='call' and i['operand']['owner']=='InternalResourceLoader');at=codeat(0x21b)+load['offset'];rows.append(execute('21b-omitted-audio-load',0x21b,load['offset'],data[at:at+5],b'\x26\x14\x00\x00\x00','audio'))
report=dict(scope='PHYSICAL_DLL_NEGATIVE_CONTROLS_ACTUAL_CIL_VS_PINNED_EXECUTED_NATIVE_RECORDS',candidate_sha256=sha(data),controls=len(rows),rejected=len(rows),process_failures_counted_as_semantic_controls=0,rows=rows)
(Q/'PHYSICAL-CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(controls=len(rows),rejected=len(rows))))
