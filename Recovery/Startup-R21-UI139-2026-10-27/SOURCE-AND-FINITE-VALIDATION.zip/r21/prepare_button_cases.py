from pathlib import Path
import itertools,json
Q=Path(__file__).resolve().parent;rows=[]
for rid in range(0x5f8,0x5fe):
 for text,image,interactable,selected,arg in itertools.product(range(3),range(3),[False,True],[False,True],[False,True] if rid==0x5f9 else [False]):
  rows.append(dict(name=f'{rid:x}-t{text}-i{image}-enable{int(interactable)}-select{int(selected)}-arg{int(arg)}',token=f'0x{0x6000000|rid:08X}',text=text,image=image,interactable=interactable,selected=selected,arg=arg,mode='stable'))
 for mode in ['alive-text','alive-image','text-fields','text-flags']:
  for selected in [False,True]:rows.append(dict(name=f'{rid:x}-{mode}-{int(selected)}',token=f'0x{0x6000000|rid:08X}',text=1,image=1,interactable=True,selected=selected,arg=True,mode=mode))
(Q/'BUTTON-CASES.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print('button cases',len(rows))
