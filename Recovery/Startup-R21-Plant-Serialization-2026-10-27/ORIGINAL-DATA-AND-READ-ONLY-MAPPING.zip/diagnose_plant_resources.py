"""Read-only original-vs-project Plant serialization census.

The optional generator produced an unsuitable string-array schema and an
unaligned MonoBehaviour enabled header. Preserve the original schema, adapt
only those explicitly described encodings, and require byte-identical write
back for every decoded original component. This is resource evidence, not a
gameplay PASS or permission to guess missing object references.
"""
from pathlib import Path
import hashlib,json,re,sys,zipfile
G=Path(__file__).resolve().parent;W=G.parent;ROOT=W.parents[1]
sys.path[:0]=[str(W/'python-deps'),str(W/'tool-deps')]
import UnityPy,yaml
from UnityPy.helpers.TypeTreeNode import TypeTreeNode
from UnityPy.helpers import TypeTreeHelper as H
from UnityPy.streams import EndianBinaryReader,EndianBinaryWriter

sha=lambda b:hashlib.sha256(b).hexdigest()
nodes=json.loads((G/'PLANT-TYPE-TREE.json').read_bytes());adaptations=[]
for i,n in enumerate(nodes):
 if n['m_Name']=='m_Enabled'and n['m_Level']==1:
  adaptations.append(dict(index=i,reason='Player MonoBehaviour enabled byte is followed by four-byte alignment',before=dict(n)));n['m_MetaFlag']|=16384
 if n['m_Type']=='string'and i+3<len(nodes)and nodes[i+1]['m_Name']=='Array'and nodes[i+3]['m_Name']=='data'and nodes[i+3]['m_Type']=='string':
  adaptations.append(dict(index=i,reason='Array of strings is a vector of strings; an ordinary string instead has char elements',before=dict(n)));n['m_Type']='vector'
tree=TypeTreeNode.from_list([TypeTreeNode(n['m_Level'],n['m_Type'],n['m_Name'],0,0,m_MetaFlag=n['m_MetaFlag'])for n in nodes])
js=lambda p,j:p.write_bytes((json.dumps(j,indent=2,ensure_ascii=False)+'\n').encode())
js(G/'PLANT-TYPE-TREE-ADAPTED.json',nodes)
with zipfile.ZipFile(ROOT/'GodsPVZ_1.0.2.zip')as z:
 raw=z.read(next(n for n in z.namelist()if n.endswith('/resources.assets')));gs=z.read(next(n for n in z.namelist()if n.endswith('/globalgamemanagers.assets')))
assert sha(raw)=='b84c445e60b52b446ae1989557541b3206a518ffc9ea64d8abd1d2a3d8472317'
env=UnityPy.load(raw);objects={o.path_id:o for o in env.objects};scripts={o.path_id:o.read_typetree()for o in UnityPy.load(gs).objects if o.type.name=='MonoScript'}
catalog=json.loads((W/'r21-device-interaction-2026-10-26/PC-RESOURCE-CONTAINER.json').read_bytes());plant_roots={}
for resource,ptr in catalog['m_Container']:
 if resource.lower().startswith('prefabs/plant/')and ptr['m_PathID']in objects and objects[ptr['m_PathID']].type.name=='GameObject':plant_roots[resource.lower()]=ptr['m_PathID']
source_zip=next((W/'r21-source-run-40368892424').rglob('r21-source-prefabs-scenes-audio-metadata.zip'));source=zipfile.ZipFile(source_zip);source_paths={n[len('Assets/Resources/'):-len('.prefab')].lower():n for n in source.namelist()if n.startswith('Assets/Resources/')and n.endswith('.prefab')}
rows=[];decoded_all={};unmodeled=[]
for resource,goid in sorted(plant_roots.items()):
 try:
  go=objects[goid].read_typetree();owners=[]
  for c in go['m_Component']:
   o=objects[c['component']['m_PathID']]
   if o.type.name!='MonoBehaviour':continue
   header=o.read_typetree(check_read=False);s=header['m_Script'];script=scripts[s['m_PathID']]
   if script['m_ClassName']=='Plant'and script['m_Namespace']=='':owners.append(o)
  assert len(owners)==1,(resource,len(owners));obj=owners[0];data=obj.get_raw_data();reader=EndianBinaryReader(data,endian='<');decoded=H.read_typetree(tree,reader,byte_size=len(data),check_read=True);writer=EndianBinaryWriter(endian='<');H.write_typetree(decoded,tree,writer);assert writer.bytes==data
  srcpath=source_paths[resource];source_bytes=source.read(srcpath);text=source_bytes.decode('utf-8');heads=list(re.finditer(r'(?m)^--- !u!(\d+) &(-?\d+)[^\r\n]*\r?$',text));docs=[]
  for k,h in enumerate(heads):
   if int(h[1])!=114:continue
   body=text[h.end():heads[k+1].start()if k+1<len(heads)else len(text)]
   if not re.search(r'(?m)^  m_Script: \{fileID: 313814881, guid: 60b84a767c46ced9aacc93f38da4d2f3, type: 3\}',body):continue
   parsed=yaml.load(body,Loader=yaml.BaseLoader)['MonoBehaviour'];keys=[k for k in parsed if not k.startswith('m_')];docs.append(dict(local_file_id=int(h[2]),game_fields=keys))
  assert len(docs)==1,(resource,len(docs));actual=docs[0];expected=[k for k in decoded if not k.startswith('m_')];missing=[k for k in expected if k not in actual['game_fields']]
  refs={}
  for key in ['animationGroup','ani_aniPart','shadow','UI_HP','UI_Elements','UI_Buff']:
   ptr=decoded[key];target=objects.get(ptr['m_PathID'])if ptr['m_FileID']==0 else None
   refs[key]=dict(pointer=ptr,target_type=None if target is None else target.type.name,target_name=None if target is None else target.read_typetree(check_read=False).get('m_Name'))
   assert not ptr['m_PathID']or target is not None,(resource,key,ptr)
  row=dict(resource=resource,original_component=obj.path_id,original_bytes=len(data),original_sha256=sha(data),original_ID=decoded['ID'],original_health=decoded['healthPoint'],original_attack=decoded['attackPoint'],original_attack_interval=decoded['attackInterval'],original_serialized_game_field_count=len(expected),byte_exact_round_trip=True,source_path=srcpath,source_sha256=sha(source_bytes),source_owner=actual['local_file_id'],source_game_fields=actual['game_fields'],missing_game_fields=missing,original_reference_targets=refs)
  rows.append(row);decoded_all[resource]=decoded
 except Exception as e:unmodeled.append(dict(resource=resource,status='UNMODELED_NOT_REPAIRED',error=repr(e)))
result=dict(scope='READ_ONLY_ORIGINAL_PLANT_SERIALIZATION_AND_CAPTURED_PROJECT_CENSUS_NOT_REPAIR_OR_GAMEPLAY_PASS',candidate_field_metadata_sha256='75160a3233f1e1ab13a44f712efb4b47fdeb9b57bd38fa25f180276bb7b50e15',original_resources_sha256=sha(raw),captured_source_zip_sha256=sha(source_zip.read_bytes()),generator='TypeTreeGeneratorAPI 0.0.10 AssetsTools backend',original_generator_schema_sha256=sha((G/'PLANT-TYPE-TREE.json').read_bytes()),schema_adaptations=adaptations,plant_resource_roots=len(plant_roots),decoded_and_exactly_round_tripped=len(rows),source_headers_without_any_game_fields=sum(not r['source_game_fields']for r in rows),missing_field_entries=sum(len(r['missing_game_fields'])for r in rows),results=rows,unmodeled=unmodeled,source_files_changed=False,game_dll_changed=False,qualified_methods_added=0,limits=['Round trip proves encoding consistency, not independent original field-name attribution; names/types/order come from the previously audited game metadata.','This does not repair any field or prove attacks, pathfinding, scene interaction or iOS gameplay.','Restoring PPtrs requires actual target class/hierarchy/GUID/localID proof, including nested data; never guess a matching name alone.'])
js(G/'PLANT-RESOURCE-CENSUS.json',result);js(G/'ORIGINAL-PLANT-SERIALIZED-VALUES.json',decoded_all)
print(json.dumps({k:v for k,v in result.items()if k not in ['results','unmodeled','limits','schema_adaptations']}));print('UNMODELED',len(unmodeled));print(json.dumps(unmodeled[:3]))
