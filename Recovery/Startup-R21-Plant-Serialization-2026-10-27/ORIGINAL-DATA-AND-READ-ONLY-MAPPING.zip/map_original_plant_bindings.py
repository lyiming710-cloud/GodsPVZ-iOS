"""Plan only: match original local PPtrs to actual source hierarchy + class.
Never modifies the captured source, Unity project, or running CI input.
"""
from pathlib import Path
import hashlib,json,re,sys,zipfile,collections,traceback,struct
G=Path(__file__).resolve().parent;W=G.parent;ROOT=W.parents[1];sys.path[:0]=[str(W/'python-deps'),str(W/'tool-deps')]
import UnityPy,yaml
sha=lambda b:hashlib.sha256(b).hexdigest()
survey=json.loads((G/'PLANT-RESOURCE-CENSUS.json').read_bytes());values=json.loads((G/'ORIGINAL-PLANT-SERIALIZED-VALUES.json').read_bytes());source=zipfile.ZipFile(next((W/'r21-source-run-40368892424').rglob('r21-source-prefabs-scenes-audio-metadata.zip')))

def source_docs(data):
 text=data.decode('utf-8');heads=list(re.finditer(r'(?m)^--- !u!(\d+) &(-?\d+)[^\r\n]*\r?$',text));result={}
 for k,h in enumerate(heads):
  body=text[h.end():heads[k+1].start()if k+1<len(heads)else len(text)];parsed=yaml.load(body,Loader=yaml.BaseLoader);assert len(parsed)==1;result[int(h[2])]=dict(kind=int(h[1]),data=next(iter(parsed.values())),body=body)
 return result

# Learn game MonoScript IDs from actual MonoScript.GetClass/instance type
# observations, tied to the same candidate and the captured Sunflower anchors.
probe=json.loads((W/'r21-reimport-run-40374543207/editor/r21-serialization-reimport-probe.json').read_bytes());p=next(o for o in probe['objects']if o['phase']=='after-force-import'and o['type']=='Plant'and o['route']=='AssetDatabase');sun=source_docs(source.read('Assets/Resources/prefabs/plant/Sunflower.prefab'));script_classes={}
for line in p['children']:
 m=re.search(r' localID=(-?\d+)$',line)
 if not m:continue
 anchor=int(m[1]);doc=sun.get(anchor)
 if doc is None or doc['kind']!=114:continue
 script=doc['data']['m_Script'];name=line.split(',',1)[0].rsplit(' ',1)[1];key=(script['guid'],int(script['fileID']));assert key not in script_classes or script_classes[key]==name;script_classes[key]=name
assert script_classes[('60b84a767c46ced9aacc93f38da4d2f3',313814881)]=='Plant'
with zipfile.ZipFile(ROOT/'GodsPVZ_1.0.2.zip')as z:raw=z.read(next(n for n in z.namelist()if n.endswith('/resources.assets')));gs=z.read(next(n for n in z.namelist()if n.endswith('/globalgamemanagers.assets')))
env=UnityPy.load(raw);objects={o.path_id:o for o in env.objects};scripts={o.path_id:o.read_typetree()for o in UnityPy.load(gs).objects if o.type.name=='MonoScript'}
text_source=zipfile.ZipFile(W/'R3-STARTUP-TEXT-40067634181.zip');assert json.loads(text_source.read('INPUT-IDENTITY.json'))['archive_sha256']=='d4264f12a00e86b6149d20ecf04caa9761af510aece6107bcceb155ea4ab0bbc'
sprite_proofs={}
def sprite_binding(pid):
 if pid in sprite_proofs:return sprite_proofs[pid]
 obj=objects[pid];assert obj.type.name=='Sprite',('UNMODELED_NONLOCAL_OBJECT',pid,obj.type.name);native=obj.read_typetree();name=native['m_Name'];path='Assets/Sprite/'+name+'.asset';members=[n for n in text_source.namelist()if n=='project-text/'+path];assert len(members)==1,('SPRITE_SOURCE_NOT_UNIQUE',pid,name)
 data=text_source.read(members[0]);text=data.decode();match=re.search(r'(?m)^--- !u!213 &(-?\d+)',text);assert match;anchor=int(match[1]);source_sprite=yaml.load(re.sub(r'^%[^\n]*\n|^--- !u![^\n]*\n','',text,flags=re.M),Loader=yaml.BaseLoader)['Sprite'];assert source_sprite['m_Name']==name
 for key in ['m_Rect','m_Offset','m_Border','m_Pivot']:
  for component,v in native[key].items():assert struct.pack('<f',v)==struct.pack('<f',float(source_sprite[key][component])),(pid,key,component)
 for key in ['m_PixelsToUnits','m_Extrude','m_IsPolygon']:assert float(native[key])==float(source_sprite[key]),(pid,key)
 a=native['m_RD'];b=source_sprite['m_RD'];index=bytes(a['m_IndexBuffer']);vertices=bytes(a['m_VertexData']['m_DataSize']);assert index==bytes.fromhex(b['m_IndexBuffer']),('SPRITE_INDEX_BYTES_DIFFER',pid);assert vertices==bytes.fromhex(b['m_VertexData']['_typelessdata']),('SPRITE_VERTEX_BYTES_DIFFER',pid);assert a['m_VertexData']['m_VertexCount']==int(b['m_VertexData']['m_VertexCount'])
 texture=a['texture'];assert texture['m_FileID']==0;tex=objects[texture['m_PathID']];assert tex.type.name=='Texture2D';texture_name=tex.read_typetree(check_read=False)['m_Name'];tex_meta_name='project-text/Assets/Texture2D/'+texture_name+'.png.meta';tex_meta=text_source.read(tex_meta_name);tex_guid=re.findall(rb'(?m)^guid: ([0-9a-f]{32})\r?$',tex_meta);assert len(tex_guid)==1;assert b['texture']==dict(fileID='2800000',guid=tex_guid[0].decode(),type='3')
 meta=text_source.read(members[0]+'.meta');meta_obj=yaml.load(meta,Loader=yaml.BaseLoader);guid=meta_obj['guid'];assert int(meta_obj['NativeFormatImporter']['mainObjectFileID'])==anchor
 proof=dict(original_path_id=pid,target_class='Sprite',source_path=path,source_file_id=anchor,source_guid=guid,source_asset_sha256=sha(data),source_meta_sha256=sha(meta),original_name=name,exact_f32_rect_offset_border_pivot=True,exact_index_buffer_sha256=sha(index),exact_vertex_buffer_sha256=sha(vertices),vertex_count=a['m_VertexData']['m_VertexCount'],original_texture_name=texture_name,source_texture_meta_sha256=sha(tex_meta),source_texture_guid=tex_guid[0].decode(),texture_pixels_independently_compared=False)
 sprite_proofs[pid]=proof;return proof

def original_graph(root):
 result={};reverse={}
 def walk(go_id,path):
  go=objects[go_id].read_typetree();result[(path,'GameObject',0)]=go_id;reverse[go_id]=(path,'GameObject',0);counts=collections.Counter();transform=None
  for c in go['m_Component']:
   pid=c['component']['m_PathID'];o=objects[pid];header=o.read_typetree(check_read=False);kind=o.type.name
   if kind=='MonoBehaviour':
    script=header['m_Script']
    if script['m_FileID']==1 and script['m_PathID']in scripts:
     s=scripts[script['m_PathID']];kind=(s['m_Namespace']+'.'if s['m_Namespace']else'')+s['m_ClassName']
    else:kind='UNRESOLVED_AUXILIARY_SCRIPT:'+str((script['m_FileID'],script['m_PathID']))
   key=(path,kind,counts[kind]);counts[kind]+=1;result[key]=pid if key not in result else None;reverse[pid]=key
   if kind in ['Transform','RectTransform']:transform=header
  assert transform is not None
  for c in transform['m_Children']:
   child=objects[c['m_PathID']].read_typetree()['m_GameObject']['m_PathID'];name=objects[child].read_typetree()['m_Name'];walk(child,(path+'/'if path else'')+name)
 walk(root,'');return result,reverse

def captured_graph(docs):
 result={};transforms={i:d for i,d in docs.items()if d['kind']in [4,224]};roots=[i for i,d in transforms.items()if int(d['data']['m_Father']['fileID'])==0];assert len(roots)==1
 bykind={o.value:o.name for o in UnityPy.enums.ClassIDType}
 def walk(tid,path):
  t=transforms[tid]['data'];go_id=int(t['m_GameObject']['fileID']);go=docs[go_id]['data'];key=(path,'GameObject',0);result[key]=go_id if key not in result else None;counts=collections.Counter()
  for c in go['m_Component']:
   anchor=int(c['component']['fileID']);d=docs[anchor];kind=bykind[d['kind']]
   if d['kind']==114:
    s=d['data']['m_Script'];key=(s.get('guid',''),int(s['fileID']));kind=script_classes.get(key,'UNOBSERVED_SCRIPT:'+str(key))
   key=(path,kind,counts[kind]);counts[kind]+=1;result[key]=anchor if key not in result else None
  for c in t['m_Children']or[]:
   child=int(c['fileID']);child_go=docs[int(transforms[child]['data']['m_GameObject']['fileID'])]['data'];walk(child,(path+'/'if path else'')+child_go['m_Name'])
 walk(roots[0],'');return result

plans=[];gaps=[]
for row in survey['results']:
 try:
  resource=row['resource'];decoded=values[resource];docs=source_docs(source.read(row['source_path']));src=captured_graph(docs);old,reverse=original_graph(decoded['m_GameObject']['m_PathID']);bindings=[]
  def map_value(v,field):
   if isinstance(v,dict):
    if set(v)=={'m_FileID','m_PathID'}:
     assert v['m_FileID']==0 or not v['m_PathID'],('EXTERNAL_REFERENCE',field,v)
     if not v['m_PathID']:return dict(fileID=0)
     if v['m_PathID']not in reverse:
      proof=sprite_binding(v['m_PathID']);bindings.append(dict(field=field,**proof));return dict(fileID=proof['source_file_id'],guid=proof['source_guid'],type=3)
     key=reverse[v['m_PathID']];assert key in src and src[key] is not None and old[key] is not None,('TARGET_CLASS_OR_HIERARCHY_NOT_PROVED_OR_AMBIGUOUS',field,key);anchor=src[key];bindings.append(dict(field=field,original_path_id=v['m_PathID'],relative_path=key[0],target_class=key[1],component_ordinal=key[2],source_local_file_id=anchor));return dict(fileID=anchor)
    return {k:map_value(x,field+'.'+k)for k,x in v.items()}
   if isinstance(v,list):return [map_value(x,field+'['+str(i)+']')for i,x in enumerate(v)]
   return v
  mapped={k:map_value(v,k)for k,v in decoded.items()if not k.startswith('m_')};assert len(mapped)==94
  owner=docs[row['source_owner']];assert not[k for k in owner['data']if not k.startswith('m_')]
  plans.append(dict(resource=resource,source_path=row['source_path'],captured_prefab_sha256=row['source_sha256'],source_owner=row['source_owner'],source_owner_body_sha256=sha(owner['body'].encode()),original_component=row['original_component'],original_component_sha256=row['original_sha256'],original_field_count=94,fields=mapped,reference_bindings=bindings))
 except Exception as e:gaps.append(dict(resource=row['resource'],status='QUARANTINED_NO_REPAIR',error=repr(e),trace=traceback.format_exc()))
result=dict(scope='SOURCE_PLAN_ONLY_94_ORIGINAL_FIELDS_PER_PROVED_PLANT_OWNER_NOT_GAMEPLAY_PASS',candidate_sha256=survey['candidate_field_metadata_sha256'],original_resources_sha256=survey['original_resources_sha256'],actual_class_observation_run=40374543207,actual_class_observation_candidate_sha256=probe['candidate_sha256'],source_values_changed=False,project_changed=False,planned_prefabs=len(plans),planned_field_entries=sum(p['original_field_count']for p in plans),script_classes=[dict(guid=g,fileID=f,actual_type=t)for(g,f),t in sorted(script_classes.items())],sprite_proofs=list(sprite_proofs.values()),plans=plans,quarantined=gaps)
(G/'ORIGINAL-PLANT-BINDING-PLAN.json').write_bytes((json.dumps(result,indent=2,ensure_ascii=False)+'\n').encode());print(json.dumps({k:v for k,v in result.items()if k not in ['plans','script_classes']}))
