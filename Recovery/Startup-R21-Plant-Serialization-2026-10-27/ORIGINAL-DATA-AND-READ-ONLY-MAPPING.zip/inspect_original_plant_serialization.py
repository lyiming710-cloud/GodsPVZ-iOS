"""Independent resource diagnosis. No game/project/assembly writes.
Generate a type tree from the already source-checked field metadata, decode
original serialized Plant bytes, and require a byte-exact round trip.
"""
from pathlib import Path
import hashlib,json,sys,zipfile
G=Path(__file__).resolve().parent;W=G.parent;ROOT=W.parents[1]
sys.path[:0]=[str(G/'type-tree-tool'),str(W/'python-deps'),str(ROOT/'audit/stage9-native3/python-deps')]
import dnfile,UnityPy
from UnityPy.helpers.TypeTreeGenerator import TypeTreeGenerator
from UnityPy.streams import EndianBinaryWriter
from UnityPy.helpers import TypeTreeHelper

sha=lambda b:hashlib.sha256(b).hexdigest()
candidate=W/'startup-r21-ui-batch100/authored1.dll';assert sha(candidate.read_bytes())=='75160a3233f1e1ab13a44f712efb4b47fdeb9b57bd38fa25f180276bb7b50e15'
g=TypeTreeGenerator('2022.3.44f1');seen={};loaded=[]
paths=[candidate]+sorted((ROOT/'audit/local-preflight/exact-editor-tools/aot-resolver').glob('*.dll'))+sorted((ROOT/'audit/local-preflight/exact-editor-tools/resolver').glob('*.dll'))+sorted((ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support').glob('*.dll'))
for p in paths:
 pe=dnfile.dnPE(str(p));table=pe.net.mdtables.Assembly
 if table is None:continue
 identity=str(table.rows[0].Name);pe.close()
 if identity in seen:continue
 seen[identity]=p;data=p.read_bytes();g.load_dll(data);loaded.append(dict(file=str(p.relative_to(ROOT)),assembly=identity,sha256=sha(data)))
print('LOADED',len(loaded),flush=True)
tree=g.get_nodes_up('GodsPVZRuntime1.dll','Plant');(G/'PLANT-TYPE-TREE.json').write_text(g.get_nodes_as_json('GodsPVZRuntime1.dll','Plant'),'utf-8')
with zipfile.ZipFile(ROOT/'GodsPVZ_1.0.2.zip')as z:
 b=z.read(next(n for n in z.namelist()if n.endswith('/resources.assets')))
env=UnityPy.load(b);objects={o.path_id:o for o in env.objects};obj=objects[15826];assert obj.type.name=='MonoBehaviour'
decoded=obj.read_typetree(tree,check_read=True);writer=EndianBinaryWriter(endian='<');TypeTreeHelper.write_typetree(decoded,tree,writer);rebuilt=writer.bytes;raw=obj.get_raw_data()
assert rebuilt==raw,('ROUND_TRIP_FAILED',len(rebuilt),len(raw))
report=dict(scope='ORIGINAL_PLANT_SERIALIZED_VALUES_READ_ONLY_NOT_GAMEPLAY_OR_RESOURCE_REPAIR',candidate_field_metadata_sha256=sha(candidate.read_bytes()),original_resources_sha256=sha(b),original_component_path_id=obj.path_id,original_component_bytes=len(raw),original_component_sha256=sha(raw),type_tree_generator_version='0.0.10',wheel_sha256='e96003e973c8d52d221b4ae50f377bcaf7538f2098e437d5383a1b7f13fa72ba',references=loaded,byte_exact_round_trip=True,decoded=decoded,game_dll_changed=False,project_files_changed=False)
(G/'ORIGINAL-PLANT-SERIALIZATION.json').write_bytes((json.dumps(report,indent=2,ensure_ascii=False)+'\n').encode())
print(json.dumps(dict(bytes=len(raw),decoded_fields=len(decoded),animationGroup=decoded.get('animationGroup'),ani_aniPart=decoded.get('ani_aniPart'),ID=decoded.get('ID'),round_trip=True)))
