from pathlib import Path
import hashlib,json,sys,zipfile,copy
G=Path(__file__).resolve().parent;W=G.parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113';sys.path[:0]=[str(R/'scripts/actions'),str(W/'tool-deps')]
import yaml
from restore_startup_r21_plant_fields import patch,restore
plan_path=G/'ORIGINAL-PLANT-BINDING-PLAN.json';plan=json.loads(plan_path.read_bytes());capture=zipfile.ZipFile(next((W/'r21-source-run-40368892424').rglob('r21-source-prefabs-scenes-audio-metadata.zip')))
project=G/'source-restoration-check-v2';assert not project.exists();project.mkdir()
for n in capture.namelist():
 if n.startswith('Assets/'):
  p=project/n;p.parent.mkdir(exist_ok=True,parents=True);p.write_bytes(capture.read(n))
p=project/'ProjectSettings/ProjectVersion.txt';p.parent.mkdir();p.write_bytes(b'm_EditorVersion: 2022.3.44f1c1\n');(project/'Assets/Plugins/GodsPVZRuntime1.dll').write_bytes((W/'startup-r21-ui-batch100/authored1.dll').read_bytes())
full=zipfile.ZipFile(W/'R3-STARTUP-TEXT-40067634181.zip')
for row in plan['sprite_proofs']:
 for rel in [row['source_path'],row['source_path']+'.meta']:
  p=project/rel;p.parent.mkdir(exist_ok=True,parents=True);p.write_bytes(full.read('project-text/'+rel))
restore(project,plan_path,G/'source-restoration-check-output-v2')
def compare(a,b,path):
 if isinstance(a,dict):assert isinstance(b,dict)and set(a)==set(b),(path,'keys');[compare(v,b[k],path+'.'+k)for k,v in a.items()]
 elif isinstance(a,list):assert isinstance(b,list)and len(a)==len(b),(path,'length');[compare(v,b[i],path+'['+str(i)+']')for i,v in enumerate(a)]
 elif isinstance(a,(int,float)):assert float(a)==float(b),(path,a,b)
 elif a is None:assert b in [None,'null'],(path,a,b)
 else:assert a==b,(path,a,b)
for row in plan['plans']:
 data=(project/row['source_path']).read_bytes();text=data.decode();import re
 heads=list(re.finditer(r'(?m)^--- !u!(\d+) &(-?\d+)[^\r\n]*\r?$',text));i=next(i for i,h in enumerate(heads)if int(h[2])==row['source_owner']);block=text[heads[i].end():heads[i+1].start()if i+1<len(heads)else len(text)];decoded=yaml.load(block,Loader=yaml.BaseLoader)['MonoBehaviour'];fields={k:v for k,v in decoded.items()if not k.startswith('m_')};compare(row['fields'],fields,row['resource'])
controls=[];row=plan['plans'][0];data=capture.read(row['source_path'])
for name,change in [('wrong_owner',lambda r:r.update(source_owner=1)),('wrong_owner_hash',lambda r:r.update(source_owner_body_sha256='0'*64)),('partial_field_set',lambda r:r['fields'].pop('ID'))]:
 damaged=copy.deepcopy(row);change(damaged)
 try:patch(data,damaged);raise AssertionError('Control falsely accepted: '+name)
 except ValueError as e:controls.append(dict(name=name,rejected=True,error=str(e)))
result=dict(scope='COPIED_SOURCE_YAML_RESTORATION_AND_BOUNDARY_CHECKS_NOT_UNITY_OR_GAMEPLAY',planned_prefabs=9,restored_fields=846,parsed_values_match_plan=True,controls=controls,game_dll_changed=False,original_inputs_changed=False,plan_sha256=hashlib.sha256(plan_path.read_bytes()).hexdigest(),unity_started=False)
changed=copy.deepcopy(plan);changed['plans'][0]['fields']['ID']=999;bad=G/'UNQUALIFIED-WRONG-ID-PLAN.json';bad.write_bytes((json.dumps(changed,indent=2)+'\n').encode())
try:restore(project,bad,G/'must-not-create-wrong-plan');raise AssertionError('Changed original plan accepted')
except ValueError as e:controls.append(dict(name='changed_original_ID_in_plan',rejected=True,error=str(e)));assert not(G/'must-not-create-wrong-plan').exists()
(G/'SOURCE-RESTORATION-CHECK-V2.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result))
