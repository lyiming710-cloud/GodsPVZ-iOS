"""Compile the gameplay probe against the hash-bound real Editor API modules.
This preflight does not start Unity or exercise a game method.
"""
from pathlib import Path
import hashlib,json,subprocess
G=Path(__file__).resolve().parent;W=G.parent;ROOT=W.parents[1]
src=ROOT/'audit/repo-native113/scripts/actions/GodsPVZGameplayAudit.cs'
r=ROOT/'audit/local-preflight/exact-editor-tools/resolver';a=r.parent/'aot-resolver'
refs=[a/n for n in ['mscorlib.dll','System.dll','System.Core.dll','netstandard.dll']]
refs += [r/n for n in ['UnityEditor.CoreModule.dll','UnityEngine.CoreModule.dll','UnityEngine.UIModule.dll','UnityEngine.JSONSerializeModule.dll','UnityEngine.InputLegacyModule.dll','UnityEngine.ScreenCaptureModule.dll']]
known={Path(row['path']).name:row['sha256']for row in json.loads((W/'asset-audit-40081048209/HELPER-COMPILATION.json').read_bytes())['references']}
for p in refs[4:]:assert hashlib.sha256(p.read_bytes()).hexdigest()==known[p.name],p.name
stem='GAMEPLAY-HELPER-API';i=1
while(G/(stem+'.json')).exists():stem='GAMEPLAY-HELPER-API-'+str(i);i+=1
cmd=[str(ROOT/'.local/dotnet10/dotnet.exe'),str(ROOT/'.local/dotnet10/sdk/10.0.402/Roslyn/bincore/csc.dll'),'/noconfig','/nostdlib','/target:library','/langversion:9.0','/utf8output','/preferreduilang:en-US','/define:UNITY_EDITOR','/out:'+str(G/(stem+'.dll'))]+['/r:'+str(p)for p in refs]+[str(src)]
proc=subprocess.run(cmd,capture_output=True);(G/(stem+'.log')).write_bytes(proc.stdout+proc.stderr)
j=dict(scope='EXACT_EDITOR_GAMEPLAY_HELPER_API_COMPILATION_ONLY',exit=proc.returncode,source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),references=[dict(file=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in refs],unity_started=False,game_changed=False)
(G/(stem+'.json')).write_bytes((json.dumps(j,indent=2)+'\n').encode());print((proc.stdout+proc.stderr).decode('utf-8',errors='replace'));print(json.dumps(j));raise SystemExit(proc.returncode)
