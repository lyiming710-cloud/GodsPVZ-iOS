"""Four unchanged original callers; all leaf substitutions are explicit."""
from pathlib import Path
import collections,ctypes as C,functools,hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
im=NativeImage();state={};ids=[0x1c6,0x31a,0x686,0x584]
cfgs={r:json.loads((W/'startup-r19-batch100/native-source-complete'/f'0x{0x6000000|r:08X}.json').read_bytes()) for r in ids}
fields=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_bytes())
def js(p,v):p.write_bytes((json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode())
@functools.lru_cache(None)
def off(owner,name):
    a=[r for r in fields if r['namespace']=='' and r['type']==owner and r['name']==name];assert len(a)==1,(owner,name);return a[0]['offset']
def tag(p):return 'null' if not p else state['tags'][p]
def n(k,d=0):return state['q'].get(k,d)
def mode():return state['q']['mode']
def make(label,size=1024):
    p=im.alloc(size);state['tags'][p]=label;return p
def at(label,owner,name):return state[label]+off(owner,name)
def byte(p,value=None):
    if value is not None:C.c_ubyte.from_address(p).value=bool(value)
    return bool(C.c_ubyte.from_address(p).value)
def array(values,kind='ref'):
    stride={'ref':8,'int':4,'bool':1}[kind];p=im.alloc(32+len(values)*stride);put64(p+0x18,len(values))
    for i,v in enumerate(values):
        if kind=='ref':put64(p+0x20+i*8,v)
        elif kind=='int':put32(p+0x20+i*4,v)
        else:byte(p+0x20+i,v)
    return p
def listing(values,kind='ref'):
    p=im.alloc(32);put64(p+0x10,array(values,kind));put32(p+0x18,len(values));put32(p+0x1c,0);state['capacity'][p]=len(values);return p
def list_state(p):return dict(items=[tag(get64(get64(p+0x10)+0x20+i*8)) for i in range(get32(p+0x18))],size=get32(p+0x18),capacity=state['capacity'][p],version=get32(p+0x1c))
def exists(p,method):
    assert not method;v=bool(p and state['live'].get(p,True));state['trace'].append('Exists:'+tag(p)+':'+str(int(v)))
    if p in [state['board'],state['other-board']] and mode()=='predicate-fields':put64(at('device','Device','board'),state['other-board'])
    if p in [state['manager'],state['other-manager']] and mode()=='manager-fields':put32(at('device','Device','gridX'),-3);put32(at('device','Device','gridY'),13)
    if p==state['zombie'] and mode()=='zombie-fields':put64(at('zombie','Zombie','buffManager'),state['other-buffs'])
    return v
def equal(p,b,method):assert not b;return not exists(p,method)
def unequal(p,b,method):assert not b;return exists(p,method)
def get_zombie(p,index,method):
    assert p==state['mouse'] and not method;state['trace'].append('GetZombie:'+str(index))
    if mode()=='query-fields':put64(at('mouse','MouseManager','skillOnHandOwnerPlant'),state['other-plant'])
    return state['zombie'] if n('zombie',1) else 0
def damage(p,projectile,index,method):assert not projectile and not method;state['trace'].append('Damage:'+tag(p)+':'+str(index));return state['damage'] if n('damage',1) else 0
def get_device(p,allow,damage,method):assert p==state['mouse'] and not method;state['trace'].append('GetDevice:'+str(int(allow))+':'+tag(damage));return state['device'] if n('device',1) else 0
def random_range(low,high,method):
    assert not method;state['trace'].append('Range:'+str(low)+':'+str(high))
    if mode()=='random-fields':put64(at('device','Device','board'),state['other-board']);put64(state['enemy']+off('EnemyManager','zombieTypes'),state['other-types'])
    return n('random_index')
def int_item(p,index,method):assert method in handles and 0<=index<get32(p+0x18);return get32(get64(p+0x10)+0x20+index*4)
def place(p,kind,x,y,method):assert not method;state['trace'].append('Place:'+tag(p)+':'+str(kind)+':'+str(x)+':'+str(y));return state['zombie'] if n('zombie',1) else 0
def alloc_hide(cls):assert cls in handles;state['trace'].append('AllocateHide');return make('hide')
def hide_ctor(p,on,zombie,method):assert not method;state['hides'][p]=dict(on=bool(on),owner=tag(zombie));state['trace'].append('Hide:'+str(int(on))+':'+tag(zombie))
def add_buff(p,buff,method):assert not method;v=state['hides'][buff];state['added'][p].append(v);state['trace'].append('Add:'+tag(p)+':'+str(int(v['on']))+':'+v['owner'])
def active(p,on,method):
    assert not method;state['active'][p]=bool(on);state['trace'].append('Active:'+tag(p)+':'+str(int(on)))
    if p==state['tip'] and mode()=='tip-fields':
        for name,label in [('playerSave','other-save'),('seedChooserScreen','other-chooser'),('card_ChooseList','other-cards')]:put64(at('prepare','PrepareUIController',name),state[label])
    if p==state['chooser-object'] and mode()=='chooser-fields':put64(at('prepare','PrepareUIController','seedChooserScreen'),state['other-chooser']);put64(at('prepare','PrepareUIController','card_ChooseList'),state['other-cards'])
def gameobject(p,method):
    assert not method;state['trace'].append('Object:'+tag(p))
    if p==state['prepare'] and mode()=='component-fields':put64(at('prepare','PrepareUIController','seedChooserScreen'),state['other-chooser'])
    return state['objects'][p]
def prechoose(p,cards,index,method):assert not method;state['trace'].append('Prechoose:'+tag(p)+':'+tag(cards)+':'+str(index))
def create_supplies(p,method):
    assert p==state['detail'] and not method;s=get64(at('detail','Almanac_PlantDetail','skillSystem'));state['trace'].append('CreateSupplies:'+str(int(byte(s+off('Almanac_SkillSystem','skillUpPreview')))))
    if mode()=='create-fields':
        for name,label in [('skillSystem','other-skill'),('button_SkillUp','other-button'),('levelSelector','other-selector'),('suppliesItemList','other-items')]:put64(at('detail','Almanac_PlantDetail',name),state[label])
def supplied(p,method):assert p==state['detail'] and not method;state['trace'].append('Supplied:'+str(n('supplied')));return n('supplied')==1
def interact(p,on,method):
    assert not method;state['interactable'][p]=bool(on);state['trace'].append('Interact:'+tag(p)+':'+str(int(on)))
    if mode()=='interact-fields':put64(at('detail','Almanac_PlantDetail','levelSelector'),state['other-selector'])
def item(p,index,method):assert method in handles and 0<=index<get32(p+0x18);return get64(get64(p+0x10)+0x20+index*8)
def destroy(p,method):
    assert not method;state['trace'].append('Destroy:'+tag(p));state['destroyed'].add(tag(p))
    if not state['destroy_changed']:
        state['destroy_changed']=True
        if mode()=='destroy-list':put64(at('detail','Almanac_PlantDetail','suppliesItemList'),state['other-items'])
def clear_array(p,start,length,method):
    assert not method and start==0 and 0<=length<=get32(p+0x18)
    for i in range(length):put64(p+0x20+i*8,0)
def tutorial(p):a=get64(p+off('Save','key_Tutorial'));return [byte(a+0x20+i) for i in range(get32(a+0x18))]
def snapshot(rid):
    if rid==0x1c6:return dict(owner=tag(get64(at('mouse','MouseManager','skillOnHandOwnerPlant'))),zombie_selected=byte(at('zombie','Zombie','selected_Bright')),device_selected=byte(at('device','Device','selected_Bright')))
    if rid==0x31a:return dict(board=tag(get64(at('device','Device','board'))),x=get32(at('device','Device','gridX')),y=get32(at('device','Device','gridY')),types_root='other' if get64(state['enemy']+off('EnemyManager','zombieTypes'))==state['other-types'] else 'initial',buffs=state['added'][state['buffs']],other_buffs=state['added'][state['other-buffs']],zombie_buffs=tag(get64(at('zombie','Zombie','buffManager'))))
    if rid==0x686:return dict(save='other' if get64(at('prepare','PrepareUIController','playerSave'))==state['other-save'] else 'initial',tutorial=tutorial(state['save']),other_tutorial=tutorial(state['other-save']),chooser=tag(get64(at('prepare','PrepareUIController','seedChooserScreen'))),cards='other' if get64(at('prepare','PrepareUIController','card_ChooseList'))==state['other-cards'] else 'initial',tip=state['active'][state['tip']],prepare=state['active'][state['prepare-object']],choose=state['active'][state['chooser-object']],other_choose=state['active'][state['other-chooser-object']])
    return dict(target=get32(at('detail','Almanac_PlantDetail','targetSkillLevel')),preview=byte(at('skill','Almanac_SkillSystem','skillUpPreview')),other_preview=byte(at('other-skill','Almanac_SkillSystem','skillUpPreview')),skill_root='other' if get64(at('detail','Almanac_PlantDetail','skillSystem'))==state['other-skill'] else 'initial',button=tag(get64(at('detail','Almanac_PlantDetail','button_SkillUp'))),interactable=state['interactable'][state['button']],other_interactable=state['interactable'][state['other-button']],selector=tag(get64(at('detail','Almanac_PlantDetail','levelSelector'))),active=state['active'][state['selector']],other_active=state['active'][state['other-selector']],root='other' if get64(at('detail','Almanac_PlantDetail','suppliesItemList'))==state['other-items'] else 'initial',initial=list_state(state['items']),other=list_state(state['other-items']),destroyed=sorted(state['destroyed']))
try:
    dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True;slots=set();handles=set()
    for cfg in cfgs.values():
        for row in cfg['instructions']:
            i=next(dis.disasm(bytes.fromhex(row['bytes']),int(row['va'],16)))
            if i.mnemonic not in ['mov','lea']:continue
            for o in i.operands:
                if o.type!=X86_OP_MEM or o.mem.base!=X86_REG_RIP:continue
                a=i.address+i.size+o.mem.disp;raw=im.pe.get_data(a-im.base,8)
                if len(raw)!=8:continue
                code=int.from_bytes(raw,'little')
                if code>0xffffffff or code>>29 not in range(1,8) or a in slots:continue
                assert code>>29!=5,'No string literal substitution expected';slots.add(a);handles.add(im.class_slot(a))
    def init(a):assert a in slots,hex(a)
    im.hook(0x18024fef0,None,[P],init);im.hook(0x1802501e0,None,[P],lambda p:None)
    im.hook(0x18131f760,C.c_bool,[P,P,P],equal);im.hook(0x18131f900,C.c_bool,[P,P,P],unequal);im.hook(0x18131f870,C.c_bool,[P,P],exists)
    im.hook(0x18031ee10,P,[P,I,P],get_zombie);im.hook(0x180350e20,P,[P,P,I,P],damage);im.hook(0x18031e300,P,[P,C.c_bool,P,P],get_device)
    im.hook(0x18130d310,I,[I,I,P],random_range);im.hook(0x180836790,I,[P,I,P],int_item);im.hook(0x1803421e0,P,[P,I,I,I,P],place);im.hook(0x180250100,P,[P],alloc_hide);im.hook(0x18031c900,None,[P,C.c_bool,P,P],hide_ctor);im.hook(0x180310190,None,[P,P,P],add_buff)
    im.hook(0x18131bad0,None,[P,C.c_bool,P],active);im.hook(0x1813044d0,P,[P,P],gameobject);im.hook(0x1803abe20,None,[P,P,I,P],prechoose)
    im.hook(0x18038c3f0,None,[P,P],create_supplies);im.hook(0x18038f0c0,C.c_bool,[P,P],supplied);im.hook(0x18156cc70,None,[P,C.c_bool,P],interact);im.hook(0x180825710,P,[P,I,P],item);im.hook(0x18131e940,None,[P,P],destroy);im.hook(0x180cb86f0,None,[P,I,I,P],clear_array)
    for rid,cfg in cfgs.items():im.verify_caller(rid,int(cfg['entry'],16),cfg)
    rows=[];cases=json.loads((Q/'CASES.json').read_bytes())
    for q in cases:
        if not q['native_supported']:continue
        if '--trace-cases' in sys.argv:print(json.dumps(dict(starting_case=q['name'],token=q['token'])),flush=True)
        state.clear();state.update(q=q,tags={},capacity={},live={},trace=[],hides={},added={},active={},objects={},interactable={},destroyed=set(),destroy_changed=False)
        for label in ['mouse','plant','other-plant','zombie','device','damage','board','other-board','enemy','other-enemy','manager','other-manager','buffs','other-buffs','save','other-save','prepare','chooser','other-chooser','tip','prepare-object','chooser-object','other-chooser-object','skill','other-skill','button','other-button','selector','other-selector','detail','plant-save']:state[label]=make(label)
        for label,key in [('zombie','zombie'),('device','device'),('board','board'),('manager','manager')]:state['live'][state[label]]=n(key,1)==1
        for label in ['buffs','other-buffs']:state['added'][state[label]]=[]
        put32(at('plant','Plant','ID'),n('id'));put32(at('other-plant','Plant','ID'),99);put64(at('mouse','MouseManager','skillOnHandOwnerPlant'),state['plant']);byte(at('zombie','Zombie','selected_Bright'),n('selected'));byte(at('device','Device','selected_Bright'),n('selected'));put64(at('zombie','Zombie','buffManager'),state['buffs'])
        state['types']=listing([11,22,33],'int');state['other-types']=listing([91,92,93],'int')
        for b,e,m,types in [('board','enemy','manager','types'),('other-board','other-enemy','other-manager','other-types')]:
            put64(state[b]+off('Board','enemyManager'),state[e]);put64(state[b]+off('Board','zombieManager'),state[m] if (b=='other-board' or n('manager',1)) else 0);put64(state[e]+off('EnemyManager','zombieTypes'),state[types])
        put64(at('device','Device','board'),state['board'] if n('board',1) else 0);put32(at('device','Device','gridX'),4);put32(at('device','Device','gridY'),7)
        for s,first in [('save',bool(n('tutorial'))),('other-save',False)]:put64(state[s]+off('Save','key_Tutorial'),array([first]+[False]*(n('length',1)-1),'bool'))
        for p,g in [('prepare','prepare-object'),('chooser','chooser-object'),('other-chooser','other-chooser-object')]:state['objects'][state[p]]=state[g]
        state['cards']=listing([]);state['other-cards']=listing([]);state['tags'][state['cards']]='cards';state['tags'][state['other-cards']]='other-cards'
        for name,label in [('playerSave','save'),('seedChooserScreen','chooser'),('card_ChooseList','cards'),('tip_FastChoose','tip')]:put64(at('prepare','PrepareUIController',name),state[label])
        for label in ['tip','prepare-object','chooser-object','other-chooser-object','selector','other-selector']:state['active'][state[label]]=None
        for label in ['button','other-button']:state['interactable'][state[label]]=True
        byte(at('skill','Almanac_SkillSystem','skillUpPreview'),n('initial_preview'));byte(at('other-skill','Almanac_SkillSystem','skillUpPreview'),False);put32(at('plant-save','PlantSave','skillLevel'),n('current'))
        for label,num,prefix in [('items',n('items'),'item'),('other-items',2,'other-item')]:
            vals=[make(prefix+str(i)) for i in range(num)]
            for p in vals:state['objects'][p]=make(tag(p)+'-object')
            state[label]=listing(vals)
        for name,label in [('plantSave','plant-save'),('skillSystem','skill'),('button_SkillUp','button'),('levelSelector','selector'),('suppliesItemList','items')]:put64(at('detail','Almanac_PlantDetail',name),state[label])
        put32(at('detail','Almanac_PlantDetail','targetSkillLevel'),-7)
        rid=int(q['token'],16)&0xffffff;entry=int(cfgs[rid]['entry'],16)
        if rid==0x584:C.CFUNCTYPE(None,P,I,P)(entry)(state['detail'],n('target'),None)
        else:C.CFUNCTYPE(None,P,P)(entry)(state[{0x1c6:'mouse',0x31a:'device',0x686:'prepare'}[rid]],None)
        assert not im.errors,(q,im.errors);rows.append(dict(name=q['name'],token=q['token'],error=None,trace=list(state['trace']),state=snapshot(rid)))
    actual=json.loads(Path(sys.argv[1]).read_bytes());digest=hashlib.sha256((W/'startup-r20-sites100/authored3.dll').read_bytes()).hexdigest();assert actual['candidate_sha256']==digest
    found={r['name']:r for r in actual['results']};assert len(found)==len(cases) and set(found)=={c['name'] for c in cases}
    diff=[dict(original=r,actual=found[r['name']]) for r in rows if r!=found[r['name']]]
    report=dict(scope='FOUR_COMPLETE_ORIGINAL_SELECTION_SUMMON_SEED_AND_SKILL_UI_CALLERS',candidate_sha256=digest,original_pc_sha256=hashlib.sha256(im.raw).hexdigest(),caller_bytes_verified=4,
        normal_records=len(rows),per_method=dict(collections.Counter(r['token'] for r in rows)),results=rows,differences=diff,callback_errors=im.errors,
        managed_only_exception_records=[found[c['name']] for c in cases if not c['native_supported']],
        controlled_leaves=['Zombie/device queries, Damage, RNG, zombie placement and Buff initialization/addition','Unity lifetime/component/activation/interactable/destruction','Supplies construction/testing and list indexing/Array.Clear'],
        limitations=['No full leaf behavior, native SEH, Unity engine execution or actual UI/gameplay acceptance','Finite contract inputs and callback mutation cases only'],formal_or_product_acceptance=False)
    js(Path(sys.argv[2]),report);print(json.dumps({k:v for k,v in report.items() if k not in ['results','differences','managed_only_exception_records']}));print('differences',len(diff));assert not diff
finally:im.close()
