from pathlib import Path
import collections,itertools,json
Q=Path(__file__).resolve().parent;cases=[]
def add(rid,mode='none',native=True,**kw):cases.append(dict(name=f's{len(cases):05d}',token=f'0x{0x6000000|rid:08X}',mode=mode,native_supported=native,**kw))
for ident,zombie,device,selected,damage,mode in itertools.product([-1,0,5],range(3),range(3),range(2),range(2),['none','query-fields']):add(0x1c6,mode=mode,id=ident,zombie=zombie,device=device,selected=selected,damage=damage)
add(0x1c6,native=False,id=0,plant=0)
for board,manager,zombie,index,mode in itertools.product(range(3),range(3),range(3),[0,2],['none','predicate-fields','random-fields','manager-fields','zombie-fields']):add(0x31a,mode=mode,board=board,manager=manager,zombie=zombie,random_index=index)
for tutorial,length,mode in itertools.product(range(2),[1,3],['none','tip-fields','chooser-fields','component-fields']):add(0x686,mode=mode,tutorial=tutorial,length=length)
add(0x686,native=False,tutorial=0,length=1,save=0);add(0x686,native=False,tutorial=0,length=0)
for target,current,supplied,items,mode in itertools.product([-1,0,1,3],[0,1,3],range(2),[0,1,3],['none','create-fields','interact-fields','destroy-list']):add(0x584,mode=mode,target=target,current=current,supplied=supplied,items=items,initial_preview=1)
add(0x584,native=False,target=1,current=0,plant_save=0)
(Q/'CASES.json').write_bytes((json.dumps(cases,indent=2)+'\n').encode())
j=dict(scope='FOUR_ALREADY_AUTHORED_R19_PENDING_CALLER_PROFILES',new_game_code_changes=0,normal_native_records=sum(c['native_supported'] for c in cases),managed_only_records=sum(not c['native_supported'] for c in cases),per_method=dict(collections.Counter(c['token'] for c in cases if c['native_supported'])),finite_engine_and_game_leaf_contracts_only=True,formal_or_product_acceptance=False)
(Q/'INPUTS.json').write_bytes((json.dumps(j,indent=2)+'\n').encode());print(json.dumps(j))
