"""Publish four more exact-candidate finite profiles, without changing game IL."""
from pathlib import Path
import json
from archive_support import sha,js,pack,manifest,variants
W=Path(__file__).resolve().parent;ROOT=W.parents[1];Q=W/'r19-pending-supplement2-2026-10-26';R=ROOT/'audit/repo-native113';D=R/'Recovery/Startup-R19-Pending4-2026-10-26';H=R/'Recovery/Startup-R19-Batch100-2026-10-25';T=R/'Recovery/Startup-R20-Sites104-2026-10-26'
assert not D.exists();D.mkdir();(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text\n*.md -text\n*.zip -text\n')
native=json.loads((Q/'NATIVE-ATTEMPT1.json').read_bytes());controls=json.loads((Q/'controls/RESULT.json').read_bytes());binding=json.loads((Q/'R19-AND-R20-BINDING.json').read_bytes())
assert not native['differences'] and native['normal_records']==790 and len(native['per_method'])==4
assert controls['controls']==controls['detected']==4 and controls['process_failures']==0 and binding['all_rows_identical']
current=(W/'startup-r20-sites100/authored3.dll').read_bytes();parent=(W/'startup-r19-batch100/candidate9.dll').read_bytes();assert sha(current)==binding['current_sha256'] and sha(parent)==binding['parent_sha256']
for p,h in [(W/'startup-r5/runtime-common/Rehost.cs','59b1e80892d0038ee188f0ef36d1af25ce37ae6df71016ba6617cc221ca51d40'),(ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py','2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14'),(ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/member-bin/MemberAccess.dll','d21ae9d0b39cbadc7c0412c87f41942e86d7eff25b22212c2c64cdd1fc4833db')]:assert sha(p.read_bytes())==h
delta=variants(Q/'controls',current);assert len(delta)==4;js(Q/'PHYSICAL-CONTROL-DELTAS.json',delta)
for p,name in [(Q/'INPUTS.json','INPUTS.json'),(Q/'NATIVE-ATTEMPT1.json','NATIVE.json'),(Q/'R19-AND-R20-BINDING.json','R19-AND-R20-BINDING.json'),(Q/'controls/RESULT.json','CONTROLS.json'),(Q/'PHYSICAL-CONTROL-DELTAS.json','PHYSICAL-CONTROL-DELTAS.json')]:(D/name).write_bytes(p.read_bytes())
files=[]
for p in sorted(Q.rglob('*')):
    if not p.is_file() or any(x in p.parts for x in ['obj','__pycache__']):continue
    if p.suffix=='.dll' and 'bin' not in p.parts:continue
    files.append(('r19-pending-supplement2/'+p.relative_to(Q).as_posix(),p.read_bytes()))
for token in native['per_method']:
    for suffix in ['.json','.txt']:
        p=W/'startup-r19-batch100/native-source-complete'/(token+suffix);files.append(('original-native/'+p.name,p.read_bytes()))
files += [('frozen-runtime/Rehost.cs',(W/'startup-r5/runtime-common/Rehost.cs').read_bytes()),('frozen-runtime/native_runtime_common.py',(W/'startup-r5/native_runtime_common.py').read_bytes()),(Path(__file__).name,Path(__file__).read_bytes())]
pack(D/'SOURCE-AND-RAW-EVIDENCE.zip',files)
pending=json.loads((H/'CURRENT-PENDING-RUNTIME-PROFILES.json').read_bytes());assert pending['methods']==30
assert set(native['per_method'])<={r['token'] for r in pending['rows']};remaining=[r for r in pending['rows'] if r['token'] not in native['per_method']];assert len(remaining)==26
js(H/'CURRENT-PENDING-RUNTIME-PROFILES.json',dict(candidate_sha256=sha(parent),methods=26,not_a_count_of_confirmed_remaining_game_bugs=True,added_supplement='../'+D.name,rows=remaining))
status=json.loads((H/'PROGRESS.json').read_bytes());assert status['finite_comparison_method_union']==70 and status['total_native_finite_comparison_records']==18938
status.update(status='HUNDRED_CONSTRUCTED_SEVENTY_FOUR_FINITE_PROFILES_BATCH_QUALIFICATION_PENDING',finite_comparison_method_union=74,other_runtime_profile_count=26,total_native_finite_comparison_records=19728,
    finite_original_native_vs_complete_cil_additional_methods=39,pending4_normal_records=790,pending4_managed_only_records=4,pending4_physical_controls=4,pending4_detected_controls=4,
    total_physical_controls_including_foreach_and_new_profiles=status['total_physical_controls_including_foreach_and_new_profiles']+4,total_runtime_differences_including_supplements=status['total_runtime_differences_including_supplements']+4)
js(H/'PROGRESS.json',status)
js(D/'PROGRESS.json',dict(status='FOUR_FINITE_FULL_CALLER_PROFILES_PASS_PRODUCT_NOT_PROMOTED',parent_candidate_sha256=sha(parent),current_candidate_sha256=sha(current),new_game_code_changes=0,methods=4,native_normal_records=790,managed_only_records=4,controls_detected=4,r19_finite_union=74,r19_native_comparison_records=19728,r19_pending_profiles=26,frozen_tools_unchanged=True,unity=False,compiler_not_rerun_because_no_game_bytes_changed=True,ipa=None,ipad_acceptance=False))
(D/'README.md').write_bytes('''# R19 再补四个完整调用方

游戏 DLL 保持固定 R19 candidate9 和当前 R20 authored3 的原字节。两个候选均实际发射并执行完整 CIL，794 条记录逐项相同；其中790条正常记录与完整原版 PC 调用方一致，四条 CLR-only 异常单列。冻结 Rehost、类型及成员审核器未改。

| Token | 方法 | 原版正常记录 |
|---|---|---:|
| 0x060001C6 | MouseManager.Update_SkillOnHand | 216 |
| 0x0600031A | Device.DC_PortalSummon | 270 |
| 0x06000686 | PrepareUIController.SeedChoose | 16 |
| 0x06000584 | Almanac_PlantDetail.SetSkillUpPreview | 288 |

检查技能所有者重新读取、Zombie/Device 高亮分支、Damage 的 -1 参数；传送门在随机回调前捕获列表并在回调后重读 board/manager/坐标，伪空判断、Hide 与 Buff 参数；教程数组写回、界面激活和最后 -1 预选索引；技能预览状态、资源/按钮回调后的字段重载、销毁与真实 List.Clear 结果。原版调用方指令和方法指针在安装叶函数桩之后逐字节检查，明确保留外部尾调用边界。

四个物理单点故障全部产生运行差异：Damage 参数 -1 改0（48条）、Hide false改true（18条）、预选索引 -1改0（16条）、漏 Clear（72条）。各故障进程正常退出，其他方法无差异。完整变体可从当前候选与增量文件重建并按SHA核验。

游戏查询/伤害/RNG/生成/Buff、Unity 生命周期与组件/UI操作、资源构造与库存判断等叶函数是受控契约，未证明其内部或实际引擎行为。没有 Windows SEH、Unity渲染或普遍等价结论。R19有限 profile 从70增至74，原版正常记录从18,938增至19,728，26个profile仍待完成；这些数量不是剩余bug数。

没有新增游戏改动，未重复跑候选字节未变的编译流程，没有新持证Editor导出、链接、IPA或iPad验收。后续新代码仍累计超过100处再集中检测。
'''.encode())
p=H/'README.md';text=p.read_text('utf-8');text+='\n## 再补四个待对照调用方\n\n[独立四方法补充](../Startup-R19-Pending4-2026-10-26/README.md) 记录790条正常原版对照、两个精确候选的794条CIL执行、四条CLR-only异常和四个已检测物理故障。有限联合数74、原版记录19,728，26个profile仍待完成。游戏候选和冻结工具不变。\n';p.write_bytes(text.encode())
progress=json.loads((T/'PROGRESS.json').read_bytes());progress.update(r19_runtime_profiles_still_pending=26,r19_additional_finite_profiles_verified_on_current_r20=9);js(T/'PROGRESS.json',progress)
queue=json.loads((T/'CURRENT-WORK-QUEUE.json').read_bytes())
for r in queue['rows']:
    if r['token'] in native['per_method']:
        assert r['parent_census_priority']=='P1_R19_RUNTIME_PROFILE';r.update(current_state='R19_BODY_FINITE_PROFILE_PASS_BOTH_EXACT_CANDIDATES_PRODUCT_PENDING',r19_runtime_pending=False,normal_native_records=native['per_method'][r['token']],current_required_action='Actual engine/product integration remains pending; finite full-caller supplement is archived')
queue.update(other_parent_followup_work_items=139,additional_parent_r19_profiles_completed=9);js(T/'CURRENT-WORK-QUEUE.json',queue)
p=R/'README.md';text=p.read_text('utf-8');assert 'Seventy methods now have 18,938' in text;text=text.replace('Seventy methods now have 18,938','Seventy-four methods now have 19,728').replace('Thirty other runtime profiles','Twenty-six other runtime profiles').replace('76 physical controls: 72 runtime differences','80 physical controls: 76 runtime differences');p.write_bytes(text.encode())
p=R/'Recovery/STATUS.md';text=p.read_text('utf-8');marker='## Latest checkpoint - 2026-10-26\n';text=text.replace(marker,marker+'\n[R19 pending-four supplement](Startup-R19-Pending4-2026-10-26/README.md): four more unchanged complete callers match790 normal original records, with both exact DLLs replayed. Four one-site physical faults are detected, four CLR-only exceptions remain separate. R19 finite union74 /19,728 records,26 pending. Across R19 supplements:80 controls comprise76 runtime differences,3 retained non-detections and1 source-EH guard. No game code/Unity/IPA/device promotion.\n',1);p.write_bytes(text.encode())
for d in [D,H,T]:manifest(d)
print(json.dumps(dict(r19_finite_methods=74,r19_native_records=19728,pending_profiles=26,new_game_code_changes=0)))
