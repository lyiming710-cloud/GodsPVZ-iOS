"""Bind an already exercised restricted Editor workflow to the exact R20 DLL."""
from pathlib import Path
import ast,json
from archive_support import sha,js,pack,manifest
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';D=R/'Recovery/Startup-R20-Editor-Diagnostic-2026-10-26';assert not D.exists();D.mkdir()
(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text\n*.md -text\n*.py -text\n*.yml -text\n*.zip -text\n')
old='6189387c6af11108eba9a9855bfd6d6af567ec000a4999d1ed1b0328ba0e1d08';new='d887b370c95c2966dc40d80648d85c286bb42d85004c32d095f64f004e095b37'
changes=[];files=[]
for name in ['prepare_startup_r8_unity.py','prepare_startup_r8_plugin.py']:
    src=R/'scripts/actions'/name;dest=R/'scripts/actions'/name.replace('r8','r20');assert not dest.exists();data=src.read_bytes();s=data.decode();assert s.count(old)==1;s=s.replace(old,new);ast.parse(s);dest.write_bytes(s.encode());changes.append(dict(parent=src.relative_to(R).as_posix(),parent_sha256=sha(data),derived=dest.relative_to(R).as_posix(),derived_sha256=sha(dest.read_bytes()),change='Only expected candidate SHA-256'))
    files.extend([(src.relative_to(R).as_posix(),data),(dest.relative_to(R).as_posix(),dest.read_bytes())])
src=R/'.github/workflows/startup-r8-editor-diagnostic.yml';registered=R/'.github/workflows/startup-r2-editor-diagnostic.yml';assert src.read_bytes()==registered.read_bytes();oldwf=src.read_bytes();(D/'PARENT-R8-EDITOR-WORKFLOW.yml').write_bytes(oldwf)
s=oldwf.decode();replacements=[(old,new),('Startup R8','Startup R20'),('startup-r8','startup-r20'),('STARTUP-R8','STARTUP-R20'),('bind_startup_r8_diagnostic.py','bind_startup_r20_diagnostic.py'),('prepare_startup_r8_unity.py','prepare_startup_r20_unity.py'),('prepare_startup_r8_plugin.py','prepare_startup_r20_plugin.py'),('Recovery/Bulk401-Generic-Repair-2026-10-24/BULK401-CANDIDATE.zip','Recovery/Startup-R20-Sites104-2026-10-26/STARTUP-R20-SITES104-CANDIDATE.zip')]
for before,after in replacements:assert before in s;s=s.replace(before,after)
registered.write_bytes(s.encode());copy=R/'.github/workflows/startup-r20-editor-diagnostic.yml';assert not copy.exists();copy.write_bytes(s.encode())
for p in [registered,copy,R/'scripts/actions/bind_startup_r20_diagnostic.py']:files.append((p.relative_to(R).as_posix(),p.read_bytes()))
files.append((Path(__file__).name,Path(__file__).read_bytes()));pack(D/'EDITOR-BINDING-SOURCES.zip',files)
js(D/'DERIVATION.json',dict(scope='R20_CANDIDATE_AND_EVIDENCE_BINDING_TO_PREVIOUSLY_EXECUTED_R8_EDITOR_DIAGNOSTIC',candidate_sha256=new,
    script_derivations=changes,parent_workflow_sha256=sha(oldwf),current_workflow_sha256=sha(registered.read_bytes()),workflow_replacements=[dict(before=a,after=b) for a,b in replacements],
    unity_version='2022.3.44f1c1',baseline_migration_package_guid_shader_controls_licensing_and_seat_return_unchanged=True,
    all_existing_helper_and_editor_assertions_retained=True,game_dll_changes=0,formal_or_product_promotion=False))
js(D/'PROGRESS.json',dict(status='PREPARED_NOT_DISPATCHED',candidate_sha256=new,unity_result='PENDING',ipa=None,ipad_acceptance=False))
(D/'README.md').write_bytes('''# R20 真实 Editor 启动诊断

当前 DLL 固定为 d887b370c95c2966dc40d80648d85c286bb42d85004c32d095f64f004e095b37，104处/8方法已先完成构造后通过本批有限运行对照和精确 Linux/Apple 全源码语法检查。新 binder 校验整个 R20 清单、内层 ZIP、目标类型/成员/JIT/隔离、768条正常对照、8个故障控制以及精确1029源码的两平台读回和34-error原始对照补跑。

沿用实际执行过的 R8 受限 Editor 流程：精确 R3/Unity China/iOS模块和软件GL上限、67项包GUID迁移、B001基线、插件GUID/文件名、资源/脚本引用、76项着色器编译和20项受控像素、真实MainMenu PlayMode。激活/归还席位、敏感信息清理、失败保留和所有原断言保持。两个工作副本注入工具仅替换预期DLL哈希。已登记入口 startup-r2-editor-diagnostic.yml 指向本次R20定义；R8历史文件保留。

该流程不会调用iOS导出器/链接器，不自动产出IPA或推进产品资格。整程序集70条失败/不支持、R19剩余完整对照和实际设备测试均继续开放。运行结果以实际回读为准，绿色也不能替代iPad Metal/画面/音效/触控验收。
'''.encode());manifest(D)
