"""Read back actual current Editor, assets, raw shader programs and images."""
from pathlib import Path
import collections,json,struct,subprocess
from archive_support import sha,js,pack,manifest
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';D=R/'Recovery/Startup-R20-Editor-Diagnostic-2026-10-26';T=R/'Recovery/Startup-R20-Sites104-2026-10-26'
E=W/'r20-editor-run-40224994102/STARTUP-R20-EDITOR-DIAGNOSTIC-EVIDENCE';B=W/'r20-editor-run-40224994102/STARTUP-R20-SHADERS-COMPILED-AND-RENDERED'
shader=json.loads((E/'custom-shader-audit.json').read_bytes());startup=json.loads((E/'startup-play-probe.json').read_bytes());asset=json.loads((E/'startup-asset-audit.json').read_bytes())
assert shader['pass'] and len(shader['compilations'])==76 and len(shader['pixels'])==20 and not shader['errors']
assert collections.Counter(r['platform'] for r in shader['compilations'])=={'Metal':38,'OpenGLCore':38}
assert shader['negative_compile_control'] and all(r['success'] and r['bytes']>0 for r in shader['compilations'])
assert all(r['pass'] and r['max_error']<.003 for r in shader['pixels']) and not shader['metal_device_execution'] and not shader['game_pixel_equivalence']
assert shader['pipeline_asset_guid']=='22c2bf3291e4d8f4db5d66a87a6f8123' and shader['render_pipeline_tag']=='UniversalPipeline' and shader['initialized_original_pipeline_for_headless_render']
assert startup['pass'] and startup['frames']==2049 and startup['active_canvases']==2 and startup['main_ui_components']==1 and not startup['errors'] and startup['active_scene']=='MainMenu'
assert not startup['device_execution'] and not startup['pixel_equivalence']
assert asset['pass'] and asset['original_serialization_markers']==130 and asset['resolved_plugin_scripts']==148 and asset['missing_components']==0 and asset['unresolved_custom_dummy_shaders']==[] and not asset['errors']
candidate=(E/'test-dll-after-reimport.sha256').read_text('utf-8').strip();assert candidate=='d887b370c95c2966dc40d80648d85c286bb42d85004c32d095f64f004e095b37'
assert (E/'license-return-exit.txt').read_text('utf-8').strip()=='0'
names=set();identities=[]
for row in shader['compilations']:
    prefix='game' if row['shader']=='Unlit/GameUnitShader' else 'brightness';suffix='_'.join(k[-1] for k in row['keywords'].split());name=f"shader-{prefix}-p{row['pass']}-{row['platform']}-{row['stage']}-{suffix}.bin"
    data=(B/name).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256'];names.add(name);identities.append(dict(file=name,bytes=len(data),sha256=sha(data)))
for row in shader['pixels']:
    name='render-'+row['name']+'.png';data=(B/name).read_bytes();assert data[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack_from('>II',data,16)==(32,32);names.add(name);identities.append(dict(file=name,bytes=len(data),sha256=sha(data)))
assert names=={p.name for p in B.iterdir() if p.is_file()} and len(names)==96
run=json.loads(subprocess.check_output([r'C:\Program Files\GitHub CLI\gh.exe','run','view','40224994102','--repo','lyiming710-cloud/GodsPVZ-iOS','--json','databaseId,status,conclusion,headSha,url,jobs']))
assert run['status']=='completed' and run['conclusion']=='success' and run['headSha']=='e3b7e3d998bf1100cf7995bcce59cc474f316d47' and all(j['conclusion']=='success' for j in run['jobs'])
items=[('evidence/'+p.relative_to(E).as_posix(),p.read_bytes()) for p in sorted(E.rglob('*')) if p.is_file()]+[('shader-output/'+p.name,p.read_bytes()) for p in sorted(B.iterdir()) if p.is_file()]
items += [(Path(__file__).name,Path(__file__).read_bytes()),('archive_support.py',(W/'archive_support.py').read_bytes())]
pack(D/'ACTUAL-EDITOR-AND-SHADERS-40224994102.zip',items);js(D/'RUN-40224994102.json',run)
js(D/'ACTUAL-EDITOR-READBACK.json',dict(candidate_sha256=candidate,run_id=40224994102,source_commit=run['headSha'],
    shader=shader,startup=startup,asset=asset,raw_shader_and_image_files=identities,personal_seat_return_exit=0,
    physical_stage_dll_returned=False,stage_dll_identity_source='RAW_WORKCOPY_AFTER_REIMPORT_SHA256_READBACK',
    new_unity_export=False,linked=False,ipa=None,ipad_acceptance=False))
s=json.loads((D/'PROGRESS.json').read_bytes());s.update(status='ACTUAL_R20_EDITOR_MAINMENU_AND_SHADER_DIAGNOSTIC_PASS_PRODUCT_PENDING',unity_result='PASS_SCOPED_ONLY',
    normal_mainmenu_frames=2049,normal_mainmenu_errors=0,resolved_plugin_scripts=148,original_serialization_markers=130,missing_components=0,
    metal_stage_compilations=38,opengl_stage_compilations=38,controlled_pixels=20,raw_programs_and_images_rehashed=96,personal_seat_return_exit=0,
    game_pixel_equivalence=False,metal_device_execution=False,ipa=None)
js(D/'PROGRESS.json',s)
s=json.loads((T/'PROGRESS.json').read_bytes());s.update(unity='PASS_SCOPED_REAL_EDITOR_MAINMENU_AND_SHADER_RUN_40224994102',editor_mainmenu_frames=2049,editor_startup_errors=0,editor_missing_components=0);js(T/'PROGRESS.json',s)
p=D/'README.md';text=p.read_text('utf-8');text+='''
## 当前候选真实结果已回读

Run40224994102在提交e3b7e3d、精确d887b370候选上完成。正常MainMenu探针2,049帧、两个活跃Canvas、一个MainUIController、0启动错误；148个插件脚本、130个原始序列化标记全部解析，缺组件0，263项游戏脚本引用通过检查。正常启动与着色器启动是分开的真实PlayMode过程。

38项Metal与38项OpenGLCore阶段编译成功，故意损坏着色器被拒绝；20项受控RGBA像素通过。逐一重算76个原始程序缓冲区SHA，检查20张32x32 PNG，共96个原文件完整留存；沿用原URP资产。注入后插件SHA和席位归还退出0均从原始证据回读。

这仍未运行iPad Metal、完整游戏相机像素对照、Board完整关卡或物理音频，未产生Xcode导出/链接/IPA。该真实启动结果允许继续构建当前候选的测试IPA，不提升尚未证明的全游戏/设备资格。
''';p.write_bytes(text.encode())
p=R/'README.md';text=p.read_text('utf-8');marker='No new Unity export, linked IPA or iPad acceptance.';assert marker in text;text=text.replace(marker,'Actual R20 Editor MainMenu runs 2,049 frames with zero startup errors; all 148 script bindings and 76 shader stages/20 controlled pixels pass with raw evidence verified. No new Unity iOS export, linked IPA or iPad acceptance.',1);p.write_bytes(text.encode())
p=R/'Recovery/STATUS.md';text=p.read_text('utf-8');marker='## Latest checkpoint - 2026-10-26\n';text=text.replace(marker,marker+'\n[R20 actual Editor readback](Startup-R20-Editor-Diagnostic-2026-10-26/README.md): exact d887b370 passes real MainMenu startup for2,049 frames, two Canvases/one MainUI/zero errors; all148 plugin scripts/130 markers resolve and no components are missing. All76 shader stages and20 controlled pixel checks pass;96 raw program/PNG files rechecked. Seat returned exit0. This is Editor/controlled-render scope, not iPad Metal/Board/physical audio/IPA acceptance.\n',1);p.write_bytes(text.encode())
for d in [D,T]:manifest(d)
print(json.dumps(dict(run=40224994102,candidate=candidate,frames=2049,shader_stages=76,controlled_pixels=20,raw_files=96,ipa=None)))
