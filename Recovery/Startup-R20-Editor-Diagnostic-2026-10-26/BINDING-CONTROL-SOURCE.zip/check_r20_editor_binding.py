"""Physical corrupted-input controls for the new diagnostic binder only."""
from pathlib import Path
import importlib.util,json,shutil,tempfile,zipfile,sys
sys.dont_write_bytecode=True
from archive_support import sha,js,manifest,pack
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';D=R/'Recovery/Startup-R20-Editor-Diagnostic-2026-10-26'
script=R/'scripts/actions/bind_startup_r20_diagnostic.py';spec=importlib.util.spec_from_file_location('r20_editor_binding',script);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
data,proof=m.validate_checkpoint();assert sha(data)==m.CANDIDATE and len(proof['targets'])==8
rows=[];temporary=Path(tempfile.mkdtemp(prefix='r20-editor-binding-controls-',dir=W)).resolve();assert temporary.is_relative_to(W.resolve())
try:
    for name,expected in [('wrong_dll','Wrong R20 candidate bytes'),('failed_target_type','A target type check failed'),('missing_runtime_record','Native/CIL finite profile missing')]:
        root=temporary/name;shutil.copytree(m.CHECKPOINT,root)
        if name=='wrong_dll':
            p=root/'STARTUP-R20-SITES104-CANDIDATE.zip';b=bytearray(data);b[0]^=1
            with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
                z.writestr('STARTUP-R20-SITES104.dll',b);z.writestr('MANIFEST.json',json.dumps([dict(file='STARTUP-R20-SITES104.dll',bytes=len(b),sha256=sha(b))]))
            mutation=dict(candidate_byte_offset=0,before=data[0],after=b[0],variant_dll_sha256=sha(b),inner_zip_manifest_updated=True)
        elif name=='failed_target_type':
            p=root/'FROZEN-WITH-INTERFACE-FACTS.json';j=json.loads(p.read_bytes());target=proof['targets'][0];next(r for r in j['results'] if r['token']==target)['status']='FAIL_OR_UNSUPPORTED';js(p,j);mutation=dict(file=p.name,target=target,replaced_status='FAIL_OR_UNSUPPORTED')
        else:
            p=root/'NATIVE-SAVE-UI.json';j=json.loads(p.read_bytes());j['normal_records']=215;js(p,j);mutation=dict(file=p.name,normal_records_before=216,normal_records_after=215)
        # Rehash the outer manifest too: reject missing semantic evidence even
        # when both delivery manifests are consistent with the corrupted input.
        manifest(root);error=None
        try:m.validate_checkpoint(root)
        except ValueError as e:error=str(e)
        assert error and expected in error,(name,error)
        rows.append(dict(name=name,rejected=True,actual_error=error,mutation=mutation,outer_manifest_updated=True))
finally:
    assert temporary.resolve().is_relative_to(W.resolve());shutil.rmtree(temporary)
result=dict(scope='DIAGNOSTIC_INPUT_BINDING_GUARDS_ONLY_NOT_GAME_TESTS',normal_candidate_sha256=sha(data),normal_validation_pass=True,
    actual_binder_sha256=sha(script.read_bytes()),physical_negative_controls=3,rejected=3,controls=rows,
    game_dll_changed=False,frozen_game_verifiers_changed=False,unity_started=False,ipa=None)
js(D/'BINDING-CONTROLS.json',result)
pack(D/'BINDING-CONTROL-SOURCE.zip',[(Path(__file__).name,Path(__file__).read_bytes()),('archive_support.py',(W/'archive_support.py').read_bytes()),(script.name,script.read_bytes())]);manifest(D)
print(json.dumps(result,indent=2))
