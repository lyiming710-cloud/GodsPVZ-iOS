from pathlib import Path
import hashlib,json,zipfile
def sha(data):return hashlib.sha256(data).hexdigest()
def record(name,data):return dict(file=name,bytes=len(data),sha256=sha(data))
def js(path,value):Path(path).write_bytes((json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode())
def pack(path,items):
    items=list(items);assert len(items)==len({n for n,b in items}) and 'MANIFEST.json' not in {n for n,b in items}
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        for name,data in items:z.writestr(name,data)
        z.writestr('MANIFEST.json',json.dumps([record(n,b) for n,b in items],indent=2))
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        rows=json.loads(z.read('MANIFEST.json'));assert set(z.namelist())=={'MANIFEST.json'}|{r['file'] for r in rows}
        for r in rows:assert record(r['file'],z.read(r['file']))==r
def variants(root,baseline):
    result=[]
    for p in sorted(Path(root).rglob('*.dll')):
        rel=p.relative_to(root)
        if p.name.startswith('candidate') or any(x in ['bin','obj'] for x in rel.parts):continue
        data=p.read_bytes();assert len(data)==len(baseline);runs=[]
        for page in range(0,len(data),4096):
            before=baseline[page:page+4096];after=data[page:page+4096]
            if before==after:continue
            at=0
            while at<len(before):
                if before[at]==after[at]:at+=1;continue
                end=at+1
                while end<len(before) and before[end]!=after[end]:end+=1
                runs.append(dict(file_offset=page+at,before=before[at:end].hex(),after=after[at:end].hex()));at=end
        rebuilt=bytearray(baseline)
        for r in runs:
            at=r['file_offset'];b=bytes.fromhex(r['before']);a=bytes.fromhex(r['after']);assert rebuilt[at:at+len(b)]==b;rebuilt[at:at+len(a)]=a
        assert rebuilt==data;result.append(dict(file=rel.as_posix(),parent_sha256=sha(baseline),sha256=sha(data),runs=runs))
    return result
def manifest(root):
    root=Path(root);js(root/'MANIFEST.json',[record(p.relative_to(root).as_posix(),p.read_bytes()) for p in sorted(root.rglob('*')) if p.is_file() and p!=root/'MANIFEST.json'])
