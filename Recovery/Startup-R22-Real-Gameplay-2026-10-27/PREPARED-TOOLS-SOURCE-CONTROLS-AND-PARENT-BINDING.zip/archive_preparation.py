"""Archive prepared tools and scoped controls before real Editor execution."""
from pathlib import Path
import json,sys
D=Path(__file__).resolve().parent;W=D.parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113';C=R/'Recovery/Startup-R22-Real-Gameplay-2026-10-27';assert not C.exists();C.mkdir()
sys.path.insert(0,str(W));from archive_support import js,pack,manifest
rows=json.loads((D/'FINAL-TOOL-SOURCE-IDENTITIES.json').read_bytes());compile=json.loads((D/'FINAL-EXACT-EDITOR-HELPERS.json').read_bytes());assert compile['exit_code']==0
controls=json.loads((D/'SOURCE-AND-READBACK-GUARD-CONTROLS.json').read_bytes());assert controls['positive_source_fields_appended']==3836 and len(controls['controls'])==6 and all(c['rejected']for c in controls['controls'])and not controls['actual_child_loaded_resource_values_proven']
files=[(p.relative_to(D).as_posix(),p.read_bytes())for p in sorted(D.rglob('*'))if p.is_file()and p.relative_to(D).parts[0]not in['source-fixture','parent-package-fixture']and not(p.suffix=='.dll'and p.name=='Assembly-CSharp-bulk401.dll')]
files += [('repository/'+r['file'],(R/r['file']).read_bytes())for r in rows]
files += [('drivers/read_actual_compiler.py',(W/'startup-r22-board-loop/read_actual_compiler.py').read_bytes()),('drivers/prepare_child_runtime.py',(W/'startup-r22-board-loop/prepare_child_runtime.py').read_bytes())]
pack(C/'PREPARED-TOOLS-SOURCE-CONTROLS-AND-PARENT-BINDING.zip',files)
for name in['FINAL-EXACT-EDITOR-HELPERS.json','SOURCE-AND-READBACK-GUARD-CONTROLS.json','BINDING-PIPELINE-FIXTURE.json','FINAL-TOOL-SOURCE-IDENTITIES.json','APPLE-WORKFLOW-DERIVATION.json']:(C/name).write_bytes((D/name).read_bytes())
(C/'.gitattributes').write_bytes(b'* -text\n')
js(C/'PROGRESS.json',dict(status='PREPARED_EXACT_R22_TOOLS_AND_SOURCE_CONTROLS_REAL_EDITOR_NOT_YET_RUN',candidate_sha256='15e0150337a14f1613321385af2d9b1997abd1bc255d56abe4a4ce2c5f7ac2cf',game_method_changes_since_board112=0,exact_editor_helper_compilation=True,source_control_rejections=6,original_source_plans_unchanged=True,child_original_resource_values='NOT_YET_OBSERVED_IN_UNITY',linux_compiler_run=40452784098,linux_compiler_raw_readback='1029_SOURCES_AND_LOGS_PASS',child_apple='SEPARATE_PENDING_GATE',real_complex_gameplay='NOT_YET_OBSERVED',game_fields_assigned_by_probe=False,units_spawned_by_probe=False,gameplay_pass=False,ipa=None))
(C/'README.md').write_text('''# R22真实复杂关卡诊断入口

固定游戏DLL15e01503…ac2cf，沿用Board112的5个方法/112个位置，不再改游戏代码。已独立回读新Linux IL2CPP输出全部1029份源码和原始日志，0错误；Apple针对同一新源码单独检查，旧父结果不归到子候选。

真实Unity继续原版Adventure 19“裂鸣共振”，通过实际桌面OS鼠标完成选卡、确定、开始、卡槽及合法空草地种植。入口仅绕过菜单/存档关卡解锁，不写库存、阳光、单位位置、HP、波次、存档解锁，不手动生成单位或调用Update/攻击/伤害。

资源恢复仍使用固定R21原版PC计划：9植物846字段、26僵尸2990字段。原计划的父候选身份75160a32保持原样；新工具仅允许经过字段/元数据字节隔离的15e01503子DLL。后续真正AssetDatabase/Resources的70路/9902叶项检查必须重新执行，不能拿本地“父观测数据换候选标签”的验证器回归用例当成子Unity已加载证明。错误父身份、owner、动画空引用、僵尸HP、缺对象、重复追加六个控制均拒绝；源恢复/绑定fixture不运行Unity。

三个新R22 Editor探针独立命名，历史探针和冻结类型检查器未改变。当前已用真实Editor API模块完成编译，并核对工作流上下文。完整父包→R20→R21→R22输入绑定本地fixture通过，保留各层provenance。首次直接调用绑定器时漏创建父输入只是fixture准备缺项，随后按实际工作流顺序补齐；没有因此放宽绑定条件。

每2秒只读记录Board暂停/倒计时、出怪管理器是否存在/激活、配置旗帜/波数、当前旗帜/波次、波次计时、预置敌人数及单位列表数。卡槽记录真实cardList成员，避免isOnBank错误导致证据被过滤；保留未激活单位及active/enabled标记。只有激活的僵尸类型、激活且已在场植物生成的激活弹丸进入进展计数。设备也能造成伤害，因此HP下降仍标记来源未证明，不用它冒充植物正常攻击。全关、iPad输入、普遍语义等价和IPA均不由收集完成自动推出。

Unity测试和Apple语法检查可并行：前者执行Linux Editor，后者检验物理iOS arm64编译。当前入口强制audit_only+interaction+gameplay，禁止导出/链接IPA；成功游戏观测仍须人工回读轨迹、事件和截图。已确认的VisualScripting Core默认返回问题保留，尚未在本批修改SDK。
''',encoding='utf-8')
manifest(C)
p=R/'README.md';text=p.read_text('utf-8');old='Fresh child compiler';text=text.replace('[Fresh child compiler run 40452784098](https://github.com/lyiming710-cloud/GodsPVZ-iOS/actions/runs/40452784098) is running at source ba78423; real complex gameplay remains pending; no new IPA.','[Fresh child compiler run 40452784098](https://github.com/lyiming710-cloud/GodsPVZ-iOS/actions/runs/40452784098) passes all 1029 sources and raw logs at source ba78423. [R22 real gameplay tools](Recovery/Startup-R22-Real-Gameplay-2026-10-27/README.md) are prepared for renewed Unity resource/planting/combat observations and separate Apple checking; no new IPA.');p.write_bytes(text.encode())
print('Archived prepared R22 real gameplay tools and explicitly scoped controls')
