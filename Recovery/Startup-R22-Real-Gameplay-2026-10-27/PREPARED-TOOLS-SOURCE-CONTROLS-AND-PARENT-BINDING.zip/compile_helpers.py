"""Compile R22 helpers against previously hashed actual Editor API modules."""
from pathlib import Path
import json,hashlib,subprocess
D=Path(__file__).resolve().parent;W=D.parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113';api=ROOT/'audit/local-preflight/exact-editor-tools/resolver';aot=api.parent/'aot-resolver'
refs=[aot/n for n in['mscorlib.dll','System.dll','System.Core.dll','netstandard.dll']]+[api/n for n in['UnityEditor.CoreModule.dll','UnityEngine.CoreModule.dll','UnityEngine.UIModule.dll','UnityEngine.JSONSerializeModule.dll','UnityEngine.InputLegacyModule.dll','UnityEngine.ScreenCaptureModule.dll']]
known={Path(r['path']).name:r['sha256']for r in json.loads((W/'asset-audit-40081048209/HELPER-COMPILATION.json').read_bytes())['references']}
for p in refs[4:]:assert hashlib.sha256(p.read_bytes()).hexdigest()==known[p.name]
sources=[R/'scripts/actions'/n for n in['GodsPVZGameplayAuditR22.cs','GodsPVZSerializedReferenceProbeR22.cs','GodsPVZInteractionAuditR22.cs']]
cmd=[str(ROOT/'.local/dotnet10/dotnet.exe'),str(ROOT/'.local/dotnet10/sdk/10.0.402/Roslyn/bincore/csc.dll'),'/noconfig','/nostdlib','/target:library','/langversion:9.0','/utf8output','/preferreduilang:en-US','/define:UNITY_EDITOR','/out:'+str(D/'FINAL-EXACT-EDITOR-HELPERS.dll')]+['/r:'+str(p)for p in refs]+[str(p)for p in sources]
p=subprocess.run(cmd,capture_output=True);(D/'FINAL-EXACT-EDITOR-HELPERS.log').write_bytes(p.stdout+p.stderr);print((p.stdout+p.stderr).decode('utf-8',errors='replace'))
result=dict(scope='EXACT_EDITOR_HELPER_API_COMPILATION_ONLY_NOT_UNITY_GAMEPLAY',exit_code=p.returncode,sources=[dict(file=f.name,sha256=hashlib.sha256(f.read_bytes()).hexdigest())for f in sources],references=[dict(file=f.name,sha256=hashlib.sha256(f.read_bytes()).hexdigest())for f in refs],unity_started=False,game_changed=False)
(D/'FINAL-EXACT-EDITOR-HELPERS.json').write_text(json.dumps(result,indent=2)+'\n');raise SystemExit(p.returncode)
