from pathlib import Path
import collections,json,re,subprocess
from archive_support import sha,js,pack,manifest
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';Q=W/'r20-full-build-run-40259026509';D=R/'Recovery/Startup-R20-Asset-Case-2026-10-26';F=R/'Recovery/Startup-R20-IPA-Build-2026-10-26';G=R/'Recovery/Startup-R20-Export-Error4-2026-10-26';T=R/'Recovery/Startup-R20-Sites104-2026-10-26'
assert not D.exists();D.mkdir();(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text\n*.md -text\n*.zip -text\n*.yml -text\n')
raw=Q/'forensics/RAW-ACTUAL-UNITY-BUILD-REPORT.json';report=json.loads(raw.read_bytes());errors=[dict(step=s['name'],**m) for s in report['steps'] for m in s['messages'] if m['type'] in ['Error','Exception','Assert']];assert len(errors)==report['total_errors']==4 and report['result']=='Succeeded'
assert all(m['content'].startswith('The following files have the same name as another file, but only differ in casing') for m in errors)
paths=sorted(set(p for e in errors for p in re.findall(r'^\t(Assets/[^\r\n]+)',e['content'],re.M)));assert len(paths)==24
groups=collections.defaultdict(list)
for p in paths:groups[p.casefold()].append(p)
groups=sorted([sorted(v) for v in groups.values()]);assert len(groups)==12 and all(len(g)==2 for g in groups)
source=json.loads((Q/'forensics/FORENSICS.json').read_bytes());assert source['observed_plugin_sha256']=='d887b370c95c2966dc40d80648d85c286bb42d85004c32d095f64f004e095b37' and source['source_commit']=='0457c90769cc6443493d13c6170a0772874cc097' and source['qualified'] is False and source['captured_files']==329
assert (Q/'editor-evidence/license-return-exit.txt').read_text().strip()=='0'
(D/'RAW-ACTUAL-UNITY-BUILD-REPORT.json').write_bytes(raw.read_bytes());(D/'GENERATED-FORENSICS-INVENTORY.json').write_bytes((Q/'forensics/FORENSICS.json').read_bytes());(D/'FORENSICS-ARCHIVE.json').write_bytes((Q/'forensics/ARCHIVE.json').read_bytes());js(D/'FOUR-ERRORS-ONE-ASSET-CASE-CLASS.json',dict(errors=errors,distinct_paths=paths,casefold_file_groups=groups,asset_pair_groups=6,distinct_assets=12,distinct_asset_and_meta_files=24))
run=json.loads(subprocess.check_output(['C:/Program Files/GitHub CLI/gh.exe','run','view','40259026509','--repo','lyiming710-cloud/GodsPVZ-iOS','--json','status,conclusion,headSha,jobs,url']));assert run['conclusion']=='failure';js(D/'RUN.json',run)
pack(D/'ACTUAL-FAILED-REPLAY-40259026509.zip',[(p.relative_to(Q/'editor-evidence').as_posix(),p.read_bytes()) for p in sorted((Q/'editor-evidence').rglob('*')) if p.is_file()])
names=['normalize_startup_r20_asset_case.py','check_startup_r20_asset_case.py'];pack(D/'SOURCE-ONLY-CASE-REPAIR-PREPARATION.zip',[('scripts/actions/'+n,(R/'scripts/actions'/n).read_bytes()) for n in names]+[('workflow/'+n,(R/'.github/workflows'/n).read_bytes()) for n in ['bulk401-startup-runtime-gate.yml','startup-r20-real-ios-test-build.yml']]+[(Path(__file__).name,Path(__file__).read_bytes())])
js(D/'PROGRESS.json',dict(status='FOUR_ACTUAL_BUILD_ERRORS_IDENTIFIED_AS_REPEATED_ASSET_CASE_COLLISIONS_SOURCE_ONLY_PREFLIGHT_PREPARED',candidate_sha256=source['observed_plugin_sha256'],actual_replay=40259026509,actual_raw_report_sha256=sha(raw.read_bytes()),build_report_error_count=4,error_category_count=1,asset_case_pair_groups=6,affected_assets=12,affected_asset_and_meta_files=24,generated_cpp=source['actual_generated_cpp'],generated_c=source['actual_generated_c'],generated_files_read_back=329,source_archive_sha256='53b73734f7edc2ed64134c86e7b7ee584aebea12a33ace2f100876d47ee7e80e',actual_apple_compile='NOT_STARTED',new_game_dll_changes=0,source_plan='AWAITING_EXACT_LINUX_R3_INSPECTION',unity_after_case_repair='NOT_RUN',ipa=None,ipad_acceptance=False))
(D/'README.md').write_bytes('''# 四条实际 Unity 构建错误已定位：六组大小写路径冲突

带完整报告的复现40259026509（提交0457c907）再次保持失败。实际BuildReport含4条Error，逐条都是同一组24个路径（12份资源及其meta）的大小写冲突，分别在Prebuild Cleanup/Prepare assets多个阶段重报。不是从summary或1221条序列化提示猜出的根因。

资源组为AnimationClip的Enter/enter、Exit/exit、Idle/idle，Sprite的Background/background、Background_0/background_0，以及Texture2D的Background.png/background.png。Unity明确提示将忽略这些文件。原错误门、候选和签名策略保持，Mac跳过，没有新IPA；席位已归还。

拟在精确R3副本首次导入前把每个冲突资源及meta移到各自GUID命名的子文件夹，保留原文件名。这样PNG默认导入名也能保留；不改资源内容、meta、GUID、动画/精灵内部名称和游戏DLL。旧显式路径引用、Resources/StreamingAssets路径、无meta/重复GUID等会先阻止移动；完整输入/输出文件清单和hash、四个变坏计划控制在Linux源码预检执行。此检查点仅准备source-only模式，尚未取得实际R3计划，不能宣称资源修复通过。

这轮也保存了真正的失败导出源码：258个C++、66个C，全部329个归档文件SHA及ZIP完整性已本机回读。它与此前可移植转换的1029单元不是同一套输入。当前实际导出源码尚未进行Apple编译，绝不继承历史1029条成功作为此导出通过。原始完整报告及完整源码归档SHA为53b73734f7edc2ed64134c86e7b7ee584aebea12a33ace2f100876d47ee7e80e（不合格诊断输入）。

资源/Unity工程修复继续完成已经超过100位置的R20测试批次；不会把12份路径调整算成12个新CIL修复，也不会把原有四个浮点修复提案偷偷写入当前游戏DLL。真实M5设备的黑屏原因和改善仍需新包实测。
'''.encode())
for folder in [F,G]:
    p=folder/'README.md';v=p.read_text('utf-8');v+='\n## 完整报告复现已定位\n\n[40259026509逐项错误及资源修复准备](../Startup-R20-Asset-Case-2026-10-26/README.md)保存4条同类case冲突错误、24路径和329个实际导出文件清单。源码预检准备中，尚未宣称修复或IPA通过。\n';p.write_bytes(v.encode())
s=json.loads((F/'PROGRESS.json').read_bytes());s.update(status='ACTUAL_EXPORT_ERRORS_IDENTIFIED_AS_ASSET_CASE_COLLISIONS',forensic_replay=40259026509,root_error_category='SIX_RESOURCE_CASE_PAIR_GROUPS_REPEATED_FOUR_BUILD_REPORT_ERRORS',source_only_preflight='PREPARED');js(F/'PROGRESS.json',s)
s=json.loads((T/'PROGRESS.json').read_bytes());s.update(real_ios_export_replay=40259026509,real_ios_export_blocker='SIX_RESOURCE_CASE_PAIR_GROUPS_REPEATED_FOUR_ERRORS',actual_export_source_count_cpp=258,actual_export_source_count_c=66);js(T/'PROGRESS.json',s)
p=R/'Recovery/STATUS.md';v=p.read_text('utf-8');marker='## Latest checkpoint - 2026-10-26\n';v=v.replace(marker,marker+'\n[Actual export errors identified](Startup-R20-Asset-Case-2026-10-26/README.md): all4 BuildReport errors are repeated reports of six asset casing pairs (24 files with meta). Source-only path repair is prepared; 329 actual export files including258cpp+66c have been independently hash-read. No Mac or newIPA acceptance.\n',1);p.write_bytes(v.encode())
for folder in [D,F,G,T]:manifest(folder)
print(json.dumps(dict(archived=D.name,errors_identified=4,asset_case_pairs=6,raw_source_files_verified=329)))
