"""Bind successful Linux source inspection and install the exact path-only transition."""
from pathlib import Path
import json,re,subprocess,zipfile
from archive_support import sha,js,pack,manifest
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';Q=W/'r20-asset-case-source-40262106436';D=R/'Recovery/Startup-R20-Asset-Case-2026-10-26';F=R/'Recovery/Startup-R20-IPA-Build-2026-10-26';T=R/'Recovery/Startup-R20-Sites104-2026-10-26'
assert not (D/'ASSET-CASE-PLAN.json').exists()
plan=json.loads((Q/'ASSET-CASE-PLAN.json').read_bytes());controls=json.loads((Q/'ASSET-CASE-CONTROLS.json').read_bytes());assert plan['asset_files']==6842 and plan['renamed_files']==24 and plan['renamed_assets']==12 and plan['collision_asset_groups']==6 and not plan['old_explicit_path_reference_mentions'] and plan['candidate_literals_scanned']
assert controls['rejected']==4 and all(r['rejected_before_any_move'] for r in controls['controls']) and controls['positive_application']['case_collision_groups_after']==0
expected=set(json.loads((D/'FOUR-ERRORS-ONE-ASSET-CASE-CLASS.json').read_bytes())['distinct_paths']);assert expected=={r['before'] for r in plan['renames']}
names=[]
with zipfile.ZipFile(Q/'ORIGINAL-COLLIDING-ASSETS.zip') as z:
    assert z.testzip() is None and set(z.namelist())==expected
    for row in plan['renames']:
        data=z.read(row['before']);assert len(data)==row['bytes'] and sha(data)==row['sha256']
        before=Path(row['before']);after=Path(row['after']);assert before.name==after.name and after.parent.name=='__r3guid_'+row['guid']
        if before.suffix=='.meta':
            assert re.findall(rb'^guid: ([0-9a-fA-F]{32})\s*$',data,re.M)==[row['guid'].encode()];continue
        if before.suffix=='.png':name=before.stem
        else:
            found=re.findall(rb'^  m_Name: *(.*)\r?$',data,re.M);assert len(found)==1,(before,found);name=found[0].decode('utf-8').strip()
            if name.startswith('"'):name=json.loads(name)
        names.append(dict(guid=row['guid'],path=row['after'],name=name))
assert len(names)==12 and len({r['guid'] for r in names})==12
for name in ['ASSET-CASE-PLAN.json','ASSET-CASE-CONTROLS.json','ORIGINAL-COLLIDING-ASSETS.zip']:(D/name).write_bytes((Q/name).read_bytes())
js(D/'ASSET-CASE-IMPORT-NAMES.json',dict(scope='EXPECTED_ORIGINAL_IMPORT_NAMES_FROM_RAW_ASSETS_AND_UNCHANGED_PNG_BASENAMES',rows=names))
run=json.loads(subprocess.check_output(['C:/Program Files/GitHub CLI/gh.exe','run','view','40262106436','--repo','lyiming710-cloud/GodsPVZ-iOS','--json','status,conclusion,headSha,jobs,url']));assert run['conclusion']=='success' and run['headSha']=='ca746368fe07b918d118f9749db843fcf7aceb6e';js(D/'SOURCE-ONLY-RUN.json',run)
failed=W/'r20-asset-case-source-40261884357';pack(D/'INITIAL-EPOCH-ZIP-FAILURE-40261884357.zip',[(p.name,p.read_bytes()) for p in sorted(failed.iterdir()) if p.is_file()])
release=json.loads(subprocess.check_output(['C:/Program Files/GitHub CLI/gh.exe','release','view','bulk152-actions-checkpoint-2026-10-20','--repo','lyiming710-cloud/GodsPVZ-iOS','--json','assets']))
asset=next(a for a in release['assets'] if a['name']=='Startup-R20-UNQUALIFIED-40259026509-generated-and-report.zip');assert asset['size']==54575278 and asset['digest']=='sha256:53b73734f7edc2ed64134c86e7b7ee584aebea12a33ace2f100876d47ee7e80e';js(D/'PERMANENT-UNQUALIFIED-SOURCE-ARCHIVE.json',asset)
p=R/'.github/workflows/startup-r20-real-ios-test-build.yml';s=p.read_text('utf-8');line='          rm -rf "$OUT/r3-cache" "$ARCHIVE"';assert s.count(line)==1;s=s.replace(line,'          python3 scripts/actions/normalize_startup_r20_asset_case.py --project "$PROJECT" --apply-plan "$GITHUB_WORKSPACE/Recovery/Startup-R20-Asset-Case-2026-10-26/ASSET-CASE-PLAN.json" --output "$E"\n'+line)
marker='      - name: Repair official shader bindings and audit all startup scenes and prefabs\n';assert s.count(marker)==1
s=s.replace(marker,'''      - name: Verify every relocated resource GUID, path and original imported name
        shell: bash
        env:
          GODSPVZ_ASSET_CASE_IMPORT_NAMES: ${{ github.workspace }}/Recovery/Startup-R20-Asset-Case-2026-10-26/ASSET-CASE-IMPORT-NAMES.json
          GODSPVZ_ASSET_CASE_AUDIT_OUTPUT: ${{ runner.temp }}/stage9-startup-r2/evidence/asset-case-import-audit.json
          LIBGL_ALWAYS_SOFTWARE: '1'
        run: |
          set -euo pipefail
          OUT="$RUNNER_TEMP/stage9-startup-r2"
          E="$OUT/evidence"
          UNITY="$(cat "$OUT/unity-path.txt")"
          PROJECT="$(cat "$OUT/project-path.txt")"
          cp "$GITHUB_WORKSPACE/scripts/actions/GodsPVZAssetCaseAudit.cs" "$PROJECT/Assets/Editor/"
          set +e
          xvfb-run -a -s '-screen 0 1280x720x24' "$UNITY" -batchmode -quit -force-glcore -buildTarget iOS -projectPath "$PROJECT" -executeMethod GodsPVZAssetCaseAudit.Run -logFile "$E/asset-case-import-audit.log" > "$E/asset-case-import-audit.stdout" 2> "$E/asset-case-import-audit.stderr"
          RC=$?
          set -e
          echo "$RC" > "$E/asset-case-import-audit-exit.txt"
          [ "$RC" -eq 0 ] || exit 73
          python3 - "$E/asset-case-import-audit.json" <<'PY'
          import json,sys
          r=json.load(open(sys.argv[1]));assert r['assets']==12 and r['failed']==0 and all(row['pass'] for row in r['rows'])
          PY

'''+marker,1)
p.write_bytes(s.encode());(R/'.github/workflows/bulk401-startup-runtime-gate.yml').write_bytes(s.encode())
source_files=[R/'scripts/actions'/name for name in ['GodsPVZAssetCaseAudit.cs','normalize_startup_r20_asset_case.py','check_startup_r20_asset_case.py','preflight_build_capture_editor.py']];pack(D/'APPLIED-CASE-FIX-AND-UNITY-NAME-AUDIT-SOURCES.zip',[(p.relative_to(R).as_posix(),p.read_bytes()) for p in source_files]+[('workflow/'+n,(R/'.github/workflows'/n).read_bytes()) for n in ['startup-r20-real-ios-test-build.yml','bulk401-startup-runtime-gate.yml']]+[('LOCAL-EXACT-API.json',(W/'r20-build-error4-forensics-2026-10-26/HELPER-API.json').read_bytes()),(Path(__file__).name,Path(__file__).read_bytes())])
s=json.loads((D/'PROGRESS.json').read_bytes());s.update(status='EXACT_R3_CASE_PATH_FIX_SOURCE_VERIFIED_INTEGRATED_REAL_UNITY_PENDING',source_only_preflight_run=40262106436,source_only_head=run['headSha'],all_r3_asset_files_rechecked=6842,source_path_fault_controls_rejected=4,source_case_groups_after=0,source_plan='PASS_EXACT_SOURCE_ONLY_WITH_FULL_INVENTORY',original_colliding_files_read_back=24,original_import_names_extracted=12,unity_after_case_repair='READY_TO_RUN',ipa=None);js(D/'PROGRESS.json',s)
p=D/'README.md';v=p.read_text('utf-8');v+='''
## 精确Linux源码预检已完成，完整构建修复已接入

源码预检40262106436（ca746368）实际解开固定R3归档，核对6,842个Assets文件。6组冲突中12份资源及12个meta全部移入各自GUID目录，文件名、每个文件的字节/hash和GUID保留，其他6,818个文件的内容与路径不变，大小写冲突归零。四个变坏计划（错误SHA、遗漏after行、越界目标、改文件名）均在第一次移动前拒绝。Source及候选DLL的完整旧路径字面量扫描没有发现需另行处理的直接引用。

第一次源码预检40261884357仅因原归档Unix-epoch时间早于ZIP的1980年限制而在证据打包时失败，尚未移动资源；部分产物保留。改动只钳制ZIP时间元数据，源文件时间/内容不动，随后真实源码预检通过。该失败不是Unity构建或资源语义故障。

固定计划已接入R3解开后、基线/Editor第一次导入前。另提取12个原始导入名称（YAML m_Name及PNG原文件名），新增真实Unity GUID→新路径→LoadMainAsset.name核验；新helper已用精确本机Unity API编译通过，并加入持证启动前的cached API预检。完整Unity尚未重跑，不能提前标四错误消失或IPA通过。冻结游戏候选仍d887b370，不含四个浮点提案。

完整不合格导出源码已永久保存在Release：Startup-R20-UNQUALIFIED-40259026509-generated-and-report.zip。GitHub远端digest与本机相同53b73734…，大小54,575,278字节，329个原始文件均单独校验。
''';p.write_bytes(v.encode())
s=json.loads((F/'PROGRESS.json').read_bytes());s.update(status='ASSET_CASE_BLOCKER_FIXED_IN_SOURCE_REAL_UNITY_REBUILD_READY',source_case_preflight=40262106436,source_case_repair='PASS_SOURCE_ONLY_24_PATHS_ALL_6842_FILE_HASHES_PRESERVED',unity_export_after_case_fix='PENDING');js(F/'PROGRESS.json',s)
s=json.loads((T/'PROGRESS.json').read_bytes());s.update(asset_case_repair_source_preflight=40262106436,asset_case_path_changes=24,asset_case_game_dll_changes=0,asset_case_after_source=0);js(T/'PROGRESS.json',s)
p=R/'README.md';v=p.read_text('utf-8');v=v.replace('The actual iOS export was rejected because its BuildReport contains four errors despite a Succeeded summary;','The actual iOS export was rejected for six resource casing pairs reported as four errors. An exact-source path-only fix now preserves all6,842 file hashes and passes four mutation guards; actual Unity rebuild remains pending;');p.write_bytes(v.encode())
for folder in [D,F,T]:manifest(folder)
print(json.dumps(dict(installed=True,asset_files=6842,renamed_files=24,preserved_basenames=12,source_controls=4,real_unity_pending=True)))
