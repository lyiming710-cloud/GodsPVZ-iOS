"""Run exact R19 parent too, then meaningful one-site physical faults in R20."""
from pathlib import Path
import hashlib,json,struct,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
sha=lambda b:hashlib.sha256(b).hexdigest()
def js(p,v):p.write_bytes((json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode())
data=(W/'startup-r20-sites100/authored3.dll').read_bytes();assert sha(data)=='d887b370c95c2966dc40d80648d85c286bb42d85004c32d095f64f004e095b37'
fixture=Q/'runtime/bin/Release/net10.0/Fixture.dll';refs=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support';dotnet=ROOT/'.local/dotnet10/dotnet.exe'
positive=json.loads((Q/'FULL-CIL-R20.json').read_bytes());native=json.loads((Q/'NATIVE-ATTEMPT1.json').read_bytes());assert not native['differences'] and native['normal_records']==768
expected={r['name']:r for r in native['results']};all_positive={r['name']:r for r in positive['results']}
assert all(all_positive[n]==r for n,r in expected.items());assert positive['candidate_sha256']==native['candidate_sha256']==sha(data)
out=Q/'controls';out.mkdir(exist_ok=False)
def execute(dll,result,stem):
    cmd=[str(dotnet),str(fixture),str(dll),str(refs),str(Q/'CASES.json'),str(result)]
    cp=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(out/(stem+'.stdout.log')).write_bytes(cp.stdout);(out/(stem+'.stderr.log')).write_bytes(cp.stderr)
    assert cp.returncode==0,('PROCESS_FAILURE_NOT_DETECTION',stem,cp.returncode)
    actual=json.loads(result.read_bytes());assert actual['candidate_sha256']==sha(dll.read_bytes())
    found={r['name']:r for r in actual['results']};assert set(found)==set(all_positive);return actual,found
parent=W/'startup-r19-batch100/candidate9.dll';assert sha(parent.read_bytes())=='0ba5bc7ec9603d14a1c0bde6d784d232aa78efaa1700304e75e4f2b56ef7dec2'
a,parent_rows=execute(parent,Q/'FULL-CIL-R19.json','R19-parent');assert parent_rows==all_positive
js(Q/'R19-AND-R20-BINDING.json',dict(scope='COMPLETE_CIL_REEXECUTED_FOR_BOTH_EXACT_DLLS',
    parent_sha256=sha(parent.read_bytes()),current_sha256=sha(data),all_execution_records_each=len(parent_rows),
    normal_native_comparison_records_each=768,managed_only_records_each=0,all_rows_identical=True,new_game_bytes=False))
pe=dnfile.dnPE(data=data);specs=[(0x5f6,87,bytes.fromhex('2001000000'),bytes.fromhex('2000000000'),'Hide image when the equal-time branch must show it')]

results=[]
for rid,offset,before,after,description in specs:
    token=f'0x{0x6000000|rid:08X}';m=pe.net.mdtables.MethodDef.rows[rid-1];at=pe.get_offset_from_rva(m.Rva);header=1 if data[at]&3==2 else (struct.unpack_from('<H',data,at)[0]>>12)*4;where=at+header+offset
    actual_before=data[where:where+5]
    if before is None:assert actual_before[0]==0x6f;before=actual_before
    assert actual_before==before and len(before)==len(after)==5
    changed=bytearray(data);changed[where:where+5]=after;assert changed[:where]==data[:where] and changed[where+5:]==data[where+5:]
    dll=out/(token+'.dll');dll.write_bytes(changed);returned=out/(token+'-actual.json');a,observed=execute(dll,returned,token)
    differences=[dict(original=r,actual=observed[n]) for n,r in expected.items() if r!=observed[n]]
    assert differences and all(d['original']['token']==token and d['actual']['error'] is None for d in differences)
    row=dict(token=token,description=description,variant_sha256=sha(changed),file_offset=where,cil_offset=offset,
        before=before.hex(),after=after.hex(),actual_process_exit=0,behavioral_differences=len(differences),
        other_method_differences=0,detected=True,differences=differences)
    js(out/(token+'-detection.json'),row);results.append(row)
    print(json.dumps({k:v for k,v in row.items() if k!='differences'}),flush=True)
js(out/'RESULT.json',dict(scope='ONE_PHYSICAL_ONE_SITE_BEHAVIORAL_FAULTS_IN_EXACT_CURRENT_DLL',
    candidate_sha256=sha(data),controls=len(results),detected=sum(r['detected'] for r in results),process_failures=0,
    no_exception_counted_as_detection=True,results=results,formal_or_product_acceptance=False))
