"""Three existing CIL methods / two original bodies; Board callee executes unchanged."""
from pathlib import Path
import ctypes as C,functools,hashlib,json,struct,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
im=NativeImage();state={};rids=[0x2b3,0x2b6,0x5f6];cfgs={r:json.loads((Q/f'0x{0x6000000|r:08X}.native.json').read_bytes()) for r in rids};fields=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_bytes())
@functools.lru_cache(None)
def off(owner,name):
    rows=[r for r in fields if r['type']==owner and r['namespace']=='' and r['name']==name];assert len(rows)==1;return rows[0]['offset']
def log(s):state['trace'].append(s)
def bits(v):return struct.pack('<f',v)[::-1].hex().upper()
def f(k):return struct.unpack('<f',bytes.fromhex(state['q'][k])[::-1])[0]
def getter(m):
    assert not m;v=state['time'];log('Get:'+bits(v));state['gets']+=1
    if state['q']['mode']==1:putf(state['board']+off('Board','gameSpeed'),f('other_speed'));put64(state['button']+off('Button_TimeSlow','image'),state['otherImage'])
    if state['q']['mode']==3 and state['gets']==2:put64(state['button']+off('Button_TimeSlow','image'),state['otherImage'])
    return v
def setter(v,m):
    assert not m;log('Set:'+bits(v));state['time']=v
    if state['q']['mode']==2:state['time']=f('observed');put64(state['button']+off('Button_TimeSlow','image'),state['otherImage'])
def gameobject(p,m):assert not m;log('Object:'+state['tags'][p]);return state['object'][p]
def active(p,v,m):assert not m;log('Active:'+state['tags'][p]+':'+str(int(v)));state['active'][p]=bool(v)
try:
    im.hook(0x18132c440,F,[P],getter);im.hook(0x18132c500,None,[F,P],setter);im.hook(0x1813044d0,P,[P,P],gameobject);im.hook(0x18131bad0,None,[P,C.c_bool,P],active)
    for rid,cfg in cfgs.items():im.verify_caller(rid,int(cfg['entry'],16),cfg)
    assert cfgs[0x2b3]['entry']==cfgs[0x2b6]['entry']=='0x180325fc0'
    rows=[];cases=json.loads((Q/'CASES.json').read_bytes())
    for q in cases:
        state.clear();state.update(q=q,tags={},trace=[],object={},active={},gets=0,time=struct.unpack('<f',bytes.fromhex(q['time'])[::-1])[0])
        for label in ['board','button','image','otherImage','initial','other']:state[label]=im.alloc(128);state['tags'][state[label]]=label
        putf(state['board']+off('Board','gameSpeed'),f('speed'));put64(state['button']+off('Button_TimeSlow','board'),state['board']);put64(state['button']+off('Button_TimeSlow','image'),state['image'])
        state['object']={state['image']:state['initial'],state['otherImage']:state['other']};state['active']={state['initial']:None,state['other']:None}
        rid=int(q['token'],16)&0xffffff;C.CFUNCTYPE(None,P,P)(int(cfgs[rid]['entry'],16))(state['button'] if rid==0x5f6 else state['board'],None);assert not im.errors,(q,im.errors)
        rows.append(dict(name=q['name'],token=q['token'],error=None,trace=list(state['trace']),state=dict(time=bits(state['time']),speed=f'{C.c_uint32.from_address(state["board"]+off("Board","gameSpeed")).value:08X}',image=state['tags'][get64(state['button']+off('Button_TimeSlow','image'))],initial=state['active'][state['initial']],other=state['active'][state['other']])))
    actual=json.loads(Path(sys.argv[1]).read_bytes());digest=hashlib.sha256((W/'startup-r20-sites100/authored3.dll').read_bytes()).hexdigest();assert actual['candidate_sha256']==digest;found={r['name']:r for r in actual['results']};assert set(found)=={q['name'] for q in cases};diff=[dict(original=r,actual=found[r['name']]) for r in rows if r!=found[r['name']]]
    report=dict(scope='THREE_EXISTING_MARKER_METHODS_TWO_DISTINCT_ORIGINAL_NATIVE_BODIES',candidate_sha256=digest,original_pc_sha256=hashlib.sha256(im.raw).hexdigest(),methoddefs=3,distinct_original_bodies=2,normal_records=len(rows),results=rows,differences=diff,callback_errors=im.errors,native_jp_and_jne_unchanged=True,nested_board_callee_executed_unmodified=True,marker_strings_unchanged=True,new_game_changes=0,formal_or_product_acceptance=False)
    Path(sys.argv[2]).write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in report.items() if k not in ['results','differences']}));print('differences',len(diff));raise SystemExit(2 if diff else 0)
finally:im.close()
