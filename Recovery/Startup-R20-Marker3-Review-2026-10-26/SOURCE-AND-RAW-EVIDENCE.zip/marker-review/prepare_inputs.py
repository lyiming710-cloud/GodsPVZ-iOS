from pathlib import Path
import itertools,json
Q=Path(__file__).resolve().parent;values=['FF800000','80000000','00000000','3E7FFFFF','3E800000','3E800001','3F800000','7FC07654'];rows=[]
for rid,t,s,mode in itertools.product([0x2b3,0x2b6,0x5f6],values,values,range(4)):rows.append(dict(name=f'm{len(rows):05}',token=f'0x{0x6000000|rid:08X}',time=t,speed=s,other_speed='40200000',observed='7FC07654',mode=mode))
(Q/'CASES.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode());print(len(rows))
