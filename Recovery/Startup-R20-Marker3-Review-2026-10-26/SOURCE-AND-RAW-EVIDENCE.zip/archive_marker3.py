from pathlib import Path
import json
from archive_support import sha,js,pack,manifest,variants
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';Q=W/'r21-marker-source-review-2026-10-26';D=R/'Recovery/Startup-R20-Marker3-Review-2026-10-26';T=R/'Recovery/Startup-R20-Sites104-2026-10-26'
assert not D.exists();D.mkdir();(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text\n*.md -text\n*.zip -text\n')
n=json.loads((Q/'NATIVE-ATTEMPT1.json').read_bytes());b=json.loads((Q/'R19-AND-R20-BINDING.json').read_bytes());c=json.loads((Q/'controls/RESULT.json').read_bytes());assert n['normal_records']==768 and n['methoddefs']==3 and n['distinct_original_bodies']==2 and not n['differences'] and not n['callback_errors'] and n['nested_board_callee_executed_unmodified'];assert b['all_rows_identical'] and c['controls']==c['detected']==1
current=(W/'startup-r20-sites100/authored3.dll').read_bytes();delta=variants(Q/'controls',current);assert len(delta)==1;js(Q/'PHYSICAL-CONTROL-DELTAS.json',delta)
for name,src in [('NATIVE.json','NATIVE-ATTEMPT1.json'),('R19-AND-R20-BINDING.json','R19-AND-R20-BINDING.json'),('CONTROLS.json','controls/RESULT.json'),('PHYSICAL-CONTROL-DELTAS.json','PHYSICAL-CONTROL-DELTAS.json')]:(D/name).write_bytes((Q/src).read_bytes())
files=[]
for p in sorted(Q.rglob('*')):
    if not p.is_file() or any(x in p.parts for x in ['obj','__pycache__']):continue
    if p.suffix=='.dll' and 'bin' not in p.parts:continue
    files.append(('marker-review/'+p.relative_to(Q).as_posix(),p.read_bytes()))
files += [('frozen-runtime/Rehost.cs',(W/'startup-r5/runtime-common/Rehost.cs').read_bytes()),('frozen-runtime/native_runtime_common.py',(W/'startup-r5/native_runtime_common.py').read_bytes()),(Path(__file__).name,Path(__file__).read_bytes())];pack(D/'SOURCE-AND-RAW-EVIDENCE.zip',files)
js(D/'PROGRESS.json',dict(status='THREE_MARKER_METHODS_FINITE_FULL_CALLER_PATHS_MATCH_NO_REPAIR',current_candidate_sha256=sha(current),parent_candidate_sha256=b['parent_sha256'],methoddefs=3,distinct_original_native_bodies=2,native_normal_records=768,controls=1,detected=1,no_new_game_code=True,marker_strings_left_unchanged=True,buff_fixed_update_source_only_not_executed=True,not_added_to_r19_hundred_method_union=True,r19_union_stays=81,r19_pending_stays=19,formal_or_product_acceptance=False))
(D/'README.md').write_bytes('''# 三个语义标记方法的完整调用方：当前无需为JP标记改代码

0x060002B3 Board.ButtonDown_Z、0x060002B6 Board.ChangeTimeSlowDownState、0x060005F6 Button_TimeSlow.ClickThis在两个固定R19/R20候选均执行完整CIL，768条记录相同，全部正常记录与未改原版一致。前两个MethodDef原版共享同一个0x180325FC0入口，所以是三个方法、两个独立原生body，不虚算三个原生实现。

覆盖正负零、0.25相邻float、Infinity/NaN，以及Time getter/setter后更新gameSpeed、image或观察到的timeScale。Button子调用在CLR中继续执行实际发射的Board body；原生也执行未改的真实Board子方法，没有用猜测的C#或stub替掉这一层。Unity Time/Component/SetActive为受控边界，未宣称实际引擎行为或设备验收。

这些JP/JNE表达的是非相等（含unordered），当前ceq后取反已经实现该路径；保留所有原生分支和当前marker字符串。UI正分支active=true误为false的单站点物理变体被检测为170条正常行为差异；其他方法没有差异，没有异常或崩溃算通过。没有新增游戏修改。

这三个方法在R19百方法以外，不加入R19的81方法/31,812记录联合数；它们单独作为三个既有marker线索的有限审查。归档中另含0x060005E7 BuffUI.FixedUpdate的只读source提取，其完整运行尚未执行，不能据本报告声称该方法通过或无缺陷。0x060005E8的已知NaN差异仍在失败档案中。
'''.encode())
queue=json.loads((T/'CURRENT-WORK-QUEUE.json').read_bytes());tokens={'0x060002B3','0x060002B6','0x060005F6'}
for row in queue['rows']:
    if row['token'] in tokens:row.update(current_state='EXISTING_MARKER_CALLER_FINITE_MATCH_NO_SOURCE_REPAIR_REQUIRED_IN_TESTED_DOMAIN',current_required_action='Keep full engine/product scope pending; do not delete JP marker strings or count them as missing behavior',finite_marker_profile='../'+D.name)
queue.update(non_r19_finite_marker_methods=3,other_parent_followup_work_items=129);js(T/'CURRENT-WORK-QUEUE.json',queue);manifest(T);manifest(D)
print(json.dumps(dict(archived=D.name,methoddefs=3,distinct_native_bodies=2,normal_records=768,no_new_game_changes=True)))
