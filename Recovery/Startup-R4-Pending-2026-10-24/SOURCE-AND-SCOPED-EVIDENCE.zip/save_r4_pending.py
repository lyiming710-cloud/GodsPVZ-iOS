from pathlib import Path
import hashlib,json,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]/'audit/repo-native113';Q=W/'startup-r4';D=R/'Recovery/Startup-R4-Pending-2026-10-24'
D.mkdir(exist_ok=True)
def info(n,b):return dict(file=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def js(path,value):path.write_bytes((json.dumps(value,indent=2)+'\n').encode())
def pack(path,items):
    items=list(items);assert len(items)==len({n for n,b in items}) and 'MANIFEST.json' not in {n for n,b in items}
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        for n,b in items:z.writestr(n,b)
        z.writestr('MANIFEST.json',json.dumps([info(n,b) for n,b in items],indent=2))
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        m=json.loads(z.read('MANIFEST.json'));assert {x['file'] for x in m}==set(z.namelist())-{'MANIFEST.json'}
        for x in m:assert x==info(x['file'],z.read(x['file']))

(D/'.gitattributes').write_bytes(b'*.json -text whitespace=cr-at-eol\n*.md -text\n*.zip -text\n*.py -text\n')
for n in ['ISOLATION.json','FROZEN-STACK-FLOW-44.json','MEMBER-ACCESS.json','SCOPED-CHECK-RECEIPT.json']:
    (D/n).write_bytes((Q/n).read_bytes())
pack(D/'PENDING-R4-CANDIDATE.zip',[('STARTUP-R4-PENDING.dll',(Q/'candidate3.dll').read_bytes())])
items=[('remaining-native/'+p.name,p.read_bytes()) for p in (W/'remaining-native').iterdir() if p.is_file()]
items += [('startup-r4/'+p.name,p.read_bytes()) for p in Q.iterdir() if p.is_file() and p.suffix!='.dll']
items += [('startup-r2/construct.py',(W/'startup-r2/construct.py').read_bytes()),('save_r4_pending.py',Path(__file__).read_bytes())]
pack(D/'SOURCE-AND-SCOPED-EVIDENCE.zip',items)
pack(D/'FIRST-ATTEMPT-STACK-FAILURE.zip',[(n,(Q/n).read_bytes()) for n in ['candidate1.dll','construction1.json','FIVE-CIL.json','FROZEN-STACK-FLOW.json']])
js(D/'CURRENT-RESULT.json',dict(status='CONSTRUCTED_SCOPED_STATIC_PASS_RUNTIME_PENDING',parent_sha256='752939d1ae69877ef457945f6e0dfe61c749e8d4657e720075adcbcc76cc2e7f',candidate_sha256='530550053cfae3d8be6ea886f87ee77b74e5c1cc8c2b96517b5ac18d3cbb4ec9',methods=5,sites=26,
                             frozen_stack_passed=44,member_access_passed=5,untouched_methods_against_r3=2312,raw_isolation_negative_controls=7,
                             real_clr_method_execution='PENDING',native_execution_comparison='PENDING',unity_startup='NOT_RUN_ON_R4',il2cpp='NOT_RUN_ON_R4',ipa=None,
                             current_shader_workflow_dll='UNCHANGED_STARTUP_R3'))
(D/'README.md').write_bytes('''# Startup R4 — pending behavior qualification

This is a five-method construction checkpoint, **not an accepted replacement DLL**. Shader R1's Unity workflow still uses Startup R3 (`752939d1…cc2e7f`). No R4 Unity/IL2CPP/IPA/device claim is made.

The candidate SHA-256 is `530550053cfae3d8be6ea886f87ee77b74e5c1cc8c2b96517b5ac18d3cbb4ec9` (18,429,952 bytes). Repeated construction produces identical bytes. Scope:

* `0x06000089 System2.ChangeEnemyType`: use the original public `TMP_InputField.get_text` for its protected `m_Text` read. Original PC TMP image module/pointer and native `mov rax,[rcx+0x220]; ret` are archived.
* `0x060002AD Board.Update_isWon`: restore three float-zero constants and two existing singleton getter calls. Native `COMISS 0,endTime; JB` requires the final `clt.un`, including unordered/NaN; the separate boolean-zero comparison stays integer.
* `0x060005E7 BuffUIController_Zombie.FixedUpdate`: restore two float-zero constants and three original-backed AttackPoint getter reads. Two native `MOV r8d,0xffffffff` arguments are Int32 -1, not Int64 4294967295. Each 9-byte damaged literal becomes 5-byte `ldc.i4 -1` plus four NOPs, preserving every old IL target and body size. Existing `!=0` comparison keeps native JP/JNE NaN behavior.
* `0x060007B7 / 0x060007B8 TMP_TextEventCheck.OnEnable/OnDisable`: close the link listener constructor as `UnityAction<string,string,int>` and use ten existing public event getters.

The frozen checker is unchanged (`2bb0a8c2…63d14`). It passes the 44-method union of the old 40-target startup set and these five targets (System2 overlaps). The independent member-access checker passes all five new targets with zero unresolved/rejected references. These are static gates only.

The independent raw audit imports no patch constructor. It verifies all 2,317 method rows, the exact five expected body deltas, 2,312 untouched methods, identical old metadata rows/heaps, two appended MemberRefs, one appended TypeSpec and one 9-byte blob entry. Headers, RVAs, locals, branches, EH regions, visibility, original SerializeField markers and the R3 helper-root repair stay unchanged. Seven physical isolation mutants are rejected.

The first candidate passed four of five stack checks but exposed two additional malformed Int64 literals in BuffUIController. Its actual DLL/CIL/report remain in `FIRST-ATTEMPT-STACK-FAILURE.zip`; it is not promoted. The Int32 correction is bound to native addresses `0x18039A604` and `0x18039A767`.

Next required work: execute the actual restored CIL in controlled fixtures, compare normal paths and side-effect traces against original native code, retain invalid controls, then qualify any candidate compiler/startup run separately. Native CFG evidence currently follows normal direct control flow only; it does not model Windows exception unwinding. Administrator.Start_关卡配置文件 and other previously held access/method defects remain open. Construction counts must not be presented as semantically accepted game methods.
'''.encode())
js(D/'MANIFEST.json',[info(p.relative_to(D).as_posix(),p.read_bytes()) for p in sorted(D.rglob('*')) if p.is_file() and p!=D/'MANIFEST.json'])
print(json.dumps(dict(checkpoint=str(D),status='PENDING_RUNTIME_QUALIFICATION')))
