"""Five-method construction checkpoint; no runtime/gameplay promotion.

All body replacements are fixed width. Existing table rows and heap prefixes
stay unchanged; two MemberRefs and one TypeSpec are appended. Branches, locals,
EH regions, method RVAs and method headers remain byte-identical.
"""
from pathlib import Path
import hashlib,importlib.util,json,struct,sys

W=Path(__file__).resolve().parent.parent;ROOT=W.parents[1]
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
spec=importlib.util.spec_from_file_location('metadata_writer',W/'startup-r2/construct.py')
writer=importlib.util.module_from_spec(spec);spec.loader.exec_module(writer)
PARENT='752939d1ae69877ef457945f6e0dfe61c749e8d4657e720075adcbcc76cc2e7f'
ACCESS='05c7cc983d87488dc864e1399265237f0b3b77000e33173ca645edf6074a4de9'
TOKENS={0x06000089,0x060002AD,0x060005E7,0x060007B7,0x060007B8}
sha=lambda b:hashlib.sha256(b).hexdigest()

def need(value,message):
    if not value:raise ValueError(message)

def encode_compressed(n):
    if n<0x80:return bytes([n])
    if n<0x4000:return (n|0x8000).to_bytes(2,'big')
    need(n<0x20000000,'Bounded compressed integer')
    return (n|0xc0000000).to_bytes(4,'big')

def construct(parent,output,report):
    parent=Path(parent).resolve();output=Path(output).resolve();report=Path(report).resolve()
    need(len({parent,output,report})==3 and not output.exists() and not report.exists(),'Fresh distinct outputs')
    before=parent.read_bytes();need(sha(before)==PARENT,'Exact Startup R3 parent')
    pe=dnfile.dnPE(data=before);after=bytearray(before);changes=[]
    cli=pe.get_offset_from_rva(pe.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress)
    meta_rva,meta_size=struct.unpack_from('<II',before,cli+8);meta_at=pe.get_offset_from_rva(meta_rva)
    root_header,streams=writer.metadata_root(before[meta_at:meta_at+meta_size]);values={n:b for n,_,b in streams}
    header,rows,tail,counts=writer.tables_decode(values['#~'])
    need(header[6]==4,'Existing 4-byte blob heap indexes')
    mr=pe.net.mdtables.MemberRef.rows
    text_ref=mr[722]
    need(str(text_ref.Name)=='get_text' and text_ref.Signature.value==bytes.fromhex('20000e'),'Existing exact text getter signature/name')
    target=pe.net.mdtables.TypeRef.rows[24]
    need(str(target.TypeName)=='TMP_InputField' and str(target.TypeNamespace)=='TMPro','Existing TMP_InputField TypeRef')
    need(not any(str(r.Name)=='get_text' and r.Class.table.name=='TypeRef' and r.Class.row_index==25 for r in mr),'No duplicate TMP_InputField getter reference')
    rows[10].append([(25<<3)|1,rows[10][722][1],rows[10][722][2]])
    getter_token=0x0a000000|len(rows[10])
    action3=pe.net.mdtables.TypeRef.rows[156]
    need(str(action3.TypeName)=='UnityAction`3' and str(action3.TypeNamespace)=='UnityEngine.Events','Original UnityAction3 type owner')
    signature=bytes.fromhex('15128275030e0e08')
    need(not any(r.Signature.value==signature for r in pe.net.mdtables.TypeSpec.rows),'No duplicate closed delegate TypeSpec')
    blob=bytearray(values['#Blob']);blob_at=len(blob);blob.extend(encode_compressed(len(signature))+signature)
    rows[27].append([blob_at]);type_token=0x1b000000|len(rows[27])
    # Both damaged instructions call the same constructor; reuse its immutable
    # .ctor string and (object,native int)->void instance signature bytes.
    ctor_source=None
    for token,offset in [(0x060007B7,318),(0x060007B8,288)]:
        method=pe.net.mdtables.MethodDef.rows[(token&0xffffff)-1]
        at=pe.get_offset_from_rva(method.Rva);head=(struct.unpack_from('<H',before,at)[0]>>12)*4
        need(before[at+head+offset]==0x73,'Exact damaged newobj')
        constructor=struct.unpack_from('<I',before,at+head+offset+1)[0]
        need(constructor>>24==10,'Existing constructor MemberRef')
        source=mr[(constructor&0xffffff)-1]
        need(str(source.Name)=='.ctor' and source.Signature.value==bytes.fromhex('2002011c18'),'Exact delegate constructor call shape')
        need(source.Class.table.name=='TypeSpec' and source.Class.row.Signature.value==bytes.fromhex('15128275031c1c08'),'Exact damaged object/object/int closed delegate')
        if ctor_source is None:ctor_source=constructor
        need(ctor_source==constructor,'Same original malformed delegate constructor')
    old_ctor=rows[10][(ctor_source&0xffffff)-1]
    rows[10].append([((type_token&0xffffff)<<3)|4,old_ctor[1],old_ctor[2]])
    constructor_token=0x0a000000|len(rows[10])

    def replace(token,offset,expected,new,reason):
        need(token in TOKENS and len(expected)==len(new),'Explicit fixed-width method scope')
        method=pe.net.mdtables.MethodDef.rows[(token&0xffffff)-1]
        at=pe.get_offset_from_rva(method.Rva);head=1 if before[at]&3==2 else (struct.unpack_from('<H',before,at)[0]>>12)*4
        pos=at+head+offset
        need(before[pos:pos+len(expected)]==expected,'Exact original instruction '+hex(token)+' '+hex(offset))
        need(after[pos:pos+len(expected)]==expected,'Unique non-overlapping patch')
        after[pos:pos+len(new)]=new
        changes.append(dict(token=f'0x{token:08X}',offset=offset,file_offset=pos,before=expected.hex(),after=new.hex(),reason=reason))

    source=(W/'PRIVATE-ACCESS-CLASSIFICATION.json').read_bytes();need(sha(source)==ACCESS,'Pinned private getter classification')
    access=json.loads(source.decode('utf-8-sig'))
    sites=[s for s in access['proposed_sites'] if int(s['token'],16) in TOKENS-{0x06000089}]
    need(len(sites)==15,'Exactly 15 original-backed public getter reads')
    for s in sites:
        token=int(s['token'],16);offset=int(s['offset'][3:],16)
        getter=int(s['getter']['method_token'],16);field=int(s['field_token'],16)
        replace(token,offset,bytes([0x7b if s['op']=='ldfld' else 0x7e])+struct.pack('<I',field),b'\x28'+struct.pack('<I',getter),'Original native-backed pure public getter')
    for token,offsets in [(0x060002AD,[83,338,366]),(0x060005E7,[212,911])]:
        for offset in offsets:
            replace(token,offset,b'\x20\0\0\0\0',b'\x22\0\0\0\0','Float zero comparison confirmed by COMISS/UCOMISS native operands')
    replace(0x060002AD,377,b'\xfe\x04',b'\xfe\x05','Native COMISS 0,endTime; JB skips settlement for positive OR unordered/NaN')
    for offset in [279,819]:
        replace(0x060005E7,offset,b'\x21\xff\xff\xff\xff\0\0\0\0',b'\x20\xff\xff\xff\xff\0\0\0\0',
                'Native MOV r8d,0xffffffff passes Int32 -1 at 0x18039A604 / 0x18039A767; four NOP bytes preserve every old IL target')
    for token,offset in [(0x060007B7,318),(0x060007B8,288)]:
        replace(token,offset,b'\x73'+struct.pack('<I',ctor_source),b'\x73'+struct.pack('<I',constructor_token),'Close link listener delegate as UnityAction<string,string,int>')
    method=pe.net.mdtables.MethodDef.rows[136]
    at=pe.get_offset_from_rva(method.Rva);head=(struct.unpack_from('<H',before,at)[0]>>12)*4
    field_token=struct.unpack_from('<I',before,at+head+75)[0]
    field=pe.net.mdtables.MemberRef.rows[(field_token&0xffffff)-1]
    need(field_token>>24==10 and str(field.Name)=='m_Text' and field.Class.row_index==25 and field.Signature.value==bytes.fromhex('060e'),'Exact protected TMP_InputField.m_Text string field')
    replace(0x06000089,74,b'\x7b'+struct.pack('<I',field_token),b'\x28'+struct.pack('<I',getter_token),'Original TMP_InputField.get_text reads identical native offset +0x220')

    blob_growth=len(blob)-len(values['#Blob'])
    values['#Blob']=bytes(blob);values['#~']=writer.tables_encode(header,rows,tail,counts)
    metadata=bytearray(root_header)
    for name,header_at,_ in streams:
        start=writer.align(len(metadata),4);metadata.extend(b'\0'*(start-len(metadata)))
        struct.pack_into('<II',metadata,header_at,start,len(values[name]));metadata.extend(values[name])
    last=pe.sections[-1]
    need(last.Name.rstrip(b'\0')==b'.n29meta' and last.PointerToRawData+last.SizeOfRawData==len(before),'Original append-only section and no overlay')
    start=writer.align(len(after),4);after.extend(b'\0'*(start-len(after)));after.extend(metadata)
    end=len(after);raw_size=writer.align(end-last.PointerToRawData,pe.OPTIONAL_HEADER.FileAlignment)
    after.extend(b'\0'*(last.PointerToRawData+raw_size-len(after)))
    sh=last.get_file_offset();opt=pe.OPTIONAL_HEADER.get_file_offset()
    updates={sh+8:end-last.PointerToRawData,sh+16:raw_size,opt+8:pe.OPTIONAL_HEADER.SizeOfInitializedData+raw_size-last.SizeOfRawData,opt+56:writer.align(last.VirtualAddress+end-last.PointerToRawData,pe.OPTIONAL_HEADER.SectionAlignment),opt+64:0,cli+8:last.VirtualAddress+start-last.PointerToRawData,cli+12:len(metadata)}
    for at,value in updates.items():struct.pack_into('<I',after,at,value)
    allowed={p+i for p in updates for i in range(4)}|{c['file_offset']+i for c in changes for i in range(len(bytes.fromhex(c['before'])))}
    need(all(x==y or i in allowed for i,(x,y) in enumerate(zip(before,after))),'Whole original-prefix byte isolation')
    need(len(changes)==26 and {int(c['token'],16) for c in changes}==TOKENS,'Exact five-method/26-site construction scope')
    output.parent.mkdir(exist_ok=True,parents=True);output.write_bytes(after)
    result=dict(status='CONSTRUCTED_NOT_RUNTIME_QUALIFIED',parent_sha256=PARENT,candidate_sha256=sha(after),candidate_bytes=len(after),methods=sorted(f'0x{t:08X}' for t in TOKENS),site_changes=changes,
                appended_memberrefs=2,appended_typespecs=1,appended_blob_bytes=blob_growth,
                metadata_root_offset=start,metadata_root_bytes=len(metadata),new_tmp_text_getter=f'0x{getter_token:08X}',new_delegate_ctor=f'0x{constructor_token:08X}',new_delegate_typespec=f'0x{type_token:08X}',
                method_headers_locals_branches_eh_unchanged=True,field_visibility_changed=False,shader_candidate_changed=False,runtime_semantics='PENDING')
    report.write_bytes((json.dumps(result,indent=2)+'\n').encode())
    print(json.dumps({k:v for k,v in result.items() if k!='site_changes'}))
    return result

if __name__=='__main__':
    need(len(sys.argv)==4,'parent fresh-candidate fresh-report')
    construct(*sys.argv[1:])
