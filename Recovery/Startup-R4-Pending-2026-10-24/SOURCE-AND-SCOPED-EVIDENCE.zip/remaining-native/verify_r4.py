"""Independent raw-body and metadata audit; never imports the constructor."""
from pathlib import Path
import collections,hashlib,importlib.util,json,struct,sys
W=Path(__file__).resolve().parent.parent;ROOT=W.parents[1];Q=W/'startup-r4'
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
sys.path.insert(0,str(ROOT/'audit/bulk388-qualification-2026-10-23/width-check'))
import dnfile
from width_fixtures import SC,width
spec=importlib.util.spec_from_file_location('raw_reader',ROOT/'audit/native111-publication-2026-10-20/repository/scripts/actions/static_gates.py')
raw=importlib.util.module_from_spec(spec);spec.loader.exec_module(raw)
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(ok,message):
    if not ok:raise ValueError(message)

def read(data):
    p=raw.parse_pe_and_cli(data);m=raw.parse_metadata_root(data,p['meta_off'],p['meta_size']);d=dnfile.dnPE(data=data)
    b=m['streams']['#~']['bytes'];flags=b[6];mask=struct.unpack_from('<Q',b,8)[0];at=24;counts={}
    for t in range(64):
        if mask>>t&1:counts[t]=struct.unpack_from('<I',b,at)[0];at+=4
    rows={}
    for t,n in counts.items():
        rows[t]=[]
        for _ in range(n):
            row=[]
            for col in SC[t]:
                size=width(col,flags,counts);row.append(int.from_bytes(b[at:at+size],'little'));at+=size
            rows[t].append(row)
    return p,m,d,rows,b[at:]

def body(data,pe,rid):
    method=pe.net.mdtables.MethodDef.rows[rid-1]
    if not method.Rva:return b'',None,0
    at=pe.get_offset_from_rva(method.Rva);span=raw.parse_raw_method_body_span(data,at)[0]
    head=1 if data[at]&3==2 else (struct.unpack_from('<H',data,at)[0]>>12)*4
    return data[at:at+span],at,head

parent=(W/'startup-r3/candidate1.dll').read_bytes()
need(sha(parent)=='752939d1ae69877ef457945f6e0dfe61c749e8d4657e720075adcbcc76cc2e7f','Pinned R3 parent')
pp,pm,pd,pr,pt=read(parent)
plan_bytes=(W/'PRIVATE-ACCESS-CLASSIFICATION.json').read_bytes()
need(sha(plan_bytes)=='05c7cc983d87488dc864e1399265237f0b3b77000e33173ca645edf6074a4de9','Independent reviewed getter plan')
targets={0x06000089,0x060002AD,0x060005E7,0x060007B7,0x060007B8}
expected={t:bytearray(body(parent,pd,t&0xffffff)[0]) for t in targets}
permitted=set();expected_changes=[]
def patch(token,offset,old,new):
    b,at,head=body(parent,pd,token&0xffffff)
    need(b[head+offset:head+offset+len(old)]==old,'Independent old bytes')
    expected[token][head+offset:head+offset+len(old)]=new
    permitted.update(range(at+head+offset,at+head+offset+len(old)))
    expected_changes.append((token,offset,at+head+offset,len(old)))

for site in json.loads(plan_bytes.decode('utf-8-sig'))['proposed_sites']:
    token=int(site['token'],16)
    if token not in targets-{0x06000089}:continue
    patch(token,int(site['offset'][3:],16),bytes([0x7b if site['op']=='ldfld' else 0x7e])+struct.pack('<I',int(site['field_token'],16)),b'\x28'+struct.pack('<I',int(site['getter']['method_token'],16)))
for token,offsets in [(0x060002AD,[83,338,366]),(0x060005E7,[212,911])]:
    for offset in offsets:patch(token,offset,bytes.fromhex('2000000000'),bytes.fromhex('2200000000'))
patch(0x060002AD,377,bytes.fromhex('fe04'),bytes.fromhex('fe05'))
for offset in [279,819]:patch(0x060005E7,offset,bytes.fromhex('21ffffffff00000000'),bytes.fromhex('20ffffffff00000000'))
new_text=0x0a000000|len(pr[10])+1;new_ctor=new_text+1;new_type=0x1b000000|len(pr[27])+1
for token,offset in [(0x060007B7,318),(0x060007B8,288)]:
    b,_,head=body(parent,pd,token&0xffffff);old=b[head+offset:head+offset+5]
    need(old[0]==0x73,'Original constructor')
    patch(token,offset,old,b'\x73'+struct.pack('<I',new_ctor))
b,_,head=body(parent,pd,0x89);patch(0x06000089,74,b[head+74:head+79],b'\x28'+struct.pack('<I',new_text))
need(len(expected_changes)==26,'26 independently specified sites')
headers=[pp['sections'][-1]['header_offset']+8,pp['sections'][-1]['header_offset']+16,pp['opt_off']+8,pp['opt_off']+56,pp['opt_off']+64,pp['cli_off']+8,pp['cli_off']+12]
permitted.update(at+i for at in headers for i in range(4))

def audit(data):
    cp,cm,cd,cr,ct=read(data)
    need(ct==pt,'Metadata table tail unchanged')
    need(cm['streams'].keys()==pm['streams'].keys() and cm['heap_sizes']==pm['heap_sizes'] and cm['valid_mask']==pm['valid_mask'] and cm['sorted_mask']==pm['sorted_mask'],'Unchanged stream/table encoding flags')
    for t,rows in pr.items():
        need(cr[t][:len(rows)]==rows,'Existing metadata rows preserved: table '+str(t))
        need(len(cr[t])-len(rows)=={10:2,27:1}.get(t,0),'Exact append-only table roster')
    need(cr[10][-2]==[(25<<3)|1,pr[10][722][1],pr[10][722][2]],'Exact TMP_InputField public text getter MemberRef')
    ctor=cd.net.mdtables.MemberRef.rows[-1]
    need(str(ctor.Name)=='.ctor' and ctor.Signature.value==bytes.fromhex('2002011c18'),'Closed delegate instance ctor signature')
    need(ctor.Class.table.name=='TypeSpec' and ctor.Class.row_index==(new_type&0xffffff),'Closed delegate ctor owner')
    need(ctor.Class.row.Signature.value==bytes.fromhex('15128275030e0e08'),'UnityAction<string,string,int> exact generic arguments')
    need(cr[27][-1]==[len(pm['streams']['#Blob']['bytes'])],'New TypeSpec points at appended blob')
    for stream in ['#Strings','#GUID','#US']:
        need(cm['streams'][stream]['bytes']==pm['streams'][stream]['bytes'],'Unchanged '+stream+' heap')
    need(cm['streams']['#Blob']['bytes']==pm['streams']['#Blob']['bytes']+bytes.fromhex('0815128275030e0e08'),'Exactly one appended 8-byte generic signature')
    counts=collections.Counter()
    need(len(pd.net.mdtables.MethodDef.rows)==len(cd.net.mdtables.MethodDef.rows)==2317,'Method roster')
    for rid,(old,new) in enumerate(zip(pd.net.mdtables.MethodDef.rows,cd.net.mdtables.MethodDef.rows),1):
        token=0x06000000|rid;need(old.Rva==new.Rva,'Unchanged MethodDef RVA')
        ob,_,_=body(parent,pd,rid);nb,_,_=body(data,cd,rid)
        need(nb==(bytes(expected[token]) if token in targets else ob),'Exact method body boundary '+hex(token))
        counts['targets' if token in targets else 'untouched']+=1
        if not old.Rva:counts['zero_rva']+=1
    need(cp['meta_off']==len(parent) and data[len(parent):cp['meta_off']]==b'','Metadata appended exactly at original EOF')
    need(all(a==b or i in permitted for i,(a,b) in enumerate(zip(parent,data))),'Whole original-prefix byte isolation')
    need(data[cp['meta_off']+cp['meta_size']:]==b'\0'*(len(data)-cp['meta_off']-cp['meta_size']),'Only zero append padding')
    return dict(scope='FIVE_METHODS_EXACT_BYTE_AND_METADATA_ISOLATION_ONLY',candidate_sha256=sha(data),target_methods=counts['targets'],untouched_methods=counts['untouched'],zero_rva_methods=counts['zero_rva'],sites=26,new_memberrefs=2,new_typespecs=1,field_visibility_unchanged=True,method_headers_locals_branches_eh_unchanged=True,runtime_qualified=False)

if __name__=='__main__':
    candidate=(Q/'candidate3.dll').read_bytes();result=audit(candidate)
    need(candidate==(Q/'candidate4.dll').read_bytes(),'Deterministic repeated construction')
    controls=[]
    def reject(name,fn):
        data=bytearray(candidate);fn(data)
        try:audit(bytes(data))
        except Exception as error:controls.append(dict(name=name,rejected=True,reason=str(error)));return
        raise AssertionError('False accept: '+name)
    cp,cm,cd,_,_=read(candidate)
    def at(token,offset):return body(candidate,cd,token&0xffffff)[1]+body(candidate,cd,token&0xffffff)[2]+offset
    reject('unrelated-GameStart-body',lambda b:b.__setitem__(at(0x06000526,0),0))
    reject('integer-bool-zero-wrongly-flipped-to-float',lambda b:b.__setitem__(at(0x060002AD,403),0x22))
    reject('NaN-unordered-comparison-removed',lambda b:b.__setitem__(at(0x060002AD,377)+1,4))
    reject('Int64-sentinel-restored',lambda b:b.__setitem__(at(0x060005E7,279),0x21))
    reject('delegate-ctor-wrong-owner',lambda b:struct.pack_into('<H',b,cd.net.mdtables.MemberRef.rows[-1].struct.get_field_absolute_offset('Class_CodedIndex'),0))
    field=cd.net.mdtables.Field.rows[0].struct.get_field_absolute_offset('Flags')
    reject('field-flags-changed',lambda b:b.__setitem__(field,b[field]^1))
    root=cd.net.mdtables.TypeDef.rows[319].struct.get_field_absolute_offset('Extends_CodedIndex')
    reject('previously-repaired-helper-root-damaged',lambda b:struct.pack_into('<H',b,root,0))
    result['negative_controls']=controls;result['negative_controls_passed']=all(c['rejected'] for c in controls)
    (Q/'ISOLATION.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
    print(json.dumps(result,indent=2))
