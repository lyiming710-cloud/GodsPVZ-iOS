from pathlib import Path
import hashlib,importlib.util,json,subprocess
W=Path(__file__).resolve().parent.parent;ROOT=W.parents[1];Q=W/'startup-r4'
DOT=ROOT/'.local/dotnet10/dotnet.exe'
SUPPORT=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'
EXPORT=ROOT/'audit/bulk250-r1-evidence-39702928368/bulk250-r1-run/tools_bin/CilExporter/bin/CilExporter.dll'
CHECKER=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py'
MEMBER=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/member-bin/MemberAccess.dll'
candidate=Q/'candidate3.dll';digest=hashlib.sha256(candidate.read_bytes()).hexdigest()
assert digest=='530550053cfae3d8be6ea886f87ee77b74e5c1cc8c2b96517b5ac18d3cbb4ec9'
original=json.loads((W/'startup-r2/construction1.json').read_text('utf-8-sig'))
tokens=sorted({s['token'] for s in original['site_changes']}|{'0x06000089','0x060002AD','0x060005E7','0x060007B7','0x060007B8'})
assert len(tokens)==44
proc=subprocess.run([str(DOT),str(EXPORT),str(candidate),str(Q/'FORTY-FOUR-CIL.json'),str(SUPPORT),','.join(tokens)],capture_output=True)
(Q/'cil-export.log').write_bytes(proc.stdout+proc.stderr);assert proc.returncode==0
assert hashlib.sha256(CHECKER.read_bytes()).hexdigest()=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14'
spec=importlib.util.spec_from_file_location('unchanged_frozen',CHECKER);checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
cil=json.loads((Q/'FORTY-FOUR-CIL.json').read_text('utf-8-sig'));results=[]
for method in cil['methods']:
    try:result=checker.verify(method,cil['types'])
    except Exception as error:result=dict(token=method['token'],status='FAIL',error=str(error))
    results.append(result)
report=dict(scope='UNCHANGED_FROZEN_STACK_FLOW_ONLY',candidate_sha256=digest,checker_sha256=hashlib.sha256(CHECKER.read_bytes()).hexdigest(),total=len(results),passed=sum(r.get('status')=='PASS' for r in results),results=results)
(Q/'FROZEN-STACK-FLOW-44.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
assert report['total']==report['passed']==44
proc=subprocess.run([str(DOT),str(MEMBER),str(candidate),str(SUPPORT),str(Q/'METHODS.json'),str(Q/'MEMBER-ACCESS.json')],capture_output=True)
(Q/'member-access.log').write_bytes(proc.stdout+proc.stderr)
assert proc.returncode==0
receipt=dict(scope='REPRODUCIBLE_SCOPED_STATIC_CHECKS_NOT_RUNTIME_ACCEPTANCE',candidate_sha256=digest,
             tools=[dict(file=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in [EXPORT,CHECKER,MEMBER]],
             frozen_stack_methods=44,new_member_access_methods=5,member_access_exit=proc.returncode,unity_started=False)
(Q/'SCOPED-CHECK-RECEIPT.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps(receipt))
