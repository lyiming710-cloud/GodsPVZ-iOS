"""Original Core module GameObject caller, valid sealed-GameObject domain.

The generic AddComponent has no direct CodeGen pointer; it is deliberately not
claimed native-executed. Component.gameObject is a controlled engine callee.
"""
from pathlib import Path
import ctypes as C,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;sys.path.insert(0,str(W/'startup-r5'));from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
cfg=json.loads((Q/'ORIGINAL-GAMEOBJECT-NATIVE.json').read_bytes());actual=json.loads((Q/'ACTUAL-CIL-SOURCE-COMPARE.json').read_bytes());im=NativeImage();entry=int(cfg['original_va'],16)
assert get64(0x181cb2db0+(4104-1)*8)==entry,'Module-relative original Core method identity differs'
for i in cfg['instructions']:assert C.string_at(int(i['va'],16),len(bytes.fromhex(i['bytes'])))==bytes.fromhex(i['bytes'])
im.hook(0x18024fef0,None,[P],lambda p:None);state={}
def cls(depth,parents):
 p=im.alloc(512);tree=im.alloc(8*len(parents));C.c_ubyte.from_address(p+0x130).value=depth;put64(p+0xc8,tree)
 for k,parent in enumerate(parents):put64(tree+k*8,parent)
 return p,tree
base,bt=cls(1,[0]);put64(bt,base);game,gt=cls(2,[base,0]);put64(gt+8,game);comp,ct=cls(2,[base,0]);put64(ct+8,comp);child,_=cls(3,[base,comp,0])
dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True;slots=[]
for r in cfg['instructions']:
 i=next(dis.disasm(bytes.fromhex(r['bytes']),int(r['va'],16)))
 if i.mnemonic=='mov'and len(i.operands)==2 and i.operands[1].type==X86_OP_MEM and i.operands[1].mem.base==X86_REG_RIP:
  at=i.address+i.size+i.operands[1].mem.disp;slots.append((i.address,at))
assert len(slots)==2;put64(slots[0][1],game);put64(slots[1][1],comp)
def getgo(p,m):state['trace'].append('gameObject:'+state['tags'][p]);return state['owned'].get(p,0)
im.hook(0x1813044d0,P,[P,P],getgo);rows=[]
for row in actual['rows']:
 if row['name']!='GameObject' or row['shape']=='derived-game':continue
 shape=row['shape'];state.clear();state.update(tags={},owned={},trace=[])
 def obj(tag_,kind):p=im.alloc(64);put64(p,kind);state['tags'][p]=tag_;return p
 owner=obj('owner',game);value=0;wanted=0
 if shape=='other':value=obj('other',base)
 elif shape=='game':value=owner;wanted=owner
 elif shape=='dead-game':value=obj('dead-go',game);wanted=value
 elif shape in['component','dead-component','derived-component','component-null-go']:
  value=obj(shape,child if shape=='derived-component'else comp);wanted=0 if shape=='component-null-go'else owner;state['owned'][value]=wanted
  if shape=='component-null-go':state['tags'][value]='component-no-owner'
 result=C.CFUNCTYPE(P,P,P)(entry)(value,None)or 0;got=dict(name='GameObject',shape=shape,fail=row['fail'],error=None,result=state['tags'].get(result),returnsExactOwner=result==wanted,componentHasExactOwner=False,added=0,trace=state['trace']);assert not im.errors,im.errors;expected=row['actual'];rows.append(dict(shape=shape,fail=row['fail'],same=got==expected,native=got,actual_cil=expected))
im.close();assert all(r['same']for r in rows)
result=dict(scope='ORIGINAL_CORE_GAMEOBJECT_CALLER_VS_ACTUAL_CHILD_CIL_WITH_CONTROLLED_COMPONENT_GETTER',candidate_sha256=actual['candidate_sha256'],cases=len(rows),unique_input_shapes=len({r['shape']for r in rows}),differences=0,rows=rows,generic_addcomponent_native_execution='UNSUPPORTED_NO_DIRECT_METHOD_POINTER',derived_gameobject_fixture_excluded='UnityEngine.GameObject is sealed; synthetic subclass is outside native input domain',unity_or_ipa=False)
(Q/'NATIVE-GAMEOBJECT-COMPARE.json').write_text(json.dumps(result,indent=2)+'\n','utf-8');print(json.dumps({k:v for k,v in result.items()if k!='rows'}))
