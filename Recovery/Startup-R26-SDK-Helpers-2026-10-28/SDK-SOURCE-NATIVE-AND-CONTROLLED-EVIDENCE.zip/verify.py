"""Independent SDK prefix/table/body isolation and unchanged static tools."""
from pathlib import Path
import hashlib,importlib.util,json,struct,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'));import dnfile
def mod(n,p):s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
writer=mod('sdk_isolation_metadata_reader',W/'startup-r2/construct.py');reader=mod('sdk_isolation_span_reader',ROOT/'audit/native111-publication-2026-10-20/repository/scripts/actions/static_gates.py');sha=lambda b:hashlib.sha256(b).hexdigest()
a=(W/'r23-gameplay-run-40614900915/runtime-support/after-real-ui/Unity.VisualScripting.Core.dll').read_bytes();b=(Q/'authored1.dll').read_bytes();r=json.loads((Q/'authored1.json').read_bytes());assert sha(a)==r['parent_sha256']and sha(b)==r['candidate_sha256'];ap=dnfile.dnPE(data=a);bp=dnfile.dnPE(data=b);targets={int(x['token'],16)&0xffffff for x in r['changes']};assert targets=={0x903,0x904};allowed=set(r['header_updates']);allowed={i for k in allowed for i in range(int(k),int(k)+4)}
assert all(x==y or i in allowed for i,(x,y)in enumerate(zip(a,b)))
changed=[]
for rid,(x,y)in enumerate(zip(ap.net.mdtables.MethodDef.rows,bp.net.mdtables.MethodDef.rows),1):
 if not x.Rva:assert not y.Rva;continue
 at=ap.get_offset_from_rva(x.Rva);bt=bp.get_offset_from_rva(y.Rva);an=reader.parse_raw_method_body_span(a,at)[0];bn=reader.parse_raw_method_body_span(b,bt)[0]
 if a[at:at+an]!=b[bt:bt+bn]:changed.append(rid)
 if rid not in targets:assert x.Rva==y.Rva and a[at:at+an]==b[bt:bt+bn]
 else:assert x.Rva!=y.Rva and a[at:at+an]==b[at:at+an]
assert set(changed)==targets and len(ap.net.mdtables.MethodDef.rows)==len(bp.net.mdtables.MethodDef.rows)==4935
def meta(data,p):
 cli=p.get_offset_from_rva(p.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress);va,size=struct.unpack_from('<2I',data,cli+8);at=p.get_offset_from_rva(va);_,st=writer.metadata_root(data[at:at+size]);v={n:b for n,_,b in st};_,rows,_,_=writer.tables_decode(v['#~']);return v,rows
av,ar=meta(a,ap);bv,br=meta(b,bp)
for n,x in av.items():
 if n=='#~':continue
 assert bv[n].startswith(x)if n in['#Blob','#Strings','#US']else bv[n]==x
for t,rows in ar.items():
 assert len(br[t])==len(rows)+len(r['added'].get(str(t),[]))
 for k,row in enumerate(rows):
  if t==6 and k+1 in targets:assert br[t][k][1:]==row[1:]
  else:assert br[t][k]==row
assert set(br)==set(ar)|{43}and len(br[43])==1
assert all(x.Characteristics==y.Characteristics for x,y in zip(ap.sections[:-1],bp.sections[:-1]))and bp.sections[-1].Characteristics==ap.sections[-1].Characteristics&~0x02000000
result=dict(scope='SDK_ONLY_ALL_4935_METHODDEF_AND_OLD_METADATA_ISOLATION',candidate_sha256=sha(b),parent_sha256=sha(a),changed_methods=2,unchanged_methoddefs=4933,old_code_slots_preserved=True,old_metadata_rows_heaps_method_flags_preserved=True,new_metadata_table=43,only_section_permission_change='CLEAR_DISCARDABLE_ON_EXTENDED_LAST_SECTION',game_assembly_edited=False,pass_=True,unity_or_ipa_proven=False)
(Q/'ISOLATION.json').write_text(json.dumps(result,indent=2)+'\n','utf-8')
tokens=['0x06000903','0x06000904'];(Q/'TARGETS.json').write_text(json.dumps(dict(methods=[dict(token=t)for t in tokens]))+'\n','utf-8');support=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support';dot=ROOT/'.local/dotnet10/dotnet.exe';exporter=ROOT/'audit/bulk250-r1-evidence-39702928368/bulk250-r1-run/tools_bin/CilExporter/bin/CilExporter.dll'
proc=subprocess.run([str(dot),str(exporter),str(Q/'authored1.dll'),str(Q/'CIL.json'),str(support),','.join(tokens)],capture_output=True);assert proc.returncode==0,proc.stderr
frozen=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py';assert sha(frozen.read_bytes())=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14';v=mod('sdk_unchanged_frozen',frozen);cil=json.loads((Q/'CIL.json').read_bytes());checks=[v.verify(m,cil['types'])for m in cil['methods']];(Q/'FROZEN-RAW.json').write_text(json.dumps(dict(candidate_sha256=sha(b),checker_sha256=sha(frozen.read_bytes()),results=checks),indent=2)+'\n','utf-8')
member=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/member-bin/MemberAccess.dll';proc=subprocess.run([str(dot),str(member),str(Q/'authored1.dll'),str(support),str(Q/'TARGETS.json'),str(Q/'MEMBER-ACCESS.json')],capture_output=True);(Q/'MEMBER-EXIT.json').write_text(json.dumps(dict(candidate_sha256=sha(b),exit_code=proc.returncode))+'\n','utf-8');assert proc.returncode==0,proc.stdout+proc.stderr
print(json.dumps(dict(isolation=result,strict=checks),indent=2))
