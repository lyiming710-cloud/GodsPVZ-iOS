"""Copy the exact two official method texts into an independent source fixture."""
from pathlib import Path
import hashlib,json
q=Path(__file__).resolve().parent;p=q.parent/'startup-r23-battle-loop/OFFICIAL-ComponentHolderProtocol-1.9.4.cs';data=p.read_bytes();assert hashlib.sha256(data).hexdigest()=='1fd885da87f69dee667d0898efffb2fb15716c7b00f48149a6eff15b1a6571f0';text=data.decode();methods=[]
for start in ['public static GameObject GameObject(this UnityObject uo)','public static T AddComponent<T>(this UnityObject uo) where T : Component']:
 at=text.index(start);begin=text.index('{',at);depth=1;end=begin+1
 while depth:
  depth+=int(text[end]=='{')-int(text[end]=='}');end+=1
 methods.append(text[at:end])
result='using System;\nusing UnityObject=UObj;\npublic static class Official {\n'+'\n'.join(methods)+'\n}\n';(q/'runtime/Official.cs').write_text(result,'utf-8');(q/'OFFICIAL-FIXTURE-BINDING.json').write_text(json.dumps(dict(original_source_sha256=hashlib.sha256(data).hexdigest(),fixture_sha256=hashlib.sha256(result.encode()).hexdigest(),two_method_texts_copied_without_body_edits=True),indent=2)+'\n','utf-8')
