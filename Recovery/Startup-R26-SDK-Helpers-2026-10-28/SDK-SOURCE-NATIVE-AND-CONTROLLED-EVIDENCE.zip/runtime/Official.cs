using System;
using UnityObject=UObj;
public static class Official {
public static GameObject GameObject(this UnityObject uo)
        {
            if (uo is GameObject)
            {
                return (GameObject)uo;
            }
            else if (uo is Component)
            {
                return ((Component)uo).gameObject;
            }
            else
            {
                return null;
            }
        }
public static T AddComponent<T>(this UnityObject uo) where T : Component
        {
            if (uo is GameObject)
            {
                return ((GameObject)uo).AddComponent<T>();
            }
            else if (uo is Component)
            {
                return ((Component)uo).gameObject.AddComponent<T>();
            }
            else
            {
                throw new NotSupportedException();
            }
        }
}
