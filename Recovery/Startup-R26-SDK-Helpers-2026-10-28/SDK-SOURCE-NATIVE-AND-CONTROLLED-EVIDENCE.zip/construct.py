"""Restore the two actually loaded default-return SDK helpers, append only.

Source authority: exact official com.unity.visualscripting 1.9.4 package already
archived and hashed. Game assembly is never written by this SDK-only builder.
"""
from pathlib import Path
import hashlib,importlib.util,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'));sys.dont_write_bytecode=True
import dnfile
def mod(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
writer=mod('sdk_append_only_metadata',W/'startup-r2/construct.py');labels=mod('sdk_labelled_cil',W/'startup-r13/construct.py');sha=lambda b:hashlib.sha256(b).hexdigest()
src=W/'r23-gameplay-run-40614900915/runtime-support/after-real-ui/Unity.VisualScripting.Core.dll';data=src.read_bytes();assert sha(data)=='dc1b51ccb332d73e52642f6a50fe0694661e51b8eb2ff7ca25381f1ab877c8f9';p=dnfile.dnPE(data=data);assert len(p.net.mdtables.MethodDef.rows)==4935
official=(W/'startup-r23-battle-loop/OFFICIAL-ComponentHolderProtocol-1.9.4.cs').read_bytes();assert sha(official)=='1fd885da87f69dee667d0898efffb2fb15716c7b00f48149a6eff15b1a6571f0'
cli=p.get_offset_from_rva(p.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress);assert struct.unpack_from('<I',data,cli+16)[0]==1 and struct.unpack_from('<2I',data,cli+32)==(0,0),'Do not silently invalidate a strong name'
mrva,msize=struct.unpack_from('<2I',data,cli+8);at=p.get_offset_from_rva(mrva);root,streams=writer.metadata_root(data[at:at+msize]);values={n:b for n,_,b in streams};head,rows,tail,counts=writer.tables_decode(values['#~']);added={1:[],10:[],43:[]}
def name(v):
 v=v.encode()+b'\0';i=len(values['#Strings']);values['#Strings']+=v;return i
def blob(v):i=len(values['#Blob']);values['#Blob']+=labels.comp(len(v))+v;return i
def tr(ns,n):
 found=[k for k,r in enumerate(p.net.mdtables.TypeRef.rows,1)if str(r.TypeNamespace)==ns and str(r.TypeName)==n]
 if found:assert len(found)==1;return found[0]
 scope=next(k for k,r in enumerate(p.net.mdtables.AssemblyRef.rows,1)if str(r.Name)=='mscorlib');rows[1].append([(scope<<2)|2,name(n),name(ns)]);rid=len(rows[1]);added[1].append(dict(token=hex(0x01000000|rid),namespace=ns,name=n));return rid
def member(owner,n,sig):
 coded=(owner<<3)|1
 for k,r in enumerate(p.net.mdtables.MemberRef.rows,1):
  if rows[10][k-1][0]==coded and str(r.Name)==n and r.Signature.value==sig:return 0x0a000000|k
 rows[10].append([coded,name(n),blob(sig)]);token=0x0a000000|len(rows[10]);added[10].append(dict(token=hex(token),owner_type_ref=owner,name=n,signature=sig.hex()));return token
game=tr('UnityEngine','GameObject');component=tr('UnityEngine','Component');exception=tr('System','NotSupportedException');getgo=member(component,'get_gameObject',bytes.fromhex('2000')+b'\x12'+labels.comp((game<<2)|1));add=member(game,'AddComponent',bytes.fromhex('3001001e00'));ctor=member(exception,'.ctor',bytes.fromhex('200001'));msig=bytes.fromhex('0a011e00');mcoded=((add&0xffffff)<<1)|1
if 43 not in rows:
 rows[43]=[];counts[43]=0;rows=dict(sorted(rows.items()));counts=dict(sorted(counts.items()));head=bytearray(head);struct.pack_into('<Q',head,8,struct.unpack_from('<Q',head,8)[0]|(1<<43));head=bytes(head)
matches=[k for k,r in enumerate(p.net.mdtables.MethodSpec.rows,1)if rows[43][k-1][0]==mcoded and r.Instantiation.value==msig]if hasattr(p.net.mdtables,'MethodSpec')else[]
if matches:assert len(matches)==1;spec=0x2b000000|matches[0]
else:rows[43].append([mcoded,blob(msig)]);spec=0x2b000000|len(rows[43]);added[43].append(dict(token=hex(spec),member_ref=hex(add),signature=msig.hex()))
holder=next(r for r in p.net.mdtables.TypeDef.rows if str(r.TypeNamespace)=='Unity.VisualScripting'and str(r.TypeName)=='ComponentHolderProtocol');targets={str(m.row.Name):m.row_index for m in holder.MethodList if str(m.row.Name)in['GameObject','AddComponent']};assert len(targets)==2
codes={}
for n in ['GameObject','AddComponent']:
 b=labels.IL().arg(0).token(0x75,0x01000000|game).op('25').branch(0x39,'component')
 if n=='AddComponent':b.token(0x6f,spec)
 b.op('2a').mark('component').op('26').arg(0).token(0x75,0x01000000|component).op('25').branch(0x39,'unsupported').token(0x6f,getgo)
 if n=='AddComponent':b.token(0x6f,spec)
 b.op('2a').mark('unsupported').op('26')
 if n=='GameObject':b.op('142a')
 else:b.token(0x73,ctor).op('7a')
 codes[targets[n]]=b.finish()
out=bytearray(data);section=p.sections[-1];assert section.Name.rstrip(b'\0')==b'.reloc'and section.Characteristics==0x42000040 and section.PointerToRawData+section.SizeOfRawData==len(out);changes=[]
for rid,code in codes.items():
 at=writer.align(len(out),4);out.extend(b'\0'*(at-len(out)));rva=section.VirtualAddress+at-section.PointerToRawData;out.extend(struct.pack('<HHII',0x3003,2,len(code),0)+code);row=p.net.mdtables.MethodDef.rows[rid-1];rows[6][rid-1][0]=rva;oldat=p.get_offset_from_rva(row.Rva);h=1 if data[oldat]&3==2 else(struct.unpack_from('<H',data,oldat)[0]>>12)*4;n=data[oldat]>>2 if h==1 else struct.unpack_from('<I',data,oldat+4)[0];changes.append(dict(token=hex(0x06000000|rid),name=str(row.Name),old_rva=hex(row.Rva),new_rva=hex(rva),old_code=data[oldat+h:oldat+h+n].hex(),new_code=code.hex()))
values['#~']=writer.tables_encode(head,rows,tail,counts);md=bytearray(root)
for n,h,b in streams:
 at=writer.align(len(md),4);md.extend(b'\0'*(at-len(md)));struct.pack_into('<II',md,h,at,len(values[n]));md.extend(values[n])
at=writer.align(len(out),4);out.extend(b'\0'*(at-len(out)));out.extend(md);end=len(out);rawsize=writer.align(end-section.PointerToRawData,p.OPTIONAL_HEADER.FileAlignment);out.extend(b'\0'*(section.PointerToRawData+rawsize-len(out)));sh=section.get_file_offset();opt=p.OPTIONAL_HEADER.get_file_offset();updates={sh+8:end-section.PointerToRawData,sh+16:rawsize,sh+36:0x40000040,opt+8:p.OPTIONAL_HEADER.SizeOfInitializedData+rawsize-section.SizeOfRawData,opt+56:writer.align(section.VirtualAddress+end-section.PointerToRawData,p.OPTIONAL_HEADER.SectionAlignment),opt+64:0,cli+8:section.VirtualAddress+at-section.PointerToRawData,cli+12:len(md)};allowed=set()
for at,value in updates.items():struct.pack_into('<I',out,at,value);allowed.update(range(at,at+4))
assert all(a==b or i in allowed for i,(a,b)in enumerate(zip(data,out))),'Changed original method bytes'
stem=sys.argv[1];path=Q/(stem+'.dll');assert not path.exists();path.write_bytes(out);j=dict(scope='SDK_ONLY_TWO_OFFICIAL_COMPONENT_HOLDER_METHODS_NO_GAME_ASSEMBLY_EDIT',parent_sha256=sha(data),candidate_sha256=sha(out),bytes=len(out),official_source_sha256=sha(official),official_package_version='1.9.4',changes=changes,added=added,header_updates=updates,section_permission_change=dict(section='.reloc',before='0x42000040',after='0x40000040',reason='Appended managed code/metadata must remain resident; clear DISCARDABLE only, no new execute or write permission'),original_methoddefs=4935,unchanged_methoddefs=4933,actual_unity_proven=False,ipa=None)
(Q/(stem+'.json')).write_text(json.dumps(j,indent=2)+'\n','utf-8');print(json.dumps({k:v for k,v in j.items()if k not in['header_updates','added']},indent=2))
