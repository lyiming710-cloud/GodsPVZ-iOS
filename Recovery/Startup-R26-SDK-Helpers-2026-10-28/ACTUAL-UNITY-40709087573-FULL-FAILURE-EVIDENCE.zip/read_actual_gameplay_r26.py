"""Read every delivered R26 file and retain the failed real-player observation."""
from pathlib import Path, PurePosixPath
from collections import Counter
import hashlib, json, math, struct, subprocess, sys

Q = Path(__file__).resolve().parent
W = Q.parent
R = W.parents[1] / 'audit/repo-native113'
D = W / 'r26-gameplay-run-40709087573'
C = R / 'Recovery/Startup-R26-SDK-Helpers-2026-10-28'
sys.path.insert(0, str(W))
from archive_support import js, pack, manifest
sha = lambda b: hashlib.sha256(b).hexdigest()
game = '9490c1845298fa5afda04fc8dfba915ce2a939eaebe96be83e3311b39557bc4c'
sdk = '51f72bcd146c5571f642f3c4149f0545eb704fd325d83eb0f7c4ca2deec14c2b'
head = '9ec1bc461d2c50172e8861191eaa1b0d7d63d92b'
delivery = json.loads((D/'gameplay/DELIVERY-MANIFEST.json').read_bytes())
seen = set()
for row in delivery['files']:
    p = PurePosixPath(row['path'])
    assert not p.is_absolute() and '..' not in p.parts and p.as_posix() not in seen
    b = (D/'gameplay'/p).read_bytes()
    assert len(b) == row['size'] and sha(b) == row['sha256'], p
    seen.add(p.as_posix())
actual_files = {p.relative_to(D/'gameplay').as_posix() for p in (D/'gameplay').rglob('*') if p.is_file()}
assert actual_files == seen | {'DELIVERY-MANIFEST.json'}
result = json.loads((D/'gameplay/GAMEPLAY-RESULT.json').read_bytes())
host = json.loads((D/'gameplay/HOST-RESULT.json').read_bytes())
assert result['candidate_sha256'] == game and result['workflow_head'] == head
assert host['candidate_unchanged'] and not host['timeout'] and host['exception'] is None
assert not result['game_dll_changed'] and not result['game_fields_assigned']
assert not result['units_spawned_by_probe'] and not result['unit_update_or_damage_called_by_probe']
assert result['status'] == 'ACTUAL_GAME_LOSS_OBSERVED' and not result['complex_gameplay_pass']
streams = {}
for name in ['UNIT-TRAJECTORIES', 'DEVICE-OBSERVATIONS', 'COMBAT-EVENTS', 'BANK-OBSERVATIONS', 'BATTLE-STATE']:
    streams[name] = [json.loads(line) for line in (D/'gameplay'/(name+'.jsonl')).read_bytes().splitlines() if line.strip()]
units = streams['UNIT-TRAJECTORIES']
assert len(units) == result['unit_samples']
assert not any(u['kind'] == 'Plant' and u['active'] and u['on_field'] == 'True' for u in units)
assert not any(u['kind'] == 'Projectile' and u['source_plant'] for u in units)
assert streams['COMBAT-EVENTS'][-1]['kind'] == 'ACTUAL_GAME_LOSS_OBSERVED'
errors = result['runtime_errors']
assert sum(e['count'] for e in errors) == 21
assert all(any(name in e['stack'] for name in ['HPUIController_Plant.Start', 'Plant.TryPlanting', 'Zombie.HeadDrop']) for e in errors)
probe = json.loads((D/'gameplay/R26-ACTUAL-SDK-HELPERS.json').read_bytes())
assert probe['loaded_sha256'] == sdk and probe['pass']
assert len(probe['checks']) == 10 and len({x['name'] for x in probe['checks']}) == 10
assert all(x['pass'] for x in probe['checks'])
assert not probe['game_fields_written'] and not probe['combat_units_created']
dumps = sorted((D/'runtime-support').rglob('Unity.VisualScripting.Core.dll'))
assert len(dumps) == 2 and all(sha(p.read_bytes()) == sdk for p in dumps)
support = json.loads((D/'editor/r26-actual-ui-runtime-support.json').read_bytes())
assert len(support['runtime_support_methods']) == 2
assert all(x['assembly_sha256'] == sdk and not x['error'] and x['il_hex'] for x in support['runtime_support_methods'])
resources = json.loads((D/'editor/r26-actual-original-resource-values.json').read_bytes())
assert resources['candidate_sha256'] == game and resources['collection_complete']
checks = [x for o in resources['objects'] for x in o['checks']]
assert len(checks) == 9902 and len(resources['objects']) == 70
for c in checks:
    if c['kind'] == 'scalar':
        assert c['expected'] == c['actual'], c
    elif c['kind'] == 'scalar_f32':
        # Compare after the original serialized Single rounding.
        assert struct.pack('<f', c['expected']) == struct.pack('<f', c['actual']), c
    elif c['kind'] == 'reference':
        e, a = c['expected'], c['actual']
        if not e['fileID']:
            assert a.get('fileID', a.get('instanceID')) == 0, c
        else:
            assert e['fileID'] == a['fileID'], c
            assert a['guid'] == e.get('guid', c.get('expected_local_guid')), c
    elif c['kind'] == 'array_length':
        # The returned format records only one length. Retain this observation
        # boundary rather than inventing an independent expected/actual pair.
        assert isinstance(c['count'], int) and c['count'] >= 0, c
    else:
        raise AssertionError(c)
assert all(o['failed_leaf_checks'] == o['unresolved_reference_checks'] == 0 for o in resources['objects'])
interaction = json.loads((D/'editor/r26-interaction-audit.json').read_bytes())
assert interaction['candidate_sha256'] == game and interaction['workflow_head'] == head
assert interaction['collection_complete'] and len(interaction['checks']) == 25
assert all(x['pass'] for x in interaction['checks']) and not interaction['runtime_errors']
assert (D/'editor/license-return-exit.txt').read_text().strip() == '0'
run = json.loads(subprocess.check_output(['C:/Program Files/GitHub CLI/gh.exe', 'run', 'view', '40709087573', '-R', 'lyiming710-cloud/GodsPVZ-iOS', '--json', 'status,conclusion,headSha,url'], cwd=R))
assert run['status'] == 'completed' and run['conclusion'] == 'failure' and run['headSha'] == head
readback = dict(
    scope='INDEPENDENT_READBACK_OF_REAL_UNITY_R26_FAILURE_AND_SEPARATE_SDK_ENGINE_PASS',
    run=run, candidate_sha256=game, sdk_sha256=sdk,
    delivery_files_rehashed=len(seen), raw_stream_records={k:len(v) for k,v in streams.items()},
    raw_runtime_error_occurrences=sum(e['count'] for e in errors), runtime_errors=errors,
    sdk_engine_checks=10, actual_loaded_sdk_copies_rehashed=2, sdk_real_engine='PASS',
    resource_report_leaf_records_reread=len(checks), resource_routes=70,
    resource_record_kinds=dict(Counter(c['kind'] for c in checks)),
    resource_array_length_limit='One returned count only; expected/actual pair not independently recomputed',
    ui_callback_checks=25, ui_callback_check_result='PASS', unity_license_return_exit=0,
    active_device_name_id_counts=[dict(name=n,ID=i,rows=c)for(n,i),c in sorted(Counter((u['name'],u['ID'])for u in streams['DEVICE-OBSERVATIONS'] if u['route']=='actual-scene').items())],
    gameplay_status=result['status'], gameplay_pass=False,
    board_started=result['board_started'], hand_after_os_click=next(c for c in result['checks'] if c['name']=='plant_prefab_on_hand_after_os_bank_click'),
    planting_attempts=result['planting_attempts'], onfield_plants=0, plant_sourced_projectiles=0,
    observed_game_seconds=result['observed_game_seconds'], host_result=host,
    current_child_actual_apple_compilation=False, ipa=None, ipad_acceptance=False, qualified_methods_added=0)
js(D/'ACTUAL-READBACK.json', readback)
js(C/'ACTUAL-UNITY-40709087573.json', readback)
pack(C/'ACTUAL-UNITY-40709087573-FULL-FAILURE-EVIDENCE.zip',
     [(p.relative_to(D).as_posix(),p.read_bytes()) for p in sorted(D.rglob('*')) if p.is_file()] +
     [('failed-step-log.txt',(W/'R26-40709087573-failed-steps.log').read_bytes()),
      ('read_actual_gameplay_r26.py',Path(__file__).read_bytes())])
progress = json.loads((C/'PROGRESS.json').read_bytes())
progress.update(status='ACTUAL_SDK_ENGINE_10_CHECKS_PASS_COMPLEX_GAMEPLAY_FAILED_AFTER_ONE_PLANTING_ATTEMPT',
                actual_unity_gameplay='FAIL_ACTUAL_GAME_LOSS_OBSERVED', actual_sdk_engine_probe='PASS_10_CHECKS',
                actual_resource_leaf_report_checks=9902, actual_input_hand_state='PASS',
                actual_planting='FAIL_NO_ONFIELD_PLANT', actual_child_apple_compilation=False)
js(C/'PROGRESS.json', progress)
with (C/'README.md').open('a',encoding='utf-8') as f:
    f.write('\n实际运行40709087573已结束：SDK两方法通过真实Unity对象的10项检查，两份实际Core DLL均回读为51f72bcd。复杂关卡仍失败：真实OS点击拿卡通过，但种植未产生场上植物，42.29游戏秒后原版败北界面出现；6251条单位观测、570条设备观测及21次原始异常完整保留。植物来源投射物为0，不能判定正常攻击通过。当前异常为血条Start、TryPlanting和HeadDrop；当前子版本未执行Apple编译，未生成IPA。\n')
manifest(C)
print(json.dumps({k:v for k,v in readback.items() if k not in ['runtime_errors','active_device_name_id_counts','host_result']},ensure_ascii=True))
