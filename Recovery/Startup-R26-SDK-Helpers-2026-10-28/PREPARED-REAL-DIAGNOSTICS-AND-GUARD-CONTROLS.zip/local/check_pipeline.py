from pathlib import Path
import hashlib,importlib.util,json,shutil,sys
Q=Path(__file__).resolve().parent;W=Q.parent;R=W.parents[1]/'audit/repo-native113';sys.path.insert(0,str(R/'scripts/actions'));sys.path.insert(0,str(W));import bind_startup_r26_diagnostic as b
from archive_support import js,manifest
out=Q/'binding-pipeline-fixture';out.mkdir();(out/'candidate').mkdir();(out/'evidence').mkdir();old=W/'r22-real-gameplay-2026-10-27/parent-package-fixture'
for p in old.iterdir():shutil.copyfile(p,out/('candidate'if p.name=='Assembly-CSharp-bulk401.dll'else'evidence')/p.name)
p=out/'evidence/PROVENANCE.json';j=json.loads(p.read_bytes());j['source_commit']='R26_LOCAL_BINDING_FIXTURE_NOT_ACTUAL_WORKFLOW';js(p,j);proof=b.bind(out,j['source_commit']);assert hashlib.sha256((out/'candidate/Assembly-CSharp-bulk401.dll').read_bytes()).hexdigest()==b.CANDIDATE;assert hashlib.sha256((out/'recovered-sdk/Unity.VisualScripting.Core.dll').read_bytes()).hexdigest()==b.SDK;parents=sorted(p.name for p in(out/'evidence').glob('PARENT-*PROVENANCE.json'));assert 'PARENT-R23-TRANSPORT-PROVENANCE.json'in parents
js(Q/'BINDING-PIPELINE-FIXTURE.json',dict(scope='LOCAL_FULL_TRANSPORT_AND_PAIR_BINDING_NOT_UNITY',game_sha256=b.CANDIDATE,sdk_sha256=b.SDK,parent_provenance_preserved=parents,pass_=True,unity_started=False,ipa_allowed=False))
controls=[];root=Q/'binding-negative-controls';root.mkdir()
for name,file,mutate in[
 ('invented-product-pass','PROGRESS.json',lambda j:j.update(whole_game_accepted=True)),
 ('hide-generic-native-limit','NATIVE-GAMEOBJECT-COMPARE.json',lambda j:j.update(generic_addcomponent_native_execution='PASS')),
 ('erase-actual-stub-differences','CONTROL-STUBS-OBSERVED.json',lambda j:j.update(old_stub_different_cases=0)),
 ('erase-old-sdk-isolation','ISOLATION.json',lambda j:j.update(unchanged_methoddefs=4932))]:
 target=root/name;shutil.copytree(b.CHECKPOINT,target);j=json.loads((target/file).read_bytes());mutate(j);js(target/file,j);manifest(target)
 try:b.validate_checkpoint(target)
 except ValueError as ex:controls.append(dict(name=name,rejected=True,reason=str(ex)));continue
 raise AssertionError('Bad SDK pair admitted: '+name)
js(Q/'BINDING-NEGATIVE-CONTROLS.json',dict(controls=len(controls),all_rejected=True,rows=controls));print(json.dumps(dict(pipeline_pass=True,negative_controls=len(controls),game_sha256=b.CANDIDATE,sdk_sha256=b.SDK)))
