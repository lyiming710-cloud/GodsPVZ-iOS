"""Seal local admission controls without claiming remote execution."""
from pathlib import Path
import ast,hashlib,json,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;R=Q.parents[1]/'repo-native113'
sys.path[:0]=[str(W),str(R/'scripts/actions')]
from archive_support import pack,manifest,js
import validate_startup_r28_checkpoint as game
C=game.ROOT
paths=list((R/'scripts/actions').glob('*r28*.py'))
for p in paths:ast.parse(p.read_text(encoding='utf-8'),filename=p.name)
exe=W/'zombie-serialization-2026-10-27/authoring-tools/actionlint.exe'
flows=[R/'.github/workflows'/n for n in ['bulk401-startup-runtime-gate.yml','startup-r28-real-gameplay-diagnostic.yml','startup-r28-editor-preflight.yml','startup-r28-compiler-check.yml','bulk401-generic-compiler-check.yml']]
proc=subprocess.run([str(exe),'-shellcheck=','-oneline']+[str(p)for p in flows],capture_output=True)
(Q/'ACTIONLINT.log').write_bytes(proc.stdout+proc.stderr)
assert proc.returncode==0,proc.stdout+proc.stderr
js(Q/'DIAGNOSTIC-SOURCE-CHECKS.json',dict(scope='LOCAL_PARSER_ACTIONLINT_EXACT_API_AND_TRANSPORT_ONLY',python_sources_parsed=len(paths),workflows_linted=len(flows),actionlint_exit_code=proc.returncode,unity_started=False))
for name in ['DIAGNOSTIC-SOURCE-CHECKS.json','BINDING-PIPELINE-FIXTURE.json','BINDING-NEGATIVE-CONTROLS.json','WORKFLOW-LITERAL-PATHS.json']:
 (C/name).write_bytes((Q/name).read_bytes())
archive=C/'ACTUAL-UNITY-DIAGNOSTIC-SOURCES-AND-LOCAL-CONTROLS.zip'
import zipfile
with zipfile.ZipFile(archive)as z:items=[(n,z.read(n))for n in z.namelist()if n!='MANIFEST.json']
for name in ['check_pipeline.py','check_workflow_paths.py','seal_checkpoint.py','DIAGNOSTIC-SOURCE-CHECKS.json','ACTIONLINT.log','BINDING-PIPELINE-FIXTURE.json','BINDING-NEGATIVE-CONTROLS.json','WORKFLOW-LITERAL-PATHS.json']:
 items.append(('local-authoring/'+name,(Q/name).read_bytes()))
pack(archive,items)
manifest(C)
proof=game.validate()
print(json.dumps(dict(candidate_sha256=game.CANDIDATE,checkpoint_files=len(json.loads((C/'MANIFEST.json').read_bytes())),admission=proof)))
