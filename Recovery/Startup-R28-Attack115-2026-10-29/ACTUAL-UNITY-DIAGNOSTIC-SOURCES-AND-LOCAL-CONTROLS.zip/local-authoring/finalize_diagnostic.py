"""Prepare fixed-candidate workflows; archive separate local tool controls."""
from pathlib import Path
import json, sys
Q=Path(__file__).resolve().parent; W=Q.parent; R=Q.parents[1]/'repo-native113'
sys.path.insert(0,str(W))
from archive_support import js, manifest, pack
S=R/'scripts/actions'; C=R/'Recovery/Startup-R28-Attack115-2026-10-29'
old='eef6c35a2dceb0c38d1032837204abaff56f3a4c4d029ca47d76ff496fd69293'
new='9081408a2226a79e23991355108540a0260a3966a500cecf4524f3cba9dfb364'
text=(S/'check_startup_r27_compiler.py').read_text().replace(old,new).replace('R27','R28').replace('r27','r28').replace('Lifecycle123','Attack115').replace('LIFECYCLE123','ATTACK115')
# Keep the already-reviewed SDK support-copy implementation and its immutable
# R26 input path instead of creating another derivative of that tool.
text=text.replace('from prepare_startup_r28_compiler_support import','from prepare_startup_r27_compiler_support import')
(S/'check_startup_r28_compiler.py').write_text(text,encoding='utf-8')
text=(R/'.github/workflows/startup-r27-compiler-check.yml').read_text().replace(old,new).replace('R27','R28').replace('r27','r28').replace('Lifecycle123','Attack115').replace('LIFECYCLE123','ATTACK115').replace('Lifecycle123-2026-10-28','Attack115-2026-10-29')
text=text.replace('Attack115-2026-10-28','Attack115-2026-10-29')
for name in ['startup-r28-compiler-check.yml','bulk401-generic-compiler-check.yml']:
 (R/'.github/workflows'/name).write_text(text,encoding='utf-8')

flow=R/'.github/workflows/bulk401-startup-runtime-gate.yml'
text=flow.read_text(encoding='utf-8')
marker='      - name: Export unsigned iOS Xcode project with exact R20 candidate\n'
step='''      - name: Independently rebuild actual attack ancestry even after natural defeat
        if: always() && inputs.gameplay_audit && inputs.audit_only && steps.actual_startup_probe.outcome == 'success'
        shell: bash
        run: |
          set -euo pipefail
          OUT="$RUNNER_TEMP/stage9-startup-r2/gameplay-output"
          python3 scripts/actions/read_startup_r28_attack_trace.py --folder "$OUT" --output "$OUT/INDEPENDENT-RAW-ATTACK-READBACK.json"

'''
assert text.count(marker)==1
if '      - name: Independently rebuild actual attack ancestry' not in text:
 text=text.replace(marker,step+marker)
flow.write_text(text,encoding='utf-8')
(R/'.github/workflows/startup-r28-real-gameplay-diagnostic.yml').write_text(text,encoding='utf-8')

p=C/'PROGRESS.json';j=json.loads(p.read_bytes())
j['known_next_acceptance']=[
 'Actual child image planting and HPUI / zombie lifecycle regression',
 'Actual plant-to-Zombie or Device TakeDamage ancestry from raw Unity profiler trees',
 'Actual complex-level paths, damage outcomes and survival observations',
 'Fresh child full conversion / all-source Linux compilation, then separately Apple / IPA / iPad']
js(p,j)
(C/'ACTUAL-PARENT-DIFFERENCES.json').write_bytes((Q/'ACTUAL-PARENT-DIFFERENCES.json').read_bytes())
for name in ['ATTACK-READER-CONTROLS.json','FINAL-EXACT-EDITOR-HELPERS.json']:
 (C/name).write_bytes((Q/name).read_bytes())
items=[]
for p in sorted(S.glob('*r28*.py')):items.append(('scripts/actions/'+p.name,p.read_bytes()))
for p in sorted(S.glob('*R28.cs')):items.append(('scripts/actions/'+p.name,p.read_bytes()))
for name in ['startup-r28-compiler-check.yml','bulk401-generic-compiler-check.yml','startup-r28-editor-preflight.yml','bulk401-startup-runtime-gate.yml','startup-r28-real-gameplay-diagnostic.yml']:
 p=R/'.github/workflows'/name;items.append(('.github/workflows/'+name,p.read_bytes()))
for name in ['check_attack_reader.py','compile_helpers.py','FINAL-EXACT-EDITOR-HELPERS.log','FINAL-EXACT-EDITOR-HELPERS.json','ATTACK-READER-CONTROLS.json','finalize_diagnostic.py']:
 items.append(('local-authoring/'+name,(Q/name).read_bytes()))
pack(C/'ACTUAL-UNITY-DIAGNOSTIC-SOURCES-AND-LOCAL-CONTROLS.zip',items)
readme=C/'README.md';text=readme.read_text(encoding='utf-8')
note='''
The new Editor-only observer requests a script reload before play after enabling deep profiling, following Unity 2022.3's ProfilerWindow implementation. It retains raw native-profiler sample tables, immediate and recursive child counts, marker IDs and ancestry. A separate Python reader reconstructs ancestry from immediate-child counts and rejects malformed trees, unrelated Device attacks, sibling plant samples and forged positive summary counters. Seventeen finite observation-tool controls pass; these are not actual Unity samples. All five helpers compile against the exact Editor APIs. The game image and game fields are not patched by these observers; profiling does affect timing, so this run cannot establish iPad performance. Actual target argument identity and complete damage equivalence remain outside this profiler observation.

Reference for observer setup: https://github.com/Unity-Technologies/UnityCsReference/blob/2022.3/Modules/ProfilerEditor/ProfilerWindow/ProfilerWindow.cs (SetEditorDeepProfiling requests EditorUtility.RequestScriptReload). The helper's real-engine support remains unobserved until the workflow executes. No child IPA has been generated.
'''
if 'The new Editor-only observer requests'not in text:readme.write_text(text+note,encoding='utf-8')
manifest(C)
print(json.dumps(dict(candidate=new,checkpoint=str(C),fresh_compiler_workflow=True,actual_unity_run_started=False)))
