"""Finite observation-tool controls, not game tests or actual Unity samples."""
from pathlib import Path
import copy, json, sys, tempfile
Q = Path(__file__).resolve().parent
R = Q.parents[1] / 'repo-native113'
sys.path.insert(0, str(R / 'scripts/actions'))
from read_startup_r28_attack_trace import CANDIDATE, frame_stacks, read

raw = dict(frame=42, thread=0, sample_count=4, tree_valid=True,
           profiler_enabled=True, deep_profiling=True, samples=[
    dict(index=0, parent=-1, children=1, descendants=3, name='PlayerLoop'),
    dict(index=1, parent=0, children=1, descendants=2, name='Plant:Shooting ()'),
    dict(index=2, parent=1, children=1, descendants=1, name='Plant::ST_Peasniper()'),
    dict(index=3, parent=2, children=0, descendants=0, name='Zombie.TakeDamage (Damage, bool)')])
rows = []
def check(name, transform, expected, valid=None):
    case = copy.deepcopy(raw)
    transform(case)
    result = frame_stacks(case)
    assert bool(result['rows']) == expected, (name, result)
    if valid is not None:
        assert result['valid'] == valid, (name, result)
    rows.append(dict(name=name, expected_stack=expected, observed_stack=bool(result['rows']), valid=result['valid']))

check('real-nested-shape', lambda r: None, True, True)
check('device-target', lambda r:r['samples'][3].update(name='Device::TakeDamage()'), True, True)
check('device-origin-only', lambda r:(r['samples'][1].update(name='Device:Attack()'), r['samples'][2].update(name='Device:Attack_Target()')), False, True)
check('plant-name-is-sibling', lambda r:(r['samples'][0].update(children=2), r['samples'][1].update(children=0, descendants=0), r['samples'][2].update(parent=0, name='Device:Attack()')), False, True)
check('different-owner-prefix', lambda r:(r['samples'][1].update(name='OtherPlant:Shooting()'), r['samples'][2].update(name='EvilPlant:ST_Peasniper()')), False, True)
check('different-method-suffix', lambda r:(r['samples'][1].update(name='Plant:ShootingAgain()'), r['samples'][2].update(name='Plant:ST_PeasniperAgain()')), False, True)
check('bad-parent-link', lambda r:r['samples'][3].update(parent=0), False, False)
check('bad-descendant-count', lambda r:r['samples'][1].update(descendants=1), False, False)
check('bad-child-count', lambda r:r['samples'][2].update(children=0), False, False)
check('negative-child-count', lambda r:r['samples'][1].update(children=-1), False, False)
check('sample-count-mismatch', lambda r:r.update(sample_count=5), False, False)
check('helper-marked-invalid', lambda r:r.update(tree_valid=False), False, False)
check('profiler-disabled', lambda r:r.update(profiler_enabled=False), False, True)
check('deep-profiling-disabled', lambda r:r.update(deep_profiling=False), False, True)

summary = dict(candidate_sha256=CANDIDATE, game_method_bytes_changed=False, game_fields_written=False,
               raw_frames_saved=1, plant_to_zombie_damage_stacks=1, plant_to_device_damage_stacks=0, error='')
with tempfile.TemporaryDirectory(prefix='r28-trace-controls-') as temp:
    folder = Path(temp)
    (folder/'R28-ACTUAL-ATTACK-TRACE.json').write_text(json.dumps(summary))
    (folder/'ATTACK-RAW-PROFILER-FRAMES.jsonl').write_text(json.dumps(raw)+'\n')
    assert read(folder)['plant_damage_call_stack_observed']
    bad = copy.deepcopy(raw)
    bad['samples'][1]['name'] = 'Device:Attack()'
    bad['samples'][2]['name'] = 'Device:Attack_Target()'
    (folder/'ATTACK-RAW-PROFILER-FRAMES.jsonl').write_text(json.dumps(bad)+'\n')
    result = read(folder)
    assert not result['plant_damage_call_stack_observed'] and result['summary_positive_without_raw_support']
    rows.append(dict(name='forged-helper-summary-not-trusted', rejected=True))
    (folder/'ATTACK-RAW-PROFILER-FRAMES.jsonl').write_text(json.dumps(raw)+'\n'+json.dumps(raw)+'\n')
    try: read(folder)
    except AssertionError: rows.append(dict(name='duplicate-raw-frame-rejected', rejected=True))
    else: raise AssertionError('Duplicate raw frame admitted')
    summary['candidate_sha256'] = '0'*64
    (folder/'R28-ACTUAL-ATTACK-TRACE.json').write_text(json.dumps(summary))
    try: read(folder)
    except AssertionError: rows.append(dict(name='wrong-candidate-rejected', rejected=True))
    else: raise AssertionError('Wrong candidate admitted')

report = dict(scope='OBSERVATION_TOOL_CONTROLS_ONLY_NO_UNITY_GAMEPLAY_EXECUTED',
              checks=len(rows), all_pass=True, rows=rows)
(Q/'ATTACK-READER-CONTROLS.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(dict(checks=len(rows), all_pass=True, actual_unity_executed=False)))
