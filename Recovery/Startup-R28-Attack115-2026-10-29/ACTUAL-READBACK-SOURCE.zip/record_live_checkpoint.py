"""Record exact dispatches and keep read-only path leads separate from fixes."""
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;R=Q.parents[1]/'repo-native113'
sys.path[:0]=[str(W),str(R/'scripts/actions')]
from archive_support import js,pack,manifest
import validate_startup_r28_checkpoint as game
C=game.ROOT;gh='C:/Program Files/GitHub CLI/gh.exe';runs=[]
for run_id in [40794439817,40794444003]:
 run=json.loads(subprocess.check_output([gh,'run','view',str(run_id),'-R','lyiming710-cloud/GodsPVZ-iOS','--json','status,conclusion,headSha,url,jobs'],cwd=R))
 assert run['headSha']=='8a0c2b0823739e87f9dc55062afc4430a511469e'
 runs.append(dict(run_id=run_id,**run))
js(C/'DISPATCH-40794439817-40794444003.json',dict(scope='ACTUAL_REMOTE_STATUS_SNAPSHOT_NOT_GAMEPLAY_PASS',captured_at_utc=datetime.now(timezone.utc).isoformat(),candidate_sha256=game.CANDIDATE,
      unity_run=40794439817,linux_compiler_run=40794444003,run_snapshot=runs))
(C/'R27-REAL-TRAJECTORY-DESCRIPTION.json').write_bytes((Q/'R27-REAL-TRAJECTORY-DESCRIPTION.json').read_bytes())
items=[(p.relative_to(Q).as_posix(),p.read_bytes())for p in sorted((Q/'next-path-review').rglob('*'))if p.is_file()]
items.extend((name,(Q/name).read_bytes())for name in ['read_trajectory_observations.py','extract_path_review.py'])
pack(C/'FOLLOWUP-READONLY-PATH-SOURCES-NO-PATCH.zip',items)
pack(C/'ACTUAL-READBACK-SOURCE.zip',[(n,(Q/n).read_bytes())for n in ['read_actual_compiler.py','record_live_checkpoint.py']])
with(C/'README.md').open('a',encoding='utf-8')as f:f.write('\nRead-only R27 trajectory review: all 35 observed zombie instances (8 IDs, 5667 samples) show some displacement; no nonfinite position was observed. Same-first-waypoint pair classification finds 2355 closer, 230 away and 19 stationary pairs. Sparse samples can cross unrecorded waypoint, hit or state changes; these are leads, not 230 established bugs. Five untouched path callers and their original PC CFGs were extracted for follow-up. No path method was changed in R28, and no all-level path equivalence is claimed.\n\nActual Unity run 40794439817 is retained separately from Linux compiler run 40794444003. Both execute source 8a0c2b0823739e87f9dc55062afc4430a511469e. The dispatch JSON is a timestamped remote status snapshot, not a final gameplay result. The selected fresh-save starter sniper and public Adventure-19 entry cannot establish save-unlock navigation, full-game balance or iPad performance.\n')
manifest(C);game.validate()
print(json.dumps(dict(checkpoint=str(C),manifest_rows=len(json.loads((C/'MANIFEST.json').read_bytes())),runs=[dict(run_id=r['run_id'],status=r['status'],conclusion=r['conclusion'])for r in runs])))
