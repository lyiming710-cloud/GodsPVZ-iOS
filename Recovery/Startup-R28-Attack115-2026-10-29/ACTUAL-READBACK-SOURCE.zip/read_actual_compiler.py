"""Authenticate current child inputs; reread all returned source bytes/logs."""
from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,re,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;R=Q.parents[1]/'repo-native113'
D=W/'r28-compiler-run-40794444003';C=R/'Recovery/Startup-R28-Attack115-2026-10-29'
sys.path.insert(0,str(W));from archive_support import js,pack,manifest
sha=lambda b:hashlib.sha256(b).hexdigest()
candidate='9081408a2226a79e23991355108540a0260a3966a500cecf4524f3cba9dfb364'
sdk='51f72bcd146c5571f642f3c4149f0545eb704fd325d83eb0f7c4ca2deec14c2b'
head='8a0c2b0823739e87f9dc55062afc4430a511469e';run_id=40794444003
report=json.loads((D/'startup-r28/STARTUP-R28-ATTACK115-COMPILER-REPORT.json').read_bytes())
entries=sum([json.loads((D/'startup-r28'/f).read_bytes())for f in ['ALL-CPP-RESULTS.json','ALL-C-RESULTS.json']],[])
assert report['candidate_sha256']==candidate and report['pass']and report['conversion']['exit_code']==0
assert report['actual_staged_sdk']['sha256']==sdk
assert len(entries)==1029 and len({r['file']for r in entries})==1029 and all(r['exit_code']==r['error_count']==0 for r in entries)
lookup={r['file']:r for r in entries};read=[];game=[]
with tarfile.open(D/'startup-r28-generated.tar.gz')as t:
 for member in t:
  p=PurePosixPath(member.name);assert not p.is_absolute()and'..'not in p.parts and not member.issym()and not member.islnk()
  if not member.isfile():continue
  if p.suffix in ['.cpp','.c']:
   b=t.extractfile(member).read();row=lookup[p.name];assert len(b)==row['bytes']and sha(b)==row['sha256'];read.append(p.name)
   if p.name.startswith('GodsPVZRuntime1'):game.append((p.name,b))
assert len(read)==len(set(read))==1029 and set(read)==set(lookup)
logs=[];negative=[];damaged_logs=[];warnings=0;input_proven=False
with tarfile.open(D/'startup-r28-evidence.tar.gz')as t:
 for member in t:
  p=PurePosixPath(member.name);assert not p.is_absolute()and'..'not in p.parts and not member.issym()and not member.islnk()
  if not member.isfile():continue
  if p.parent.as_posix()=='.validation/startup-r28/candidate/results/clang_logs'and p.name.endswith('.log'):
   b=t.extractfile(member).read();text=b.decode(errors='replace');assert not re.search(r': (?:fatal )?error:',text),p.name
   source=p.name[:-4];assert source in lookup;assert text.count(': warning:')==lookup[source]['warning_count']
   warnings+=text.count(': warning:');logs.append(source)
  elif p.name=='COHERENT-PLAYER-INPUT-ASSEMBLIES.json'and'/candidate/'in p.as_posix():
   inputs=json.loads(t.extractfile(member).read());sdkrows=[r for r in inputs['files']if PurePosixPath(r['name']).stem=='Unity.VisualScripting.Core']
   games=[r for r in inputs['files']if r['name']=='GodsPVZRuntime1.dll']
   assert len(sdkrows)==len(games)==1 and sdkrows[0]['sha256']==sdk and games[0]['sha256']==candidate
   input_proven=True
  elif p.name.endswith('.log')and('/controls/'in p.as_posix()or'/r4-control/'in p.as_posix()):
   text=t.extractfile(member).read().decode(errors='replace');errors=len(re.findall(r': (?:fatal )?error:',text))
   item=dict(file=p.as_posix(),raw_errors=errors)
   (negative if '/controls/'in p.as_posix()else damaged_logs).append(item)
assert input_proven and set(logs)==set(lookup)and len(logs)==1029
bad=[x for x in negative if PurePosixPath(x['file']).name.startswith('bad_')]
assert len(bad)==4 and all(x['raw_errors']for x in bad)
assert any(x['raw_errors']for x in damaged_logs), 'No raw damaged R4 error observed'
gh='C:/Program Files/GitHub CLI/gh.exe'
run=json.loads(subprocess.check_output([gh,'run','view',str(run_id),'-R','lyiming710-cloud/GodsPVZ-iOS','--json','status,conclusion,headSha,url'],cwd=R))
assert run['status']=='completed'and run['conclusion']=='success'and run['headSha']==head
result=dict(scope='ACTUAL_CURRENT_CHILD_LINUX_COMPILER_ALL_RAW_SOURCES_AND_LOGS_NOT_UNITY_OR_IPA',candidate_sha256=candidate,run_id=run_id,
 source_commit=head,pass_=True,conversion_exit=0,runtime_sdk_sha256=sdk,actual_input_manifest_proven=input_proven,
 raw_generated_sources_rehashed=len(read),raw_source_logs_rechecked=len(logs),cpp=755,c=274,raw_errors=0,raw_warnings=warnings,
 all_game_translation_units_preserved=len(game),generated_archive_bytes=(D/'startup-r28-generated.tar.gz').stat().st_size,
 generated_archive_sha256=sha((D/'startup-r28-generated.tar.gz').read_bytes()),
 evidence_archive_sha256=sha((D/'startup-r28-evidence.tar.gz').read_bytes()),raw_compiler_controls=negative,
 raw_damaged_R4_logs=damaged_logs,damaged_R4_control=report['damaged_r4_control'],unity_executed=False,apple_compiler_executed=False,ipa=None)
js(D/'ACTUAL-READBACK.json',result);js(C/'ACTUAL-COMPILER-40794444003.json',result)
pack(C/'ACTUAL-LINUX-40794444003-REPORTS-AND-GAME-SOURCES.zip',[(p.relative_to(D).as_posix(),p.read_bytes())for p in sorted(D.rglob('*'))if p.is_file()and p.name!='startup-r28-generated.tar.gz']+ [('generated-game/'+n,b)for n,b in game])
progress=json.loads((C/'PROGRESS.json').read_bytes());progress.update(status='SCOPED_ATTACK_CHECKS_AND_CURRENT_GAME_SDK_LINUX_PASS_REAL_UNITY_PENDING',current_linux_compiler='PASS_RAW_1029_SOURCES_AND_LOGS_READ_BACK');js(C/'PROGRESS.json',progress)
with(C/'README.md').open('a',encoding='utf-8')as f:f.write('\nR28 actual Linux run 40794444003 completed successfully at source 8a0c2b0823739e87f9dc55062afc4430a511469e and candidate 9081408a. Independently rehashed 755 C++ and 274 C sources and reread all 1029 raw compiler logs: 0 errors. Four bad compiler snippets and the damaged R4 input still produce errors. Actual converter input manifests bind this game and SDK 51f72bcd. The full generated archive hash is retained; all game-prefixed sources and raw logs are archived here. This is Linux conversion/syntax evidence only; actual child Unity, Apple linking, IPA and iPad acceptance are separate.\n')

# Correct an old prose label by its machine-readable and actual-run evidence.
# The JSON evidence was already bound to b504fa7/EEF; no result is reassigned.
old=R/'Recovery/Startup-R27-Lifecycle123-2026-10-28';p=old/'README.md';text=p.read_text(encoding='utf-8')
needle='固定3bdd831源码及9490c184候选';replacement='固定b504fa77c05262a054792fa0fce83f78050ecd88源码及eef6c35a2dceb0c38d1032837204abaff56f3a4c4d029ca47d76ff496fd69293候选'
assert text.count(needle)==1
prior=json.loads((old/'ACTUAL-COMPILER-40723256900.json').read_bytes())
assert prior['source_commit']=='b504fa77c05262a054792fa0fce83f78050ecd88'and prior['candidate_sha256']=='eef6c35a2dceb0c38d1032837204abaff56f3a4c4d029ca47d76ff496fd69293'
p.write_text(text.replace(needle,replacement),encoding='utf-8');manifest(old)
manifest(C)
print(json.dumps({k:v for k,v in result.items()if k not in ['damaged_R4_control','raw_compiler_controls','raw_damaged_R4_logs']}))
