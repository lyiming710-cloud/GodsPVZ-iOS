"""Read-only follow-up: current untouched path callers and original PC CFGs."""
from pathlib import Path
import json,sys
Q=Path(__file__).resolve().parent
sys.path.insert(0,str(Q))
import source_common as original
out=Q/'next-path-review';out.mkdir(exist_ok=True)
cil=json.loads((Q/'shared-authored2/ALL-CIL.json').read_bytes())
tokens={'0x06000427','0x06000428','0x06000429','0x06000433','0x0600044F'}
result=[]
for method in cil['methods']:
 if method['token']not in tokens:continue
 assert method==original.methods[method['token']], 'Path method changed between R27 and R28'
 native=original.native(method['token']);name=method['token']
 (out/(name+'-native.json')).write_text(json.dumps(native,indent=2)+'\n',encoding='utf-8')
 (out/(name+'-native.txt')).write_text('\n'.join(i['va']+' '+i['op']+' '+i['operands']for i in native['instructions'])+'\n',encoding='utf-8')
 (out/(name+'-cil.json')).write_text(json.dumps(method,indent=2)+'\n',encoding='utf-8')
 lines=[method['name'],'locals='+json.dumps(method['locals'])]
 for i in method['instructions']:
  op=i['operand'];text=op.get('identity',json.dumps(op))if isinstance(op,dict)else str(op)
  lines.append(f"IL_{i['offset']:04X} {i['opcode']} {text}")
 (out/(name+'-cil.txt')).write_text('\n'.join(lines)+'\n',encoding='utf-8')
 result.append(dict(token=name,method=method['name'],native_instruction_count=len(native['instructions']),
                    cil_instructions=len(method['instructions']),indirect_jumps=native['indirect_jumps'],
                    external_boundaries=native['outside_boundaries']))
(out/'SOURCE-REVIEW-STATUS.json').write_text(json.dumps(dict(scope='UNMODIFIED_SOURCE_EXTRACTION_NOT_CANDIDATE_OR_CORRECTNESS_PROOF',
 candidate_sha256='9081408a2226a79e23991355108540a0260a3966a500cecf4524f3cba9dfb364',methods=result),indent=2)+'\n')
print(json.dumps(result))
