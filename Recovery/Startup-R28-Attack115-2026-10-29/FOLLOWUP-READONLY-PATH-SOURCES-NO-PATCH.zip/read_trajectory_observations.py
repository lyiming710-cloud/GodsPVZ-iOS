"""Describe real samples; motion statistics never stand in for path equivalence."""
from pathlib import Path
from collections import Counter,defaultdict
import argparse,hashlib,json,math

def number(value):
    try:return float(value)
    except (ValueError,TypeError):return None

def read(folder):
    folder=Path(folder)
    report=json.loads((folder/'GAMEPLAY-RESULT.json').read_bytes())
    path=folder/'UNIT-TRAJECTORIES.jsonl';data=path.read_bytes()
    manifest=json.loads((folder/'DELIVERY-MANIFEST.json').read_bytes())
    row=next(r for r in manifest['files']if r['path']=='UNIT-TRAJECTORIES.jsonl')
    digest=hashlib.sha256(data).hexdigest()
    assert row['sha256']==digest and row['size']==len(data)
    rows=[json.loads(line)for line in data.splitlines()if line.strip()]
    assert len(rows)==report['unit_samples']
    groups=defaultdict(list);nonfinite=[]
    for index,row in enumerate(rows):
        if row['kind']!='Zombie' or not row['active']:continue
        groups[row['instance']].append(row)
        for field in ['x','y','z','logical_x','logical_y','logical_z']:
            value=number(row[field])
            if value is None or not math.isfinite(value):nonfinite.append(dict(row=index,instance=row['instance'],field=field,value=row[field]))
    counts=Counter();moving=set();away=[];ranges=[]
    for instance,samples in groups.items():
        points=[(number(r['x']),number(r['y']))for r in samples]
        if any(x is None or y is None or not math.isfinite(x+y)for x,y in points):continue
        span_x=max(p[0]for p in points)-min(p[0]for p in points)
        span_y=max(p[1]for p in points)-min(p[1]for p in points)
        if span_x>0.01 or span_y>0.01:moving.add(instance)
        ranges.append(dict(instance=instance,zombie_id=samples[0]['ID'],samples=len(samples),x_span=span_x,y_span=span_y,
                           first_time=samples[0]['time'],last_time=samples[-1]['time']))
        for a,b in zip(samples,samples[1:]):
            counts['adjacent_pairs']+=1
            if float(b['time'])<=float(a['time']):counts['non_increasing_sample_time']+=1;continue
            if any(r['dead']!='False' or r['on_field']!='True' or r['stance']!='False' or not r['path_nodes']for r in [a,b]):
                counts['not_active_nonstance_live_path_pair']+=1;continue
            na,nb=a['path_nodes'][0],b['path_nodes'][0]
            if any(na[k]!=nb[k]for k in ['grid_x','grid_y','x','y','arrived']):counts['first_waypoint_changed']+=1;continue
            if na['arrived']!='False' or number(a['waiting']) is None or number(b['waiting']) is None or max(float(a['waiting']),float(b['waiting']))>0:
                counts['arrived_or_waiting_pair']+=1;continue
            tx,ty=number(na['x']),number(na['y'])
            if tx is None or ty is None:counts['missing_waypoint_position']+=1;continue
            da=math.hypot(float(a['x'])-tx,float(a['y'])-ty)
            db=math.hypot(float(b['x'])-tx,float(b['y'])-ty)
            difference=db-da
            kind='closer_to_same_first_waypoint' if difference<-.001 else 'away_from_same_first_waypoint' if difference>.001 else 'stationary_to_same_first_waypoint'
            counts[kind]+=1
            if kind=='away_from_same_first_waypoint':
                away.append(dict(instance=instance,zombie_id=a['ID'],frame_a=a['frame'],frame_b=b['frame'],distance_change=difference,
                                 x_a=a['x'],y_a=a['y'],x_b=b['x'],y_b=b['y'],first_waypoint=na))
    return dict(scope='REAL_FRAME_SAMPLE_MOTION_DESCRIPTION_NOT_NORMAL_PATH_EQUIVALENCE',candidate_sha256=report['candidate_sha256'],
                workflow_head=report['workflow_head'],raw_units_sha256=digest,raw_samples=len(rows),
                active_zombie_samples=sum(len(x)for x in groups.values()),zombie_instances=len(groups),
                zombie_ids=sorted({r['ID']for g in groups.values()for r in g}),moving_instances=len(moving),
                nonfinite_coordinates=nonfinite,pair_classification=dict(counts),instance_ranges=ranges,away_pairs=away,
                waypoints_match_original_native=False,all_level_paths_accepted=False,whole_level_completed=report['whole_level_completed'],
                limits=['Sparse samples can skip path-node changes, knockback or teleport events between two frames.',
                        'Stationary/away pairs are observations requiring original behavior and full state review, not automatic bugs.',
                        'Different waypoint lists may contain the same first waypoint; this statistic does not assume paths are immutable.',
                        'No unit state was edited; all measurements describe delivered raw observations.'])

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--folder',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    output=Path(a.output);assert not output.exists()
    result=read(a.folder);output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items()if k not in ['instance_ranges','away_pairs','limits']}))
