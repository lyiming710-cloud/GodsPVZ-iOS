"""Physical type-valid wrong-behavior variants; strict checker is not changed."""
from pathlib import Path
import collections,hashlib,json,struct,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'));import dnfile
base=(Q/'authored2.dll').read_bytes();report=json.loads((Q/'authored2.json').read_bytes());cil=json.loads((Q/'shared-authored2/ALL-CIL.json').read_bytes());ms={m['token']:m for m in cil['methods']};good=json.loads((Q/'ACTUAL-CIL.json').read_bytes());normal={q['name']for q in json.loads((Q/'CASES.json').read_bytes())if'native_unwind'not in q};pe=dnfile.dnPE(data=base);out=Q/'physical-controls';out.mkdir(exist_ok=True);controls=[]
def site(token,va):return next(x for x in report['repair_sites']if x['method']==token and x['native_va']==hex(va))
def run(name,token,offset,before,after):
 row=pe.net.mdtables.MethodDef.rows[(int(token,16)&0xffffff)-1];at=pe.get_offset_from_rva(row.Rva)+12+offset;assert len(before)==len(after)and base[at:at+len(before)]==before
 data=bytearray(base);data[at:at+len(after)]=after;path=out/(name+'.dll');path.write_bytes(data);result=out/(name+'.json')
 p=subprocess.run([str(ROOT/'.local/dotnet10/dotnet.exe'),str(Q/'runtime/bin/Release/net10.0/Fixture.dll'),str(path),str(Q/'CASES.json'),str(result)],capture_output=True,timeout=30);(out/(name+'.stdout.log')).write_bytes(p.stdout);(out/(name+'.stderr.log')).write_bytes(p.stderr);assert p.returncode==0,(name,p.stderr[-1500:]);actual=json.loads(result.read_bytes());assert actual['candidate_sha256']==hashlib.sha256(data).hexdigest();diff=[];normaldiff=0;state_diff=0
 for a,b in zip(good['results'],actual['results']):
  assert a['name']==b['name']
  if a!=b:
   diff.append(a['name'])
   if a['name']in normal and a['error']is None and b['error']is None:
    normaldiff+=1
    if a['state']!=b['state']:state_diff+=1
 assert diff and state_diff>0,(name,diff)
 # The behavior controls must also pass the original frozen type checker;
 # a missing call trace alone is insufficient evidence of detection.
 exporter=ROOT/'audit/bulk250-r1-evidence-39702928368/bulk250-r1-run/tools_bin/CilExporter/bin/CilExporter.dll';export=out/(name+'.cil.json');support=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'
 ex=subprocess.run([str(ROOT/'.local/dotnet10/dotnet.exe'),str(exporter),str(path),str(export),str(support),token],capture_output=True);assert ex.returncode==0,ex.stderr
 import importlib.util
 checker=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py';assert hashlib.sha256(checker.read_bytes()).hexdigest()=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14';spec=importlib.util.spec_from_file_location('unchanged_type_control',checker);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);cx=json.loads(export.read_bytes());checked=v.verify(next(m for m in cx['methods']if m['token']==token),cx['types']);assert checked['status']=='PASS',checked
 controls.append(dict(name=name,kind='PHYSICAL_WRONG_SEMANTICS',token=token,offset=offset,before=before.hex(),after=after.hex(),variant_sha256=hashlib.sha256(data).hexdigest(),detected=True,different_cases=len(diff),normal_execution_differences=normaldiff,normal_execution_state_differences=state_diff,frozen_type_status=checked['status']))

def within(token,va):
 v=site(token,va);return[i for i in ms[token]['instructions']if v['new_cil_start']<=i['offset']<v['new_cil_end']]

for name,t,va in [('shooting-original-null-damage-loss','0x060003A8',0x180359bc3),('sniper-original-null-damage-loss','0x060003AB',0x180357836)]:
 ins=within(t,va);i=next(i for i in reversed(ins)if i['opcode'].startswith('ldloc'))
 seq=ms[t]['instructions'];n=seq[seq.index(i)+1]['offset']-i['offset'];raw=bytes.fromhex(next(r for r in report['changes']if r['token']==t)['new_code']);before=raw[i['offset']:i['offset']+n]
 run(name,t,i['offset'],before,b'\x14'+b'\x00'*(n-1))
for name,t,va,op in [('short-damage-overload-drops-argument','0x060004E1',0x1803865b0,b'\x04'),('short-projectile-overload-drops-argument','0x060004E2',0x18038657d,b'\x05')]:
 v=site(t,va);run(name,t,v['new_cil_start'],op,b'\x14')
t='0x060003A8';raw=bytes.fromhex(next(r for r in report['changes']if r['token']==t)['new_code'])
i=next(i for i in within(t,0x180359985)if i['opcode']=='ldc.r4'and 558<i['operand']<559);at=i['offset']+1;run('wrong-projectile-velocity-sign',t,at,raw[at:at+4],struct.pack('<f',-558.2999877929688))
i=next(i for i in within(t,0x1803599d5)if i['opcode']=='ldfld');run('discard-actual-projectile-camp',t,i['offset'],raw[i['offset']:i['offset']+5],bytes.fromhex('2616000000'))
result=dict(scope='PHYSICAL_CANDIDATE_VARIANTS_WITH_ACTUAL_RAW_CIL_EXECUTION',candidate_sha256=hashlib.sha256(base).hexdigest(),controls=len(controls),all_detected=all(x['detected']for x in controls),results=controls,whole_game_or_unity_behavior_proven=False)
(Q/'PHYSICAL-CONTROLS.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,indent=2))

