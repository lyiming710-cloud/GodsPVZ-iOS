"""Four unchanged original PC callers, including nested short forwarders.

Engine/game leaves are explicit finite controlled contracts. All four repaired
caller bodies execute as original native bytes and as actual candidate raw CIL.
"""
from pathlib import Path
import collections,ctypes as C,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
spec=json.loads((Q/'ORIGINAL-OPERAND-RESOLUTION.json').read_bytes());cases=json.loads((Q/'CASES.json').read_bytes());actual=json.loads(Path(sys.argv[1]).read_bytes());by={r['name']:r for r in actual['results']};state={};rows=[]
def log(*args):state['trace'].append(':'.join('1'if v is True else'0'if v is False else'null'if v is None else str(v)for v in args))
def tag(p):return 'null'if not p else state['objects'][p]['tag']
def obj(label,kind='UObj',alive=True):p=im.alloc(1024);state['objects'][p]=dict(tag=label,kind=kind,alive=alive);return p
def f32(v):return struct.unpack('<f',struct.pack('<f',v))[0]
def vec(v):return ','.join(bits(x)for x in v)
def vector(p):return struct.unpack('<3f',C.string_at(p,12))
def string(v):p=im.alloc(32);state['strings'][p]=v;return p
def audioarray(p):a=im.alloc(64);put32(a+0x18,2);put64(a+0x20,p);put64(a+0x28,p);return a
def ne(a,b,m):v=not((not a or not state['objects'][a]['alive'])and(not b or not state['objects'][b]['alive'])or a==b);log('ne',tag(a),tag(b),v);return v
def volume(m):
 log('getVolume')
 if state['mode']=='audio-swap':put64(state['plant']+0x1d8,audioarray(state['audioOther']))
 return .75
def setvolume(p,v,m):log('volume',tag(p),bits(v));state['objects'][p]['volume']=v
def play(p,m):log('play',tag(p));state['objects'][p]['plays']+=1
def getdamage(p,projectile,typ,flags,m):
 log('getDamage',tag(projectile),typ,flags);d=obj('damage'+str(len(state['damages'])+1),'Damage');state['objects'][d]['point']=10.;state['damages'].append(d)
 if state['mode']=='damage-swap':put64(p+0x120,state['z2']);put64(p+0xe0,state['other'])
 return d
def function4(sk,p,z,projectile,damage,m):
 log('function4',tag(sk),tag(p),tag(z),tag(projectile),tag(damage))
 if damage:state['objects'][damage]['point']=f32(state['objects'][damage]['point']*2)
 if state['mode']=='function-swap':put64(p+0x120,state['z2']);put64(p+0xe0,state['other'])
def function1(sk,p,m):
 log('function1',tag(sk),tag(p))
 if state['mode']=='ongoing-switch':put32(sk+0x18,3)
def end(sk,p,z,projectile,damage,m):log('end',tag(sk),tag(p),tag(z),tag(projectile),tag(damage),bool(C.c_ubyte.from_address(p+0xf4).value))
def takedamage(p,d,projectile,m):k='zombieDamage'if state['objects'][p]['kind']=='Zombie'else'deviceDamage';point=state['objects'][d]['point'];log(k,tag(p),tag(d),tag(projectile),bits(point));state['objects'][p]['health']=f32(state['objects'][p]['health']-point)
def trigger(p,m):
 log('trigger')
 if state['mode']=='trigger-swap':put64(p+0xe0,state['other'])
def charge(p,v,m):log('charge',bits(v))
def createprojectile(manager,ID,m):
 log('createProjectile',ID);p=obj('projectile','Projectile');state['objects'][p].update(position=(0.,0.,0.),velocity=(0.,0.,0.),acceleration=(0.,0.,0.),life=0.,type=0,source=0,damage=0,camp=0);state['projectiles'].append(p);return p
def spritepos(out,items,name,m):log('spritePos',state['strings'][name]);C.memmove(out,struct.pack('<3f',12,23,34),12);return out
def initial(p,pos,velocity,acceleration,life,typ,source,m):
 a,b,c=vector(pos),vector(velocity),vector(acceleration);log('initial',tag(p),vec(a),vec(b),vec(c),bits(life),typ,tag(source));state['objects'][p].update(position=a,velocity=b,acceleration=c,life=life,type=typ,source=source)
 if state['mode']=='initial-camp':put32(state['plant']+0xbc,2)
def setdamage(p,d,camp,m):log('setDamage',tag(p),tag(d),camp);state['objects'][p].update(damage=d,camp=camp)
def special(name,nextID=None):
 def f(p,m):
  log(name)
  if state['mode']=='id-chain'and nextID is not None:put32(p+0x7c,nextID)
 return f

def setup(q):
 state.clear();state.update(mode=q['mode'],objects={},strings={},trace=[],damages=[],projectiles=[])
 for at,text in literals.items():put64(at,string(text))
 p=obj('plant','Plant');state['plant']=p;put32(p+0x7c,q['ID']);put32(p+0xbc,1);C.c_ubyte.from_address(p+0xf4).value=q['super'];C.c_ubyte.from_address(p+0xe8).value=q['ongoing']
 sk=obj('skill','Skill');other=obj('other-skill','Skill');state.update(skill=sk,other=other);put64(p+0xe0,sk)
 for ptr in [sk,other]:put32(ptr+0x18,q['skillID'])
 put32(sk+0x48,q['charged']);put32(sk+0x2c,q['skillType']);put32(sk+0x28,q['chargeType']);put32(sk+0x30,q['triggerType']);put32(other+0x28,1)
 z1=obj('zombie','Zombie',q['target']!='destroyed');z2=obj('zombie-two','Zombie');device=obj('device','Device');state.update(z1=z1,z2=z2,device=device)
 for a in[z1,z2,device]:state['objects'][a]['health']=1000.
 if q['target']in['zombie','both','destroyed']:put64(p+0x120,z1)
 if q['target']in['device','both','destroyed']:put64(p+0x128,device)
 a=obj('audio-original','AudioSource');b=obj('audio-other','AudioSource');state.update(audioOriginal=a,audioOther=b)
 for ptr in[a,b]:state['objects'][ptr].update(volume=0.,plays=0)
 put64(p+0x1d8,audioarray(a));board=im.alloc(512);put64(p+0x1e8,board);put64(board+0xf8,im.alloc(64));put64(p+0x148,im.alloc(64))
 supplied=obj('provided','Damage');state['objects'][supplied]['point']=33.;state['provided']=supplied;state['providedProjectile']=obj('provided-projectile','Projectile')
 if q['token']in['0x060004E1','0x060004E2']:state['damages'].append(supplied)

def snapshot():
 p=state['plant'];sk=get64(p+0xe0)
 return dict(ID=get32(p+0x7c),super=bool(C.c_ubyte.from_address(p+0xf4).value),skill=tag(sk),skillID=get32(sk+0x18),zombie=tag(get64(p+0x120)),camp=get32(p+0xbc),zombieHealth=bits(state['objects'][state['z1']]['health']),otherZombieHealth=bits(state['objects'][state['z2']]['health']),deviceHealth=bits(state['objects'][state['device']]['health']),
 audio=[dict(tag=tag(a),volume=bits(state['objects'][a]['volume']),plays=state['objects'][a]['plays'])for a in[state['audioOriginal'],state['audioOther']]],damage=[dict(tag=tag(d),point=bits(state['objects'][d]['point']))for d in state['damages']],
 projectiles=[dict(tag=tag(a),position=vec(state['objects'][a]['position']),velocity=vec(state['objects'][a]['velocity']),acceleration=vec(state['objects'][a]['acceleration']),life=bits(state['objects'][a]['life']),type=state['objects'][a]['type'],source=tag(state['objects'][a]['source']),damage=tag(state['objects'][a]['damage']),camp=state['objects'][a]['camp'])for a in state['projectiles']])

im=NativeImage();classes={};literals={}
for d in spec:
 for r in d['rows']:
  v=r['resolved']
  if isinstance(v,dict)and'class'in v:
   if v['class']not in classes:
    ptr=im.alloc(512);sf=im.alloc(512);put64(ptr+0xb8,sf);put32(ptr+0xe0,1);classes[v['class']]=ptr
   put64(int(v['slot_va'],16),classes[v['class']])
  if isinstance(v,dict)and'string'in v:literals[int(v['slot_va'],16)]=v['string']
im.hook(0x18024fef0,None,[P],lambda p:None);im.hook(0x1802501e0,None,[P],lambda p:None)
im.hook(0x18131f900,C.c_bool,[P,P,P],ne);im.hook(0x18031aea0,F,[P],volume);im.hook(0x1812dc4b0,None,[P,F,P],setvolume);im.hook(0x1812dc300,None,[P,P],play)
im.hook(0x180350e40,P,[P,P,I,I,P],getdamage);im.hook(0x180386210,None,[P,P,P,P,P,P],function4);im.hook(0x180386550,None,[P,P,P],function1);im.hook(0x180386040,None,[P,P,P,P,P,P],end)
im.hook(0x180369aa0,None,[P,P,P,P],takedamage);im.hook(0x18034b8e0,None,[P,P,P,P],takedamage);im.hook(0x18035b150,None,[P,P],trigger);im.hook(0x180359e00,None,[P,F,P],charge)
im.hook(0x180324150,P,[P,I,P],createprojectile);im.hook(0x18031b680,P,[P,P,P,P],spritepos);im.hook(0x1804a25f0,None,[P,P,P,P,F,I,P,P],initial);im.hook(0x18037c0f0,None,[P,P,I,P],setdamage)
im.hook(0x180357880,None,[P,P],special('potato',5));im.hook(0x180356d90,None,[P,P],special('chomper',7));im.hook(0x180357c50,None,[P,P],special('repear'))
configs={}
for rid in [0x3a8,0x3ab,0x4e1,0x4e2]:
 cfg=json.loads((Q/'native-source-complete'/f'0x{0x6000000|rid:08X}.json').read_bytes());im.verify_caller(rid,int(cfg['entry'],16),cfg);configs[rid]=cfg
for q in cases:
 rid=int(q['token'],16)&0xffffff;setup(q);entry=int(configs[rid]['entry'],16)
 if rid==0x4e1:C.CFUNCTYPE(None,P,P,P,P)(entry)(state['skill'],state['plant'],state['provided'],None)
 elif rid==0x4e2:C.CFUNCTYPE(None,P,P,P,P,P)(entry)(state['skill'],state['plant'],state['providedProjectile'],state['provided'],None)
 else:C.CFUNCTYPE(None,P,P)(entry)(state['plant'],None)
 assert not im.errors,im.errors
 expected=by[q['name']];got=dict(state=snapshot(),trace=state['trace']);diff={k:dict(native=got[k],cil=expected[k])for k in['state','trace']if got[k]!=expected[k]}
 if expected['error']:diff['cil_error']=expected['error']
 rows.append(dict(name=q['name'],token=q['token'],status='ZERO_DIFFERENCE'if not diff else'DIFFERENCE',native=got,cil=expected,differences=diff))
im.close()
result=dict(scope='FOUR_BYTE_RECHECKED_PC_DAMAGE_CALLERS_AND_NESTED_SHORT_FORWARDERS_VS_EXACT_RAW_CIL_FINITE_CONTRACTS',candidate_sha256=actual['candidate_sha256'],original_pc_sha256=PC_SHA,counts=dict(collections.Counter(r['status']for r in rows)),rows=rows,unity_or_full_game_behavior_proven=False,ipa=None)
(Q/'NATIVE-COMPARE.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in result.items()if k!='rows'},indent=2));print(json.dumps([r for r in rows if r['status']=='DIFFERENCE'][:1],indent=2));assert not any(r['status']=='DIFFERENCE'for r in rows)
