from pathlib import Path
import itertools,json
q=Path(__file__).resolve().parent;rows=[]
def add(token,ID,skillID,super_,target,mode='normal',charged=0,skillType=0,chargeType=0,triggerType=0,ongoing=False):
 rows.append(dict(name='case-'+str(len(rows)),token=token,ID=ID,skillID=skillID,super=super_,target=target,mode=mode,charged=charged,skillType=skillType,chargeType=chargeType,triggerType=triggerType,ongoing=ongoing))
for ID,sk,sup,target in itertools.product([0,3,4,5,6,7,49,99],[1,2,3],[False,True],['zombie','device','both','destroyed','none']):add('0x060003A8',ID,sk,sup,target)
for sk,sup,target in itertools.product([1,2,3],[False,True],['zombie','device','both','destroyed','none']):add('0x060003AB',0,sk,sup,target)
for token in ['0x060004E1','0x060004E2']:
 for sk,mode in itertools.product([1,2,3],['normal','function-swap']):add(token,0,sk,True,'zombie',mode)
for ID,mode in itertools.product([0,3,4,5,49],['damage-swap','function-swap','trigger-swap','initial-camp','id-chain','ongoing-switch','audio-swap']):add('0x060003A8',ID,1 if ID!=3 else 2,True,'both',mode,charged=1,skillType=2,chargeType=1,ongoing=True)
for ID,sk in itertools.product([49],[1,2,3]):add('0x060003A8',ID,sk,False,'none','ongoing-switch',ongoing=True)
(q/'CASES.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(cases=len(rows))))
