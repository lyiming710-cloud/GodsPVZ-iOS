"""Find differences; never relabel NaN-domain mismatches as a successful profile."""
from pathlib import Path
import collections,ctypes as C,hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86_const import X86_OP_MEM,X86_REG_RIP
im=NativeImage();state={};cfgs={r:json.loads((W/'startup-r19-batch100/native-source-complete'/f'0x{0x6000000|r:08X}.json').read_bytes()) for r in [0x5e8,0xc3]}
fields=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_bytes())
def off(owner,name):
    rows=[r for r in fields if r['type']==owner and r['namespace']=='' and r['name']==name];assert len(rows)==1;return rows[0]['offset']
def text(p):return None if not p else C.string_at(p+0x14,get32(p+0x10)*2).decode('utf-16-le')
def string(s):
    if s is None:return 0
    b=s.encode('utf-16-le');p=im.alloc(24+len(b));put32(p+0x10,len(b)//2);C.memmove(p+0x14,b,len(b));return p
def f(key):return struct.unpack('<f',bytes.fromhex(state['q'][key])[::-1])[0]
def tag(p):return 'null' if not p else state['tags'][p]
def exists(p,method):assert not method;value=bool(p and state['live'][p]);state['trace'].append('Exists:'+tag(p)+':'+str(int(value)));return value
def equal(p,b,method):assert not b;return not exists(p,method)
def stats(p,key,level,direction,method):assert p==state['self'] and not method;state['trace'].append(f'Stats:{key}:{level}:{direction}')
def delta(method):assert not method;state['trace'].append('Delta:'+state['q']['delta']);return f('delta')
def string_equal(a,b,method):assert not method;return text(a)==text(b)
def close(p,method):assert p==state['self'] and not method;state['closed']+=1;state['trace'].append('Close')
try:
    meta=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/global-metadata.dat').read_bytes();assert hashlib.sha256(meta).hexdigest()=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9'
    so,sn,do,dn=struct.unpack_from('<4I',meta,8);dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True;slots=set();literals=[]
    for cfg in cfgs.values():
        for row in cfg['instructions']:
            i=next(dis.disasm(bytes.fromhex(row['bytes']),int(row['va'],16)))
            if i.mnemonic not in ['mov','lea']:continue
            for o in i.operands:
                if o.type!=X86_OP_MEM or o.mem.base!=X86_REG_RIP:continue
                at=i.address+i.size+o.mem.disp;raw=im.pe.get_data(at-im.base,8)
                if len(raw)!=8:continue
                code=int.from_bytes(raw,'little')
                if code>0xffffffff or code>>29 not in range(1,8) or at in slots:continue
                slots.add(at);kind,index=code>>29,(code&0x1fffffff)>>1
                if kind==5:
                    n,pos=struct.unpack_from('<II',meta,so+8*index);literal=meta[do+pos:do+pos+n].decode('utf-8');put64(at,string(literal));literals.append(literal)
                else:im.class_slot(at)
    assert literals==['PlantSkill']
    def init(p):assert p in slots
    im.hook(0x18024fef0,None,[P],init);im.hook(0x1802501e0,None,[P],lambda p:None)
    im.hook(0x18039a7d0,None,[P,I,I,I,P],stats);im.hook(0x18131f760,C.c_bool,[P,P,P],equal);im.hook(0x18132c2f0,F,[P],delta);im.hook(0x180b76170,C.c_bool,[P,P,P],string_equal);im.hook(0x18030d8a0,None,[P,P],close)
    for rid,cfg in cfgs.items():im.verify_caller(rid,int(cfg['entry'],16),cfg)
    state.update(q={'delta':'7FC07654'},trace=[]);probe=C.CFUNCTYPE(F,P)(0x18132c2f0)(None);assert struct.pack('<f',probe)[::-1].hex().upper()=='7FC07654'
    cases=json.loads((Q/'CASES.json').read_bytes());rows=[]
    for q in cases:
        if '--trace-cases' in sys.argv:print(json.dumps(dict(starting_case=q['name'])),flush=True)
        state.clear();state.update(q=q,tags={},live={},trace=[],closed=0);p=im.alloc(256);state['self']=p;rid=int(q['token'],16)&0xffffff
        if rid==0x5e8:C.CFUNCTYPE(None,P,I,F,P)(int(cfgs[rid]['entry'],16))(p,q['key'],f('value'),None);snapshot={}
        else:
            for name,owner in [('plant','Plant'),('zombie','Zombie'),('projectile','Projectile')]:
                a=im.alloc(256);state['tags'][a]=name;state['live'][a]=q[name]==1;put64(p+off('VFXAnimationEvent',name),a if q[name] else 0)
                if name=='plant':C.c_ubyte.from_address(a+off('Plant','skillOngoing')).value=q['ongoing']
            C.c_ubyte.from_address(p+off('VFXAnimationEvent','original')).value=q['original'];C.c_uint32.from_address(p+off('VFXAnimationEvent','duration')).value=int(q['duration'],16);put64(p+off('VFXAnimationEvent','type'),string(None if q['type']==0 else 'PlantSkill' if q['type']==1 else 'Other'))
            C.CFUNCTYPE(None,P,P)(int(cfgs[rid]['entry'],16))(p,None);snapshot=dict(duration_bits=f'{C.c_uint32.from_address(p+off("VFXAnimationEvent","duration")).value:08X}',closed=state['closed'])
        assert not im.errors,(q,im.errors);rows.append(dict(name=q['name'],token=q['token'],error=None,trace=list(state['trace']),state=snapshot))
    actual=json.loads(Path(sys.argv[1]).read_bytes());digest=hashlib.sha256((W/'startup-r20-sites100/authored3.dll').read_bytes()).hexdigest();assert actual['candidate_sha256']==digest
    found={r['name']:r for r in actual['results']};assert set(found)=={q['name'] for q in cases};domains={q['name']:q['domain'] for q in cases};diff=[dict(domain=domains[r['name']],original=r,actual=found[r['name']]) for r in rows if r!=found[r['name']]]
    report=dict(scope='TWO_COMPLETE_ORIGINAL_FLOAT_CALLERS_DIFFERENCE_DISCOVERY',candidate_sha256=digest,original_pc_sha256=hashlib.sha256(im.raw).hexdigest(),caller_bytes_verified=2,records=len(rows),results=rows,differences=diff,
        difference_counts_by_method=dict(collections.Counter(r['original']['token'] for r in diff)),difference_counts_by_domain=dict(collections.Counter(r['domain'] for r in diff)),callback_errors=im.errors,float_return_nan_payload_abi_probe_pass=True,
        native_comparisons_and_conditional_jumps_unchanged=True,new_game_dll_changes=0,do_not_promote_methods_if_differences_exist=True,
        limitations=['Delta NaN/Infinity cases are expanded contract inputs with no established real Unity trigger','Buff float arguments have no narrowed domain proof','Controlled leaves; no actual engine or device acceptance'],formal_or_product_acceptance=False)
    Path(sys.argv[2]).write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in report.items() if k not in ['results','differences']}));print('differences',len(diff));raise SystemExit(2 if diff else 0)
finally:im.close()
