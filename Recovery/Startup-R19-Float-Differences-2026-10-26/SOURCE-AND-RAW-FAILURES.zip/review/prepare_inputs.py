from pathlib import Path
import collections,itertools,json
Q=Path(__file__).resolve().parent;cases=[]
stats=['FF800000','BF800000','80000001','80000000','00000000','00000001','3EFFFFFF','3F000000','3F000001','3F4CCCCC','3F4CCCCD','3F4CCCCE','3F7FFFFF','3F800000','3F800001','3FC00000','40000000','40400000','7F800000','7FC01234','FFC01234']
for key,value in itertools.product([-2147483648,-1,0,1,99,2147483647],stats):cases.append(dict(name=f'f{len(cases):05d}',token='0x060005E8',key=key,value=value,domain='FLOAT_ARGUMENT',native_supported=True))
refs=[(0,0,0),(1,0,0),(0,1,0),(0,0,1),(2,0,0),(0,2,0),(0,0,2),(1,1,1)]
durations=['FF800000','80000000','00000000','3DCCCCCD','3F800000','7F800000','7FC01234','FFC01234']
for duration,delta,original,ongoing,kind,ref in itertools.product(durations,['00000000','3E000000','3F800000'],[0,1],[0,1],[0,1,2],refs):
    cases.append(dict(name=f'f{len(cases):05d}',token='0x060000C3',duration=duration,delta=delta,original=original,ongoing=ongoing,type=kind,plant=ref[0],zombie=ref[1],projectile=ref[2],domain='FINITE_NONNEGATIVE_DELTA',native_supported=True))
for duration,delta,original,ongoing,kind,ref in itertools.product(['3DCCCCCD','7F800000'],['7F800000','7FC07654'],[0,1],[0,1],[0,1,2],refs):
    cases.append(dict(name=f'f{len(cases):05d}',token='0x060000C3',duration=duration,delta=delta,original=original,ongoing=ongoing,type=kind,plant=ref[0],zombie=ref[1],projectile=ref[2],domain='EXPANDED_DELTA_NO_GAME_TRIGGER_CLAIM',native_supported=True))
(Q/'CASES.json').write_bytes((json.dumps(cases,indent=2)+'\n').encode());print(json.dumps(dict(records=len(cases),domains=dict(collections.Counter(q['domain'] for q in cases)))))
