using System.Reflection;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public class Obj{public string Tag="";public bool Live=true;}
public class Plant:Obj{public bool skillOngoing;}
public class Zombie:Obj{}
public class Projectile:Obj{}
public class BuffUI{public void SetStatsImageSet(int key,int level,int direction)=>Program.Trace.Add("Stats:"+key+":"+level+":"+direction);}
public class Effect{public Plant? plant;public Zombie? zombie;public Projectile? projectile;public bool original;public float duration;public string? type;public int Closed;public void Close(){Closed++;Program.Trace.Add("Close");}}
public static class Time{public static float deltaTime{get{Program.Trace.Add("Delta:"+Program.Case.GetProperty("delta").GetString());return Program.F("delta");}}}
public static class Program
{
 public static JsonElement Case;public static List<string> Trace=[];public static int N(string key,int d=0)=>Case.TryGetProperty(key,out var v)?v.GetInt32():d;public static float F(string key)=>BitConverter.Int32BitsToSingle(unchecked((int)Convert.ToUInt32(Case.GetProperty(key).GetString(),16)));public static string Bits(float f)=>((uint)BitConverter.SingleToInt32Bits(f)).ToString("X8");
 public static bool Exists(Obj? p){bool a=p!=null&&p.Live;Trace.Add("Exists:"+(p?.Tag??"null")+":"+(a?1:0));return a;}public static bool Equal(Obj? a,Obj? b){if(b!=null)throw new Exception();return !Exists(a);}public static bool Unequal(Obj? a,Obj? b){if(b!=null)throw new Exception();return Exists(a);}
 static Type Map(MC.TypeReference t)=>t.FullName switch{"System.Void"=>typeof(void),"System.Boolean"=>typeof(bool),"System.Int32"=>typeof(int),"System.Single"=>typeof(float),"System.String"=>typeof(string),"UnityEngine.Object"=>typeof(Obj),"UnityEngine.Time"=>typeof(Time),"Plant"=>typeof(Plant),"Zombie"=>typeof(Zombie),"Projectile"=>typeof(Projectile),"BuffUIController_Zombie"=>typeof(BuffUI),"VFXAnimationEvent"=>typeof(Effect),_=>throw new NotSupportedException(t.FullName)};
 static FieldInfo Field(MC.FieldReference f)=>Map(f.DeclaringType).GetField(f.Name)!;
 static MethodBase Method(MC.MethodReference m)=>m.DeclaringType.FullName=="UnityEngine.Object"?typeof(Program).GetMethod(m.Name=="op_Equality"?"Equal":"Unequal")!:Map(m.DeclaringType).GetMethod(m.Name,BindingFlags.Public|BindingFlags.Static|BindingFlags.Instance,null,m.Parameters.Select(p=>Map(p.ParameterType)).ToArray(),null)!;
 public static void Main(string[] args)
 {
  var resolver=new MC.DefaultAssemblyResolver();resolver.AddSearchDirectory(args[1]);using var asm=MC.AssemblyDefinition.ReadAssembly(args[0],new MC.ReaderParameters{AssemblyResolver=resolver});var stats=ActualCil.Emit((MC.MethodDefinition)asm.MainModule.LookupToken(0x60005e8),Map,Field,Method);var update=ActualCil.Emit((MC.MethodDefinition)asm.MainModule.LookupToken(0x60000c3),Map,Field,Method);using var cases=JsonDocument.Parse(File.ReadAllText(args[2]));var rows=new List<object>();
  foreach(var q in cases.RootElement.EnumerateArray())
  {
   Case=q;Trace.Clear();int rid=Convert.ToInt32(q.GetProperty("token").GetString(),16)&0xffffff;var fx=new Effect{original=N("original")==1,duration=rid==0xc3?F("duration"):0,type=N("type")==0?null:N("type")==1?"PlantSkill":"Other",plant=N("plant")==0?null:new(){Tag="plant",Live=N("plant")==1,skillOngoing=N("ongoing")==1},zombie=N("zombie")==0?null:new(){Tag="zombie",Live=N("zombie")==1},projectile=N("projectile")==0?null:new(){Tag="projectile",Live=N("projectile")==1}};string? error=null;
   try{if(rid==0x5e8)stats.Invoke(null,[new BuffUI(),N("key"),F("value")]);else update.Invoke(null,[fx]);}catch(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;error=e.GetType().FullName;}
   rows.Add(new{name=q.GetProperty("name").GetString(),token=q.GetProperty("token").GetString(),error,trace=Trace.ToArray(),state=rid==0xc3?(object)new{duration_bits=Bits(fx.duration),closed=fx.Closed}:new{}});
  }
  File.WriteAllText(args[3],JsonSerializer.Serialize(new{scope="COMPLETE_EXISTING_CIL_FLOAT_COMPARISON_REVIEW_NO_REPAIR_CANDIDATE",candidate_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),methods=2,results=rows,eh_removed=false,private_access_bypass=false,unity_or_product_acceptance=false},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{records=rows.Count,methods=2}));
 }
}
