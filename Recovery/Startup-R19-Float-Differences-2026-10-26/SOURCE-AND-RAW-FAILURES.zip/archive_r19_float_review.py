"""Archive discovered differences without repairing candidates or granting acceptance."""
from pathlib import Path
import collections,json,struct,sys
sys.dont_write_bytecode=True
from archive_support import sha,js,pack,manifest
W=Path(__file__).resolve().parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113'
Q=W/'r19-floating-comparison-review-2026-10-26';D=R/'Recovery/Startup-R19-Float-Differences-2026-10-26'
H=R/'Recovery/Startup-R19-Batch100-2026-10-25';T=R/'Recovery/Startup-R20-Sites104-2026-10-26'
assert not D.exists();D.mkdir();(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text\n*.md -text\n*.zip -text\n')
a=json.loads((Q/'FULL-CIL-R19.json').read_bytes());b=json.loads((Q/'FULL-CIL-R20.json').read_bytes());n=json.loads((Q/'NATIVE-ATTEMPT1.json').read_bytes());cases=json.loads((Q/'CASES.json').read_bytes())
assert a['results']==b['results'] and len(a['results'])==2814 and not any(r['error'] for r in b['results'])
assert n['records']==2814 and len(n['differences'])==228 and n['difference_counts_by_method']=={'0x060005E8':12,'0x060000C3':216}
assert n['difference_counts_by_domain']=={'FLOAT_ARGUMENT':12,'EXPANDED_DELTA_NO_GAME_TRIGGER_CLAIM':216} and not n['callback_errors']
assert n['float_return_nan_payload_abi_probe_pass'] and n['caller_bytes_verified']==2
assert json.loads((Q/'native-attempt1.process.json').read_bytes())['actual_exit']==2
parent=(W/'startup-r19-batch100/candidate9.dll').read_bytes();current=(W/'startup-r20-sites100/authored3.dll').read_bytes()
assert sha(parent)==a['candidate_sha256'] and sha(current)==b['candidate_sha256']==n['candidate_sha256']
assert sha((W/'startup-r5/runtime-common/Rehost.cs').read_bytes())=='59b1e80892d0038ee188f0ef36d1af25ce37ae6df71016ba6617cc221ca51d40'
cil=json.loads((W/'startup-r20-sites100/shared-authored3/ALL-CIL.json').read_bytes());methods={m['token']:m for m in cil['methods']}
tokens=['0x060005E8','0x060000C3'];fixes=[]
for token,items in [('0x060005E8',[(72,'0x18039aa91'),(104,'0x18039aaa2'),(136,'0x18039aab3')]),('0x060000C3',[(211,'0x18030de74')])]:
    cfg=json.loads((W/'startup-r19-batch100/native-source-complete'/(token+'.json')).read_bytes());native={i['va']:i for i in cfg['instructions']};ins=methods[token]['instructions'];indices={i['offset']:j for j,i in enumerate(ins)}
    for offset,branch in items:
        j=indices[offset];assert [i['opcode'] for i in ins[j:j+3]]==['clt','ldc.i4.0','ceq'] and native[branch]['op']=='jae'
        fixes.append(dict(token=token,cil_offset=offset,old='clt',proposed='clt.un',old_opcode_hex='fe04',proposed_opcode_hex='fe05',native_ordered_branch=native[branch],evidence='COMISS+JAE is false for unordered operands; inverted CLT is true; inverted CLT.UN is false',source_proposal_only=True,game_candidate_modified=False))
binding=dict(parent_sha256=sha(parent),current_sha256=sha(current),both_candidates_executed=True,all_2814_clr_rows_identical=True,new_game_dll_changes=0)
js(Q/'R19-AND-R20-BINDING.json',binding);js(D/'PROPOSED-FOUR-SITES.json',fixes)
example=[];bycase={q['name']:q for q in cases}
for token in tokens:
    diff=next(x for x in n['differences'] if x['original']['token']==token);example.append(dict(input=bycase[diff['original']['name']],comparison=diff))
js(D/'COUNTEREXAMPLES.json',example)
js(D/'PROGRESS.json',dict(status='TWO_EXISTING_METHODS_NATIVE_CIL_DIFFERENCES_CONFIRMED_NO_FIX_YET',candidate_sha256=sha(current),parent_candidate_sha256=sha(parent),methods=2,records=2814,matching_records=2586,differing_records=228,callback_errors=0,process_crashes=0,process_exit=2,normal_nonnegative_delta_records=2304,normal_nonnegative_delta_differences=0,buff_float_argument_records=126,buff_nan_differences=12,expanded_delta_records=384,expanded_delta_differences=216,proposed_source_positions=4,new_game_dll_changes=0,r19_finite_union_remains=75,r19_profiles_pending_remain=25,no_established_real_unity_nan_delta_trigger=True,black_screen_cause_proven=False,full_method_accepted=False,ipad_acceptance=False))
files=[]
for p in sorted(Q.rglob('*')):
    if p.is_file() and not any(s in p.parts for s in ['obj','__pycache__']):files.append(('review/'+p.relative_to(Q).as_posix(),p.read_bytes()))
for token in tokens:
    for suffix in ['.txt','.json']:
        p=W/'startup-r19-batch100/native-source-complete'/(token+suffix);files.append(('original-native/'+p.name,p.read_bytes()))
    files.append(('current-cil/'+token+'.json',(json.dumps(methods[token],indent=2)+'\n').encode()))
files += [('frozen-runtime/Rehost.cs',(W/'startup-r5/runtime-common/Rehost.cs').read_bytes()),('frozen-runtime/native_runtime_common.py',(W/'startup-r5/native_runtime_common.py').read_bytes()),(Path(__file__).name,Path(__file__).read_bytes())]
pack(D/'SOURCE-AND-RAW-FAILURES.zip',files)
(D/'README.md').write_bytes('''# R19 两个已有方法的浮点差异：保留失败，尚未修补

对固定 R19 candidate9 与 R20 authored3 实际发射并执行完整 CIL，2,814 条 CLR 记录完全相同。运行两个未改比较和条件跳转的完整原版 PC 调用方，共发现 228 条差异（2586 条一致），原生受控回调错误 0，子进程正常写出失败报告后退出 2。冻结 Rehost 不变，未修改游戏 DLL。这里是已有百方法批次的补充验证；后续新修复仍待累计超过 100 个有证据的位置后集中检测。

- 0x060005E8 BuffUIController_Zombie.SetStatsImageSet(int,float)：126 个实参记录中 12 个 NaN 记录不同。原版调用 SetStatsImageSet(key,3,+1)，当前 CIL 调用 (key,3,-1)。该 float 参数的真实取值域没有得到缩窄证明，不能判该完整方法通过。
- 0x060000C3 VFXAnimationEvent.Update：2304 个非负有限 delta 的组合均一致，另 384 个扩展 delta（NaN/Infinity）输入中 216 个不同。例如 delta=NaN、duration=.1 时，当前 CIL 会提前 Close，原版不会。未证实真实 Unity deltaTime 会返回这些输入，不能将其作为当前 iPad 黑屏的已证原因。

原版四处 COMISS+JAE 对 unordered 为 false；当前三条指令 clt; ldc.i4.0; ceq 对 unordered 为 true。逐站点依据与拟改 clt.un 的四个位置在 PROPOSED-FOUR-SITES.json 中，尚未写入候选。不得全局替换 clt/cgt 或无依据改整数比较。VFX 原版先捕获 duration 再取 delta、当前 CIL 先 getter 再重读字段这一顺序差异另保留观察，不凭人为有副作用的 Time getter 宣称实际引擎缺陷。

测试覆盖 ±NaN、±0、相邻阈值、Infinity，保持原生 XMM 浮点返回协议并单独核对 NaN payload 7FC07654。Unity 对象伪空、时间/图标/Close 等是明确受控叶函数，其内部未被证明；不是实际场景、真机或全游戏验收。未删指令、EH、分支或私有访问规则来取得通过。全部输入、完整 CLR 与原生行、源字节、stderr/stdout 和退出码均归档。

R19 已有有限对照联合数仍为75、正常原版记录21,456，另25个方法仍待验收，其中这两个已有差异。不会把本次2586条相等记录追加到已通过方法总数。R20 本轮8个新方法的原有768条对照范围不变；当前 iOS 构建仍只用于启动诊断和设备反馈，不能标整个游戏完成。
'''.encode())
pending=json.loads((H/'CURRENT-PENDING-RUNTIME-PROFILES.json').read_bytes());assert pending['methods']==25
for r in pending['rows']:
    if r['token'] in tokens:r.update(runtime_profile_status='DIFFERENCES_FOUND_NOT_ACCEPTED',difference_review='../'+D.name,native_difference_records=n['difference_counts_by_method'][r['token']],source_fix_pending=True)
js(H/'CURRENT-PENDING-RUNTIME-PROFILES.json',pending)
s=json.loads((H/'PROGRESS.json').read_bytes());s.update(floating_additional_review_methods=2,floating_confirmed_difference_records=228,floating_proposed_source_sites_not_yet_applied=4);js(H/'PROGRESS.json',s)
q=json.loads((T/'CURRENT-WORK-QUEUE.json').read_bytes())
for r in q['rows']:
    if r['token'] in tokens:r.update(current_state='R19_BODY_HAS_FLOAT_NATIVE_CIL_DIFFERENCES_NOT_ACCEPTED',r19_runtime_pending=True,current_required_action='Four native-backed source positions proposed; keep pending and accumulate next new-source batch before shared testing',review='../'+D.name)
js(T/'CURRENT-WORK-QUEUE.json',q)
s=json.loads((T/'PROGRESS.json').read_bytes());s.update(inherited_r19_float_methods_with_differences=2,inherited_r19_float_difference_records=228,whole_game_accepted=False);js(T/'PROGRESS.json',s)
p=R/'Recovery/STATUS.md';v=p.read_text('utf-8');marker='## Latest checkpoint - 2026-10-26\n';assert marker in v;v=v.replace(marker,marker+'\n[Float difference review](Startup-R19-Float-Differences-2026-10-26/README.md) retains 228 native/CIL mismatches in two inherited methods. Both exact R19/R20 candidates reproduce them; no repair DLL was created. These methods stay among the 25 pending; the existing75 finite profiles are unchanged. NaN deltaTime has no established real Unity trigger.\n',1);p.write_bytes(v.encode())
for folder in [D,H,T]:manifest(folder)
print(json.dumps(dict(archived=D.name,failures=228,new_candidate_changes=0,r19_pending=25)))
