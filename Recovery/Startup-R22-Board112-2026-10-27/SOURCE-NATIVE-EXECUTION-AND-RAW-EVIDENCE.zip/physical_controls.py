"""Type-valid physical DLL mutants must disagree with executed PC callers."""
from pathlib import Path
import sys,json,hashlib,struct,subprocess
S=Path(__file__).resolve().parent;W=S.parent;ROOT=W.parents[1];sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'));import dnfile
raw=(S/'authored2.dll').read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest();assert sha(raw)=='15e0150337a14f1613321385af2d9b1997abd1bc255d56abe4a4ce2c5f7ac2cf'
pe=dnfile.dnPE(data=raw);cil=json.loads((S/'shared-authored2/ALL-CIL.json').read_bytes());methods={m['token']:m for m in cil['methods']};native=json.loads((S/'NATIVE-COMPARE.json').read_bytes());baseline=json.loads((S/'ACTUAL-CIL.json').read_bytes());out=S/'physical-controls';out.mkdir(exist_ok=True);results=[]
def ins(rid):return methods[f'0x{0x6000000|rid:08X}']['instructions']
def codeat(rid):
 p=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[rid-1].Rva);return p+(1 if raw[p]&3==2 else(struct.unpack_from('<H',raw,p)[0]>>12)*4)
def execute(name,rid,offset,before,after):
 at=codeat(rid)+offset;assert len(before)==len(after)and raw[at:at+len(before)]==before;bad=bytearray(raw);bad[at:at+len(after)]=after;delta=[i for i,(a,b)in enumerate(zip(raw,bad))if a!=b];assert delta and all(at<=i<at+len(before)for i in delta)
 p=out/(name+'.dll')
 if p.exists():assert p.read_bytes()==bad
 else:p.write_bytes(bad)
 report=out/(name+'.json');cmd=[str(ROOT/'.local/dotnet10/dotnet.exe'),str(S/'runtime/bin/Release/net10.0/Fixture.dll'),str(p),str(S/'CASES.json'),str(report)];run=subprocess.run(cmd,capture_output=True,timeout=30);(out/(name+'.log')).write_bytes(run.stdout+run.stderr);assert run.returncode==0,(name,run.returncode)
 actual=json.loads(report.read_bytes());assert actual['candidate_sha256']==sha(bad);assert not any(r['error']in['System.InvalidProgramException','System.BadImageFormatException','System.TypeLoadException']for r in actual['results']),name
 lookup={r['name']:r for r in actual['results']};diff=[dict(original=r,actual=lookup[r['name']])for r in native['results']if r!=lookup[r['name']]];assert diff,('False semantic accept',name)
 exc=[dict(baseline=r,mutant=lookup[r['name']])for r in baseline['results']if'throw-parent'in r['name']and r!=lookup[r['name']]]
 results.append(dict(name=name,token=f'0x{0x6000000|rid:08X}',mutant_sha256=sha(bad),physical_byte_deltas=len(delta),file_offset=at,before=before.hex(),after=after.hex(),process_exit=0,invalid_program_cases=0,native_normal_differences=len(diff),managed_exception_differences=len(exc),example=diff[0],native_exception_execution=False))
calls=ins(0x2a8);call=next(i for i in calls if i['opcode']=='callvirt'and i['operand']['name']=='GetComponent');at=codeat(0x2a8)+call['offset'];execute('start-omitted-manager-component',0x2a8,call['offset'],raw[at:at+5],b'\x26\x14\0\0\0')
flags=next(i for i in calls if i['opcode']=='stfld'and i['operand']['identity'].endswith('EnemyManager::flagsNum'));waves=next(i for i in calls if i['opcode']=='stfld'and i['operand']['identity'].endswith('EnemyManager::wavesNum'));at=codeat(0x2a8);execute('start-wrong-manager-flags-target',0x2a8,flags['offset']+1,raw[at+flags['offset']+1:at+flags['offset']+5],raw[at+waves['offset']+1:at+waves['offset']+5])
threshold=next(i for i in ins(0x2ab)if i['opcode']=='ldc.r4'and i['operand']==1.75);execute('update-wrong-ready-threshold',0x2ab,threshold['offset']+1,struct.pack('<f',1.75),struct.pack('<f',1))
branch=next(i for i in ins(0x2ab)if i['opcode']=='bge.un');execute('update-wrong-NaN-branch',0x2ab,branch['offset'],b'\x41',b'\x3c')
rows=ins(0x2c2);index=next(k for k,i in enumerate(rows)if i['opcode']=='callvirt'and i['operand']['name']=='SetActive'and k>20);constant=rows[index-1];assert constant['opcode']=='ldc.i4'and constant['operand']==0;execute('game-start-wrong-meter-visibility',0x2c2,constant['offset']+1,struct.pack('<I',0),struct.pack('<I',1))
spacing=next(i for i in ins(0xe7)if i['opcode']=='ldc.r4'and i['operand']==92);execute('bank-wrong-card-spacing',0xe7,spacing['offset']+1,struct.pack('<f',92),struct.pack('<f',91))
dispose=next(i for i in ins(0xe7)if i['opcode']=='call'and i['operand']['name']=='Dispose');at=codeat(0xe7)+dispose['offset'];execute('bank-omitted-finally-dispose',0xe7,dispose['offset'],raw[at:at+5],b'\x26\0\0\0\0')
rows=ins(0xe4);index=next(k for k,i in enumerate(rows)if i['opcode']=='callvirt'and i['operand']['name']=='SetKeyText');arg=rows[index-1];assert arg['opcode']=='ldloc.s'and arg['operand']['index']==0;execute('bank-wrong-prop-key-index',0xe4,arg['offset'],b'\x11\0',b'\x16\0')
result=dict(scope='TYPE_VALID_PHYSICAL_CANDIDATE_BYTE_MUTANTS_VS_EXECUTED_NATIVE_NORMAL_PROFILES',candidate_sha256=sha(raw),controls=len(results),rejected=len(results),process_failures_counted_as_semantic_controls=0,rows=results,managed_exception_checks_do_not_claim_native_unwind_execution=True)
(S/'PHYSICAL-CONTROLS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(controls=len(results),rejected=len(results))))
