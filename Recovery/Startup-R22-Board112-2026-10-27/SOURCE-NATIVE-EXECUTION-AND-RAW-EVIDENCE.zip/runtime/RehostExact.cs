using System.Reflection;using System.Reflection.Emit;using System.Reflection.Metadata;using System.Reflection.PortableExecutable;using MC=Mono.Cecil;using CIL=Mono.Cecil.Cil;
// A separate EH-capable reader. The historical rehoster is left unchanged.
// Raw opcodes, branches, code length and EH offsets remain the actual DLL's.
public static class RehostExact {
 static MC.TypeReference Close(MC.TypeReference t,MC.MethodReference m){
  if(t is MC.GenericParameter g){if(g.Type==MC.GenericParameterType.Method&&m is MC.GenericInstanceMethod gm)return gm.GenericArguments[g.Position];if(g.Type==MC.GenericParameterType.Type&&m.DeclaringType is MC.GenericInstanceType gt)return gt.GenericArguments[g.Position];throw new NotSupportedException(t.FullName);}
  if(t is MC.ArrayType a)return new MC.ArrayType(Close(a.ElementType,m),a.Rank);
  if(t is MC.GenericInstanceType x){var n=new MC.GenericInstanceType(x.ElementType);foreach(var p in x.GenericArguments)n.GenericArguments.Add(Close(p,m));return n;}return t;
 }
 public static MethodInfo Emit(byte[] dll,MC.MethodDefinition source,Func<MC.TypeReference,Type> map,Func<MC.FieldReference,FieldInfo> field,Func<MC.MethodReference,MethodBase> method){
  using var pe=new PEReader(new MemoryStream(dll));var body=pe.GetMethodBody(source.RVA);byte[] code=body.GetILBytes()!;if(code.Length!=source.Body.CodeSize)throw new InvalidOperationException("Raw body mismatch");
  var args=(source.HasThis?new[]{map(source.DeclaringType)}:Array.Empty<Type>()).Concat(source.Parameters.Select(p=>map(p.ParameterType))).ToArray();var dm=new DynamicMethod("Actual_"+source.MetadataToken.ToInt32().ToString("X8"),map(source.ReturnType),args,typeof(RehostExact).Module,false);dm.InitLocals=source.Body.InitLocals;var di=dm.GetDynamicILInfo();var original=(byte[])code.Clone();var allowed=new HashSet<int>();
  foreach(var i in source.Body.Instructions){int token=0;bool replace=true;switch(i.Operand){
   case string v:token=di.GetTokenFor(v);break;
   case MC.TypeReference v:token=di.GetTokenFor(map(v).TypeHandle);break;
   case MC.FieldReference v:var f=field(v);if(f.FieldType!=map(v.FieldType))throw new InvalidOperationException("Changed field contract: "+v.FullName);token=di.GetTokenFor(f.FieldHandle,f.DeclaringType!.TypeHandle);break;
   case MC.MethodReference v:var m=method(v);if(v.HasThis==m.IsStatic||!v.Parameters.Select(p=>map(Close(p.ParameterType,v))).SequenceEqual(m.GetParameters().Select(p=>p.ParameterType)))throw new InvalidOperationException("Changed callee contract: "+v.FullName);if(m is MethodInfo mi&&mi.ReturnType!=map(Close(v.ReturnType,v)))throw new InvalidOperationException("Changed return: "+v.FullName);token=di.GetTokenFor(m.MethodHandle,m.DeclaringType!.TypeHandle);break;
   case MC.CallSite:throw new NotSupportedException("calli is not modeled");default:replace=false;break;
  }if(replace){int at=i.Offset+i.OpCode.Size;BitConverter.GetBytes(token).CopyTo(code,at);for(int n=at;n<at+4;n++)allowed.Add(n);}}
  for(int n=0;n<code.Length;n++)if(code[n]!=original[n]&&!allowed.Contains(n))throw new InvalidOperationException("Non-token instruction byte changed");
  var locals=SignatureHelper.GetLocalVarSigHelper();foreach(var v in source.Body.Variables)locals.AddArgument(map(v.VariableType),v.IsPinned);di.SetLocalSignature(locals.GetSignature());
  if(body.ExceptionRegions.Length!=source.Body.ExceptionHandlers.Count)throw new InvalidOperationException("EH parse mismatch");
  if(body.ExceptionRegions.Length>0){var eh=new byte[4+24*body.ExceptionRegions.Length];eh[0]=0x41;int size=eh.Length;eh[1]=(byte)size;eh[2]=(byte)(size>>8);eh[3]=(byte)(size>>16);int at=4;foreach(var r in body.ExceptionRegions){if(r.Kind!=System.Reflection.Metadata.ExceptionRegionKind.Finally)throw new NotSupportedException("Only explicit finally is reviewed");foreach(int x in new[]{2,r.TryOffset,r.TryLength,r.HandlerOffset,r.HandlerLength,0}){BitConverter.GetBytes(x).CopyTo(eh,at);at+=4;}}di.SetExceptions(eh);}
  di.SetCode(code,body.MaxStack);return dm;
 }
}
