"""Publish the constructed and finitely checked child; do not mark gameplay PASS."""
from pathlib import Path
import json,sys,hashlib,collections
S=Path(__file__).resolve().parent;W=S.parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113';C=R/'Recovery/Startup-R22-Board112-2026-10-27';assert not C.exists();C.mkdir()
sys.path.insert(0,str(W));from archive_support import js,pack,manifest
sha=lambda b:hashlib.sha256(b).hexdigest();construction=json.loads((S/'authored2.json').read_bytes());candidate=(S/'authored2.dll').read_bytes();assert sha(candidate)==construction['candidate_sha256']=='15e0150337a14f1613321385af2d9b1997abd1bc255d56abe4a4ce2c5f7ac2cf'
assert (S/'authored3.dll').read_bytes()==candidate
native=json.loads((S/'NATIVE-COMPARE.json').read_bytes());actual=json.loads((S/'ACTUAL-CIL.json').read_bytes());controls=json.loads((S/'PHYSICAL-CONTROLS.json').read_bytes());isolation=json.loads((S/'shared-authored2/ISOLATION.json').read_bytes());assert native['records']==128 and not native['differences']and controls['controls']==controls['rejected']==8 and isolation['unchanged_methoddefs']==2312
assert len(actual['results'])==131 and len([r for r in actual['results']if r['error']])==3 and all('dispose'in r['trace']for r in actual['results']if r['error']);assert construction['new_unique_repair_positions']==112 and construction['distinct_changed_methods']==5
pack(C/'STARTUP-R22-BOARD112-CANDIDATE.zip',[('STARTUP-R22-BOARD112.dll',candidate)])
for source,target in[(S/'authored2.json','CONSTRUCTION.json'),(S/'SHARED-TEST-START.json','SHARED-TEST-START.json'),(S/'shared-authored2/ISOLATION.json','ISOLATION.json'),(S/'shared-authored2/FROZEN-RAW.json','FROZEN-RAW.json'),(S/'shared-authored2/MEMBER-EXIT.json','MEMBER-EXIT.json'),(S/'shared-authored2/jit/RESULT.json','EXACT-JIT.json'),(S/'NATIVE-COMPARE.json','NATIVE-COMPARE.json'),(S/'PHYSICAL-CONTROLS.json','PHYSICAL-CONTROLS.json'),(S/'PARENT-ACTUAL-FAILURE.json','PARENT-ACTUAL-FAILURE.json'),(S/'EARLY-AUTHORING-REJECTED.json','EARLY-AUTHORING-REJECTED.json'),(S/'COMPILER-WORKFLOW-DERIVATION.json','COMPILER-WORKFLOW-DERIVATION.json')]:
 (C/target).write_bytes(source.read_bytes())
inputs=[]
for p in sorted(S.rglob('*')):
 if not p.is_file()or any(x in['bin','obj','__pycache__']for x in p.relative_to(S).parts):continue
 if p.suffix=='.dll'and p.parent.name=='physical-controls':continue
 inputs.append((p.relative_to(S).as_posix(),p.read_bytes()))
for p in[W/'startup-r19-batch100/construction.py',W/'startup-r13/construct.py',W/'startup-r2/construct.py',W/'startup-r5/native_runtime_common.py',ROOT/'audit/bulk400-generic-repair-2026-10-24/runtime/Mono.Cecil.dll']:
 inputs.append(('dependencies/'+p.relative_to(ROOT/'audit').as_posix(),p.read_bytes()))
pack(C/'SOURCE-NATIVE-EXECUTION-AND-RAW-EVIDENCE.zip',inputs)
progress=dict(status='CONSTRUCTED_112_POSITIONS_SCOPED_NATIVE_AND_CIL_CHECKS_PASS_FRESH_COMPILER_PENDING',candidate_sha256=sha(candidate),candidate_bytes=len(candidate),parent_sha256=construction['parent_sha256'],new_unique_repair_positions=112,distinct_changed_methods=5,unchanged_methoddefs=2312,exact_cil_executed_cases=131,normal_native_comparisons=128,native_normal_differences=0,managed_throw_finally_cases=3,native_exception_unwind_executed=False,physical_semantic_controls=8,early_authoring_callback_defects_preserved=4,target_type_stack_passes=5,target_jit_prepared=5,whole_type_raw_counts={'PASS':2199,'FAIL_OR_UNSUPPORTED':98},whole_type_interface_supplement_not_rerun=True,original_resource_restoration_pass_applies_to_parent_only=True,child_actual_import=False,child_actual_complex_gameplay=False,whole_game_accepted=False,qualified_methods=0,ipad_acceptance=False,fresh_linux_compiler='PENDING',fresh_apple_compiler='PENDING',ipa=None)
js(C/'PROGRESS.json',progress)
(C/'.gitattributes').write_bytes(b'* -text\n')
(C/'README.md').write_text('''# R22：恢复完整开局链，112个位置 / 5个方法

真实Unity父运行40413139415已确认35个Plant/Zombie资源、70个加载路由、9902项原始字段/引用全部正确；实际桌面鼠标进入第19关后154游戏秒仍没有单位，卡牌在原点且无Canvas。完整真实失败保留在相邻Complex-Gameplay检查点，没有被后续修复覆盖。

本批直接对照原版PC GameAssembly.dll完整调用者与metadata/原始字面量，恢复Board.Start、Board.Update、Board.GameStartOnBoard、Banks.Initialize、Banks.BankStart，计112个不重复原生语义位置，5个方法。位置不是112个独立游戏bug。创建并连接EnemyManager、按原关卡配置出怪参数/初始设备/预置卡牌，恢复开场阈值、卡槽动画、FlagMeter和音乐；卡槽恢复原版相邻价格比较、带finally的类型化枚举、父Canvas层级、零起始编号、(ordinal*92-677,22,0)位置与14张一页边界，以及原始道具栏启动。没有注入游戏单位、修改关卡、解锁/库存或直接赋值战斗状态。

父DLL75160a32…，子DLL15e01503…ac2cf。5个新方法全部迁移至追加区域，原槽位全部保留；其余2312个MethodDef、旧元数据行/堆/成员可见性及段权限不变。仅追加5个local签名、1个GetComponent<EnemyManager> MethodSpec，没有新增MemberRef。独立隔离验证含3个越界损坏控制。5个目标的冻结类型栈、全程序集成员访问和精确JIT准备通过；全程序集原始类型统计2199 PASS / 98 FAIL_OR_UNSUPPORTED，未将旧接口补充结果或其他方法当作本批行为证明。

实际执行子DLL原始CIL字节，仅重绑声明的外部成员token，保持操作码/分支/代码长度及原始EH偏移。131个有限用例运行，128个正常用例与5个未修改原版PC调用者实测逐条轨迹/状态一致；另3个受控父节点抛错用例确实执行CLR finally并记录Dispose。原版Windows C++异常展开未执行，这3个不能记为原生异常等价。所有Unity/列表/嵌套游戏调用叶子均为明确受控契约，不是Unity或iPad游玩。

8个物理DLL、类型有效的错误变体（遗漏manager、错误flags字段、错误ready阈值、错误NaN分支、错误meter显隐、卡牌间距、finally Dispose和道具索引）均在进程正常完成的情况下与已执行原生正常轨迹产生分歧。初版构建还保留4个回调敏感失败：资源加载回调改变background及GameObject查询回调改变ordinal；112位置版本修正为原版读取顺序，未把早期110位置版本冒充合格候选。

新EH执行器是独立工具，历史禁止EH的执行器与冻结验证器未改变。早期工具编译缺少PEReader扩展命名空间、未映射嵌套LawnApp，以及负控制驱动把ldloc.s误称ldloc，都属于工具问题，未计为游戏缺陷或语义拒绝控制。当前正常执行及8个语义控制均已实际完成。源码包保留依赖、原生证据、原始执行结果、所有负控制日志和字节变体位置。

下一门为固定子候选的全新IL2CPP转换及全部生成C/C++编译，再验证Apple输入并回到真实Unity复杂关卡种植/轨迹/攻击。实际加载的VisualScripting Core默认返回问题另行保留；本批尚未改SDK。当前不宣称子候选Unity导入、复杂关卡、iPad或IPA通过，正式新增合格方法0。
''',encoding='utf-8')
manifest(C)
p=R/'README.md';t=p.read_text('utf-8');at=t.index('\n\n',t.index('Real Unity run '));t=t[:at]+'\n\n[R22 Board112](Recovery/Startup-R22-Board112-2026-10-27/README.md) restores the complete startup/countdown/card-bank family: 112 native-backed positions in five methods, 128 finite normal PC/raw-CIL comparisons with zero differences, three managed finally cases and eight physical semantic controls. The other 2312 MethodDefs are preserved. Fresh child compiler and real complex gameplay remain pending; no new IPA.'+t[at:];p.write_text(t,'utf-8')
print(json.dumps(progress))
