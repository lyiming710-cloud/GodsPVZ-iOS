"""Author one complete Board/bank family; shared tests are a separate command."""
import sys
from construction import Context
import source_board,source_banks
c=Context();source_board.populate(c);source_banks.populate(c);c.save_authored(sys.argv[1])
