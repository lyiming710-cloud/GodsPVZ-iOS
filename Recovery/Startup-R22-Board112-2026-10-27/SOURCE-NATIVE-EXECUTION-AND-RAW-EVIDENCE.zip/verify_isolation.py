"""Independent complete PE/CLI isolation audit; no builder functions imported."""
from pathlib import Path
import sys,json,struct,hashlib,importlib.util
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'));sys.dont_write_bytecode=True
import dnfile
def mod(n,p):
    x=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(x);x.loader.exec_module(m);return m
writer=mod('independent_metadata_reader_r19',W/'startup-r2/construct.py');reader=mod('independent_body_reader_r19',ROOT/'audit/native111-publication-2026-10-20/repository/scripts/actions/static_gates.py')
sha=lambda b:hashlib.sha256(b).hexdigest();stem=sys.argv[1];P=Q/('shared-'+stem);P.mkdir(exist_ok=True)
a=(W/'startup-r21-ui-batch100/authored1.dll').read_bytes();b=(Q/(stem+'.dll')).read_bytes();report=json.loads((Q/(stem+'.json')).read_bytes());assert sha(a)==report['parent_sha256']=='75160a3233f1e1ab13a44f712efb4b47fdeb9b57bd38fa25f180276bb7b50e15' and sha(b)==report['candidate_sha256'] and len(report['changes'])==5 and report['new_unique_repair_positions']>100
ap=dnfile.dnPE(data=a);bp=dnfile.dnPE(data=b);targets={int(r['token'],16)&0xffffff for r in report['changes']};assert len(targets)==5
def metadata(data,p):
    cli=p.get_offset_from_rva(p.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress);rva,n=struct.unpack_from('<II',data,cli+8);at=p.get_offset_from_rva(rva);_,streams=writer.metadata_root(data[at:at+n]);values={k:v for k,_,v in streams};_,rows,_,_=writer.tables_decode(values['#~']);return values,rows
av,ar=metadata(a,ap);allowed=set();changed=[];relocated=[]
for rid,(x,y) in enumerate(zip(ap.net.mdtables.MethodDef.rows,bp.net.mdtables.MethodDef.rows),1):
    if not x.Rva:assert not y.Rva;continue
    at=ap.get_offset_from_rva(x.Rva);bt=bp.get_offset_from_rva(y.Rva);an=reader.parse_raw_method_body_span(a,at)[0];bn=reader.parse_raw_method_body_span(b,bt)[0]
    if a[at:at+an]!=b[bt:bt+bn]:changed.append(rid)
    if rid not in targets:assert x.Rva==y.Rva and an==bn and a[at:at+an]==b[bt:bt+bn];continue
    assert a[at:at+an]!=b[bt:bt+bn]
    if x.Rva!=y.Rva:assert a[at:at+an]==b[at:at+an];relocated.append(rid)
    else:
        assert a[at:at+2]==b[at:at+2];h=(struct.unpack_from('<H',b,bt)[0]>>12)*4;assert h==12;n=struct.unpack_from('<I',b,bt+4)[0]
        allowed.update(range(bt+2,bt+12));allowed.update(range(bt+h,bt+h+n));assert a[bt+h+n:at+an]==b[bt+h+n:at+an]
assert set(changed)==targets and len(ap.net.mdtables.MethodDef.rows)==len(bp.net.mdtables.MethodDef.rows)==2317
sh=ap.sections[-1].get_file_offset();opt=ap.OPTIONAL_HEADER.get_file_offset();cli=ap.get_offset_from_rva(ap.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress)
for at in [sh+8,sh+16,opt+8,opt+56,opt+64,cli+8,cli+12]:allowed.update(range(at,at+4))
def boundary(data):
    assert len(data)==len(b) and all(x==y or k in allowed for k,(x,y) in enumerate(zip(a,data)))
    p=dnfile.dnPE(data=data);v,rows=metadata(data,p);assert set(v)==set(av) and set(rows)==set(ar)
    for name,old in av.items():
        if name=='#~':continue
        if name in ['#Blob','#Strings','#US']:assert v[name].startswith(old)
        else:assert v[name]==old
    appends={10:len(report['new_memberrefs']),17:len(report['new_local_signatures']),43:len(report['new_methodspecs'])}
    for table,old in ar.items():
        assert len(rows[table])==len(old)+appends.get(table,0)
        for n,row in enumerate(old):
            if table==6 and n+1 in targets:assert rows[table][n][1:]==row[1:]
            else:assert rows[table][n]==row
    assert [x.Characteristics for x in ap.sections]==[x.Characteristics for x in p.sections]
boundary(b);controls=[]
for name,at in [('non-target-body',ap.get_offset_from_rva(ap.net.mdtables.MethodDef.rows[0x526-1].Rva)+12),('old-metadata-row',ap.net.mdtables.Field.rows[0].struct.get_file_offset()),('section-permissions',ap.sections[-1].get_file_offset()+36)]:
    bad=bytearray(b);bad[at]^=1
    try:boundary(bad)
    except AssertionError:controls.append(dict(name=name,rejected=True));continue
    raise AssertionError('Out-of-scope control accepted: '+name)
result=dict(scope='INDEPENDENT_ALL_2317_METHODDEF_AND_OLD_METADATA_BYTE_ISOLATION',candidate_sha256=sha(b),parent_sha256=sha(a),pass_=True,changed_methods=5,unchanged_methoddefs=2312,relocated_methods=[f'0x{0x6000000|rid:08X}' for rid in relocated],old_code_slots_preserved=True,old_metadata_rows_and_heaps_preserved=True,method_flags_and_section_permissions_unchanged=True,new_memberrefs=len(report['new_memberrefs']),new_locals=len(report['new_local_signatures']),new_methodspecs=len(report['new_methodspecs']),negative_controls=controls,semantic_or_product_acceptance=False)
(P/'ISOLATION.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,indent=2))
