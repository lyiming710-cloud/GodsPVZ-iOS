"""Original-PC-backed Board startup/countdown. This module authors, never tests."""
import struct
import source_common as s
from construction import old

def type_sig(c,name):
 own=[k for k,r in enumerate(s.pe.net.mdtables.TypeDef.rows,1)if(str(r.TypeNamespace)+'.'if str(r.TypeNamespace)else'')+str(r.TypeName)==name]
 if own:return b'\x12'+old.labels.comp(own[0]<<2)
 return b'\x12'+old.labels.comp(((c.type(name)&0xffffff)<<2)|1)

def generic(c,owner,name,arg):
 sig=b'\x0a\x01'+type_sig(c,arg)
 if owner=='InternalResourceLoader':definition=0x06000153;coded=0x153<<1
 else:
  defs=[]
  for k,r in enumerate(s.pe.net.mdtables.MemberRef.rows,1):
   if str(r.Name)!=name or r.Class.table.name!='TypeRef':continue
   t=r.Class.row;full=(str(t.TypeNamespace)+'.'if str(t.TypeNamespace)else'')+str(t.TypeName)
   if full==owner and r.Signature.value in[bytes.fromhex('3001001e00'),bytes.fromhex('1001011e001e00')]:defs.append(k)
  assert len(defs)==1,(owner,name,defs);definition=0xa000000|defs[0];coded=(defs[0]<<1)|1
 for k,r in enumerate(s.pe.net.mdtables.MethodSpec.rows,1):
  if c.rows[43][k-1][0]==coded and r.Instantiation.value==sig:return 0x2b000000|k
 for r in c.new_specs:
  if int(r['definition'],16)==definition and r['argument']==arg:return int(r['token'],16)
 c.rows[43].append([coded,c.blob(sig)]);token=0x2b000000|len(c.rows[43]);c.new_specs.append(dict(token=hex(token),definition=hex(definition),argument=arg,signature=sig.hex()));return token

def field(b,c,owner,name):return b.arg(0).token(0x7b,c.fld(owner,name))
def site(b,va,kind,description,fn):return b.site(va,kind,description,fn)
def gettype(c,name):
 own=[k for k,r in enumerate(s.pe.net.mdtables.TypeDef.rows,1)if str(r.TypeName)==name and not str(r.TypeNamespace)]
 return 0x02000000|own[0]if own else c.type(name)

def board_start(c):
 rid=0x2a8;b=c.begin(rid);loc,sig=c.append_locals(rid,[type_sig(c,'EnemyManager'),b'\x08',type_sig(c,'UnityEngine.SpriteRenderer')]);enumlocal=loc+1;backgroundlocal=loc+2
 mt=lambda owner,name,args=():c.meth(owner,name,args)
 f=lambda name:c.fld('Board',name)
 tr=mt('UnityEngine.Component','get_transform');setparent=mt('UnityEngine.Transform','SetParent',('UnityEngine.Transform','System.Boolean'))
 # Original requires the actual MouseManager; no defensive skip.
 field(b,c,'Board','mouseManager').token(0x6f,mt('MouseManager','ResetStart'))
 b.token(0x72,c.string('prefabs')).token(0x72,c.string('Managers')).token(0x72,c.string('EnemyManager'))
 site(b,0x180327b82,'CALL','Build original EnemyManager resource path',lambda x:x.token(0x28,mt('System.IO.Path','Combine',('System.String','System.String','System.String'))))
 site(b,0x180327b91,'CALL','Load original EnemyManager GameObject resource',lambda x:x.token(0x28,generic(c,'InternalResourceLoader','Load','UnityEngine.GameObject')))
 site(b,0x180327bb8,'CALL','Instantiate the original manager prefab',lambda x:x.token(0x28,generic(c,'UnityEngine.Object','Instantiate','UnityEngine.GameObject')))
 site(b,0x180327bd0,'CALL','Get actual EnemyManager component',lambda x:x.token(0x6f,generic(c,'UnityEngine.GameObject','GetComponent','EnemyManager')))
 # Store with a local so receiver evaluation does not rearrange the source call.
 b.store(loc).arg(0).loc(loc)
 site(b,0x180327bdc,'FIELD_WRITE','Attach the instantiated manager to Board.enemyManager',lambda x:x.token(0x7d,f('enemyManager')))
 site(b,0x180327beb,'FIELD_READ','Read Board.enemyManager before linking its board',lambda x:field(x,c,'Board','enemyManager'))
 b.arg(0);site(b,0x180327bfb,'FIELD_WRITE','Assign EnemyManager.board to this Board',lambda x:x.token(0x7d,c.fld('EnemyManager','board')))
 field(b,c,'Board','enemyManager');site(b,0x180327c20,'CALL','Capture manager transform before reading Board transform',lambda x:x.token(0x6f,tr));b.arg(0)
 site(b,0x180327c2d,'CALL','Read original Board transform',lambda x:x.token(0x28,tr));b.i4(0)
 site(b,0x180327c47,'CALL','Parent manager to Board with worldPositionStays=false',lambda x:x.token(0x6f,setparent))
 field(b,c,'Board','boardConfig');site(b,0x180327c51,'CONTROL_FLOW','Only the configuration-dependent block is optional in original native',lambda x:x.branch(0x39,'ret'))
 b.arg(0);field(b,c,'Board','boardConfig').token(0x6f,mt('BoardConfig','CreateMap')).token(0x7d,f('map'))
 b.token(0x28,mt('UnityEngine.Camera','get_main'));field(b,c,'Board','map').token(0x7b,c.fld('Map','cameraSize')).token(0x6f,mt('UnityEngine.Camera','set_orthographicSize',('System.Single',)))
 site(b,0x180327c9f,'FIELD_READ','Capture audioSource[0] before BGM list selection',lambda x:field(x,c,'Board','audioSource').i4(0).op('9a'))
 site(b,0x180327ce7,'FIELD_READ','Read original BGM registration list',lambda x:x.token(0x7e,c.fld('ResourceManager','BGMs')))
 site(b,0x180327ce3,'FIELD_READ','Select BGM from map.senarioState+9',lambda x:field(x,c,'Board','map').token(0x7b,c.fld('Map','senarioState')).i4(9).op('58'))
 site(b,0x180327d0d,'CALL','Fetch exact BGM slot, including original null slots',lambda x:x.token(0x6f,mt('System.Collections.Generic.List`1<UnityEngine.AudioClip>','get_Item',('System.Int32',))))
 site(b,0x180327d24,'CALL','Assign the original BGM clip before playback',lambda x:x.token(0x6f,mt('UnityEngine.AudioSource','set_clip',('UnityEngine.AudioClip',))))
 site(b,0x180327d29,'FIELD_READ','Read SunManager for original weather setup',lambda x:field(x,c,'Board','sunManager'))
 field(b,c,'Board','boardConfig');field(b,c,'Board','map')
 site(b,0x180327d44,'CALL','Set original max sun fall time from boardConfig/map',lambda x:x.token(0x6f,mt('SunManager','SetMaxSunFallTime',('BoardConfig','Map'))))
 field(b,c,'Board','sunManager');field(b,c,'Board','boardConfig').token(0x7b,c.fld('BoardConfig','baseSunPoint')).token(0x7d,c.fld('SunManager','sunPoint'))
 for source,dest,readva,writeva in [('zombieTypes','zombieTypes',0x180327d80,0x180327d8d),('enemyPoint_Base','enemyPoint_Base',0x180327db7,0x180327dba),('flagsNum','flagsNum',0x180327dda,0x180327ddd),('wavesNum','wavesNum',0x180327dfd,0x180327e00)]:
  field(b,c,'Board','enemyManager')
  site(b,readva,'FIELD_READ','Load original BoardConfig.'+source,lambda x,k=source:field(x,c,'Board','boardConfig').token(0x7b,c.fld('BoardConfig',k)))
  site(b,writeva,'FIELD_WRITE','Configure EnemyManager.'+dest+' before Unity Start',lambda x,k=dest:x.token(0x7d,c.fld('EnemyManager',k)))
 for va,owner,fieldname,name,args in[(0x180327e1e,'DeviceManager','deviceManager','SetupPreDevice',('BoardConfig','Map')),(0x180327e3a,'Banks','banks','SetPreCards',('BoardConfig',)),(0x180327e51,'Banks','banks','BoardEntriesEffect',())]:
  field(b,c,'Board',fieldname)
  for arg in args:field(b,c,'Board','boardConfig'if arg=='BoardConfig'else'map')
  site(b,va,'CALL','Restore original '+owner+'.'+name,lambda x,o=owner,n=name,a=args:x.token(0x6f,mt(o,n,a)))
 b.token(0x72,c.string('\u52a0\u8f7d\u914d\u7f6e\u6587\u4ef6\u6210\u529f'))
 site(b,0x180327e74,'CALL','Preserve original loaded-config diagnostic',lambda x:x.token(0x28,mt('UnityEngine.Debug','Log',('System.Object',))))
 # The native snapshots the enum before constructing path/type/name.
 field(b,c,'Board','map').token(0x7b,c.fld('Map','senarioState')).store(enumlocal)
 b.token(0x72,c.string('sprites')).token(0x72,c.string('Board')).token(0x72,c.string('Background')).token(0x28,mt('System.IO.Path','Combine',('System.String','System.String','System.String')))
 b.token(0xd0,gettype(c,'SenarioState')).token(0x28,mt('System.Type','GetTypeFromHandle',('System.RuntimeTypeHandle',))).loc(enumlocal).token(0x8c,gettype(c,'SenarioState')).token(0x28,mt('System.Enum','GetName',('System.Type','System.Object'))).token(0x28,mt('System.IO.Path','Combine',('System.String','System.String')))
 site(b,0x180327fb4,'FIELD_READ','Capture original background renderer before resource loading can change fields',lambda x:field(x,c,'Board','background').store(backgroundlocal))
 b.token(0x28,generic(c,'InternalResourceLoader','Load','UnityEngine.Sprite')).store(2)
 b.loc(backgroundlocal).loc(2).token(0x6f,mt('UnityEngine.SpriteRenderer','set_sprite',('UnityEngine.Sprite',)))
 b.mark('ret').op('2a');c.add(rid,b,'Restore complete original Board.Start manager/resource/configuration ordering without optional-null suppression',maxstack=5,local_token=sig,group='complete-original-board-startup')

def board_update(c):
 rid=0x2ab;b=c.begin(rid);mt=lambda o,n,a=():c.meth(o,n,a);f=lambda n:c.fld('Board',n)
 loc,sig=c.append_locals(rid,[b'\x0c',b'\x0c',type_sig(c,'UnityEngine.GameObject'),type_sig(c,'UnityEngine.Transform')]);oldtime,newtime,effect,target=range(loc,loc+4)
 site(b,0x1803291c6,'CALL','Run original popup updates on every frame',lambda x:x.arg(0).token(0x28,mt('Board','Update_Popups')))
 field(b,c,'Board','gameStart').branch(0x39,'countdown')
 field(b,c,'Board','isWon');site(b,0x1803291d9,'CONTROL_FLOW','Dispatch started-game frame by original isWon field',lambda x:x.branch(0x3a,'won'))
 site(b,0x1803291e0,'CALL','Run original Board input update while not won',lambda x:x.arg(0).token(0x28,mt('Board','Update_BoardKey')));b.op('2a').mark('won')
 site(b,0x1803291ea,'CALL','Run original win update after victory',lambda x:x.arg(0).token(0x28,mt('Board','Update_isWon')));b.op('2a').mark('countdown')
 field(b,c,'Board','gameStartCountdown').store(oldtime);b.loc(oldtime).token(0x28,mt('UnityEngine.Time','get_deltaTime')).op('59').store(newtime).arg(0).loc(newtime).token(0x7d,f('gameStartCountdown'))
 site(b,0x180329212,'FIELD_READ','Read original cardBankHidden countdown latch',lambda x:field(x,c,'Board','cardBankHidden'))
 b.branch(0x39,'ready');b.loc(newtime).r4(3.0999999046325684)
 site(b,0x18032922f,'CONTROL_FLOW','Only hide after countdown is ordered-below original f32 3.1',lambda x:x.branch(0x41,'ready'))
 site(b,0x180329231,'FIELD_READ','Read actual Banks animator for original reveal/hide trigger',lambda x:field(x,c,'Board','banks').token(0x7b,c.fld('Banks','animator')))
 b.token(0x72,c.string('hide'));site(b,0x18032925b,'CALL','Send original hide animation trigger',lambda x:x.token(0x6f,mt('UnityEngine.Animator','SetTrigger',('System.String',))))
 b.arg(0).i4(0);site(b,0x180329260,'FIELD_WRITE','Clear original one-shot card bank hidden latch',lambda x:x.token(0x7d,f('cardBankHidden')))
 b.mark('ready').loc(newtime).r4(1.75);site(b,0x180329273,'CONTROL_FLOW','Reject current countdown above ready threshold or unordered',lambda x:x.branch(0x42,'start'))
 b.loc(oldtime).r4(1.75);site(b,0x18032927c,'CONTROL_FLOW','Only create ready effect when previous countdown was above 1.75',lambda x:x.branch(0x43,'start'))
 site(b,0x1803292a8,'FIELD_READ','Read ordered boardClips collection',lambda x:x.token(0x7e,c.fld('ResourceManager','boardClips')))
 b.i4(6);site(b,0x1803292c4,'CALL','Play original ready audio slot 6',lambda x:x.token(0x6f,mt('System.Collections.Generic.List`1<UnityEngine.AudioClip>','get_Item',('System.Int32',))))
 site(b,0x1803292ce,'CALL','Use actual main Camera position for ready audio',lambda x:x.token(0x28,mt('UnityEngine.Camera','get_main')))
 site(b,0x1803292e1,'CALL','Read main Camera transform',lambda x:x.token(0x6f,mt('UnityEngine.Component','get_transform')))
 site(b,0x1803292fa,'CALL','Read audio emission position as a Vector3 value',lambda x:x.token(0x6f,mt('UnityEngine.Transform','get_position')))
 site(b,0x18032931d,'CALL','Read original configured audio volume',lambda x:x.token(0x28,mt('GlobalStaticVars','AudioVolume')))
 site(b,0x18032933a,'CALL','Create original positional ready AudioSource',lambda x:x.token(0x28,mt('GlobalStaticVars','CreateAudioAtPoint',('UnityEngine.AudioClip','UnityEngine.Vector3','System.Single'))));b.op('26')
 site(b,0x18032934d,'FIELD_READ','Read original FightReady prefab',lambda x:x.token(0x7e,c.fld('ResourceManager','prefab_FightReady')))
 site(b,0x180329373,'CALL','Instantiate original FightReady effect',lambda x:x.token(0x28,generic(c,'UnityEngine.Object','Instantiate','UnityEngine.GameObject')));b.store(effect).loc(effect)
 site(b,0x180329389,'CALL','Capture scale assignment receiver before scale query',lambda x:x.token(0x6f,mt('UnityEngine.GameObject','get_transform')));b.store(target).loc(target).loc(effect)
 site(b,0x180329396,'CALL','Query effect transform again in original order',lambda x:x.token(0x6f,mt('UnityEngine.GameObject','get_transform')))
 site(b,0x1803293af,'CALL','Read actual prefab local scale',lambda x:x.token(0x6f,mt('UnityEngine.Transform','get_localScale')))
 site(b,0x1803293bd,'FIELD_READ','Scale by original map camera size',lambda x:field(x,c,'Board','map').token(0x7b,c.fld('Map','cameraSize')))
 b.r4(540);site(b,0x1803293c2,'CONTROL_FLOW','Preserve original f32 cameraSize/540 scaling',lambda x:x.op('5b').token(0x28,mt('UnityEngine.Vector3','op_Multiply',('UnityEngine.Vector3','System.Single'))))
 site(b,0x180329403,'CALL','Write scaled original ready effect',lambda x:x.token(0x6f,mt('UnityEngine.Transform','set_localScale',('UnityEngine.Vector3',))))
 b.mark('start').loc(newtime).r4(0);site(b,0x18032940f,'CONTROL_FLOW','Start only when countdown is strictly negative; unordered does not start',lambda x:x.branch(0x41,'ret'))
 b.arg(0).token(0x28,mt('Board','GameStartOnBoard')).mark('ret').op('2a');c.add(rid,b,'Restore original frame dispatch, one-shot bank trigger and ready-effect thresholds with ordered f32 comparisons',maxstack=5,local_token=sig,group='complete-original-board-countdown')

def board_game_start(c):
 rid=0x2c2;b=c.begin(rid);mt=lambda o,n,a=():c.meth(o,n,a);f=lambda n:c.fld('Board',n)
 # Original captures the object before setting gameStart.
 loc,sig=c.append_locals(rid,[type_sig(c,'UnityEngine.GameObject'),type_sig(c,'FlagMeter')]);meter=loc+1;field(b,c,'Board','buttomButtons').store(loc);b.arg(0).i4(1).token(0x7d,f('gameStart'))
 b.loc(loc).op('14').token(0x28,mt('UnityEngine.Object','op_Inequality',('UnityEngine.Object','UnityEngine.Object'))).branch(0x39,'bank');field(b,c,'Board','buttomButtons').i4(1).token(0x6f,mt('UnityEngine.GameObject','SetActive',('System.Boolean',)))
 b.mark('bank');field(b,c,'Board','banks').op('14').token(0x28,mt('UnityEngine.Object','op_Inequality',('UnityEngine.Object','UnityEngine.Object'))).branch(0x39,'meter');field(b,c,'Board','banks').token(0x6f,mt('Banks','BankStart'))
 b.mark('meter');site(b,0x180326cf0,'FIELD_READ','Load original ResourceManager flag-meter prefab',lambda x:x.token(0x7e,c.fld('ResourceManager','prefab_FlagMeter')))
 site(b,0x180326d08,'CALL','Instantiate exact FlagMeter prefab',lambda x:x.token(0x28,generic(c,'UnityEngine.Object','Instantiate','FlagMeter')))
 b.store(meter).arg(0).loc(meter)
 site(b,0x180326d14,'FIELD_WRITE','Store original Board.flagMeter',lambda x:x.token(0x7d,f('flagMeter')))
 field(b,c,'Board','flagMeter');site(b,0x180326d33,'FIELD_READ','Pass configured EnemyManager to FlagMeter',lambda x:field(x,c,'Board','enemyManager'))
 site(b,0x180326d3d,'CALL','Initialize original flag-meter waves and flags',lambda x:x.token(0x6f,mt('FlagMeter','Initialize',('EnemyManager',))))
 field(b,c,'Board','flagMeter');site(b,0x180326d54,'CALL','Capture meter transform before UI parent',lambda x:x.token(0x6f,mt('UnityEngine.Component','get_transform')))
 site(b,0x180326d59,'FIELD_READ','Read original UI_flagMeterButtom target',lambda x:field(x,c,'Board','UI_flagMeterButtom'))
 site(b,0x180326d6b,'CALL','Read original flag-meter parent transform',lambda x:x.token(0x6f,mt('UnityEngine.GameObject','get_transform')));b.i4(0)
 site(b,0x180326d85,'CALL','Parent flag-meter preserving original local coordinates',lambda x:x.token(0x6f,mt('UnityEngine.Transform','SetParent',('UnityEngine.Transform','System.Boolean'))))
 field(b,c,'Board','flagMeter');site(b,0x180326d9c,'CALL','Get flag-meter transform for original position',lambda x:x.token(0x6f,mt('UnityEngine.Component','get_transform')))
 b.r4(-195).r4(0).r4(0).token(0x73,mt('UnityEngine.Vector3','.ctor',('System.Single','System.Single','System.Single')))
 site(b,0x180326dcf,'CALL','Apply original (-195,0,0) meter local position',lambda x:x.token(0x6f,mt('UnityEngine.Transform','set_localPosition',('UnityEngine.Vector3',))))
 field(b,c,'Board','flagMeter');site(b,0x180326de6,'CALL','Read meter GameObject before original visibility change',lambda x:x.token(0x6f,mt('UnityEngine.Component','get_gameObject')));b.i4(0)
 site(b,0x180326dfc,'CALL','Preserve original initially hidden flag-meter',lambda x:x.token(0x6f,mt('UnityEngine.GameObject','SetActive',('System.Boolean',))))
 site(b,0x180326e2f,'FIELD_READ','Capture original audioSource[0] before configured volume',lambda x:field(x,c,'Board','audioSource').i4(0).op('9a'))
 site(b,0x180326e59,'FIELD_READ','Read actual GlobalStaticVars.gLawnApp',lambda x:x.token(0x7e,c.fld('GlobalStaticVars','gLawnApp')))
 site(b,0x180326e66,'FIELD_READ','Read original BGMVolume',lambda x:x.token(0x7b,c.fld('LawnApp','BGMVolume')))
 site(b,0x180326e71,'CALL','Assign original BGM volume before playback',lambda x:x.token(0x6f,mt('UnityEngine.AudioSource','set_volume',('System.Single',))))
 field(b,c,'Board','audioSource').i4(0).op('9a');site(b,0x180326e9d,'CALL','Start the selected original BGM',lambda x:x.token(0x6f,mt('UnityEngine.AudioSource','Play')));b.op('2a')
 c.add(rid,b,'Restore original FlagMeter creation/initialization/parent/visibility and configured BGM start with Unity object truthiness',maxstack=5,local_token=sig,group='complete-original-board-game-start')

def populate(c):board_start(c);board_update(c);board_game_start(c)
