"""Preserve a real failed gameplay run before changing any game code."""
from pathlib import Path
import json,sys,hashlib,subprocess
S=Path(__file__).resolve().parent;W=S.parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113'
sys.path.insert(0,str(W));from archive_support import js,pack,manifest
D=W/'r21-gameplay-run-40413139415';C=R/'Recovery/Startup-R21-Complex-Gameplay-2026-10-27';Z=R/'Recovery/Startup-R21-Zombie-Serialization-2026-10-27'
summary=json.loads((D/'ACTUAL-READBACK.json').read_bytes())
run=json.loads(subprocess.check_output(['C:/Program Files/GitHub CLI/gh.exe','run','view','40413139415','--repo','lyiming710-cloud/GodsPVZ-iOS','--json','status,conclusion,headSha,url'],cwd=R))
assert run['conclusion']=='failure'and run['headSha']==summary['workflow_source_commit'];js(D/'RUN.json',run)
pack(C/'ACTUAL-40413139415-FULL-BYTE-READBACK.zip',[(p.relative_to(D).as_posix(),p.read_bytes())for p in sorted(D.rglob('*'))if p.is_file()])
js(C/'ACTUAL-40413139415.json',summary)
for p in (D/'gameplay/screens').glob('*final.png'):
 assert p.read_bytes().startswith(b'\x89PNG\r\n\x1a\n');(C/'ACTUAL-COMPLEX-LEVEL-154SECONDS-40413139415.png').write_bytes(p.read_bytes())
for p in [C,Z]:
 progress=json.loads((p/'PROGRESS.json').read_bytes())if(p/'PROGRESS.json').exists()else{}
 progress.update(status='ACTUAL_35_RESOURCES_MATCH_ORIGINAL_COMPLEX_GAMEPLAY_FAIL',actual_run=40413139415,workflow_source_commit=run['headSha'],actual_resource_routes=70,actual_resource_leaf_checks_passed=9902,actual_resource_leaf_checks_failed=0,actual_zombie_field_values_pass=True,actual_plant_field_values_pass=True,game_dll_changed=False,gameplay_proven=False,trajectory_acceptance='FAIL_NO_UNITS_OBSERVED',plant_damage_acceptance='UNREACHED',qualified_methods_added=0,ipa=None,next_real_state='COMPLETED_FAILED_GAMEPLAY')
 js(p/'PROGRESS.json',progress)
 next_run=json.loads((p/'NEXT-REAL-RUN.json').read_bytes());next_run.update(status='COMPLETED_FAILURE',result='RESOURCE_VALUES_PASS_GAMEPLAY_FAIL_NO_UNITS_154_SECONDS');js(p/'NEXT-REAL-RUN.json',next_run)
 with(p/'README.md').open('a',encoding='utf-8')as f:
  f.write('\n## 实测40413139415：全部资源值正确，复杂关卡仍停滞\n\n固定source b945553、游戏DLL75160a32未变。9植物及26僵尸合计3836源字段，在AssetDatabase/Resources两路70个实际资源实例路由展开9902项标量/数组/持久引用比对，全部通过，0失败/0未决。实际桌面鼠标完成选卡、确定和开始，Board.level=19且gameStart=true；继续观察153.6877游戏秒/1614帧后仍没有任何单位轨迹或植物弹丸。Ready卡牌根世界位置一直(0,0,0)，背景无父Canvas，种植尝试0。真实游戏游玩验收失败；不将无异常日志当作成功。席位归还exit0。\n\n实际UI进程加载的Unity.VisualScripting.Core.dll SHA dc1b51cc…7c8f9，ComponentHolderProtocol.GameObject的IL为142a，AddComponent<T>为1200fe156900001b062a，确认为空值/默认值返回；先前参考DLL线索已由实际加载二进制闭合。图鉴仍失败。原版PC对照另证当前Board.Start省略出怪管理器创建及配置、Banks.Initialize省略真实父节点/位置设置，后续按整条开局调用链恢复，不能给探针直接注入单位或强改显示状态。完整真实失败和二进制保存在Complex-Gameplay相邻目录。无新IPA。\n')
 manifest(p)
root=R/'README.md';text=root.read_text('utf-8');start=text.index('Real Unity run ');end=text.index('\n\n',start)
text=text[:start]+'Real Unity run [40413139415](https://github.com/lyiming710-cloud/GodsPVZ-iOS/actions/runs/40413139415) verifies all 35 restored Plant/Zombie resources through 70 actual loading routes / 9,902 original field and reference checks. Actual OS input enters Adventure 19, but 154 game seconds yield no units or attacks; the Ready card has no parent Canvas. Complex gameplay fails. The actual loaded VisualScripting helper is also confirmed to return defaults. [Full actual evidence and next repair](Recovery/Startup-R21-Complex-Gameplay-2026-10-27/README.md). Game DLL remains unchanged; no new IPA.'+text[end:];root.write_text(text,'utf-8')
js(S/'ACTUAL-PARENT-ARCHIVE.json',dict(run=40413139415,full_archive=str(C/'ACTUAL-40413139415-FULL-BYTE-READBACK.zip'),gameplay_pass=False,resources_pass=True))
print('Preserved full failed actual run and 70-route original resource readback')
