"""Archive whole managed-code findings without promoting any candidate."""
from pathlib import Path
import collections,csv,json,sys
O=Path(__file__).resolve().parent;W=O.parent;ROOT=W.parents[1];sys.path.insert(0,str(W))
from archive_support import js,manifest,pack,sha
R=ROOT/'audit/repo-native113';D=R/'Recovery/Whole-Program-Census-2026-10-26';Q=W/'startup-r19-batch100';P=Q/'shared-candidate9';N=O/'run3';digest='0ba5bc7ec9603d14a1c0bde6d784d232aa78efaa1700304e75e4f2b56ef7dec2'
assert not D.exists();assert sha((Q/'candidate9.dll').read_bytes())==digest
read=lambda p:json.loads(Path(p).read_bytes());summary=read(N/'SUMMARY.json');rows=read(N/'ALL-METHOD-STATUS.json')['rows'];cil={r['token']:r for r in read(N/'ALL-CIL.json')['methods']};pending={r['token']:r for r in read(P/'PENDING-RUNTIME-PROFILES.json')['rows']}
assert summary['candidate_sha256']==digest and summary['bodies']==2297 and summary['deduplicated_finding_methods']==123 and summary['finding_categories']['EMPTY_CIL_WITH_NONEMPTY_NATIVE_CALLER']==8
gaps=[r for r in rows if any(i['kind']=='EMPTY_CIL_WITH_NONEMPTY_NATIVE_CALLER' for i in r['issues'])];assert len(gaps)==8 and all(r['token'] not in pending and not r['r19_target'] and cil[r['token']]['instructions']==[dict(offset=0,opcode='ret',operand=None)] for r in gaps)
marker=[r for r in rows if r['markers'] and '::System.Collections.IEnumerator.Reset(' not in r['name']];assert len(marker)==5
queue=[]
for r in rows:
 issues=r['issues'];isgap=r in gaps;is_pending=r['token'] in pending;is_marker=r in marker;reset=bool(r['markers']) and '::System.Collections.IEnumerator.Reset(' in r['name']
 if not issues and not is_pending:continue
 priority='P0_SOURCE_GAP' if isgap else 'P1_R19_RUNTIME_PROFILE' if is_pending else 'P2_OTHER_SEMANTIC_MARKER_REVIEW' if is_marker else 'P4_RESET_THROW_CONTEXT_RETAINED' if reset else 'P3_VALIDATOR_OR_JIT_REVIEW'
 action='核实迁移记录并按原版恢复完整方法体，再进行独立运行对照' if isgap else '完成当前候选完整调用方运行对照；发现偏差后修复' if is_pending else '对照原版控制流确认标记是否代表缺失逻辑，不能直接删除字符串当作修复' if is_marker else '保留异常形态与历史原版证据；不因反编译标记自动重写 Reset' if reset else '区分真实 IL 错误与检查器不支持形态，保留原始失败并用独立证据补足'
 queue.append(dict(token=r['token'],name=r['name'],priority=priority,required_action=action,known_body_gap=isgap,r19_runtime_pending=is_pending,non_reset_marker_review=is_marker,frozen_status=r['frozen_status'],jit_status=r['jit_status'],issue_categories=[i['kind'] for i in issues],existing_finite_r19_profile=bool(r['current_r19_finite_profile']),not_a_confirmed_bug_count=True))
queue.sort(key=lambda r:(r['priority'],r['token']));assert len(queue)==156;counts=dict(collections.Counter(r['priority'] for r in queue));assert counts=={'P0_SOURCE_GAP':8,'P1_R19_RUNTIME_PROFILE':35,'P2_OTHER_SEMANTIC_MARKER_REVIEW':4,'P3_VALIDATOR_OR_JIT_REVIEW':92,'P4_RESET_THROW_CONTEXT_RETAINED':17}
D.mkdir();(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text\n*.md -text\n*.csv -text\n*.py -text\n*.zip -text\n')
js(D/'SOURCE-GAPS.json',dict(scope='EIGHT_EMPTY_MANAGED_BODIES_WITH_NONEMPTY_ORIGINAL_NATIVE_CALLERS_NOT_YET_REPAIRED',candidate_sha256=digest,methods=8,rows=[dict(token=r['token'],name=r['name'],candidate_cil=cil[r['token']],original_native=r['tiny_native_summary'],unity_lifecycle_name_candidate=r['unity_lifecycle_name_candidate'],runtime_device_cause_proven=False,porting_intent_review_required=True) for r in gaps]))
js(D/'OTHER-SEMANTIC-MARKERS.json',dict(candidate_sha256=digest,methods=5,rows=[dict(token=r['token'],name=r['name'],already_in_r19_pending=r['token'] in pending,markers=r['markers'],candidate_cil=cil[r['token']],classification='REVIEW_LEAD_NOT_PROVEN_BUG') for r in marker]))
js(D/'UNIFIED-WORK-QUEUE.json',dict(scope='DEDUPLICATED_REPAIR_VALIDATION_AND_TOOL_COVERAGE_WORK_NOT_BUG_COUNT',candidate_sha256=digest,methods=156,priority_counts=counts,semantic_repair_or_validation_queue_methods=47,reset_throw_context_methods=17,remaining_validator_or_jit_review_methods=92,rows=queue))
with (D/'UNIFIED-WORK-QUEUE.csv').open('w',encoding='utf-8-sig',newline='') as f:
 writer=csv.writer(f);writer.writerow(['priority','token','name','action','frozen','JIT','issue_categories','not_confirmed_bug_count'])
 for r in queue:writer.writerow([r['priority'],r['token'],r['name'],r['required_action'],r['frozen_status'],r['jit_status'],';'.join(r['issue_categories']),True])
for name in ['SUMMARY.json','CONTROLS.json','INPUTS.json','FRESH-TYPE-CENSUS.json','ORIGINAL-CODEGEN-MODULE.json']:(D/name).write_bytes((N/name).read_bytes())
for name in ['census.py','census-v1.py','census-v2.py']:(D/name).write_bytes((O/name).read_bytes())
revisions=[]
for run,source in [('run1','census-v1.py'),('run2','census-v2.py'),('run3','census.py')]:
 inputs=read(O/run/'INPUTS.json');expected=next(r['sha256'] for r in inputs if r['path'].endswith('/census.py'));assert sha((O/source).read_bytes())==expected;revisions.append(dict(run=run,source_snapshot=source,sha256=expected,summary=read(O/run/'SUMMARY.json')))
js(D/'AUDITOR-REVISIONS.json',dict(candidate_unchanged=True,frozen_checkers_unchanged=True,first_run_and_sources_preserved=True,initial_overbroad_tiny_body_leads=154,original_empty_bodies_separately_matched=145,initial_out_of_bounds_native_lookup=dict(managed_rid='0x0600090D',initial_value='0x60004c8',actual_original_method_count=2316,corrected_status='INJECTED_METHOD_OUTSIDE_ORIGINAL_CODEGEN_TABLE',negative_control_added=True),revisions=revisions,note='Run1 was a conservative lead inventory, not a bug-count or promotion. Its ordinary-native table bound and empty-body classification were independently corrected; raw earlier reports remain archived.'))
items=[]
for p in sorted(O.rglob('*')):
 if p.is_file() and '__pycache__' not in p.parts:items.append(('whole-program-census-2026-10-26/'+p.relative_to(O).as_posix(),p.read_bytes()))
pack(D/'WHOLE-CODE-CENSUS-SOURCES-AND-RAW-EVIDENCE.zip',items)
body_lines='\n'.join('| `'+r['token']+'` | `'+r['name'].split(' ',1)[-1]+'` | `'+r['tiny_native_summary']['entry']+'` |' for r in gaps)
text='''# 当前候选全程序集代码普查（2026-10-26）

当前 DLL SHA-256：`'''+digest+'''`。范围是核心游戏程序集全部 2,317 个 MethodDef，其中 2,297 个有方法体。状态：**全量代码普查已完成，发现与验证缺口仍待处理；不等于完整游戏通过**。未修改候选 DLL、冻结检查器、原版输入或正式验收状态。

## 本轮实际执行和复核

- 使用冻结 CilExporter 从当前 DLL 重新导出全部 2,297 个方法；与先前当前候选投影完全一致。
- 使用未修改的冻结类型检查器重新检查全部方法：原始 2,199 PASS /98 FAIL_OR_UNSUPPORTED；核对真实 InterfaceImpl 的 owner、interface 和行号后补充接口事实，得到 2,227 PASS /70 FAIL_OR_UNSUPPORTED。原始失败保留。检查器每方法只报告首条问题，这不是所有错误站点的总数。
- 对全部方法执行分支、switch、异常区间、可达末尾、占位字符串、微小/空方法和直接内部调用图扫描。这一轮未发现分支/EH 结构错误或可达的缺少终结指令末尾。
- 复核先前完整 JIT 准备的 2,297 条记录与当前 DLL 的逐方法原始 IL SHA：2,247 已准备、50 不支持、零进程失败；JIT 记录被复用，未声称重新执行游戏逻辑。
- 当前候选先前的全程序集成员检查仍为零拒绝/零未解析；Linux 与 Apple 各 1,029 个生成源码检查绑定同一 DLL。它们都是部分质量门，不是游戏行为恢复证明。
- 十三个扫描器正负控制覆盖合法常量、错误常量、原版空回调、分支/EH/switch 和原版方法表越界。它们验证扫描器的特定判决，不是游戏测试。

## 新发现的八个方法体缺口

这八个当前 CIL 方法均只有一条 `ret`；原版对应入口均含实际调用。它们不在 R19 本批 100 个修改目标或 35 个待运行对照目标内。SOURCE-GAPS.json 包含实际 CIL、原版入口、全部已解码可达指令字节、调用和外部尾部边界。**需要核对迁移意图并恢复/验证，不能因编译通过就接受为空实现**。其真机症状尚未确定，不能直接归因为黑屏。

| Token | 方法 | 原版 PC 入口 |
|---|---|---|
'''+body_lines+'''

## 全量分类与去重

已用直接原版字节将 145 个空方法和五个简单常量方法的当前方法体形态核对为一致。这不代表它们所在场景、调用者或生命周期全部验证完成。22 个方法含反编译标记：17 个是迭代器 Reset 抛异常形态，单独保留上下文；五个普通方法需要语义复核，其中一个已在 R19 的 35 个待验证方法中。

UNIFIED-WORK-QUEUE.json/.csv 按方法去重合并为 **156 个工作项**，这个数不是 bug 数：

| 优先级 | 数量 | 工作 |
|---|---:|---|
| P0 | 8 | 原版非空、当前为空的方法体缺口 |
| P1 | 35 | R19 已改但待完整运行对照的方法 |
| P2 | 4 | 其他普通方法的未实现指令标记复核（另一个在 P1） |
| P3 | 92 | 其余检查器/JIT 不支持或失败项，需要独立分类和补证据 |
| P4 | 17 | Reset 抛异常上下文保留，不能自动当作游戏故障改掉 |

P0–P2 共 47 个修复、验证或语义复核工作项，也不是 47 个已证明游戏 bug。冻结检查的 70 条、JIT 的 50 条和标记项有重叠；不能把这些数字直接相加。

## 全量检测仍需要哪些运行层

1. **真实 Unity 资产/场景检查**：对固定候选重新扫描所有场景、预制体、丢失脚本和序列化引用、资源路径与 Shader/材质绑定；旧 R8 Editor 结果不能代替当前 R19。
2. **真实场景流程测试**：启动到主菜单，进入关卡，选卡、种植、出怪、攻击、掉落物、暂停/变速、胜负结算、保存/加载、退出重入。记录每条路线实际覆盖的方法、异常和日志，未到达保持未覆盖。
3. **完整 iOS 构建与打包**：对同一输入完成 Unity 导出、Apple 编译、运行时/Objective-C、链接及未签名 IPA 包结构检查。目前只有生成源码预检查通过。
4. **iPad 验收**：检查黑屏、闪烁、声音、触控与持续运行，并用设备日志判断根因。Windows CLR 和 Linux/Mac 编译不能替代 Metal/设备运行。

扫描器能够全覆盖方法清单，但运行测试只能证明已执行的输入和路径；外部 Unity、虚调用、反射、序列化事件、存档状态和设备交互不能由一次静态扫描穷尽。内部调用图只解析直接 MethodDef/MethodSpec 边，12,035 个外部/MemberRef 调用点明确没有在该图中完整解析，不把它们当作不存在。

## 重跑与原始证据

在原工作区运行 `python audit/ipad-startup-2026-10-24/whole-program-census-2026-10-26/census.py 新输出目录名`。每次输出目录必须不存在，避免覆盖历史结果。需要原始 PC、当前 candidate9、真实参考 DLL、现有冻结工具和先前 JIT/成员/接口事实记录。脚本故意固定候选和工具哈希，不能拿旧绿色报告给新候选背书。

ZIP 按原工作区相对布局包含三个完整执行结果、输入清单、全方法状态表、调用图、原始导出、扫描器版本快照和发布脚本。首轮对空方法的分类过宽，并尝试为注入的最终 helper RID 读取超出原版 CodeGenModule 的指针；首次输出未被当成 bug 总数或验收。复核实际 CodeGenModule 得到 2,316 个原版方法槽位，修正并增加越界负控制。AUDITOR-REVISIONS.json 保留此前原始证据、源码哈希及修正过程。

当前 R19 有限运行对照仍是 65 个方法 /18,077 条原版比较；35 个尚待完成。没有新 Unity 场景运行、链接后新 IPA 或 iPad 验收结果，黑屏/闪烁/无声音仍为开放问题。
'''
(D/'README.md').write_bytes(text.encode('utf-8'));manifest(D)
# Add the whole-program debt reference without changing the R19 batch count.
old=R/'Recovery/Startup-R19-Batch100-2026-10-25';progress=read(old/'PROGRESS.json');assert progress['candidate_sha256']==digest and progress['finite_comparison_method_union']==65;progress['whole_program_census']=dict(checkpoint='../Whole-Program-Census-2026-10-26',scanned_bodies=2297,new_empty_body_gaps_outside_r19=8,other_non_reset_marker_methods=5,unified_work_items_not_bug_count=156,full_game_bug_count=None);js(old/'PROGRESS.json',progress);js(Q/'PROGRESS.json',progress)
p=old/'README.md';s=p.read_text(encoding='utf-8');s+='\n## Whole-program debt discovered after this batch\n\nThe [2026-10-26 whole managed-code census](../Whole-Program-Census-2026-10-26/README.md) checks every one of 2,297 bodies and identifies eight empty current methods with nonempty original callers outside this batch. The R19 pending count remains 35; it is not the whole-project remaining bug count. A deduplicated 156-method work queue separates source gaps, pending profiles, semantic markers and validator/Reset context. It does not promote this candidate or change the 100-target construction scope.\n';p.write_bytes(s.encode());manifest(old)
p=R/'README.md';s=p.read_text(encoding='utf-8');marker='Reverse-recovery workspace for the GodsPVZ 1.0.2 Unity IL2CPP builds supplied by the repository owner.\n';assert marker in s;s=s.replace(marker,marker+'\nLatest [whole managed-code census](Recovery/Whole-Program-Census-2026-10-26/README.md) covers all 2,297 bodies. It identifies eight empty CIL bodies with nonempty original callers outside R19, retains five ordinary semantic-marker leads, and separates 156 deduplicated repair/validation/tool-context work items from a game-bug count. R19 remains 65 finite profiles/35 pending; new Editor/IPA/device acceptance is pending.\n',1);p.write_bytes(s.encode())
p=R/'Recovery/STATUS.md';s=p.read_text(encoding='utf-8');marker=next(x+'\n' for x in s.splitlines() if x.startswith('## Latest checkpoint'));s=s.replace(marker,'## Latest checkpoint - 2026-10-26\n\n[Whole managed-code census](Whole-Program-Census-2026-10-26/README.md): all 2,297 method bodies freshly exported/type-checked and scanned for control flow, placeholders and tiny bodies; cached exact JIT IL hashes rechecked. Eight current empty bodies have nonempty original callers outside R19. 145 original-empty and five constant body shapes match direct native bytes. The unified 156-method queue distinguishes eight source gaps, 35 R19 pending profiles, four additional semantic-marker reviews, 92 validator/JIT reviews and seventeen Reset contexts. These are work items, not a bug total. No game DLL, frozen verifier, Unity/IPA/device promotion changed.\n',1);p.write_bytes(s.encode())
print(json.dumps(dict(checkpoint=D.name,methods=2297,new_source_gaps=8,queue_methods=156,priority_counts=counts,raw_archive_bytes=(D/'WHOLE-CODE-CENSUS-SOURCES-AND-RAW-EVIDENCE.zip').stat().st_size,manifest_rows=len(read(D/'MANIFEST.json')),candidate_sha256=digest,ipa=None)))
