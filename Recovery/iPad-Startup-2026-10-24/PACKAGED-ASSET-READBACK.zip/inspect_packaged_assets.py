from pathlib import Path
import sys,zipfile,json,hashlib,collections
work=Path(__file__).resolve().parent
sys.path.insert(0,str(work/'python-deps'))
import UnityPy
ipa=work.parent.parent/'build/output/Bulk401-2026-10-24/GodsPVZ_1.0.2_bulk401_unsigned.ipa'
out=work/'packaged-assets';out.mkdir(exist_ok=True)
report=[]
with zipfile.ZipFile(ipa) as z:
    for name in ['globalgamemanagers','globalgamemanagers.assets','level0','level1','resources.assets','sharedassets0.assets','sharedassets1.assets']:
        data=z.read('Payload/GodsPVZ.app/Data/'+name)
        env=UnityPy.load(data);counts=collections.Counter();scripts=[];selected=[];errors=[]
        for obj in env.objects:
            counts[obj.type.name]+=1
            try:
                if obj.type.name=='MonoScript':
                    tree=obj.read_typetree();scripts.append(dict(path_id=obj.path_id,**{k:v for k,v in tree.items() if k in ('m_Name','m_ClassName','m_Namespace','m_AssemblyName')}))
                if name in ('level0','level1') or obj.type.name in ('PlayerSettings','BuildSettings','MonoManager','GraphicsSettings','QualitySettings'):
                    tree=obj.read_typetree()
                    if obj.type.name=='PlayerSettings':tree={k:v for k,v in tree.items() if any(s.lower() in k.lower() for s in ['splash','screen','stereo','vr','orientation','resolution','ios'])}
                    selected.append(dict(path_id=obj.path_id,type=obj.type.name,tree=tree))
            except Exception as e:errors.append(dict(path_id=obj.path_id,type=obj.type.name,error=str(e)))
        entry=dict(file=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),objects=dict(counts),scripts=scripts,selected=selected,read_errors=errors)
        (out/(name+'.json')).write_text(json.dumps(entry,indent=2,ensure_ascii=False,default=repr)+'\n','utf-8')
        report.append({k:v for k,v in entry.items() if k not in ('scripts','selected')})
        print(json.dumps(report[-1],ensure_ascii=True),flush=True)
(out/'SUMMARY.json').write_text(json.dumps(report,indent=2)+'\n','utf-8')
