"""Preserve the completed scoped startup failure; never promote a candidate."""
from pathlib import Path
import collections
import hashlib
import json
import re
import subprocess
import zipfile

W = Path(__file__).resolve().parent
R = W.parent / "repo-native113"
E = W / "asset-audit-40070605799"
D = R / "Recovery/iPad-Startup-2026-10-24"
G = R / "Recovery/Bulk401-Generic-Repair-2026-10-24"

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write_preserving_eol(path, text):
    relative = path.relative_to(R).as_posix()
    prior = subprocess.run(["git", "show", "HEAD:" + relative], cwd=R, capture_output=True)
    if prior.returncode == 0 and b"\r\n" in prior.stdout:
        text = text.replace("\r\n", "\n").replace("\n", "\r\n")
    path.write_bytes(text.encode("utf-8"))

def save(path, value):
    write_preserving_eol(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")

def digest(data):
    return hashlib.sha256(data).hexdigest()

run = json.loads(subprocess.check_output([
    r"C:\Program Files\GitHub CLI\gh.exe", "run", "view", "40070605799", "--repo",
    "lyiming710-cloud/GodsPVZ-iOS", "--json", "databaseId,headSha,status,conclusion,url,updatedAt,jobs"
]))
assert run["headSha"] == "fed0d3cecdafbe07c4010f1c8afe7d46ba2c440a"
assert run["status"] == "completed" and run["conclusion"] == "failure"
save(D / "RUN-40070605799.json", run)

a = load(E / "startup-asset-audit.json")
p = load(E / "startup-play-probe.json")
c = load(W / "READ-ONLY-STARTUP-CIL.json")
assert a["pass"] is True and p["pass"] is False
assert c["input_sha256"] == "6de4db6c94b80a43876aea060b573ed60c1fa7170cff485103d2c808b94762ae"
targets = {m["token"] for m in load(W.parent / "bulk400-generic-repair-2026-10-24/all-targets.json")["methods"]}
sites = c["private_field_sites"]
body_tokens = {x["token"] for x in sites}
logs = (E / "startup-play-probe.log").read_text(encoding="utf-8", errors="replace").splitlines()
exceptions = collections.Counter(l for l in logs if re.match(r"(?:NullReference|FieldAccess|InvalidProgram|MissingReference|MissingMethod|TypeLoad)Exception:", l))
summary = {
    "run_id": 40070605799,
    "source_commit": run["headSha"],
    "candidate_sha256": c["input_sha256"],
    "state": "ASSET_BINDING_PASS_EDITOR_STARTUP_FAIL_NO_NEW_IPA",
    "asset_check": {
        **{k: a[k] for k in ("pass", "plugin_scripts", "resolved_plugin_scripts", "validated_game_script_references", "prefab_assets", "missing_components", "game_start_component", "game_start_prefab", "board_start_component", "core_blit_keyword", "splash_unity_logo_canonical", "splash_game_logo_preserved")},
        "official_shader_bindings": len(a["official_shader_bindings"]),
        "fonts_checked": len(a["fonts"]),
        "restored_original_empty_atlases": len(a["restored_original_empty_atlases"]),
        "unresolved_custom_dummy_shaders": a["unresolved_custom_dummy_shaders"],
    },
    "editor_play_probe": {
        **{k: p[k] for k in ("scope", "pass", "frames", "active_scene", "active_canvases", "main_ui_components", "device_execution", "pixel_equivalence", "audio_scope")},
        "distinct_captured_traces": [{"count_in_capped_report": n, "trace": t} for t, n in collections.Counter(p["errors"]).items()],
        "report_error_cap": 50,
        "full_log_exception_header_counts": dict(exceptions),
        "exception_counts_are_occurrences_not_distinct_method_defects": True,
    },
    "broader_private_field_census": {
        "scope": c["scope"],
        "methods_with_body_scanned": c["methods_with_body"],
        "sites": len(sites),
        "methods": len(body_tokens),
        "private_fields": len({x["field_token"] for x in sites}),
        "prior_target_count": len(targets),
        "intersecting_prior_target_methods": len(body_tokens & targets),
        "unresolved_own_field_references": len(c["unresolved"]),
        "status": "STATIC_FINDINGS_NOT_56_OBSERVED_RUNTIME_FAILURES",
        "all_possible_access_defects_exhaustively_audited": False,
    },
    "serialization_lead": {
        "status": "STATIC_METADATA_AND_PREFAB_MISMATCH_CAUSAL_RUNTIME_BINDING_NOT_YET_INSTRUMENTED",
        "prefab": "Assets/Resources/prefabs/ui/MainMenu.prefab",
        "component_file_id": "114739268104783211",
        "script_file_id": "-1435929971",
        "field": "TMPro.TMP_Text TextLink::TMP_Text",
        "serialized_reference_file_id": "114249237965167194",
        "candidate_field_token": "0x040008E1",
        "candidate_access": "Private",
        "candidate_custom_attributes": [],
        "reference_rules": "https://docs.unity3d.com/2022.3/Documentation/Manual/script-Serialization.html",
    },
    "device_startup": "PREVIOUS_IPA_FAILED_USER_OBSERVATION_NO_REPAIRED_DEVICE_RESULT",
    "new_unity_export": "NOT_EXECUTED_BLOCKED_BY_PLAY_PROBE",
    "new_xcode_and_ipa": "NOT_EXECUTED_BLOCKED_BY_PLAY_PROBE",
    "candidate_changed": False,
    "next_work": [
        "Bind restored serialization metadata to original PC evidence and audit other serialized game fields.",
        "Classify cross-type private field accesses and restore source-equivalent legal access from native evidence without widening field visibility globally.",
        "Restore the two original custom shaders from preserved source/state evidence and verify their rendering separately.",
        "Require error-free actual startup before another Unity export, Apple build and device retest."
    ],
}
save(D / "STARTUP-READBACK-40070605799.json", summary)

files = {}
for name in (
    "PROVENANCE.json", "HELPER-COMPILATION.json", "startup-plugin-transition.json",
    "official-tmp-shader-sources.json", "startup-asset-audit.json", "startup-asset-audit.log",
    "startup-asset-audit-exit.txt", "startup-play-probe.json", "startup-play-probe.log",
    "startup-play-probe-exit.txt", "test-dll-after-reimport.sha256",
):
    files["unity/" + name] = (E / name).read_bytes()
files["read-only/READ-ONLY-STARTUP-CIL.json"] = (W / "READ-ONLY-STARTUP-CIL.json").read_bytes()
for name in ("Program.cs", "Inspect.csproj"):
    files["read-only/" + name] = (W / "read-only-cil" / name).read_bytes()
files["read-only/save_startup_readback_40070605799.py"] = Path(__file__).read_bytes()
files["SUMMARY.json"] = (D / "STARTUP-READBACK-40070605799.json").read_bytes()
archive_manifest = [{"path": n, "bytes": len(b), "sha256": digest(b)} for n, b in sorted(files.items())]
files["ARCHIVE-MANIFEST.json"] = (json.dumps(archive_manifest, indent=2) + "\n").encode()
archive = D / "REAL-UNITY-STARTUP-40070605799.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as z:
    for name, data in sorted(files.items()):
        entry = zipfile.ZipInfo(name, (2026, 10, 24, 0, 0, 0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(entry, data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in archive_manifest:
        data = z.read(row["path"])
        assert len(data) == row["bytes"] and digest(data) == row["sha256"]

current = load(G / "CURRENT-RESULT.json")
current["device_runtime"].update({
    "startup_repair": "ASSET_BINDING_PASS_EDITOR_STARTUP_FAIL_NO_NEW_IPA",
    "latest_run": 40070605799,
    "latest_run_conclusion": "failure",
    "latest_source": run["headSha"],
    "fixed_ipa": None,
    "readback": "../iPad-Startup-2026-10-24/STARTUP-READBACK-40070605799.json",
    "editor_play_frames": p["frames"],
    "editor_main_ui_components": p["main_ui_components"],
    "editor_startup_distinct_captured_error_traces": len(collections.Counter(p["errors"])),
})
save(G / "CURRENT-RESULT.json", current)

readme = (D / "README.md").read_text(encoding="utf-8")
blocks = readme.split("\n\n")
seen = set()
deduped = []
for block in blocks:
    if block.strip() and block in seen:
        continue
    seen.add(block)
    deduped.append(block)
readme = "\n\n".join(deduped)
readme = readme.replace("It is running; no repaired IPA or device success is claimed yet.", "It completed with asset binding PASS and actual Editor startup FAIL; no new export or repaired IPA was produced.")
addition = """

**Completed startup gate (40070605799):** the asset check passed with 148/148 scripts resolved, 263 game-script references validated, 186 prefabs with zero missing components, 40 official shader mappings, 21 valid font assets, six restored original empty dynamic atlases, canonical Unity splash identity and preserved game logo. These are source/import checks, not GPU or device acceptance.

Normal Editor Play Mode created one MainUIController and two active Canvases and advanced 1,702 frames in MainMenu. It failed on three distinct captured exception traces: Administrator.Start NullReferenceException; TextLink.Update -> TMP_TextUtilities.FindIntersectingLink NullReferenceException; and Administrator.Update -> GlobalStaticVars.IsOnBoard FieldAccessException for BoardManager's private Instance backing field. The 50-entry JSON is capped; the full log preserves 1 Administrator.Start exception, 1,702 TMP exceptions and 1,702 field-access exceptions. These are repeated occurrences, not 3,405 separate method bugs. Linux Editor behavior has not been proved equivalent to the installed iPad build.

A read-only broader census of all 2,297 methods with bodies found 143 cross-type private-field access instructions in 56 methods involving 29 fields. All 56 are outside the earlier 401-target audit. This is a bounded structural finding, not 56 observed runtime failures or an exhaustive access/semantic audit. Source and exact sites are archived; the DLL is unchanged. MainMenu.prefab also contains a TextLink.TMP_Text reference while that private candidate field has no SerializeField attribute. This is a serialization restoration lead requiring original input binding and runtime confirmation, not authorization to make fields public or inject references at runtime.

Two custom shaders remain dummy/unproven: Shader Graphs/Brightness and Unlit/GameUnitShader. Gameplay, level transitions, saves, touch input, physical audio, Metal rendering and repaired iPad startup remain unverified. The Play Mode failure stopped Unity export and Xcode/IPA creation. See STARTUP-READBACK-40070605799.json and REAL-UNITY-STARTUP-40070605799.zip for actual scoped results and raw logs.
"""
if "**Completed startup gate (40070605799):**" not in readme:
    readme = readme.rstrip() + addition
write_preserving_eol(D / "README.md", readme.rstrip() + "\n")

for directory in (D, G):
    manifest = []
    for path in sorted(directory.rglob("*")):
        if path.is_file() and path.name != "MANIFEST.json":
            data = path.read_bytes()
            manifest.append({"path": path.relative_to(directory).as_posix(), "bytes": len(data), "sha256": digest(data)})
    save(directory / "MANIFEST.json", manifest)
print(json.dumps({"run": run["databaseId"], "state": summary["state"], "archived_files": len(files), "archive_bytes": archive.stat().st_size, "archive_sha256": digest(archive.read_bytes()), "candidate_changed": False}))
