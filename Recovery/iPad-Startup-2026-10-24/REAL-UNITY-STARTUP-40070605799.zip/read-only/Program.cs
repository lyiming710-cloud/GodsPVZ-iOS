using Mono.Cecil;
using Mono.Cecil.Cil;
using System.Text.Json;
using System.Security.Cryptography;

// Read-only census. It neither rewrites the input nor promotes any method.
using var module = ModuleDefinition.ReadModule(args[0]);
static IEnumerable<TypeDefinition> Walk(IEnumerable<TypeDefinition> roots) {
    foreach (var type in roots) { yield return type; foreach (var nested in Walk(type.NestedTypes)) yield return nested; }
}
static TypeDefinition Outer(TypeDefinition type) { while (type.DeclaringType != null) type = type.DeclaringType; return type; }
var types = Walk(module.Types).ToArray();
var methods = types.SelectMany(t => t.Methods).Where(m => m.HasBody).ToArray();
var wanted = new HashSet<string> { "Administrator", "GlobalStaticVars", "TextLink", "BoardManager" };
var dumps = new List<object>();
var privateUses = new List<object>();
var unresolved = new List<object>();
foreach (var m in methods) {
    if (wanted.Contains(m.DeclaringType.FullName) && (m.Name is "Start" or "Update" or "Awake" or "IsOnBoard" or "get_Instance" or ".ctor"))
        dumps.Add(new { token = $"0x{m.MetadataToken.ToInt32():X8}", method = m.FullName, locals = m.Body.Variables.Select(v => new {v.Index,type=v.VariableType.FullName}), instructions = m.Body.Instructions.Select(i => new { offset=$"IL_{i.Offset:X4}", op=i.OpCode.Name, operand=i.Operand?.ToString() }) });
    foreach (var i in m.Body.Instructions) {
        if (i.Operand is not FieldReference f) continue;
        if (f.DeclaringType.Scope != module && f.DeclaringType.Scope?.Name != module.Name) continue;
        FieldDefinition? d;
        try { d = f.Resolve(); } catch (Exception e) { unresolved.Add(new { method=m.FullName, offset=i.Offset, field=f.FullName, error=e.Message }); continue; }
        if (d == null || !d.IsPrivate || Outer(d.DeclaringType) == Outer(m.DeclaringType)) continue;
        privateUses.Add(new { token=$"0x{m.MetadataToken.ToInt32():X8}", method=m.FullName, offset=$"IL_{i.Offset:X4}", op=i.OpCode.Name, field=f.FullName, field_token=$"0x{d.MetadataToken.ToInt32():X8}" });
    }
}
var report = new { scope="READ_ONLY_CIL_INACCESSIBLE_PRIVATE_FIELD_CENSUS_ONLY", input_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(), methods_with_body=methods.Length, custom_attribute_count=types.Sum(t=>t.CustomAttributes.Count+t.Fields.Sum(f=>f.CustomAttributes.Count)+t.Methods.Sum(m=>m.CustomAttributes.Count)), fields_of_selected_types=types.Where(t=>wanted.Contains(t.FullName)).Select(t=>new {type=t.FullName, fields=t.Fields.Select(f=>new {f.Name,type=f.FieldType.FullName,attributes=f.Attributes.ToString(),custom_attributes=f.CustomAttributes.Select(a=>a.AttributeType.FullName),token=$"0x{f.MetadataToken.ToInt32():X8}"})}), dumps, private_field_sites=privateUses, unresolved };
File.WriteAllText(args[1], JsonSerializer.Serialize(report, new JsonSerializerOptions { WriteIndented=true }));
Console.WriteLine(JsonSerializer.Serialize(new { report.input_sha256, report.methods_with_body, selected_methods=dumps.Count, inaccessible_private_field_sites=privateUses.Count, unresolved=unresolved.Count }));
