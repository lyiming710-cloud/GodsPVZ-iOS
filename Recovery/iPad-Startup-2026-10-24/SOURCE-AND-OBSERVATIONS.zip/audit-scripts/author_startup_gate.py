from pathlib import Path
import shutil

work=Path(__file__).resolve().parent;repo=work.parent/'repo-native113'
old=repo/'Recovery/Bulk389-Qualification-2026-10-23/ios-support'
new=repo/'Recovery/iPad-Startup-2026-10-24/ios-support'
editor=new/'Assets/Editor';editor.mkdir(parents=True,exist_ok=True)
shutil.copyfile(old/'Assets/Editor/GodsPVZPackageReferenceMigrator.cs',editor/'GodsPVZPackageReferenceMigrator.cs')
builder=(old/'Assets/Editor/GodsPVZIOSBuild.cs').read_text('utf-8')
builder=builder.replace('if (report.summary.result != BuildResult.Succeeded)', 'if (report.summary.result != BuildResult.Succeeded || report.summary.totalErrors != 0)')
(editor/'GodsPVZIOSBuild.cs').write_text(builder,'utf-8')
preflight=(repo/'scripts/actions/preflight_bulk389_editor.py').read_text('utf-8')
assert "{'GodsPVZIOSBuild.cs', 'GodsPVZPackageReferenceMigrator.cs'}" in preflight
preflight=preflight.replace("{'GodsPVZIOSBuild.cs', 'GodsPVZPackageReferenceMigrator.cs'}", "{'GodsPVZIOSBuild.cs', 'GodsPVZPackageReferenceMigrator.cs', 'GodsPVZStartupAudit.cs'}")
(repo/'scripts/actions/preflight_bulk401_startup_editor.py').write_text(preflight,'utf-8')
helper=(repo/'.github/workflows/bulk389-editor-helper-preflight.yml').read_text('utf-8')
helper=helper.replace('Bulk389 exact Editor helper preflight', 'Bulk401 startup exact Editor helper preflight')
helper=helper.replace('scripts/actions/preflight_bulk389_editor.py','scripts/actions/preflight_bulk401_startup_editor.py')
helper=helper.replace('Recovery/Bulk389-Qualification-2026-10-23/ios-support','Recovery/iPad-Startup-2026-10-24/ios-support')
(repo/'.github/workflows/bulk401-startup-editor-preflight.yml').write_text(helper,'utf-8')
workflow=(repo/'.github/workflows/bulk389-real-ios-ipa.yml').read_text('utf-8')
workflow=workflow.replace('name: Bulk401 REAL Unity Xcode unsigned IPA diagnostic gate','name: Bulk401 iPad startup binding and rendering gate',1)
workflow=workflow.replace('  workflow_dispatch:\n','''  workflow_dispatch:
    inputs:
      audit_only:
        description: Repair work-copy references and audit scenes without exporting another IPA
        type: boolean
        default: true
        required: true
  push:
    branches: [verify/codex-bulk250-r2-takeover-2026-10-23]
    paths: [.github/workflows/bulk401-startup-runtime-gate.yml]
''',1)
workflow=workflow.replace('group: bulk401-real-ios-ipa','group: bulk401-startup-real-ios-ipa')
workflow=workflow.replace('./.github/workflows/bulk389-editor-helper-preflight.yml','./.github/workflows/bulk401-startup-editor-preflight.yml')
workflow=workflow.replace('scripts/actions/preflight_bulk389_editor.py','scripts/actions/preflight_bulk401_startup_editor.py')
oldcp='cp "$GITHUB_WORKSPACE/Recovery/Bulk389-Qualification-2026-10-23/ios-support/Assets/Editor/GodsPVZIOSBuild.cs" "$PROJECT/Assets/Editor/"'
newcp='cp "$GITHUB_WORKSPACE/Recovery/iPad-Startup-2026-10-24/ios-support/Assets/Editor/GodsPVZIOSBuild.cs" "$PROJECT/Assets/Editor/"\n          cp "$GITHUB_WORKSPACE/Recovery/iPad-Startup-2026-10-24/ios-support/Assets/Editor/GodsPVZStartupAudit.cs" "$PROJECT/Assets/Editor/"'
assert workflow.count(oldcp)==1
workflow=workflow.replace(oldcp,newcp)
at=workflow.index('      - name: Reimport fixed candidate')
workflow=workflow[:at]+'''      - name: Align unchanged plugin filename with its assembly identity and preserve its GUID
        shell: bash
        run: |
          set -euo pipefail
          OUT="$RUNNER_TEMP/stage9-bulk401-ios"
          PROJECT="$(cat "$OUT/project-path.txt")"
          python3 scripts/actions/prepare_bulk401_startup.py --project "$PROJECT" --evidence "$OUT/evidence"

'''+workflow[at:]
at=workflow.index('      - name: Reimport fixed candidate')
workflow=workflow[:at]+workflow[at:].replace('Assets/Plugins/Assembly-CSharp.dll','Assets/Plugins/GodsPVZRuntime1.dll')
at=workflow.index('      - name: Export unsigned iOS Xcode project')
workflow=workflow[:at]+'''      - name: Repair official shader bindings and audit all startup scenes and prefabs
        shell: bash
        env:
          GODSPVZ_STARTUP_EVIDENCE: ${{ runner.temp }}/stage9-bulk401-ios/evidence
        run: |
          set -euo pipefail
          OUT="$RUNNER_TEMP/stage9-bulk401-ios"
          UNITY="$(cat "$OUT/unity-path.txt")"
          PROJECT="$(cat "$OUT/project-path.txt")"
          set +e
          "$UNITY" -batchmode -nographics -quit -projectPath "$PROJECT" -executeMethod GodsPVZStartupAudit.Run -logFile "$OUT/evidence/startup-asset-audit.log"
          RC=$?
          set -e
          echo "$RC" > "$OUT/evidence/startup-asset-audit-exit.txt"
          [ "$RC" -eq 0 ]
          python3 - "$OUT/evidence/startup-asset-audit.json" <<'PY'
          import json,sys
          data=json.load(open(sys.argv[1]))
          assert data['pass'] and data['missing_components']==0
          assert data['game_start_component'] and data['game_start_prefab'] and data['board_start_component']
          assert data['core_blit_keyword']
          PY

'''+workflow[at:]
for label in ['Export unsigned iOS Xcode project with bulk401 candidate','Audit Xcode and IL2CPP export']:
    needle='      - name: '+label+'\n';assert workflow.count(needle)==1
    workflow=workflow.replace(needle,needle+"        if: github.event_name == 'workflow_dispatch' && !inputs.audit_only\n")
workflow=workflow.replace("if: always() && steps.xcode_audit.outcome == 'success'", "if: always() && steps.xcode_audit.outcome == 'success'")
workflow=workflow.replace('name: Stage9-bulk401-REAL-UNITY-IOS-EVIDENCE','name: Bulk401-STARTUP-UNITY-EVIDENCE')
workflow=workflow.replace('  build_ipa:\n    needs: export','  build_ipa:\n    if: github.event_name == \'workflow_dispatch\' && !inputs.audit_only\n    needs: export')
(repo/'.github/workflows/bulk401-startup-runtime-gate.yml').write_text(workflow,'utf-8')
# The source-only extractor has completed. No repeat run on documentation pushes.
path=repo/'.github/workflows/bulk401-startup-asset-audit.yml'
source=path.read_text('utf-8');source=source.replace('  push:\n    branches: [verify/codex-bulk250-r2-takeover-2026-10-23]\n    paths: [.github/workflows/bulk401-startup-asset-audit.yml]\n','');path.write_text(source,'utf-8')
print('STARTUP_GATE_SOURCE_WRITTEN audit-only by default, same candidate bytes')
