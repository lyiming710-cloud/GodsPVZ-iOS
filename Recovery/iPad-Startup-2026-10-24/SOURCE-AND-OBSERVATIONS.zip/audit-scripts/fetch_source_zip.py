from pathlib import Path
import subprocess,zipfile,hashlib,json
work=Path(__file__).resolve().parent
gh=r'C:\Program Files\GitHub CLI\gh.exe'
artifact=json.loads(subprocess.check_output([gh,'api','repos/lyiming710-cloud/GodsPVZ-iOS/actions/artifacts/12550076650']))
target=work/'R3-STARTUP-TEXT-40067634181.zip'
with target.open('wb') as f:
    subprocess.run([gh,'api','repos/lyiming710-cloud/GodsPVZ-iOS/actions/artifacts/12550076650/zip'],stdout=f,check=True)
if artifact.get('digest'):assert 'sha256:'+hashlib.sha256(target.read_bytes()).hexdigest()==artifact['digest']
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    names=z.namelist();assert len(names)==len(set(names))
    print(json.dumps(dict(bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),entries=len(names))))
    for name in names:
        if name.endswith(('ProjectSettings.asset','MainMenu.unity','Board.unity','GameStart.asset','GameStart.cs','BoardStart.asset','Assembly-CSharp.dll.meta')):
            data=z.read(name);print(name,len(data));print(data.decode('utf-8',errors='replace')[:1400])
