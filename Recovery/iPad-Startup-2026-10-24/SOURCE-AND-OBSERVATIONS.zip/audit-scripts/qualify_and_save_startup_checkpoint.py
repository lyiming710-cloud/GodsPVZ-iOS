from pathlib import Path
import hashlib,json,sys,tempfile,zipfile,shutil,re,collections,datetime
work=Path(__file__).resolve().parent;repo=work.parent/'repo-native113'
sys.path.insert(0,str(repo/'scripts/actions'))
from prepare_bulk401_startup import prepare,CANDIDATE,GUID
out=repo/'Recovery/iPad-Startup-2026-10-24';out.mkdir(exist_ok=True)
candidate=work.parent/'bulk400-generic-repair-2026-10-24/candidates/candidate1.dll'
assert hashlib.sha256(candidate.read_bytes()).hexdigest()==CANDIDATE
checks=[]
with tempfile.TemporaryDirectory(prefix='godspvz-startup-') as temporary:
    base=Path(temporary)
    def fixture(name):
        root=base/name;(root/'Assets/Plugins').mkdir(parents=True);(root/'ProjectSettings').mkdir()
        (root/'ProjectSettings/ProjectVersion.txt').write_text('m_EditorVersion: 2022.3.44f1c1\n')
        shutil.copyfile(candidate,root/'Assets/Plugins/Assembly-CSharp.dll')
        (root/'Assets/Plugins/Assembly-CSharp.dll.meta').write_text('fileFormatVersion: 2\nguid: '+GUID+'\n')
        return root
    root=fixture('positive');before=(root/'Assets/Plugins/Assembly-CSharp.dll.meta').read_bytes()
    report=prepare(root,base/'e-positive')
    assert (root/'Assets/Plugins/GodsPVZRuntime1.dll.meta').read_bytes()==before
    assert hashlib.sha256((root/'Assets/Plugins/GodsPVZRuntime1.dll').read_bytes()).hexdigest()==CANDIDATE
    assert not (root/'Assets/Plugins/Assembly-CSharp.dll').exists()
    checks.append('aligned_name_identical_dll_identical_meta_same_guid')
    def reject(name,fn):
        try:fn()
        except ValueError:checks.append(name)
        else:raise AssertionError('False acceptance: '+name)
    reject('second_application_rejected',lambda:prepare(root,base/'e-twice'))
    root=fixture('bad-hash');(root/'Assets/Plugins/Assembly-CSharp.dll').write_bytes(b'wrong')
    reject('wrong_candidate_rejected',lambda:prepare(root,base/'e-hash'))
    assert not (root/'Assets/Plugins/GodsPVZRuntime1.dll').exists()
    root=fixture('bad-guid');(root/'Assets/Plugins/Assembly-CSharp.dll.meta').write_text('guid: '+'0'*32)
    reject('wrong_guid_rejected',lambda:prepare(root,base/'e-guid'))
    root=fixture('existing-target');(root/'Assets/Plugins/GodsPVZRuntime1.dll').write_bytes(b'existing')
    reject('existing_destination_preserved',lambda:prepare(root,base/'e-existing'))
    assert (root/'Assets/Plugins/GodsPVZRuntime1.dll').read_bytes()==b'existing'
    reject('non_project_rejected',lambda:prepare(base,base/'e-non-project'))
def dump(path,data):path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n','utf-8')
dump(out/'PLUGIN-TRANSITION-CONTROLS.json',dict(scope='PORTABLE_FILENAME_GUID_AND_DLL_BYTE_CONTROLS_ONLY',checks=checks,passed=len(checks),unity_resolution='NOT_YET_TESTED'))
logs=work.parent/'bulk400-generic-repair-2026-10-24/real-export-40016440758/evidence'
text=(logs/'ios-export.log').read_text('utf-8',errors='replace')
missing=[dict(line=i+1,text=line) for i,line in enumerate(text.splitlines()) if line.startswith('Script attached to ') and 'is missing or no valid script' in line]
errors=[dict(line=i+1,text=line) for i,line in enumerate(text.splitlines()) if line.startswith(('Local keyword ','MissingReferenceException:','GodsPVZ iOS export summary:'))]
dump(out/'ORIGINAL-EXPORT-STARTUP-ERRORS.json',dict(scope='PRESERVED_ORIGINAL_EXPORT_LOG_FINDINGS',
    original_log_sha256=hashlib.sha256((logs/'ios-export.log').read_bytes()).hexdigest(),missing_script_messages=len(missing),missing=missing,error_markers=errors))
with zipfile.ZipFile(out/'PACKAGED-ASSET-READBACK.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted((work/'packaged-assets').glob('*.json')):z.write(p,p.name)
    z.write(work/'inspect_packaged_assets.py','inspect_packaged_assets.py')
scripts=json.loads((work/'packaged-assets/globalgamemanagers.assets.json').read_text('utf-8'))['scripts']
old_scripts=[s for s in scripts if s['m_AssemblyName']=='Assembly-CSharp.dll']
dump(out/'DEVICE-OBSERVATION.json',dict(scope='USER_REPORTED_DEVICE_FAILURE_NOT_DEVICE_LOG_CAPTURE',
    device='iPad Pro 2025, M5',os='iPadOS 27.0',hardware_os_source='USER_PROVIDED_NOT_INDEPENDENTLY_VERIFIED',
    delivered_ipa_sha256='13cd203c01cddca272e5245761168b6f383701102ef1442d4a8843186a674013',
    installed_signed_ipa_sha256='NOT_PROVIDED',app_returns_to_home=False,splash_repeats=False,audio_heard=False,
    observed='Splash finishes, black screen for one to two minutes, then continual flickering',
    original_assembly_internal_name='GodsPVZRuntime1',plugin_filename='Assembly-CSharp.dll',
    packaged_scripts_with_old_assembly_name=len(old_scripts),affected_script_definitions=old_scripts,
    startup_fix_state='SOURCE_PREPARED_REQUIRES_REAL_UNITY_AUDIT',device_retest='PENDING'))
with zipfile.ZipFile(work/'R3-STARTUP-TEXT-40067634181.zip') as z:
    for name in ['INPUT-IDENTITY.json','TEXT-MANIFEST.json']:
        (out/name).write_bytes(z.read(name))
    shader_names=[]
    for name in z.namelist():
        if name.startswith('project-text/Assets/Shader/') and name.endswith('.shader'):
            data=z.read(name);decl=re.search(rb'Shader\s+"([^"]+)"',data)
            shader_names.append(dict(path=name,shader=decl.group(1).decode() if decl else None,dummy=b'DummyShaderTextExporter' in data,sha256=hashlib.sha256(data).hexdigest()))
    dump(out/'R3-SHADER-INVENTORY.json',shader_names)
    raw=z.read('project-text/Assets/Shader/Hidden_Universal_CoreBlit.shader')
    (out/'ORIGINAL-DUMMY-COREBLIT.shader.txt').write_bytes(raw)
with zipfile.ZipFile(out/'SOURCE-AND-OBSERVATIONS.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(work.glob('*.py')):z.write(p,'audit-scripts/'+p.name)
    z.write(repo/'scripts/actions/prepare_bulk401_startup.py','scripts/actions/prepare_bulk401_startup.py')
    for p in sorted((out/'ios-support').rglob('*.cs')):z.write(p,p.relative_to(out).as_posix())
(out/'.gitattributes').write_bytes(b'*.json -text\n*.md -text\n*.zip -text\n*.txt -text\n')
(out/'README.md').write_text('''# iPad startup failure investigation - 2026-10-24

The delivered Bulk401 IPA is a real unsigned arm64 build, but the user reports a black screen followed by flickering without process exit, repeated splash or audio on an iPad Pro M5 / iPadOS 27.0 (user-provided hardware/OS). Device runtime acceptance has failed. No fix is claimed on-device yet.

The original export log contains missing-script warnings for GameStart, BoardStart and many prefabs, plus a dummy CoreBlit keyword error and a TMP atlas MissingReferenceException. Its BuildReport returned Succeeded with 6 errors and 382 warnings. Earlier delivery acceptance checked compilation/linking and package bytes but missed the scene-binding failures. Original evidence and counts remain preserved.

Actual IPA readback found 148 MonoScript definitions naming Assembly-CSharp.dll while the unchanged candidate's internal assembly identity is GodsPVZRuntime1. R3 scenes reference the plugin GUID 60b84a767c46ced9aacc93f38da4d2f3 with original class local IDs. The work-copy fix renames the DLL and its .meta to GodsPVZRuntime1.dll, preserving both files byte-for-byte and all serialized GUID/fileID references. Six portable controls verify preservation and reject bad input/destination states; real Unity GetClass, scene and prefab checks are still required.

All 42 restored asset Shader files are marked DummyShaderTextExporter. CoreBlit returns constant white and lacks the real copy passes/keywords. The new Editor helper rebinds exact shader-name matches to non-dummy shaders from the pinned packages and official TMP Essential Resources, keeps original font atlases, then opens both scenes and checks every prefab for missing scripts. Unmatched custom shaders are reported explicitly rather than claimed restored. The game DLL and frozen CIL validators are unchanged.

The new iOS exporter rejects nonzero BuildReport.totalErrors even when result is Succeeded. The startup workflow defaults to audit-only, compiles all three real helper sources against the exact 210-reference Editor set before acquiring a seat, and does not export an IPA during its initial audit. Full export remains a separate manual operation after evidence readback. This audit does not establish gameplay or device equivalence.

The source text came from exact R3 through read-only run 40067634181. Its artifact is bound by INPUT-IDENTITY.json/TEXT-MANIFEST.json. Local full-archive transfer ended with unexpected EOF; extracting the Linux text artifact directly on Windows hit case-colliding names, so the verified ZIP was read without overwriting colliding paths. Those transport limitations did not become game or tool PASS results.
''','utf-8')
prior=repo/'Recovery/Bulk401-Generic-Repair-2026-10-24'
current=json.loads((prior/'CURRENT-RESULT.json').read_text('utf-8'))
current.update(state='UNSIGNED_IPA_DELIVERED_DEVICE_STARTUP_FAILURE_REPORTED',device_runtime=dict(status='FAIL_USER_OBSERVATION',details='../iPad-Startup-2026-10-24/DEVICE-OBSERVATION.json',startup_repair='SOURCE_PREPARED_REAL_EDITOR_AUDIT_PENDING'))
current['ipa']['device_execution']='USER_OBSERVED_BLACK_SCREEN_AND_FLICKERING'
dump(prior/'CURRENT-RESULT.json',current)
readme=(prior/'README.md').read_text('utf-8')
notice='\n**Device update:** the user reports black screen/flickering after splash. Compilation/package delivery remains verified, but startup runtime acceptance has failed. See [the startup investigation](../iPad-Startup-2026-10-24/README.md); no corrected IPA or on-device fix is claimed yet.\n'
if '**Device update:**' not in readme:readme=readme.replace('\n\n','\n'+notice+'\n',1)
(prior/'README.md').write_text(readme,'utf-8')
for folder in [out,prior]:
    entries=[dict(path=p.relative_to(folder).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(folder.rglob('*')) if p.is_file() and p.name!='MANIFEST.json']
    dump(folder/'MANIFEST.json',entries)
print(json.dumps(dict(plugin_transition_controls=len(checks),missing_script_log_messages=len(missing),packaged_old_name_scripts=len(old_scripts),shader_dummies=sum(x['dummy'] for x in shader_names),candidate_changed=False)))
