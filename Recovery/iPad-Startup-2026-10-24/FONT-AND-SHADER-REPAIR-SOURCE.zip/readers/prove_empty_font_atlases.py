from pathlib import Path
import sys,zipfile,json,re,hashlib,gc,struct
work=Path(__file__).resolve().parent;sys.path.insert(0,str(work/'python-deps'))
import UnityPy
fonts=['Anton','Bangers','Electronic Highway Sign','LiberationSans SDF - Fallback','Oswald Bold','Roboto-Bold']
rows=[]
with zipfile.ZipFile(work/'R3-STARTUP-TEXT-40067634181.zip') as z:
    names=z.namelist()
    for font in fonts:
        path='Assets/Resources/fonts & materials/'+font+('' if font.endswith('Fallback') else ' SDF')+'.asset'
        data=z.read('project-text/'+path);text=data.decode('utf-8-sig')
        assert 'm_AtlasPopulationMode: 1' in text and 'm_GlyphTable: []' in text and 'm_CharacterTable: []' in text
        m=re.search(r'm_AtlasTextures:\s*- \{fileID: 2800000, guid: ([0-9a-f]{32}), type: 3\}',text);assert m,path
        guid=m.group(1)
        meta=[n for n in names if n.endswith('.meta') and ('guid: '+guid).encode() in z.read(n).splitlines()]
        assert len(meta)==0,(font,'An exported atlas unexpectedly exists',meta)
        original_path='NOT_EXPORTED_ZERO_SIZED_TEXTURE'
        texture_name={'Roboto-Bold':'Roboto-Bold Atlas','LiberationSans SDF - Fallback':'LiberationSans SDF Atlas'}.get(font,font+' SDF Atlas')
        rows.append(dict(font_path=path,source_font_asset_sha256=hashlib.sha256(data).hexdigest(),missing_atlas_guid=guid,
            missing_exported_texture_path=original_path,texture_name=texture_name,original_atlas=None,original_font=None))
original_fonts=[]
with zipfile.ZipFile(work.parent.parent/'GodsPVZ_1.0.2.zip') as z:
    for name in z.namelist():
        if not name.endswith(('resources.assets','sharedassets0.assets','globalgamemanagers.assets')):continue
        env=UnityPy.load(z.read(name))
        for obj in env.objects:
            if obj.type.name=='MonoBehaviour':
                head=obj.read_typetree(check_read=False)
                matched=[r for r in rows if Path(r['font_path']).stem==head.get('m_Name')]
                if matched:
                    original_fonts.append(dict(row=matched[0],member=name,path_id=obj.path_id,
                        externals=[e.path for e in obj.assets_file.externals],raw=obj.get_raw_data()))
                continue
            if obj.type.name!='Texture2D':continue
            tex=obj.read()
            if tex.m_Width!=0 or tex.m_Height!=0:continue
            matches=[r for r in rows if r['texture_name']==tex.m_Name]
            for row in matches:
                assert row['original_atlas'] is None,'ambiguous original texture name'
                row['original_atlas']=dict(member=name,path_id=obj.path_id,name=tex.m_Name,width=tex.m_Width,height=tex.m_Height,
                    texture_format=int(tex.m_TextureFormat),image_data_bytes=len(tex.image_data),
                    stream_size=tex.m_StreamData.size if tex.m_StreamData is not None else 0,
                    texture_settings=obj.read_typetree()['m_TextureSettings'],mip_count=tex.m_MipCount,is_readable=tex.m_IsReadable,
                    raw_sha256=hashlib.sha256(obj.get_raw_data()).hexdigest())
        del env;gc.collect()
assert all(r['original_atlas'] is not None for r in rows)
for row in rows:
    a=row['original_atlas'];assert a['width']==a['height']==a['image_data_bytes']==a['stream_size']==0
    fonts=[f for f in original_fonts if f['row'] is row];assert len(fonts)==1,(row['font_path'],len(fonts))
    font=fonts[0]
    if font['member']==a['member']:file_id=0
    else:
        refs=[i+1 for i,e in enumerate(font['externals']) if e.endswith('/'+a['member'].rsplit('/',1)[-1]) or e==a['member'].rsplit('/',1)[-1]]
        assert len(refs)==1;file_id=refs[0]
    pattern=struct.pack('<Iiq',1,file_id,a['path_id'])
    assert font['raw'].count(pattern)==1,(row['font_path'],'Ambiguous original single-atlas pointer')
    row['original_font']=dict(member=font['member'],path_id=font['path_id'],raw_sha256=hashlib.sha256(font['raw']).hexdigest(),
        atlas_array_count=1,atlas_pptr_file_id=file_id,atlas_pptr_path_id=a['path_id'],unique_single_atlas_pointer_offset=font['raw'].find(pattern))
report=dict(scope='ORIGINAL_PC_EMPTY_DYNAMIC_FONT_ATLAS_PROOF_NOT_A_FONT_SUBSTITUTION',fonts=rows)
dest=work.parent/'repo-native113/Recovery/iPad-Startup-2026-10-24/EMPTY-DYNAMIC-FONT-ATLAS-EVIDENCE.json'
dest.write_text(json.dumps(report,indent=2)+'\n','utf-8')
print(json.dumps(report))
