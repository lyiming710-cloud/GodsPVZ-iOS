from pathlib import Path
import sys,tarfile,io,tempfile,json
work=Path(__file__).resolve().parent;repo=work.parent/'repo-native113';sys.path.insert(0,str(repo/'scripts/actions'))
from prepare_bulk401_startup_resources import prepare
checks=[]
with tempfile.TemporaryDirectory(prefix='godspvz-shader-') as temp:
    base=Path(temp)
    def fixture(name,bad_path=False,dummy=False):
        root=base/name;plugin=root/'Assets/Plugins/GodsPVZRuntime1.dll';plugin.parent.mkdir(parents=True);plugin.write_bytes(b'fixture')
        package=root/'Packages/com.unity.textmeshpro/Package Resources/TMP Essential Resources.unitypackage';package.parent.mkdir(parents=True)
        with tarfile.open(package,'w:gz') as tar:
            for i in range(8):
                path='Assets/TextMesh Pro/Shaders/'+('TMP_'+str(i)+'.shader' if i<7 else 'TMP_Properties.cginc')
                if bad_path and i==0:path='Assets/TextMesh Pro/Shaders/../../outside.shader'
                code=('Shader "Test '+str(i)+'" {}\n').encode() if i<7 else b'float parameter;\n'
                if dummy and i==0:code+=b'//DummyShaderTextExporter'
                for filename,data in [('pathname',path.encode()),('asset',code),('asset.meta',('fileFormatVersion: 2\nguid: '+str(i)*32+'\n').encode())]:
                    info=tarfile.TarInfo(str(i)+'/'+filename);info.size=len(data);tar.addfile(info,io.BytesIO(data))
        return root
    root=fixture('valid');report=prepare(root,base/'valid-evidence');assert len(report['files'])==8
    for row in report['files']:
        assert row['workcopy_guid']!=row['source_guid']
        assert row['sha256']==__import__('hashlib').sha256((root/'Assets/Recovery/TMP-Official-Shaders'/row['path']).read_bytes()).hexdigest()
    assert (root/'Assets/Plugins/GodsPVZRuntime1.dll').read_bytes()==b'fixture';checks.append('source_bytes_and_plugin_preserved_eight_files')
    for name,root in [('existing_target_rejected',root),('path_traversal_rejected',fixture('traversal',bad_path=True)),('dummy_package_rejected',fixture('dummy',dummy=True))]:
        try:prepare(root,base/(name+'-evidence'))
        except ValueError:checks.append(name)
        else:raise AssertionError('False acceptance '+name)
dest=repo/'Recovery/iPad-Startup-2026-10-24/SHADER-SOURCE-RESTORE-CONTROLS.json'
dest.write_text(json.dumps(dict(scope='SOURCE_BYTE_AND_EXTRACTION_BOUNDARY_CONTROLS_NOT_GPU_TESTS',checks=checks,passed=len(checks)),indent=2)+'\n','utf-8')
print('SHADER_SOURCE_RESTORE_CONTROLS_PASS',len(checks))
