"""Check checked-in inputs separately from explicit project copy destinations."""
from pathlib import Path
import json,re
Q=Path(__file__).resolve().parent;R=Q.parents[1]/'repo-native113';rows=[]
for name in ['bulk401-startup-runtime-gate.yml','startup-r27-real-gameplay-diagnostic.yml','startup-r27-editor-preflight.yml']:
 text=(R/'.github/workflows'/name).read_text(encoding='utf-8');assert 'runtime correction-2026'not in text
 refs=set(re.findall(r'(?:scripts/actions|Recovery)/[A-Za-z0-9_./-]+\.(?:py|cs|zip|json)',text));missing=[];outputs=[]
 for ref in sorted(refs):
  if(R/ref).exists():continue
  lines=[s for s in text.splitlines()if '"$PROJECT/'+ref+'"'in s and s.strip().startswith('cp ') and '"$GITHUB_WORKSPACE/Recovery/'in s]
  if lines:outputs.append(dict(path=ref,explicit_source_copy_lines=lines))
  else:missing.append(ref)
 assert not missing,(name,missing)
 rows.append(dict(file=name,literal_repository_references_checked=len(refs)-len(outputs),generated_project_copy_destinations=outputs,missing=missing))
(Q/'WORKFLOW-LITERAL-PATHS.json').write_text(json.dumps(dict(scope='STATIC_LITERAL_INPUT_PATHS_AND_PROJECT_DESTINATIONS_NOT_EXECUTION',rows=rows),indent=2)+'\n')
print(json.dumps(rows))
