"""Exercise complete transport and independent report-corruption controls."""
from pathlib import Path
import hashlib,json,shutil,sys
Q=Path(__file__).resolve().parent;W=Q.parent;R=W.parents[1]/'audit/repo-native113'
sys.path[:0]=[str(R/'scripts/actions'),str(W)]
import bind_startup_r27_diagnostic as b
import validate_startup_r27_checkpoint as game
from archive_support import js,manifest
out=Q/'binding-pipeline-fixture';out.mkdir();(out/'candidate').mkdir();(out/'evidence').mkdir()
old=W/'r22-real-gameplay-2026-10-27/parent-package-fixture'
for p in old.iterdir():shutil.copyfile(p,out/('candidate'if p.name=='Assembly-CSharp-bulk401.dll'else'evidence')/p.name)
p=out/'evidence/PROVENANCE.json';j=json.loads(p.read_bytes());j['source_commit']='R27_LOCAL_BINDING_FIXTURE_NOT_ACTUAL_WORKFLOW';js(p,j)
proof=b.bind(out,j['source_commit'])
assert hashlib.sha256((out/'candidate/Assembly-CSharp-bulk401.dll').read_bytes()).hexdigest()==b.CANDIDATE
assert hashlib.sha256((out/'recovered-sdk/Unity.VisualScripting.Core.dll').read_bytes()).hexdigest()==b.SDK
parents=sorted(p.name for p in (out/'evidence').glob('PARENT-*PROVENANCE.json'))
assert 'PARENT-R26-TRANSPORT-PROVENANCE.json'in parents
js(Q/'BINDING-PIPELINE-FIXTURE.json',dict(scope='LOCAL_COMPLETE_TRANSPORT_AND_GAME_SDK_PAIR_BINDING_NOT_UNITY',candidate_sha256=b.CANDIDATE,sdk_sha256=b.SDK,parent_provenance_preserved=parents,pass_=True,current_child_linux_compile=False,unity_started=False,ipa_allowed=False))
controls=[];root=Q/'binding-negative-controls';root.mkdir()
for name,file,mutate in [
 ('invented-product-pass','PROGRESS.json',lambda j:j.update(whole_game_accepted=True)),
 ('erase-original-finally','CONSTRUCTION.json',lambda j:j['changes'][0].update(new_eh=None)),
 ('hidden-native-case-difference','NATIVE-COMPARE.json',lambda j:j['rows'][0].update(differences={'state':'forged summary'})),
 ('wrong-non-target-isolation-count','ISOLATION.json',lambda j:j.update(unchanged_methoddefs=2314))]:
 target=root/name;shutil.copytree(game.ROOT,target);j=json.loads((target/file).read_bytes());mutate(j);js(target/file,j);manifest(target)
 try:game.validate(target)
 except AssertionError:controls.append(dict(name=name,rejected=True));continue
 raise AssertionError('Corrupt checkpoint admitted: '+name)
js(Q/'BINDING-NEGATIVE-CONTROLS.json',dict(controls=len(controls),all_rejected=True,rows=controls))
print(json.dumps(dict(pipeline_pass=True,negative_controls=len(controls),candidate_sha256=b.CANDIDATE,sdk_sha256=b.SDK)))
