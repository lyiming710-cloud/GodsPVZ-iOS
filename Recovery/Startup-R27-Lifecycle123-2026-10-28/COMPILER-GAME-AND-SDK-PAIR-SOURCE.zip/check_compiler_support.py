"""Filesystem/support binding checks; no IL2CPP conversion is claimed locally."""
from pathlib import Path
import hashlib,json,sys,zipfile
Q=Path(__file__).resolve().parent;W=Q.parent;R=W.parents[1]/'audit/repo-native113';sys.path[:0]=[str(R/'scripts/actions'),str(W)]
from prepare_startup_r27_compiler_support import prepare,SDK
from archive_support import js
sha=lambda b:hashlib.sha256(b).hexdigest()
base=Q/'compiler-support-fixture';base.mkdir();source=base/'source';source.mkdir()
with zipfile.ZipFile(R/'Recovery/Startup-R26-SDK-Helpers-2026-10-28/ORIGINAL-ACTUALLY-LOADED-SDK.zip')as z:
 names=[n for n in z.namelist()if n.endswith('.dll')];assert len(names)==1;old=z.read(names[0])
assert sha(old)=='dc1b51ccb332d73e52642f6a50fe0694661e51b8eb2ff7ca25381f1ab877c8f9'
(source/'Unity.VisualScripting.Core.dll').write_bytes(old)
ref=W.parents[1]/'audit/local-preflight/exact-editor-tools/resolver/UnityEngine.CoreModule.dll'
(source/ref.name).write_bytes(ref.read_bytes())
target,receipt=prepare(source,base/'positive',base/'positive.json')
assert receipt['original_sdk']['sha256']==sha(old)and receipt['actual_staged_sdk']['sha256']==SDK and receipt['other_files_byte_identical']==1
controls=[]
for name in ['ambiguous-sdk','missing-sdk','destination-inside-source']:
 try:
  if name=='ambiguous-sdk':
   (source/'Unity.VisualScripting.Core.exe').write_bytes(old)
   try:prepare(source,base/name,base/(name+'.json'))
   finally:(source/'Unity.VisualScripting.Core.exe').unlink()
  elif name=='missing-sdk':
   empty=base/'empty';empty.mkdir();prepare(empty,base/name,base/(name+'.json'))
  else:prepare(source,source/'nested',base/(name+'.json'))
 except AssertionError:controls.append(dict(name=name,rejected=True));continue
 raise AssertionError('Unsafe support input admitted: '+name)
js(Q/'COMPILER-SUPPORT-CONTROLS.json',dict(scope='LOCAL_COPY_AND_FIXED_SDK_BINDING_NOT_COMPILER_OR_GAMEPLAY',positive_original_sdk_sha256=sha(old),positive_recovered_sdk_sha256=SDK,unrelated_files_byte_identical=1,negative_controls=controls,pass_=True))
print(json.dumps(dict(support_preparation_pass=True,negative_controls=len(controls),sdk=SDK)))
