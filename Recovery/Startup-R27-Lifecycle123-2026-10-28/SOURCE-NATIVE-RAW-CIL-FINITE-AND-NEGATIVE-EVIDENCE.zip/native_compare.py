"""Execute byte-rechecked original PC callers; compare raw CIL observations.

The callee leaves below are finite, explicit contracts. This is not Unity, not
proof of those callees, and not Windows SEH exception-unwind verification.
"""
from pathlib import Path
import collections,ctypes as C,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
spec=json.loads((Q/'ORIGINAL-OPERAND-RESOLUTION.json').read_bytes())
cases=json.loads((Q/'CASES.json').read_bytes())
actual=json.loads(Path(sys.argv[1]).read_bytes());by={r['name']:r for r in actual['results']}
state={};rows=[]

def log(*args):state['trace'].append(':'.join('1'if x is True else'0'if x is False else'null'if x is None else str(x)for x in args))
def tag(p):return 'null'if not p else state['objects'][p]['tag']
def obj(label,kind='UObj',alive=True,size=1024):
 p=im.alloc(size);state['objects'][p]=dict(tag=label,kind=kind,alive=alive);return p
def string(text):p=im.alloc(32);state['strings'][p]=text;return p
def live(p):return bool(p and state['objects'][p]['alive'])
def seq(items):p=im.alloc(64);state['lists'][p]=list(items);return p
def go(label,alive=True):
 p=obj(label,'GameObject',alive);t=obj(label+'-tr','Transform');state['objects'][p].update(transform=t,active=True,group=0);state['objects'][t]['position']=(0.,0.,0.);return p
def newplant(label):
 p=obj(label,'Plant');t=obj(label+'-tr','Transform');state['objects'][p].update(transform=t,onHand=False,preview=False,numeric=0);put64(p+0x1e8,state['oldboard']);put32(p+0x78,3)
 children=[]
 for k in range(state['q'].get('children',2)):
  name='Shadow'if k==0 else'Child'+str(k);child=obj(label+'-'+name,'Transform');state['objects'][child]['name']=name;put64(child,classes['UnityEngine.Transform']);children.append(child)
 state['objects'][t]['children']=children
 return p
def clone(prefab,method):
 log('instantiate',tag(prefab));n=len(state['clones'])+1;p=newplant('hand'if n==1 else'preview');state['clones'].append(p)
 if n==2 and state['mode']=='missing-preview':return 0
 if n==2 and state['mode']=='destroyed-preview':state['objects'][p]['alive']=False
 return p
def presence(kind):
 def cb(a,b=None,m=None):
  if kind=='implicit':v=live(a);log(kind,tag(a),v)
  else:
   v=(not live(a)and not live(b))or a==b
   if kind=='ne':v=not v
   log(kind,tag(a),tag(b),v)
  return v
 return cb
def transform(p,m):log('componentTransform',tag(p));return state['objects'][p]['transform']
def gotransform(p,m):log('goTransform',tag(p));return state['objects'][p]['transform']
def getenum(p,m):
 log('getEnum',tag(p));en=obj('enumerator');cls=im.alloc(512);put64(en,cls);state['objects'][en].update(items=state['objects'][p]['children'],index=-1);return en
def move(index,method,p):
 assert index==0;v=state['objects'][p];v['index']+=1;result=v['index']<len(v['items']);log('move',result);return int(result)
def current(p,method):v=state['objects'][p];log('current',v['index']);return v['items'][v['index']]
def dispose(index,method,p):assert index==0;state['disposed']+=1;log('dispose')
def getname(p,m):log('name',tag(p));return string(state['objects'][p]['name'])
def onhand(p,card,mouse,m):log('onHand',tag(p),tag(card),tag(get64(p+0x1e8)));state['objects'][p]['onHand']=True
def numeric(p,m):log('numeric',tag(p),tag(get64(p+0x1e8)));state['objects'][p]['numeric']+=1;put32(p+0x78,7)
def preview(p,mouse,m):log('preview',tag(p),tag(get64(p+0x1e8)));state['objects'][p]['preview']=True;put64(p+0x1e8,get64(mouse+0x28))
def detail(p,plant,m):
 mouse=state['mouse'];log('detail',tag(plant),tag(get64(plant+0x1e8)),get32(mouse+0x40),tag(get64(mouse+0x68)));state['detailCalls']+=1;put64(p+0x28,plant)
def trigger(p,name,m):v=state['strings'][name];log('trigger',tag(p),v);state['trigger']=v
def collapse(p,m):log('collapse',tag(p));state['objects'][p]['collapsed']=True
def armor(p,no,m):log('armor',tag(p),bool(no));state['armorDrops']+=1
def volume(m):log('volume');return .75
def spritepos(out,items,name,m):
 text=state['strings'][name];log('spritePos',text)
 if state['mode']=='id-callback':put32(state['zombie']+0x60,16)
 value=(1.25,-2.5,3.75)if text=='Zombie_head'else(7.,8.,9.)if text=='LadderSaboteurs_head'else(-4.,5.,-6.)
 C.memmove(out,struct.pack('<3f',*value),12);return out
def camera(m):log('main');return state['camera']
def getpos(out,p,m):log('position',tag(p));C.memmove(out,struct.pack('<3f',*state['objects'][p]['position']),12);return out
def vec(value):return ','.join(bits(x)for x in value)
def audio(clip,pos,vol,m):
 position=vec(struct.unpack('<3f',C.string_at(pos,12)));log('audio',tag(clip),position,bits(vol));state['audioCalls']+=1;state['audioSources'].append(dict(clip=tag(clip),position=position,volume=bits(vol)));return obj('audio','AudioSource')
def newparticle(p,state_,m):log('particle',state_);state['particleCode']=state_;return state['particle']
def setpos(p,pos,m):value=struct.unpack('<3f',C.string_at(pos,12));log('setPosition',tag(p),vec(value));state['objects'][p]['position']=value
def addcomponent(p,m):log('addComponent',tag(p),'SortingGroup');g=obj('new-group','SortingGroup');state['objects'][g]['layer']='';state['objects'][p]['group']=g;return g
def setlayer(p,text,m):v=state['strings'][text];log('layer',tag(p),v);state['objects'][p]['layer']=v
def active(p,value,m):log('active',tag(p),bool(value));state['objects'][p]['active']=bool(value)
def block(p,z,v,m):log('block',tag(p),tag(z),bool(v));state['objects'][p]['unblocked']=not bool(v)

def setup(q):
 state.clear();state.update(q=q,mode=q['mode'],objects={},strings={},lists={},trace=[],clones=[],disposed=0,detailCalls=0,trigger='',armorDrops=0,audioCalls=0,audioSources=[],particleCode=0)
 for slot,text in literals.items():put64(slot,string(text))
 oldboard=obj('old-board','Board');state['oldboard']=oldboard
 oldplant=obj('old-plant','Plant',q['mode']!='destroyed-old');ar=obj('old-range','AttackRangeUIController');state['objects'][ar]['collapsed']=False;put64(oldplant+0x70,0 if q['mode']=='no-old-range'else ar)
 board=obj('board','Board');dp=obj('detail','Plant_DetaiPage');datapage=im.alloc(64);anim=obj('detail-animator','Animator');put64(datapage+0x30,anim);put64(dp+0x88,datapage);put64(dp+0x28,0 if q['mode']=='null-old'else oldplant);put64(board+0xc8,dp);C.c_ubyte.from_address(board+0xd0).value=q.get('open',False)
 mouse=obj('mouse','MouseManager');put64(mouse+0x28,board);put32(mouse+0x40,9);put32(mouse+0x98,12);put64(mouse+0x68,obj('old-card','Card'));state.update(mouse=mouse,board=board,detail=dp)
 manager=im.alloc(64);put64(board+0xe8,manager);card=obj('card','Card');data=im.alloc(64);put64(card+0x30,data);put32(data+0x18,q.get('plantID',0));state['card']=card
 prefab=obj('prefab','Plant',q['mode']!='destroyed-prefab');items=[0]*4;items[q.get('plantID',0)]=0 if q['mode']=='missing-prefab'else prefab;put64(manager+0x28,seq(items))
 z=obj('zombie','Zombie');state['zombie']=z;put32(z+0x60,q.get('ID',0));put32(z+0x84,q.get('armor',0));put64(z+0x1a8,go('anim-head'));put64(z+0x1b0,seq([]));target=obj('target','Plant')if q.get('target',False)else 0
 if target:state['objects'][target]['unblocked']=False
 put64(z+0x170,target)
 cam=obj('camera','Camera');tr=obj('camera-tr','Transform');state['objects'][cam]['transform']=tr;state['objects'][tr]['position']=(101.,102.,103.);state['camera']=cam
 part=0 if q['mode']=='missing-particle'else go('particle',q['mode']!='destroyed-particle');state['particle']=part
 pm=obj('particles','ParticlesManager');put64(statics['ParticlesManager'],pm);clip=0 if q['mode']=='missing-clip'else obj('clip','AudioClip',q['mode']!='destroyed-clip');clips=[0]*5;clips[4]=clip;put64(statics['ResourceManager']+0x120,seq(clips))

def snapshot():
 m=state['mouse'];b=get64(m+0x28);dp=get64(b+0xc8);z=state['zombie'];target=get64(z+0x170);p=state['particle'];g=state['objects'][p]['group']if p else 0
 return dict(hand=tag(get64(m+0x70)),preview=tag(get64(m+0x78)),card=tag(get64(m+0x68)),item=get32(m+0x40),plantType=get32(m+0x98),open=bool(C.c_ubyte.from_address(b+0xd0).value),detailPlant=tag(get64(dp+0x28)),detailCalls=state['detailCalls'],trigger=state['trigger'],disposed=state['disposed'],
 clones=[dict(tag=tag(p),board=tag(get64(p+0x1e8)),onHand=state['objects'][p]['onHand'],preview=state['objects'][p]['preview'],numeric=state['objects'][p]['numeric'],plantType=get32(p+0x78))for p in state['clones']],
 dying=bool(C.c_ubyte.from_address(z+0xb7).value),armorDrops=state['armorDrops'],headActive=state['objects'][get64(z+0x1a8)]['active'],targetUnblocked=state['objects'][target]['unblocked']if target else None,particleCode=state['particleCode'],particleGroup=tag(g),particleLayer=state['objects'][g]['layer']if g else None,particlePosition=vec(state['objects'][state['objects'][p]['transform']]['position'])if p else vec((0.,0.,0.)),audioCalls=state['audioCalls'],audioSources=state['audioSources'])

for rid in [0x1dd,0x453]:
 im=NativeImage();classes={};statics={};literals={};cfg=json.loads((Q/'native-source-complete'/f'0x{0x6000000|rid:08X}.json').read_bytes())
 for d in spec:
  for r in d['rows']:
   v=r['resolved']
   if isinstance(v,dict)and'class'in v:
    name=v['class']
    if name not in classes:
     p=im.alloc(512);sf=im.alloc(4096);put64(p+0xb8,sf);put32(p+0xe0,1);classes[name]=p;statics[name]=sf
    put64(int(v['slot_va'],16),classes[name])
   if isinstance(v,dict)and'string'in v:literals[int(v['slot_va'],16)]=v['string']
 transformclass=classes['UnityEngine.Transform'];C.c_ubyte.from_address(transformclass+0x130).value=1;parents=im.alloc(16);put64(parents,transformclass);put64(transformclass+0xc8,parents)
 im.hook(0x18024fef0,None,[P],lambda p:None);im.hook(0x1802501e0,None,[P],lambda p:None);im.hook(0x18024f360,None,[P,P],lambda a,b:None)
 im.hook(0x18131f760,C.c_bool,[P,P,P],presence('eq'));im.hook(0x18131f900,C.c_bool,[P,P,P],presence('ne'));im.hook(0x18131f870,C.c_bool,[P,P],presence('implicit'))
 im.hook(0x180825710,P,[P,I,P],lambda p,i,m:state['lists'][p][i]);im.hook(0x1804a0690,P,[P,P],clone);im.hook(0x181304510,P,[P,P],transform);im.hook(0x18131c070,P,[P,P],gotransform)
 im.hook(0x18132dc20,P,[P,P],getenum);im.hook(0x180002cd0,P,[I,P,P],move);im.hook(0x180f00000,P,[P,P],current);slot=im.alloc(16);put64(slot,0x180f00000);im.hook(0x180258380,P,[P,P,I],lambda p,i,n:slot)
 im.hook(0x18131f6f0,P,[P,P],getname);im.hook(0x180b76170,C.c_bool,[P,P,P],lambda a,b,m:state['strings'][a]==state['strings'][b]);im.hook(0x18024f380,P,[P,P],lambda p,cls:p);im.hook(0x180002d90,None,[I,P,P],dispose)
 im.hook(0x180358b50,None,[P,P,P,P],onhand);im.hook(0x180351d70,None,[P,P],numeric);im.hook(0x180358d00,None,[P,P,P],preview);im.hook(0x1803a3e30,None,[P,P,P],detail);im.hook(0x1812dbc00,None,[P,P,P],trigger);im.hook(0x180394350,None,[P,P],collapse);im.hook(0x18131e440,None,[P,P],lambda p,m:log('print',state['strings'][p]))
 im.hook(0x18035f040,None,[P,C.c_bool,P],armor);im.hook(0x18031aea0,F,[P],volume);im.hook(0x18031b680,P,[P,P,P,P],spritepos);im.hook(0x1812e27c0,P,[P],camera);im.hook(0x18132f3a0,P,[P,P,P],getpos);im.hook(0x18031b230,P,[P,P,F,P],audio);im.hook(0x180321f30,P,[P,I,P],newparticle);im.hook(0x18132fbb0,None,[P,P,P],setpos);im.hook(0x18046d280,P,[P,P],addcomponent);im.hook(0x181348060,None,[P,P,P],setlayer);im.hook(0x18131bad0,None,[P,C.c_bool,P],active);im.hook(0x18034df60,None,[P,P,C.c_bool,P],block)
 im.verify_caller(rid,int(cfg['entry'],16),cfg)
 if rid==0x453:assert C.string_at(0x180361fc8,24).hex()==json.loads((Q/'HEAD-ID-JUMP-TABLE.json').read_bytes())['raw']
 for q in cases:
  if q['token']!=f'0x{0x6000000|rid:08X}':continue
  expected=by[q['name']]
  if 'native_unwind'in q:
   assert expected['error']=='System.InvalidOperationException'and expected['state']['disposed']==1
   rows.append(dict(name=q['name'],token=q['token'],status='UNSUPPORTED_ORIGINAL_WINDOWS_SEH_EXCEPTION_UNWIND',cil_error=expected['error'],candidate_finally_observed=True));continue
  setup(q)
  if rid==0x1dd:ret=bool(C.CFUNCTYPE(C.c_bool,P,P,P)(int(cfg['entry'],16))(state['mouse'],state['card'],None))
  else:C.CFUNCTYPE(None,P,C.c_bool,P)(int(cfg['entry'],16))(state['zombie'],q.get('noResidue',False),None);ret=None
  assert not im.errors,im.errors
  got=dict(returned=ret,state=snapshot(),trace=state['trace']);diff={k:dict(native=got[k],cil=expected[k])for k in ['returned','state','trace']if got[k]!=expected[k]}
  if expected['error']:diff['cil_error']=expected['error']
  rows.append(dict(name=q['name'],token=q['token'],status='ZERO_DIFFERENCE'if not diff else'DIFFERENCE',native=got,cil=expected,differences=diff))
 im.close()
result=dict(scope='TWO_UNMODIFIED_ORIGINAL_PC_CALLERS_VS_EXACT_CHILD_RAW_CIL_FINITE_CONTRACTS_NOT_UNITY',candidate_sha256=actual['candidate_sha256'],original_pc_sha256=PC_SHA,counts=dict(collections.Counter(r['status']for r in rows)),rows=rows,whole_game_behavior_proven=False,ipa=None)
(Q/'NATIVE-COMPARE.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items()if k!='rows'},indent=2));print(json.dumps([r for r in rows if r['status']=='DIFFERENCE'][:1],indent=2));assert not any(r['status']=='DIFFERENCE'for r in rows)
