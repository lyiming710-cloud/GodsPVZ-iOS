from pathlib import Path
import hashlib,json,sys
Q=Path(__file__).resolve().parent;W=Q.parent;R=W.parents[1]/'audit/repo-native113'
sys.path.insert(0,str(W));from archive_support import js,pack,manifest,variants
data=(Q/'authored1.dll').read_bytes();r=json.loads((Q/'authored1.json').read_bytes())
assert hashlib.sha256(data).hexdigest()==r['candidate_sha256']=='eef6c35a2dceb0c38d1032837204abaff56f3a4c4d029ca47d76ff496fd69293'
C=R/'Recovery/Startup-R27-Lifecycle123-2026-10-28';assert not C.exists();C.mkdir()
(C/'.gitattributes').write_bytes(b'* -text\n')
pack(C/'STARTUP-R27-LIFECYCLE123-CANDIDATE.zip',[('STARTUP-R27-LIFECYCLE123.dll',data)])
for src,name in [('authored1.json','CONSTRUCTION.json'),('shared-authored1/ISOLATION.json','ISOLATION.json'),('shared-authored1/FROZEN-RAW.json','FROZEN-RAW.json'),('shared-authored1/MEMBER-EXIT.json','MEMBER-EXIT.json'),('shared-authored1/jit/RESULT.json','EXACT-JIT.json'),('NATIVE-COMPARE.json','NATIVE-COMPARE.json'),('PHYSICAL-CONTROLS.json','PHYSICAL-CONTROLS.json'),('REPEATED-CONSTRUCTION.json','REPEATED-CONSTRUCTION.json'),('ORIGINAL-DIRECT-API-IDENTITIES.json','ORIGINAL-DIRECT-API-IDENTITIES.json')]:
 (C/name).write_bytes((Q/src).read_bytes())
items=[]
for p in sorted(Q.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(Q)
 if any(x in ['bin','obj','__pycache__']for x in rel.parts)or p.suffix.lower()=='.dll':continue
 items.append((rel.as_posix(),p.read_bytes()))
pack(C/'SOURCE-NATIVE-RAW-CIL-FINITE-AND-NEGATIVE-EVIDENCE.zip',items)
js(C/'PHYSICAL-VARIANT-BYTE-DELTAS.json',variants(Q/'physical-controls',data))
js(C/'PROGRESS.json',dict(status='TWO_ORIGINAL_LIFECYCLE_CALLERS_123_POSITIONS_SCOPED_CHECKS_PASS_REAL_UNITY_PENDING',candidate_sha256=r['candidate_sha256'],parent_sha256=r['parent_sha256'],positions=123,methods=2,qualified_methods=0,whole_game_accepted=False,ipad_acceptance=False,ipa=None,unity_run=None,normal_native_comparisons=268,unsupported_windows_unwind=1,physical_semantic_controls=6,current_linux_compiler='NOT_RUN_FOR_THIS_CHILD',current_apple_compiler='NOT_RUN_FOR_THIS_CHILD',sdk_sha256='51f72bcd146c5571f642f3c4149f0545eb704fd325d83eb0f7c4ca2deec14c2b',known_next_acceptance=['Actual Editor planting and HPUI initialization','Actual zombie head residue without missing component exceptions','Plant-sourced projectile creation and attributable zombie damage','Actual complex-level trajectory review']))
(C/'README.md').write_text('''# R27 original card-to-hand and zombie-head lifecycle recovery

R25 parent `9490c1845298fa5afda04fc8dfba915ce2a939eaebe96be83e3311b39557bc4c` → R27 `eef6c35a2dceb0c38d1032837204abaff56f3a4c4d029ca47d76ff496fd69293`. Two full method bodies; 123 distinct original native semantic operation positions. These are not 123 independent bugs, methods or formal qualifications. The separately recovered SDK remains `51f72bcd…14c2b`.

R26 actual Unity run 40709087573 passed all ten real-engine SDK checks, loaded the exact SDK in both dumps, and passed actual OS-input card selection. It failed planting and reached the original defeat screen after 42.29 game seconds. Full failure evidence is retained in the R26 checkpoint. The 21 raw exception occurrences were HPUIController_Plant.Start, Plant.TryPlanting and Zombie.HeadDrop.

`MouseManager.GetPlantFromCardbank` (0x060001DD / PC 0x18031E4D0) now restores the full original sequence: required card/board data, original prefab-list index and Unity-null normalization, real prefab instantiation, Transform enumeration with discarded Shadow string comparison and finally Dispose, **handPlant.board before initialization**, separate hand item/type writes, complete first-open/already-open detail-page logic, correct card assignment order, and preview instantiation with **only** SetPrefabState_previewOnField. Original MonoBehaviour.print messages and missing-prefab/preview behavior remain. Original Equals and op_Equality share PC pointer 0x180B76170; the static string equality contract is retained, with no invented child mutation.

`Zombie.HeadDrop` (0x06000453 / PC 0x180361A70) restores original armor/noResidue handling, six-entry native jump table and additional/special IDs, exact audio slot/volume and sprite-position selection, camera-located sound, ID-specific particles, original **GameObject.AddComponent<SortingGroup>** and Particles layer, hiding anim_Head, target unblock, and final **isDying=true at +0xB7**. The field is isDying, not an invented isHeadDropped field.

The Plant.TryPlanting and HPUIController_Plant.Start leaf bodies were inspected and left unchanged. The captured Peasniper prefab already has its serialized HPUIController_Plant.plant reference; no fallback GetComponentInParent, defensive null check, dummy resource or field visibility change was added.

Independent byte isolation checks all 2,317 MethodDefs: exactly two targets differ and the other **2,315 remain byte-identical**. All old code slots, metadata rows/heaps, method flags and section permissions are preserved. Two local signatures are appended; no MemberRef or MethodSpec is added. Repeated construction is identical. Both targets pass the unchanged frozen checker; the whole assembly remains 2,200 PASS / 97 FAIL_OR_UNSUPPORTED. All 2,297 exported method member accesses pass; two exact-image JIT preparations pass without invoking gameplay.

The exact candidate raw CIL was actually executed in 269 finite cases, and the two byte-rechecked original PC callers matched all **268 normal cases**. One injected exception case observes candidate finally/Dispose but original Windows SEH unwind remains UNSUPPORTED. Controlled engine/game callee leaves are explicit test contracts, not restored nested game behavior. Six physically changed, type-valid wrong candidates create observable final-state differences and are detected. An initial audio-volume mutant exposed a missing audio-source state observation in the fixture; the fixture was extended to retain source clip, position and volume and both CIL and original-PC comparisons were rerun, without weakening the frozen checker.

Current-child full IL2CPP/Clang, actual Unity gameplay, Apple compilation and iPad testing remain pending. The old R25 Linux compiler result is parent evidence. The last IPA is R20; this checkpoint provides no new IPA and adds zero formally qualified methods.
''',encoding='utf-8')
manifest(C)
print(json.dumps(dict(checkpoint=str(C),candidate_sha256=r['candidate_sha256'],positions=123,methods=2)))
