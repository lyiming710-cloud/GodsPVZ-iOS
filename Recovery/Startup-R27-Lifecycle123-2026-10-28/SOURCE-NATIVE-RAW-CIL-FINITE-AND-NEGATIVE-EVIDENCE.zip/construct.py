"""Restore the complete original card-to-hand and zombie-head lifecycle bodies.

Positions are distinct native semantic operations, not separate game bugs.
No candidate verifier, mock execution or engine task is invoked here.
"""
import json, struct, sys
import source_common as s
from construction import Context, old

c = Context()
GO = 'UnityEngine.GameObject'
UO = 'UnityEngine.Object'

def sig(name, value=False):
    t = c.type(name) if '.' in name else 0x02000000 | next(k for k,r in enumerate(s.pe.net.mdtables.TypeDef.rows,1) if str(r.TypeName)==name and not str(r.TypeNamespace))
    return bytes([0x11 if value else 0x12]) + old.labels.comp(((t&0xffffff)<<2) | (1 if t>>24==1 else 0))

def call(b,owner,name,args=(),v=False):
    return b.token(0x6f if v else 0x28,c.meth(owner,name,args))

def f(b,owner,name):
    return b.arg(0).token(0x7b,c.fld(owner,name))

def site(b,va,kind,description,emit):
    return b.site(va,kind,description,emit)

def generic(owner,name,arg):
    rows=[]
    for k,r in enumerate(s.pe.net.mdtables.MethodSpec.rows,1):
        if r.Instantiation.value!=b'\x0a\x01'+sig(arg) or r.Method.table.name!='MemberRef':continue
        mr=r.Method.row;t=mr.Class.row
        if str(mr.Name)==name and (str(t.TypeNamespace)+'.' if str(t.TypeNamespace)else'')+str(t.TypeName)==owner:rows.append(0x2b000000|k)
    assert len(rows)==1,(owner,name,arg,rows)
    return rows[0]

def mouse_card():
    rid=0x1dd;b=c.begin(rid)
    l,ls=c.append_locals(rid,[sig('PlantManager'),b'\x08',sig('Plant'),sig('System.Collections.IEnumerator'),sig('System.IDisposable'),sig('Plant_DetaiPage')])
    manager,pid,prefab,en,disposable,detail=range(l,l+6)
    # The native null-card route raises NRE. Do not convert it to false.
    site(b,0x18031e575,'CONTROL_FLOW','Null card throws before reading its data, as in original native',
         lambda x:x.arg(1).branch(0x3a,'have-card').token(0x73,c.meth('System.NullReferenceException','.ctor')).op('7a'))
    b.mark('have-card')
    site(b,0x18031e57e,'FIELD_READ','Read actual mouse board',lambda x:f(x,'MouseManager','board'))
    site(b,0x18031e58b,'FIELD_READ','Capture manager before reading card data',lambda x:x.token(0x7b,c.fld('Board','plantManager')).store(manager))
    site(b,0x18031e592,'FIELD_READ','Original required card.plantData reference',lambda x:x.arg(1).token(0x7b,c.fld('Card','plantData')))
    site(b,0x18031e59f,'FIELD_READ','Original plant ID, without invented bounds fallback',lambda x:x.token(0x7b,c.fld('Card/PlantData','plantID')).store(pid))
    site(b,0x18031e5d3,'FIELD_READ','Read original manager prefab list',lambda x:x.loc(manager).token(0x7b,c.fld('PlantManager','plantPrefabList')))
    site(b,0x18031e5e9,'CALL','Original List<Plant>.get_Item(plantID)',lambda x:call(x.loc(pid),'System.Collections.Generic.List`1<Plant>','get_Item',('System.Int32',),True).store(prefab))
    site(b,0x18031e60e,'CALL','Original Unity inequality normalizes destroyed prefabs to CLR null',lambda x:call(x.loc(prefab).op('14'),UO,'op_Inequality',(UO,UO)).branch(0x3a,'normalized'))
    site(b,0x18031e615,'LOOP_STATE','Original conditional null normalization',lambda x:x.op('14').store(prefab))
    b.mark('normalized')
    site(b,0x18031e63b,'CALL','Original Unity equality missing-prefab branch',lambda x:call(x.loc(prefab).op('14'),UO,'op_Equality',(UO,UO)).branch(0x3a,'no-prefab'))
    site(b,0x18031e667,'CALL','Instantiate the genuine plant component prefab',lambda x:x.arg(0).loc(prefab).token(0x28,generic(UO,'Instantiate','Plant')))
    site(b,0x18031e66c,'FIELD_WRITE','Store actual hand plant before enumerating children',lambda x:x.token(0x7d,c.fld('MouseManager','plantPrefabOnHand')))
    site(b,0x18031e67c,'FIELD_READ','Read hand instance for transform enumeration',lambda x:f(x,'MouseManager','plantPrefabOnHand'))
    site(b,0x18031e68b,'CALL','Original hand component transform',lambda x:call(x,'UnityEngine.Component','get_transform',v=True))
    site(b,0x18031e69e,'CALL','Original Transform.GetEnumerator, including its observable failures',lambda x:call(x,'UnityEngine.Transform','GetEnumerator',v=True).store(en))
    b.mark('try-children').mark('next-child')
    site(b,0x18031e6eb,'CALL','Original IEnumerator.MoveNext on hand children',lambda x:call(x.loc(en),'System.Collections.IEnumerator','MoveNext',v=True).branch(0x39,'leave-children'))
    site(b,0x18031e762,'CALL','Read original IEnumerator.Current interface result',lambda x:call(x.loc(en),'System.Collections.IEnumerator','get_Current',v=True))
    site(b,0x18031e7bf,'CONTROL_FLOW','Retain original Transform cast; wrong child type throws',lambda x:x.token(0x74,c.type('UnityEngine.Transform')))
    site(b,0x18031e7ca,'CALL','Read each original child name',lambda x:call(x,UO,'get_name',v=True))
    site(b,0x18031e7dc,'CALL','Retain the original discarded Shadow equality result; no invented child writes',lambda x:call(x.token(0x72,c.string('Shadow')),'System.String','op_Equality',('System.String','System.String')).op('26').branch(0x38,'next-child'))
    b.mark('leave-children').branch(0xdd,'after-children').mark('finally-children')
    site(b,0x18031e7f5,'CONTROL_FLOW','Original enumerator isinst IDisposable cleanup',lambda x:x.loc(en).token(0x75,c.type('System.IDisposable')).store(disposable))
    site(b,0x18031e80f,'CONTROL_FLOW','Dispose only a non-null IDisposable interface',lambda x:x.loc(disposable).branch(0x39,'finally-children-done'))
    site(b,0x18031e81d,'CALL','Keep child enumerator Dispose in finally, including exceptional exits',lambda x:call(x.loc(disposable),'System.IDisposable','Dispose',v=True))
    b.mark('finally-children-done').op('dc').mark('finally-children-end').mark('after-children')
    site(b,0x18031e851,'FIELD_READ','Reload original hand plant after enumeration',lambda x:f(x,'MouseManager','plantPrefabOnHand'))
    site(b,0x18031e855,'FIELD_READ','Read original board for the hand instance',lambda x:f(x,'MouseManager','board'))
    site(b,0x18031e862,'FIELD_WRITE','Restore handPlant.board assignment before both initialization calls',lambda x:x.token(0x7d,c.fld('Plant','board')))
    site(b,0x18031e875,'FIELD_READ','Reload actual hand instance before on-hand state initialization',lambda x:f(x,'MouseManager','plantPrefabOnHand'))
    site(b,0x18031e88b,'CALL','Original SetPrefabState_onHand(card,this)',lambda x:call(x.arg(1).arg(0),'Plant','SetPrefabState_onHand',('Card','MouseManager'),True))
    site(b,0x18031e890,'FIELD_READ','Reload actual hand for numerical initialization',lambda x:f(x,'MouseManager','plantPrefabOnHand'))
    site(b,0x18031e89f,'CALL','Initialize numerical card values exactly once, on the hand instance',lambda x:call(x,'Plant','NumericalInitialize_FromCard',v=True))
    site(b,0x18031e8a4,'FIELD_WRITE','Set CardOnCardbank hand item before detail page work',lambda x:x.arg(0).op('17').token(0x7d,c.fld('MouseManager','handItemType')))
    site(b,0x18031e8ab,'FIELD_READ','Read actual hand plant for its plant type',lambda x:x.arg(0).arg(0).token(0x7b,c.fld('MouseManager','plantPrefabOnHand')))
    site(b,0x18031e8b8,'FIELD_READ','Read original initialized plant type',lambda x:x.token(0x7b,c.fld('Plant','plantType')))
    site(b,0x18031e8bb,'FIELD_WRITE','Store actual hand plant type',lambda x:x.token(0x7d,c.fld('MouseManager','plantTypeOnHand')))
    site(b,0x18031e8c1,'FIELD_READ','Original board for detail page',lambda x:f(x,'MouseManager','board'))
    site(b,0x18031e8ce,'FIELD_READ','Capture original required detail page',lambda x:x.token(0x7b,c.fld('Board','detailPage')).store(detail))
    site(b,0x18031e8de,'FIELD_READ','Read current board again for detail-page state',lambda x:f(x,'MouseManager','board'))
    site(b,0x18031e8e2,'CONTROL_FLOW','Original open versus already-open detail page branch',lambda x:x.token(0x7b,c.fld('Board','onDetailPage')).branch(0x3a,'detail-already-open'))
    site(b,0x18031e8ee,'FIELD_READ','Read actual hand argument for opening detail page',lambda x:x.loc(detail).arg(0).token(0x7b,c.fld('MouseManager','plantPrefabOnHand')))
    site(b,0x18031e8f5,'CALL','Initialize original detail page from actual hand plant',lambda x:call(x,'Plant_DetaiPage','Initialize',('Plant',),True))
    site(b,0x18031e8fa,'FIELD_READ','Original data-page component',lambda x:x.loc(detail).token(0x7b,c.fld('Plant_DetaiPage','dataPage')))
    site(b,0x18031e90a,'FIELD_READ','Original data-page animator',lambda x:x.token(0x7b,c.fld('Board_PlantDetail_PlantData','animator')))
    site(b,0x18031e921,'CALL','Original EnterTrigger animation on first detail-page opening',lambda x:call(x.token(0x72,c.string('EnterTrigger')),'UnityEngine.Animator','SetTrigger',('System.String',),True).branch(0x38,'detail-ready'))
    b.mark('detail-already-open')
    site(b,0x18031e928,'FIELD_READ','Read previous detail-page plant',lambda x:x.loc(detail).token(0x7b,c.fld('Plant_DetaiPage','plant')))
    site(b,0x18031e946,'CALL','Original Unity live-plant predicate',lambda x:call(x,UO,'op_Implicit',(UO,)).branch(0x39,'detail-reinitialize'))
    site(b,0x18031e94f,'FIELD_READ','Reload original previous plant after predicate',lambda x:x.loc(detail).token(0x7b,c.fld('Plant_DetaiPage','plant')))
    site(b,0x18031e95c,'FIELD_READ','Original previous plant range controller',lambda x:x.token(0x7b,c.fld('Plant','attackRangeUIController')).op('25'))
    site(b,0x18031e960,'CONTROL_FLOW','Original raw-null range gate',lambda x:x.branch(0x3a,'collapse-range').op('26').branch(0x38,'detail-reinitialize'))
    b.mark('collapse-range')
    site(b,0x18031e967,'CALL','Collapse previous plant range before reinitializing detail page',lambda x:call(x,'AttackRangeUIController','CollapseView',v=True))
    b.mark('detail-reinitialize')
    site(b,0x18031e96f,'FIELD_READ','Read actual hand for already-open detail page',lambda x:x.loc(detail).arg(0).token(0x7b,c.fld('MouseManager','plantPrefabOnHand')))
    site(b,0x18031e976,'CALL','Reinitialize existing original detail page',lambda x:call(x,'Plant_DetaiPage','Initialize',('Plant',),True))
    b.mark('detail-ready')
    site(b,0x18031e97b,'FIELD_READ','Reload original board after detail work',lambda x:f(x,'MouseManager','board'))
    site(b,0x18031e988,'FIELD_WRITE','Mark original detail page open',lambda x:x.op('17').token(0x7d,c.fld('Board','onDetailPage')))
    site(b,0x18031e98f,'FIELD_WRITE','Store bank card only after original detail-page sequence',lambda x:x.arg(0).arg(1).token(0x7d,c.fld('MouseManager','cardOfBankOnHand')))
    site(b,0x18031e9be,'CALL','Instantiate separate genuine preview from the uninitialized prefab',lambda x:x.arg(0).loc(prefab).token(0x28,generic(UO,'Instantiate','Plant')))
    site(b,0x18031e9c3,'FIELD_WRITE','Store original preview instance, including null result',lambda x:x.token(0x7d,c.fld('MouseManager','plantPrefabPreview')))
    site(b,0x18031e9d8,'FIELD_READ','Read actual preview before original Unity equality check',lambda x:f(x,'MouseManager','plantPrefabPreview'))
    site(b,0x18031e9dc,'CALL','Original preview Unity-null branch',lambda x:call(x.op('14'),UO,'op_Equality',(UO,UO)).branch(0x3a,'no-preview'))
    site(b,0x18031e9e5,'FIELD_READ','Read preview for its sole original initialization method',lambda x:f(x,'MouseManager','plantPrefabPreview'))
    site(b,0x18031e9f4,'CALL','Preview receives only SetPrefabState_previewOnField(this)',lambda x:call(x.arg(0),'Plant','SetPrefabState_previewOnField',('MouseManager',),True).branch(0x38,'success'))
    b.mark('no-preview')
    site(b,0x18031ea04,'CALL','Keep exact original MonoBehaviour.print missing-preview message',lambda x:call(x.token(0x72,c.string('\u8be5\u690d\u7269\u9884\u89c8\u4e0d\u5b58\u5728')),'UnityEngine.MonoBehaviour','print',('System.Object',)))
    b.mark('success')
    site(b,0x18031ea09,'RETURN_VALUE','Original success even if preview is missing',lambda x:x.op('172a'))
    b.mark('no-prefab')
    site(b,0x18031ea29,'CALL','Keep exact original MonoBehaviour.print missing-plant message',lambda x:call(x.token(0x72,c.string('\u8be5\u690d\u7269\u4e0d\u5b58\u5728')),'UnityEngine.MonoBehaviour','print',('System.Object',)))
    site(b,0x18031ea2e,'RETURN_VALUE','Original false only for Unity-null prefab',lambda x:x.op('162a'))
    c.add(rid,b,'Complete original GetPlantFromCardbank including hand board, child foreach/finally, detail-page sequence and distinct preview initialization',local_token=ls,
          new_eh=[dict(kind='finally',try_start=b.labels['try-children'],try_end=b.labels['finally-children'],handler_start=b.labels['finally-children'],handler_end=b.labels['finally-children-end'])])

def zombie_head():
    rid=0x453;b=c.begin(rid)
    l,ls=c.append_locals(rid,[b'\x0c',sig('UnityEngine.AudioClip'),sig('UnityEngine.Vector3',True),b'\x08',b'\x08',sig(GO),sig('Plant')])
    volume,clip,pos,particle,zid,head,plant=range(l,l+7)
    # Resolve the indirect jump using the original immutable six-entry table.
    table=[s.base+struct.unpack('<I',s.pc.get_data(0x361fc8+4*k,4))[0] for k in range(6)]
    assert table==[0x180361ba5,0x180361ba5,0x180361ba5,0x180361b99,0x180361ba5,0x180361ba5]
    supplement=dict(table_va='0x180361fc8',raw=s.pc.get_data(0x361fc8,24).hex(),targets=list(map(hex,table)),source_pc_sha256=s.sha(s.raw),all_targets_in_saved_cfg=all(any(int(i['va'],16)==v for i in c.cfgs[s.tok(rid)]['instructions']) for v in table))
    assert supplement['all_targets_in_saved_cfg']
    (s.Q/'HEAD-ID-JUMP-TABLE.json').write_text(json.dumps(supplement,indent=2)+'\n',encoding='utf-8')
    site(b,0x180361afc,'CONTROL_FLOW','Original armor1Type gate before head residue handling',lambda x:f(x,'Zombie','armor1Type').branch(0x39,'armor-ready'))
    site(b,0x180361b0f,'CALL','Original Drop_Armor1(noResidue)',lambda x:call(x.arg(0).arg(1),'Zombie','Drop_Armor1',('System.Boolean',)))
    b.mark('armor-ready')
    site(b,0x180361b2e,'CONTROL_FLOW','Original noResidue skips audio and particle work, retaining final state changes',lambda x:x.arg(1).branch(0x3a,'finish'))
    site(b,0x180361b4f,'CALL','Original volume getter',lambda x:call(x,'GlobalStaticVars','AudioVolume').store(volume))
    site(b,0x180361b58,'LOOP_STATE','Original default clip, zero position and no particle',lambda x:x.op('14').store(clip).loca(pos).op('fe15').emit(struct.pack('<I',c.type('UnityEngine.Vector3'))).op('16').store(particle))
    site(b,0x180361b54,'FIELD_READ','Capture original zombie ID for initial switch',lambda x:f(x,'Zombie','ID').store(zid))
    site(b,0x180361b6c,'CONTROL_FLOW','Original unsigned six-way ID jump table',lambda x:x.loc(zid).switch(['common','common','common','extra-ids','common','common']))
    b.mark('extra-ids')
    for ident,va in [(14,0x180361b8b),(15,0x180361b88),(1,0x180361b92),(10,0x180361b97)]:
        site(b,va,'CONTROL_FLOW','Original common-head ID '+str(ident),lambda x,ident=ident:x.loc(zid).i4(ident).branch(0x3b,'common'))
    b.branch(0x38,'special-ids')
    b.mark('common')
    # Source-ordered data reads and calls are retained for all four ID arms.
    arms=[('common',0x180361bca,0x180361be6,0x180361bf5,0x180361bfc,0x180361c1f,0x180361c24,'Zombie_head',39),
          ('pole',0x180361c63,0x180361c7f,0x180361c8e,0x180361c95,0x180361cb9,0x180361cbe,'Zombie_polevaulter__head',41),
          ('ladder',0x180361cf7,0x180361d13,0x180361d22,0x180361d29,0x180361d4d,0x180361d52,'LadderSaboteurs_head',40),
          ('vanguard',0x180361d8b,0x180361da7,0x180361db6,0x180361dbd,0x180361de1,0x180361de6,'Zombie_polevaulter__head',42)]
    def arm(row):
        label,readva,itemva,animva,mulva,posva,kindva,name,state=row
        site(b,readva,'FIELD_READ','Original zombieClips for '+label,lambda x:x.token(0x7e,c.fld('ResourceManager','zombieClips')))
        site(b,itemva,'CALL','Original clip slot four for '+label,lambda x:call(x.op('1a'),'System.Collections.Generic.List`1<UnityEngine.AudioClip>','get_Item',('System.Int32',),True).store(clip))
        site(b,animva,'FIELD_READ','Original animationSprites before volume multiplication for '+label,lambda x:f(x,'Zombie','animationSprites'))
        site(b,mulva,'LOOP_STATE','Original exact 0x3f19999a volume multiplier for '+label,lambda x:x.loc(volume).r4(.6).op('5a').store(volume))
        site(b,posva,'CALL','Original sprite-position lookup '+name,lambda x:call(x.token(0x72,c.string(name)),'GlobalStaticVars','GetAnimationSpritePosition',('System.Collections.Generic.List`1<UnityEngine.GameObject>','System.String')).store(pos))
        site(b,kindva,'LOOP_STATE','Original ParticleState '+str(state)+' for '+label,lambda x:x.i4(state).store(particle))
    arm(arms[0])
    b.mark('special-ids')
    site(b,0x180361c31,'FIELD_READ','Reload original current ID for independent specialized cases',lambda x:f(x,'Zombie','ID').store(zid))
    for ident,va,label in [(3,0x180361c34,'pole'),(16,0x180361cc8,'ladder'),(23,0x180361d5c,'vanguard')]:
        site(b,va,'CONTROL_FLOW','Original specialized head ID '+str(ident),lambda x,ident=ident,label=label:x.loc(zid).i4(ident).branch(0x3b,label))
    b.branch(0x38,'audio')
    for row in arms[1:]:
        b.mark(row[0]);arm(row);b.branch(0x38,'audio')
    b.mark('audio')
    site(b,0x180361e0d,'CALL','Original live-clip Unity predicate',lambda x:call(x.loc(clip),UO,'op_Implicit',(UO,)).branch(0x39,'particle'))
    site(b,0x180361e18,'CALL','Original Camera.main location for head sound',lambda x:x.loc(clip).token(0x28,c.meth('UnityEngine.Camera','get_main')))
    site(b,0x180361e2b,'CALL','Original camera transform',lambda x:call(x,'UnityEngine.Component','get_transform',v=True))
    site(b,0x180361e4c,'CALL','Original camera position value',lambda x:call(x,'UnityEngine.Transform','get_position',v=True))
    site(b,0x180361e87,'CALL','Original CreateAudioAtPoint(clip,cameraPosition,volume)',lambda x:call(x.loc(volume),'GlobalStaticVars','CreateAudioAtPoint',('UnityEngine.AudioClip','UnityEngine.Vector3','System.Single')).op('26'))
    b.mark('particle')
    site(b,0x180361e94,'CONTROL_FLOW','Original no-particle state skips particle creation',lambda x:x.loc(particle).branch(0x39,'finish'))
    site(b,0x180361ec6,'FIELD_READ','Original ParticlesManager instance getter',lambda x:call(x,'ParticlesManager','get_instance'))
    site(b,0x180361ed7,'CALL','Create original ID-specific particle',lambda x:call(x.loc(particle),'ParticlesManager','CreatNewParticle',('ParticleState',),True).store(head))
    site(b,0x180361efc,'CALL','Original Unity inequality on created particle',lambda x:call(x.loc(head).op('14'),UO,'op_Inequality',(UO,UO)).branch(0x39,'finish'))
    site(b,0x180361f13,'CALL','Original created GameObject transform',lambda x:call(x.loc(head),GO,'get_transform',v=True))
    site(b,0x180361f37,'CALL','Set original captured animation-sprite position by value',lambda x:call(x.loc(pos),'UnityEngine.Transform','set_position',('UnityEngine.Vector3',),True))
    site(b,0x180361f46,'CALL','Restore original AddComponent<SortingGroup>, never GetComponent',lambda x:x.loc(head).token(0x6f,generic(GO,'AddComponent','UnityEngine.Rendering.SortingGroup')))
    site(b,0x180361f5d,'CALL','Set new component to original Particles sorting layer',lambda x:call(x.token(0x72,c.string('Particles')),'UnityEngine.Rendering.SortingGroup','set_sortingLayerName',('System.String',),True))
    b.mark('finish')
    site(b,0x180361f62,'FIELD_READ','Original required anim_Head object',lambda x:f(x,'Zombie','anim_Head'))
    site(b,0x180361f73,'CALL','Hide original head even when residue was suppressed',lambda x:call(x.op('16'),GO,'SetActive',('System.Boolean',),True))
    site(b,0x180361f78,'FIELD_READ','Capture original targetPlant',lambda x:f(x,'Zombie','targetPlant').store(plant))
    site(b,0x180361f7f,'CONTROL_FLOW','Original raw-null target gate',lambda x:x.loc(plant).branch(0x39,'dying'))
    site(b,0x180361f8d,'CALL','Original targetPlant.BlockZombie(this,false)',lambda x:call(x.loc(plant).arg(0).op('16'),'Plant','BlockZombie',('Zombie','System.Boolean'),True))
    b.mark('dying')
    site(b,0x180361fac,'FIELD_WRITE','Restore original Zombie.isDying=true at offset 0xb7',lambda x:x.arg(0).op('17').token(0x7d,c.field_at('Zombie',0xb7)))
    site(b,0x180361fc0,'RETURN_VALUE','Original head-drop return after final state write',lambda x:x.op('2a'))
    c.add(rid,b,'Complete original HeadDrop ID dispatch, sound and residue, AddComponent<SortingGroup>, target release and final isDying flag',local_token=ls)

mouse_card()
zombie_head()
c.save_authored(sys.argv[1])
