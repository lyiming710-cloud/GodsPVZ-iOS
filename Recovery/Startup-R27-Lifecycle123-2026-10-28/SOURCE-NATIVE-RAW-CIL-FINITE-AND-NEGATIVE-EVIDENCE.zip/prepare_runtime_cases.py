"""Finite discriminator cases; observed gameplay is a later, separate gate."""
from pathlib import Path
import itertools,json
q=Path(__file__).resolve().parent;rows=[]
for mode,open_,children,pid in itertools.product(['normal','missing-prefab','destroyed-prefab','missing-preview','destroyed-preview','null-old','destroyed-old','no-old-range'],[False,True],[0,2],[0,3]):
 rows.append(dict(name=f'mouse-{mode}-{open_}-{children}-{pid}',token='0x060001DD',mode=mode,open=open_,children=children,plantID=pid))
rows.append(dict(name='mouse-exception-retains-finally',token='0x060001DD',mode='throw-move',open=False,children=2,plantID=0,native_unwind='UNSUPPORTED_ORIGINAL_WINDOWS_SEH_EXCEPTION_UNWIND'))
for ID,no,armor,mode in itertools.product([-1,0,1,2,3,4,5,6,10,14,15,16,19,23,26],[False,True],[0,1],['normal','missing-particle','destroyed-particle']):
 rows.append(dict(name=f'head-{ID}-{no}-{armor}-{mode}',token='0x06000453',mode=mode,ID=ID,noResidue=no,armor=armor,target=True))
for mode,ID,target in itertools.product(['missing-clip','destroyed-clip','id-callback'],[0,3,16,23],[False,True]):
 rows.append(dict(name=f'head-{mode}-{ID}-{target}',token='0x06000453',mode=mode,ID=ID,noResidue=False,armor=0,target=target))
assert len({r['name']for r in rows})==len(rows)
(q/'CASES.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(cases=len(rows),normal=sum('native_unwind'not in r for r in rows),by_token={t:sum(r['token']==t for r in rows)for t in {r['token']for r in rows}})))
