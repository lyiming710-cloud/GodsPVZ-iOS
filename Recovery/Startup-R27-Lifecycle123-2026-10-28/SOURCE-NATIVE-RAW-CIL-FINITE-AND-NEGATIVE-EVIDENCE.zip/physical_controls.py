"""Physical type-valid wrong-behavior variants; strict checker is not changed."""
from pathlib import Path
import collections,hashlib,json,struct,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'));import dnfile
base=(Q/'authored1.dll').read_bytes();report=json.loads((Q/'authored1.json').read_bytes());cil=json.loads((Q/'shared-authored1/ALL-CIL.json').read_bytes());ms={m['token']:m for m in cil['methods']};good=json.loads((Q/'ACTUAL-CIL.json').read_bytes());normal={q['name']for q in json.loads((Q/'CASES.json').read_bytes())if'native_unwind'not in q};pe=dnfile.dnPE(data=base);out=Q/'physical-controls';out.mkdir(exist_ok=True);controls=[]
def site(token,va):return next(x for x in report['repair_sites']if x['method']==token and x['native_va']==hex(va))
def run(name,token,offset,before,after):
 row=pe.net.mdtables.MethodDef.rows[(int(token,16)&0xffffff)-1];at=pe.get_offset_from_rva(row.Rva)+12+offset;assert len(before)==len(after)and base[at:at+len(before)]==before
 data=bytearray(base);data[at:at+len(after)]=after;path=out/(name+'.dll');path.write_bytes(data);result=out/(name+'.json')
 p=subprocess.run([str(ROOT/'.local/dotnet10/dotnet.exe'),str(Q/'runtime/bin/Release/net10.0/Fixture.dll'),str(path),str(Q/'CASES.json'),str(result)],capture_output=True,timeout=30);(out/(name+'.stdout.log')).write_bytes(p.stdout);(out/(name+'.stderr.log')).write_bytes(p.stderr);assert p.returncode==0,(name,p.stderr[-1500:]);actual=json.loads(result.read_bytes());assert actual['candidate_sha256']==hashlib.sha256(data).hexdigest();diff=[];normaldiff=0;state_diff=0
 for a,b in zip(good['results'],actual['results']):
  assert a['name']==b['name']
  if a!=b:
   diff.append(a['name'])
   if a['name']in normal and a['error']is None and b['error']is None:
    normaldiff+=1
    if a['state']!=b['state']:state_diff+=1
 assert diff and state_diff>0,(name,diff)
 # The behavior controls must also pass the original frozen type checker;
 # a missing call trace alone is insufficient evidence of detection.
 exporter=ROOT/'audit/bulk250-r1-evidence-39702928368/bulk250-r1-run/tools_bin/CilExporter/bin/CilExporter.dll';export=out/(name+'.cil.json');support=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support'
 ex=subprocess.run([str(ROOT/'.local/dotnet10/dotnet.exe'),str(exporter),str(path),str(export),str(support),token],capture_output=True);assert ex.returncode==0,ex.stderr
 import importlib.util
 checker=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py';assert hashlib.sha256(checker.read_bytes()).hexdigest()=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14';spec=importlib.util.spec_from_file_location('unchanged_type_control',checker);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);cx=json.loads(export.read_bytes());checked=v.verify(next(m for m in cx['methods']if m['token']==token),cx['types']);assert checked['status']=='PASS',checked
 controls.append(dict(name=name,kind='PHYSICAL_WRONG_SEMANTICS',token=token,offset=offset,before=before.hex(),after=after.hex(),variant_sha256=hashlib.sha256(data).hexdigest(),detected=True,different_cases=len(diff),normal_execution_differences=normaldiff,normal_execution_state_differences=state_diff,frozen_type_status=checked['status']))

def at_site(token,va,opcode):
 v=site(token,va)
 found=[i for i in ms[token]['instructions'] if v['new_cil_start']<=i['offset']<v['new_cil_end'] and i['opcode']==opcode]
 assert len(found)==1,(token,hex(va),opcode,found)
 return found[0]['offset']

t='0x060001DD';raw=bytes.fromhex(next(r for r in report['changes'] if r['token']==t)['new_code'])
for name,va in [('omit-hand-board-assignment',0x18031e862),('omit-bank-card-assignment',0x18031e98f)]:
 at=at_site(t,va,'stfld');run(name,t,at,raw[at:at+5],bytes.fromhex('2626000000'))
at=at_site(t,0x18031e8a4,'ldc.i4.1');run('wrong-hand-item-state',t,at,b'\x17',b'\x16')
t='0x06000453';raw=bytes.fromhex(next(r for r in report['changes'] if r['token']==t)['new_code'])
at=at_site(t,0x180361fac,'stfld');run('omit-original-isDying-write',t,at,raw[at:at+5],bytes.fromhex('2626000000'))
at=at_site(t,0x180361c24,'ldc.i4')+1;run('wrong-common-head-particle-ID',t,at,struct.pack('<i',39),struct.pack('<i',40))
at=at_site(t,0x180361bfc,'ldc.r4')+1;run('wrong-common-head-audio-volume',t,at,struct.pack('<f',.6),struct.pack('<f',1.0))
result=dict(scope='PHYSICAL_CANDIDATE_VARIANTS_WITH_ACTUAL_RAW_CIL_EXECUTION',candidate_sha256=hashlib.sha256(base).hexdigest(),controls=len(controls),all_detected=all(x['detected']for x in controls),results=controls,does_not_establish_unmodeled_unwind_or_unity_gameplay=True)
(Q/'PHYSICAL-CONTROLS.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,indent=2))

