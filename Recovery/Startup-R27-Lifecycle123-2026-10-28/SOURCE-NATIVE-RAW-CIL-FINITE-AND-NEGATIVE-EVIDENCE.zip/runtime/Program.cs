using System.Collections;using System.Reflection;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public class UObj {
 public string Tag="",Name="";public bool Alive=true;
 public string name{get{Program.Log("name",Tag);return Name;}}
 public static bool Eq(UObj? a,UObj? b){bool v=(a==null||!a.Alive)&&(b==null||!b.Alive)||ReferenceEquals(a,b);Program.Log("eq",Program.Tag(a),Program.Tag(b),v);return v;}
 public static bool Ne(UObj? a,UObj? b){bool v=!((a==null||!a.Alive)&&(b==null||!b.Alive)||ReferenceEquals(a,b));Program.Log("ne",Program.Tag(a),Program.Tag(b),v);return v;}
 public static bool Implicit(UObj? a){bool v=a!=null&&a.Alive;Program.Log("implicit",Program.Tag(a),v);return v;}
 public static T Instantiate<T>(T original)where T:UObj{Program.Log("instantiate",original.Tag);return(T)(UObj)Program.ClonePlant();}
}
public struct V3{public float x,y,z;public V3(float X,float Y,float Z){x=X;y=Y;z=Z;}}
public class Transform:UObj{
 public List<UObj> Children=[];public V3 Pos;
 public IEnumerator GetEnumerator(){Program.Log("getEnum",Tag);return new ChildEnumerator(Children);}
 public V3 position{get{Program.Log("position",Tag);return Pos;}set{Program.Log("setPosition",Tag,Program.Vec(value));Pos=value;}}
}
public class ChildEnumerator:IEnumerator,IDisposable{
 List<UObj> Items;int Index=-1;public ChildEnumerator(List<UObj> items){Items=items;}
 public bool MoveNext(){if(Program.Mode=="throw-move")throw new InvalidOperationException("controlled move");bool v=++Index<Items.Count;Program.Log("move",v);return v;}
 public object Current{get{Program.Log("current",Index);return Items[Index];}}
 public void Reset()=>throw new NotSupportedException();public void Dispose(){Program.Disposed++;Program.Log("dispose");}
}
public class Component:UObj{public Transform T=new();public Transform transform{get{Program.Log("componentTransform",Tag);return T;}}}
public class GameObject:UObj{
 public Transform T=new();public bool Active=true;public SortingGroup? Group;
 public Transform transform{get{Program.Log("goTransform",Tag);return T;}}
 public void SetActive(bool v){Program.Log("active",Tag,v);Active=v;}
 public T AddComponent<T>()where T:UObj,new(){Program.Log("addComponent",Tag,typeof(T).Name);var g=new SortingGroup{Tag="new-group"};Group=g;return(T)(UObj)g;}
 public T? GetComponent<T>()where T:UObj{Program.Log("getComponent",Tag,typeof(T).Name);return(T?)(UObj?)Group;}
}
public class SortingGroup:UObj{public string Layer="";public string sortingLayerName{set{Program.Log("layer",Tag,value);Layer=value;}}}
public class Animator:UObj{public string Trigger="";public void SetTrigger(string v){Program.Log("trigger",Tag,v);Trigger=v;}}
public class Camera:Component{public static Camera main{get{Program.Log("main");return Program.Cam;}}}
public class MonoBehaviour:Component{public static void print(object value)=>Program.Log("print",value);}
public class AudioClip:UObj{} public class AudioSource:Component{public AudioClip? Clip;public V3 Position;public float Volume;}
public enum ItemType{None=0,CardOnCardbank=1}public enum PlantType{None=0,A=1,B=2,C=3}public enum Armor1Type{None=0,Some=1}public enum ParticleState{None=0}
public class Card:UObj{public PlantData plantData=new();public class PlantData{public int plantID;}}
public class PlantManager{public List<Plant?> plantPrefabList=[];}
public class Board:UObj{public PlantManager plantManager=new();public Plant_DetaiPage detailPage=new();public bool onDetailPage;}
public class Board_PlantDetail_PlantData{public Animator animator=new(){Tag="detail-animator"};}
public class Plant_DetaiPage:UObj{
 public Plant? plant;public Board_PlantDetail_PlantData dataPage=new();public int InitCalls;
 public void Initialize(Plant p){Program.Log("detail",p.Tag,Program.Tag(p.board),(int)Program.Mouse.handItemType,Program.Tag(Program.Mouse.cardOfBankOnHand));InitCalls++;plant=p;}
}
public class AttackRangeUIController:UObj{public bool Collapsed;public void CollapseView(){Program.Log("collapse",Tag);Collapsed=true;}}
public class MouseManager:Component{public Board board=new();public Plant? plantPrefabOnHand,plantPrefabPreview;public Card? cardOfBankOnHand;public ItemType handItemType;public PlantType plantTypeOnHand;}
public class Plant:Component{
 public Board? board;public PlantType plantType;public AttackRangeUIController? attackRangeUIController;public bool OnHand,Preview,Unblocked;public int Numeric;
 public void SetPrefabState_onHand(Card card,MouseManager mouse){Program.Log("onHand",Tag,card.Tag,Program.Tag(board));OnHand=true;}
 public void NumericalInitialize_FromCard(){Program.Log("numeric",Tag,Program.Tag(board));Numeric++;plantType=(PlantType)7;}
 public void SetPrefabState_previewOnField(MouseManager mouse){Program.Log("preview",Tag,Program.Tag(board));Preview=true;board=mouse.board;}
 public void BlockZombie(Zombie z,bool block){Program.Log("block",Tag,z.Tag,block);Unblocked=!block;}
}
public class Zombie:Component{public int ID;public Armor1Type armor1Type;public bool isDying;public GameObject anim_Head=new();public List<GameObject> animationSprites=[];public Plant? targetPlant;public int ArmorDrops;public void Drop_Armor1(bool no){Program.Log("armor",Tag,no);ArmorDrops++;}}
public static class ResourceManager{public static List<AudioClip?> zombieClips=[];}
public class ParticlesManager:UObj{public static ParticlesManager instance=>Program.Particles;public GameObject? CreatNewParticle(ParticleState state){Program.Log("particle",(int)state);Program.ParticleCode=(int)state;return Program.Particle;}}
public static class GlobalStaticVars{
 public static float AudioVolume(){Program.Log("volume");return Program.Volume;}
 public static V3 GetAnimationSpritePosition(List<GameObject> sprites,string name){Program.Log("spritePos",name);if(Program.Mode=="id-callback")Program.Z.ID=16;return name switch{"Zombie_head"=>new(1.25f,-2.5f,3.75f),"LadderSaboteurs_head"=>new(7,8,9),_=>new(-4,5,-6)};}
 public static AudioSource CreateAudioAtPoint(AudioClip clip,V3 position,float volume){Program.Log("audio",clip.Tag,Program.Vec(position),Program.Bits(volume));Program.AudioCalls++;var a=new AudioSource{Tag="audio",Clip=clip,Position=position,Volume=volume};Program.AudioSources.Add(a);return a;}
}
public static class Program{
 public static string Mode="";public static List<string> Trace=[];public static List<AudioSource> AudioSources=[];public static MouseManager Mouse=new();public static Zombie Z=new();public static Camera Cam=new();public static ParticlesManager Particles=new();public static GameObject? Particle;public static float Volume;public static int ParticleCode,AudioCalls,Disposed,Clones;public static Board OldBoard=new();static Card? Card;static List<Plant> CloneList=[];
 public static string Tag(object? o)=>o is UObj u?u.Tag:o==null?"null":o.ToString()!;
 public static string Bits(float f)=>((uint)BitConverter.SingleToInt32Bits(f)).ToString("X8");public static string Vec(V3 v)=>string.Join(",",new[]{v.x,v.y,v.z}.Select(Bits));
 public static void Log(params object?[] a)=>Trace.Add(string.Join(":",a.Select(x=>x is bool b?(b?"1":"0"):Tag(x))));
 public static Plant ClonePlant(){Clones++;string tag=Clones==1?"hand":"preview";var p=new Plant{Tag=tag,board=OldBoard,plantType=(PlantType)3,T=new(){Tag=tag+"-tr"}};
  foreach(string n in Enumerable.Range(0,ChildCount).Select(i=>i==0?"Shadow":"Child"+i))p.T.Children.Add(new Transform{Tag=tag+"-"+n,Name=n});
  CloneList.Add(p);if(Clones==2&&Mode=="missing-preview")return null!;if(Clones==2&&Mode=="destroyed-preview")p.Alive=false;return p;}
 static int ChildCount;
 static int N(JsonElement q,string n,int d=0)=>q.TryGetProperty(n,out var x)?x.GetInt32():d;
 static bool B(JsonElement q,string n)=>q.TryGetProperty(n,out var x)&&x.GetBoolean();
 static void Setup(JsonElement q){Mode=q.GetProperty("mode").GetString()!;Trace=[];AudioSources=[];Disposed=Clones=AudioCalls=ParticleCode=0;CloneList=[];ChildCount=N(q,"children",2);Volume=.75f;OldBoard=new(){Tag="old-board"};
  var oldPlant=new Plant{Tag="old-plant",Alive=Mode!="destroyed-old",attackRangeUIController=Mode=="no-old-range"?null:new(){Tag="old-range"}};var detail=new Plant_DetaiPage{Tag="detail",plant=Mode=="null-old"?null:oldPlant};var board=new Board{Tag="board",detailPage=detail,onDetailPage=B(q,"open")};
  Mouse=new(){Tag="mouse",board=board,handItemType=(ItemType)9,plantTypeOnHand=(PlantType)12,cardOfBankOnHand=new(){Tag="old-card"}};Card=new(){Tag="card",plantData=new(){plantID=N(q,"plantID")}};
  var prefab=new Plant{Tag="prefab",Alive=Mode!="destroyed-prefab"};board.plantManager.plantPrefabList=Enumerable.Repeat<Plant?>(null,4).ToList();board.plantManager.plantPrefabList[N(q,"plantID")]=Mode=="missing-prefab"?null:prefab;
  Z=new(){Tag="zombie",ID=N(q,"ID"),armor1Type=(Armor1Type)N(q,"armor"),anim_Head=new(){Tag="anim-head"},targetPlant=B(q,"target")?new(){Tag="target"}:null};Cam=new(){Tag="camera",T=new(){Tag="camera-tr",Pos=new(101,102,103)}};Particles=new(){Tag="particles"};Particle=Mode=="missing-particle"?null:new(){Tag="particle",Alive=Mode!="destroyed-particle",T=new(){Tag="particle-tr"}};ResourceManager.zombieClips=Enumerable.Repeat<AudioClip?>(null,5).ToList();ResourceManager.zombieClips[4]=Mode=="missing-clip"?null:new(){Tag="clip",Alive=Mode!="destroyed-clip"};
 }
 static object State()=>new{
  hand=Tag(Mouse.plantPrefabOnHand),preview=Tag(Mouse.plantPrefabPreview),card=Tag(Mouse.cardOfBankOnHand),item=(int)Mouse.handItemType,plantType=(int)Mouse.plantTypeOnHand,open=Mouse.board.onDetailPage,detailPlant=Tag(Mouse.board.detailPage.plant),detailCalls=Mouse.board.detailPage.InitCalls,trigger=Mouse.board.detailPage.dataPage.animator.Trigger,disposed=Disposed,
  clones=CloneList.Select(p=>new{tag=p.Tag,board=Tag(p.board),onHand=p.OnHand,preview=p.Preview,numeric=p.Numeric,plantType=(int)p.plantType}).ToArray(),
  dying=Z.isDying,armorDrops=Z.ArmorDrops,headActive=Z.anim_Head.Active,targetUnblocked=Z.targetPlant?.Unblocked,particleCode=ParticleCode,particleGroup=Tag(Particle?.Group),particleLayer=Particle?.Group?.Layer,particlePosition=Vec(Particle?.T.Pos??default),audioCalls=AudioCalls,audioSources=AudioSources.Select(a=>new{clip=Tag(a.Clip),position=Vec(a.Position),volume=Bits(a.Volume)}).ToArray()};
 static Type Map(MC.TypeReference t){
  if(t is MC.ByReferenceType br)return Map(br.ElementType).MakeByRefType();if(t is MC.GenericInstanceType g){Type d=g.ElementType.FullName switch{"System.Collections.Generic.List`1"=>typeof(List<>),"System.Collections.Generic.List`1/Enumerator"=>typeof(List<>.Enumerator),_=>throw new Exception(g.FullName)};return d.MakeGenericType(g.GenericArguments.Select(Map).ToArray());}
  return t.FullName switch{"System.Void"=>typeof(void),"System.Object"=>typeof(object),"System.Boolean"=>typeof(bool),"System.Int32"=>typeof(int),"System.Int64"=>typeof(long),"System.Single"=>typeof(float),"System.Double"=>typeof(double),"System.String"=>typeof(string),"System.IntPtr"=>typeof(IntPtr),"System.NullReferenceException"=>typeof(NullReferenceException),"System.Collections.IEnumerator"=>typeof(IEnumerator),"System.IDisposable"=>typeof(IDisposable),"UnityEngine.Object"=>typeof(UObj),"UnityEngine.Component"=>typeof(Component),"UnityEngine.GameObject"=>typeof(GameObject),"UnityEngine.Transform"=>typeof(Transform),"UnityEngine.Vector3"=>typeof(V3),"UnityEngine.Camera"=>typeof(Camera),"UnityEngine.AudioClip"=>typeof(AudioClip),"UnityEngine.AudioSource"=>typeof(AudioSource),"UnityEngine.Animator"=>typeof(Animator),"UnityEngine.MonoBehaviour"=>typeof(MonoBehaviour),"UnityEngine.Rendering.SortingGroup"=>typeof(SortingGroup),_=>typeof(Program).Assembly.GetType(t.FullName.Replace('/','+'),true)!};
 }
 static MethodBase Method(MC.MethodReference m){Type o=Map(m.DeclaringType);string n=m.Name;if(o==typeof(UObj))n=n switch{"op_Equality"=>"Eq","op_Inequality"=>"Ne","op_Implicit"=>"Implicit",_=>n};if(m is MC.GenericInstanceMethod gm)return o.GetMethods().Single(x=>x.Name==n&&x.IsGenericMethodDefinition&&x.GetParameters().Length==m.Parameters.Count).MakeGenericMethod(gm.GenericArguments.Select(Map).ToArray());var pp=m.Parameters.Select(p=>p.ParameterType is MC.GenericParameter gp&&m.DeclaringType is MC.GenericInstanceType gt?Map(gt.GenericArguments[gp.Position]):Map(p.ParameterType));if(n==".ctor")return o.GetConstructors().Single(x=>x.GetParameters().Select(p=>p.ParameterType).SequenceEqual(pp));return o.GetMethods(BindingFlags.Public|BindingFlags.Static|BindingFlags.Instance).Single(x=>x.Name==n&&x.GetParameters().Select(p=>p.ParameterType).SequenceEqual(pp));}
 public static void Main(string[] args){var bytes=File.ReadAllBytes(args[0]);using var asm=MC.AssemblyDefinition.ReadAssembly(new MemoryStream(bytes));var methods=new[]{0x1dd,0x453}.ToDictionary(r=>r,r=>RehostExact.Emit(bytes,(MC.MethodDefinition)asm.MainModule.LookupToken(0x06000000|r),Map,f=>Map(f.DeclaringType).GetField(f.Name)!,Method));using var cases=JsonDocument.Parse(File.ReadAllText(args[1]));var rows=new List<object>();foreach(var q in cases.RootElement.EnumerateArray()){Setup(q);int rid=Convert.ToInt32(q.GetProperty("token").GetString(),16)&0xffffff;string? error=null;object? returned=null;try{returned=methods[rid].Invoke(null,rid==0x1dd?[Mouse,Card]:[Z,B(q,"noResidue")]);}catch(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;error=e.GetType().FullName;}rows.Add(new{name=q.GetProperty("name").GetString(),token=q.GetProperty("token").GetString(),error,returned,trace=Trace.ToArray(),state=State()});}File.WriteAllText(args[2],JsonSerializer.Serialize(new{scope="ACTUAL_RAW_CIL_TWO_LIFECYCLE_CALLERS_WITH_EXPLICIT_FINITE_LEAF_CONTRACTS_NOT_GAMEPLAY",candidate_sha256=Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant(),results=rows},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine("R27_ACTUAL_RAW_CIL_EXECUTED "+rows.Count);}
}
