"""Pinned R25 parent and original PC inputs and original PC evidence. No test suite is invoked."""
from pathlib import Path
import hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile,pefile
from capstone import Cs,CS_ARCH_X86,CS_MODE_64,CS_GRP_RET,CS_GRP_JUMP
from capstone.x86_const import X86_OP_IMM
sha=lambda b:hashlib.sha256(b).hexdigest()
parent=(W/'startup-r25-plant-visual-lifecycle/authored1.dll').read_bytes();assert sha(parent)=='9490c1845298fa5afda04fc8dfba915ce2a939eaebe96be83e3311b39557bc4c';pe=dnfile.dnPE(data=parent)
cil=json.loads((W/'startup-r25-plant-visual-lifecycle/shared-authored1/ALL-CIL.json').read_bytes());methods={m['token']:m for m in cil['methods']}
I=ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs';raw=(I/'original-pc/GameAssembly.dll').read_bytes();assert sha(raw)=='9ebd7ca996a5b03fb4a766f7a2502b660d581ddbbb36af4d7bf2f06a211da39d';pc=pefile.PE(data=raw);base=pc.OPTIONAL_HEADER.ImageBase
field_rows=json.loads((I/'maps/native-fields.json').read_bytes());dis=Cs(CS_ARCH_X86,CS_MODE_64);dis.detail=True
def tok(rid):return f'0x{0x6000000|rid:08X}'
def pointer(token):
 rid=int(token,16)&0xffffff;assert 1<=rid<=2316,'Injected helper has no original PC pointer';return int.from_bytes(pc.get_data(0x181b82d60-base+(rid-1)*8,8),'little')
pointers={tok(rid):pointer(tok(rid)) for rid in range(1,2317)}
def body(token):
 r=pe.net.mdtables.MethodDef.rows[(int(token,16)&0xffffff)-1];at=pe.get_offset_from_rva(r.Rva);h=1 if parent[at]&3==2 else (struct.unpack_from('<H',parent,at)[0]>>12)*4;n=parent[at]>>2 if h==1 else struct.unpack_from('<I',parent,at+4)[0];return dict(offset=at,header=h,code_size=n,code=parent[at+h:at+h+n])
def operand_token(token,ins):
 b=body(token)['code'];at=ins['offset'];return int.from_bytes(b[at+(2 if b[at]==0xfe else 1):at+(2 if b[at]==0xfe else 1)+4],'little')
def native(token):
 entry=pointer(token);assert entry;fn=next((x.struct for x in pc.DIRECTORY_ENTRY_EXCEPTION if x.struct.BeginAddress<=entry-base<x.struct.EndAddress),None);end=min(p for p in pointers.values() if p>entry);pending=[entry];ins={};outside=[];indirect=[]
 while pending:
  at=pending.pop()
  while at not in ins:
   if not entry<=at<end:outside.append(dict(target=hex(at)));break
   i=next(dis.disasm(pc.get_data(at-base,15),at));ins[at]=i;assert len(ins)<=end-entry, "Unique instruction count exceeds the pointer-bounded byte span"
   if i.group(CS_GRP_RET) or i.mnemonic in ['int3','ud2']:break
   if i.group(CS_GRP_JUMP):
    if i.operands[0].type==X86_OP_IMM:
     target=i.operands[0].imm
     if entry<=target<end:pending.append(target)
     else:outside.append(dict(source=hex(at),target=hex(target),kind='EXTERNAL_TAIL_OR_SEPARATE_FUNCLET'))
    else:indirect.append(dict(source=hex(at),operand=i.op_str))
    if i.mnemonic=='jmp':break
   at+=i.size
 return dict(token=token,entry=hex(entry),runtime_end=hex(base+fn.EndAddress) if fn is not None else None,next_distinct_method_pointer=hex(end),scope='COMPLETE_POINTER_BOUNDED_CFG_WITH_EXTERNAL_BOUNDARIES_RETAINED',instructions=[dict(va=hex(i.address),op=i.mnemonic,operands=i.op_str,bytes=i.bytes.hex()) for i in sorted(ins.values(),key=lambda i:i.address)],outside_boundaries=outside,indirect_jumps=indirect)
def save_native(rid):
 token=tok(rid);d=Q/'native-source-complete';d.mkdir(exist_ok=True);j=native(token);(d/(token+'.json')).write_text(json.dumps(j,indent=2)+'\n',encoding='utf-8');(d/(token+'.txt')).write_text('\n'.join(i['va']+' '+i['op']+' '+i['operands'] for i in j['instructions'])+'\n',encoding='utf-8');return j
