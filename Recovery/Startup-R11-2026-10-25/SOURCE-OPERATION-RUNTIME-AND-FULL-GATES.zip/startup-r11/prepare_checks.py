"""Input/output-only derivatives of the existing readonly and runtime drivers."""
from pathlib import Path
import hashlib,json,shutil
Q=Path(__file__).resolve().parent;W=Q.parent;rows=[];sha=lambda b:hashlib.sha256(b).hexdigest();old='9f030dc1c48e6d77e854979091a223fb636c93b1b528b8c6b9fbb2397a34d72e';new='e101c701802969bffe370841abc92cd01ec75592097d60b2b9e3629c5c107637'
for name in ['full_type_census_r10.py','interface_facts_r10.py','census_lexical_tails.py','full_member_access.py']:
    src=W/'startup-r10'/name;b=src.read_bytes();text=b.decode().replace(old,new).replace("Q=W/'startup-r10'","Q=W/'startup-r11'").replace("Q/'candidate3.dll'","Q/'candidate1.dll'")
    out=Q/name.replace('_r10','_r11');out.write_bytes(text.encode());rows.append(dict(source=str(src.relative_to(W)),source_sha256=sha(b),derived=str(out.relative_to(W)),derived_sha256=sha(out.read_bytes()),changes='Exact candidate hash/path and output only'))
shutil.copy2(W/'startup-r10/ALL-METHODS.json',Q/'ALL-METHODS.json')
src=W/'startup-r10/run_all_exact_jit.py';b=src.read_bytes();text=b.decode().replace(old,new).replace("Q/'candidate3.dll'","Q/'candidate1.dll'").replace("O=Q/'all-exact-jit-results'","O=Q/'changed-exact-jit-results'")
text=text.replace("W/'startup-r6/ALL-METHODS.json'","Q/'METHODS.json'").replace('len(tokens)==2297','len(tokens)==47').replace('WHOLE_ASSEMBLY_EXACT_CLR_JIT_PRECHECK_NO_GAMEPLAY_EXECUTION','CHANGED_47_EXACT_CLR_JIT_PRECHECK_NO_GAMEPLAY_EXECUTION')
out=Q/'run_changed_exact_jit.py';out.write_bytes(text.encode());rows.append(dict(source=str(src.relative_to(W)),source_sha256=sha(b),derived=str(out.relative_to(W)),derived_sha256=sha(out.read_bytes()),changes='Exact child and changed-47 scope/output only; previous whole-assembly result remains R10-bound'))
src=W/'startup-r10/run_runtime.py';b=src.read_bytes();text=b.decode().replace(old,new)
text=text.replace("Q=Path(__file__).resolve().parent;ROOT=Q.parents[2];O=Q/'runtime-results'","Q=Path(__file__).resolve().parent.parent/'startup-r10';ROOT=Q.parents[2];O=Q.parent/'startup-r11/nut-runtime-results'")
text=text.replace("candidate=Q/'candidate3.dll'","candidate=Q.parent/'startup-r11/candidate1.dll'").replace('from portable_guard import verify as verify_guard',"sys.path.insert(0,str(Q));from portable_guard import verify as verify_guard")
out=Q/'run_prior_nut.py';out.write_bytes(text.encode());rows.append(dict(source=str(src.relative_to(W)),source_sha256=sha(b),derived=str(out.relative_to(W)),derived_sha256=sha(out.read_bytes()),changes='Only exact child, immutable R10 source assets, current output and guard-module path'))
src=W/'startup-r10/run_prior_regressions.py';b=src.read_bytes();text=b.decode().replace(old,new).replace("candidate=Q/'candidate3.dll'","candidate=Q/'candidate1.dll'").replace("new=json.loads((Q/'runtime-results/RESULT.json')","new=json.loads((Q/'nut-runtime-results/RESULT.json')").replace('startup-r10/candidate3.dll','startup-r11/candidate1.dll').replace('startup-r10','startup-r11')
out=Q/'run_prior_regressions.py';out.write_bytes(text.encode());rows.append(dict(source=str(src.relative_to(W)),source_sha256=sha(b),derived=str(out.relative_to(W)),derived_sha256=sha(out.read_bytes()),changes='Only exact child and prior 13 method output binding'))
(Q/'DRIVER-DERIVATION.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode());print('Prepared',len(rows),'explicit input/output derivatives')
