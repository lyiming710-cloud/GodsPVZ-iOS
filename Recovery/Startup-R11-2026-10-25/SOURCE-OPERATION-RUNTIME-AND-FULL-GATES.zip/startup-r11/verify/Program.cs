using System.Reflection;using System.Security.Cryptography;using System.Text.Json;using Mono.Cecil;using Mono.Cecil.Cil;
public sealed class Box{public int _size,m_Value;public float m_FillAmount;public bool m_Interactable;public object? m_OnSubmit,m_textInfo;}
public static class Program
{
    static readonly List<string> Trace=[];static bool Answer;
    public static bool Key(int k){Trace.Add(k.ToString());return Answer;}
    static string Hash(string p)=>Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(p))).ToLowerInvariant();
    static bool Same(MemberReference a,MemberReference b)
    {
        var x=a is FieldReference f?(MemberReference)f.Resolve():((MethodReference)a).Resolve();var y=b is FieldReference g?(MemberReference)g.Resolve():((MethodReference)b).Resolve();
        return x.MetadataToken==y.MetadataToken&&x.Module.Assembly.Name.FullName==y.Module.Assembly.Name.FullName;
    }
    static void Require(bool value,string message){if(!value)throw new InvalidOperationException(message);}
    static bool Eq(object? a,object? b)=>a is float x&&b is float y?BitConverter.SingleToInt32Bits(x)==BitConverter.SingleToInt32Bits(y):a is object&&a.GetType()==typeof(object)?ReferenceEquals(a,b):Equals(a,b);
    static (object? value,string? error) Invoke(MethodInfo method,object?[] args)
    {
        try{return(method.Invoke(null,args),null);}catch(TargetInvocationException e){return(null,e.InnerException!.GetType().FullName);}
    }
    public static void Main(string[] args)
    {
        var resolver=new DefaultAssemblyResolver();resolver.AddSearchDirectory(args[2]);var rp=new ReaderParameters{AssemblyResolver=resolver};using var parent=ModuleDefinition.ReadModule(args[0],rp);using var child=ModuleDefinition.ReadModule(args[1],rp);var rows=new List<object>();var operations=new List<object>();int changedMethods=0,cases=0;
        var types=new List<TypeDefinition>();void Add(TypeDefinition t){types.Add(t);foreach(var n in t.NestedTypes)Add(n);}foreach(var t in parent.Types)Add(t);
        foreach(var old in types.SelectMany(t=>t.Methods).Where(m=>m.HasBody))
        {
            var now=(MethodDefinition)child.LookupToken(old.MetadataToken);Require(old.RVA==now.RVA&&old.Body.CodeSize==now.Body.CodeSize&&old.Body.MaxStackSize==now.Body.MaxStackSize&&old.Body.LocalVarToken==now.Body.LocalVarToken&&old.Body.Instructions.Count==now.Body.Instructions.Count,"Changed caller body form");
            bool changed=false;
            for(int k=0;k<old.Body.Instructions.Count;k++)
            {
                var a=old.Body.Instructions[k];var b=now.Body.Instructions[k];Require(a.Offset==b.Offset,"Changed instruction offset");
                string Operand(Instruction i)=>i.Operand?.ToString()??"";
                if(a.OpCode==b.OpCode&&Operand(a)==Operand(b))continue;
                Require(!old.IsConstructor&&a.OpCode.Code is Code.Ldfld or Code.Call&&b.OpCode.Code==Code.Call&&b.Operand is MethodReference,"Unexpected rewrite");
                var target=((MethodReference)b.Operand).Resolve();Require(target.IsPublic&&(!target.IsVirtual||target.IsFinal)&&target.HasBody&&target.Body.ExceptionHandlers.Count==0,"Target is not public sealed/direct CIL");
                var body=target.Body.Instructions.Where(i=>i.OpCode.Code!=Code.Nop).ToArray();Require(body.Length==3||body.Length==6,"Not an exact leaf contract");
                Require(body[0].OpCode.Code==Code.Ldarg_0&&body[1].OpCode.Code==(a.OpCode.Code==Code.Ldfld?Code.Ldfld:Code.Call)&&body[1].Operand is MemberReference,"Not a direct read/forward");
                Require(Same((MemberReference)a.Operand,(MemberReference)body[1].Operand),"Public accessor forwards to different private member");
                if(body.Length==3)Require(body[2].OpCode.Code==Code.Ret,"Wrong leaf return");
                else Require(body[2].OpCode.Code==Code.Stloc_0&&body[3].OpCode.Code is Code.Br or Code.Br_S&&body[3].Operand==body[4]&&body[4].OpCode.Code==Code.Ldloc_0&&body[5].OpCode.Code==Code.Ret,"Nontrivial debug getter control flow");
                var owner=((MemberReference)a.Operand).DeclaringType;Require(owner.FullName==((MethodReference)b.Operand).DeclaringType.FullName,"Changed closed owner/instantiation");
                Type Map(TypeReference t)
                {
                    if(t.FullName=="System.Void")return typeof(void);if(t.FullName=="System.Int32"||t.FullName=="UnityEngine.KeyCode")return typeof(int);if(t.FullName=="System.Single")return typeof(float);if(t.FullName=="System.Boolean")return typeof(bool);
                    if(t.GetElementType().FullName==target.DeclaringType.FullName)return typeof(Box);
                    if(t.FullName is "TMPro.TMP_InputField/SubmitEvent" or "TMPro.TMP_TextInfo")return typeof(object);
                    throw new NotSupportedException(t.FullName);
                }
                FieldInfo Field(FieldReference f)=>typeof(Box).GetField(f.Name)??throw new NotSupportedException(f.FullName);
                MethodBase Method(MethodReference m){Require(Same(m,(MemberReference)a.Operand),"Unexpected nested callee");return typeof(Program).GetMethod(nameof(Key))!;}
                var emitted=ActualCil.Emit(target,Map,Field,Method);int siteCases=0;var witnessRows=new List<object>();
                if(a.Operand is FieldReference field)
                {
                    Require(!target.IsStatic&&target.Parameters.Count==0,"Getter signature changed");var info=Field(field);object?[] values=info.FieldType==typeof(int)?[-2147483648,-1,0,1,2,2147483647]:info.FieldType==typeof(bool)?[false,true]:info.FieldType==typeof(float)?new uint[]{0,0x80000000,0x3f800000,0xbf800000,0x7f7fffff,0x7f800000,0xff800000,0x7fc00001}.Select(x=>(object)BitConverter.Int32BitsToSingle(unchecked((int)x))).ToArray():[null,new object(),new object()];
                    foreach(var value in values){var box=new Box();info.SetValue(box,value);var got=Invoke(emitted,[box]);Require(got.error==null&&Eq(info.GetValue(box),got.value),"Getter value divergence");siteCases++;}
                    var null_=Invoke(emitted,[null]);Require(null_.error=="System.NullReferenceException","Null receiver contract changed");siteCases++;
                }
                else
                {
                    Require(target.IsStatic&&target.Parameters.Count==1&&target.ReturnType.FullName=="System.Boolean","Forwarder signature changed");
                    foreach(int value in new[]{int.MinValue,-1,0,1,32,int.MaxValue})foreach(bool answer in new[]{false,true}){Answer=answer;Trace.Clear();var got=Invoke(emitted,[value]);Require(got.error==null&&Equals(got.value,answer)&&Trace.SequenceEqual(new[]{value.ToString()}),"Forwarder argument/result/call-count divergence");siteCases++;}
                }
                rows.Add(new{token="0x"+old.MetadataToken.ToUInt32().ToString("X8"),caller=old.FullName,offset=a.Offset,before_op=a.OpCode.Name,before_member=Operand(a),after_member=Operand(b),old_operand_token="0x"+((IMetadataTokenProvider)a.Operand).MetadataToken.ToUInt32().ToString("X8"),new_operand_token="0x"+((IMetadataTokenProvider)b.Operand).MetadataToken.ToUInt32().ToString("X8"),target=target.FullName,contract_module_sha256=Hash(target.Module.FileName),target.IsVirtual,target.IsFinal,target.DeclaringType.IsBeforeFieldInit,has_type_initializer=target.DeclaringType.Methods.Any(m=>m.IsConstructor&&m.IsStatic),operation_cases=siteCases});
                cases+=siteCases;changed=true;
            }
            if(changed)changedMethods++;
        }
        Require(rows.Count==71&&changedMethods==47,"Exact reviewed substitution scope not restored");
        File.WriteAllText(args[3],JsonSerializer.Serialize(new{scope="INDEPENDENT_ACTUAL_CIL_LEAF_CONTRACT_AND_ISOLATED_OPERATION_EXECUTION_NOT_FULL_CALLERS",parent_sha256=Hash(args[0]),candidate_sha256=Hash(args[1]),pass_=true,methods=changedMethods,sites=rows.Count,operation_cases=cases,all_leaf_instructions_emitted=true,full_original_native_caller_execution=false,whole_game_acceptance=false,rows},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{pass=true,methods=changedMethods,sites=rows.Count,operation_cases=cases}));
    }
}
