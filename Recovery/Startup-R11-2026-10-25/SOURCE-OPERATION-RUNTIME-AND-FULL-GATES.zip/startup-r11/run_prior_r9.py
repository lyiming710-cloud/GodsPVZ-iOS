from pathlib import Path
import hashlib,itertools,json,random,struct,subprocess,sys
Q=Path(__file__).resolve().parent.parent/'startup-r9';W=Q.parent;ROOT=W.parents[1];O=W/'startup-r11/r9-runtime-results';O.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'));import dnfile
raw=(W/'startup-r11/candidate1.dll').read_bytes();digest=hashlib.sha256(raw).hexdigest();assert digest=='e101c701802969bffe370841abc92cd01ec75592097d60b2b9e3629c5c107637'
frames=[0,0x80000000,0x3f800000,0xbf800000,0x4479e000,0x447a0000,0x447a4000,0xc47a1000,0x7f7fffff,0xff7fffff,1,0x80000001,0x7fc00001]
rng=random.Random(9017)
while len(frames)<38:
    v=rng.getrandbits(32)
    if v&0x7f800000!=0x7f800000:frames.append(v)
cases=[dict(name='case-'+str(n),frame=f'{f:08X}',delta=d,callback=c) for n,(f,d,c) in enumerate(itertools.product(frames,['00000000','80000000','3DCCCCCD','BDCCCCCD','7FC00000','7F800000'],['none','mutate-frame-on-text','mutate-frame-on-time','replace-text-on-text']))]
(O/'CASES.json').write_bytes((json.dumps(cases,indent=2)+'\n').encode())
dot=ROOT/'.local/dotnet10/dotnet.exe';fixture=Q/'runtime/bin/Release/net10.0/Fixture.dll'
def run(label,args):
    p=subprocess.run([str(x) for x in args],capture_output=True);(O/(label+'.stdout.log')).write_bytes(p.stdout);(O/(label+'.stderr.log')).write_bytes(p.stderr)
    if p.returncode:raise RuntimeError(f'{label} exit={p.returncode}: '+p.stderr.decode('utf-8','replace')[:1000])
run('native',[sys.executable,Q/'native_oracle.py',O/'CASES.json',O/'NATIVE.json']);run('actual-cil',[dot,fixture,W/'startup-r11/candidate1.dll',O/'CASES.json',O/'ACTUAL-CIL.json'])
a=json.loads((O/'NATIVE.json').read_bytes());b=json.loads((O/'ACTUAL-CIL.json').read_bytes());assert len(a['constants'])==len(b['constants'])==80 and len(a['results'])==len(b['results'])==912
baseline=a['constants']+a['results'];actual=b['constants']+b['results'];differences=[dict(name=x['name'],native=x,cil=y) for x,y in zip(baseline,actual) if x!=y]
assert b['managed_null_text_control']==dict(error='System.NullReferenceException',frame='3F800000',native_exception_execution=False)
pe=dnfile.dnPE(data=raw)
def body(rid):
    p=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[rid-1].Rva);return p+(1 if raw[p]&3==2 else (struct.unpack_from('<H',raw,p)[0]>>12)*4)
start=body(0x76d);method=next(c for c in json.loads((Q/'CONSTRUCTION.json').read_bytes())['changes'] if c['token']=='0x0600076D');code=bytes.fromhex(method['new_code']);mutants={}
m=bytearray(raw);bool_rids=[0xd5,0xd6,0x312,0x35a,0x489]
for p in {body(rid) for rid in bool_rids}:
    assert raw[p] in [0x16,0x17];m[p]=0x17 if raw[p]==0x16 else 0x16
for rid in bool_rids:assert m[body(rid)]==(0x17 if raw[body(rid)]==0x16 else 0x16)
mutants['all-five-native-bools-inverted']=bytes(m)
m=bytearray(raw);pos=code.index(b'\x22'+struct.pack('<f',1000.0)+b'\x5d\x6f')+5;m[start+pos]=0x58;mutants['remainder-replaced-by-addition']=bytes(m)
assert code[12]==0x7b;frame=code[13:17];delta=code[code.index(b'\x0b\x28')+2:code.index(b'\x0b\x28')+6];span=b'\x02\x7b'+frame+b'\x0b\x28'+delta+b'\x07';pos=code.index(span);assert len(span)==13
m=bytearray(raw);m[start+pos:start+pos+13]=b'\x28'+delta+b'\x02\x7b'+frame+b'\0\0';mutants['frame-reloaded-after-delta-callback']=bytes(m)
m=bytearray(raw);assert code[-6:-1]==b'\x7d'+frame;m[start+len(code)-6:start+len(code)-1]=bytes.fromhex('2626000000');mutants['frame-write-omitted']=bytes(m)
controls=[]
for name,data in mutants.items():
    dll=O/(name+'.dll');dll.write_bytes(data);run(name,[dot,fixture,dll,O/'CASES.json',O/(name+'.json')]);r=json.loads((O/(name+'.json')).read_bytes());rows=r['constants']+r['results'];detected=sum(x!=y for x,y in zip(baseline,rows))
    controls.append(dict(name=name,mutant_sha256=hashlib.sha256(data).hexdigest(),detected_cases=detected,baseline_pass=not differences,pass_=not differences and detected>0))
report=dict(scope='FIVE_ORIGINAL_PC_CONSTANT_METHODS_AND_SIMPLE_CALLER_VALUE_TRACE_EQUIVALENCE_CONTROLLED_TEXT_TIME',candidate_sha256=digest,constant_methods=5,constant_cases=80,simple_cases=912,
    pass_=not differences and all(c['pass_'] for c in controls),differences=differences,negative_controls=controls,original_fmod_helper_executed=True,managed_null_text_control=b['managed_null_text_control'],
    native_exception_unwind=False,crt_errno_domain_behavior=False,actual_tmp_formatting=False,nan_payload_equivalence=False,unity_execution=False,whole_game_acceptance=False)
(O/'RESULT.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({**report,'differences':differences[:4]},indent=2));assert report['pass_']
