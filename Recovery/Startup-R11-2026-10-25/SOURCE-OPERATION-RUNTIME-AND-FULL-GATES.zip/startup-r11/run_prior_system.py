from pathlib import Path
import hashlib,json,subprocess,sys,struct,itertools
Q=Path(__file__).resolve().parent.parent/'startup-r5';ROOT=Q.parents[2];OUT=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else Q.parent/'startup-r6/system-runtime-results';OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'));import dnfile
cases=[]
for name,value in itertools.product(['0','1','2','x','',None,' 1 ','+1','2147483648'],['0','1','-1','2147483647','-2147483648','2147483648','x','',None,'1.5','+3',' 7 ']):
    cases.append(dict(name='parse-'+str(len(cases)),input_name=name,text=value,callback='none'))
for callback in ['replace-config-on-name','mutate-text-on-name']:
    for name in ['0','2']:cases.append(dict(name=callback+'-'+name,input_name=name,text='19',callback=callback))
(OUT/'CASES.json').write_bytes((json.dumps(cases,indent=2)+'\n').encode())
dot=ROOT/'.local/dotnet10/dotnet.exe';fixture=Q/'runtime-system/bin/Release/net10.0/Fixture.dll';candidate=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Q.parent/'startup-r6/candidate1.dll';raw=candidate.read_bytes();sha=hashlib.sha256(raw).hexdigest()
assert sha in ['c36092b5326687112adfa8c285bb3cf5e8ad46d3b3de8ebcd84daf598041465d','22d6aa537bfb71e40dcfa0fdd8776566278cf8fd9a4d4212a93fb7d49d3a8655','6189387c6af11108eba9a9855bfd6d6af567ec000a4999d1ed1b0328ba0e1d08','738ebc37ebdea606011294728ffeaa6a2128d19417905856729efe5947f5577e','e101c701802969bffe370841abc92cd01ec75592097d60b2b9e3629c5c107637']
def run(label,args):
    p=subprocess.run(args,capture_output=True);(OUT/(label+'.stdout.log')).write_bytes(p.stdout);(OUT/(label+'.stderr.log')).write_bytes(p.stderr)
    if p.returncode:raise RuntimeError(f'{label} exit={p.returncode}: '+p.stderr.decode('utf-8','replace')[:800])
run('native',[sys.executable,str(Q/'native_system_oracle.py'),str(OUT/'CASES.json'),str(OUT/'NATIVE.json')])
run('actual-cil',[str(dot),str(fixture),str(candidate),str(OUT/'CASES.json'),str(OUT/'ACTUAL-CIL.json')])
native=json.loads((OUT/'NATIVE.json').read_bytes())['results'];cil=json.loads((OUT/'ACTUAL-CIL.json').read_bytes())['results'];assert len(native)==len(cil)==len(cases)
diff=[dict(name=a['name'],native=a,cil=b) for a,b in zip(native,cil) if a!=b]
pe=dnfile.dnPE(data=raw);start=pe.get_offset_from_rva(pe.net.mdtables.MethodDef.rows[0x89-1].Rva);body=start+(struct.unpack_from('<H',raw,start)[0]>>12)*4
mutants={}
b=bytearray(raw);assert b[body+74]==0x28;b[body+75:body+79]=raw[body+10:body+14];mutants['name-used-instead-of-text']=bytes(b)
b=bytearray(raw);assert b[body+186:body+188]==bytes.fromhex('fe0c');struct.pack_into('<H',b,body+188,3);mutants['row-index-used-instead-of-value']=bytes(b)
b=bytearray(raw);b[body:body+5]=b'\x2a\0\0\0\0';mutants['early-return']=bytes(b)
b=bytearray(raw);assert b[body+190]==0x7d;b[body+190:body+195]=bytes.fromhex('2626000000');mutants['row-write-omitted']=bytes(b)
controls=[]
def control(name,dll,digest):
    run(name,[str(dot),str(fixture),str(dll),str(OUT/'CASES.json'),str(OUT/(name+'.json'))]);r=json.loads((OUT/(name+'.json')).read_bytes())['results'];detected=sum(a!=b for a,b in zip(native,r));controls.append(dict(name=name,mutant_sha256=digest,detected_cases=detected,baseline_pass=not diff,pass_=not diff and detected>0))
for name,data in mutants.items():
    dll=OUT/(name+'.dll');dll.write_bytes(data);control(name,dll,hashlib.sha256(data).hexdigest())
parent=Q.parent/'startup-r3/candidate1.dll';control('damaged-parent-private-text-read',parent,hashlib.sha256(parent.read_bytes()).hexdigest())
report=dict(scope='SYSTEM2_ACTUAL_CIL_VS_ORIGINAL_PC_NATIVE_CONTROLLED_NORMAL_PATHS_ONLY',candidate_sha256=sha,method_token='0x06000089',cases=len(cases),
            pass_=not diff and all(c['pass_'] for c in controls),differences=diff,negative_controls=controls,exceptions_native_unwind_modeled=False,log_text_equivalence=False,unity_execution=False,whole_six_method_acceptance=False)
(OUT/'RESULT.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({**report,'differences':diff[:4]},indent=2));assert report['pass_']
