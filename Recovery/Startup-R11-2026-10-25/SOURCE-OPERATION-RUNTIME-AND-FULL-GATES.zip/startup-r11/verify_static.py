"""Independent all-MethodDef/raw append isolation and exact changed-call tests.

Does not read the constructor report. Actual changed-site rows come from the
separate Cecil walker and complete leaf-CIL execution against controlled state.
"""
from pathlib import Path
import collections,hashlib,importlib.util,json,struct,subprocess,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
sha=lambda b:hashlib.sha256(b).hexdigest()
def mod(n,p):s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
writer=mod('metadata_reader',W/'startup-r2/construct.py');raw=mod('body_reader',ROOT/'audit/native111-publication-2026-10-20/repository/scripts/actions/static_gates.py')
f=ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py';assert sha(f.read_bytes())=='2bb0a8c229a63fd33269433759a587ff551c6fde19669bafc506033df9b63d14';checker=mod('unchanged_frozen',f)
a=(W/'startup-r10/candidate3.dll').read_bytes();b=(Q/'candidate1.dll').read_bytes();assert sha(a)=='9f030dc1c48e6d77e854979091a223fb636c93b1b528b8c6b9fbb2397a34d72e' and b==(Q/'candidate2.dll').read_bytes()
proof=json.loads((Q/'INDEPENDENT-OPERATION-TEST.json').read_bytes());assert proof['pass_'] and proof['candidate_sha256']==sha(b) and proof['sites']==71 and proof['methods']==47
pp=dnfile.dnPE(data=a);cp=dnfile.dnPE(data=b)
def meta(data,p):
    cli=p.get_offset_from_rva(p.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress);rva,size=struct.unpack_from('<II',data,cli+8);at=p.get_offset_from_rva(rva);_,streams=writer.metadata_root(data[at:at+size]);v={n:x for n,_,x in streams};_,rows,_,counts=writer.tables_decode(v['#~']);return v,rows,counts
pv,pr,pc=meta(a,pp);cv,cr,cc=meta(b,cp)
assert set(pr)==set(cr) and set(pv)==set(cv)
for t in pr:
    if t==10:assert cr[t][:len(pr[t])]==pr[t] and len(cr[t])==len(pr[t])+4
    else:assert pr[t]==cr[t],t
for n in pv:
    if n in ['#Strings','#Blob']:assert cv[n].startswith(pv[n])
    elif n!='#~':assert cv[n]==pv[n]
sites={};tokens={r['token'] for r in proof['rows']}
for r in proof['rows']:
    rid=int(r['token'],16)&0xffffff;p=pp.get_offset_from_rva(pp.net.mdtables.MethodDef.rows[rid-1].Rva);head=1 if a[p]&3==2 else (struct.unpack_from('<H',a,p)[0]>>12)*4;at=p+head+r['offset']
    assert a[at]==(0x7b if r['before_op']=='ldfld' else 0x28) and b[at]==0x28
    assert int.from_bytes(a[at+1:at+5],'little')==int(r['old_operand_token'],16) and int.from_bytes(b[at+1:at+5],'little')==int(r['new_operand_token'],16)
    sites[at]=r
changed=[]
for rid,(x,y) in enumerate(zip(pp.net.mdtables.MethodDef.rows,cp.net.mdtables.MethodDef.rows),1):
    assert x.Rva==y.Rva
    if not x.Rva:continue
    at=pp.get_offset_from_rva(x.Rva);span=raw.parse_raw_method_body_span(a,at)[0];assert span==raw.parse_raw_method_body_span(b,at)[0]
    if a[at:at+span]!=b[at:at+span]:changed.append(f'0x{0x6000000|rid:08X}')
assert set(changed)==tokens and len(changed)==47
last=pp.sections[-1];sh=last.get_file_offset();opt=pp.OPTIONAL_HEADER.get_file_offset();cli=pp.get_offset_from_rva(pp.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress)
allowed={p+i for p in [sh+8,sh+16,opt+8,opt+56,opt+64,cli+8,cli+12] for i in range(4)}|{p+i for p in sites for i in range(5)}
def boundary(data):
    if len(data)!=len(b) or any(x!=y and i not in allowed for i,(x,y) in enumerate(zip(a,data))):raise ValueError('Unexpected non-target mutation')
boundary(b);controls=[]
for name,at in [('unrelated-original-code',pp.get_offset_from_rva(pp.net.mdtables.MethodDef.rows[0x526-1].Rva)+12),('old-metadata',pp.get_offset_from_rva(pp.net.struct.MetaDataRva))]:
    m=bytearray(b);m[at]^=1
    try:boundary(m)
    except ValueError:controls.append(dict(name=name,rejected=True));continue
    raise AssertionError('Isolation false accept')
DOT=ROOT/'.local/dotnet10/dotnet.exe';SUP=ROOT/'audit/bulk350-root-verification-2026-10-22/authentic-support';EXP=ROOT/'audit/bulk250-r1-evidence-39702928368/bulk250-r1-run/tools_bin/CilExporter/bin/CilExporter.dll';O=Q/'negative-controls';O.mkdir(exist_ok=True)
def run(label,args,want=0):
    p=subprocess.run([str(x) for x in args],capture_output=True,timeout=120);(O/(label+'.stdout.log')).write_bytes(p.stdout);(O/(label+'.stderr.log')).write_bytes(p.stderr);assert (p.returncode==0)==(want==0),(label,p.returncode,p.stderr[-800:]);return p
run('baseline-export',[DOT,EXP,Q/'candidate1.dll',Q/'CHANGED-CIL.json',SUP,','.join(sorted(tokens))]);cil=json.loads((Q/'CHANGED-CIL.json').read_text('utf-8-sig'));typed=[checker.verify(m,cil['types']) for m in cil['methods']];assert all(r['status']=='PASS' for r in typed)
# Same signature/public visibility, wrong key event. Only the leaf contract
# check catches the semantic difference; legality alone is insufficient.
at,r=next((p,r) for p,r in sites.items() if 'Input::GetKeyInt' in r['before_member']);down=next(x for x in proof['rows'] if 'Input::GetKeyDownInt' in x['before_member']);m=bytearray(b);m[at+1:at+5]=struct.pack('<I',int(down['new_operand_token'],16));wrong=O/'wrong-public-key-event.dll';wrong.write_bytes(m)
p=run('wrong-key-contract',[DOT,Q/'verify/bin/Release/net10.0/Verify.dll',W/'startup-r10/candidate3.dll',wrong,SUP,O/'wrong-key-report.json'],want=1);assert b'forwards to different private member' in p.stderr
run('wrong-key-export',[DOT,EXP,wrong,O/'WRONG-KEY-CIL.json',SUP,r['token']]);c=json.loads((O/'WRONG-KEY-CIL.json').read_text('utf-8-sig'));assert checker.verify(c['methods'][0],c['types'])['status']=='PASS'
controls.append(dict(name='wrong-public-key-event',mutant_sha256=sha(m),unchanged_type_gate='PASS_NOT_BEHAVIORAL_EVIDENCE',contract_gate_rejected=True))
# Restore one actual private-field read. Stack types remain legal, visibility
# must reject it even though the field value matches the public getter.
at,r=next((p,r) for p,r in sites.items() if 'Image::m_FillAmount' in r['before_member']);m=bytearray(b);m[at:at+5]=a[at:at+5];private=O/'private-field-restored.dll';private.write_bytes(m)
one=O/'ONE-METHOD.json';one.write_text(json.dumps(dict(methods=[dict(token=r['token'])])))
p=run('private-access-control',[DOT,ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/member-bin/MemberAccess.dll',private,SUP,one,O/'PRIVATE-ACCESS.json'],want=1);v=json.loads((O/'PRIVATE-ACCESS.json').read_bytes());assert any(not x['allowed'] and x.get('offset')==r['offset'] for x in v['members'])
controls.append(dict(name='private-field-restored',mutant_sha256=sha(m),auditor_exit=p.returncode,rejected=True))
report=dict(scope='ALL_METHODDEF_RAW_ISOLATION_AND_UNCHANGED_TYPE_AND_MEMBER_CONTRACT_GATES',candidate_sha256=sha(b),parent_sha256=sha(a),pass_=True,changed_methods=47,unchanged_methoddefs=2270,sites=71,method_headers_rvas_locals_maxstack_branches_eh_unchanged=True,old_metadata_rows_heaps_preserved=True,new_memberrefs=4,changed_method_type_results=typed,negative_controls=controls,operation_tests=532,full_47_callers_native_equivalence=False)
(Q/'ISOLATION-AND-GATES.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in report.items() if k!='changed_method_type_results'},indent=2))
