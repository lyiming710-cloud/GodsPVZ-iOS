"""Legalize fixed-width reads/calls using exact public pure SDK/game contracts.

Only methods passing the unchanged R10 type gate are selected. No constructor,
write, address, virtual-overridable getter, guessed property or algorithm edit.
This is operation-level substitution, not native equivalence of 47 full callers.
"""
from pathlib import Path
import hashlib,importlib.util,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;ROOT=W.parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'audit/stage9-native3/python-deps'))
import dnfile
s=importlib.util.spec_from_file_location('raw_writer',W/'startup-r2/construct.py');writer=importlib.util.module_from_spec(s);s.loader.exec_module(writer)
sha=lambda b:hashlib.sha256(b).hexdigest()
def compressed(n):
    if n<128:return bytes([n])
    if n<16384:return (0x8000|n).to_bytes(2,'big')
    assert n<0x20000000;return (0xc0000000|n).to_bytes(4,'big')
def build(output,report):
    output=Path(output);report=Path(report);assert not output.exists() and not report.exists()
    before=(W/'startup-r10/candidate3.dll').read_bytes();assert sha(before)=='9f030dc1c48e6d77e854979091a223fb636c93b1b528b8c6b9fbb2397a34d72e';pe=dnfile.dnPE(data=before)
    evidence=json.loads((Q/'PURE-CONTRACTS.json').read_bytes());assert evidence['candidate_sha256']==sha(before)
    typed=json.loads((W/'startup-r10/FROZEN-WITH-INTERFACE-FACTS.json').read_bytes());assert typed['candidate_sha256']==sha(before)
    passed={r['token'] for r in typed['results'] if r['status']=='PASS'}
    sites=[r for r in evidence['rows'] if len(r['matches'])==1 and r['token'] in passed];assert len(sites)==71 and len({r['token'] for r in sites})==47
    target_rids={int(r['token'],16)&0xffffff for r in sites}
    aliases={}
    for rid,row in enumerate(pe.net.mdtables.MethodDef.rows,1):
        if row.Rva:aliases.setdefault(row.Rva,[]).append(rid)
    for rid in target_rids:assert set(aliases[pe.net.mdtables.MethodDef.rows[rid-1].Rva])<=target_rids,'Unselected physical body alias'
    cli=pe.get_offset_from_rva(pe.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress);meta_rva,meta_size=struct.unpack_from('<II',before,cli+8);meta_at=pe.get_offset_from_rva(meta_rva)
    root,streams=writer.metadata_root(before[meta_at:meta_at+meta_size]);values={n:b for n,_,b in streams};th,rows,tail,counts=writer.tables_decode(values['#~'])
    original_strings=values['#Strings'];original_blob=values['#Blob'];new_refs=[];changes=[];out=bytearray(before);actual={}
    def name_index(name):
        b=name.encode()+b'\0';at=values['#Strings'].find(b)
        if at>=0 and (at==0 or values['#Strings'][at-1]==0):return at
        at=len(values['#Strings']);values['#Strings']+=b;return at
    def blob_index(blob):
        for row in pe.net.mdtables.MemberRef.rows:
            if row.Signature.value==blob:return row.struct.Signature_BlobIndex
        at=len(values['#Blob']);values['#Blob']+=compressed(len(blob))+blob;return at
    def string(at):return values['#Strings'][at:values['#Strings'].index(0,at)].decode()
    for site in sites:
        contract=site['matches'][0];module=Path(contract['module']);assert sha(module.read_bytes())==contract['module_sha256']
        assert contract['IsPublic'] and (not contract['IsVirtual'] or contract['IsFinal'])
        old_token=int(site['operand_token'],16);assert old_token>>24==10;old_ref=pe.net.mdtables.MemberRef.rows[(old_token&0xffffff)-1]
        old_row=rows[10][(old_token&0xffffff)-1];name=contract['FullName'].split('::',1)[1].split('(',1)[0]
        old_sig=old_ref.Signature.value
        if site['site_opcode']=='ldfld':assert old_sig[0]==6 and not contract['IsStatic'];signature=b'\x20\0'+old_sig[1:]
        else:assert site['site_opcode']=='call' and contract['IsStatic'];signature=old_sig
        key=(old_row[0],name,signature);new_token=None
        for rid,row in enumerate(rows[10],1):
            if row[0]!=key[0] or string(row[1])!=name:continue
            if rid<=counts[10]:sig=pe.net.mdtables.MemberRef.rows[rid-1].Signature.value
            else:sig=next(r['signature'] for r in new_refs if r['rid']==rid)
            if sig==signature:new_token=0x0a000000|rid;break
        if new_token is None:
            rows[10].append([old_row[0],name_index(name),blob_index(signature)]);rid=len(rows[10]);new_token=0x0a000000|rid
            new_refs.append(dict(rid=rid,class_coded_index=old_row[0],name=name,signature=signature))
        rid=int(site['token'],16)&0xffffff;method=pe.net.mdtables.MethodDef.rows[rid-1];at=pe.get_offset_from_rva(method.Rva);head=1 if before[at]&3==2 else (struct.unpack_from('<H',before,at)[0]>>12)*4;offset=at+head+site['offset']
        expected=bytes([0x7b if site['site_opcode']=='ldfld' else 0x28])+struct.pack('<I',old_token);replacement=b'\x28'+struct.pack('<I',new_token);assert before[offset:offset+5]==expected
        if offset in actual:assert actual[offset]==replacement
        actual[offset]=replacement;out[offset:offset+5]=replacement
        changes.append(dict(**site,new_memberref=f'0x{new_token:08X}',file_offset=offset,before=expected.hex(),after=replacement.hex(),contract_scope='PURE_OPERATION_SUBSTITUTION_NOT_FULL_CALLER_SEMANTIC_PROOF'))
    assert values['#Strings'].startswith(original_strings) and values['#Blob'].startswith(original_blob)
    values['#~']=writer.tables_encode(th,rows,tail,counts);metadata=bytearray(root)
    for name,h,_ in streams:
        start=writer.align(len(metadata),4);metadata.extend(b'\0'*(start-len(metadata)));struct.pack_into('<II',metadata,h,start,len(values[name]));metadata.extend(values[name])
    last=pe.sections[-1];assert last.Name.rstrip(b'\0')==b'.n29meta' and last.Characteristics==0x40000040 and last.PointerToRawData+last.SizeOfRawData==len(before)
    start=writer.align(len(out),4);out.extend(b'\0'*(start-len(out)));out.extend(metadata);end=len(out);size=writer.align(end-last.PointerToRawData,pe.OPTIONAL_HEADER.FileAlignment);out.extend(b'\0'*(last.PointerToRawData+size-len(out)))
    sh=last.get_file_offset();opt=pe.OPTIONAL_HEADER.get_file_offset();updates={sh+8:end-last.PointerToRawData,sh+16:size,opt+8:pe.OPTIONAL_HEADER.SizeOfInitializedData+size-last.SizeOfRawData,opt+56:writer.align(last.VirtualAddress+end-last.PointerToRawData,pe.OPTIONAL_HEADER.SectionAlignment),opt+64:0,cli+8:last.VirtualAddress+start-last.PointerToRawData,cli+12:len(metadata)}
    for at,v in updates.items():struct.pack_into('<I',out,at,v)
    allowed={at+i for at in updates for i in range(4)}|{at+i for at in actual for i in range(5)};assert all(a==b or i in allowed for i,(a,b) in enumerate(zip(before,out)))
    output.write_bytes(out);result=dict(scope='CONSTRUCTED_PURE_OPERATION_LEGALIZATION_NOT_FULL_CALLER_OR_GAME_ACCEPTANCE',parent_sha256=sha(before),candidate_sha256=sha(out),bytes=len(out),sites=len(changes),methods=len(target_rids),physical_sites=len(actual),new_memberrefs=len(new_refs),new_memberref_rows=[{**r,'signature':r['signature'].hex()} for r in new_refs],site_changes=changes,
        original_code_sizes_maxstack_locals_branches_eh_unchanged=True,field_visibility_unchanged=True,type_visibility_unchanged=True,old_metadata_rows_heaps_preserved=True,header_updates={str(k):v for k,v in updates.items()},full_47_original_native_callers_executed=False,runtime_operation_tests='PENDING',unity_or_ipa=False)
    report.write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in result.items() if k not in ['site_changes','new_memberref_rows','header_updates']},indent=2))
if __name__=='__main__':build(*sys.argv[1:])
