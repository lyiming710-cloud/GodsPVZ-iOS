using Mono.Cecil;using Mono.Cecil.Cil;using System.Security.Cryptography;using System.Text.Json;
var resolver=new DefaultAssemblyResolver();resolver.AddSearchDirectory(args[1]);using var asm=AssemblyDefinition.ReadAssembly(args[0],new ReaderParameters{AssemblyResolver=resolver});
string Hash(string p)=>Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(p))).ToLowerInvariant();
using var input=JsonDocument.Parse(File.ReadAllText(args[2]));var bad=input.RootElement.GetProperty("members").EnumerateArray().Where(x=>!x.GetProperty("allowed").GetBoolean()).ToArray();var rows=new List<object>();
bool Pure(MethodDefinition method,IMetadataTokenProvider target,bool call)
{
    if(!method.HasBody||(method.IsVirtual&&!method.IsFinal)||!method.IsPublic||method.Body.ExceptionHandlers.Count!=0)return false;
    var ins=method.Body.Instructions.Where(i=>i.OpCode.Code!=Code.Nop).ToArray();if(ins.Length<3)return false;
    if(ins[0].OpCode.Code!=Code.Ldarg_0||ins[1].OpCode.Code!=(call?Code.Call:Code.Ldfld))return false;
    var resolved=ins[1].Operand is FieldReference f?(IMetadataTokenProvider)f.Resolve():((MethodReference)ins[1].Operand).Resolve();
    if(resolved.MetadataToken!=target.MetadataToken)return false;
    if(ins.Length==3)return ins[2].OpCode.Code==Code.Ret;
    // Exact debug build spill/branch/return form. No alternate control edge.
    return ins.Length==6&&ins[2].OpCode.Code==Code.Stloc_0&&ins[3].OpCode.Code is Code.Br or Code.Br_S&&ins[3].Operand==ins[4]&&ins[4].OpCode.Code==Code.Ldloc_0&&ins[5].OpCode.Code==Code.Ret;
}
object Describe(MethodDefinition m)=>new{m.FullName,token="0x"+m.MetadataToken.ToUInt32().ToString("X8"),m.IsPublic,m.IsStatic,m.IsVirtual,m.IsFinal,declaring_type_generic=m.DeclaringType.HasGenericParameters,module=m.Module.FileName,module_sha256=Hash(m.Module.FileName),cil=m.Body.Instructions.Select(i=>new{offset=i.Offset,op=i.OpCode.Name,operand=i.Operand?.ToString()}).ToArray()};
foreach(var r in bad)
{
    int token=Convert.ToInt32(r.GetProperty("token").GetString(),16),offset=r.GetProperty("offset").GetInt32();var caller=(MethodDefinition)asm.MainModule.LookupToken(token);var site=caller.Body.Instructions.Single(i=>i.Offset==offset);var matches=new List<object>();
    if(site.Operand is FieldReference fr)
    {
        var field=fr.Resolve();
        if(site.OpCode.Code==Code.Ldfld&&!field.IsStatic&&!caller.IsConstructor)
        foreach(var m in field.DeclaringType.Methods.Where(m=>m.Parameters.Count==0&&!m.IsStatic&&m.ReturnType.FullName==field.FieldType.FullName))if(Pure(m,field,false))matches.Add(Describe(m));
    }
    else if(site.Operand is MethodReference mr)
    {
        var method=mr.Resolve();
        if(site.OpCode.Code==Code.Call&&method.IsStatic&&method.Parameters.Count==1&&!caller.IsConstructor)
        foreach(var m in method.DeclaringType.Methods.Where(m=>m.IsStatic&&m.Parameters.Select(p=>p.ParameterType.FullName).SequenceEqual(method.Parameters.Select(p=>p.ParameterType.FullName))&&m.ReturnType.FullName==method.ReturnType.FullName))if(Pure(m,method,true))matches.Add(Describe(m));
    }
    rows.Add(new{caller=caller.FullName,token="0x"+token.ToString("X8"),offset,site_opcode=site.OpCode.Name,operand=site.Operand.ToString(),operand_token="0x"+((IMetadataTokenProvider)site.Operand).MetadataToken.ToUInt32().ToString("X8"),matches});
}
File.WriteAllText(args[3],JsonSerializer.Serialize(new{scope="READ_ONLY_EXACT_PUBLIC_PURE_ACCESSOR_AND_FORWARDER_DISCOVERY_NOT_CANDIDATE_CONSTRUCTION",candidate_sha256=Hash(args[0]),rows},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{sites=rows.Count,report=args[3]}));
