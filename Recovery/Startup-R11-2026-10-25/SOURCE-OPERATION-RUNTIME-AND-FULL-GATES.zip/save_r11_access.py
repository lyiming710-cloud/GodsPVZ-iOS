from pathlib import Path
import collections,json
from archive_support import sha,js,pack,variants,manifest
W=Path(__file__).resolve().parent;ROOT=W.parents[1];R=ROOT/'audit/repo-native113';Q=W/'startup-r11';D=R/'Recovery/Startup-R11-2026-10-25';D.mkdir(exist_ok=True)
data=(Q/'candidate1.dll').read_bytes();digest=sha(data);assert digest=='e101c701802969bffe370841abc92cd01ec75592097d60b2b9e3629c5c107637' and data==(Q/'candidate2.dll').read_bytes()
iso=json.loads((Q/'ISOLATION-AND-GATES.json').read_bytes());ops=json.loads((Q/'INDEPENDENT-OPERATION-TEST.json').read_bytes());runtime=json.loads((Q/'RUNTIME-SUMMARY.json').read_bytes());jit=json.loads((Q/'changed-exact-jit-results/RESULT.json').read_bytes())
assert iso['pass_'] and iso['unchanged_methoddefs']==2270 and ops['operation_cases']==532 and ops['sites']==71 and runtime['total_cases']==5583 and runtime['candidate_sha256']==digest and jit['counts']==dict(JIT_PREPARED_NO_EXECUTION=47)
types=json.loads((Q/'FROZEN-WITH-INTERFACE-FACTS.json').read_bytes());members=json.loads((Q/'MEMBER-ACCESS-ALL-2297.json').read_bytes());bad_types=[r for r in types['results'] if r['status']!='PASS'];bad_members=[r for r in members['members'] if not r['allowed']]
assert len(bad_types)==131 and len(bad_members)==145 and len({r['token'] for r in bad_members})==70 and members['unresolved']==0
js(Q/'REMAINING-QUEUES.json',dict(scope='OVERLAPPING_GATE_QUEUES_NOT_TOTAL_GAME_BUG_COUNT',candidate_sha256=digest,frozen_fail_or_unsupported=131,member_rejected_sites=145,member_rejected_methods=70,type_and_access_method_union=len({r['token'] for r in bad_types+bad_members}),type_rows=bad_types,access_rows=bad_members,all_assembly_pass=False))
js(Q/'PHYSICAL-VARIANTS.json',dict(scope='EXACT_RECONSTRUCTION_OF_EXECUTED_FAULT_VARIANTS',variants=variants(Q,data)))
(D/'.gitattributes').write_bytes(b'.gitattributes -text\n*.json -text whitespace=cr-at-eol\n*.md -text\n*.zip -text\n*.yml -text\n')
for name in ['CONSTRUCTION.json','CONSTRUCTION-REPEAT.json','PURE-CONTRACTS.json','INDEPENDENT-OPERATION-TEST.json','ISOLATION-AND-GATES.json','RUNTIME-SUMMARY.json','REMAINING-QUEUES.json','INT64-NEGATIVE-WIDTH.json','LEXICAL-TAIL-CENSUS.json']:(D/name).write_bytes((Q/name).read_bytes())
(D/'EXACT-JIT-CHANGED-47.json').write_bytes((Q/'changed-exact-jit-results/RESULT.json').read_bytes())
pack(D/'STARTUP-R11-CANDIDATE.zip',[('STARTUP-R11.dll',data)])
items=[]
for folder in [Q,W/'startup-r5',W/'startup-r9/runtime',W/'startup-r10/runtime']:
    for p in sorted(folder.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(folder)
        if any(x in ['obj','__pycache__'] for x in rel.parts):continue
        if folder==W/'startup-r5' and any(x.endswith('-runtime-results') for x in rel.parts):continue
        if p.suffix=='.dll' and 'bin' not in rel.parts:continue
        if p.suffix=='.exe' or p.name=='Mono.Cecil.dll':continue
        if folder!=Q and p.suffix not in ['.py','.cs','.csproj','.json','.dll','.pdb']:continue
        items.append((p.relative_to(W).as_posix(),p.read_bytes()))
for folder in ['remaining-native','administrator-next-native','next-runtime-native']:
    for p in sorted((W/folder).glob('*')):
        if p.is_file() and ('.normal-cfg.' in p.name or p.name=='FMOD-HELPER-CFG.json'):items.append((p.relative_to(W).as_posix(),p.read_bytes()))
for p in [W/'archive_support.py',Path(__file__),W/'startup-r2/construct.py',W/'startup-r9/native_oracle.py',W/'startup-r10/native_oracle.py',W/'startup-r10/portable_guard.py',W/'startup-r10/CONSTRUCTION-3.json',W/'startup-r10/METHOD-CIL.json',W/'startup-r10/NATIVE-GLOBALS.json',W/'startup-r10/NATIVE-FLOOR-CFG.json',W/'startup-r5/runtime-admin/bin/Release/net10.0/Mono.Cecil.dll']:items.append((p.relative_to(W).as_posix(),p.read_bytes()))
for p in [ROOT/'audit/bulk350-root-verification-2026-10-22/reviewed-tools/verify_types_reviewed.py',ROOT/'audit/bulk388-qualification-2026-10-23/width-check/width_fixtures.py',ROOT/'audit/native111-publication-2026-10-20/repository/scripts/actions/static_gates.py']:items.append(('required-tools/'+p.name,p.read_bytes()))
pack(D/'SOURCE-OPERATION-RUNTIME-AND-FULL-GATES.zip',items)
status=dict(status='PURE_ACCESS_SUBSTITUTIONS_AND_PRIOR_CALLER_SCOPES_PASS_WIDER_GATES_HELD',candidate_sha256=digest,parent_sha256='9f030dc1c48e6d77e854979091a223fb636c93b1b528b8c6b9fbb2397a34d72e',bytes=len(data),sites_changed=71,methods_touched=47,untouched_methoddefs=2270,new_memberrefs=4,field_and_type_visibility_unchanged=True,operation_level_cases=532,complete_47_native_caller_equivalence=False,
    prior_13_native_caller_scope_records_reexecuted=5583,changed_47_jit=jit['counts'],full_2297_jit_not_rerun=True,parent_r10_full_jit=dict(prepared=2247,rejected=0,unsupported_open_generics=50),whole_frozen_types=dict(raw_pass=2138,raw_fail_or_unsupported=159,interface_fact_pass=2166,interface_fact_fail_or_unsupported=131),member_access=dict(rejected_sites=145,rejected_methods=70,unresolved=0,passed=False),unterminated_lexical_tails=0,
    r11_il2cpp='NOT_RUN',r11_apple_cpp='NOT_RUN',r11_unity='NOT_RUN',ipa=None,ipad_device_acceptance=False,separate_parent_compiler_result='Exact R10 run 40120380134 passed 756 CPP +274 C, not a child qualification')
js(D/'CURRENT-RESULT.json',status)
(D/'README.md').write_bytes('''# Startup R11: 71 pure access substitutions across 47 methods

Candidate `e101c701802969bffe370841abc92cd01ec75592097d60b2b9e3629c5c107637` (19,731,968 bytes), derived from R10 `9f030dc1…34d72e`. This batch legalizes 71 read/call sites across 47 existing methods. It does not claim to recover or execute all 47 original native callers. Existing target method sizes, RVAs, locals, MaxStack, branches, EH and field/type visibility remain unchanged. An independent raw audit proves all other 2,270 MethodDefs unchanged. Old metadata rows/heaps remain, four exact MemberRefs are appended, and only 71 five-byte instructions plus bounded PE/CLI append headers change before the appended metadata root.

## Selection and independent operation evidence

The 216 R10 access failures were inspected against actual candidate and authentic support metadata/CIL. Only public, non-overridable exact leaf contracts were eligible: a direct field read/return, a direct static call/return, or their exact debug spill/branch/return form. Final virtual interface implementations such as List.Count are non-overridable and explicitly recorded. Closed generic declaring owners are retained exactly. Constructors, writes, managed addresses, nontrivial accessors and methods already failing the frozen type gate remain held. Of 89 possible leaf-accessor sites, 18 in failed type scopes were excluded; the other 127 original failures had no eligible exact contract in this pass.

Substitutions include List.Count for private _size reads, Image.fillAmount, Selectable.interactable, TMP onSubmit/textInfo, SwfList.Count, and public Input.GetKey/GetKeyDown forwarding to the same existing private engine methods. Sixty-four sites reuse existing compatible MemberRefs; seven sites share four appended references. Each actual resolved getter/forwarder body, module SHA, visibility/finality and type-initialization flags is recorded. All owners are beforefieldinit; whole engine/package type initialization is outside the isolated execution model.

A separate Cecil walker compares every old/new caller instruction without reading the constructor plan. It resolves each changed public target, verifies it reads the same private field or calls the same private method with the same closed owner, then emits and runs all actual leaf CIL instructions against controlled storage/callees. All 532 isolated operation cases pass, including Int32 bounds, signed-zero/NaN float bits, boolean/reference identities, null receivers and input argument/result/call-count traces. Model storage is public solely for rehosting; actual assembly member visibility is checked separately. This is operation-level substitution evidence, not full-caller/native gameplay equivalence.

Four physical controls are retained. Unrelated code and metadata mutations are rejected by the raw boundary. A public GetKey reference changed to public GetKeyDown still passes the unchanged type checker, but the independent exact-private-callee contract rejects it. Restoring one private Image field read is rejected by the unchanged access auditor. Thus a type PASS alone cannot accept a behaviorally wrong public API substitution.

## Current results and limits

All 47 actual changed methods prepare under CLR JIT and pass the unchanged frozen type checker. The prior 13 native/CIL caller scopes are rerun on exact R11 and all 5,583 records match; these are separate from the 532 operation cases and must not be added as equivalent full-game coverage. A fresh all-2,297-body type/access census retains 131 frozen failures or unsupported cases after exact interface facts. Access failures fall from 216 sites across 111 methods to 145 sites across 70 methods, with zero unresolved members. Forty-one previously failing method access scopes are now clear; the remaining six touched methods still have other held sites. Zero lexical tails remain. A new full 2,297 JIT scan is not claimed: R10's full scan remains parent-bound, and R11 directly checks the 47 changed methods while proving other raw bodies unchanged.

R11 Unity/IL2CPP/Apple compilation, a new unsigned IPA and iPad acceptance are initially pending. Exact R10 separately passed fresh IL2CPP and all 756 C++/274 C Linux checks at run 40120380134; every generated source hash and staged DLL identity was independently read back. That parent result does not qualify this child. Wider type/access and full gameplay scopes remain held.

## Reproduction

Use construct.py with fresh output paths and the exact R10 parent, build/run contracts/Contracts.csproj for the read-only inventory, then verify/Verify.csproj and verify_static.py for independent CIL operations/raw isolation/controls. Existing authentic support, SDK10 and Cecil/exporter/access paths are required; the archive is an evidence/source bundle, not a complete Unity/SDK distribution. Native regressions require Windows x64 and original PC GameAssembly/metadata with the established immutable hashes. DRIVER-DERIVATION records input/output-only changes to previous drivers. All ZIP members and top-level checkpoint files have size/SHA manifests. Read CURRENT-RESULT and every per-suite scope before promotion.
'''.encode());manifest(D)
print(json.dumps(dict(checkpoint=str(D),candidate_sha256=digest,access_sites=145,access_methods=70,operation_cases=532,prior_native_scope_cases=5583,archives={p.name:p.stat().st_size for p in D.glob('*.zip')})))
