using System.Reflection;using System.Runtime.CompilerServices;using System.Runtime.Loader;using System.Security.Cryptography;using System.Text.Json;
// Compile the untouched actual method body. Never invoke it or instantiate a
// Unity object; no Reflection.Emit, instruction rewrites, or missing-type mocks.
public static class Program
{
    public static void Main(string[] args)
    {
        string input=Path.GetFullPath(args[0]),support=Path.GetFullPath(args[1]);int token=Convert.ToInt32(args[2],16);string status="UNSUPPORTED",error="";string? ilSha=null;int? maxStack=null;
        var context=new AssemblyLoadContext("ExactCandidate_"+Guid.NewGuid().ToString("N"),true);
        context.Resolving+=(c,name)=>
        {
            foreach(string extension in new[]{".dll",".exe"})
            {
                string p=Path.Combine(support,name.Name+extension);if(!File.Exists(p))continue;
                var actual=AssemblyName.GetAssemblyName(p);if(actual.FullName!=name.FullName)throw new FileLoadException("Reference identity mismatch: "+p);
                return c.LoadFromAssemblyPath(p);
            }
            return null;
        };
        try
        {
            var a=context.LoadFromAssemblyPath(input);var method=(MethodBase)a.ManifestModule.ResolveMethod(token)!;
            var body=method.GetMethodBody();if(body==null)throw new NotSupportedException("No CIL body");ilSha=Convert.ToHexString(SHA256.HashData(body.GetILAsByteArray()!)).ToLowerInvariant();maxStack=body.MaxStackSize;
            if(method.ContainsGenericParameters)throw new NotSupportedException("Open generic method requires explicit instantiation");
            RuntimeHelpers.PrepareMethod(method.MethodHandle);status="JIT_PREPARED_NO_EXECUTION";
        }
        catch(Exception ex){status=ex is NotSupportedException?"UNSUPPORTED":"REJECTED";error=ex.GetType().FullName+": "+ex.Message;}
        File.WriteAllText(args[3],JsonSerializer.Serialize(new {scope="EXACT_ASSEMBLY_CLR_JIT_VALIDATION_NO_METHOD_EXECUTION",input_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(input))).ToLowerInvariant(),token="0x"+token.ToString("X8"),status,error,il_sha256=ilSha,max_stack=maxStack,reference_resolution_extensions=new[]{".dll",".exe"},method_executed=false,unity_execution=false},new JsonSerializerOptions{WriteIndented=true}));
        context.Unload();Console.WriteLine(status);
    }
}
