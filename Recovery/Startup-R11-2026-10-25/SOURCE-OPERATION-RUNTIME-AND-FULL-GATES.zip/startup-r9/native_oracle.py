"""Original PC constant methods plus real SimpleScript and fmod caller code.

Original 141-instruction CRT fmod helper executes for finite/quiet-NaN frame
inputs. Unexpected CRT-domain handling fails the probe. Text/time are controlled
callees. Native null throw/unwind and actual TMP formatting are not executed.
"""
from pathlib import Path
import ctypes as C,json,sys,struct
Q=Path(__file__).resolve().parent;W=Q.parent;sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
cases=json.loads(Path(sys.argv[1]).read_bytes());out=Path(sys.argv[2]);im=NativeImage();state={};constants=[];results=[]
def value(bits_):return struct.unpack('<f',bytes.fromhex(bits_)[::-1])[0]
def string(s):
    data=s.encode('utf-16-le');p=im.alloc(24+len(data)+2);put32(p+0x10,len(data)//2);C.memmove(p+0x14,data,len(data));return p
def read(p):return C.string_at(p+0x14,get32(p+0x10)*2).decode('utf-16-le')
try:
    for rid,expected in [(0xD5,False),(0xD6,False),(0x312,False),(0x35A,True),(0x489,False)]:
        entry=int.from_bytes(im.pe.get_data(0x181B82D60-im.base+(rid-1)*8,8),'little');raw=bytes.fromhex('b001c3' if expected else '32c0c3');assert C.string_at(entry,3)==raw
        invoke=C.CFUNCTYPE(C.c_bool,P,P,P)(entry)
        for n in range(16):
            owner=0 if n%2==0 else im.alloc(64);arg=im.alloc(32)
            for offset in range(0,32,4):C.c_uint32.from_address(arg+offset).value=(0xffffffff-1234567*n-offset)&0xffffffff
            constants.append(dict(name=f'constant-{0x6000000|rid:08X}-{n}',token=f'0x{0x6000000|rid:08X}',value=bool(invoke(owner,arg,None)),error=None))
    cfg=json.loads((W/'next-runtime-native/076D.normal-cfg.json').read_bytes());helper=json.loads((W/'next-runtime-native/FMOD-HELPER-CFG.json').read_bytes())
    im.verify_caller(0x76d,0x1803B5320,cfg)
    for i in helper['instructions']:assert C.string_at(int(i['va'],16),len(bytes.fromhex(i['bytes'])))==bytes.fromhex(i['bytes'])
    metadata=(ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/original-pc/global-metadata.dat').read_bytes();assert hashlib.sha256(metadata).hexdigest()=='ad992341add498bd1018ac980f42171e0737b0793bf945c8714ad70a445b36b9'
    format_slot=0x1803B536A+0x18036CE;encoded=int.from_bytes(im.pe.get_data(format_slot-im.base,8),'little');assert encoded>>29==5
    literals,literal_bytes,literal_data=struct.unpack_from('<3I',metadata,8);index=(encoded&0x1fffffff)>>1;assert index*8<literal_bytes
    length,at=struct.unpack_from('<2I',metadata,literals+index*8);format_=metadata[literal_data+at:literal_data+at+length].decode();assert format_=='The <#0050FF>count is: </color>{0:2}'
    def init(slot):assert slot==format_slot;put64(slot,string(format_))
    def text(p,fmt,v,method):
        state['trace'].append('Text:'+state['texts'][p]+':'+read(fmt)+':'+bits(v));mode=state['case']['callback']
        if mode=='mutate-frame-on-text':putf(state['owner']+0x28,17)
        if mode=='replace-text-on-text':
            t=im.alloc(64);state['texts'][t]='text-new';put64(state['owner']+0x20,t)
    def delta(method):
        v=value(state['case']['delta']);state['trace'].append('Time:'+bits(v))
        if state['case']['callback']=='mutate-frame-on-time':putf(state['owner']+0x28,19)
        return v
    def unexpected_domain(*unused):raise AssertionError('Unexpected CRT domain path; this oracle does not model errno/error callbacks')
    im.hook(0x18024FEF0,None,[P],init);im.hook(0x1811AF370,None,[P,P,F,P],text);im.hook(0x18132C2F0,F,[P],delta)
    im.hook(0x1802E6538,F,[P,I,I,I],unexpected_domain)
    # All original caller/helper bytes must still be intact after hook setup.
    im.verify_caller(0x76d,0x1803B5320,cfg)
    for i in helper['instructions']:assert C.string_at(int(i['va'],16),len(bytes.fromhex(i['bytes'])))==bytes.fromhex(i['bytes'])
    invoke=C.CFUNCTYPE(None,P,P)(0x1803B5320)
    for case in cases:
        frame=value(case['frame']);assert frame!=float('inf') and frame!=-float('inf')
        state.clear();state.update(case=case,trace=[],texts={});owner=im.alloc(64);t=im.alloc(64);state.update(owner=owner);state['texts'][t]='text';put64(owner+0x20,t);putf(owner+0x28,frame)
        invoke(owner,None);results.append(dict(name=case['name'],trace=list(state['trace']),frame=bits(getf(owner+0x28)),text_id=state['texts'][get64(owner+0x20)],error=None))
    assert not im.errors,im.errors
    report=dict(scope='ACTUAL_PC_CONSTANTS_AND_SIMPLE_CALLER_PLUS_ORIGINAL_CRT_FMOD_FINITE_QUIET_NAN_INPUTS',original_sha256=PC_SHA,caller_instructions=len(cfg['instructions']),fmod_helper_instructions=len(helper['instructions']),
        caller_and_fmod_bytes_preserved=True,format_binding=dict(slot=hex(format_slot),encoded=hex(encoded),literal_index=index,text=format_),callback_errors=im.errors,
        native_exception_unwind=False,crt_errno_or_domain_behavior=False,actual_tmp_formatting=False,unity_execution=False,constants=constants,results=results)
    out.write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(dict(constants=len(constants),simple_cases=len(results),callback_errors=im.errors)))
finally:im.close()
