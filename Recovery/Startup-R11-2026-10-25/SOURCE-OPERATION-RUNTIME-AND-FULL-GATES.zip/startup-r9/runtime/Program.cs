using System.Reflection;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public sealed class RangeState {}
public sealed class DeviceState {}
public sealed class PlantState {}
public sealed class ZombieState {}
public struct RectState {public float x,y,w,h;}
public struct VectorState {public float x,y,z;}
public sealed class SimpleState {public float m_frame;public TextState? m_textMeshPro;}
public sealed class TextState(string id)
{
    public string Id=id;
    public void SetText(string format,float value)
    {
        Program.Trace.Add("Text:"+Id+":"+format+":"+Program.Bits(value));
        if(Program.Current.callback=="mutate-frame-on-text")Program.Owner.m_frame=17;
        if(Program.Current.callback=="replace-text-on-text")Program.Owner.m_textMeshPro=new("text-new");
    }
}
public sealed class Case
{
    public string name {get;set;}="";public string frame {get;set;}="00000000";public string delta {get;set;}="3DCCCCCD";public string callback {get;set;}="none";
}
public static class Program
{
    public static Case Current=new();public static SimpleState Owner=new();public static List<string> Trace=[];
    public static float Value(string bits)=>BitConverter.Int32BitsToSingle(unchecked((int)Convert.ToUInt32(bits,16)));
    public static string Bits(float value)=>float.IsNaN(value)?"NaN":BitConverter.SingleToInt32Bits(value).ToString("X8");
    public static float Delta()
    {
        var v=Value(Current.delta);Trace.Add("Time:"+Bits(v));
        if(Current.callback=="mutate-frame-on-time")Owner.m_frame=19;
        return v;
    }
    static Type Map(MC.TypeReference t)=>t.FullName switch
    {
        "System.Void"=>typeof(void),"System.Boolean"=>typeof(bool),"System.Int32"=>typeof(int),"OccupyState"=>typeof(int),"System.Single"=>typeof(float),"System.String"=>typeof(string),
        "AttackRange"=>typeof(RangeState),"Device"=>typeof(DeviceState),"Plant"=>typeof(PlantState),"Zombie"=>typeof(ZombieState),"UnityEngine.Rect"=>typeof(RectState),"UnityEngine.Vector3"=>typeof(VectorState),
        "TMPro.Examples.SimpleScript"=>typeof(SimpleState),"TMPro.TextMeshPro"=>typeof(TextState),_=>throw new NotSupportedException(t.FullName)
    };
    static FieldInfo Field(MC.FieldReference f)=>Map(f.DeclaringType).GetField(f.Name,BindingFlags.Instance|BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic)??throw new NotSupportedException(f.FullName);
    static MethodBase Method(MC.MethodReference m)=>(m.DeclaringType.FullName+"::"+m.Name) switch
    {
        "TMPro.TMP_Text::SetText"=>typeof(TextState).GetMethod(nameof(TextState.SetText))!,
        "UnityEngine.Time::get_deltaTime"=>typeof(Program).GetMethod(nameof(Delta))!,_=>throw new NotSupportedException(m.FullName)
    };
    public static void Main(string[] args)
    {
        using var module=MC.ModuleDefinition.ReadModule(args[0]);var constants=new List<object>();
        foreach(int token in new[]{0x060000D5,0x060000D6,0x06000312,0x0600035A,0x06000489})
        {
            var method=(MC.MethodDefinition)module.LookupToken(token);var emitted=ActualCil.Emit(method,Map,Field,Method);
            for(int n=0;n<16;n++)
            {
                object? owner=n%2==0?null:Activator.CreateInstance(Map(method.DeclaringType));var parameters=new List<object?>{owner};
                if(method.Parameters.Count!=0)
                {
                    Type t=Map(method.Parameters[0].ParameterType);
                    parameters.Add(t==typeof(int)?unchecked(n*0x1234567-3):t==typeof(RectState)?new RectState{x=n,y=-n,w=Value("7FC00001"),h=Value("80000000")}:t==typeof(VectorState)?new VectorState{x=n,y=float.PositiveInfinity,z=float.NaN}:n%3==0?null:new DeviceState());
                }
                bool? value=null;string? error=null;try{value=(bool)emitted.Invoke(null,parameters.ToArray())!;}catch(Exception e){var x=e.InnerException??e;error=x.GetType().FullName+": "+x.Message;}
                constants.Add(new{name="constant-"+token.ToString("X8")+"-"+n,token="0x"+token.ToString("X8"),value,error});
            }
        }
        var simple=(MC.MethodDefinition)module.LookupToken(0x0600076D);var run=(Action<SimpleState>)ActualCil.Emit(simple,Map,Field,Method).CreateDelegate(typeof(Action<SimpleState>));var results=new List<object>();
        foreach(var c in JsonSerializer.Deserialize<List<Case>>(File.ReadAllText(args[1]))!)
        {
            Current=c;Trace=[];Owner=new(){m_frame=Value(c.frame),m_textMeshPro=new("text")};string? error=null;
            try{run(Owner);}catch(Exception e){error=e.GetType().FullName+": "+e.Message;}
            results.Add(new{name=c.name,trace=Trace.ToArray(),frame=Bits(Owner.m_frame),text_id=Owner.m_textMeshPro?.Id,error});
        }
        Current=new();Trace=[];Owner=new(){m_frame=1,m_textMeshPro=null};string? nullError=null;
        try{run(Owner);}catch(Exception e){nullError=e.GetType().FullName;}
        File.WriteAllText(args[2],JsonSerializer.Serialize(new{scope="ACTUAL_R9_CIL_CONSTANT_AND_SIMPLE_CALLERS_CONTROLLED_TEXT_TIME_CALLEES",input_sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))).ToLowerInvariant(),
            constants,results,managed_null_text_control=new{error=nullError,frame=Bits(Owner.m_frame),native_exception_execution=false},all_source_instructions_emitted=true,unity_execution=false},new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(new{constant_cases=constants.Count,simple_cases=results.Count}));
    }
}
