"""Examine actual exported CIL for the PC-defined invalid double-to-I4 result.

No constructor offset map is read. X64 CLR behavior without this guard cannot
prove portable ARM64 behavior; actual ARM64 execution remains a product gate.
"""
def verify(method):
    b=method['instructions'];floor=next(k for k,i in enumerate(b) if i['opcode']=='call' and i['operand']['identity']=='System.Double System.Math::Floor(System.Double)')
    assert b[floor+1]['opcode']=='stloc' and b[floor+1]['operand']['index']==2
    start=floor+2;g=b[start:start+14]
    assert [i['opcode'] for i in g]==['ldloc','ldc.r8','clt.un','brtrue','ldloc','ldc.r8','clt','brfalse','ldloc','conv.i4','stloc','br','ldc.i4','stloc']
    assert [g[k]['operand']['index'] for k in [0,4,8]]==[2,2,2]
    assert g[1]['operand']==-2147483648.0 and g[5]['operand']==2147483648.0
    assert g[3]['operand']['target']==g[7]['operand']['target']==g[12]['offset']
    assert g[11]['operand']['target']==b[start+14]['offset']
    assert g[12]['operand']==-2147483648 and g[10]['operand']['index']==g[13]['operand']['index']==86
    return dict(pass_=True,property='Only ordered in-range floor doubles reach conv.i4; all NaN/out-of-range values write Int32.MinValue',guard_instructions=14)
