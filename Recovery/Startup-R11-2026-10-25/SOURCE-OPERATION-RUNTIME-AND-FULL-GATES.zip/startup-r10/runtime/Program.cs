using System.Reflection;using System.Security.Cryptography;using System.Text.Json;using MC=Mono.Cecil;
public sealed class SpriteState(string id){public string Id=id;}
public sealed class GameObjectState {}
public sealed class PlantState
{
    public float healthPoint,maxHealthPoint;
    public ListState<int> parameter_ints=null!;
    public ListState<GameObjectState> animationSprites=null!;
}
public static class ResourceState {public static ListState<SpriteState> plantSprites=null!;}
public sealed class ListState<T>(string id,List<T> items)
{
    public string Id=id;public List<T> Items=items;
    public T this[int index]
    {
        get
        {
            T v=Items[index];Program.Trace.Add("Get:"+Id+":"+index+":"+Program.Describe(v));
            if(typeof(T)==typeof(int)&&Program.Current.mode=="get-replaces-parameters")Program.Owner.parameter_ints=new("parameters-new",[99]);
            if(typeof(T)==typeof(int)&&Program.Current.mode=="get-mutates-health")Program.Owner.healthPoint=0;
            if(typeof(T)==typeof(SpriteState)&&Program.SpriteGets++==Program.Current.mutate_get_at&&Program.Current.mode=="sprite-get-replaces-animation")Program.Owner.animationSprites=new("animation-new",[]);
            return v;
        }
        set
        {
            Program.Trace.Add("Set:"+Id+":"+index+":"+Program.Describe(value));Items[index]=value;
            if(typeof(T)==typeof(int)&&Program.Current.mode=="set-replaces-animation")Program.Owner.animationSprites=new("animation-new",[]);
        }
    }
}
public sealed class Case
{
    public string name{get;set;}="";public string hp{get;set;}="00000000";public string max{get;set;}="40400000";
    public int previous{get;set;}=-1;public string mode{get;set;}="none";public int mutate_get_at{get;set;}=0;
}
public static class Program
{
    public static Case Current=new();public static PlantState Owner=new();public static List<string> Trace=[];public static int Changes,SpriteGets;
    public static string Describe<T>(T value)=>value is SpriteState s?s.Id:value?.ToString()??"null";
    public static float Value(string bits)=>BitConverter.Int32BitsToSingle(unchecked((int)Convert.ToUInt32(bits,16)));
    public static string Bits(float value)=>float.IsNaN(value)?"NaN":BitConverter.SingleToInt32Bits(value).ToString("X8");
    public static ListState<SpriteState> Sprites(string id)=>new(id,Enumerable.Range(0,32).Select(k=>new SpriteState(id+"-"+k)).ToList());
    public static bool ChangeSprite(ListState<GameObjectState> list,string name,SpriteState? sprite)
    {
        Changes++;bool result=Current.mode!="false-result"&&(Current.mode!="alternating-result"||Changes%2==0);
        Trace.Add("Change:"+list.Id+":"+name+":"+(sprite?.Id??"null")+":"+(result?"1":"0"));
        if(Changes==1&&Current.mode=="change-replaces-animation")Owner.animationSprites=new("animation-new",[]);
        if(Changes==1&&Current.mode=="change-replaces-sprites")ResourceState.plantSprites=Sprites("sprites-new");
        return result;
    }
    static Type Map(MC.TypeReference t)
    {
        if(t is MC.ArrayType a)return Map(a.ElementType).MakeArrayType();
        if(t is MC.GenericInstanceType g&&g.ElementType.FullName=="System.Collections.Generic.List`1")return typeof(ListState<>).MakeGenericType(g.GenericArguments.Select(Map).ToArray());
        return t.FullName switch
        {
            "System.Void"=>typeof(void),"System.Boolean"=>typeof(bool),"System.Int32"=>typeof(int),"System.Single"=>typeof(float),"System.Double"=>typeof(double),"System.String"=>typeof(string),"System.Object"=>typeof(object),"System.IntPtr"=>typeof(IntPtr),
            "Plant"=>typeof(PlantState),"UnityEngine.Sprite"=>typeof(SpriteState),"UnityEngine.GameObject"=>typeof(GameObjectState),"ResourceManager"=>typeof(ResourceState),_=>throw new NotSupportedException("Unmapped type: "+t.FullName)
        };
    }
    static FieldInfo Field(MC.FieldReference f)=>Map(f.DeclaringType).GetField(f.Name,BindingFlags.Public|BindingFlags.Static|BindingFlags.Instance)??throw new NotSupportedException(f.FullName);
    static MethodBase Method(MC.MethodReference m)
    {
        if(m.DeclaringType is MC.GenericInstanceType g&&g.ElementType.FullName=="System.Collections.Generic.List`1")return Map(g).GetMethod(m.Name)!;
        if(m.DeclaringType.FullName=="System.Math"&&m.Name=="Floor")return typeof(Math).GetMethod("Floor",[typeof(double)])!;
        if(m.DeclaringType.FullName=="GlobalStaticVars"&&m.Name=="ChangeSprite")return typeof(Program).GetMethod(nameof(ChangeSprite))!;
        throw new NotSupportedException("Unmapped callee: "+m.FullName);
    }
    public static void Main(string[] args)
    {
        byte[] raw=File.ReadAllBytes(args[0]);using var module=MC.ModuleDefinition.ReadModule(new MemoryStream(raw));var source=(MC.MethodDefinition)module.LookupToken(0x06000383);
        var run=ActualCil.Emit(source,Map,Field,Method).CreateDelegate<Action<PlantState>>();var rows=new List<object>();
        foreach(var c in JsonSerializer.Deserialize<List<Case>>(File.ReadAllText(args[1]))!)
        {
            Current=c;Trace=[];Changes=0;SpriteGets=0;Owner=new(){healthPoint=Value(c.hp),maxHealthPoint=Value(c.max),parameter_ints=new("parameters",[c.previous]),animationSprites=new("animation",[])};ResourceState.plantSprites=Sprites("sprites");
            string? error=null;try{run(Owner);}catch(Exception e){error=e.GetType().FullName;}
            rows.Add(new{name=c.name,trace=Trace.ToArray(),previous=Owner.parameter_ints.Items[0],parameters_id=Owner.parameter_ints.Id,animation_id=Owner.animationSprites.Id,sprites_id=ResourceState.plantSprites.Id,hp=Bits(Owner.healthPoint),max=Bits(Owner.maxHealthPoint),changes=Changes,error});
        }
        File.WriteAllText(args[2],JsonSerializer.Serialize(new{scope="COMPLETE_ACTUAL_CANDIDATE_CIL_REHOST_CONTROLLED_LIST_AND_SPRITE_CALLEES",input_sha256=Convert.ToHexString(SHA256.HashData(raw)).ToLowerInvariant(),source_instructions=source.Body.Instructions.Count,source_locals=source.Body.Variables.Count,all_source_instructions_emitted=true,private_model_storage_only=true,unity_execution=false,results=rows},new JsonSerializerOptions{WriteIndented=true}));
        Console.WriteLine(JsonSerializer.Serialize(new{cases=rows.Count}));
    }
}
