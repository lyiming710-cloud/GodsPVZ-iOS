"""Run original 592-instruction caller and original 49-instruction Floor helper.

Actual CVTTSD2SI, integer clamp and all 22 sprite call sites execute. Metadata,
arrays, lists and sprite changes are controlled contracts; no Windows/Unity EH.
"""
from pathlib import Path
import ctypes as C,hashlib,json,struct,sys
Q=Path(__file__).resolve().parent;W=Q.parent;sys.path.insert(0,str(W/'startup-r5'))
from native_runtime_common import *
im=NativeImage();state={};results=[];cases=json.loads(Path(sys.argv[1]).read_bytes())
def value(s):return struct.unpack('<f',bytes.fromhex(s)[::-1])[0]
def string(s):
    b=s.encode('utf-16-le');p=im.alloc(24+len(b)+2);put32(p+0x10,len(b)//2);C.memmove(p+0x14,b,len(b));return p
def read(p):return C.string_at(p+0x14,get32(p+0x10)*2).decode('utf-16-le')
def objects(id_,items):
    p=im.alloc(64);state['lists'][p]=dict(id=id_,items=list(items));return p
def sprites(id_):
    items=[]
    for k in range(32):
        p=im.alloc(32);state['sprites'][p]=id_+'-'+str(k);items.append(p)
    return objects(id_,items)
def object_id(p):return state['lists'][p]['id']
try:
    cfg=json.loads((W/'next-runtime-native/0383.normal-cfg.json').read_bytes());floor=json.loads((Q/'NATIVE-FLOOR-CFG.json').read_bytes());globals_=json.loads((Q/'NATIVE-GLOBALS.json').read_bytes())
    assert len(cfg['instructions'])==592 and len(floor['instructions'])==49 and not cfg['indirect_jumps'] and not cfg['tail_targets']
    im.verify_caller(0x383,0x180352b10,cfg)
    for i in floor['instructions']:assert C.string_at(int(i['va'],16),len(bytes.fromhex(i['bytes'])))==bytes.fromhex(i['bytes'])
    global_map={int(r['slot'],16):r for r in globals_};assert global_map[0x181bb6478]['kind']==1
    # This slot is loaded by original MOV at 0x180352E32; original static +0x10
    # agrees with the immutable native-fields ResourceManager.plantSprites row.
    fields=json.loads((ROOT/'audit/offline-test-handoff-2026-10-14/payload/inputs/maps/native-fields.json').read_text('utf-8-sig'))
    assert next(r for r in fields if r['type']=='ResourceManager' and r['name']=='plantSprites')['offset']==16
    def init(at):
        assert at in global_map,hex(at);r=global_map[at]
        if r['kind']==5:
            if at not in im.classes:im.classes[at]=string(r['string'])
            put64(at,im.classes[at])
        else:im.class_slot(at)
    for at,r in global_map.items():assert get64(at)==int(r['encoded'],16);init(at)
    static=get64(im.classes[0x181bb6478]+0xb8)
    def get_int(p,index,method):
        row=state['lists'][p];v=row['items'][index];state['trace'].append(f"Get:{row['id']}:{index}:{v}")
        if state['case']['mode']=='get-replaces-parameters':put64(state['owner']+0x218,objects('parameters-new',[99]))
        if state['case']['mode']=='get-mutates-health':putf(state['owner']+0x94,0)
        return v
    def set_int(p,index,v,method):
        row=state['lists'][p];state['trace'].append(f"Set:{row['id']}:{index}:{v}");row['items'][index]=v
        if state['case']['mode']=='set-replaces-animation':put64(state['owner']+0x148,objects('animation-new',[]))
    def get_sprite(p,index,method):
        row=state['lists'][p];v=row['items'][index];state['trace'].append(f"Get:{row['id']}:{index}:{state['sprites'][v]}")
        if state['sprite_gets']==state['case'].get('mutate_get_at',0) and state['case']['mode']=='sprite-get-replaces-animation':put64(state['owner']+0x148,objects('animation-new',[]))
        state['sprite_gets']+=1;return v
    def change(p,name,sprite,method):
        state['changes']+=1;mode=state['case']['mode'];result=mode!='false-result' and (mode!='alternating-result' or state['changes']%2==0)
        state['trace'].append(f"Change:{object_id(p)}:{read(name)}:{state['sprites'].get(sprite,'null')}:{int(result)}")
        if state['changes']==1 and mode=='change-replaces-animation':put64(state['owner']+0x148,objects('animation-new',[]))
        if state['changes']==1 and mode=='change-replaces-sprites':put64(static+0x10,sprites('sprites-new'))
        return result
    def array(cls,n,method):
        assert n==8;nptr=im.alloc(32+8*n);put64(nptr,cls);put64(nptr+0x18,n);return nptr
    def reject(*args):raise AssertionError('Native null/range throw outside supported normal-object oracle')
    im.hook(0x18024fef0,None,[P],init);im.hook(0x1802501e0,None,[P],lambda _:None)
    im.hook(0x180836790,I,[P,I,P],get_int);im.hook(0x180836a10,None,[P,I,I,P],set_int)
    im.hook(0x180825710,P,[P,I,P],get_sprite);im.hook(0x18031b050,C.c_bool,[P,P,P,P],change)
    im.hook(0x18024f3e0,P,[P,C.c_size_t,P],array);im.hook(0x18024f360,None,[P],lambda _:None)
    im.hook(0x180250150,None,[P],reject);im.hook(0x180250140,None,[],reject)
    im.verify_caller(0x383,0x180352b10,cfg)
    for i in floor['instructions']:assert C.string_at(int(i['va'],16),len(bytes.fromhex(i['bytes'])))==bytes.fromhex(i['bytes'])
    invoke=C.CFUNCTYPE(None,P,P)(0x180352b10)
    for c in cases:
        state.clear();state.update(case=c,trace=[],lists={},sprites={},changes=0,sprite_gets=0);owner=im.alloc(1024);state['owner']=owner
        putf(owner+0x94,value(c['hp']));putf(owner+0x98,value(c['max']));put64(owner+0x218,objects('parameters',[c['previous']]));put64(owner+0x148,objects('animation',[]));put64(static+0x10,sprites('sprites'))
        invoke(owner,None);assert not im.errors,im.errors
        pars=state['lists'][get64(owner+0x218)]
        results.append(dict(name=c['name'],trace=list(state['trace']),previous=pars['items'][0],parameters_id=pars['id'],animation_id=object_id(get64(owner+0x148)),sprites_id=object_id(get64(static+0x10)),hp=bits(getf(owner+0x94)),max=bits(getf(owner+0x98)),changes=state['changes'],error=None))
    report=dict(scope='ACTUAL_PC_CALLER_FLOOR_CVTTSD2SI_AND_ALL_SPRITE_BRANCHES_CONTROLLED_CALLEES',original_sha256=PC_SHA,caller_instructions=592,floor_helper_instructions=49,caller_and_floor_bytes_preserved=True,original_string_bindings=globals_,callback_errors=im.errors,
        native_exception_unwind=False,actual_list_implementation=False,actual_sprite_implementation=False,unity_execution=False,results=results)
    Path(sys.argv[2]).write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(dict(cases=len(results),callback_errors=im.errors)))
finally:im.close()
